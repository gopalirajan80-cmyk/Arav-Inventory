// Server side of the multi-device sync.
// Every browser-storage key of the app ("krishiyantra_*") is kept here as
//   key -> { v: value (string) | null, m: last-modified time (ms), s: server version, d: deleted? }
// Newest "m" wins per key, so two devices editing DIFFERENT data never overwrite each other.

export type SyncEntry = { v: string | null; m: number; s: number; d?: boolean };
export type SyncDb = { version: number; entries: Record<string, SyncEntry> };

export const emptySyncDb = (): SyncDb => ({ version: 0, entries: {} });

const KEY_RE = /^krishiyantra_[A-Za-z0-9_\-:.]{1,160}$/;
const MAX_VALUE = 40 * 1024 * 1024;       // 40 MB per key
const MAX_FUTURE_MS = 10 * 60 * 1000;     // ignore clocks more than 10 min ahead

export function readSince(db: SyncDb, since: number, skip?: Set<string>) {
  const entries: Record<string, SyncEntry> = {};
  for (const [k, e] of Object.entries(db.entries)) {
    if (e.s > since && !(skip && skip.has(k))) entries[k] = e;
  }
  return { version: db.version, entries };
}

export function applyPut(db: SyncDb, body: any, now = Date.now()) {
  const incoming = body && typeof body === 'object' ? body.entries : null;
  if (!incoming || typeof incoming !== 'object') {
    return { error: 'Invalid payload' as const };
  }
  const nextVersion = db.version + 1;
  const entries = { ...db.entries }; // copy-on-write: caller only commits if disk save succeeds
  const accepted: string[] = [];
  const rejected: string[] = []; // server already has same/newer data -> sent back to the client
  let risky = false;

  for (const [key, raw] of Object.entries<any>(incoming)) {
    if (!KEY_RE.test(key) || !raw || typeof raw !== 'object') continue;
    const deleted = raw.d === true || raw.v === null;
    if (!deleted && (typeof raw.v !== 'string' || raw.v.length > MAX_VALUE)) continue;
    const m = Math.min(Number(raw.m) || 0, now + MAX_FUTURE_MS);
    if (m <= 0) continue;
    const existing = entries[key];
    if (existing && m <= existing.m) { rejected.push(key); continue; }

    const prevLen = existing && !existing.d && existing.v ? existing.v.length : 0;
    const newLen = deleted ? 0 : (raw.v as string).length;
    if (prevLen > 0 && (deleted || (prevLen > 2000 && newLen < prevLen * 0.5))) risky = true;

    entries[key] = deleted ? { v: null, m, s: nextVersion, d: true } : { v: raw.v, m, s: nextVersion };
    accepted.push(key);
  }

  const next: SyncDb = accepted.length ? { version: nextVersion, entries } : db;
  return { next, accepted, rejected, risky, changed: accepted.length > 0 };
}
