// Simple password login + signed session token (no extra npm packages needed).
import crypto from 'crypto';
import { getUser, normId, verifyUserPassword } from './server-users.ts';

const TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const MAX_FAILS = 5;                            // wrong tries allowed...
const LOCK_MS = 15 * 60 * 1000;                 // ...before a 15 minute lock

export const APP_PASSWORD = process.env.APP_PASSWORD || '';
export const AUTH_ENABLED = APP_PASSWORD.length > 0;

// Secret for signing tokens. Changing the password (or SESSION_SECRET) logs everyone out.
const SECRET = crypto
  .createHash('sha256')
  .update('krishiyantra-session:' + (process.env.SESSION_SECRET || '') + ':' + APP_PASSWORD)
  .digest();

const b64url = (b: Buffer | string) => Buffer.from(b).toString('base64url');
const sign = (data: string) => crypto.createHmac('sha256', SECRET).update(data).digest('base64url');

function safeEqual(a: string, b: string): boolean {
  const ha = crypto.createHash('sha256').update(a).digest();
  const hb = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(ha, hb);
}

export interface AuthUser { id: string; role: 'OWNER' | 'STAFF'; tv: number }

export function createToken(u: AuthUser): string {
  const payload = b64url(JSON.stringify({ u: u.id, r: u.role, tv: u.tv, exp: Date.now() + TOKEN_TTL_MS }));
  return `${payload}.${sign(payload)}`;
}

/** Returns who the token belongs to, or null if invalid / expired / the staff account was disabled or reset. */
export function verifyToken(token: string | undefined): AuthUser | null {
  if (!token) return null;
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expected = sign(payload);
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const p = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8'));
    if (typeof p.exp !== 'number' || p.exp <= Date.now()) return null;
    if (p.r === 'OWNER') return { id: 'owner', role: 'OWNER', tv: 0 };
    if (p.r !== 'STAFF' || typeof p.u !== 'string') return null;
    const u = getUser(p.u);
    if (!u || !u.active || u.tv !== p.tv) return null; // disabled, deleted or password changed
    return { id: u.id, role: 'STAFF', tv: u.tv };
  } catch {
    return null;
  }
}

// ---- brute-force protection (in memory): per IP, and per staff ID ----
const fails = new Map<string, { count: number; lockedUntil: number }>();

function lockedMsg(rec: { lockedUntil: number }, now: number) {
  const mins = Math.ceil((rec.lockedUntil - now) / 60000);
  return `धेरै गलत प्रयास। ${mins} मिनेटपछि पुनः प्रयास गर्नुहोस्।`;
}
function recordFail(key: string, max: number, now: number) {
  const rec = fails.get(key) || { count: 0, lockedUntil: 0 };
  rec.count += 1;
  if (rec.count >= max) { rec.lockedUntil = now + LOCK_MS; rec.count = 0; }
  fails.set(key, rec);
}

export interface LoginResult {
  ok: boolean; status: number; error?: string; token?: string;
  user?: { id: string; name: string; role: string; allowedTabs: string[] };
}

/** Login with ID + password. ID "owner" (or empty, for old links) + APP_PASSWORD = owner; anything else = staff account. */
export function checkLogin(ip: string, idRaw: unknown, password: unknown): LoginResult {
  const now = Date.now();
  const id = normId(idRaw);
  const ipRec = fails.get(ip);
  if (ipRec && ipRec.lockedUntil > now) return { ok: false, status: 429, error: lockedMsg(ipRec, now) };
  const idKey = 'id:' + id;
  const idRec = id && id !== 'owner' ? fails.get(idKey) : undefined;
  if (idRec && idRec.lockedUntil > now) return { ok: false, status: 429, error: lockedMsg(idRec, now) };

  if (id === '' || id === 'owner') {
    if (typeof password === 'string' && safeEqual(password, APP_PASSWORD)) {
      fails.delete(ip);
      return {
        ok: true, status: 200, token: createToken({ id: 'owner', role: 'OWNER', tv: 0 }),
        user: { id: 'owner', name: 'Owner', role: 'OWNER', allowedTabs: [] },
      };
    }
  } else {
    const u = verifyUserPassword(id, password);
    if (u) {
      fails.delete(ip); fails.delete(idKey);
      return {
        ok: true, status: 200, token: createToken({ id: u.id, role: 'STAFF', tv: u.tv }),
        user: { id: u.id, name: u.name, role: u.role, allowedTabs: u.allowedTabs },
      };
    }
    recordFail(idKey, 10, now);
  }
  recordFail(ip, MAX_FAILS, now);
  return { ok: false, status: 401, error: 'ID वा पासवर्ड मिलेन।' };
}

// Express middleware: blocks requests without a valid Bearer token; sets req.user.
export function requireAuth(req: any, res: any, next: any) {
  if (!AUTH_ENABLED) { req.user = { id: 'owner', role: 'OWNER', tv: 0 }; return next(); } // local dev only
  const header: string = req.headers['authorization'] || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : undefined;
  const user = verifyToken(token);
  if (user) { req.user = user; return next(); }
  return res.status(401).json({ error: 'लगइन आवश्यक छ।' });
}

// Only the owner may pass (use after requireAuth).
export function requireOwner(req: any, res: any, next: any) {
  if (req.user?.role === 'OWNER') return next();
  return res.status(403).json({ error: 'यो काम मालिकले मात्र गर्न सक्छ।' });
}

// Simple per-IP rate limit (in memory) e.g. rateLimit(30, 60_000) = 30 requests per minute
export function rateLimit(max: number, windowMs: number) {
  const hits = new Map<string, { n: number; reset: number }>();
  return (req: any, res: any, next: any) => {
    const now = Date.now();
    const ip = req.ip || 'unknown';
    const rec = hits.get(ip);
    if (!rec || rec.reset < now) { hits.set(ip, { n: 1, reset: now + windowMs }); return next(); }
    rec.n += 1;
    if (rec.n > max) return res.status(429).json({ error: 'धेरै अनुरोध। केही बेरपछि प्रयास गर्नुहोस्।' });
    return next();
  };
}
