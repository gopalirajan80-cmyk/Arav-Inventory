// Per-staff accounts: each staff member has their own login ID and password.
// Passwords are never stored - only a salted scrypt hash. Saved in DATA_DIR/erp-users.json (with backups).
import crypto from 'crypto';
import { createStore } from './server-storage.ts';

export type StaffRole = 'ACCOUNTANT' | 'SALESMAN' | 'COUNTER_SALES' | 'SUPERVISOR' | 'STAFF';
export const STAFF_ROLES: StaffRole[] = ['ACCOUNTANT', 'SALESMAN', 'COUNTER_SALES', 'SUPERVISOR', 'STAFF'];

export interface StaffUser {
  id: string;            // login ID (lowercase letters/digits/._-), e.g. "ram" or "9841234567"
  name: string;          // display name
  role: StaffRole;
  allowedTabs: string[]; // [] = default staff tabs
  active: boolean;
  salt: string;
  hash: string;
  tv: number;            // token version - bumped on password reset / disable => old logins stop working
  createdAt: string;
  updatedAt: string;
}
interface UsersDb { users: Record<string, StaffUser> }

const store = createStore<UsersDb>('erp-users.json', 'users', () => ({ users: {} }));
store.load();

export const RESERVED_IDS = new Set(['owner', 'admin', 'superadmin']);
export const ID_RE = /^[a-z0-9][a-z0-9._-]{2,31}$/;
export const MIN_PASSWORD = 6;

const hashPw = (password: string, salt: string) =>
  crypto.scryptSync(password, salt, 64).toString('hex');

export const normId = (v: unknown) => (typeof v === 'string' ? v.trim().toLowerCase() : '');

export function getUser(id: string): StaffUser | undefined {
  return store.load().users[normId(id)];
}

export function verifyUserPassword(id: string, password: unknown): StaffUser | null {
  const u = getUser(id);
  // do the hash work even for unknown users so timing does not reveal which IDs exist
  const salt = u?.salt || 'x'.repeat(32);
  const h = hashPw(typeof password === 'string' ? password : '', salt);
  if (!u || !u.active) return null;
  const a = Buffer.from(h, 'hex'), b = Buffer.from(u.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b) ? u : null;
}

export const publicUser = (u: StaffUser) => ({
  id: u.id, name: u.name, role: u.role, allowedTabs: u.allowedTabs, active: u.active,
  createdAt: u.createdAt, updatedAt: u.updatedAt,
});
export const listUsers = () => Object.values(store.load().users).map(publicUser)
  .sort((a, b) => a.name.localeCompare(b.name));

const cleanTabs = (t: unknown): string[] =>
  Array.isArray(t) ? t.filter((x): x is string => typeof x === 'string' && /^[a-z_]{1,32}$/.test(x)).slice(0, 40) : [];

export function createUser(input: any): { ok: true; user: ReturnType<typeof publicUser> } | { ok: false; error: string } {
  const id = normId(input?.id);
  const name = typeof input?.name === 'string' ? input.name.trim().slice(0, 80) : '';
  const password = typeof input?.password === 'string' ? input.password : '';
  const role: StaffRole = STAFF_ROLES.includes(input?.role) ? input.role : 'STAFF';
  if (!ID_RE.test(id)) return { ok: false, error: 'ID ३–३२ अक्षर (a-z, 0-9, . _ -) को हुनुपर्छ।' };
  if (RESERVED_IDS.has(id)) return { ok: false, error: 'यो ID प्रयोग गर्न मिल्दैन।' };
  if (!name) return { ok: false, error: 'कर्मचारीको नाम चाहिन्छ।' };
  if (password.length < MIN_PASSWORD) return { ok: false, error: `पासवर्ड कम्तीमा ${MIN_PASSWORD} अक्षरको हुनुपर्छ।` };
  const db = store.load();
  if (db.users[id]) return { ok: false, error: 'यो ID पहिले नै छ।' };
  const salt = crypto.randomBytes(16).toString('hex');
  const now = new Date().toISOString();
  const user: StaffUser = {
    id, name, role, allowedTabs: cleanTabs(input?.allowedTabs), active: true,
    salt, hash: hashPw(password, salt), tv: 1, createdAt: now, updatedAt: now,
  };
  store.save({ users: { ...db.users, [id]: user } });
  return { ok: true, user: publicUser(user) };
}

export function updateUser(idRaw: string, input: any): { ok: true; user: ReturnType<typeof publicUser> } | { ok: false; error: string } {
  const id = normId(idRaw);
  const db = store.load();
  const cur = db.users[id];
  if (!cur) return { ok: false, error: 'कर्मचारी फेला परेन।' };
  const next: StaffUser = { ...cur, updatedAt: new Date().toISOString() };
  if (typeof input?.name === 'string' && input.name.trim()) next.name = input.name.trim().slice(0, 80);
  if (STAFF_ROLES.includes(input?.role)) next.role = input.role;
  if (input?.allowedTabs !== undefined) next.allowedTabs = cleanTabs(input.allowedTabs);
  if (typeof input?.active === 'boolean') {
    if (input.active !== cur.active) next.tv = cur.tv + 1;
    next.active = input.active;
  }
  if (input?.password !== undefined) {
    if (typeof input.password !== 'string' || input.password.length < MIN_PASSWORD)
      return { ok: false, error: `पासवर्ड कम्तीमा ${MIN_PASSWORD} अक्षरको हुनुपर्छ।` };
    next.salt = crypto.randomBytes(16).toString('hex');
    next.hash = hashPw(input.password, next.salt);
    next.tv = cur.tv + 1; // logs the staff member out everywhere
  }
  store.save({ users: { ...db.users, [id]: next } });
  return { ok: true, user: publicUser(next) };
}

export function deleteUser(idRaw: string): boolean {
  const id = normId(idRaw);
  const db = store.load();
  if (!db.users[id]) return false;
  const { [id]: _gone, ...rest } = db.users;
  store.save({ users: rest }, { risky: true });
  return true;
}
