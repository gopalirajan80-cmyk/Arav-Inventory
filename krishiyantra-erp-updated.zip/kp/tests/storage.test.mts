import fs from 'fs';
import { createStore, BACKUP_DIR } from '../server-storage.ts';
import { emptySyncDb } from '../server-sync.ts';
let p=0,f=0; const ok=(c:boolean,m:string)=>{c?p++:f++;console.log((c?'  PASS ':'  FAIL ')+m)};
const s1 = createStore<any>('erp-sync-db.json','sync',emptySyncDb);
ok(s1.load().version===0,'empty start');
s1.save({version:1,entries:{a:{v:'1',m:1,s:1}}});
s1.save({version:2,entries:{a:{v:'2',m:2,s:2}}},{risky:true});
const names=fs.readdirSync(BACKUP_DIR);
ok(names.some(n=>n.includes('hourly'))&&names.some(n=>n.includes('daily'))&&names.some(n=>n.includes('risky')),'hourly+daily+risky backups: '+names.length);
const s2 = createStore<any>('erp-sync-db.json','sync',emptySyncDb);   // simulates server restart
ok(s2.load().version===2,'data survives restart');
fs.writeFileSync(s2.file,'{broken');
const s3 = createStore<any>('erp-sync-db.json','sync',emptySyncDb);
ok(s3.load().version>=1,'damaged main file -> restored from backup (version '+s3.load().version+')');
ok(fs.readdirSync(process.env.DATA_DIR!).filter(x=>x.includes('.tmp')).length===0,'no temp files left');
console.log(`${p} passed, ${f} failed`); process.exit(f?1:0);
