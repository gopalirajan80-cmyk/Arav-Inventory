import { createSyncEngine } from '../src/utils/syncEngine.ts';
import { applyPut, readSince, emptySyncDb } from '../server-sync.ts';

let pass = 0, fail = 0;
const ok = (c: boolean, msg: string) => { c ? pass++ : fail++; console.log((c ? '  PASS ' : '  FAIL ') + msg); };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---- fake server ----
let db = emptySyncDb();
let serverUp = true;
function fetchFn(url: string, init: any = {}) {
  if (!serverUp) return Promise.reject(new Error('offline'));
  const u = new URL(url, 'http://x');
  const json = (o: any, status = 200) => Promise.resolve({ ok: status < 300, status, json: async () => o } as any);
  if (u.pathname === '/api/sync' && (init.method || 'GET') === 'GET') {
    return json({ success: true, ...readSince(db, Number(u.searchParams.get('since')) || 0) });
  }
  if (u.pathname === '/api/sync' && init.method === 'PUT') {
    const body = JSON.parse(init.body);
    const r: any = applyPut(db, body);
    if (r.error) return json({ error: r.error }, 400);
    db = r.next;
    return json({ success: true, ...readSince(db, Number(body.since) || 0, new Set(r.accepted)) });
  }
  return json({}, 404);
}

// ---- fake device (own storage + own prototype) ----
function makeDevice(name: string, clockOffset = 0) {
  class FakeStorage {
    m = new Map<string, string>();
    get length() { return this.m.size; }
    key(i: number) { return [...this.m.keys()][i] ?? null; }
    getItem(k: string) { return this.m.has(k) ? this.m.get(k)! : null; }
    setItem(k: string, v: string) { this.m.set(k, String(v)); }
    removeItem(k: string) { this.m.delete(k); }
  }
  const storage: any = new FakeStorage();
  const engine = createSyncEngine({ storage, proto: FakeStorage.prototype, fetchFn: fetchFn as any, now: () => Date.now() + clockOffset });
  return { name, storage, engine };
}
const KEYS = { inv: 'krishiyantra_invoices_v3', items: 'krishiyantra_items_v3', ret: 'krishiyantra_sales_returns_v1', lang: 'krishiyantra_lang_v3' };

console.log('1) Existing device with data from before sync (legacy) uploads to server');
const A = makeDevice('A');
A.storage.m.set(KEYS.inv, '["inv1","inv2"]'); A.storage.m.set(KEYS.items, '["itemA"]'); A.storage.m.set(KEYS.lang, 'ne');
ok((await A.engine.init()).ok, 'A init ok');
await A.engine.flushNow();
ok(db.entries[KEYS.inv]?.v === '["inv1","inv2"]', 'server has invoices');
ok(db.entries[KEYS.items]?.v === '["itemA"]', 'server has items');
ok(!(KEYS.lang in db.entries), 'device-only language setting is NOT uploaded');

console.log('2) App deleted / new phone: login restores everything BEFORE app starts');
const B = makeDevice('B');
const r = await B.engine.init();
ok(r.ok, 'B init ok');
ok(B.storage.getItem(KEYS.inv) === '["inv1","inv2"]' && B.storage.getItem(KEYS.items) === '["itemA"]', 'B has all A data immediately after init');
ok(B.storage.getItem(KEYS.lang) === null, 'B does not get A language');
ok(B.engine.getStatus().pending === 0, 'nothing pending on B after restore');

console.log('3) Edit on B flows to A');
B.storage.setItem(KEYS.inv, '["inv1","inv2","inv3"]');
B.storage.setItem(KEYS.ret, '["ret1"]');
await sleep(1700);
ok(db.entries[KEYS.inv]?.v.includes('inv3'), 'server got inv3 after debounce');
await A.engine.syncNow();
ok(A.storage.getItem(KEYS.inv) === '["inv1","inv2","inv3"]' && A.storage.getItem(KEYS.ret) === '["ret1"]', 'A pulled B changes incl. returns');
ok(A.engine.getStatus().remoteChanged === true, 'A is told to refresh');

console.log('4) Different keys edited at once -> both kept');
A.storage.setItem(KEYS.items, '["itemA","itemB"]');
B.storage.setItem(KEYS.ret, '["ret1","ret2"]');
await sleep(1700);
await A.engine.syncNow(); await B.engine.syncNow();
ok(A.storage.getItem(KEYS.items) === '["itemA","itemB"]' && B.storage.getItem(KEYS.items) === '["itemA","itemB"]', 'items edit reached both');
ok(A.storage.getItem(KEYS.ret) === '["ret1","ret2"]' && B.storage.getItem(KEYS.ret) === '["ret1","ret2"]', 'returns edit reached both');

console.log('5) Same key edited offline on both -> newest wins, loser kept in conflict copy');
serverUp = false;
A.storage.setItem(KEYS.inv, '["A-offline"]');
await sleep(20);
B.storage.setItem(KEYS.inv, '["B-offline-later"]');
await sleep(1700);
ok(A.engine.getStatus().pending > 0 && B.engine.getStatus().pending > 0, 'both show pending while offline');
serverUp = true;
await A.engine.syncNow(); await B.engine.syncNow(); await A.engine.syncNow();
ok(A.storage.getItem(KEYS.inv) === '["B-offline-later"]' && B.storage.getItem(KEYS.inv) === '["B-offline-later"]', 'newest edit won on both devices');
ok(A.storage.getItem('ky_conflict_' + KEYS.inv) === '["A-offline"]', 'overwritten copy saved on A (nothing silently lost)');

console.log('5b) Same LIST edited on two devices at once (records with id) -> nothing lost');
serverUp = false;
A.storage.setItem(KEYS.items, '[{"id":"1","n":"x"},{"id":"A2","n":"added on A"}]');
B.storage.setItem(KEYS.items, '[{"id":"1","n":"x"},{"id":"B2","n":"added on B"}]');
await sleep(1700);
serverUp = true;
await B.engine.syncNow(); await A.engine.syncNow(); await A.engine.flushNow(); await B.engine.syncNow(); await A.engine.syncNow();
const ids = (d: any) => JSON.parse(d.storage.getItem(KEYS.items)).map((x: any) => x.id).sort().join(',');
ok(ids(A) === '1,A2,B2' && ids(B) === '1,A2,B2', 'both devices end with records 1, A2 and B2');
ok(JSON.parse(db.entries[KEYS.items].v!).length === 3, 'server holds the merged list');

console.log('6) Delete propagates');
A.storage.removeItem(KEYS.ret);
await sleep(1700); await B.engine.syncNow();
ok(B.storage.getItem(KEYS.ret) === null, 'deletion reached B');
ok(db.entries[KEYS.ret]?.d === true, 'server holds tombstone');

console.log('7) New device while OFFLINE must not start with empty data');
serverUp = false;
const C = makeDevice('C');
ok((await C.engine.init()).ok === false, 'init refuses (ok=false) so empty app cannot overwrite server');
serverUp = true;

console.log('8) Server data lost (disk failure) -> devices re-upload everything');
db = emptySyncDb();
await A.engine.syncNow(); await A.engine.flushNow();
ok(JSON.parse(db.entries[KEYS.items]?.v || '[]').length === 3 && db.entries[KEYS.inv]?.v === '["B-offline-later"]', 'server rebuilt from device A');
const D = makeDevice('D'); await D.engine.init();
ok(JSON.parse(D.storage.getItem(KEYS.items) || '[]').length === 3, 'fresh device D restored from rebuilt server');

console.log('9) Server rejects junk / path tricks');
const bad: any = applyPut(db, { entries: { 'evil_key': { v: 'x', m: Date.now() }, '__proto__': { v: 'x', m: 1 }, 'krishiyantra_ok_v1': { v: 5, m: Date.now() } } });
ok(bad.accepted.length === 0, 'invalid keys / non-string values ignored');
const fut: any = applyPut(db, { entries: { 'krishiyantra_future_v1': { v: 'x', m: Date.now() + 1e12 } } });
ok(fut.next.entries['krishiyantra_future_v1'].m < Date.now() + 11 * 60 * 1000, 'far-future timestamps are clamped');
const wipe: any = applyPut(db, { entries: { [KEYS.items]: { v: null, d: true, m: Date.now() + 5 } } });
ok(wipe.risky === true, 'deleting existing data is flagged for an extra snapshot');

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
