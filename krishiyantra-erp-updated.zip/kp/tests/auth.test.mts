// Staff accounts: separate ID/password per person, owner-only management, instant revoke.
import assert from 'node:assert/strict';
process.env.APP_PASSWORD = 'owner-secret-1';
const auth = await import('../server-auth.ts');
const users = await import('../server-users.ts');

const login = (ip: string, id: unknown, pw: unknown) => auth.checkLogin(ip, id, pw);

// owner
let r = login('1.1.1.1', 'owner', 'owner-secret-1');
assert.ok(r.ok && r.user?.role === 'OWNER');
assert.ok(login('1.1.1.1', '', 'owner-secret-1').ok, 'old links without ID still work for owner');
assert.ok(!login('1.1.1.1', 'owner', 'wrong').ok);

// create staff
assert.ok(users.createUser({ id: 'Ram01', name: 'Ram', password: 'ram-pass-1', role: 'STAFF', allowedTabs: ['billing'] }).ok);
assert.ok(users.createUser({ id: 'sita01', name: 'Sita', password: 'sita-pass-1', role: 'ACCOUNTANT' }).ok);
assert.ok(!users.createUser({ id: 'ram01', name: 'Dup', password: 'abcdef' }).ok, 'duplicate id');
assert.ok(!users.createUser({ id: 'owner', name: 'X', password: 'abcdef' }).ok, 'reserved id');
assert.ok(!users.createUser({ id: 'bad id', name: 'X', password: 'abcdef' }).ok, 'bad id');
assert.ok(!users.createUser({ id: 'short1', name: 'X', password: '123' }).ok, 'short password');

// each person has their own password
const ram = login('2.2.2.2', 'RAM01', 'ram-pass-1');
assert.ok(ram.ok && ram.user?.id === 'ram01' && ram.user.allowedTabs[0] === 'billing');
assert.ok(!login('2.2.2.2', 'ram01', 'sita-pass-1').ok, "Ram cannot use Sita's password");
assert.ok(!login('2.2.2.2', 'ram01', 'owner-secret-1').ok, 'owner password does not open staff ID');
const sita = login('3.3.3.3', 'sita01', 'sita-pass-1');
assert.ok(sita.ok);

// token identity
assert.equal(auth.verifyToken(ram.token)?.id, 'ram01');
assert.equal(auth.verifyToken(ram.token)?.role, 'STAFF');
assert.equal(auth.verifyToken(r.token)?.role, 'OWNER');
assert.equal(auth.verifyToken(ram.token + 'x'), null);
// staff cannot be turned into owner by editing the token
const [p] = ram.token!.split('.');
const forged = Buffer.from(JSON.stringify({ ...JSON.parse(Buffer.from(p, 'base64url').toString()), r: 'OWNER' })).toString('base64url');
assert.equal(auth.verifyToken(forged + '.' + ram.token!.split('.')[1]), null);

// requireOwner
let code = 0;
const res: any = { status: (c: number) => ({ json: () => { code = c; } }) };
auth.requireOwner({ user: { role: 'STAFF' } }, res, () => { code = 200; });
assert.equal(code, 403);
auth.requireOwner({ user: { role: 'OWNER' } }, res, () => { code = 200; });
assert.equal(code, 200);

// password reset logs the staff out everywhere
assert.ok(users.updateUser('ram01', { password: 'new-pass-77' }).ok);
assert.equal(auth.verifyToken(ram.token), null, 'old token dead after reset');
assert.ok(!login('2.2.2.2', 'ram01', 'ram-pass-1').ok);
const ram2 = login('2.2.2.2', 'ram01', 'new-pass-77');
assert.ok(ram2.ok);
assert.equal(auth.verifyToken(sita.token)?.id, 'sita01', "Sita unaffected");

// disable / delete
assert.ok(users.updateUser('ram01', { active: false }).ok);
assert.equal(auth.verifyToken(ram2.token), null);
assert.ok(!login('2.2.2.2', 'ram01', 'new-pass-77').ok);
assert.ok(users.deleteUser('sita01'));
assert.equal(auth.verifyToken(sita.token), null);

// passwords are not stored in plain text
const raw = JSON.stringify(users.listUsers());
assert.ok(!raw.includes('hash') && !raw.includes('salt'));

// brute force: 5 wrong tries from one IP => locked even with right password
for (let i = 0; i < 5; i++) login('9.9.9.9', 'owner', 'nope');
const locked = login('9.9.9.9', 'owner', 'owner-secret-1');
assert.equal(locked.status, 429);
console.log('auth tests passed');
