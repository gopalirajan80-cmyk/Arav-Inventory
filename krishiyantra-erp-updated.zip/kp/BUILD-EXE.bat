@echo off
setlocal
title KrishiYantra - Installer banaudai
cd /d "%~dp0"
net session >nul 2>nul
if errorlevel 1 (
  echo Yo file Administrator bhayera chalaunu parchha.
  echo File ma right-click garnus -^> "Run as administrator" thichnus.
  pause & exit /b
)
where node >nul 2>nul
if errorlevel 1 ( echo Node.js chahinchha: https://nodejs.org bata LTS install garnus. & pause & exit /b )
set CSC_IDENTITY_AUTO_DISCOVERY=false
rmdir /s /q "%LOCALAPPDATA%\electron-builder\Cache\winCodeSign" >nul 2>nul
call npm install --include=dev
if errorlevel 1 ( echo npm install fail bhayo. & pause & exit /b )
call npm run exe > build-log.txt 2>&1
if errorlevel 1 ( type build-log.txt & echo. & echo Build fail bhayo. "build-log.txt" file ko lekhai (text) pathaunus. & pause & exit /b )
type build-log.txt
echo.
echo ===== Tayar! "release" folder bhitra "KrishiYantra ERP Setup x.x.x.exe" chha. =====
echo ===== Tyo file ma double-click garera install garnus (Play Store jastai). =====
start "" "%~dp0release"
pause
