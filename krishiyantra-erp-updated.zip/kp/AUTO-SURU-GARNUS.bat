@echo off
setlocal
title KrishiYantra - Auto start setup
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js install gareko chhaina. https://nodejs.org bata LTS install garera pheri kholnus.
  pause & exit /b
)
if not exist ".env" copy ".env.example" ".env" >nul
findstr /b /c:"APP_PASSWORD=" ".env" >nul 2>nul
if not errorlevel 1 goto PW_OK
echo.
echo Login password set gareko chhaina. Aafno password lekhnus (English akshar/number matra, space, %% ra ^& ^< ^> ^| nabhaaune):
set "PW="
set /p PW=Password: 
if "%PW%"=="" ( echo Password khali huna hudaina. & pause & exit /b )
>> ".env" echo.
>> ".env" echo APP_PASSWORD="%PW%"
echo Password .env ma save bhayo. Login ID: owner
:PW_OK
if not exist "node_modules\tsx" (
  echo Pahilo patak: file download hudai chha, kehi minet kurnus...
  call npm install --include=dev
  if errorlevel 1 ( echo npm install fail bhayo. & pause & exit /b )
)
if not exist "dist\index.html" (
  echo App banaudai chha...
  call npm run build
  if errorlevel 1 ( echo build fail bhayo. & pause & exit /b )
)
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
copy /y "%~dp0server-chalau-chupchap.vbs" "%STARTUP%\KrishiYantra-server.vbs" >nul
echo set dir=%~dp0>nul
> "%STARTUP%\KrishiYantra-server.vbs" echo Set sh = CreateObject("WScript.Shell")
>> "%STARTUP%\KrishiYantra-server.vbs" echo sh.CurrentDirectory = "%~dp0"
>> "%STARTUP%\KrishiYantra-server.vbs" echo sh.Run "cmd /c npm start ^> server-log.txt 2^>^&1", 0, False
echo Server ahile suru gardai chha...
wscript "%STARTUP%\KrishiYantra-server.vbs"
timeout /t 8 >nul
start "" http://localhost:3000
echo.
echo ===== Tayar! Aba kampyutar on bhayepachi server aafai chalchha (kalo window aaudaina). =====
echo Chrome ma Install thichera Desktop icon banaunus; pachi icon ma click garyo bhane sidhai khulchha.
pause
