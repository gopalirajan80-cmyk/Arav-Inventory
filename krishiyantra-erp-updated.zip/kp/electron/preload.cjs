const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('setup', { save: (pw) => ipcRenderer.send('set-password', pw) });
// Used by the app's print code (src/utils/desktopPrint.ts): shows a real print preview.
contextBridge.exposeInMainWorld('kyDesktop', { printPreview: (o) => ipcRenderer.invoke('print-preview', o) });
