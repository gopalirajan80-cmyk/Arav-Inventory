// KrishiYantra ERP - Windows desktop app wrapper (Electron).
// Starts the bundled server in the background and shows the app in its own window.
const { app, BrowserWindow, ipcMain, dialog, Menu, shell } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const http = require('http');
const { pathToFileURL } = require('url');
const os = require('os');

let PORT = 3123;
const net = require('net');
// Free port khojne: purano server atkeko bhaye pani naya app khulos
function findFreePort(start) {
  return new Promise((resolve) => {
    const t = (p) => { const srv = net.createServer(); srv.once('error', () => t(p + 1)); srv.once('listening', () => srv.close(() => resolve(p))); srv.listen(p, '127.0.0.1'); };
    t(start);
  });
}
const ROOT = path.resolve(__dirname, '..');
const userDir = app.getPath('userData');
const dataDir = path.join(userDir, 'data');
const cfgFile = path.join(userDir, 'config.json');
let server = null;
let serverExit = null;
let serverReady = false;
let win = null;
let mainShown = false;
let fatal = false;
function mlog(m) { try { fs.appendFileSync(path.join(userDir, 'main-log.txt'), new Date().toISOString() + ' ' + m + '\n'); } catch {} }

process.on('uncaughtException', (e) => { try { require('electron').dialog.showErrorBox('KrishiYantra error', String(e && e.stack || e)); } catch {} });
if (!app.requestSingleInstanceLock()) { app.quit(); }
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });


// ---- Print preview: page -> PDF -> preview window (PDF viewer has its own Print button) ----
const printDir = path.join(os.tmpdir(), 'krishiyantra-print');
function cleanOldPrints() {
  try {
    fs.mkdirSync(printDir, { recursive: true });
    for (const f of fs.readdirSync(printDir)) {
      const fp = path.join(printDir, f);
      if (Date.now() - fs.statSync(fp).mtimeMs > 24 * 3600 * 1000) fs.unlinkSync(fp);
    }
  } catch {}
}
ipcMain.handle('print-preview', async (e, o = {}) => {
  try {
    const pdf = await e.sender.printToPDF({
      printBackground: true,
      preferCSSPageSize: !!o.preferCss,
      pageSize: o.pageSize || 'A4',
      landscape: !!o.landscape,
    });
    fs.mkdirSync(printDir, { recursive: true });
    const file = path.join(printDir, 'print-' + Date.now() + '.pdf');
    fs.writeFileSync(file, pdf);
    const pw = new BrowserWindow({ width: 1000, height: 860, autoHideMenuBar: true, title: 'Print Preview - KrishiYantra',
      parent: win || undefined, webPreferences: { plugins: true } });
    pw.loadURL(pathToFileURL(file).toString());
    return true;
  } catch (err) {
    console.error('print-preview failed', err);
    return false;
  }
});

function readCfg() { try { return JSON.parse(fs.readFileSync(cfgFile, 'utf8')); } catch { return null; } }

function askPassword() {
  return new Promise((resolve) => {
    const w = new BrowserWindow({ width: 460, height: 360, resizable: false, autoHideMenuBar: true,
      title: 'KrishiYantra - Password rakhnus',
      webPreferences: { preload: path.join(__dirname, 'preload.cjs') } });
    w.loadFile(path.join(__dirname, 'setup.html'));
    ipcMain.once('set-password', (_e, pw) => { resolve(pw); w.destroy(); });
    w.on('closed', () => resolve(null));
  });
}

function startServer(cfg) {
  fs.mkdirSync(dataDir, { recursive: true });
  const bundle = path.join(ROOT, 'server.bundle.mjs');
  const tsxCli = path.join(ROOT, 'node_modules', 'tsx', 'dist', 'cli.mjs');
  // Bundled server (fast). tsx only as a fallback if the bundle is missing.
  const args = fs.existsSync(bundle) ? [bundle, '--production'] : [tsxCli, 'server.ts', '--production'];
  server = spawn(process.execPath, args, {
    cwd: ROOT,
    env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', NODE_ENV: 'production', PORT: String(PORT), HOST: '127.0.0.1',
      DATA_DIR: dataDir, APP_PASSWORD: cfg.password, SESSION_SECRET: cfg.secret },
    windowsHide: true,
  });
  const log = fs.createWriteStream(path.join(userDir, 'server-log.txt'), { flags: 'a' });
  log.write('\n--- ' + new Date().toISOString() + ' start (' + path.basename(args[0]) + ') ---\n');
  server.stdout.on('data', (d) => { if (String(d).includes('Server running')) serverReady = true; });
  server.stdout.pipe(log); server.stderr.pipe(log);
  server.on('exit', (code) => { serverExit = code === null ? -1 : code; });
  server.on('error', (e) => { serverExit = -2; try { log.write('spawn error: ' + e.message + '\n'); } catch {} });
}

function stopServer() {
  if (!server) return;
  try {
    if (process.platform === 'win32' && server.pid) spawn('taskkill', ['/pid', String(server.pid), '/T', '/F'], { windowsHide: true });
    else server.kill();
  } catch {}
}

function waitForServer(tries = 240) {
  return new Promise((resolve, reject) => {
    const tick = (n) => {
      if (serverReady) return resolve();
      if (serverExit !== null) return reject(new Error('Server band bhayo (code ' + serverExit + ')'));
      http.get({ host: '127.0.0.1', port: PORT, path: '/api/health', timeout: 1000 }, (r) => { r.resume(); resolve(); })
        .on('error', () => (n <= 0 ? reject(new Error('Server suru bhayena')) : setTimeout(() => tick(n - 1), 500)));
    };
    tick(tries);
  });
}

async function boot() {
  mlog('boot start');
  Menu.setApplicationMenu(null);
  let cfg = readCfg();
  if (!cfg) {
    const pw = await askPassword();
    if (!pw) return app.quit();
    cfg = { password: pw, secret: crypto.randomBytes(24).toString('hex') };
    fs.mkdirSync(userDir, { recursive: true });
    fs.writeFileSync(cfgFile, JSON.stringify(cfg));
  }
  if (!fs.existsSync(path.join(ROOT, 'dist', 'index.html'))) {
    fatal = true;
    dialog.showErrorBox('KrishiYantra', 'App ko "dist" folder chhaina (build adhuro bhayo). BUILD-EXE.bat pheri chalaunus.');
    return app.quit();
  }
  const splash = new BrowserWindow({ width: 420, height: 160, frame: false, resizable: false, alwaysOnTop: true,
    title: 'KrishiYantra' });
  splash.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(
    '<body style="font-family:Segoe UI,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;margin:0;background:#f4f7f4;color:#14532d">' +
    '<h2 style="margin:0 0 8px">KrishiYantra ERP</h2><div>Server suru hudai chha, kripaya kurnus...</div>' +
    '<div style="font-size:12px;color:#666;margin-top:8px">Pahilo palta 1-2 minute lagna sakchha</div></body>'));
  PORT = await findFreePort(3123);
  mlog('port ' + PORT);
  startServer(cfg);
  try { await waitForServer(); splash.destroy(); } catch (e) {
    try { splash.destroy(); } catch {}
    stopServer();
    fatal = true;
    dialog.showErrorBox('KrishiYantra', 'Server suru hudaina. Log: ' + path.join(userDir, 'server-log.txt'));
    return app.quit();
  }
  cleanOldPrints();
  win = new BrowserWindow({ width: 1366, height: 820, autoHideMenuBar: true, title: 'KrishiYantra ERP',
    webPreferences: { preload: path.join(__dirname, 'preload.cjs') },
    icon: path.join(ROOT, 'public', 'pwa-512x512.png') });
  mainShown = true;
  win.maximize();
  win.show();
  win.focus();

  // PDF / Excel download: Downloads folder ma save garera folder kholne
  win.webContents.session.on('will-download', (_e, item) => {
    const dl = app.getPath('downloads');
    const ext = path.extname(item.getFilename());
    const base = path.basename(item.getFilename(), ext);
    let target = path.join(dl, item.getFilename());
    for (let i = 1; fs.existsSync(target); i++) target = path.join(dl, `${base} (${i})${ext}`);
    item.setSavePath(target);
    item.once('done', (_ev, state) => {
      if (state === 'completed') shell.showItemInFolder(target);
      else dialog.showErrorBox('KrishiYantra', 'File save bhayena: ' + state);
    });
  });

  // Print / naya window kholne (window.open) lai app bhitrai kholne
  win.webContents.setWindowOpenHandler(() => ({
    action: 'allow',
    overrideBrowserWindowOptions: { autoHideMenuBar: true, width: 1000, height: 800 },
  }));

  win.loadURL('http://127.0.0.1:' + PORT);
  mlog('window loaded');
}
app.whenReady().then(boot).catch((e) => {
  mlog('boot error ' + (e && e.stack || e));
  fatal = true;
  dialog.showErrorBox('KrishiYantra', 'App suru garda error: ' + (e && e.message || e) + '\nLog: ' + path.join(userDir, 'main-log.txt'));
  app.quit();
});

// Startup ko bela (password window band bhayera splash khulnu agadi) app quit nagarne
app.on('window-all-closed', () => { if (mainShown || fatal) app.quit(); });
app.on('before-quit', stopServer);
