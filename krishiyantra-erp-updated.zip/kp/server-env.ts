// Must be the FIRST import of server.ts.
// ES-module imports run before any other code, so .env has to be loaded here -
// otherwise server-auth.ts / server-storage.ts read APP_PASSWORD and DATA_DIR while they are still empty.
import dotenv from 'dotenv';

dotenv.config();

// Works on Windows, Mac and Linux (plain "NODE_ENV=production tsx ..." fails on Windows cmd).
if (process.argv.includes('--production')) process.env.NODE_ENV = 'production';
