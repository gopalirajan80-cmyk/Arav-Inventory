' KrishiYantra server lai kalo window bina background ma chalaucha
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
sh.Run "cmd /c npm start > server-log.txt 2>&1", 0, False
