// Crash-safe JSON file storage with automatic backups.
//  - DATA_DIR: point this at a PERSISTENT disk/volume so data survives restarts & redeploys
//  - atomic writes (temp file + fsync + rename): a crash can never leave a half-written file
//  - rolling backups: hourly (48), daily (30) and "risky change" snapshots (30)
//  - if the main file is ever unreadable, the newest readable backup is used automatically
import fs from 'fs';
import path from 'path';

export const DATA_DIR = path.resolve(process.env.DATA_DIR || process.cwd());
export const BACKUP_DIR = path.join(DATA_DIR, 'backups');
fs.mkdirSync(BACKUP_DIR, { recursive: true });

function tryParse(file: string): any | null {
  try {
    if (!fs.existsSync(file)) return null;
    const parsed = JSON.parse(fs.readFileSync(file, 'utf-8'));
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch (err) {
    console.error('Could not read', file, err);
    return null;
  }
}

function prune(prefix: string, keep: number) {
  try {
    const files = fs.readdirSync(BACKUP_DIR).filter((f) => f.startsWith(prefix)).sort();
    for (const f of files.slice(0, Math.max(0, files.length - keep))) {
      try { fs.unlinkSync(path.join(BACKUP_DIR, f)); } catch {}
    }
  } catch {}
}

export function createStore<T extends object>(fileName: string, backupPrefix: string, empty: () => T) {
  const file = path.join(DATA_DIR, fileName);
  let cache: T | null = null;

  function load(): T {
    if (cache) return cache;
    let data = tryParse(file);
    if (!data && fs.existsSync(file)) {
      // main file exists but is unreadable -> newest readable backup
      const names = fs.readdirSync(BACKUP_DIR)
        .filter((f) => f.startsWith(backupPrefix + '-'))
        .map((f) => ({ f, t: fs.statSync(path.join(BACKUP_DIR, f)).mtimeMs }))
        .sort((a, b) => b.t - a.t) // newest first
        .map((x) => x.f);
      for (const n of names) {
        const b = tryParse(path.join(BACKUP_DIR, n));
        if (b) { console.warn('Main data file damaged - restored from backup', n); data = b; break; }
      }
    }
    cache = (data as T) || empty();
    return cache;
  }

  function snapshot(name: string, prefixForPrune: string, keep: number, previous: T) {
    const target = path.join(BACKUP_DIR, name);
    if (fs.existsSync(target)) return;
    try {
      fs.writeFileSync(target, JSON.stringify(previous), 'utf-8');
      prune(prefixForPrune, keep);
    } catch (e) {
      console.error('Backup failed', name, e);
    }
  }

  /** Saves `next`. Throws if the disk write fails (cache is only updated on success). */
  function save(next: T, opts: { risky?: boolean } = {}) {
    const previous = load();
    const hadFile = fs.existsSync(file);
    const iso = new Date().toISOString();

    if (hadFile) {
      snapshot(`${backupPrefix}-hourly-${iso.slice(0, 13)}.json`, `${backupPrefix}-hourly-`, 48, previous);
      snapshot(`${backupPrefix}-daily-${iso.slice(0, 10)}.json`, `${backupPrefix}-daily-`, 30, previous);
      if (opts.risky) {
        snapshot(`${backupPrefix}-risky-${iso.replace(/[:.]/g, '-')}.json`, `${backupPrefix}-risky-`, 30, previous);
      }
    }

    const tmp = `${file}.tmp-${process.pid}`;
    const fd = fs.openSync(tmp, 'w');
    try {
      fs.writeFileSync(fd, JSON.stringify(next), 'utf-8');
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    fs.renameSync(tmp, file);
    cache = next;
  }

  return { load, save, file, exists: () => fs.existsSync(file) };
}
