import './server-env.ts';
import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { AUTH_ENABLED, checkLogin, requireAuth, requireOwner, rateLimit } from './server-auth.ts';
import { listUsers, createUser, updateUser, deleteUser, getUser } from './server-users.ts';
import { DATA_DIR, createStore } from './server-storage.ts';
import { applyPut, emptySyncDb, readSince, type SyncDb } from './server-sync.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.set('trust proxy', 1); // correct client IP behind Render/Railway/Cloud Run

// Basic security headers
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');
  next();
});

// Tiny body limit for the (public) login endpoint, large limit for the rest (photos, data sync)
app.use('/api/login', express.json({ limit: '4kb' }));
app.use(express.json({ limit: '50mb' }));

// Public health check for the hosting platform (reveals nothing)
app.get('/api/health', (_req, res) => res.json({ ok: true }));

// ---- Authentication ----
if (!AUTH_ENABLED) {
  if (process.env.NODE_ENV === 'production') {
    console.error('FATAL: APP_PASSWORD is not set. Refusing to start without a password in production.');
    process.exit(1);
  }
  console.warn('WARNING: APP_PASSWORD not set - login is DISABLED (local development only).');
}

app.post('/api/login', (req, res) => {
  if (!AUTH_ENABLED) return res.json({ success: true, token: '', authDisabled: true, user: { id: 'owner', name: 'Owner', role: 'OWNER', allowedTabs: [] } });
  const r = checkLogin(req.ip || 'unknown', req.body?.id, req.body?.password);
  if (!r.ok) return res.status(r.status).json({ error: r.error });
  return res.json({ success: true, token: r.token, user: r.user });
});

// Lets the app check whether its saved token is still valid, and who is logged in (fresh name/permissions)
app.get('/api/auth-check', requireAuth, (req: any, res) => {
  if (req.user.role === 'OWNER') return res.json({ success: true, user: { id: 'owner', name: 'Owner', role: 'OWNER', allowedTabs: [] } });
  const u = getUser(req.user.id)!;
  return res.json({ success: true, user: { id: u.id, name: u.name, role: u.role, allowedTabs: u.allowedTabs } });
});

// ---- Staff accounts (owner only) ----
app.get('/api/users', requireAuth, requireOwner, (_req, res) => res.json({ success: true, users: listUsers() }));
app.post('/api/users', requireAuth, requireOwner, (req, res) => {
  const r = createUser(req.body);
  return r.ok ? res.json({ success: true, user: r.user }) : res.status(400).json({ error: r.error });
});
app.put('/api/users/:id', requireAuth, requireOwner, (req, res) => {
  const r = updateUser(req.params.id, req.body);
  return r.ok ? res.json({ success: true, user: r.user }) : res.status(400).json({ error: r.error });
});
app.delete('/api/users/:id', requireAuth, requireOwner, (req, res) =>
  deleteUser(req.params.id) ? res.json({ success: true }) : res.status(404).json({ error: 'कर्मचारी फेला परेन।' }));

// ---- Shared data store (all devices) ----
const syncStore = createStore<SyncDb>('erp-sync-db.json', 'sync', emptySyncDb);
syncStore.load(); // read once at start-up (restores from backup automatically if the file is damaged)

// Pull: everything that changed after version `since` (since=0 -> everything)
app.get('/api/sync', requireAuth, (req, res) => {
  const since = Math.max(0, Number(req.query.since) || 0);
  return res.json({ success: true, ...readSince(syncStore.load(), since) });
});

// Push: save changed keys; the reply also carries anything newer that other devices saved
app.put('/api/sync', requireAuth, (req, res) => {
  const db = syncStore.load();
  const result = applyPut(db, req.body);
  if ('error' in result) return res.status(400).json({ error: result.error });
  if (result.changed) {
    try {
      syncStore.save(result.next, { risky: result.risky });
    } catch (err) {
      console.error('Error writing data file:', err);
      return res.status(500).json({ error: 'डाटा सेभ गर्न सकिएन।' });
    }
  }
  const since = Math.max(0, Number(req.body?.since) || 0);
  const out = readSince(result.next, since, new Set(result.accepted));
  for (const k of result.rejected) out.entries[k] = result.next.entries[k]; // always tell the device what the server kept
  return res.json({ success: true, accepted: result.accepted.length, ...out });
});

// Download a full copy of all data (needs login)
app.get('/api/backup', requireAuth, requireOwner, (_req, res) => {
  if (!syncStore.exists()) return res.status(404).json({ error: 'अहिलेसम्म कुनै डाटा सेभ भएको छैन।' });
  const day = new Date().toISOString().slice(0, 10);
  res.setHeader('Content-Disposition', `attachment; filename="krishiyantra-backup-${day}.json"`);
  res.setHeader('Content-Type', 'application/json');
  return res.send(JSON.stringify(syncStore.load()));
});

// Initialize Google Gemini SDK
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

// AI OCR Endpoint: लिखित/छापिएको बिलको फोटो स्क्यान गरी सिधै विलिङ डाटामा रूपान्तरण
app.post('/api/scan-handwritten-bill', requireAuth, rateLimit(30, 60_000), async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg' } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Missing imageBase64 data' });
    }

    const activeApiKey = process.env.GEMINI_API_KEY || apiKey;
    if (!activeApiKey) {
      return res.status(503).json({
        error: 'Gemini API Key is not configured on the server. Please check GEMINI_API_KEY environment variable.'
      });
    }

    const client =
      aiClient ||
      new GoogleGenAI({
        apiKey: activeApiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });

    // Strip data URL header if present
    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');

    const promptText = `तपाईं नेपालको कृषि यन्त्र, औजार तथा हार्डवेयर पसलको लेखा विशेषज्ञ (OCR Accounting Assistant) हुनुहुन्छ।
संलग्न गरिएको फोटो हातले लेखिएको बिल (Handwritten paper bill/chit/रसिद) वा छापिएको खरिद/बिक्री बिल हो। 
यस बिलमा लेखिएका सबै विवरणहरू सावधानीपूर्वक पढेर निम्न JSON संरचनामा मात्र आउटपुट दिनुहोस्:

{
  "invoiceNo": "बिल वा बीजक नम्बर (फेला परेमा, अन्यथा खाली)",
  "customerName": "ग्राहक वा आपूर्तिकर्ता पसलको नाम (फेला परेमा, अन्यथा खाली)",
  "customerPan": "प्यान वा भ्याट नम्बर (फेला परेमा)",
  "customerAddress": "ठेगाना (जस्तै: भरतपुर-०६, माडी, आदि)",
  "customerPhone": "सम्पर्क फोन नम्बर",
  "billType": "VAT" वा "NON_VAT" (भ्याट लेखिएको भए "VAT", सामान्य/कच्चा भए "NON_VAT"),
  "paymentDueDate": "रकम बुझाउने अन्तिम म्याद वा भाका (फेला परेमा)",
  "previousDue": 0,
  "amountPaid": 0,
  "discountPercent": 0,
  "freightCharge": 0,
  "notes": "कुनै कैफियत वा टिप्पणी",
  "items": [
    {
      "name": "सामानको नाम",
      "quantity": 1,
      "unit": "Pcs",
      "rate": 0,
      "amount": 0
    }
  ]
}

महत्वपूर्ण नियमहरू:
1. केवल शुद्ध JSON फर्काउनुहोस्।
2. अंकहरूलाई अङ्ग्रेजी अंक (numeric standard) मा रूपान्तरण गर्नुहोस्।
3. नेपाली वा अङ्ग्रेजी भाषामा लेखिएका सामानको नाम स्पष्ट राख्नुहोस्।`;

    const response = await client.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              inlineData: {
                mimeType,
                data: cleanBase64
              }
            },
            {
              text: promptText
            }
          ]
        }
      ],
      config: {
        responseMimeType: 'application/json'
      }
    });

    const responseText = response.text || '';
    
    // Clean response text to extract valid JSON
    let jsonString = responseText.trim();
    if (jsonString.startsWith('```json')) {
      jsonString = jsonString.slice(7);
    } else if (jsonString.startsWith('```')) {
      jsonString = jsonString.slice(3);
    }
    if (jsonString.endsWith('```')) {
      jsonString = jsonString.slice(0, -3);
    }
    jsonString = jsonString.trim();

    try {
      const parsedData = JSON.parse(jsonString);
      return res.json({ success: true, data: parsedData });
    } catch (parseError) {
      console.error('Failed to parse Gemini OCR JSON:', responseText);
      return res.status(500).json({
        error: 'Failed to parse AI output into invoice JSON',
        rawText: responseText
      });
    }

  } catch (error: any) {
    console.error('OCR Extraction error:', error);
    return res.status(500).json({
      error: error.message || 'Error processing bill photo'
    });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files from dist
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));
    app.use((_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  // HOST is set only by the desktop app (127.0.0.1) so it is reachable on IPv4 and not exposed to the network.
  const onListen = () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Data stored in: ${DATA_DIR}`);
    if (!isDev && !process.env.DATA_DIR) {
      console.warn('WARNING: DATA_DIR is not set. Data lives in the app folder and may be LOST on restart/redeploy. Mount a persistent disk and set DATA_DIR.');
    }
  };
  if (process.env.HOST) app.listen(Number(PORT), process.env.HOST, onListen);
  else app.listen(PORT, onListen);
}

startServer();
