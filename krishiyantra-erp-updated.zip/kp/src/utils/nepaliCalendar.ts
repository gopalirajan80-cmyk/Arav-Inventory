// Nepali Bikram Sambat (B.S.) Calendar & Dual Date Utility
// Synchronized accurately with Computer & Mobile device clocks
// Powered by standard Bikram Sambat conversion (2000 B.S. - 2099 B.S.)
import NepaliDate from 'nepali-date-converter';

export interface BsDate {
  year: number;
  month: number; // 1 - 12
  day: number; // 1 - 32
}

export const NEPALI_MONTHS_NE = [
  'बैशाख', 'जेठ', 'असार', 'साउन', 'भदौ', 'असोज',
  'कात्तिक', 'मंसिर', 'पुस', 'माघ', 'फागुन', 'चैत'
];

export const NEPALI_MONTHS_EN = [
  'Baisakh', 'Jestha', 'Ashadh', 'Shrawan', 'Bhadra', 'Ashwin',
  'Kartik', 'Mangsir', 'Poush', 'Magh', 'Falgun', 'Chaitra'
];

export const NEPALI_DIGITS: { [key: string]: string } = {
  '0': '०', '1': '१', '2': '२', '3': '३', '4': '४',
  '5': '५', '6': '६', '7': '७', '8': '८', '9': '९'
};

const MANUAL_OVERRIDE_KEY = 'app_manual_override_date_bs';
const DATE_SYNC_MODE_KEY = 'app_date_sync_mode';

/**
 * Gets the current date sync mode: 'AUTO' (device clock) or 'MANUAL' (user override)
 */
export function getDateSyncMode(): 'AUTO' | 'MANUAL' {
  if (typeof window === 'undefined') return 'AUTO';
  const mode = localStorage.getItem(DATE_SYNC_MODE_KEY);
  if (mode === 'MANUAL') return 'MANUAL';
  return 'AUTO';
}

/**
 * Sets a manual override date (YYYY-MM-DD) or clears it (null) to revert to device auto-sync
 */
export function setManualOverrideDate(bsDateStr: string | null): void {
  if (typeof window === 'undefined') return;
  if (!bsDateStr) {
    localStorage.removeItem(MANUAL_OVERRIDE_KEY);
    localStorage.setItem(DATE_SYNC_MODE_KEY, 'AUTO');
  } else {
    const sanitized = bsDateStr.trim().replace(/\//g, '-');
    localStorage.setItem(MANUAL_OVERRIDE_KEY, sanitized);
    localStorage.setItem(DATE_SYNC_MODE_KEY, 'MANUAL');
  }
  window.dispatchEvent(new CustomEvent('ims-date-sync-changed', { detail: { date: bsDateStr } }));
}

/**
 * Converts a Gregorian JavaScript Date to Bikram Sambat Date (B.S.)
 * Accurately takes device date from computer or mobile phone.
 */
export function adToBs(date: Date = new Date()): BsDate {
  try {
    const nd = new NepaliDate(date);
    return {
      year: nd.getYear(),
      month: nd.getMonth() + 1, // 1 to 12
      day: nd.getDate() // 1 to 32
    };
  } catch {
    const fallbackYear = date.getFullYear() + 57;
    return { year: fallbackYear, month: 1, day: 1 };
  }
}

/**
 * Converts a Bikram Sambat Date to Gregorian JavaScript Date (A.D.)
 */
export function bsToAd(bs: string | BsDate): Date {
  try {
    if (typeof bs === 'string') {
      const sanitized = bs.replace(/\//g, '-').trim();
      const nd = new NepaliDate(sanitized);
      return nd.toJsDate();
    } else {
      const m = String(bs.month).padStart(2, '0');
      const d = String(bs.day).padStart(2, '0');
      const nd = new NepaliDate(`${bs.year}-${m}-${d}`);
      return nd.toJsDate();
    }
  } catch {
    return new Date();
  }
}

/**
 * Formats BS Date to string "YYYY-MM-DD"
 */
export function formatBsDate(bs: BsDate): string {
  const m = bs.month < 10 ? `0${bs.month}` : `${bs.month}`;
  const d = bs.day < 10 ? `0${bs.day}` : `${bs.day}`;
  return `${bs.year}-${m}-${d}`;
}

/**
 * Returns formatted BS string for today's date dynamically (YYYY-MM-DD)
 * Defaults to live computer and mobile device clock, but respects manual override if enabled by user.
 */
export function getTodayBsString(): string {
  if (typeof window !== 'undefined') {
    const mode = localStorage.getItem(DATE_SYNC_MODE_KEY);
    const manualDate = localStorage.getItem(MANUAL_OVERRIDE_KEY);
    if (mode === 'MANUAL' && manualDate && /^\d{4}-\d{2}-\d{2}$/.test(manualDate)) {
      return manualDate;
    }
    // Clean up stale legacy keys
    if (localStorage.getItem('app_custom_today_bs') === '2083-07-12') {
      localStorage.removeItem('app_custom_today_bs');
    }
  }

  try {
    const deviceNow = new Date();
    const nd = new NepaliDate(deviceNow);
    return nd.format('YYYY-MM-DD');
  } catch {
    return '2081-01-01';
  }
}

/**
 * Returns the exact live BS date string from computer/mobile device clock, ignoring any manual override
 */
export function getDeviceLiveBsString(): string {
  try {
    const deviceNow = new Date();
    const nd = new NepaliDate(deviceNow);
    return nd.format('YYYY-MM-DD');
  } catch {
    return '2081-01-01';
  }
}

/**
 * Returns formatted AD string for today's device date (YYYY-MM-DD)
 */
export function getTodayAdString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}


/**
 * BS (YYYY-MM-DD) -> AD (YYYY-MM-DD). Returns '' when the BS date is invalid / out of range.
 * Uses local-date parts (not toISOString) so Nepal's +05:45 offset can never shift the day.
 */
export function bsStringToAdString(bs: string): string {
  const clean = (bs || '').trim().replace(/\//g, '-');
  if (!/^\d{4}-\d{1,2}-\d{1,2}$/.test(clean)) return '';
  try {
    const [y, m, d] = clean.split('-').map((n) => parseInt(n, 10));
    const nd = new NepaliDate(`${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`);
    const js = nd.toJsDate();
    if (Number.isNaN(js.getTime())) return '';
    // Round-trip check: rejects things like 2083-02-35 that the library may silently roll over
    const back = adToBs(js);
    if (back.year !== y || back.month !== m || back.day !== d) return '';
    return `${js.getFullYear()}-${String(js.getMonth() + 1).padStart(2, '0')}-${String(js.getDate()).padStart(2, '0')}`;
  } catch {
    return '';
  }
}

/** AD (YYYY-MM-DD) -> BS (YYYY-MM-DD). Returns '' when the AD date is invalid / out of range. */
export function adStringToBsString(ad: string): string {
  const clean = (ad || '').trim().replace(/\//g, '-');
  if (!/^\d{4}-\d{1,2}-\d{1,2}$/.test(clean)) return '';
  try {
    const [y, m, d] = clean.split('-').map((n) => parseInt(n, 10));
    const js = new Date(y, m - 1, d, 12, 0, 0); // noon local: safe from DST / timezone day-shifts
    if (Number.isNaN(js.getTime())) return '';
    return formatBsDate(adToBs(js));
  } catch {
    return '';
  }
}

/**
 * Single source of truth for BS + AD dates of a transaction.
 * - BS given  -> AD is derived from it (so the two can never disagree)
 * - only AD   -> BS is derived from it
 * - nothing   -> today's device/override BS date + matching AD
 */
export function resolveDatePair(input?: { bs?: string; ad?: string }): { dateBs: string; dateAd: string } {
  const bsIn = (input?.bs || '').trim().replace(/\//g, '-');
  const adIn = (input?.ad || '').trim().replace(/\//g, '-');
  if (bsIn) {
    const ad = bsStringToAdString(bsIn);
    if (ad) return { dateBs: formatBsDate(parseBsString(bsIn)), dateAd: ad };
  }
  if (adIn) {
    const bs = adStringToBsString(adIn);
    if (bs) return { dateBs: bs, dateAd: adIn };
  }
  const todayBs = getTodayBsString();
  return { dateBs: todayBs, dateAd: bsStringToAdString(todayBs) || getTodayAdString() };
}

function parseBsString(bs: string): BsDate {
  const [y, m, d] = bs.split('-').map((n) => parseInt(n, 10));
  return { year: y, month: m, day: d };
}

/**
 * Returns rich device date/time details for display in UI
 */
export function getDeviceClockDetails() {
  const now = new Date();
  const liveBsStr = getDeviceLiveBsString();
  const activeBsStr = getTodayBsString();
  const syncMode = getDateSyncMode();
  
  let bsDateNeText = '';
  try {
    const nd = new NepaliDate(activeBsStr);
    bsDateNeText = nd.format('YYYY MMMM DD', 'np');
  } catch {
    bsDateNeText = formatBsDateNepaliText(activeBsStr);
  }

  const daysNe = ['आइतबार', 'सोमबार', 'मंगलबार', 'बुधबार', 'बिहीबार', 'शुक्रबार', 'शनिबार'];
  const dayNe = daysNe[now.getDay()] || '';

  return {
    syncMode,
    activeBsStr,
    liveBsStr,
    bsDateNeText,
    adDateStr: getTodayAdString(),
    adDateFormatted: now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    dayNe,
    timeFormatted: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
  };
}

/**
 * Formats BS Date in Nepali text, e.g. "२०८३ कार्तिक १३"
 */
export function formatBsDateNepaliText(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split(/[-/]/);
  if (parts.length !== 3) return dateStr;
  const y = parts[0];
  const m = parseInt(parts[1], 10);
  const d = parseInt(parts[2], 10);
  const monthName = NEPALI_MONTHS_NE[m - 1] || '';
  return `${toNepaliDigits(y)} ${monthName} ${toNepaliDigits(d)}`;
}

/**
 * Converts English digits (123) to Nepali Devanagari (१२३)
 */
export function toNepaliDigits(input: string | number): string {
  const str = String(input);
  return str.replace(/[0-9]/g, (digit) => NEPALI_DIGITS[digit] || digit);
}

/**
 * Formats currency in Nepali Rupees, e.g., "रू. १,२५,०००.००" or "Rs. 1,25,000.00"
 */
export function formatCurrency(amount: number, inNepaliDigits: boolean = false): string {
  const fixed = (amount || 0).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  if (inNepaliDigits) {
    return `रू. ${toNepaliDigits(fixed)}`;
  }
  return `Rs. ${fixed}`;
}

/**
 * Computes Nepali Fiscal Year from BS Date string
 * In Nepal, Fiscal Year starts 1st Shrawan (Month 4).
 * Example: Date in 2081 Shrawan -> Fiscal Year 081/82
 * Date in 2081 Baisakh (Month 1) -> Fiscal Year 080/81
 */
export function getFiscalYear(bsDateStr: string): string {
  const parts = bsDateStr.split(/[-/]/);
  if (parts.length !== 3) return '081/82';
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);

  if (month >= 4) {
    const startY = String(year).slice(-2);
    const endY = String(year + 1).slice(-2);
    return `0${startY}/${endY}`;
  } else {
    const startY = String(year - 1).slice(-2);
    const endY = String(year).slice(-2);
    return `0${startY}/${endY}`;
  }
}

/**
 * Helper to parse BS Date into Year and Month for reports and filters
 */
export function parseBsYearMonth(dateBs: string): { year: string; monthCode: string; monthNumber: number } {
  if (!dateBs) return { year: '2081', monthCode: '01', monthNumber: 1 };
  const parts = dateBs.split(/[-/]/);
  const year = parts[0] || '2081';
  const monthNumber = parseInt(parts[1] || '1', 10);
  const monthCode = String(monthNumber).padStart(2, '0');
  return { year, monthCode, monthNumber };
}
