// Nepal VAT Calculation Engine (13% Standard VAT & Tax Exempt Items)
import { InvoiceItem } from '../types';

export interface VatCalculationResult {
  subtotal: number;
  discountAmount: number;
  taxableAmount: number;
  exemptAmount: number;
  vatAmount: number; // 13% of taxableAmount
  freightCharge: number;
  grandTotal: number;
}

export function calculateInvoiceTotals(
  items: InvoiceItem[],
  discountPercent: number = 0,
  freightCharge: number = 0,
  isVatBill: boolean = true,
  manualExemptAmount?: number | null
): VatCalculationResult {
  let subtotal = 0;
  let rawTaxable = 0;
  let rawExempt = 0;

  items.forEach((item) => {
    const itemAmount = item.amount !== undefined ? item.amount : item.quantity * item.rate;
    subtotal += itemAmount;
    if (item.isVatExempt) {
      rawExempt += itemAmount;
    } else {
      rawTaxable += itemAmount;
    }
  });

  // If user entered manual VAT exempt amount, override rawExempt and rawTaxable
  if (manualExemptAmount !== undefined && manualExemptAmount !== null && manualExemptAmount >= 0) {
    rawExempt = Math.min(subtotal, Math.max(0, manualExemptAmount));
    rawTaxable = Math.max(0, subtotal - rawExempt);
  }

  // Calculate proportional discount across taxable and exempt items
  const discountRate = Math.min(100, Math.max(0, discountPercent)) / 100;
  const discountAmount = subtotal * discountRate;

  let taxableBase = rawTaxable * (1 - discountRate);
  const exemptBase = rawExempt * (1 - discountRate);

  // Freight is considered taxable in standard billing unless specified otherwise
  if (isVatBill && taxableBase > 0) {
    taxableBase += freightCharge;
  }

  const vatAmount = isVatBill ? taxableBase * 0.13 : 0;
  const grandTotal = isVatBill
    ? taxableBase + exemptBase + vatAmount
    : subtotal - discountAmount + freightCharge;

  return {
    subtotal: Math.round(subtotal * 100) / 100,
    discountAmount: Math.round(discountAmount * 100) / 100,
    taxableAmount: Math.round(taxableBase * 100) / 100,
    exemptAmount: Math.round(exemptBase * 100) / 100,
    vatAmount: Math.round(vatAmount * 100) / 100,
    freightCharge: Math.round(freightCharge * 100) / 100,
    grandTotal: Math.round(grandTotal * 100) / 100
  };
}

const ONES_NE = ['', 'एक', 'दुई', 'तीन', 'चार', 'पाँच', 'छ', 'सात', 'आठ', 'नौ', 'दश', 
  'एघार', 'बाह्र', 'तेह्र', 'चौध', 'पन्ध्र', 'सोह्र', 'सत्र', 'अठार', 'उन्नाइस'];

const TENS_NE = ['', '', 'बीस', 'तीस', 'चालीस', 'पचास', 'साठ्ठी', 'सत्तरी', 'असी', 'नब्बे'];

/**
 * Converts numeric amount to Nepali Words (अक्षरूपी)
 */
export function amountInNepaliWords(amount: number): string {
  const rounded = Math.floor(amount);
  if (rounded === 0) return 'शून्य रुपैयाँ मात्र';

  function convertTwoDigits(num: number): string {
    if (num === 0) return '';
    if (num < 20) return ONES_NE[num] + ' ';
    const tens = Math.floor(num / 10);
    const ones = num % 10;
    return (TENS_NE[tens] || '') + (ones > 0 ? ' ' + ONES_NE[ones] : '') + ' ';
  }

  let words = '';
  let n = rounded;

  if (n >= 10000000) {
    const crore = Math.floor(n / 10000000);
    words += convertTwoDigits(crore) + 'करोड ';
    n %= 10000000;
  }

  if (n >= 100000) {
    const lakh = Math.floor(n / 100000);
    words += convertTwoDigits(lakh) + 'लाख ';
    n %= 100000;
  }

  if (n >= 1000) {
    const thousand = Math.floor(n / 1000);
    words += convertTwoDigits(thousand) + 'हजार ';
    n %= 1000;
  }

  if (n >= 100) {
    const hundred = Math.floor(n / 100);
    words += ONES_NE[hundred] + ' सय ';
    n %= 100;
  }

  if (n > 0) {
    words += convertTwoDigits(n);
  }

  const paisa = Math.round((amount - rounded) * 100);
  let paisaWords = '';
  if (paisa > 0) {
    paisaWords = `र ${convertTwoDigits(paisa)}पैसा `;
  }

  return `रुपैयाँ ${words.trim()} ${paisaWords}मात्र`;
}

/**
 * Converts numeric amount to English Words
 */
export function amountInEnglishWords(amount: number): string {
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  const rounded = Math.floor(amount);
  if (rounded === 0) return 'Zero Rupees Only';

  function convertChunk(num: number): string {
    let s = '';
    if (num >= 100) {
      s += ones[Math.floor(num / 100)] + ' Hundred ';
      num %= 100;
    }
    if (num >= 20) {
      s += tens[Math.floor(num / 10)] + ' ';
      num %= 10;
    }
    if (num > 0) {
      s += ones[num] + ' ';
    }
    return s;
  }

  let words = '';
  let n = rounded;

  if (n >= 10000000) {
    words += convertChunk(Math.floor(n / 10000000)) + 'Crore ';
    n %= 10000000;
  }
  if (n >= 100000) {
    words += convertChunk(Math.floor(n / 100000)) + 'Lakh ';
    n %= 100000;
  }
  if (n >= 1000) {
    words += convertChunk(Math.floor(n / 1000)) + 'Thousand ';
    n %= 1000;
  }
  if (n > 0) {
    words += convertChunk(n);
  }

  return `Rupees ${words.trim()} Only`;
}
