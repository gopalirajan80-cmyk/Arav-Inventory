// Google Drive Integration for KrishiYantra ERP
// Follows workspace-integration skill: client-side Firebase Auth + Google Drive REST API v3
import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut,
  User
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);

const provider = new GoogleAuthProvider();
// Workspace Scopes for Google Drive file management & backup
export const SCOPES = [
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/drive.appdata'
];

SCOPES.forEach((scope) => provider.addScope(scope));

let isSigningIn = false;
let cachedAccessToken: string | null = null;

/**
 * Initializes Google Auth state listener and handles redirect results.
 */
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  getRedirectResult(auth)
    .then((result) => {
      if (result) {
        const credential = GoogleAuthProvider.credentialFromResult(result);
        if (credential?.accessToken) {
          cachedAccessToken = credential.accessToken;
          if (onAuthSuccess) onAuthSuccess(result.user, credential.accessToken);
        }
      }
    })
    .catch((err) => {
      console.error('Redirect result error:', err);
    });

  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken as string);
      } else if (!isSigningIn) {
        // Try to get token or fallback
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

/**
 * Launches Google Sign-In popup with redirect fallback.
 */
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('गुगल ड्राइभको अनुमति टोकन प्राप्त हुन सकेन');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: credential.accessToken };
  } catch (error: any) {
    console.warn('Popup sign in failed, trying redirect fallback:', error);
    try {
      await signInWithRedirect(auth, provider);
      return null;
    } catch (redirectErr: any) {
      console.error('Redirect sign in error:', redirectErr);
      throw new Error(
        redirectErr?.message || error?.message || 'गुगल लग-इन असफल भयो। कृपया पपअप ब्लकर (Popup Blocker) बन्द गर्नुहोस् वा पुनः प्रयास गर्नुहोस्।'
      );
    }
  } finally {
    isSigningIn = false;
  }
};

/**
 * Returns currently cached Google access token in memory.
 */
export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

/**
 * Signs out and clears cached token in memory.
 */
export const logoutGoogle = async () => {
  await signOut(auth);
  cachedAccessToken = null;
};

export interface DriveBackupFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime?: string;
  modifiedTime?: string;
}

const BACKUP_FOLDER_NAME = 'KrishiYantra_ERP_Backups';

/**
 * Finds or creates the KrishiYantra ERP backup folder in Google Drive
 */
async function getOrCreateBackupFolder(accessToken: string): Promise<string> {
  const query = encodeURIComponent(
    `name = '${BACKUP_FOLDER_NAME}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`
  );
  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name)`,
    {
      headers: { Authorization: `Bearer ${accessToken}` }
    }
  );

  if (searchRes.ok) {
    const data = await searchRes.json();
    if (data.files && data.files.length > 0) {
      return data.files[0].id;
    }
  }

  // Create folder if not found
  const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: BACKUP_FOLDER_NAME,
      mimeType: 'application/vnd.google-apps.folder'
    })
  });

  const folderData = await createRes.json();
  return folderData.id;
}

/**
 * Uploads a backup file (JSON or binary) to the KrishiYantra backup folder in Google Drive
 */
export async function uploadBackupToDrive(params: {
  fileName: string;
  content: string | Blob;
  mimeType: string;
}): Promise<DriveBackupFile> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('गुगल खाता जोडिएको छैन। पहिले लग-इन गर्नुहोस्।');
  }

  const folderId = await getOrCreateBackupFolder(token);

  const metadata = {
    name: params.fileName,
    parents: [folderId]
  };

  const form = new FormData();
  form.append(
    'metadata',
    new Blob([JSON.stringify(metadata)], { type: 'application/json' })
  );

  const fileBlob =
    typeof params.content === 'string'
      ? new Blob([params.content], { type: params.mimeType })
      : params.content;

  form.append('file', fileBlob);

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,createdTime,modifiedTime',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`
      },
      body: form
    }
  );

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData?.error?.message || 'गुगल ड्राइभमा फाइल अपलोड हुन सकेन');
  }

  return await res.json();
}

/**
 * Lists all ERP backups saved in Google Drive
 */
export async function listDriveBackups(): Promise<DriveBackupFile[]> {
  const token = await getAccessToken();
  if (!token) return [];

  const folderId = await getOrCreateBackupFolder(token);
  const query = encodeURIComponent(`'${folderId}' in parents and trashed = false`);

  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&orderBy=createdTime desc&fields=files(id,name,mimeType,size,createdTime,modifiedTime)`,
    {
      headers: { Authorization: `Bearer ${token}` }
    }
  );

  if (!res.ok) return [];
  const data = await res.json();
  return data.files || [];
}

/**
 * Downloads a backup file from Google Drive as text
 */
export async function downloadDriveBackupText(fileId: string): Promise<string> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('गुगल खाता जोडिएको छैन');
  }

  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!res.ok) {
    throw new Error('गुगल ड्राइभबाट फाइल डाउनलोड गर्न सकिएन');
  }

  return await res.text();
}

/**
 * Deletes a backup file from Google Drive with mandatory user confirmation
 */
export async function deleteDriveFile(fileId: string): Promise<void> {
  const token = await getAccessToken();
  if (!token) throw new Error('गुगल खाता जोडिएको छैन');

  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!res.ok && res.status !== 204) {
    throw new Error('गुगल ड्राइभबाट फाइल हटाउन सकिएन');
  }
}
