import jsPDF from 'jspdf';
import { nativePrint } from './desktopPrint';
import html2canvas from 'html2canvas';
import { getPaperSize } from './paperSize';

export interface GeneratePdfOptions {
  elementId: string;
  fileName: string;
  format?: 'a4' | 'pos80' | 'pos58';
  onProgress?: (progress: boolean) => void;
}

const colorCanvas = typeof document !== 'undefined' ? document.createElement('canvas') : null;
if (colorCanvas) {
  colorCanvas.width = 1;
  colorCanvas.height = 1;
}
const colorCtx = colorCanvas ? colorCanvas.getContext('2d', { willReadFrequently: true }) : null;

export const resolveCssColorToRgba = (cssColor: string): string => {
  if (!cssColor || !colorCtx) return cssColor;
  try {
    colorCtx.clearRect(0, 0, 1, 1);
    colorCtx.fillStyle = 'rgba(0,0,0,0)';
    colorCtx.fillStyle = cssColor;
    colorCtx.fillRect(0, 0, 1, 1);
    const [r, g, b, a] = colorCtx.getImageData(0, 0, 1, 1).data;
    if (a === 0) return 'transparent';
    if (a === 255) return `rgb(${r}, ${g}, ${b})`;
    return `rgba(${r}, ${g}, ${b}, ${(a / 255).toFixed(3)})`;
  } catch {
    return '#1e293b';
  }
};

export const replaceModernCssColorsInText = (cssText: string): string => {
  if (!cssText) return cssText;
  // Replace oklch(...), oklab(...), color(...) with standard rgb/rgba
  return cssText.replace(/(?:oklch|oklab|color)\([^)]+\)/gi, (match) => {
    return resolveCssColorToRgba(match);
  });
};

export const sanitizeClonedDocForHtml2Canvas = (clonedDoc: Document) => {
  // 1. Sanitize all <style> tags so html2canvas CSS parser never sees oklch()
  clonedDoc.querySelectorAll('style').forEach((styleEl) => {
    if (styleEl.textContent && /(?:oklch|oklab|color)\(/i.test(styleEl.textContent)) {
      styleEl.textContent = replaceModernCssColorsInText(styleEl.textContent);
    }
  });

  // 2. Sanitize inline style attributes and computed colors on all elements in body
  const allEls = clonedDoc.body ? Array.from(clonedDoc.body.querySelectorAll('*')) : [];
  allEls.forEach((el) => {
    const htmlEl = el as HTMLElement;
    const inlineStyle = htmlEl.getAttribute('style');
    if (inlineStyle && /(?:oklch|oklab|color)\(/i.test(inlineStyle)) {
      htmlEl.setAttribute('style', replaceModernCssColorsInText(inlineStyle));
    }
    const win = clonedDoc.defaultView;
    if (win) {
      const comp = win.getComputedStyle(htmlEl);
      const props: (keyof CSSStyleDeclaration)[] = [
        'color',
        'backgroundColor',
        'borderTopColor',
        'borderRightColor',
        'borderBottomColor',
        'borderLeftColor',
        'outlineColor'
      ];
      props.forEach((p) => {
        const val = comp[p] as string;
        if (val && /(?:oklch|oklab|color)\(/i.test(val)) {
          (htmlEl.style as any)[p] = resolveCssColorToRgba(val);
        }
      });
      if (comp.boxShadow && /(?:oklch|oklab|color)\(/i.test(comp.boxShadow)) {
        htmlEl.style.boxShadow = 'none';
      }
      if (comp.backgroundImage && /(?:oklch|oklab|color)\(/i.test(comp.backgroundImage)) {
        htmlEl.style.backgroundImage = replaceModernCssColorsInText(comp.backgroundImage);
      }
    }
  });
};

export const createElementPdfInstance = async (
  element: HTMLElement,
  fileName: string,
  format: 'a4' | 'pos80' | 'pos58' = 'a4'
): Promise<{ pdf: jsPDF; finalName: string }> => {
  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
    onclone: (clonedDoc) => {
      sanitizeClonedDocForHtml2Canvas(clonedDoc);
    }
  });

  const imgData = canvas.toDataURL('image/png');
  const finalName = fileName.endsWith('.pdf') ? fileName : `${fileName}.pdf`;

  if (format === 'a4') {
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: getPaperSize().toLowerCase()
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const margin = 6;
    const imgWidth = pdfWidth - margin * 2;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    const pageUsableHeight = pdfHeight - margin * 2;

    let heightLeft = imgHeight;
    let position = margin;

    pdf.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight);
    heightLeft -= pageUsableHeight;

    while (heightLeft > 2) {
      position = heightLeft - imgHeight + margin;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', margin, position, imgWidth, imgHeight);
      heightLeft -= pageUsableHeight;
    }

    return { pdf, finalName };
  } else {
    const rollWidthMm = format === 'pos80' ? 80 : 58;
    const rollHeightMm = (canvas.height * rollWidthMm) / canvas.width + 10;

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [rollWidthMm, Math.max(100, rollHeightMm)]
    });

    pdf.addImage(imgData, 'PNG', 2, 2, rollWidthMm - 4, (canvas.height * (rollWidthMm - 4)) / canvas.width);
    return { pdf, finalName };
  }
};

export const renderElementToPdfFile = async (
  element: HTMLElement,
  fileName: string,
  format: 'a4' | 'pos80' | 'pos58' = 'a4'
): Promise<boolean> => {
  const { pdf, finalName } = await createElementPdfInstance(element, fileName, format);
  pdf.save(finalName);
  return true;
};

export const renderElementToShareablePdfFile = async (
  element: HTMLElement,
  fileName: string,
  format: 'a4' | 'pos80' | 'pos58' = 'a4'
): Promise<File> => {
  const { pdf, finalName } = await createElementPdfInstance(element, fileName, format);
  const blob = pdf.output('blob');
  return new File([blob], finalName, { type: 'application/pdf' });
};

export const generateElementPdfFile = async ({
  elementId,
  fileName,
  format = 'a4',
  onProgress
}: GeneratePdfOptions): Promise<File | null> => {
  try {
    if (onProgress) onProgress(true);
    const element = document.getElementById(elementId);
    if (!element) {
      console.error(`Element #${elementId} not found`);
      if (onProgress) onProgress(false);
      return null;
    }
    const file = await renderElementToShareablePdfFile(element, fileName, format);
    if (onProgress) onProgress(false);
    return file;
  } catch (error) {
    console.error('Failed to generate shareable PDF file:', error);
    if (onProgress) onProgress(false);
    return null;
  }
};

export const downloadElementAsPdf = async ({
  elementId,
  fileName,
  format = 'a4',
  onProgress
}: GeneratePdfOptions): Promise<boolean> => {
  try {
    if (onProgress) onProgress(true);
    const element = document.getElementById(elementId);
    if (!element) {
      console.error(`Element #${elementId} not found`);
      if (onProgress) onProgress(false);
      return false;
    }

    await renderElementToPdfFile(element, fileName, format);
    if (onProgress) onProgress(false);
    return true;
  } catch (error) {
    console.error('Failed to export PDF:', error);
    if (onProgress) onProgress(false);
    return false;
  }
};

/**
 * Prints an HTML string reliably inside iframes/browsers by injecting a print-only container
 * AND showing an on-screen print/PDF preview toolbar if needed.
 */
export const triggerReliableHtmlPrint = (bodyInnerHtml: string, pageSizeCss = 'A4 portrait') => {
  // Remove any previous print container
  const existingRoot = document.getElementById('ky-direct-print-container');
  if (existingRoot) existingRoot.remove();
  const existingStyle = document.getElementById('ky-direct-print-style');
  if (existingStyle) existingStyle.remove();

  if (/^A4/i.test(pageSizeCss)) pageSizeCss = `${getPaperSize()} portrait`;
  const styleEl = document.createElement('style');
  styleEl.id = 'ky-direct-print-style';
  styleEl.textContent = `
    #ky-direct-print-container {
      display: none;
    }
    @media print {
      @page {
        size: ${pageSizeCss};
        margin: 8mm;
      }
      body > *:not(#ky-direct-print-container) {
        display: none !important;
      }
      #ky-direct-print-container {
        display: block !important;
        width: 100% !important;
        background: #ffffff !important;
        color: #000000 !important;
        margin: 0 !important;
        padding: 0 !important;
        font-family: 'Mukta', 'Noto Sans Devanagari', 'Plus Jakarta Sans', sans-serif !important;
      }
      #ky-direct-print-container * {
        font-family: inherit !important;
      }
    }
  `;
  document.head.appendChild(styleEl);

  const printContainer = document.createElement('div');
  printContainer.id = 'ky-direct-print-container';
  printContainer.innerHTML = bodyInnerHtml;
  document.body.appendChild(printContainer);

  setTimeout(() => {
    try {
      void nativePrint({ preferCss: true });
    } catch (e) {
      console.error('Print error:', e);
    }
  }, 120);
};

