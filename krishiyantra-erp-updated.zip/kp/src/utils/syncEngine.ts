// Multi-device sync + "data never lost" engine.
//
// All app data lives in localStorage under keys "krishiyantra_*". This engine
//  * remembers WHEN each key was last changed on this device,
//  * pushes changes to the server (/api/sync) a moment after they happen,
//  * pulls changes made on other devices,
//  * on a brand-new / reinstalled device restores EVERYTHING from the server before the app starts.
// Per key, the newest change wins. A copy of anything overwritten is kept in "ky_conflict_<key>".
//
// No imports on purpose: dependencies are injected so it can be tested outside a browser.

export const SYNC_PREFIX = 'krishiyantra_';
const META_KEY = 'ky_sync_meta';
const CONFLICT_PREFIX = 'ky_conflict_';

// Per-device settings that must NOT be shared between devices
const LOCAL_ONLY = new Set([
  'krishiyantra_local_backup_enabled',
  'krishiyantra_local_backup_folder_path',
  'krishiyantra_explicit_logout_v1',
  'krishiyantra_active_acc_v3',
  'krishiyantra_role_v3',
  'krishiyantra_lang_v3',
  'krishiyantra_active_company_id_v1',
]);

export const isSyncedKey = (k: string) => k.startsWith(SYNC_PREFIX) && !LOCAL_ONLY.has(k);

type Meta = { mtimes: Record<string, number>; pending: Record<string, true>; local: Record<string, true>; since: number };
type Entry = { v: string | null; m: number; s?: number; d?: boolean };

export type SyncStatus = {
  state: 'idle' | 'syncing' | 'offline';
  pending: number;        // changes not yet saved on the server
  remoteChanged: boolean; // another device saved newer data -> app should reload
};

export interface SyncDeps {
  storage: Storage;
  proto: any; // Storage.prototype (setItem/removeItem are patched here)
  fetchFn: (url: string, init?: any) => Promise<Response>;
  now?: () => number;
}

export function createSyncEngine(deps: SyncDeps) {
  const { storage, proto, fetchFn } = deps;
  const now = deps.now ?? (() => Date.now());
  const origGet = proto.getItem as (k: string) => string | null;
  const origSet = proto.setItem as (k: string, v: string) => void;
  const origRemove = proto.removeItem as (k: string) => void;

  let tracked = false;
  let pushing = false;
  let pushAgain = false;
  let pushTimer: any = null;
  let retryTimer: any = null;
  let pollTimer: any = null;
  let retryDelay = 5000;
  let started = false;
  let state: SyncStatus['state'] = 'idle';
  let remoteChanged = false;
  const listeners = new Set<(s: SyncStatus) => void>();

  // ---------- meta ----------
  const emptyMeta = (): Meta => ({ mtimes: {}, pending: {}, local: {}, since: 0 });
  function loadMeta(): Meta {
    try {
      const raw = origGet.call(storage, META_KEY);
      if (raw) {
        const p = JSON.parse(raw);
        return { mtimes: p.mtimes || {}, pending: p.pending || {}, local: p.local || {}, since: Number(p.since) || 0 };
      }
    } catch {}
    return emptyMeta();
  }
  let meta: Meta = loadMeta();
  const saveMeta = () => { try { origSet.call(storage, META_KEY, JSON.stringify(meta)); } catch {} };

  // ---------- status ----------
  const getStatus = (): SyncStatus => ({ state, pending: Object.keys(meta.pending).length, remoteChanged });
  const notify = () => { const s = getStatus(); listeners.forEach((l) => { try { l(s); } catch {} }); };
  function subscribe(cb: (s: SyncStatus) => void) { listeners.add(cb); return () => { listeners.delete(cb); }; }
  const setState = (s: SyncStatus['state']) => { state = s; notify(); };

  // ---------- helpers ----------
  function syncedLocalKeys(): string[] {
    const out: string[] = [];
    for (let i = 0; i < storage.length; i++) {
      const k = storage.key(i);
      if (k && isSyncedKey(k)) out.push(k);
    }
    return out;
  }
  const hasLocalData = () => syncedLocalKeys().length > 0;

  function saveConflictCopy(key: string, value: string) {
    try { origSet.call(storage, CONFLICT_PREFIX + key, value); } catch {}
  }

  function markLocal(key: string) {
    meta.mtimes[key] = Math.max(now(), (meta.mtimes[key] || 0) + 1);
    meta.pending[key] = true;
    meta.local[key] = true; // this device wrote the current value
    saveMeta();
    schedulePush();
    notify();
  }

  /** Watch writes made by the app so they are synced. Called once. */
  function track() {
    if (tracked) return;
    tracked = true;
    proto.setItem = function (this: Storage, key: string, value: string) {
      if (this !== storage || !isSyncedKey(key)) return origSet.call(this, key, value);
      const old = origGet.call(this, key);
      origSet.call(this, key, value); // may throw (quota) -> then nothing is tracked
      if (old !== String(value)) markLocal(key);
    };
    proto.removeItem = function (this: Storage, key: string) {
      if (this !== storage || !isSyncedKey(key)) return origRemove.call(this, key);
      const old = origGet.call(this, key);
      origRemove.call(this, key);
      if (old !== null) markLocal(key);
    };
  }

  /** Two copies of the same list (items with an "id") -> one list containing everything. */
  function mergeById(localJson: string, remoteJson: string): string | null {
    try {
      const l = JSON.parse(localJson);
      const r = JSON.parse(remoteJson);
      const hasId = (x: any) => x && typeof x === 'object' && !Array.isArray(x) && x.id !== undefined && x.id !== null;
      if (!Array.isArray(l) || !Array.isArray(r) || !l.every(hasId) || !r.every(hasId)) return null;
      const seen = new Set(r.map((x: any) => String(x.id)));
      return JSON.stringify([...r, ...l.filter((x: any) => !seen.has(String(x.id)))]);
    } catch {
      return null;
    }
  }

  /** Apply one entry from the server. Returns true if local data actually changed. */
  function applyRemote(key: string, e: Entry): boolean {
    const local = origGet.call(storage, key);
    const lm = meta.mtimes[key] ?? 0;
    const remoteVal = e.d || e.v === null ? null : e.v;
    if (e.m < lm) return false; // our copy is newer -> keep (and push if pending)
    if (e.m === lm && !(meta.pending[key] && local !== remoteVal)) return false; // same version

    const wroteHere = !!meta.local[key] || !!meta.pending[key] || lm <= 1;
    if (local !== null && local !== remoteVal && wroteHere) {
      saveConflictCopy(key, local); // never throw an edit away silently
      if (remoteVal !== null) {
        const merged = mergeById(local, remoteVal);
        if (merged !== null) {
          // both devices changed the same list: keep everything from both and upload the result
          const changed = merged !== local;
          if (changed) origSet.call(storage, key, merged);
          meta.mtimes[key] = Math.max(e.m, lm) + 1;
          meta.pending[key] = true;
          meta.local[key] = true;
          schedulePush(300);
          return changed;
        }
      }
    }
    const changed = local !== remoteVal;
    if (changed) {
      if (remoteVal === null) origRemove.call(storage, key);
      else origSet.call(storage, key, remoteVal);
    }
    meta.mtimes[key] = e.m;
    delete meta.pending[key];
    delete meta.local[key];
    return changed;
  }

  // ---------- network ----------
  async function pull(): Promise<boolean> {
    const res = await fetchFn(`/api/sync?since=${meta.since}`);
    if (!res.ok) throw new Error('pull ' + res.status);
    const json: any = await res.json();
    if (typeof json.version === 'number' && json.version < meta.since) {
      // Server data was reset/lost -> this device re-uploads everything it has
      meta.since = 0;
      for (const k of syncedLocalKeys()) {
        meta.mtimes[k] = meta.mtimes[k] || 1;
        meta.pending[k] = true;
      }
      saveMeta();
      schedulePush(0);
      return false;
    }
    let changed = false;
    for (const [k, e] of Object.entries<Entry>(json.entries || {})) {
      if (isSyncedKey(k) && applyRemote(k, e)) changed = true;
    }
    meta.since = Number(json.version) || meta.since;
    saveMeta();
    return changed;
  }

  async function push(): Promise<void> {
    if (pushing) { pushAgain = true; return; }
    const keys = Object.keys(meta.pending);
    if (!keys.length) return;
    pushing = true;
    setState('syncing');
    try {
      const sent: Record<string, number> = {};
      const entries: Record<string, Entry> = {};
      for (const k of keys) {
        const v = origGet.call(storage, k);
        const m = meta.mtimes[k] ?? 1;
        sent[k] = m;
        entries[k] = v === null ? { v: null, m, d: true } : { v, m };
      }
      const res = await fetchFn('/api/sync', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ since: meta.since, entries }),
      });
      if (!res.ok) throw new Error('push ' + res.status);
      const json: any = await res.json();

      let changed = false;
      for (const [k, e] of Object.entries<Entry>(json.entries || {})) {
        if (isSyncedKey(k) && applyRemote(k, e)) changed = true;
      }
      for (const k of keys) if ((meta.mtimes[k] ?? 1) === sent[k]) delete meta.pending[k];
      meta.since = Number(json.version) || meta.since;
      saveMeta();
      if (changed) remoteChanged = true;
      retryDelay = 5000;
      setState('idle');
    } catch {
      setState('offline');
      scheduleRetry();
    } finally {
      pushing = false;
      if (pushAgain || Object.keys(meta.pending).length) {
        pushAgain = false;
        if (state !== 'offline') schedulePush();
      }
      notify();
    }
  }

  function schedulePush(delay = 1500) {
    if (pushTimer) clearTimeout(pushTimer);
    pushTimer = setTimeout(() => { pushTimer = null; void push(); }, delay);
  }
  function scheduleRetry() {
    if (retryTimer) return;
    retryTimer = setTimeout(() => { retryTimer = null; void syncNow(); }, retryDelay);
    retryDelay = Math.min(retryDelay * 2, 60000);
  }

  /** Pull other devices' changes, then push ours. */
  async function syncNow(): Promise<void> {
    try {
      const changed = await pull();
      if (changed) remoteChanged = true;
      if (Object.keys(meta.pending).length) await push();
      else setState('idle');
    } catch {
      setState('offline');
      scheduleRetry();
    }
  }

  function startBackground() {
    if (started) return;
    started = true;
    pollTimer = setInterval(() => { void syncNow(); }, 30000);
    if (typeof window !== 'undefined') {
      window.addEventListener('online', onWake);
      window.addEventListener('focus', onWake);
    }
    if (typeof document !== 'undefined') document.addEventListener('visibilitychange', onVisible);
  }
  function onWake() { void syncNow(); }
  function onVisible() { if (typeof document !== 'undefined' && document.visibilityState === 'visible') void syncNow(); }

  function stop() {
    started = false;
    for (const t of [pushTimer, retryTimer]) if (t) clearTimeout(t);
    pushTimer = retryTimer = null;
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;
    if (typeof window !== 'undefined') {
      window.removeEventListener('online', onWake);
      window.removeEventListener('focus', onWake);
    }
    if (typeof document !== 'undefined') document.removeEventListener('visibilitychange', onVisible);
  }

  // ---------- public API ----------
  /**
   * Run once after login, BEFORE the app starts.
   * ok=false only when this device has no data yet AND the server cannot be reached
   * (starting an empty app then could later overwrite the real data).
   */
  async function init(): Promise<{ ok: boolean }> {
    track();
    const hadData = hasLocalData();
    if (!hadData) meta = emptyMeta(); // new / reinstalled device: restore everything from the server

    // data from before sync existed: remember it so it is uploaded
    for (const k of syncedLocalKeys()) {
      if (meta.mtimes[k] === undefined) { meta.mtimes[k] = 1; meta.pending[k] = true; }
    }
    saveMeta();

    try {
      await pull();
    } catch {
      if (!hadData) return { ok: false };
      setState('offline');
      scheduleRetry();
    }
    if (Object.keys(meta.pending).length) schedulePush(300);
    startBackground();
    return { ok: true };
  }

  async function flushNow(): Promise<boolean> {
    if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
    for (let i = 0; i < 3 && Object.keys(meta.pending).length; i++) {
      while (pushing) await new Promise((r) => setTimeout(r, 50));
      await push();
    }
    return Object.keys(meta.pending).length === 0;
  }

  /** Load a downloaded server backup into this device and upload it (overrides current data). */
  async function restoreFromBackup(text: string): Promise<{ ok: boolean; count: number }> {
    let parsed: any;
    try { parsed = JSON.parse(text); } catch { return { ok: false, count: 0 }; }
    const entries = parsed && typeof parsed === 'object' ? parsed.entries : null;
    if (!entries || typeof entries !== 'object') return { ok: false, count: 0 };
    let count = 0;
    const t = now();
    for (const [k, e] of Object.entries<any>(entries)) {
      if (!isSyncedKey(k) || !e || e.d || typeof e.v !== 'string') continue;
      origSet.call(storage, k, e.v);
      meta.mtimes[k] = Math.max(t, (meta.mtimes[k] || 0) + 1);
      meta.pending[k] = true;
      count++;
    }
    saveMeta();
    notify();
    const saved = await flushNow();
    return { ok: count > 0 && saved, count };
  }

  const acknowledgeRemote = () => { remoteChanged = false; notify(); };

  return { init, syncNow, flushNow, stop, subscribe, getStatus, restoreFromBackup, acknowledgeRemote };
}

export type SyncEngine = ReturnType<typeof createSyncEngine>;
