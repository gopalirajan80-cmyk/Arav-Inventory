// The one sync engine used by the running app (browser localStorage <-> server).
import { createSyncEngine } from './syncEngine';
import { authFetch } from './auth';

export const syncEngine = createSyncEngine({
  storage: localStorage,
  proto: Storage.prototype,
  fetchFn: authFetch,
});
