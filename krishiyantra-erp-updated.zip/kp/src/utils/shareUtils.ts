// Share Utility for WhatsApp, Viber, SMS, and Mobile Messaging
// Formats customer dues, party ledger statements, and invoice reports in clean Nepali

import { Invoice, Party, CompanyProfile } from '../types';
import { formatCurrency } from './nepaliCalendar';

/**
 * Builds a clean Nepali statement message for customer dues & ledger
 */
export function buildCustomerStatementMessage(
  party: Party,
  company: CompanyProfile,
  latestInvoice?: Invoice
): string {
  const currentDue = party.currentBalance !== undefined ? party.currentBalance : party.openingBalance;
  
  let msg = `*${company.name}*\n`;
  msg += `ठेगाना: ${company.address} | फोन: ${company.phone}\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `*ग्राहक हिसाब विवरण (Customer Statement)*\n`;
  msg += `ग्राहकको नाम: *${party.name}*\n`;
  if (party.address) msg += `ठेगाना: ${party.address}\n`;
  if (party.phone) msg += `सम्पर्क: ${party.phone}\n`;
  if (party.panNo) msg += `प्यान नं: ${party.panNo}\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  
  if (latestInvoice) {
    msg += `भर्खरैको बिल नं: ${latestInvoice.invoiceNo}\n`;
    msg += `बिल मिति: ${latestInvoice.dateBs}\n`;
    msg += `बिल रकम: ${formatCurrency(latestInvoice.grandTotal, true)}\n`;
    if (latestInvoice.amountPaid) {
      msg += `बुझाएको रकम: ${formatCurrency(latestInvoice.amountPaid, true)}\n`;
    }
    if (latestInvoice.paymentDueDate) {
      msg += `रकम बुझाउने म्याद: *${latestInvoice.paymentDueDate}*\n`;
    }
  }

  msg += `\n*हालसम्म कुल तिर्न बाँकी रकम: ${formatCurrency(currentDue, true)}*\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;

  if (company.bankAccounts && company.bankAccounts.length > 0) {
    const primaryBank = company.bankAccounts[0];
    msg += `*बैंक खाता विवरण (Bank Details):*\n`;
    msg += `बैंक: ${primaryBank.bankName}\n`;
    msg += `खाता नं: *${primaryBank.accountNumber}*\n`;
    msg += `खातावाला: ${primaryBank.accountHolder}\n`;
    if (primaryBank.branch) msg += `शाखा: ${primaryBank.branch}\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  }

  msg += `समयमै रकम भुक्तानी गरी सहयोग गरिदिनुहुन अनुरोध छ। धन्यवाद !\n`;
  msg += `_${company.name}_`;

  return msg;
}

/**
 * Builds invoice receipt message
 */
export function buildInvoiceShareMessage(
  invoice: Invoice,
  company: CompanyProfile
): string {
  let msg = `*${company.name}*\n`;
  msg += `फोन: ${company.phone} | प्यान: ${company.panVatNo}\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `*${invoice.billType === 'VAT' ? 'कर बीजक (Tax Invoice)' : 'बिक्री बिल (Sales Bill)'}*\n`;
  msg += `बीजक नं: *${invoice.invoiceNo}*\n`;
  msg += `मिति: ${invoice.dateBs} (समय: ${invoice.time || '10:00'})\n`;
  msg += `ग्राहक: *${invoice.customerName}*\n`;
  if (invoice.customerPhone) msg += `फोन: ${invoice.customerPhone}\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `*सामग्री विवरण:*\n`;
  invoice.items.forEach((item, idx) => {
    msg += `${idx + 1}. ${item.name} (${item.quantity} ${item.unit}) x रु. ${item.rate} = रु. ${item.amount}\n`;
  });
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `कुल रकम: *${formatCurrency(invoice.grandTotal, true)}*\n`;
  if (invoice.amountPaid !== undefined) {
    msg += `बुझाएको रकम: ${formatCurrency(invoice.amountPaid, true)}\n`;
    msg += `बाँकी रकम: *${formatCurrency(invoice.remainingDue || 0, true)}*\n`;
  }
  if (invoice.paymentDueDate) {
    msg += `रकम बुझाउने म्याद: *${invoice.paymentDueDate}*\n`;
  }
  msg += `\nधन्यवाद ! फेरि भेटौँला।`;
  return msg;
}

/**
 * Converts Devanagari digits (०-९) to standard ASCII digits (0-9)
 */
export function normalizeNepaliDigitsToAscii(str?: string): string {
  if (!str) return '';
  const map: Record<string, string> = {
    '०': '0',
    '१': '1',
    '२': '2',
    '३': '3',
    '४': '4',
    '५': '5',
    '६': '6',
    '७': '7',
    '८': '8',
    '९': '9'
  };
  return str.replace(/[०-९]/g, (d) => map[d] || d);
}

/**
 * Sanitizes phone number (including Nepali digits) to international 977 format for WhatsApp wa.me links
 */
export function cleanPhoneNumber(phone?: string): string {
  if (!phone) return '';
  const ascii = normalizeNepaliDigitsToAscii(phone);
  // First check if there is a 10-digit Nepal mobile number starting with 97 or 98
  const mobileMatch = ascii.match(/(?:977)?(9[678]\d{8})/);
  if (mobileMatch && mobileMatch[1]) {
    return `977${mobileMatch[1]}`;
  }
  const digits = ascii.replace(/\D/g, '');
  if (digits.startsWith('977') && digits.length === 13) {
    return digits;
  }
  if (digits.length === 10) {
    return `977${digits}`;
  }
  if (digits.length > 10 && digits.slice(-10).startsWith('9')) {
    return `977${digits.slice(-10)}`;
  }
  return digits;
}

/**
 * Open WhatsApp directly with prefilled message via wa.me intent URL
 */
export function shareViaWhatsApp(phone: string | undefined, message: string) {
  const cleanedPhone = cleanPhoneNumber(phone);
  const encodedText = encodeURIComponent(message);
  const url = cleanedPhone
    ? `https://wa.me/${cleanedPhone}?text=${encodedText}`
    : `https://wa.me/?text=${encodedText}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}

/**
 * Open Viber directly with prefilled message
 */
export function shareViaViber(message: string) {
  const encodedText = encodeURIComponent(message);
  const viberUrl = `viber://forward?text=${encodedText}`;
  window.open(viberUrl, '_blank');
}

/**
 * Open native SMS app on mobile
 */
export function shareViaSms(phone: string | undefined, message: string) {
  const asciiPhone = normalizeNepaliDigitsToAscii(phone);
  const cleanedPhone = asciiPhone ? asciiPhone.replace(/[^\d+]/g, '') : '';
  const encodedText = encodeURIComponent(message);
  const smsUrl = cleanedPhone
    ? `sms:${cleanedPhone}?body=${encodedText}`
    : `sms:?body=${encodedText}`;
  window.location.href = smsUrl;
}

/**
 * Copy text to clipboard
 */
export async function copyMessageToClipboard(message: string): Promise<boolean> {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(message);
      return true;
    }
    const textArea = document.createElement('textarea');
    textArea.value = message;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);
    return true;
  } catch {
    return false;
  }
}

/**
 * Builds a clean Nepali summary of any report for WhatsApp / Message
 */
export function buildReportShareMessage(
  titleNe: string,
  periodText: string,
  summaryCards: { label: string; value: string | number }[],
  company: CompanyProfile,
  headers?: string[],
  rows?: (string | number)[][]
): string {
  let msg = `*${company.name}*\n`;
  msg += `फोन: ${company.phone} | प्यान: ${company.panVatNo}\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `📊 *${titleNe}*\n`;
  if (periodText) msg += `अवधि/मिति: *${periodText}*\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;

  if (summaryCards && summaryCards.length > 0) {
    msg += `*मुख्य सारांश (Key Highlights):*\n`;
    summaryCards.forEach((c) => {
      msg += `• ${c.label}: *${c.value}*\n`;
    });
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  }

  if (headers && rows && rows.length > 0) {
    msg += `*विवरण सूची (Records Preview):*\n`;
    const previewRows = rows.slice(0, 5);
    previewRows.forEach((r, idx) => {
      msg += `${idx + 1}. ${r[0]} | ${r[1]} : ${r[r.length - 1]}\n`;
    });
    if (rows.length > 5) {
      msg += `(थप ${rows.length - 5} वटा रेकर्डहरू सफ्टवेयरमा उपलब्ध छन्)\n`;
    }
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  }

  msg += `कृषियन्त्र ERP सफ्टवेयरबाट सिर्जना गरिएको आधिकारिक विवरण।\n`;
  return msg;
}

/**
 * Builds a bank settlement / payment receipt message for customer
 */
export function buildBankSettlementReceiptMessage(
  params: {
    customerName: string;
    amount: number;
    bankName: string;
    referenceNo: string;
    dateBs: string;
    settledInvoices?: string[];
    remainingBalance?: number;
  },
  company: CompanyProfile
): string {
  let msg = `*${company.name}*\n`;
  msg += `ठेगाना: ${company.address} | फोन: ${company.phone}\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `✅ *बैंक भुक्तानी रसिद (Payment Confirmation)*\n`;
  msg += `ग्राहक: *${params.customerName}*\n`;
  msg += `भुक्तानी मिति: ${params.dateBs}\n`;
  msg += `जम्मा भएको बैंक: *${params.bankName}*\n`;
  msg += `बैंक रेफ / UTR नं: *${params.referenceNo}*\n`;
  msg += `प्राप्त रकम: *${formatCurrency(params.amount, true)}*\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  
  if (params.settledInvoices && params.settledInvoices.length > 0) {
    msg += `*फर्स्यौट भएका बिलहरू:*\n`;
    params.settledInvoices.forEach((inv) => {
      msg += `✓ बिल नं: ${inv} (चुक्ता)\n`;
    });
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  }

  if (params.remainingBalance !== undefined) {
    msg += `*हाल बाँकी रकम: ${formatCurrency(params.remainingBalance, true)}*\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
  }

  msg += `तपाईँको रकम हाम्रो बैंक खातामा प्राप्त भई सफ्टवेयरमा मिलान भइसकेको छ।\n`;
  msg += `सहयोगका लागि धन्यवाद !\n`;
  msg += `_${company.name}_`;
  return msg;
}

/**
 * Triggers native mobile/desktop Web Share sheet (with optional PDF File attachment)
 */
export async function triggerNativeWebShare(data: {
  title: string;
  text: string;
  url?: string;
  files?: File[];
}): Promise<boolean> {
  if (typeof navigator !== 'undefined' && navigator.share) {
    try {
      if (data.files && data.files.length > 0 && navigator.canShare && navigator.canShare({ files: data.files })) {
        await navigator.share({
          files: data.files,
          title: data.title,
          text: data.text
        });
        return true;
      }
      await navigator.share({
        title: data.title,
        text: data.text,
        ...(data.url ? { url: data.url } : {})
      });
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

/**
 * Shares a generated PDF file + message using Web Share API (if supported) or downloads the PDF
 * and opens direct WhatsApp wa.me chat with the customer's stored phone number.
 */
export async function sharePdfFileViaWebShareOrWhatsApp(params: {
  title: string;
  message: string;
  phone?: string;
  pdfFile: File | null;
  preferDirectWhatsAppNumber?: boolean;
}): Promise<{ status: 'SHARED_FILE_NATIVE' | 'DOWNLOADED_AND_OPENED_WAME' | 'OPENED_WAME_ONLY' }> {
  const { title, message, phone, pdfFile, preferDirectWhatsAppNumber } = params;

  // 1. If device supports native file sharing via Web Share API and user didn't force direct wa.me number:
  if (
    !preferDirectWhatsAppNumber &&
    pdfFile &&
    typeof navigator !== 'undefined' &&
    navigator.share &&
    navigator.canShare &&
    navigator.canShare({ files: [pdfFile] })
  ) {
    try {
      await navigator.share({
        files: [pdfFile],
        title,
        text: message
      });
      return { status: 'SHARED_FILE_NATIVE' };
    } catch {
      // User cancelled or browser blocked; fall through to download + wa.me
    }
  }

  // 2. Download the PDF file locally so user has it ready to attach in WhatsApp Web / Desktop, then open wa.me/<phone>
  if (pdfFile && typeof document !== 'undefined') {
    const blobUrl = URL.createObjectURL(pdfFile);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = pdfFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);

    const attachmentNote = `\n\n📎 *(नोट: ${pdfFile.name} फाइल डाउनलोड भएको छ, कृपया यस च्याटमा संलग्न गर्नुहोस्)*`;
    shareViaWhatsApp(phone, message + attachmentNote);
    return { status: 'DOWNLOADED_AND_OPENED_WAME' };
  }

  // 3. Fallback: open wa.me directly with text message
  shareViaWhatsApp(phone, message);
  return { status: 'OPENED_WAME_ONLY' };
}

