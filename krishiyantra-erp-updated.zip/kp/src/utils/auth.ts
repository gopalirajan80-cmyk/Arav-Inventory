// Client-side helpers for the server login.
const TOKEN_KEY = 'ky_auth_token';

export const getToken = (): string => {
  try { return localStorage.getItem(TOKEN_KEY) || ''; } catch { return ''; }
};
export const setToken = (t: string) => { try { localStorage.setItem(TOKEN_KEY, t); } catch {} };
export const clearToken = () => {
  try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); } catch {}
};

// Who is logged in (set by the server at login). Not secret; the server re-checks the token on every request.
const USER_KEY = 'ky_auth_user';
export interface ServerUser { id: string; name: string; role: string; allowedTabs: string[] }
export const getServerUser = (): ServerUser | null => {
  try { const r = localStorage.getItem(USER_KEY); return r ? JSON.parse(r) : null; } catch { return null; }
};
export const setServerUser = (u: ServerUser | null) => {
  try { if (u) localStorage.setItem(USER_KEY, JSON.stringify(u)); else localStorage.removeItem(USER_KEY); } catch {}
};
/** true when a staff member (not the owner) is logged in */
export const isStaffLogin = () => { const u = getServerUser(); return !!u && u.role !== 'OWNER'; };

/** Same as fetch(), but attaches the login token. If the server says 401, logs the user out. */
export async function authFetch(input: string, init: RequestInit = {}): Promise<Response> {
  const headers = new Headers(init.headers || {});
  const token = getToken();
  if (token) headers.set('Authorization', `Bearer ${token}`);
  const res = await fetch(input, { ...init, headers });
  if (res.status === 401) {
    clearToken();
    window.dispatchEvent(new Event('ky-auth-expired'));
  }
  return res;
}

// ---- Staff accounts (owner only) ----
export interface StaffAccount { id: string; name: string; role: string; allowedTabs: string[]; active: boolean; createdAt: string; updatedAt: string }
async function jsonCall(url: string, method: string, body?: unknown): Promise<{ ok: boolean; error?: string; data?: any }> {
  try {
    const res = await authFetch(url, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    return res.ok ? { ok: true, data } : { ok: false, error: data.error || 'असफल भयो।' };
  } catch { return { ok: false, error: 'सर्भरसँग जोडिन सकिएन।' }; }
}
export const staffApi = {
  list: () => jsonCall('/api/users', 'GET'),
  create: (u: { id: string; name: string; password: string; role: string; allowedTabs: string[] }) => jsonCall('/api/users', 'POST', u),
  update: (id: string, patch: Partial<{ name: string; password: string; role: string; allowedTabs: string[]; active: boolean }>) =>
    jsonCall('/api/users/' + encodeURIComponent(id), 'PUT', patch),
  remove: (id: string) => jsonCall('/api/users/' + encodeURIComponent(id), 'DELETE'),
};

/** Downloads the full server-side data copy as a .json file (needs login). */
export async function downloadServerBackup(): Promise<{ ok: boolean; message: string }> {
  try {
    const res = await authFetch('/api/backup');
    if (res.status === 404) return { ok: false, message: 'empty' };
    if (!res.ok) return { ok: false, message: 'failed' };
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `krishiyantra-server-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return { ok: true, message: 'ok' };
  } catch {
    return { ok: false, message: 'network' };
  }
}
