import { BillOfMaterial, RawMaterial } from '../types';

export interface MaterialRequirement {
  materialId: string;
  name: string;
  unit: string;
  required: number;
  stock: number;
  shortage: number;
  unitCost: number;
  cost: number;
}

const r3 = (n: number) => Math.round(n * 1000) / 1000;

/** कुनै BOM बाट qty एकाइ बनाउन चाहिने कच्चा पदार्थ (खेर % सहित) */
export function bomRequirements(
  bom: BillOfMaterial | undefined,
  qty: number,
  rawMaterials: RawMaterial[]
): MaterialRequirement[] {
  if (!bom || !bom.outputQty || qty <= 0) return [];
  const scale = qty / bom.outputQty;
  return bom.lines.map((l) => {
    const mat = rawMaterials.find((r) => r.id === l.materialId);
    const required = r3(l.qtyPerBatch * scale * (1 + (l.wastagePercent || 0) / 100));
    const stock = mat?.currentStock ?? 0;
    const unitCost = mat?.unitCostPrice ?? 0;
    return {
      materialId: l.materialId,
      name: mat?.nameNe || l.materialName,
      unit: l.unit || mat?.unit || '',
      required,
      stock,
      shortage: Math.max(0, r3(required - stock)),
      unitCost,
      cost: Math.round(required * unitCost * 100) / 100
    };
  });
}

/** आधार ब्याचको अनुमानित लागत (कच्चा पदार्थ + ज्याला + बिजुली + अन्य) */
export function bomBatchCost(bom: BillOfMaterial, rawMaterials: RawMaterial[]) {
  const material = bomRequirements(bom, bom.outputQty, rawMaterials).reduce((s, r) => s + r.cost, 0);
  const other = (bom.laborCostPerBatch || 0) + (bom.electricityCostPerBatch || 0) + (bom.otherCostPerBatch || 0);
  const total = material + other;
  return {
    material,
    other,
    total,
    perUnit: bom.outputQty > 0 ? Math.round((total / bom.outputQty) * 100) / 100 : 0
  };
}
