import { CompanyProfile, Party, Item, Invoice, PurchaseRecord, PartyTransaction, BankAccount } from '../types';
import { formatCurrency, getTodayBsString } from './nepaliCalendar';

interface ExportDataPayload {
  company: CompanyProfile;
  parties: Party[];
  items: Item[];
  invoices: Invoice[];
  purchases: PurchaseRecord[];
  partyTransactions: PartyTransaction[];
  bankAccounts: BankAccount[];
}

export const generateStandaloneHtmlReport = (data: ExportDataPayload): string => {
  const { company, parties, items, invoices, purchases, partyTransactions } = data;
  const todayBs = getTodayBsString();

  const totalCustomerReceivable = parties
    .filter((p) => ((p.partyType || p.type) === 'CUSTOMER' || !(p.partyType || p.type)) && (p.currentBalance ?? p.openingBalance) > 0)
    .reduce((sum, p) => sum + (p.currentBalance ?? p.openingBalance), 0);

  const totalSupplierPayable = parties
    .filter((p) => (p.partyType || p.type) === 'SUPPLIER' && (p.currentBalance ?? p.openingBalance) > 0)
    .reduce((sum, p) => sum + (p.currentBalance ?? p.openingBalance), 0);

  const totalInvoicesAmount = invoices
    .filter((inv) => inv.status === 'ACTIVE')
    .reduce((sum, inv) => sum + inv.grandTotal, 0);

  return `<!DOCTYPE html>
<html lang="ne">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${company.name || 'KrishiYantra ERP'} - अफलाइन रिपोर्ट तथा लेजरखाता (${todayBs})</title>
  <style>
    :root {
      --primary: #047857;
      --primary-dark: #065f46;
      --bg-slate: #f8fafc;
      --border: #e2e8f0;
      --text-dark: #0f172a;
      --text-muted: #64748b;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
    body { background-color: var(--bg-slate); color: var(--text-dark); padding: 20px; line-height: 1.5; }
    .container { max-width: 1200px; margin: 0 auto; }
    
    header { background: #064e3b; color: white; padding: 24px; border-radius: 16px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; }
    header h1 { font-size: 24px; font-weight: 800; }
    header p { font-size: 13px; opacity: 0.85; }
    
    .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .kpi-card { background: white; border: 1px solid var(--border); padding: 18px; border-radius: 14px; }
    .kpi-card .title { font-size: 12px; font-weight: 700; color: var(--text-muted); }
    .kpi-card .val { font-size: 22px; font-weight: 900; margin-top: 6px; font-family: monospace; }
    .val.green { color: #047857; }
    .val.red { color: #be123c; }

    .nav-tabs { display: flex; gap: 8px; margin-bottom: 16px; border-bottom: 2px solid var(--border); padding-bottom: 8px; overflow-x: auto; }
    .tab-btn { background: #e2e8f0; border: none; padding: 10px 18px; border-radius: 10px; font-weight: 700; font-size: 13px; cursor: pointer; color: #334155; }
    .tab-btn.active { background: var(--primary); color: white; }

    .search-box { margin-bottom: 16px; }
    .search-box input { width: 100%; padding: 12px 16px; border: 1px solid var(--border); border-radius: 10px; font-size: 13px; background: white; }

    .card-panel { background: white; border: 1px solid var(--border); border-radius: 16px; padding: 20px; overflow-x: auto; margin-bottom: 24px; }
    table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
    th { background: #0f172a; color: white; padding: 12px 14px; font-size: 12px; font-weight: 700; }
    td { padding: 12px 14px; border-bottom: 1px solid #f1f5f9; }
    tr:hover { background: #f8fafc; }

    .badge { display: inline-block; padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; }
    .badge-cust { background: #d1fae5; color: #065f46; }
    .badge-supp { background: #ffe4e6; color: #9f1239; }

    .btn-print { background: #0f172a; color: white; border: none; padding: 10px 18px; border-radius: 10px; font-weight: 700; cursor: pointer; }
    @media print {
      .no-print { display: none !important; }
      body { background: white; padding: 0; }
      header { background: #000; color: #fff; }
    }
  </style>
</head>
<body>
  <div class="container">
    
    <header>
      <div>
        <h1>${company.name || 'कृषियन्त्र ERP'}</h1>
        <p>${company.address ? company.address + ' | ' : ''}फोन: ${company.phone || 'N/A'} | PAN: ${company.panVatNo || 'N/A'}</p>
        <p>अफलाइन ब्याकअप तथा लेजर खाता डाटाबेस | मिति: ${todayBs}</p>
      </div>
      <div class="no-print">
        <button class="btn-print" onclick="window.print()">🖨️ प्रिन्ट गर्नुहोस् (Print Report)</button>
      </div>
    </header>

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="title">ग्राहकबाट कुल लिन बाँकी (Customer Dues)</div>
        <div class="val green">रु. ${totalCustomerReceivable.toLocaleString('ne-NP')}</div>
      </div>
      <div class="kpi-card">
        <div class="title">सप्लायरलाई कुल दिन बाँकी (Supplier Payable)</div>
        <div class="val red">रु. ${totalSupplierPayable.toLocaleString('ne-NP')}</div>
      </div>
      <div class="kpi-card">
        <div class="title">कुल बिक्री रकम (Total Active Sales)</div>
        <div class="val green">रु. ${totalInvoicesAmount.toLocaleString('ne-NP')}</div>
      </div>
      <div class="kpi-card">
        <div class="title">कुल सामान स्टक (Items Registered)</div>
        <div class="val">${items.length} वटा सामान</div>
      </div>
    </div>

    <div class="nav-tabs no-print">
      <button class="tab-btn active" onclick="switchTab('parties')">👥 ग्राहक/सप्लायर खाता (${parties.length})</button>
      <button class="tab-btn" onclick="switchTab('items')">📦 सामान सूची स्टक (${items.length})</button>
      <button class="tab-btn" onclick="switchTab('invoices')">📄 बिक्री बिल सूची (${invoices.length})</button>
      <button class="tab-btn" onclick="switchTab('purchases')">🛒 खरीद विवरण (${purchases.length})</button>
    </div>

    <div class="search-box no-print">
      <input type="text" id="searchInput" onkeyup="filterTables()" placeholder="नामतर्फ, फोन वा विवरणबाट खोज्नुहोस्...">
    </div>

    <!-- PARTIES TABLE -->
    <div id="tab-parties" class="card-panel tab-content">
      <h3 style="margin-bottom: 12px;">👥 ग्राहक तथा सप्लायर लेजर खाता बक्यौता</h3>
      <table id="partiesTable">
        <thead>
          <tr>
            <th>प्रकार</th>
            <th>वर्ग</th>
            <th>ग्राहक / सप्लायरको नाम</th>
            <th>ठेगाना / फोन</th>
            <th>PAN</th>
            <th style="text-align: right;">सुरुवाती बाँकी</th>
            <th style="text-align: right;">हालको खुद बाँकी</th>
          </tr>
        </thead>
        <tbody>
          ${parties.map((p) => {
            const isSupp = (p.partyType || p.type) === 'SUPPLIER';
            const curBal = p.currentBalance ?? p.openingBalance;
            return `<tr>
              <td><span class="badge ${isSupp ? 'badge-supp' : 'badge-cust'}">${isSupp ? 'सप्लायर' : 'ग्राहक'}</span></td>
              <td><b>${p.customerCategory || 'OTHER'}</b></td>
              <td><b>${p.name}</b></td>
              <td>${p.address || '-'} / ${p.phone || '-'}</td>
              <td>${p.panNo || '-'}</td>
              <td style="text-align: right; font-family: monospace;">रु. ${(p.openingBalance || 0).toLocaleString('ne-NP')}</td>
              <td style="text-align: right; font-family: monospace; font-weight: 800; color: ${curBal > 0 ? (isSupp ? '#be123c' : '#047857') : '#334155'};">
                रु. ${curBal.toLocaleString('ne-NP')}
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>

    <!-- ITEMS TABLE -->
    <div id="tab-items" class="card-panel tab-content" style="display: none;">
      <h3 style="margin-bottom: 12px;">📦 सामान मौज्दात सूची (Inventory)</h3>
      <table id="itemsTable">
        <thead>
          <tr>
            <th>कोड</th>
            <th>सामानको नाम</th>
            <th>वर्ग</th>
            <th style="text-align: right;">खरिद मूल्य</th>
            <th style="text-align: right;">बिक्री मूल्य</th>
            <th style="text-align: right;">मौज्दात (Stock)</th>
            <th>इकाई</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((i) => `<tr>
            <td><code>${i.code}</code></td>
            <td><b>${i.nameNe || i.nameEn}</b></td>
            <td>${i.category}</td>
            <td style="text-align: right;">रु. ${(i.purchasePrice || 0).toLocaleString('ne-NP')}</td>
            <td style="text-align: right;">रु. ${(i.sellingPrice || 0).toLocaleString('ne-NP')}</td>
            <td style="text-align: right; font-weight: 800; color: ${i.currentStock <= i.minStockAlert ? '#be123c' : '#047857'};">
              ${i.currentStock} ${i.unit}
            </td>
            <td>${i.unit}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>

    <!-- INVOICES TABLE -->
    <div id="tab-invoices" class="card-panel tab-content" style="display: none;">
      <h3 style="margin-bottom: 12px;">📄 बिक्री बिल सूची (Sales Invoices)</h3>
      <table id="invoicesTable">
        <thead>
          <tr>
            <th>बिल प्रकार</th>
            <th>बिल नं.</th>
            <th>मिति (BS)</th>
            <th>ग्राहकको नाम</th>
            <th>भुक्तानी</th>
            <th style="text-align: right;">जम्मा रकम</th>
          </tr>
        </thead>
        <tbody>
          ${invoices.map((inv) => `<tr>
            <td><span class="badge badge-cust">${inv.billType}</span></td>
            <td><b>${inv.invoiceNo}</b></td>
            <td>${inv.dateBs}</td>
            <td><b>${inv.customerName}</b></td>
            <td>${inv.paymentMode}</td>
            <td style="text-align: right; font-weight: 800; font-family: monospace;">रु. ${inv.grandTotal.toLocaleString('ne-NP')}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>

    <!-- PURCHASES TABLE -->
    <div id="tab-purchases" class="card-panel tab-content" style="display: none;">
      <h3 style="margin-bottom: 12px;">🛒 खरिद विवरण (Purchases)</h3>
      <table id="purchasesTable">
        <thead>
          <tr>
            <th>खरीद बिल नं.</th>
            <th>मिति (BS)</th>
            <th>सप्लायरको नाम</th>
            <th>सामानहरू</th>
            <th style="text-align: right;">कुल रकम</th>
          </tr>
        </thead>
        <tbody>
          ${purchases.map((pur) => `<tr>
            <td><code>${pur.purchaseBillNo || pur.id.slice(-6)}</code></td>
            <td>${pur.dateBs}</td>
            <td><b>${pur.supplierName}</b></td>
            <td>${pur.itemsSummary || '-'}</td>
            <td style="text-align: right; font-weight: 800; font-family: monospace;">रु. ${pur.grandTotal.toLocaleString('ne-NP')}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>

  </div>

  <script>
    function switchTab(tabId) {
      document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
      document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
      document.getElementById('tab-' + tabId).style.display = 'block';
      event.target.classList.add('active');
    }

    function filterTables() {
      var query = document.getElementById('searchInput').value.toLowerCase();
      var activeTab = document.querySelector('.tab-content:not([style*="display: none"])');
      if (!activeTab) return;
      var rows = activeTab.querySelectorAll('tbody tr');
      rows.forEach(function(row) {
        var text = row.textContent.toLowerCase();
        row.style.display = text.indexOf(query) > -1 ? '' : 'none';
      });
    }
  </script>
</body>
</html>`;
};

// Download File Helper
export const triggerDownloadFile = (content: string, fileName: string, mimeType: string) => {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
