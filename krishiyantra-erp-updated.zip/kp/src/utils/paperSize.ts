// Global paper size (A4 / A5) for every print & PDF in the app.
import { useEffect, useState } from 'react';

export type PaperSize = 'A4' | 'A5';
const KEY = 'ky-paper-size';
const EVENT = 'ky-paper-size-changed';

export function getPaperSize(): PaperSize {
  try {
    return localStorage.getItem(KEY) === 'A5' ? 'A5' : 'A4';
  } catch {
    return 'A4';
  }
}

/** <html data-paper> + @page rule: browser print uses the selected paper */
export function applyPaperSize(size: PaperSize = getPaperSize()) {
  if (typeof document === 'undefined') return;
  document.documentElement.setAttribute('data-paper', size.toLowerCase());
  let el = document.getElementById('ky-paper-style') as HTMLStyleElement | null;
  if (!el) {
    el = document.createElement('style');
    el.id = 'ky-paper-style';
    document.head.appendChild(el);
  }
  // Print width is fluid; A5 just scales the (A4-designed) layout so it fits one page.
  el.textContent = `
    @media print {
      @page { size: ${size} portrait; margin: ${size === 'A5' ? '7mm' : '10mm'}; }
      html[data-paper="a5"] #ky-print-host .ky-print-doc > * { zoom: 0.78; }
    }`;
}

export function setPaperSize(size: PaperSize) {
  try {
    localStorage.setItem(KEY, size);
  } catch {}
  applyPaperSize(size);
  window.dispatchEvent(new Event(EVENT));
}

export function usePaperSize(): PaperSize {
  const [size, setSize] = useState<PaperSize>(getPaperSize());
  useEffect(() => {
    const h = () => setSize(getPaperSize());
    window.addEventListener(EVENT, h);
    return () => window.removeEventListener(EVENT, h);
  }, []);
  return size;
}

// ---- Letterhead: print the designed header, or leave blank space for pre-printed letterhead paper ----
export type LetterheadMode = 'PRINT' | 'PREPRINTED';
const LH_KEY = 'ky-letterhead-mode';
const LH_EVENT = 'ky-letterhead-changed';
export function getLetterheadMode(): LetterheadMode {
  try { return localStorage.getItem(LH_KEY) === 'PREPRINTED' ? 'PREPRINTED' : 'PRINT'; } catch { return 'PRINT'; }
}
export function setLetterheadMode(m: LetterheadMode) {
  try { localStorage.setItem(LH_KEY, m); } catch {}
  window.dispatchEvent(new Event(LH_EVENT));
}
export function useLetterheadMode(): LetterheadMode {
  const [m, setM] = useState<LetterheadMode>(getLetterheadMode());
  useEffect(() => {
    const h = () => setM(getLetterheadMode());
    window.addEventListener(LH_EVENT, h);
    return () => window.removeEventListener(LH_EVENT, h);
  }, []);
  return m;
}
