// Sparrow SMS Integration Helper
// This acts as a placeholder for real API calls to Sparrow SMS
// Integration: https://sparrowsms.com/

export interface SmsResponse {
  success: boolean;
  message?: string;
  smsId?: string;
}

/**
 * Sends an SMS using the Sparrow SMS API integration
 */
export const sendSmsReceipt = async (
  mobileNumber: string,
  message: string
): Promise<SmsResponse> => {
  // IMPORTANT: For production, you must use a server-side proxy route to 
  // protect your API Token. Never include API tokens in client-side code.
  
  console.log(`[SMS INTEGRATION] Sending message to ${mobileNumber}: ${message}`);
  
  // Placeholder API Call
  // const response = await fetch('https://api.sparrowsms.com/v2/sms/', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify({
  //     token: 'YOUR_SPARROW_SMS_API_TOKEN',
  //     from: 'Demo',
  //     to: mobileNumber,
  //     text: message
  //   })
  // });

  // Mock response for now
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true, smsId: 'mock-sms-id-123' });
    }, 1000);
  });
};
