import type { Item, Invoice, InvoiceItem, PurchaseRecord, RawMaterial } from '../types';
import { normBs, round2 } from './accountingEngine';

export type CostMethod = 'FIFO' | 'LIFO' | 'AVG';

export interface CostLayer {
  qty: number;
  cost: number; // per primary unit
  dateBs: string;
  source: 'OPENING' | 'PURCHASE' | 'UNLAYERED';
  ref?: string;
}

export interface ItemCosting {
  item: Item;
  onHand: number;
  value: number;
  avgCost: number;
  layers: CostLayer[];
  cogs: number; // cost of goods sold inside the period
  qtySold: number; // qty sold inside the period (primary unit)
  revenue: number; // sales amount inside the period
  shortfallQty: number; // sold more than purchase layers could cover
  adjustedQty: number; // +ve: stock exists that has no purchase layer (production/adjustment); -ve: written off
}

const ratioOf = (it?: Item) => (it && it.secondaryUnitRatio && it.secondaryUnitRatio > 1 ? it.secondaryUnitRatio : 1);

export const primaryQty = (line: InvoiceItem, item?: Item): number => {
  if (line.primaryQtyEquivalent !== undefined && line.primaryQtyEquivalent !== null) return line.primaryQtyEquivalent;
  const r = ratioOf(item);
  return line.unitMode === 'SECONDARY' && r > 1 ? line.quantity / r : line.quantity;
};

interface Ev { date: string; order: number; qty: number; cost: number; ref: string; amount: number }

const EPS = 0.0001;

export const computeStockCosting = (
  items: Item[],
  purchases: PurchaseRecord[],
  invoices: Invoice[],
  method: CostMethod,
  period?: { from: string; to: string }
): { rows: ItemCosting[]; totals: { value: number; cogs: number; revenue: number; qtySold: number }; purchasesWithoutDetail: number } => {
  const itemMap = new Map(items.map((i) => [i.id, i]));
  const events = new Map<string, Ev[]>();
  const push = (id: string, e: Ev) => {
    const a = events.get(id);
    if (a) a.push(e); else events.set(id, [e]);
  };

  let purchasesWithoutDetail = 0;
  purchases.forEach((p) => {
    const d = normBs(p.dateBs);
    if (!d) return;
    if (!p.items || p.items.length === 0) { purchasesWithoutDetail++; return; }
    p.items.forEach((l) => {
      const it = itemMap.get(l.itemId);
      if (!it) return;
      const q = primaryQty(l, it);
      if (q <= 0) return;
      const total = l.amount > 0 ? l.amount : l.rate * l.quantity;
      push(it.id, { date: d, order: 0, qty: q, cost: total / q, ref: p.purchaseBillNo, amount: 0 });
    });
  });

  invoices.forEach((inv) => {
    if (inv.status !== 'ACTIVE' || inv.stockDeducted === false) return;
    const d = normBs(inv.dateBs);
    if (!d) return;
    inv.items.forEach((l) => {
      const it = itemMap.get(l.itemId);
      if (!it) return;
      const q = primaryQty(l, it);
      if (q <= 0) return;
      push(it.id, { date: d, order: 1, qty: q, cost: 0, ref: inv.invoiceNo, amount: l.amount || 0 });
    });
  });

  const rows: ItemCosting[] = items.map((item) => {
    const evs = (events.get(item.id) || []).slice().sort((a, b) => (a.date === b.date ? a.order - b.order : a.date.localeCompare(b.date)));
    let layers: CostLayer[] = [];
    if ((item.openingStock || 0) > 0) {
      layers.push({ qty: item.openingStock, cost: item.purchasePrice || 0, dateBs: '0000-00-00', source: 'OPENING' });
    }
    let lastCost = item.purchasePrice || 0;
    let cogs = 0, qtySold = 0, revenue = 0, shortfall = 0;

    const mergeAvg = () => {
      const q = layers.reduce((s, l) => s + l.qty, 0);
      const v = layers.reduce((s, l) => s + l.qty * l.cost, 0);
      layers = q > EPS ? [{ qty: q, cost: v / q, dateBs: layers[0]?.dateBs || '', source: 'PURCHASE' }] : [];
    };

    // consume qty from layers per method; returns cost of what was consumed + qty not covered
    const consume = (qty: number): { cost: number; missing: number } => {
      let need = qty, cost = 0;
      if (method === 'AVG') mergeAvg();
      while (need > EPS && layers.length > 0) {
        const idx = method === 'LIFO' ? layers.length - 1 : 0;
        const l = layers[idx];
        const take = Math.min(l.qty, need);
        cost += take * l.cost;
        l.qty -= take;
        need -= take;
        if (l.qty <= EPS) layers.splice(idx, 1);
      }
      return { cost, missing: Math.max(0, need) };
    };

    evs.forEach((e) => {
      if (e.order === 0) {
        layers.push({ qty: e.qty, cost: e.cost, dateBs: e.date, source: 'PURCHASE', ref: e.ref });
        lastCost = e.cost;
        if (method === 'AVG') mergeAvg();
      } else {
        const r = consume(e.qty);
        const c = r.cost + r.missing * lastCost; // uncovered qty is costed at last known cost
        if (r.missing > EPS) shortfall += r.missing;
        const inPeriod = !period || (e.date >= period.from && e.date <= period.to);
        if (inPeriod) { cogs += c; qtySold += e.qty; revenue += e.amount; }
      }
    });

    // Reconcile with the real stock register (production, manual adjustments, returns are not in bills)
    const remaining = layers.reduce((s, l) => s + l.qty, 0);
    const diff = (item.currentStock || 0) - remaining;
    let adjusted = 0;
    if (diff > EPS) {
      layers.push({ qty: diff, cost: lastCost, dateBs: '9999-99-99', source: 'UNLAYERED' });
      if (method === 'AVG') mergeAvg();
      adjusted = diff;
    } else if (diff < -EPS) {
      consume(-diff);
      adjusted = diff;
    }

    const onHand = layers.reduce((s, l) => s + l.qty, 0);
    const value = round2(layers.reduce((s, l) => s + l.qty * l.cost, 0));
    return {
      item, onHand: round2(onHand), value, avgCost: onHand > EPS ? round2(value / onHand) : round2(lastCost),
      layers: layers.map((l) => ({ ...l, qty: round2(l.qty), cost: round2(l.cost) })),
      cogs: round2(cogs), qtySold: round2(qtySold), revenue: round2(revenue),
      shortfallQty: round2(shortfall), adjustedQty: round2(adjusted)
    };
  });

  const totals = rows.reduce(
    (t, r) => ({ value: round2(t.value + r.value), cogs: round2(t.cogs + r.cogs), revenue: round2(t.revenue + r.revenue), qtySold: round2(t.qtySold + r.qtySold) }),
    { value: 0, cogs: 0, revenue: 0, qtySold: 0 }
  );
  return { rows, totals, purchasesWithoutDetail };
};

// ----------------------------------------------------------------------------
// Reorder suggestions
// ----------------------------------------------------------------------------
export type ReorderStatus = 'OUT' | 'BELOW_MIN' | 'REORDER' | 'OK';

export interface ReorderRow {
  id: string;
  kind: 'ITEM' | 'RAW';
  code: string;
  name: string;
  unit: string;
  current: number;
  minLevel: number;
  avgDaily: number;
  daysCover: number | null;
  reorderPoint: number;
  suggestQty: number;
  supplier: string;
  lastRate: number;
  lastPurchaseDateBs: string;
  estCost: number;
  status: ReorderStatus;
}

export interface ReorderParams {
  lookbackDays: number; // sales history window
  leadTimeDays: number; // supplier delivery time
  coverDays: number; // how many days of sales one order should cover (after lead time)
}

export const computeReorder = (
  items: Item[],
  rawMaterials: RawMaterial[],
  purchases: PurchaseRecord[],
  invoices: Invoice[],
  params: ReorderParams,
  now: Date = new Date()
): ReorderRow[] => {
  const itemMap = new Map(items.map((i) => [i.id, i]));
  const since = now.getTime() - params.lookbackDays * 86400000;
  const sold = new Map<string, number>();
  invoices.forEach((inv) => {
    if (inv.status !== 'ACTIVE') return;
    const t = new Date(inv.dateAd || '').getTime();
    if (!Number.isFinite(t) || t < since || t > now.getTime() + 86400000) return;
    inv.items.forEach((l) => {
      const it = itemMap.get(l.itemId);
      if (!it) return;
      sold.set(it.id, (sold.get(it.id) || 0) + primaryQty(l, it));
    });
  });

  // last supplier / rate per item
  const last = new Map<string, { date: string; supplier: string; rate: number }>();
  purchases.forEach((p) => {
    const d = normBs(p.dateBs);
    (p.items || []).forEach((l) => {
      const it = itemMap.get(l.itemId);
      if (!it) return;
      const q = primaryQty(l, it);
      if (q <= 0) return;
      const cur = last.get(it.id);
      if (!cur || d >= cur.date) {
        last.set(it.id, { date: d, supplier: p.supplierName, rate: (l.amount > 0 ? l.amount : l.rate * l.quantity) / q });
      }
    });
  });

  const out: ReorderRow[] = [];
  items.forEach((it) => {
    const cur = it.currentStock || 0;
    const min = it.minStockAlert || 0;
    const avgDaily = (sold.get(it.id) || 0) / Math.max(1, params.lookbackDays);
    const reorderPoint = avgDaily * params.leadTimeDays + min;
    const target = avgDaily * (params.leadTimeDays + params.coverDays) + min;
    const status: ReorderStatus = cur <= 0 && (min > 0 || avgDaily > 0) ? 'OUT' : cur <= min && min > 0 ? 'BELOW_MIN' : (avgDaily > 0 || min > 0) && cur <= reorderPoint ? 'REORDER' : 'OK';
    const suggest = status === 'OK' ? 0 : Math.max(0, Math.ceil(target - cur));
    const lp = last.get(it.id);
    const rate = lp?.rate ?? it.purchasePrice ?? 0;
    out.push({
      id: it.id, kind: 'ITEM', code: it.code, name: it.nameNe || it.nameEn, unit: it.primaryUnit || it.unit,
      current: round2(cur), minLevel: min, avgDaily: round2(avgDaily), daysCover: avgDaily > 0 ? round2(cur / avgDaily) : null,
      reorderPoint: Math.ceil(reorderPoint), suggestQty: suggest, supplier: lp?.supplier || '', lastRate: round2(rate),
      lastPurchaseDateBs: lp?.date || '', estCost: round2(suggest * rate), status
    });
  });

  rawMaterials.forEach((m) => {
    const cur = m.currentStock || 0;
    const min = m.minStockAlert || 0;
    const status: ReorderStatus = cur <= 0 && min > 0 ? 'OUT' : min > 0 && cur <= min ? 'BELOW_MIN' : 'OK';
    const suggest = status === 'OK' ? 0 : Math.max(0, Math.ceil(min * 2 - cur));
    out.push({
      id: m.id, kind: 'RAW', code: m.code, name: m.nameNe || m.nameEn, unit: m.unit, current: round2(cur), minLevel: min,
      avgDaily: 0, daysCover: null, reorderPoint: min, suggestQty: suggest, supplier: m.supplierName || '',
      lastRate: round2(m.unitCostPrice || 0), lastPurchaseDateBs: m.lastPurchasedDateBs || '',
      estCost: round2(suggest * (m.unitCostPrice || 0)), status
    });
  });

  const rank: Record<ReorderStatus, number> = { OUT: 0, BELOW_MIN: 1, REORDER: 2, OK: 3 };
  return out.sort((a, b) => rank[a.status] - rank[b.status] || (a.daysCover ?? 1e9) - (b.daysCover ?? 1e9));
};
