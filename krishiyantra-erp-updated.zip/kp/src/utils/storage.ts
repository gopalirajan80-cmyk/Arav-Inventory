// LocalStorage & JSON Backup Engine for KrishiYantra ERP
import {
  Item,
  Invoice,
  PurchaseRecord,
  Party,
  Employee,
  AttendanceRecord,
  CompanyProfile,
  EmployeeLedgerEntry,
  DailyCashRecord,
  BankAccount,
  PartyTransaction,
  RawMaterial,
  ProductionBatch,
  CompanyAccount,
  AuditLogEntry,
  Machine
} from '../types';

export const DEFAULT_BANK_ACCOUNTS: BankAccount[] = [
  {
    id: 'bank-1',
    bankName: 'कृषि विकास बैंक (Agricultural Dev Bank - ADBL)',
    accountNumber: '०२१०१०१२३४५६७८९०',
    accountHolder: 'नेपाल कृषि यन्त्र तथा औजार सप्लायर्स',
    branch: 'भरतपुर, चितवन',
    openingBalance: 175000,
    currentBalance: 175000
  },
  {
    id: 'bank-2',
    bankName: 'ग्लोबल आइएमई बैंक (Global IME Bank)',
    accountNumber: '०१२३४५६७८९०१२३',
    accountHolder: 'नेपाल कृषि यन्त्र तथा औजार सप्लायर्स',
    branch: 'नारायणगढ, चितवन',
    openingBalance: 240000,
    currentBalance: 240000
  },
  {
    id: 'bank-3',
    bankName: 'नबिल बैंक (Nabil Bank Limited)',
    accountNumber: '०८९००१२३४५६७८',
    accountHolder: 'नेपाल कृषि यन्त्र तथा औजार सप्लायर्स',
    branch: 'तीनकुने, काठमाडौँ',
    openingBalance: 95000,
    currentBalance: 95000
  }
];

export const DEFAULT_ATTENDANCE_GROUPS = [
  {
    id: 'grp-workshop',
    nameNe: 'वर्कसप तथा मर्मत समूह',
    nameEn: 'Workshop & Maintenance Team',
    supervisorEmpId: 'emp-1',
    supervisorName: 'रामचन्द्र सिलवाल',
    color: '#0284c7'
  },
  {
    id: 'grp-counter',
    nameNe: 'काउन्टर तथा बिक्री समूह',
    nameEn: 'Counter & Sales Team',
    supervisorEmpId: 'emp-2',
    supervisorName: 'सिता अधिकारी',
    color: '#059669'
  },
  {
    id: 'grp-store',
    nameNe: 'गोदाम तथा ढुवानी समूह',
    nameEn: 'Warehouse & Logistics Team',
    supervisorEmpId: 'emp-3',
    supervisorName: 'हरि प्रसाद ढकाल',
    color: '#7c3aed'
  }
];

export const DEFAULT_COMPANY: CompanyProfile = {
  name: 'नेपाल कृषि यन्त्र तथा औजार सप्लायर्स (Nepal Krishi Yantra Suppliers)',
  panVatNo: '602345891',
  address: 'भरतपुर-१०, चितवन / तीनकुने, काठमाडौँ',
  phone: '०५६-५२०१२३, ९८५५०१२३४५',
  email: 'info@krishiyantra.com.np',
  tagline: 'आधुनिक कृषि औजार तथा मेसिनरीको भरपर्दो केन्द्र',
  vatBillPrefix: 'TI',
  nonVatBillPrefix: 'NV',
  fiscalYear: '081/82',
  bankAccounts: DEFAULT_BANK_ACCOUNTS,
  shiftStartTime: '10:00 AM',
  shiftEndTime: '05:00 PM',
  lateGraceMinutes: 15,
  autoSetShiftTime: true,
  workplaceLatitude: 27.7172,
  workplaceLongitude: 85.3240,
  workplaceRadiusMeters: 200,
  workplaceLocationLabel: 'कृषियन्त्र मुख्य शोरुम तथा वर्कसप',
  enforceGpsLocation: true,
  attendanceGroups: DEFAULT_ATTENDANCE_GROUPS
};

export const SAMPLE_AGRICULTURE_ITEMS: Item[] = [
  {
    id: 'item-1',
    code: 'KY-PT01',
    nameEn: 'Power Tiller 7HP Diesel (Electric Start)',
    nameNe: 'पावर टिलर ७ एचपी डिजेल (इलेक्ट्रिक स्टार्ट)',
    category: 'TRACTOR_TILLER',
    unit: 'Set',
    purchasePrice: 110000,
    sellingPrice: 128000,
    openingStock: 4, // पुरानो सुरुवाती स्टक
    currentStock: 6,
    minStockAlert: 2,
    isVatExempt: false,
    hsnCode: '8432.29'
  },
  {
    id: 'item-2',
    code: 'KY-WP02',
    nameEn: 'Submersible Water Pump 1.5HP (Copper Rotor)',
    nameNe: 'सबमर्सिबल पानी पम्प १.५ एचपी (कपर रोटर)',
    category: 'IRRIGATION_PUMP',
    unit: 'Pcs',
    purchasePrice: 14000,
    sellingPrice: 17500,
    openingStock: 10,
    currentStock: 15,
    minStockAlert: 4,
    isVatExempt: false,
    hsnCode: '8413.70'
  },
  {
    id: 'item-3',
    code: 'KY-SP03',
    nameEn: 'Knapsack 2-in-1 Battery & Manual Sprayer 16L',
    nameNe: 'ब्याट्री तथा म्यानुअल २-इन-१ स्प्रेयर १६ लिटर',
    category: 'SPRAYER_TOOLS',
    unit: 'Pcs',
    purchasePrice: 3800,
    sellingPrice: 4700,
    openingStock: 20,
    currentStock: 35,
    minStockAlert: 8,
    isVatExempt: false,
    hsnCode: '8424.81'
  },
  {
    id: 'item-4',
    code: 'KY-BL04',
    nameEn: 'Rotary Tiller Curve Blades (18 Pcs Set)',
    nameNe: 'रोटाभेटर कभ्र्ड ब्लेड सेट (१८ थान)',
    category: 'SPARE_PARTS',
    unit: 'Set',
    purchasePrice: 4200,
    sellingPrice: 5800,
    openingStock: 15,
    currentStock: 20,
    minStockAlert: 5,
    isVatExempt: false,
    hsnCode: '8432.90'
  },
  {
    id: 'item-5',
    code: 'KY-DP05',
    nameEn: 'Drip Irrigation Pipe 16mm (Roll 100M)',
    nameNe: 'ड्रिप इरिगेसन पाइप १६ एमएम (१०० मिटर रोल)',
    category: 'IRRIGATION_PUMP',
    unit: 'Roll',
    purchasePrice: 2200,
    sellingPrice: 2850,
    openingStock: 25,
    currentStock: 40,
    minStockAlert: 10,
    isVatExempt: false,
    hsnCode: '3917.39'
  },
  {
    id: 'item-6',
    code: 'KY-SD06',
    nameEn: 'Certified Hybrid Paddy Seed (Radha-4) 10Kg',
    nameNe: 'प्रमाणित हाइब्रिड धानको बिउ (राधा-४) १० केजी',
    category: 'SEEDS_AGRO',
    unit: 'Bag',
    purchasePrice: 850,
    sellingPrice: 1050,
    openingStock: 40,
    currentStock: 60,
    minStockAlert: 15,
    isVatExempt: true,
    hsnCode: '1006.10'
  },
  {
    id: 'item-7',
    code: 'KY-FR07',
    nameEn: 'Subsidized Urea Fertilizer 50Kg Bag',
    nameNe: 'अनुदानित युरिया रासायनिक मल (५० केजी बोरा)',
    category: 'FERTILIZER',
    unit: 'Bag',
    purchasePrice: 850,
    sellingPrice: 950,
    openingStock: 50,
    currentStock: 80,
    minStockAlert: 20,
    isVatExempt: true,
    hsnCode: '3102.10'
  },
  {
    id: 'item-8',
    code: 'KY-PE08',
    nameEn: 'Bio-Fungicide & Crop Booster (1 Litre)',
    nameNe: 'जैविक ढुसीनाशक तथा बाली टोनिक (१ लिटर)',
    category: 'PESTICIDES',
    unit: 'Bottle',
    purchasePrice: 1100,
    sellingPrice: 1450,
    openingStock: 15,
    currentStock: 25,
    minStockAlert: 5,
    isVatExempt: false,
    hsnCode: '3808.92'
  },
  {
    id: 'item-9',
    code: 'KY-LF09',
    nameEn: 'Nutritious Dairy Cattle Mineral Feed 25Kg',
    nameNe: 'दुधालु गाईभैँसीको पौष्टिक दाना/खनिज (२५ केजी)',
    category: 'LIVESTOCK_FEED',
    unit: 'Bag',
    purchasePrice: 1800,
    sellingPrice: 2150,
    openingStock: 20,
    currentStock: 30,
    minStockAlert: 8,
    isVatExempt: true,
    hsnCode: '2309.90'
  }
];

export const SAMPLE_EMPLOYEES: Employee[] = [
  {
    id: 'emp-1',
    name: 'रामचन्द्र सिलवाल (Ram Chandra Silwal)',
    role: 'मेसिनरी प्राविधिक / सर्भिसिङ (Technician)',
    phone: '९८५५०१२३४१',
    salaryMonthly: 32000,
    wageType: 'MONTHLY',
    dailyWageRate: 1200,
    joinedDateBs: '2080-04-01',
    openingDue: 1500,
    groupId: 'grp-workshop',
    groupName: 'वर्कसप तथा मर्मत समूह',
    isGroupSupervisor: true,
    supervisorAuthPin: '1122',
    fingerprintEnrolled: true,
    fingerprintHash: 'bio_hash_rcs_01',
    enrolledFingerName: 'दायाँ चोरी औँला (Right Index)',
    fingerprintEnrolledDateBs: '2081-01-05'
  },
  {
    id: 'emp-2',
    name: 'सिता अधिकारी (Sita Adhikari)',
    role: 'लेखा तथा बिलिङ अपरेटर (Billing & Cashier)',
    phone: '९८४५०९८७६५',
    salaryMonthly: 28000,
    wageType: 'MONTHLY',
    dailyWageRate: 1000,
    joinedDateBs: '2080-06-15',
    openingDue: 0,
    groupId: 'grp-counter',
    groupName: 'काउन्टर तथा बिक्री समूह',
    isGroupSupervisor: true,
    supervisorAuthPin: '2233',
    fingerprintEnrolled: true,
    fingerprintHash: 'bio_hash_sita_02',
    enrolledFingerName: 'दायाँ चोरी औँला (Right Index)',
    fingerprintEnrolledDateBs: '2081-01-10'
  },
  {
    id: 'emp-3',
    name: 'हरि प्रसाद ढकाल (Hari Prasad Dhakal)',
    role: 'स्टोर तथा ढुवानी व्यवस्थापक (Store Keeper)',
    phone: '९८१२३४५६७८',
    salaryMonthly: 24000,
    wageType: 'DAILY', // दैनिक ज्याला / दैनिक हिसाबमा काम गर्ने
    dailyWageRate: 900,
    joinedDateBs: '2081-01-10',
    openingDue: 3000,
    groupId: 'grp-store',
    groupName: 'गोदाम तथा ढुवानी समूह',
    isGroupSupervisor: true,
    supervisorAuthPin: '3344',
    fingerprintEnrolled: true,
    fingerprintHash: 'bio_hash_hari_03',
    enrolledFingerName: 'दायाँ बुढी औँला (Right Thumb)',
    fingerprintEnrolledDateBs: '2081-02-01'
  },
  {
    id: 'emp-4',
    name: 'दिल बहादुर महतो (Dil Bahadur Mahato)',
    role: 'दैनिक ज्याला मजदुर / लोड-अनलोड (Helper)',
    phone: '९८२३४५६७८९',
    salaryMonthly: 20000,
    wageType: 'DAILY', // दैनिक ज्याला
    dailyWageRate: 800,
    joinedDateBs: '2081-03-01',
    openingDue: 500,
    groupId: 'grp-store',
    groupName: 'गोदाम तथा ढुवानी समूह',
    isGroupSupervisor: false,
    fingerprintEnrolled: false
  }
];

export const SAMPLE_PARTIES: Party[] = [
  {
    id: 'pty-1',
    name: 'चितवन एग्रो फार्म प्रा.लि. (Chitwan Agro Farm)',
    panNo: '601245892',
    address: 'गीतानगर, भरतपुर-०६',
    phone: '९८५५०११२२३',
    partyType: 'CUSTOMER',
    openingBalance: 14500,
    currentBalance: 14500
  },
  {
    id: 'pty-2',
    name: 'प्रगतिशिल कृषि सहकारी संस्था (Pragatisheel Coop)',
    panNo: '602334455',
    address: 'बसन्तपुर, माडी-०३',
    phone: '९८४५०१२३९९',
    partyType: 'CUSTOMER',
    openingBalance: 8200,
    currentBalance: 8200
  },
  {
    id: 'pty-3',
    name: 'कालिका आधुनिक फलफूल तथा तरकारी फार्म',
    panNo: '603445566',
    address: 'खैरहनी-०८, चितवन',
    phone: '९८५५०२३४५६',
    partyType: 'CUSTOMER',
    openingBalance: 19800,
    currentBalance: 19800
  },
  {
    id: 'pty-4',
    name: 'रत्ननगर उन्नत बिउबिजन भण्डार',
    panNo: '604556677',
    address: 'टाँडी, रत्ननगर-०२',
    phone: '९८४५०३४५६७',
    partyType: 'CUSTOMER',
    openingBalance: 11200,
    currentBalance: 11200
  },
  {
    id: 'pty-5',
    name: 'हिमालयन अर्गानिक टी एण्ड एग्रो',
    panNo: '605667788',
    address: 'नयाँबजार, पोखरा-०९',
    phone: '९८५६०४५६७८',
    partyType: 'CUSTOMER',
    openingBalance: 24500,
    currentBalance: 24500
  },
  {
    id: 'pty-6',
    name: 'काठमाडौँ भ्याली हाइटेक नर्सरी',
    panNo: '606778899',
    address: 'कोटेश्वर, काठमाडौँ-३२',
    phone: '९८४१२३४५६७',
    partyType: 'CUSTOMER',
    openingBalance: 16000,
    currentBalance: 16000
  },
  {
    id: 'pty-7',
    name: 'मकवानपुर डेरी तथा पशुपालन केन्द्र',
    panNo: '607889900',
    address: 'हेटौँडा-०४, मकवानपुर',
    phone: '९८५५०५६७८९',
    partyType: 'CUSTOMER',
    openingBalance: 7500,
    currentBalance: 7500
  },
  {
    id: 'pty-8',
    name: 'नेपाल एग्रो टूल्स इम्पोर्टर्स (Supplier)',
    panNo: '600123987',
    address: 'वीरगञ्ज-१०, पर्सा',
    phone: '०५१-५२०९९९',
    partyType: 'SUPPLIER',
    type: 'SUPPLIER',
    openingBalance: 45000,
    currentBalance: 45000
  },
  {
    id: 'pty-9',
    name: 'नेपाल स्टिल एण्ड एग्रो इन्डस्ट्रिज',
    panNo: '601987654',
    address: 'सिमरा, बारा',
    phone: '०५३-५२११००',
    partyType: 'SUPPLIER',
    type: 'SUPPLIER',
    openingBalance: 84750,
    currentBalance: 84750
  }
];

export const SAMPLE_PARTY_TRANSACTIONS: PartyTransaction[] = [
  {
    id: 'ptx-1',
    partyId: 'pty-1',
    partyName: 'चितवन एग्रो फार्म प्रा.लि.',
    partyAddress: 'गीतानगर, भरतपुर-०६',
    dateBs: '2081-11-02',
    dateAd: '2025-02-14',
    type: 'COLLECTION_FROM_CUSTOMER',
    amount: 5000,
    paymentMode: 'BANK',
    bankAccountId: 'bank-1',
    bankName: 'कृषि विकास बैंक (ADBL)',
    bankAccountNo: '०२१०१०१२३४५६७८९०',
    referenceNo: 'FONEPAY-891234',
    notes: 'ग्राहकले कृषि विकास बैंकमा खाता ट्रान्सफर गरी बाँकी चुक्ता गरेको'
  }
];

export const SAMPLE_DAILY_CASH: DailyCashRecord = {
  id: 'cash-today',
  dateBs: '2081-11-05',
  openingCash: 5000, // काउन्टर सुरु गर्दा ५,००० नगद
  totalCashSales: 0,
  totalBankTransfers: 0,
  totalAdvancesGiven: 0,
  closingCashInHand: 5000
};

export const SAMPLE_RAW_MATERIALS: RawMaterial[] = [
  {
    id: 'rm-1',
    code: 'RM-MS01',
    nameNe: 'स्टिल पाता / एमएस सीट (MS Steel Sheet 2mm)',
    nameEn: 'MS Steel Sheet 2mm Heavy Grade',
    category: 'STEEL_METALS',
    unit: 'Kg',
    currentStock: 450,
    unitCostPrice: 120,
    minStockAlert: 100,
    supplierName: 'नेपाल स्टिल एण्ड एग्रो इन्डस्ट्रिज',
    lastPurchasedDateBs: '2081-11-01'
  },
  {
    id: 'rm-2',
    code: 'RM-ENG02',
    nameNe: '७ एचपी डिजेल इन्जिन एसेम्ब्ली (7HP Diesel Engine)',
    nameEn: '7HP Diesel Engine Core Assembly',
    category: 'ENGINES',
    unit: 'Pc',
    currentStock: 18,
    unitCostPrice: 22000,
    minStockAlert: 5,
    supplierName: 'नेपाल एग्रो टूल्स इम्पोर्टर्स',
    lastPurchasedDateBs: '2081-10-25'
  },
  {
    id: 'rm-3',
    code: 'RM-PP03',
    nameNe: 'इरिगेसन ग्याल्भानाइज्ड पाइप २ इन्च (HDPE Heavy Pipe)',
    nameEn: 'HDPE Galvanized Heavy Pipe 2 Inch',
    category: 'HARDWARE_PARTS',
    unit: 'Meter',
    currentStock: 320,
    unitCostPrice: 380,
    minStockAlert: 50,
    supplierName: 'सगरमाथा पाइप्स प्रा.लि.',
    lastPurchasedDateBs: '2081-11-03'
  },
  {
    id: 'rm-4',
    code: 'RM-BLD04',
    nameNe: 'रोटाभेटर साफ्ट तथा बेयरिङ सेट (Bearing Shaft Set)',
    nameEn: 'Rotavator Shaft & Ball Bearing Heavy Set',
    category: 'HARDWARE_PARTS',
    unit: 'Set',
    currentStock: 35,
    unitCostPrice: 1850,
    minStockAlert: 10,
    supplierName: 'नेपाल एग्रो टूल्स इम्पोर्टर्स',
    lastPurchasedDateBs: '2081-10-28'
  },
  {
    id: 'rm-5',
    code: 'RM-PK05',
    nameNe: 'काठको भारी प्याकिङ बाकस (Heavy Wooden Crate)',
    nameEn: 'Heavy Duty Wooden Packaging Crate',
    category: 'PLASTIC_PACK',
    unit: 'Pc',
    currentStock: 60,
    unitCostPrice: 850,
    minStockAlert: 15,
    supplierName: 'चितवन काठ उद्योग',
    lastPurchasedDateBs: '2081-11-02'
  },
  {
    id: 'rm-chili',
    code: 'RM-AG01',
    nameNe: 'सुकेको रातो खुर्सानी (Dried Red Chili)',
    nameEn: 'Dried Red Chili Whole Grade A',
    category: 'AGRO_FOOD',
    unit: 'Kg',
    currentStock: 250,
    unitCostPrice: 350,
    minStockAlert: 50,
    supplierName: 'सिन्धुली कृषि फर्म',
    lastPurchasedDateBs: '2081-11-01'
  },
  {
    id: 'rm-onion',
    code: 'RM-AG02',
    nameNe: 'सुकेको प्याज / अनियन फ्लेक्स (Dried Onion)',
    nameEn: 'Dehydrated Onion Flakes',
    category: 'AGRO_FOOD',
    unit: 'Kg',
    currentStock: 180,
    unitCostPrice: 180,
    minStockAlert: 40,
    supplierName: 'तराई जैविक उत्पादन सहकारी',
    lastPurchasedDateBs: '2081-10-28'
  },
  {
    id: 'rm-ginger',
    code: 'RM-AG03',
    nameNe: 'सुठो / सुकेको अदुवा (Dried Ginger)',
    nameEn: 'Dried Ginger (Sutho)',
    category: 'AGRO_FOOD',
    unit: 'Kg',
    currentStock: 140,
    unitCostPrice: 450,
    minStockAlert: 30,
    supplierName: 'इलाम अदुवा प्रशोधन केन्द्र',
    lastPurchasedDateBs: '2081-11-02'
  },
  {
    id: 'rm-pouch',
    code: 'RM-PK06',
    nameNe: 'सिल्भर जिपर पाउच ५०० ग्राम (Packaging Pouch 500g)',
    nameEn: 'Silver Standup Zipper Pouch 500g',
    category: 'PLASTIC_PACK',
    unit: 'Pc',
    currentStock: 2000,
    unitCostPrice: 12,
    minStockAlert: 300,
    supplierName: 'काठमाडौं प्याकेजिङ इन्डस्ट्रिज',
    lastPurchasedDateBs: '2081-11-03'
  }
];

export const SAMPLE_PRODUCTION_BATCHES: ProductionBatch[] = [
  {
    id: 'batch-101',
    batchNumber: 'BATCH-2081-001',
    productNameNe: 'पावर टिलर ७ एचपी असम्बल (Power Tiller 7HP)',
    productNameEn: 'Power Tiller 7HP Heavy Assembly',
    stage: 'IN_MACHINE_WIP',
    productionDateBs: '2081-11-01',
    productionDateAd: '2024-11-16',
    targetQuantity: 10,
    inputQuantity: 130,
    inputUnit: 'Kg/Pcs',
    outputQuantity: 10,
    outputUnit: 'Set',
    yieldPercent: 100,
    wastagePercent: 0,
    rawMaterialCost: 234400,
    laborCost: 15000,
    electricityCost: 6000,
    otherOverheadCost: 3000,
    totalProductionCost: 258400,
    unitManufacturingCost: 25840,
    qualityCheckStatus: 'PENDING',
    rawMaterialsUsed: [
      { materialId: 'rm-1', materialName: 'स्टिल पाता / एमएस सीट', quantityUsed: 120, unit: 'Kg', costPerUnit: 120 },
      { materialId: 'rm-2', materialName: '७ एचपी डिजेल इन्जिन एसेम्ब्ली', quantityUsed: 10, unit: 'Pc', costPerUnit: 22000 }
    ],
    machineName: 'वर्कसप वेल्डिङ तथा सीएनसी कटिङ युनिट',
    operatorName: 'रामचन्द्र सिलवाल (मेसिनरी प्राविधिक)',
    startedDateBs: '2081-11-01',
    notes: 'फ्रेम वेल्डिङ र इन्जिन फिटिङको काम भइरहेको',
    status: 'ACTIVE'
  },
  {
    id: 'batch-102',
    batchNumber: 'BATCH-2081-002',
    productNameNe: 'रोटाभेटर ब्लेड १८ थान सेट (Rotavator Blade Sets)',
    productNameEn: 'Rotavator Curved Blade Set',
    stage: 'FINISHED_GOODS',
    productionDateBs: '2081-10-20',
    productionDateAd: '2024-11-05',
    targetQuantity: 25,
    finishedGoodsQuantity: 25,
    inputQuantity: 225,
    inputUnit: 'Kg/Set',
    outputQuantity: 25,
    outputUnit: 'Set',
    yieldPercent: 96,
    wastagePercent: 4,
    rawMaterialCost: 70250,
    laborCost: 6500,
    electricityCost: 3200,
    otherOverheadCost: 1500,
    totalProductionCost: 81450,
    unitManufacturingCost: 3258,
    qualityCheckStatus: 'PASS',
    qualityNotes: 'ब्लेडको कडापन र तीक्ष्णता मापदण्ड अनुसार ठीक छ',
    qualityCheckedBy: 'रामचन्द्र सिलवाल',
    rawMaterialsUsed: [
      { materialId: 'rm-1', materialName: 'स्टिल पाता / एमएस सीट', quantityUsed: 200, unit: 'Kg', costPerUnit: 120 },
      { materialId: 'rm-4', materialName: 'रोटाभेटर साफ्ट तथा बेयरिङ सेट', quantityUsed: 25, unit: 'Set', costPerUnit: 1850 }
    ],
    machineName: 'हिट ट्रिटमेन्ट र फोर्जिङ प्रेसर मेसिन',
    operatorName: 'रामचन्द्र सिलवाल',
    startedDateBs: '2081-10-20',
    completionDateBs: '2081-10-28',
    notes: 'क्वालिटी टेस्ट पास भई तयारी मौज्दातमा दाखिला गरिएको',
    status: 'ACTIVE'
  },
  {
    id: 'batch-105',
    batchNumber: 'BATCH-2081-005',
    productNameNe: 'सुकेको खुर्सानी धुलो (Chili Powder 500g)',
    productNameEn: 'Pure Chili Powder 500g Pack',
    stage: 'FINISHED_GOODS',
    productionDateBs: '2081-11-02',
    productionDateAd: '2024-11-17',
    manufactureDateBs: '2081-11-02',
    manufactureDateAd: '2024-11-17',
    expiryDateBs: '2082-11-01',
    expiryDateAd: '2025-11-17',
    targetQuantity: 100,
    inputQuantity: 55,
    inputUnit: 'Kg',
    outputQuantity: 50,
    outputUnit: 'Kg',
    yieldPercent: 90.9,
    wastagePercent: 9.1,
    rawMaterialCost: 18500,
    laborCost: 2500,
    electricityCost: 1200,
    otherOverheadCost: 800,
    totalProductionCost: 23000,
    unitManufacturingCost: 460,
    costPerPacket: 230,
    packetSize: '500g',
    packetsProduced: 100,
    packagingType: 'सिल्भर जिपर पाउच (500g)',
    qualityCheckStatus: 'PASS',
    qualityNotes: 'आर्द्रता ९.५%, स्वाद तथा सुगन्ध मानक अनुसार शुद्ध',
    qualityCheckedBy: 'सुरेश खनाल (ल्याब टेक्निसियन)',
    finishedGoodsQuantity: 50,
    completionDateBs: '2081-11-02',
    rawMaterialsUsed: [
      { materialId: 'rm-chili', materialName: 'सुकेको रातो खुर्सानी (Dried Red Chili)', quantityUsed: 35, unit: 'Kg', costPerUnit: 350 },
      { materialId: 'rm-ginger', materialName: 'सुठो / सुकेको अदुवा (Dried Ginger)', quantityUsed: 10, unit: 'Kg', costPerUnit: 450 },
      { materialId: 'rm-onion', materialName: 'सुकेको प्याज / अनियन फ्लेक्स (Dried Onion)', quantityUsed: 10, unit: 'Kg', costPerUnit: 180 }
    ],
    machineName: 'ग्राइन्डिङ मिल तथा मसला पल्भराइजर',
    operatorName: 'हरि प्रसाद ढकाल',
    startedDateBs: '2081-11-02',
    notes: 'खुर्सानी, प्याज र अदुवा सुकाएर पल्भराइज गरी ५०० ग्राम प्याकिङ गरिएको',
    status: 'ACTIVE'
  },
  {
    id: 'batch-103',
    batchNumber: 'BATCH-2081-003',
    productNameNe: 'सबमर्सिबल वाटर पम्प १.५ एचपी (Water Pump 1.5HP)',
    productNameEn: 'Submersible Water Pump 1.5HP',
    stage: 'PACKAGING',
    productionDateBs: '2081-10-25',
    productionDateAd: '2024-11-10',
    targetQuantity: 15,
    finishedGoodsQuantity: 15,
    packedQuantity: 15,
    inputQuantity: 60,
    inputUnit: 'Meter',
    outputQuantity: 15,
    outputUnit: 'Pc',
    yieldPercent: 100,
    wastagePercent: 0,
    rawMaterialCost: 22800,
    laborCost: 8000,
    electricityCost: 3500,
    otherOverheadCost: 2000,
    totalProductionCost: 36300,
    unitManufacturingCost: 2420,
    qualityCheckStatus: 'PASS',
    rawMaterialsUsed: [
      { materialId: 'rm-3', materialName: 'इरिगेसन ग्याल्भानाइज्ड पाइप २ इन्च', quantityUsed: 60, unit: 'Meter', costPerUnit: 380 }
    ],
    machineName: 'कपर क्वाइल वाइन्डिङ र एसेम्ब्ली लाइन',
    operatorName: 'हरि प्रसाद ढकाल',
    startedDateBs: '2081-10-25',
    completionDateBs: '2081-11-01',
    packagingType: 'काठको भारी प्याकिङ बाकस तथा थर्मोकोल',
    packedDateBs: '2081-11-03',
    notes: 'बाकस प्याकिङ सकिएर बजार पठाउन तयारी अवस्थामा रहेको',
    status: 'ACTIVE'
  },
  {
    id: 'batch-104',
    batchNumber: 'BATCH-2081-004',
    productNameNe: 'मिनी पावर बीडर / झार उखेल्ने मेसिन (Mini Weeder)',
    productNameEn: 'Mini Power Weeder 3HP',
    stage: 'DISPATCHED_MARKET',
    productionDateBs: '2081-10-15',
    productionDateAd: '2024-10-31',
    targetQuantity: 8,
    finishedGoodsQuantity: 8,
    packedQuantity: 8,
    inputQuantity: 80,
    inputUnit: 'Kg',
    outputQuantity: 8,
    outputUnit: 'Set',
    yieldPercent: 100,
    wastagePercent: 0,
    rawMaterialCost: 9600,
    laborCost: 12000,
    electricityCost: 4000,
    otherOverheadCost: 2500,
    totalProductionCost: 28100,
    unitManufacturingCost: 3512,
    qualityCheckStatus: 'PASS',
    rawMaterialsUsed: [
      { materialId: 'rm-1', materialName: 'स्टिल पाता / एमएस सीट', quantityUsed: 80, unit: 'Kg', costPerUnit: 120 }
    ],
    startedDateBs: '2081-10-15',
    completionDateBs: '2081-10-22',
    packedDateBs: '2081-10-24',
    dispatches: [
      {
        id: 'disp-01',
        challanNo: 'CH-20811102-001',
        type: 'SALES',
        items: [],
        dealerName: 'पोखरा एग्रो विकास सप्लायर्स (पोखरा)',
        address: 'नयाँबजार, पोखरा-०९',
        phone: '९८५६०४५६७८',
        dispatchedQuantity: 5,
        dispatchDateBs: '2081-11-02',
        vehicleNo: 'बा २ प ४५२१ (आईसुजु पिकअप)',
        driverName: 'माधव नेपाल',
        notes: 'पोखरा शो-रुमका लागि ५ वटा रवाना गरिएको',
        status: 'IN_TRANSIT'
      },
      {
        id: 'disp-02',
        challanNo: 'CH-20811104-002',
        type: 'SALES',
        items: [],
        dealerName: 'प्रगतिशिल कृषि सहकारी (माडी)',
        address: 'माडी, चितवन',
        phone: '९८४५०१२३९९',
        dispatchedQuantity: 3,
        dispatchDateBs: '2081-11-04',
        vehicleNo: 'ना ३ ख ९०१२ (आईसुजु ट्रयाक्टर)',
        driverName: 'सुरेश थापा',
        notes: 'माडी क्षेत्रका कृषकलाई वितरण गर्न पठाइएको',
        status: 'DELIVERED'
      }
    ],
    notes: 'बजार तथा डिलरहरूमा आपूर्ति भइसकेको',
    status: 'COMPLETED'
  }
];

export const SAMPLE_COMPANY_ACCOUNTS: CompanyAccount[] = [
  {
    id: 'acc-admin',
    mobileNumber: '9855012345',
    companyName: 'नेपाल कृषि यन्त्र तथा औजार सप्लायर्स (मुख्य कार्यालय)',
    ownerName: 'रामेश्वर अधिकारी (Master Admin)',
    panVatNo: '602345891',
    address: 'भरतपुर-१०, चितवन / तीनकुने, काठमाडौँ',
    status: 'APPROVED',
    role: 'SUPER_ADMIN',
    assignedRole: 'ADMINISTRATION',
    pin: '1234',
    registeredDateBs: '2080-01-01',
    approvedDateBs: '2080-01-01',
    notes: 'प्रणालीको मुख्य व्यवस्थापक (Master Administrator)'
  },
  {
    id: 'acc-chitwan',
    mobileNumber: '9845012399',
    companyName: 'चितवन एग्रो फार्म तथा मेसिनरी प्रा.लि.',
    ownerName: 'केपी शर्मा (मालिक/Owner)',
    panVatNo: '601245892',
    address: 'गीतानगर, भरतपुर-०६',
    status: 'APPROVED',
    role: 'COMPANY_OWNER',
    assignedRole: 'OWNER',
    pin: '1111',
    registeredDateBs: '2081-06-15',
    approvedDateBs: '2081-06-16',
    notes: 'मालिक खाता (पूर्ण नियन्त्रण अधिकार) - PIN: 1111'
  },
  {
    id: 'acc-accountant',
    mobileNumber: '9841000002',
    companyName: 'चितवन एग्रो फार्म तथा मेसिनरी प्रा.लि.',
    ownerName: 'विनोद दाहाल (लेखापाल/Accountant)',
    panVatNo: '601245892',
    address: 'लेखा शाखा, भरतपुर',
    status: 'APPROVED',
    role: 'STAFF',
    assignedRole: 'ACCOUNTANT',
    pin: '2222',
    registeredDateBs: '2081-07-01',
    approvedDateBs: '2081-07-01',
    notes: 'मालिकद्वारा तोकिएको लेखापाल - PIN: 2222'
  },
  {
    id: 'acc-counter',
    mobileNumber: '9841000003',
    companyName: 'चितवन एग्रो फार्म तथा मेसिनरी प्रा.लि.',
    ownerName: 'मनिषा श्रेष्ठ (काउन्टर बिलिङ/Sales)',
    panVatNo: '601245892',
    address: 'काउन्टर नं. १',
    status: 'APPROVED',
    role: 'STAFF',
    assignedRole: 'COUNTER_SALES',
    pin: '3333',
    registeredDateBs: '2081-07-10',
    approvedDateBs: '2081-07-10',
    notes: 'मालिकद्वारा तोकिएको काउन्टर सेल्स - PIN: 3333'
  },
  {
    id: 'acc-salesman',
    mobileNumber: '9845098765',
    companyName: 'चितवन एग्रो फार्म तथा मेसिनरी प्रा.लि.',
    ownerName: 'सिता अधिकारी (फिल्ड सेल्स/Salesman)',
    panVatNo: '601245892',
    address: 'बिक्री शाखा, भरतपुर',
    status: 'APPROVED',
    role: 'STAFF',
    assignedRole: 'SALESMAN',
    pin: '4444',
    registeredDateBs: '2081-08-01',
    approvedDateBs: '2081-08-01',
    notes: 'मालिकद्वारा तोकिएको सेल्सम्यान - PIN: 4444'
  },
  {
    id: 'acc-supervisor',
    mobileNumber: '9855012341',
    companyName: 'चितवन एग्रो फार्म तथा मेसिनरी प्रा.लि.',
    ownerName: 'रामचन्द्र सिलवाल (सुपरभाइजर/Supervisor)',
    panVatNo: '601245892',
    address: 'औद्योगिक क्षेत्र, भरतपुर',
    status: 'APPROVED',
    role: 'STAFF',
    assignedRole: 'SUPERVISOR',
    pin: '5555',
    registeredDateBs: '2081-08-05',
    approvedDateBs: '2081-08-05',
    notes: 'मालिकद्वारा तोकिएको सुपरभाइजर - PIN: 5555'
  },
  {
    id: 'acc-staff',
    mobileNumber: '9841000006',
    companyName: 'चितवन एग्रो फार्म तथा मेसिनरी प्रा.लि.',
    ownerName: 'दिपक गुरुङ (वर्कसप कर्मचारी/Staff)',
    panVatNo: '601245892',
    address: 'वर्कसप युनिट',
    status: 'APPROVED',
    role: 'STAFF',
    assignedRole: 'STAFF',
    pin: '6666',
    registeredDateBs: '2081-08-10',
    approvedDateBs: '2081-08-10',
    notes: 'मालिकद्वारा तोकिएको कर्मचारी - PIN: 6666'
  },
  {
    id: 'acc-pending-1',
    mobileNumber: '9812345678',
    companyName: 'लुम्बिनी आधुनिक कृषि औजार केन्द्र',
    ownerName: 'सुरेश चौधरी (नयाँ आवेदक)',
    panVatNo: '608991234',
    address: 'तिलोत्तमा-०४, रुपन्देही',
    status: 'PENDING_APPROVAL',
    role: 'COMPANY_OWNER',
    assignedRole: 'OWNER',
    pin: '1234',
    registeredDateBs: '2081-11-05',
    notes: 'नयाँ दर्ता आवेदन - एडमिनबाट स्वीकृतिको पर्खाइमा'
  }
];

export const SAMPLE_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'aud-init-1',
    timestamp: '10:15:20 AM',
    dateBs: '2083-07-12',
    dateAd: '2026-10-29',
    actionType: 'USER_LOGIN',
    module: 'AUTH',
    severity: 'INFO',
    actorName: 'रामेश्वर अधिकारी (Master Admin)',
    actorMobile: '9855012345',
    actorRole: 'SUPER_ADMIN',
    targetId: '9855012345',
    summaryNe: 'सुपर एडमिन (9855012345) प्रणालीमा लग-इन गरियो',
    summaryEn: 'Super Admin (9855012345) logged into the system',
    details: 'Device: Web ERP | Status: APPROVED | Role: SUPER_ADMIN'
  },
  {
    id: 'aud-init-2',
    timestamp: '11:05:44 AM',
    dateBs: '2083-07-12',
    dateAd: '2026-10-29',
    actionType: 'INVOICE_CREATED',
    module: 'BILLING',
    severity: 'INFO',
    actorName: 'मनिषा श्रेष्ठ (Counter Sales)',
    actorMobile: '9841000003',
    actorRole: 'COUNTER_SALES',
    targetId: 'TI-081/82-0001',
    summaryNe: 'भ्याट बिल नं. TI-081/82-0001 काटियो — रु. 1,44,640 (चितवन एग्रो फार्म प्रा.लि.)',
    summaryEn: 'Created VAT Invoice TI-081/82-0001 — Rs. 144,640 for Chitwan Agro Farm',
    details: 'Bill Type: VAT (13%) | Customer: चितवन एग्रो फार्म प्रा.लि. | Mode: BANK_FONEPAY | Items: 1'
  },
  {
    id: 'aud-init-3',
    timestamp: '12:30:10 PM',
    dateBs: '2083-07-12',
    dateAd: '2026-10-29',
    actionType: 'STOCK_ADJUSTED',
    module: 'INVENTORY',
    severity: 'WARNING',
    actorName: 'रामचन्द्र सिलवाल (Supervisor)',
    actorMobile: '9855012341',
    actorRole: 'SUPERVISOR',
    targetId: 'KY-PT01',
    summaryNe: 'स्टक समायोजन: पावर टिलर ७ एचपी डिजेल (KY-PT01) मौज्दात ४ बाट ६ सेट बनाइयो (+२ सेट)',
    summaryEn: 'Stock Adjusted: Power Tiller 7HP Diesel (KY-PT01) changed from 4 to 6 Set (+2 Set)',
    details: 'Item Code: KY-PT01 | Previous Stock: 4 Set | New Stock: 6 Set | Net Change: +2 Set'
  },
  {
    id: 'aud-init-4',
    timestamp: '01:45:05 PM',
    dateBs: '2083-07-12',
    dateAd: '2026-10-29',
    actionType: 'INVOICE_CANCELLED',
    module: 'BILLING',
    severity: 'CRITICAL',
    actorName: 'केपी शर्मा (Owner)',
    actorMobile: '9845012399',
    actorRole: 'OWNER',
    targetId: 'NV-081/82-0002',
    summaryNe: 'बिल रद्द गरियो: NV-081/82-0002 (रु. 4,700) रद्द गरी स्टक फिर्ता गरियो',
    summaryEn: 'Invoice Cancelled: NV-081/82-0002 (Rs. 4,700) cancelled and inventory stock restored',
    details: 'Cancelled Invoice: NV-081/82-0002 | Reversed Amount: Rs. 4,700 | Stock Restored: Yes'
  }
];

export const SAMPLE_PURCHASES: PurchaseRecord[] = [
  {
    id: 'pur-init-1',
    purchaseBillNo: 'PB-081/82-0001',
    supplierName: 'नेपाल एग्रो टूल्स इम्पोर्टर्स (Supplier)',
    supplierPan: '600123987',
    dateBs: '2081-11-01',
    dateAd: '2025-02-13',
    itemsSummary: 'पावर टिलर ७ एचपी डिजेल (2 Set), सबमर्सिबल पानी पम्प १.५ एचपी (5 Pcs)',
    taxableAmount: 290000,
    exemptAmount: 0,
    vatAmount: 37700,
    grandTotal: 327700,
    paymentMode: 'BANK_FONEPAY',
    bankAccountId: 'bank-1',
    bankName: 'कृषि विकास बैंक (ADBL)'
  },
  {
    id: 'pur-init-2',
    purchaseBillNo: 'PB-081/82-0002',
    supplierName: 'नेपाल स्टिल एण्ड एग्रो इन्डस्ट्रिज',
    supplierPan: '601987654',
    dateBs: '2081-11-03',
    dateAd: '2025-02-15',
    itemsSummary: 'रोटाभेटर कभ्र्ड ब्लेड सेट (10 Set), ड्रिप इरिगेसन पाइप १६ एमएम (15 Roll)',
    taxableAmount: 75000,
    exemptAmount: 0,
    vatAmount: 9750,
    grandTotal: 84750,
    paymentMode: 'CREDIT'
  }
];

export const SAMPLE_INVOICES: Invoice[] = [
  {
    id: 'inv-init-1',
    billType: 'VAT',
    invoiceNo: 'TI-081/82-0001',
    seriesNumber: 1,
    fiscalYear: '081/82',
    dateBs: '2081-11-02',
    dateAd: '2025-02-14',
    time: '11:05 AM',
    customerName: 'चितवन एग्रो फार्म प्रा.लि. (Chitwan Agro Farm)',
    customerPan: '601245892',
    customerAddress: 'गीतानगर, भरतपुर-०६',
    customerPhone: '९८५५०११२२३',
    partyId: 'pty-1',
    previousDue: 14500,
    netTotalDue: 159140,
    amountPaid: 144640,
    remainingDue: 14500,
    items: [
      {
        itemId: 'item-1',
        code: 'KY-PT01',
        name: 'पावर टिलर ७ एचपी डिजेल (इलेक्ट्रिक स्टार्ट)',
        unit: 'Set',
        hsCode: '8432.29',
        quantity: 1,
        rate: 128000,
        amount: 128000,
        isVatExempt: false
      }
    ],
    subtotal: 128000,
    discountPercent: 0,
    discountAmount: 0,
    freightCharge: 0,
    taxableAmount: 128000,
    exemptAmount: 0,
    vatAmount: 16640,
    grandTotal: 144640,
    paymentMode: 'BANK_FONEPAY',
    bankName: 'कृषि विकास बैंक (ADBL)',
    status: 'ACTIVE',
    createdRole: 'OWNER'
  },
  {
    id: 'inv-init-2',
    billType: 'NON_VAT',
    invoiceNo: 'NV-081/82-0001',
    seriesNumber: 1,
    fiscalYear: '081/82',
    dateBs: '2081-11-04',
    dateAd: '2025-02-16',
    time: '02:15 PM',
    customerName: 'प्रगतिशिल कृषि सहकारी संस्था (Pragatisheel Coop)',
    customerPan: '602334455',
    customerAddress: 'बसन्तपुर, माडी-०३',
    customerPhone: '९८४५०१२३९९',
    partyId: 'pty-2',
    previousDue: 8200,
    netTotalDue: 22300,
    amountPaid: 14100,
    remainingDue: 8200,
    items: [
      {
        itemId: 'item-3',
        code: 'KY-SP03',
        name: 'ब्याट्री तथा म्यानुअल २-इन-१ स्प्रेयर १६ लिटर',
        unit: 'Pcs',
        hsCode: '8424.81',
        quantity: 3,
        rate: 4700,
        amount: 14100,
        isVatExempt: false
      }
    ],
    subtotal: 14100,
    discountPercent: 0,
    discountAmount: 0,
    freightCharge: 0,
    taxableAmount: 14100,
    exemptAmount: 0,
    vatAmount: 0,
    grandTotal: 14100,
    paymentMode: 'CASH',
    status: 'ACTIVE',
    createdRole: 'OWNER'
  }
];

const STORAGE_KEYS = {
  ITEMS: 'krishiyantra_items_v3',
  INVOICES: 'krishiyantra_invoices_v3',
  PURCHASES: 'krishiyantra_purchases_v3',
  PARTIES: 'krishiyantra_parties_v3',
  EMPLOYEES: 'krishiyantra_employees_v3',
  ATTENDANCE: 'krishiyantra_attendance_v3',
  EMPLOYEE_LEDGER: 'krishiyantra_emp_ledger_v3',
  DAILY_CASH: 'krishiyantra_daily_cash_v3',
  COMPANY: 'krishiyantra_company_v3',
  BANK_ACCOUNTS: 'krishiyantra_banks_v3',
  PARTY_TRANSACTIONS: 'krishiyantra_party_txns_v3',
  RAW_MATERIALS: 'krishiyantra_raw_materials_v3',
  PRODUCTION_BATCHES: 'krishiyantra_production_batches_v3',
  COMPANY_ACCOUNTS: 'krishiyantra_accounts_v3',
  ACTIVE_ACCOUNT: 'krishiyantra_active_acc_v3',
  LANGUAGE: 'krishiyantra_lang_v3',
  USER_ROLE: 'krishiyantra_role_v3',
  AUDIT_LOGS: 'krishiyantra_audit_logs_v3',
  USER_CLEARED: 'krishiyantra_user_cleared_v3',
  MACHINES: 'krishiyantra_machines_v1',
  FIELD_ORDERS: 'krishiyantra_field_orders_v1',
  QUOTATIONS: 'krishiyantra_quotations_v1',
  BOMS: 'krishiyantra_boms_v1',
  PRODUCTION_ORDERS: 'krishiyantra_production_orders_v1'
};

export function loadStoredData<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    const parsed = JSON.parse(raw);
    const wasExplicitlyCleared = localStorage.getItem(STORAGE_KEYS.USER_CLEARED) === 'true';
    if (Array.isArray(parsed) && parsed.length === 0 && Array.isArray(defaultValue) && defaultValue.length > 0 && !wasExplicitlyCleared) {
      return defaultValue;
    }
    return parsed;
  } catch (e) {
    console.error(`Error loading storage key ${key}:`, e);
    return defaultValue;
  }
}

export function saveStoredData<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error saving storage key ${key}:`, e);
  }
}

export const SAMPLE_MACHINES: Machine[] = [
  {
    id: 'mach-1',
    nameNe: 'सीएनसी मेसिन (CNC Machine)',
    nameEn: 'CNC Machining Unit',
    code: 'MACH-001',
    powerConsumptionPerHr: 5.5,
    purchaseDateBs: '2081-01-01',
    status: 'ACTIVE'
  },
  {
    id: 'mach-2',
    nameNe: 'वेल्डिङ युनिट (Welder Unit)',
    nameEn: 'Welding Station',
    code: 'MACH-002',
    powerConsumptionPerHr: 3.2,
    purchaseDateBs: '2081-02-15',
    status: 'ACTIVE'
  }
];

export { STORAGE_KEYS };

