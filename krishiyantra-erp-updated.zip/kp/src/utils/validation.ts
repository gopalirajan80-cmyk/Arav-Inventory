export const validatePan = (pan: string): boolean => {
  if (!pan) return true; // Optional field, if provided validate
  return /^\d{9}$/.test(pan.trim());
};
