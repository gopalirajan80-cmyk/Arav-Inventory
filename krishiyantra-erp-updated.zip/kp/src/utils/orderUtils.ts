// फिल्ड अर्डर तथा कोटेशनका साझा हिसाब, सन्देश र प्रिन्ट सहायकहरू
import { FieldOrder, FieldOrderItem, FieldOrderStatus, Quotation, CompanyProfile } from '../types';
import { adToBs, formatBsDate } from './nepaliCalendar';
import { getPaperSize } from './paperSize';
import { amountInNepaliWords } from './vatCalculator';

export const VAT_RATE = 0.13;
/** फिल्ड स्टाफले दिन पाउने अधिकतम छुट % (मालिक/अफिसलाई सीमा छैन) */
export const MAX_FIELD_STAFF_DISCOUNT = 10;

export const round2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

export const calcLineAmount = (qty: number, rate: number, discountPercent = 0): number =>
  round2((Number(qty) || 0) * (Number(rate) || 0) * (1 - (Number(discountPercent) || 0) / 100));

export interface OrderTotals {
  subtotal: number;
  discountAmount: number;
  taxable: number;
  vatAmount: number;
  grandTotal: number;
}

/** जम्मा हिसाब। isVat भए छुट नपाउने सामान बाहेक १३% थपिन्छ। */
export function calcTotals(
  lines: FieldOrderItem[],
  discountPercent: number,
  isVat: boolean,
  freight = 0
): OrderTotals {
  const subtotal = round2(lines.reduce((s, l) => s + (l.amount || 0), 0));
  const discountAmount = round2((subtotal * (Number(discountPercent) || 0)) / 100);
  const taxableBase = lines.filter((l) => !l.isVatExempt).reduce((s, l) => s + (l.amount || 0), 0);
  const taxable = round2(taxableBase * (1 - (Number(discountPercent) || 0) / 100));
  const vatAmount = isVat ? round2(taxable * VAT_RATE) : 0;
  const grandTotal = round2(subtotal - discountAmount + vatAmount + (Number(freight) || 0));
  return { subtotal, discountAmount, taxable, vatAmount, grandTotal };
}

/** AD मिति (YYYY-MM-DD) बाट BS मिति (YYYY-MM-DD) */
export function adStringToBs(ad: string): string {
  if (!ad) return '';
  try {
    return formatBsDate(adToBs(new Date(ad + 'T00:00:00')));
  } catch {
    return '';
  }
}

export function addDaysAd(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${dd}`;
}

export const ORDER_STATUS_META: Record<
  FieldOrderStatus,
  { ne: string; en: string; cls: string }
> = {
  DRAFT: { ne: 'ड्राफ्ट', en: 'Draft', cls: 'bg-slate-100 text-slate-700 border-slate-300' },
  SUBMITTED: { ne: 'अफिसमा पठाइयो', en: 'Submitted', cls: 'bg-blue-100 text-blue-800 border-blue-300' },
  APPROVED: { ne: 'स्वीकृत', en: 'Approved', cls: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
  IN_PRODUCTION: { ne: 'उत्पादनमा', en: 'In Production', cls: 'bg-purple-100 text-purple-800 border-purple-300' },
  READY: { ne: 'तयार', en: 'Ready', cls: 'bg-teal-100 text-teal-800 border-teal-300' },
  DISPATCHED: { ne: 'चलान भयो', en: 'Dispatched', cls: 'bg-indigo-100 text-indigo-800 border-indigo-300' },
  DELIVERED: { ne: 'डेलिभर भयो', en: 'Delivered', cls: 'bg-green-100 text-green-900 border-green-400' },
  CANCELLED: { ne: 'रद्द', en: 'Cancelled', cls: 'bg-rose-100 text-rose-800 border-rose-300' }
};

const num = (n: number) => (Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });

export function buildOrderMessage(o: FieldOrder, company: CompanyProfile): string {
  const lines = o.items
    .map((it, i) => `${i + 1}. ${it.name}${it.size ? ' (' + it.size + ')' : ''} — ${num(it.qty)} ${it.unit} × ${num(it.rate)} = ${num(it.amount)}`)
    .join('\n');
  return [
    `*${company.name}* — अर्डर नं. ${o.orderNo}`,
    `मिति: ${o.dateBs}`,
    `ग्राहक: ${o.customerName}${o.customerPhone ? ' (' + o.customerPhone + ')' : ''}`,
    o.customerAddress ? `ठेगाना: ${o.customerAddress}` : '',
    '',
    lines,
    '',
    `जम्मा: रू. ${num(o.grandTotal)}`,
    o.advanceAmount ? `अग्रिम: रू. ${num(o.advanceAmount)}` : '',
    o.expectedDeliveryBs ? `डेलिभरी मिति: ${o.expectedDeliveryBs}` : '',
    o.gpsLat && o.gpsLng ? `लोकेसन: https://maps.google.com/?q=${o.gpsLat},${o.gpsLng}` : '',
    `अर्डर लिने: ${o.takenBy}`
  ]
    .filter((x) => x !== '')
    .join('\n');
}

export function buildQuotationMessage(q: Quotation, company: CompanyProfile): string {
  const lines = q.items
    .map((it, i) => `${i + 1}. ${it.name}${it.size ? ' (' + it.size + ')' : ''} — ${num(it.qty)} ${it.unit} × ${num(it.rate)} = ${num(it.amount)}`)
    .join('\n');
  return [
    `*${company.name}* — कोटेशन नं. ${q.quotationNo}`,
    `मिति: ${q.dateBs}${q.validUntilBs ? ' | मान्य: ' + q.validUntilBs + ' सम्म' : ''}`,
    `श्री ${q.customerName}`,
    q.subject ? `विषय: ${q.subject}` : '',
    '',
    lines,
    '',
    q.discountAmount ? `छुट: रू. ${num(q.discountAmount)}` : '',
    q.vatAmount ? `भ्याट (१३%): रू. ${num(q.vatAmount)}` : '',
    q.freightCharge ? `ढुवानी: रू. ${num(q.freightCharge)}` : '',
    `*कुल जम्मा: रू. ${num(q.grandTotal)}*`,
    q.paymentTerms ? `भुक्तानी: ${q.paymentTerms}` : '',
    q.deliveryTerms ? `डेलिभरी: ${q.deliveryTerms}` : '',
    company.phone ? `सम्पर्क: ${company.phone}` : ''
  ]
    .filter((x) => x !== '')
    .join('\n');
}

const esc = (s: unknown) =>
  String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

/** नयाँ विन्डोमा HTML खोलेर प्रिन्ट गर्ने (एपको मुख्य प्रिन्ट नियमसँग नझिँगिने) */
export function printHtmlDocument(title: string, bodyHtml: string): boolean {
  const w = window.open('', '_blank', 'width=900,height=1000');
  if (!w) return false;
  w.document.open();
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>
  @page { size: ${getPaperSize()}; margin: 12mm; }
  ${getPaperSize() === 'A5' ? 'body { zoom: 0.7; }' : ''}
  * { box-sizing: border-box; }
  body { font-family: 'Mukta','Noto Sans Devanagari','Segoe UI',Arial,sans-serif; color:#111; font-size:12px; margin:0; }
  .head { display:flex; align-items:center; gap:12px; border-bottom:2px solid #065f46; padding-bottom:8px; margin-bottom:10px; }
  .head img { height:56px; }
  .head h1 { margin:0; font-size:20px; color:#065f46; }
  .head p { margin:1px 0; color:#444; }
  .title { text-align:center; font-weight:800; font-size:16px; margin:8px 0; letter-spacing:.5px; }
  .meta { display:flex; justify-content:space-between; gap:12px; margin-bottom:8px; }
  .meta div { flex:1; }
  table { width:100%; border-collapse:collapse; margin:6px 0; }
  th, td { border:1px solid #888; padding:4px 6px; }
  th { background:#ecfdf5; text-align:left; }
  td.r, th.r { text-align:right; }
  .tot { width:55%; margin-left:auto; }
  .tot td { border:none; border-bottom:1px solid #ddd; }
  .tot tr.g td { font-weight:800; font-size:14px; border-top:2px solid #065f46; }
  .box { border:1px dashed #999; padding:6px 8px; margin:8px 0; }
  .sign { display:flex; justify-content:space-between; margin-top:48px; }
  .sign div { width:30%; text-align:center; border-top:1px solid #333; padding-top:4px; }
  .small { color:#555; font-size:11px; }
</style></head><body>${bodyHtml}
<script>window.onload=function(){setTimeout(function(){window.focus();window.print();},300);};</script>
</body></html>`);
  w.document.close();
  return true;
}

function companyHeader(c: CompanyProfile): string {
  return `<div class="head">
    ${c.logoUrl ? `<img src="${esc(c.logoUrl)}" alt="">` : ''}
    <div><h1>${esc(c.name)}</h1>
    <p>${esc(c.address)}${c.phone ? ' | फोन: ' + esc(c.phone) : ''}${c.email ? ' | ' + esc(c.email) : ''}</p>
    ${c.panVatNo ? `<p>PAN/VAT: ${esc(c.panVatNo)}</p>` : ''}</div></div>`;
}

function itemsTable(items: FieldOrderItem[]): string {
  return `<table><thead><tr><th>क्र.सं.</th><th>विवरण</th><th>एकाइ</th><th class="r">परिमाण</th><th class="r">दर</th><th class="r">छुट%</th><th class="r">रकम</th></tr></thead><tbody>
  ${items
    .map(
      (it, i) => `<tr><td>${i + 1}</td><td>${esc(it.name)}${it.size ? ' <span class="small">(' + esc(it.size) + ')</span>' : ''}${it.note ? '<br><span class="small">' + esc(it.note) + '</span>' : ''}</td><td>${esc(it.unit)}</td><td class="r">${num(it.qty)}</td><td class="r">${num(it.rate)}</td><td class="r">${it.discountPercent ? num(it.discountPercent) : '-'}</td><td class="r">${num(it.amount)}</td></tr>`
    )
    .join('')}
  </tbody></table>`;
}

export function printQuotation(q: Quotation, company: CompanyProfile): boolean {
  const banks = (company.bankAccounts || [])
    .slice(0, 3)
    .map((b) => `${esc(b.bankName)} — ${esc(b.accountNumber)} (${esc(b.accountHolder)})`)
    .join('<br>');
  const html = `${companyHeader(company)}
  <div class="title">कोटेशन / मूल्य प्रस्ताव (QUOTATION)</div>
  <div class="meta">
    <div><b>श्री ${esc(q.customerName)}</b><br>${esc(q.customerAddress || '')}<br>${q.customerPhone ? 'फोन: ' + esc(q.customerPhone) : ''}${q.customerPan ? '<br>PAN: ' + esc(q.customerPan) : ''}</div>
    <div style="text-align:right">कोटेशन नं.: <b>${esc(q.quotationNo)}</b><br>मिति: ${esc(q.dateBs)}<br>${q.validUntilBs ? 'मान्य अवधि: ' + esc(q.validUntilBs) + ' सम्म' : ''}</div>
  </div>
  ${q.subject ? `<p><b>विषय:</b> ${esc(q.subject)}</p>` : ''}
  <p>उपरोक्त सम्बन्धमा तहाँले माग गर्नुभएका सामानहरूको मूल्य प्रस्ताव तल उल्लेख गरिएको छ:</p>
  ${itemsTable(q.items)}
  <table class="tot">
    <tr><td>उप-जम्मा</td><td class="r">${num(q.subtotal)}</td></tr>
    ${q.discountAmount ? `<tr><td>छुट (${num(q.discountPercent)}%)</td><td class="r">- ${num(q.discountAmount)}</td></tr>` : ''}
    ${q.billType === 'VAT' ? `<tr><td>भ्याट (१३%)</td><td class="r">${num(q.vatAmount)}</td></tr>` : ''}
    ${q.freightCharge ? `<tr><td>ढुवानी</td><td class="r">${num(q.freightCharge)}</td></tr>` : ''}
    <tr class="g"><td>कुल जम्मा</td><td class="r">रू. ${num(q.grandTotal)}</td></tr>
  </table>
  <p class="small">अक्षरमा: ${esc(amountInNepaliWords(q.grandTotal))}</p>
  <div class="box">
    ${q.paymentTerms ? `<b>भुक्तानी सर्त:</b> ${esc(q.paymentTerms)}<br>` : ''}
    ${q.deliveryTerms ? `<b>डेलिभरी सर्त:</b> ${esc(q.deliveryTerms)}<br>` : ''}
    ${q.warrantyNote ? `<b>ग्यारेन्टी/वारेन्टी:</b> ${esc(q.warrantyNote)}<br>` : ''}
    ${q.validUntilBs ? `<b>वैधता:</b> यो कोटेशन ${esc(q.validUntilBs)} सम्म मात्र मान्य हुनेछ।<br>` : ''}
    ${q.notes ? `<b>अन्य:</b> ${esc(q.notes)}` : ''}
  </div>
  ${banks ? `<p class="small"><b>बैंक विवरण:</b><br>${banks}</p>` : ''}
  <div class="sign"><div>तयार गर्ने: ${esc(q.preparedBy)}</div><div>स्वीकृत गर्ने</div><div>ग्राहकको स्वीकृति / दस्तखत</div></div>`;
  return printHtmlDocument(`Quotation ${q.quotationNo}`, html);
}

export function printOrderSlip(o: FieldOrder, company: CompanyProfile): boolean {
  const html = `${companyHeader(company)}
  <div class="title">अर्डर स्लिप (ORDER SLIP)</div>
  <div class="meta">
    <div><b>${esc(o.customerName)}</b><br>${esc(o.customerAddress || '')}<br>${o.customerPhone ? 'फोन: ' + esc(o.customerPhone) : ''}</div>
    <div style="text-align:right">अर्डर नं.: <b>${esc(o.orderNo)}</b><br>मिति: ${esc(o.dateBs)} ${esc(o.time)}<br>${o.expectedDeliveryBs ? 'डेलिभरी मिति: <b>' + esc(o.expectedDeliveryBs) + '</b>' : ''}<br>${o.priority === 'URGENT' ? '<b>⚡ जरुरी</b>' : ''}</div>
  </div>
  ${itemsTable(o.items)}
  <table class="tot">
    <tr><td>उप-जम्मा</td><td class="r">${num(o.subtotal)}</td></tr>
    ${o.discountAmount ? `<tr><td>छुट (${num(o.discountPercent)}%)</td><td class="r">- ${num(o.discountAmount)}</td></tr>` : ''}
    <tr class="g"><td>अनुमानित जम्मा</td><td class="r">रू. ${num(o.grandTotal)}</td></tr>
    ${o.advanceAmount ? `<tr><td>अग्रिम प्राप्त</td><td class="r">${num(o.advanceAmount)}</td></tr>` : ''}
  </table>
  <div class="box">भुक्तानी: ${o.paymentTerm === 'CASH' ? 'नगद' : o.paymentTerm === 'CREDIT' ? 'उधारो' + (o.creditDays ? ' (' + o.creditDays + ' दिन)' : '') : 'अग्रिम'}<br>
  ${o.deliveryAddress ? 'डेलिभरी ठेगाना: ' + esc(o.deliveryAddress) + '<br>' : ''}${o.notes ? 'टिप्पणी: ' + esc(o.notes) : ''}</div>
  <div class="sign"><div>अर्डर लिने: ${esc(o.takenBy)}</div><div>स्वीकृत गर्ने</div><div>ग्राहक दस्तखत</div></div>`;
  return printHtmlDocument(`Order ${o.orderNo}`, html);
}
