// Desktop (Electron) app: Windows' own print dialog cannot show a preview for Electron
// ("This app doesn't support print preview"). So the desktop app turns the page into a PDF and shows it in
// its own preview window (with a Print button). In the browser / PWA this simply calls window.print().
declare global {
  interface Window {
    kyDesktop?: {
      printPreview: (o: { pageSize?: string; preferCss?: boolean; landscape?: boolean }) => Promise<boolean>;
    };
  }
}

export interface NativePrintOptions {
  /** 'A4' | 'A5' | 'Letter' ... used when the page has no @page size of its own */
  pageSize?: string;
  /** true when the page's CSS already sets @page size (two-up, challan, etc.) */
  preferCss?: boolean;
}

/** Resolves when the preview/print dialog has been handed over (not when the user finishes printing). */
export async function nativePrint(opts: NativePrintOptions = {}): Promise<void> {
  if (typeof window === 'undefined') return;
  const bridge = window.kyDesktop;
  if (bridge && typeof bridge.printPreview === 'function') {
    try {
      const ok = await bridge.printPreview({ pageSize: opts.pageSize || 'A4', preferCss: !!opts.preferCss });
      if (ok) return;
    } catch (e) {
      console.error('Print preview failed, using normal print:', e);
    }
  }
  window.focus();
  window.print();
}
