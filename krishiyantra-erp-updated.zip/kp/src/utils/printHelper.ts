import { nativePrint } from './desktopPrint';
// Reliable printing: clone the on-screen document into a plain top-level host so modals,
// fixed positioning and scroll containers can never crop or blank the printed page.
const IDS = [
  'printable-invoice', 'printable-quotation', 'printable-batch-invoices', 'printable-challan', 'printable-daily-summary', 'printable-purchase-bill', 'printable-report', 'ky-report-pdf-sheet',
  'printable-accounting-voucher', 'printable-attendance-sheet', 'ky-direct-print-container'
];

export type PrintMode = 'A4' | 'A5' | 'THERMAL_80' | 'THERMAL_58';

export interface PrintOptions {
  mode?: PrintMode;
  /** One printed copy per label (e.g. ORIGINAL, DUPLICATE). Each gets a badge + its own page. */
  copies?: string[];
  /** Two copies stacked on one A4 sheet (cut line between). */
  twoUp?: boolean;
  /** Black & white (saves colour ink). */
  bw?: boolean;
  /** Diagonal watermark text on every page, e.g. COPY / PAID / UNPAID. */
  watermark?: string;
  /** Hide the discount columns of the items table (cleaner, compact bill). */
  hideDiscount?: boolean;
}

export function printPage(opts: PrintOptions = {}) {
  if (typeof document === 'undefined') return;
  const src =
    (IDS.map((id) => document.getElementById(id)).find(Boolean) as HTMLElement | undefined) ||
    (document.querySelector('[data-print-target]') as HTMLElement | null);
  const root = document.documentElement;

  if (!src) {
    root.classList.add('ky-print-raw');
    void nativePrint({ pageSize: opts.mode === 'A5' ? 'A5' : 'A4' }).finally(() => {
      setTimeout(() => root.classList.remove('ky-print-raw'), 1000);
    });
    return;
  }

  document.getElementById('ky-print-host')?.remove();
  document.getElementById('ky-print-mode')?.remove();

  const thermal = opts.mode === 'THERMAL_80' || opts.mode === 'THERMAL_58';
  const twoUp = !!opts.twoUp && !thermal;
  const labels = opts.copies && opts.copies.length > 0 ? opts.copies : [''];

  const host = document.createElement('div');
  host.id = 'ky-print-host';
  if (twoUp) host.classList.add('ky-two-up');
  if (opts.bw) host.classList.add('ky-bw');
  if (opts.hideDiscount) host.classList.add('ky-hide-disc');
  if (opts.watermark) host.setAttribute('data-watermark', opts.watermark);

  const srcCanvas = src.querySelectorAll('canvas');
  labels.forEach((label) => {
    const clone = src.cloneNode(true) as HTMLElement;
    clone.removeAttribute('id');
    clone.classList.add('ky-print-doc');
    clone.querySelectorAll('canvas').forEach((c, i) => {
      try {
        const img = document.createElement('img');
        img.src = (srcCanvas[i] as HTMLCanvasElement).toDataURL();
        img.style.width = (srcCanvas[i] as HTMLCanvasElement).clientWidth + 'px';
        c.replaceWith(img);
      } catch { /* ignore */ }
    });
    const wrap = document.createElement('div');
    wrap.className = 'ky-copy';
    if (label) {
      const badge = document.createElement('div');
      badge.className = 'ky-copy-badge';
      badge.textContent = label;
      wrap.appendChild(badge);
    }
    wrap.appendChild(clone);
    host.appendChild(wrap);
  });
  document.body.appendChild(host);

  const style = document.createElement('style');
  style.id = 'ky-print-mode';
  if (opts.mode === 'THERMAL_80') style.textContent = '@media print{@page{size:80mm auto;margin:2mm}}';
  else if (opts.mode === 'THERMAL_58') style.textContent = '@media print{@page{size:58mm auto;margin:1mm}}';
  else if (twoUp) style.textContent = '@media print{@page{size:A4 portrait;margin:6mm}}';
  document.head.appendChild(style);

  let done = false;
  const cleanup = () => {
    if (done) return;
    done = true;
    host.remove();
    style.remove();
    window.removeEventListener('afterprint', cleanup);
  };
  window.addEventListener('afterprint', cleanup);
  setTimeout(() => {
    // Thermal receipts use the printer driver's own dialog; A4/A5 go through the in-app preview on desktop.
    if (thermal) {
      window.print();
      setTimeout(cleanup, 60000);
    } else {
      void nativePrint({ pageSize: opts.mode === 'A5' ? 'A5' : 'A4', preferCss: twoUp })
        .finally(() => setTimeout(cleanup, window.kyDesktop ? 500 : 60000));
    }
  }, 200);
}
