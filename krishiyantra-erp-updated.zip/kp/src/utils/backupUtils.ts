import {
  CompanyProfile,
  Item,
  Invoice,
  PurchaseRecord,
  Party,
  PartyTransaction,
  BankAccount,
  Employee,
  AttendanceRecord,
  EmployeeLedgerEntry,
  RawMaterial,
  ProductionBatch
} from '../types';
import { getTodayBsString } from './nepaliCalendar';

export interface BackupPayload {
  app: string;
  exportDateBs: string;
  exportDateIso: string;
  company: CompanyProfile;
  items: Item[];
  invoices: Invoice[];
  purchases: PurchaseRecord[];
  parties: Party[];
  partyTransactions: PartyTransaction[];
  bankAccounts: BankAccount[];
  employees: Employee[];
  attendance: AttendanceRecord[];
  employeeLedger: EmployeeLedgerEntry[];
  rawMaterials: RawMaterial[];
  productionBatches: ProductionBatch[];
}

export const generateBackupPayload = (data: Omit<BackupPayload, 'app' | 'exportDateBs' | 'exportDateIso'>): BackupPayload => {
  return {
    app: 'KrishiYantra ERP',
    exportDateBs: getTodayBsString(),
    exportDateIso: new Date().toISOString(),
    ...data
  };
};
