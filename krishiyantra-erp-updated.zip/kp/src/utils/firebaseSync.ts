// Firebase Firestore Multi-Device Sync Engine for KrishiYantra ERP
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, setDoc, getDoc } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const db = getFirestore(app);

export async function syncCompanyDataToCloud(companyId: string, fullData: {
  company: any;
  items: any[];
  invoices: any[];
  purchases: any[];
  parties: any[];
  partyTransactions: any[];
  bankAccounts: any[];
  employees: any[];
  attendance: any[];
  employeeLedger: any[];
  rawMaterials: any[];
  productionBatches: any[];
  dailyCash: any;
}): Promise<{ success: boolean; message: string }> {
  try {
    if (!companyId) return { success: false, message: 'कम्पनी आईडी फेला परेन।' };

    const docRef = doc(db, 'krishiyantra_companies', companyId);
    await setDoc(docRef, {
      companyId,
      updatedAt: new Date().toISOString(),
      timestamp: Date.now(),
      ...fullData
    }, { merge: true });

    return { success: true, message: 'डाटा क्लाउड (Firebase Firestore) मा सफलतापूर्वक सिंक भयो!' };
  } catch (err: any) {
    console.error('Cloud sync error:', err);
    return { success: false, message: err?.message || 'क्लाउड सिंक असफल भयो।' };
  }
}

export async function fetchCompanyDataFromCloud(companyId: string): Promise<any | null> {
  try {
    if (!companyId) return null;
    const docRef = doc(db, 'krishiyantra_companies', companyId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data();
    }
    return null;
  } catch (err) {
    console.error('Fetch cloud data error:', err);
    return null;
  }
}
