import type { PartyTransaction } from '../types';

/**
 * खरिद बिल दर्ता गर्दा बिलको भुक्तानी जनाउन सिस्टमले आफैं राख्ने (auto) PAYMENT_TO_SUPPLIER रेकर्ड।
 * यो भौचर होइन — ledger / बाँकी हिसाबका लागि मात्र हो, त्यसैले भौचर सूची र भौचर गणनामा देखाइँदैन।
 * (पुराना रेकर्डमा flag छैन, तर id `ptx-pur-` बाट सुरु हुन्छ — त्यसैले दुवै जाँचिन्छ।)
 */
export const isAutoPurchasePayment = (tx: Pick<PartyTransaction, 'id' | 'autoFromPurchase'>): boolean =>
  !!tx.autoFromPurchase || (tx.id || '').startsWith('ptx-pur-');

/** खरिद बिलबाट स्वतः बनेका भुक्तानी बाहेकका वास्तविक (हातले बनाएका) भौचरहरू */
export const manualVouchersOnly = <T extends Pick<PartyTransaction, 'id' | 'autoFromPurchase'>>(list: T[]): T[] =>
  list.filter((tx) => !isAutoPurchasePayment(tx));

type PartyLike = { partyType?: string; type?: string };
const kindOf = (p: PartyLike) => p.partyType || p.type;

/** ग्राहक (बिक्री पक्ष): CUSTOMER, BOTH, वा type नभएका पुराना पार्टी */
export const isCustomerParty = (p: PartyLike): boolean => {
  const k = kindOf(p);
  return !k || k === 'CUSTOMER' || k === 'BOTH';
};

/** सप्लायर (खरिद पक्ष): SUPPLIER वा BOTH */
export const isSupplierParty = (p: PartyLike): boolean => {
  const k = kindOf(p);
  return k === 'SUPPLIER' || k === 'BOTH';
};
