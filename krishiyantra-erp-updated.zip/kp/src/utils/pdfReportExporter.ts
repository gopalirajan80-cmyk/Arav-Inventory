import * as XLSX from 'xlsx';
import {
  BankAccount,
  CompanyProfile,
  Employee,
  EmployeeLedgerEntry,
  Invoice,
  Item,
  Party,
  PartyTransaction,
  ProductionBatch,
  PurchaseRecord,
  RawMaterial,
  AttendanceRecord,
  CompanyAccount
} from '../types';
import { getTodayBsString } from './nepaliCalendar';

export interface SummaryCardItem {
  label: string;
  value: string;
}

export interface PrintableReportConfig {
  title?: string;
  titleNe?: string;
  titleEn?: string;
  subtitle?: string;
  subtitleNe?: string;
  periodLabel?: string;
  headers: string[];
  rows: (string | number)[][];
  summaryCards?: SummaryCardItem[];
  footerNote?: string;
  company: CompanyProfile;
  fileName?: string;
  mode?: 'PRINT' | 'DOWNLOAD';
}

/**
 * Exports any single report table into a formatted .xlsx Excel file with Company Header & Summary
 */
export const exportReportToExcel = (config: PrintableReportConfig) => {
  const wb = XLSX.utils.book_new();
  const todayBs = getTodayBsString();
  const displayTitle = config.title || config.titleNe || config.titleEn || 'Report';

  const sheetData: (string | number)[][] = [
    [config.company.name || 'KrishiYantra Agri & Machinery Center'],
    [`PAN/VAT No: ${config.company.panVatNo || '-'} | Address: ${config.company.address || '-'} | Phone: ${config.company.phone || '-'}`],
    [displayTitle],
    [config.subtitle || `Generated Date (B.S.): ${todayBs} | Fiscal Year: ${config.company.fiscalYear}`],
    ...(config.periodLabel ? [[`अवधि (Period): ${config.periodLabel}`]] : []),
    []
  ];

  if (config.summaryCards && config.summaryCards.length > 0) {
    sheetData.push(['--- मुख्य सारांश (Executive Summary) ---', '']);
    config.summaryCards.forEach((sc) => {
      sheetData.push([sc.label, sc.value]);
    });
    sheetData.push([]);
  }

  sheetData.push(config.headers);
  config.rows.forEach((r) => {
    sheetData.push(r.map((cell) => (cell === undefined || cell === null ? '' : cell)));
  });

  const ws = XLSX.utils.aoa_to_sheet(sheetData);
  ws['!cols'] = config.headers.map(() => ({ wch: 20 }));

  const safeSheetName = (displayTitle.replace(/[\\/?*[\]:]/g, '').slice(0, 28) || 'Report').trim();
  XLSX.utils.book_append_sheet(wb, ws, safeSheetName);

  const rawFile = config.fileName || config.titleEn || config.title || 'Report';
  const cleanFile = rawFile.replace(/[^a-zA-Z0-9_-]/g, '_') || 'Report';
  XLSX.writeFile(wb, `${cleanFile}_${todayBs}.xlsx`);
};

/**
 * Generates a self-contained A4 PDF-formatted document and triggers:
 * 1) Direct real .pdf file download (via jsPDF + html2canvas) when mode is DOWNLOAD / DOWNLOAD_PDF
 * 2) Interactive Print Preview overlay + reliable browser print when mode is PRINT
 */
const buildReportPdfHtml = (config: PrintableReportConfig) => {
  const todayBs = getTodayBsString();
  const displayTitle = config.title || config.titleNe || config.titleEn || 'प्रतिवेदन (Report)';
  const displaySubtitle = config.subtitle || config.subtitleNe || '';
  const rawFile = config.fileName || config.titleEn || config.title || 'Report';
  const cleanFile = rawFile.replace(/[^a-zA-Z0-9_-]/g, '_') || 'Report';

  const summaryHtml =
    config.summaryCards && config.summaryCards.length > 0
      ? `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:8px;margin-bottom:14px;">
          ${config.summaryCards
            .map(
              (c) => `
            <div style="border:1px solid #cbd5e1;border-radius:8px;padding:8px 10px;background:#f8fafc;">
              <div style="font-size:10px;color:#475569;font-weight:700;">${c.label}</div>
              <div style="font-size:13px;font-weight:800;color:#0f172a;margin-top:2px;font-family:monospace;">${c.value}</div>
            </div>`
            )
            .join('')}
        </div>`
      : '';

  const tableHeaderHtml = config.headers
    .map(
      (h) =>
        `<th style="border:1px solid #64748b;padding:6px 8px;text-align:left;background:#f1f5f9;font-weight:800;color:#0f172a;font-size:11px;">${h}</th>`
    )
    .join('');

  const tableRowsHtml =
    config.rows.length > 0
      ? config.rows
          .map(
            (r, rIdx) =>
              `<tr style="background:${rIdx % 2 === 1 ? '#f8fafc' : '#ffffff'};">${r
                .map((cell, idx) => {
                  const isNumericCol =
                    typeof cell === 'number' ||
                    (typeof cell === 'string' && /^(रु\.|Rs\.|\+|-|\d)/.test(cell.trim()) && idx >= r.length - 3);
                  return `<td style="border:1px solid #94a3b8;padding:6px 8px;font-size:11px;color:#0f172a;${
                    isNumericCol ? 'text-align:right;font-family:monospace;font-weight:700;' : 'text-align:left;'
                  }">${cell ?? ''}</td>`;
                })
                .join('')}</tr>`
          )
          .join('')
      : `<tr><td colspan="${config.headers.length}" style="border:1px solid #94a3b8;text-align:center;padding:18px;color:#64748b;">कुनै विवरण फेला परेन (No records found for this filter)</td></tr>`;

  const reportBodyHtml = `
    <div id="ky-report-pdf-sheet" style="width:100%;max-width:780px;margin:0 auto;padding:18px;background:#ffffff;color:#0f172a;font-family:'Mukta','Noto Sans Devanagari',system-ui,-apple-system,sans-serif;font-size:12px;box-sizing:border-box;">
      <div style="text-align:center;border-bottom:3px solid #1e293b;padding-bottom:12px;margin-bottom:18px;position:relative;">
        ${
          config.company.logoUrl
            ? `<img src="${config.company.logoUrl}" alt="Logo" style="height:65px;width:auto;object-fit:contain;margin-bottom:8px;border-radius:4px;" />`
            : ''
        }
        <h1 style="font-size:26px;font-weight:900;color:#0f172a;margin:0;letter-spacing:-0.5px;text-transform:uppercase;">${config.company.name}</h1>
        <div style="font-size:12px;color:#334155;margin-top:6px;font-weight:700;line-height:1.4;">
          ${config.company.address || '-'}
          <br />
          स्थायी लेखा नं. (PAN / VAT No.): <span style="font-family:monospace;font-weight:800;">${config.company.panVatNo || '-'}</span>
          <br />
          फोन: ${config.company.phone || '-'} ${config.company.email ? ` | इमेल: ${config.company.email}` : ''}
        </div>
        
        <div style="margin-top:14px;display:flex;justify-content:center;">
          <div style="font-size:16px;font-weight:900;background:#1e293b;color:#ffffff;padding:6px 24px;border-radius:4px;display:inline-block;letter-spacing:0.5px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
            ${displayTitle}
          </div>
        </div>
        
        ${displaySubtitle ? `<div style="font-size:12px;color:#475569;margin-top:8px;font-weight:700;font-style:italic;">${displaySubtitle}</div>` : ''}
        
        <div style="font-size:11px;color:#64748b;margin-top:6px;font-weight:600;display:flex;justify-content:center;gap:10px;">
          <span>मिति: <span style="font-family:monospace;font-weight:800;">${todayBs}</span></span>
          <span>आ.व.: <span style="font-family:monospace;font-weight:800;">${config.company.fiscalYear}</span></span>
          ${config.periodLabel ? `<span>अवधि: <span style="font-family:monospace;font-weight:800;">${config.periodLabel}</span></span>` : ''}
        </div>
      </div>

      ${summaryHtml}

      <table style="width:100%;border-collapse:collapse;margin-top:6px;">
        <thead>
          <tr>${tableHeaderHtml}</tr>
        </thead>
        <tbody>
          ${tableRowsHtml}
        </tbody>
      </table>

      ${
        config.footerNote
          ? `<div style="margin-top:12px;padding:8px 12px;background:#f8fafc;border:1px solid #cbd5e1;border-radius:6px;font-size:11px;color:#334155;">${config.footerNote}</div>`
          : ''
      }

      <div style="display:flex;justify-content:space-between;margin-top:36px;padding-top:12px;font-size:11px;color:#334155;">
        <div style="border-top:1px dashed #334155;padding-top:4px;min-width:140px;text-align:center;font-weight:700;">तयार गर्ने (Prepared By)</div>
        <div style="border-top:1px dashed #334155;padding-top:4px;min-width:140px;text-align:center;font-weight:700;">लेखा परीक्षण (Checked By)</div>
        <div style="border-top:1px dashed #334155;padding-top:4px;min-width:150px;text-align:center;font-weight:700;">स्वीकृत गर्ने / छाप (Authorized Stamp)</div>
      </div>
    </div>
  `;

  return { reportBodyHtml, cleanFile, todayBs, displayTitle };
};

/**
 * Generates a real shareable PDF File object (application/pdf) for Web Share API or WhatsApp sharing
 */
export const generateReportPdfFile = async (config: PrintableReportConfig): Promise<File | null> => {
  const { renderElementToShareablePdfFile } = await import('./pdfHelper');
  const { reportBodyHtml, cleanFile, todayBs } = buildReportPdfHtml(config);

  const tempHolder = document.createElement('div');
  tempHolder.style.position = 'fixed';
  tempHolder.style.left = '-9999px';
  tempHolder.style.top = '0';
  tempHolder.style.width = '794px';
  tempHolder.style.background = '#ffffff';
  tempHolder.style.zIndex = '-1';
  tempHolder.innerHTML = reportBodyHtml;
  document.body.appendChild(tempHolder);

  try {
    const sheetEl = tempHolder.querySelector('#ky-report-pdf-sheet') as HTMLElement;
    const pdfFile = await renderElementToShareablePdfFile(sheetEl || tempHolder, `${cleanFile}_${todayBs}.pdf`, 'a4');
    return pdfFile;
  } catch (e) {
    console.error('Report PDF File generation error:', e);
    return null;
  } finally {
    if (tempHolder.parentNode) tempHolder.parentNode.removeChild(tempHolder);
  }
};

export const printOrDownloadReportPdf = async (
  config: PrintableReportConfig,
  modeArg?: 'PRINT' | 'DOWNLOAD_PDF' | 'DOWNLOAD'
) => {
  const { renderElementToPdfFile, triggerReliableHtmlPrint } = await import('./pdfHelper');
  const effectiveMode = modeArg || config.mode || 'PRINT';
  const { reportBodyHtml, cleanFile, todayBs, displayTitle } = buildReportPdfHtml(config);

  if (effectiveMode === 'DOWNLOAD' || effectiveMode === 'DOWNLOAD_PDF') {
    const tempHolder = document.createElement('div');
    tempHolder.style.position = 'fixed';
    tempHolder.style.left = '-9999px';
    tempHolder.style.top = '0';
    tempHolder.style.width = '794px';
    tempHolder.style.background = '#ffffff';
    tempHolder.style.zIndex = '-1';
    tempHolder.innerHTML = reportBodyHtml;
    document.body.appendChild(tempHolder);

    try {
      const sheetEl = tempHolder.querySelector('#ky-report-pdf-sheet') as HTMLElement;
      await renderElementToPdfFile(sheetEl || tempHolder, `${cleanFile}_${todayBs}.pdf`, 'a4');
    } catch (e) {
      console.error('PDF Download error:', e);
    } finally {
      if (tempHolder.parentNode) tempHolder.parentNode.removeChild(tempHolder);
    }
    return;
  }

  // Mode === 'PRINT': Show interactive on-screen Print Preview overlay + trigger direct print
  const existingModal = document.getElementById('ky-report-print-modal');
  if (existingModal) existingModal.remove();

  const modalOverlay = document.createElement('div');
  modalOverlay.id = 'ky-report-print-modal';
  modalOverlay.style.cssText =
    'position:fixed;inset:0;z-index:99999;background:rgba(15,23,42,0.75);display:flex;flex-direction:column;align-items:center;padding:16px;overflow-y:auto;';

  modalOverlay.innerHTML = `
    <div style="width:100%;max-width:820px;background:#0f172a;color:#ffffff;padding:12px 16px;border-radius:12px 12px 0 0;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;box-shadow:0 10px 25px rgba(0,0,0,0.3);">
      <div style="font-size:13px;font-weight:700;">
        🖨️ ${displayTitle} — प्रिन्ट तथा PDF सेभ प्रिभ्यु (Print & Save as PDF)
      </div>
      <div style="display:flex;align-items:center;gap:8px;">
        <button id="ky-modal-btn-print" style="background:#10b981;color:#ffffff;border:none;padding:7px 14px;border-radius:8px;font-weight:700;font-size:12px;cursor:pointer;">
          🖨️ प्रिन्ट गर्नुहोस् (Print Now)
        </button>
        <button id="ky-modal-btn-pdf" style="background:#2563eb;color:#ffffff;border:none;padding:7px 14px;border-radius:8px;font-weight:700;font-size:12px;cursor:pointer;">
          📥 PDF डाउनलोड (.PDF Save)
        </button>
        <button id="ky-modal-btn-close" style="background:#334155;color:#ffffff;border:none;padding:7px 12px;border-radius:8px;font-weight:700;font-size:12px;cursor:pointer;">
          ✕ बन्द (Close)
        </button>
      </div>
    </div>
    <div id="ky-modal-sheet-wrapper" style="width:100%;max-width:820px;background:#ffffff;border-radius:0 0 12px 12px;padding:16px;box-shadow:0 20px 35px rgba(0,0,0,0.35);">
      ${reportBodyHtml}
    </div>
  `;

  document.body.appendChild(modalOverlay);

  const btnClose = document.getElementById('ky-modal-btn-close');
  const btnPrint = document.getElementById('ky-modal-btn-print');
  const btnPdf = document.getElementById('ky-modal-btn-pdf');

  if (btnClose) {
    btnClose.onclick = () => {
      modalOverlay.remove();
    };
  }
  if (btnPrint) {
    btnPrint.onclick = () => {
      triggerReliableHtmlPrint(reportBodyHtml, 'A4 portrait');
    };
  }
  if (btnPdf) {
    btnPdf.onclick = async () => {
      btnPdf.textContent = '⏳ सेभ हुँदैछ...';
      const targetEl = modalOverlay.querySelector('#ky-report-pdf-sheet') as HTMLElement;
      if (targetEl) {
        await renderElementToPdfFile(targetEl, `${cleanFile}_${todayBs}.pdf`, 'a4');
      }
      btnPdf.textContent = '✓ PDF डाउनलोड भयो!';
      setTimeout(() => {
        if (btnPdf) btnPdf.textContent = '📥 PDF डाउनलोड (.PDF Save)';
      }, 2000);
    };
  }

  // Trigger browser print automatically as well
  triggerReliableHtmlPrint(reportBodyHtml, 'A4 portrait');
};

export interface BankStatementRow {
  id: string;
  dateBs: string;
  bankId?: string;
  bankName?: string;
  particulars: string;
  voucherType: string;
  referenceNo: string;
  depositCredit: number; // बैंकमा जम्मा (+)
  withdrawalDebit: number; // बैंकबाट भुक्तानी / झिकिएको (-)
  runningBalance: number;
  voucherNo?: string;
  modeLabel?: string;
  deposit?: number;
  withdrawal?: number;
}

export type BankPeriodMode = 'ALL' | 'DAILY' | 'MONTHLY' | 'YEARLY' | 'CUSTOM';

export const buildUnifiedBankStatement = (params: {
  bankAccounts: BankAccount[];
  invoices: Invoice[];
  purchases: PurchaseRecord[];
  partyTransactions: PartyTransaction[];
  employeeLedger?: EmployeeLedgerEntry[];
  manualBankEntries?: CompanyProfile['manualBankEntries'];
  manualEntries?: CompanyProfile['manualBankEntries'];
  selectedBankId: string; // 'ALL' or bank.id
  periodMode?: BankPeriodMode;
  filterMode?: BankPeriodMode;
  dailyDateBs?: string;
  filterDayBs?: string;
  monthYearBs?: string;
  filterMonthBs?: string; // '01' to '12'
  yearBs?: string;
  filterYearBs?: string; // e.g. '2081' or '2082'
  customStartBs?: string;
  customFromBs?: string;
  customEndBs?: string;
  customToBs?: string;
}) => {
  const {
    bankAccounts,
    invoices,
    purchases,
    partyTransactions,
    employeeLedger = [],
    manualBankEntries = params.manualEntries || [],
    selectedBankId
  } = params;

  const periodMode = params.periodMode || params.filterMode || 'ALL';
  const filterDayBs = params.filterDayBs || params.dailyDateBs;
  const filterMonthBs = params.filterMonthBs || (params.monthYearBs ? params.monthYearBs.split('-')[1] : undefined);
  const filterYearBs = params.filterYearBs || params.yearBs || (params.monthYearBs ? params.monthYearBs.split('-')[0] : undefined);
  const customStartBs = params.customStartBs || params.customFromBs;
  const customEndBs = params.customEndBs || params.customToBs;

  const targetBanks =
    selectedBankId === 'ALL'
      ? bankAccounts
      : bankAccounts.filter((b) => b.id === selectedBankId);

  const primaryBank = targetBanks[0] || bankAccounts[0];

  const matchesSelectedBank = (bankId?: string, bankName?: string, bankAccNo?: string) => {
    if (selectedBankId === 'ALL') return true;
    const target = bankAccounts.find((b) => b.id === selectedBankId);
    if (!target) return true;
    if (bankId && bankId === target.id) return true;
    if (bankAccNo && bankAccNo === target.accountNumber) return true;
    if (bankName && target.bankName.toLowerCase().includes(bankName.toLowerCase().slice(0, 5))) return true;
    // If no specific bank was tagged on a legacy transaction and target is the first/primary bank, include it
    if (!bankId && !bankName && !bankAccNo && bankAccounts[0]?.id === target.id) return true;
    return false;
  };

  const rawEvents: Omit<BankStatementRow, 'runningBalance'>[] = [];

  // 1. Sales Invoices paid via BANK_FONEPAY
  invoices
    .filter((inv) => inv.status === 'ACTIVE' && inv.paymentMode === 'BANK_FONEPAY')
    .forEach((inv) => {
      if (!matchesSelectedBank(undefined, inv.bankName, inv.bankAccountNo)) return;
      const amt = inv.amountPaid !== undefined && inv.amountPaid > 0 ? inv.amountPaid : inv.grandTotal;
      if (amt <= 0) return;
      rawEvents.push({
        id: `inv-${inv.id}`,
        dateBs: inv.dateBs,
        bankId: primaryBank?.id || 'bank-1',
        bankName: inv.bankName || primaryBank?.bankName || 'बैंक खाता',
        particulars: `बिक्री बीजक दाखिला - ${inv.customerName} (${inv.invoiceNo})`,
        voucherType: 'बिक्री (Sales/QR)',
        referenceNo: inv.transactionRef || inv.invoiceNo,
        depositCredit: amt,
        withdrawalDebit: 0
      });
    });

  // 2. Party Transactions via BANK (Customer Collections & Supplier Payments)
  partyTransactions
    .filter((tx) => tx.paymentMode === 'BANK')
    .forEach((tx) => {
      if (!matchesSelectedBank(tx.bankAccountId, tx.bankName, tx.bankAccountNo)) return;
      const isCollection = tx.type === 'COLLECTION_FROM_CUSTOMER';
      rawEvents.push({
        id: `ptx-${tx.id}`,
        dateBs: tx.dateBs,
        bankId: tx.bankAccountId || primaryBank?.id || 'bank-1',
        bankName: tx.bankName || primaryBank?.bankName || 'बैंक खाता',
        particulars: `${isCollection ? 'ग्राहक असुली जम्मा' : 'आपूर्तिकर्ता भुक्तानी'} - ${tx.partyName}${tx.notes ? ` (${tx.notes})` : ''}`,
        voucherType: isCollection ? 'असुली (Receipt)' : 'भुक्तानी (Payment)',
        referenceNo: tx.referenceNo || '-',
        depositCredit: isCollection ? tx.amount : 0,
        withdrawalDebit: isCollection ? 0 : tx.amount
      });
    });

  // 3. Purchases paid via BANK_FONEPAY (avoid duplicating if already in partyTransactions with same bill ref)
  purchases
    .filter((p) => p.paymentMode === 'BANK_FONEPAY')
    .forEach((p) => {
      if (!matchesSelectedBank(p.bankAccountId, p.bankName, p.bankAccountNo)) return;
      const alreadyInPartyTx = partyTransactions.some(
        (tx) => tx.paymentMode === 'BANK' && tx.referenceNo === p.purchaseBillNo
      );
      if (alreadyInPartyTx) return;
      rawEvents.push({
        id: `pur-${p.id}`,
        dateBs: p.dateBs,
        bankId: p.bankAccountId || primaryBank?.id || 'bank-1',
        bankName: p.bankName || primaryBank?.bankName || 'बैंक खाता',
        particulars: `सामान खरिद भुक्तानी - ${p.supplierName} (${p.itemsSummary})`,
        voucherType: 'खरिद (Purchase)',
        referenceNo: p.purchaseBillNo,
        depositCredit: 0,
        withdrawalDebit: p.grandTotal
      });
    });

  // 4. Staff Salary Paid via BANK
  employeeLedger
    .filter((el) => el.type === 'SALARY_PAYMENT' && el.paymentMode === 'BANK')
    .forEach((el) => {
      if (!matchesSelectedBank(el.bankAccountId, el.bankName, undefined)) return;
      rawEvents.push({
        id: `sal-${el.id}`,
        dateBs: el.dateBs,
        bankId: el.bankAccountId || primaryBank?.id || 'bank-1',
        bankName: el.bankName || primaryBank?.bankName || 'बैंक खाता',
        particulars: `कर्मचारी तलब/ज्याला भुक्तानी (${el.notes})`,
        voucherType: 'तलब (Payroll)',
        referenceNo: el.referenceBillNo || 'SALARY',
        depositCredit: 0,
        withdrawalDebit: el.amount
      });
    });

  // 5. Manual Bank Entries (Direct Deposit / Withdrawal / Interest / Charges)
  manualBankEntries.forEach((m) => {
    if (!matchesSelectedBank(m.bankAccountId, m.bankName, undefined)) return;
    const isCredit = m.type === 'DEPOSIT' || m.type === 'INTEREST';
    const typeLabel =
      m.type === 'DEPOSIT'
        ? 'बैंक दाखिला (Deposit)'
        : m.type === 'WITHDRAWAL'
        ? 'चेक/नगद झिकिएको (Withdrawal)'
        : m.type === 'INTEREST'
        ? 'बैंक ब्याज (Interest)'
        : 'बैंक शुल्क (Charge)';
    rawEvents.push({
      id: m.id,
      dateBs: m.dateBs,
      bankId: m.bankAccountId,
      bankName: m.bankName,
      particulars: m.particulars,
      voucherType: typeLabel,
      referenceNo: m.referenceNo || '-',
      depositCredit: isCredit ? m.amount : 0,
      withdrawalDebit: isCredit ? 0 : m.amount
    });
  });

  // Sort chronologically by dateBs ascending
  rawEvents.sort((a, b) => a.dateBs.localeCompare(b.dateBs));

  const baseOpeningBalance = targetBanks.reduce((sum, b) => sum + (b.openingBalance || 0), 0);

  // Helper to check if a dateBs falls before or within the selected period
  const isBeforePeriod = (dateBs: string): boolean => {
    if (periodMode === 'DAILY' && filterDayBs) {
      return dateBs < filterDayBs;
    }
    if (periodMode === 'MONTHLY' && filterYearBs && filterMonthBs) {
      const prefix = `${filterYearBs}-${filterMonthBs.padStart(2, '0')}`;
      return dateBs.slice(0, 7) < prefix;
    }
    if (periodMode === 'YEARLY' && filterYearBs) {
      return dateBs.slice(0, 4) < filterYearBs;
    }
    if (periodMode === 'CUSTOM' && customStartBs) {
      return dateBs < customStartBs;
    }
    return false;
  };

  const isWithinPeriod = (dateBs: string): boolean => {
    if (periodMode === 'ALL') return true;
    if (periodMode === 'DAILY' && filterDayBs) {
      return dateBs === filterDayBs;
    }
    if (periodMode === 'MONTHLY' && filterYearBs && filterMonthBs) {
      const prefix = `${filterYearBs}-${filterMonthBs.padStart(2, '0')}`;
      return dateBs.startsWith(prefix);
    }
    if (periodMode === 'YEARLY' && filterYearBs) {
      return dateBs.startsWith(filterYearBs);
    }
    if (periodMode === 'CUSTOM') {
      const afterStart = !customStartBs || dateBs >= customStartBs;
      const beforeEnd = !customEndBs || dateBs <= customEndBs;
      return afterStart && beforeEnd;
    }
    return true;
  };

  // Calculate brought-forward opening balance prior to the selected period
  let broughtForwardBalance = baseOpeningBalance;
  rawEvents.forEach((ev) => {
    if (isBeforePeriod(ev.dateBs)) {
      broughtForwardBalance += ev.depositCredit - ev.withdrawalDebit;
    }
  });

  let running = broughtForwardBalance;
  let totalDeposits = 0;
  let totalWithdrawals = 0;

  const statementRows: BankStatementRow[] = [];

  rawEvents.forEach((ev) => {
    if (isWithinPeriod(ev.dateBs)) {
      running += ev.depositCredit - ev.withdrawalDebit;
      totalDeposits += ev.depositCredit;
      totalWithdrawals += ev.withdrawalDebit;
      statementRows.push({
        ...ev,
        runningBalance: running,
        voucherNo: ev.referenceNo,
        modeLabel: ev.voucherType,
        deposit: ev.depositCredit,
        withdrawal: ev.withdrawalDebit
      });
    }
  });

  return {
    openingBalance: broughtForwardBalance,
    totalDeposits,
    totalWithdrawals,
    totalDeposit: totalDeposits,
    totalWithdrawal: totalWithdrawals,
    periodLabelNe: periodMode === 'DAILY' ? `दैनिक मिति: ${filterDayBs}` : `आर्थिक विवरण`,
    closingBalance: running,
    rows: statementRows
  };
};

/**
 * Exports all ERP modules into a single Multi-Sheet Master Excel Workbook (.xlsx)
 */
export const exportAllReportsWorkbookToExcel = (data: {
  company: CompanyProfile;
  items: Item[];
  invoices: Invoice[];
  purchases: PurchaseRecord[];
  parties: Party[];
  partyTransactions: PartyTransaction[];
  bankAccounts: BankAccount[];
  employees: Employee[];
  attendance: AttendanceRecord[];
  employeeLedger: EmployeeLedgerEntry[];
  rawMaterials: RawMaterial[];
  productionBatches: ProductionBatch[];
  companyAccounts?: CompanyAccount[];
}) => {
  const wb = XLSX.utils.book_new();
  const todayBs = getTodayBsString();

  // 1. Sales Sheet
  const salesRows = [
    ['क्र.सं.', 'बीजक नं.', 'प्रकार', 'मिति (B.S.)', 'ग्राहकको नाम', 'प्यान नं.', 'भुक्तानी माध्यम', 'करयोग्य रकम', 'छुट रकम', '१३% भ्याट', 'कुल रकम', 'बुझाएको रकम', 'बाँकी रकम'],
    ...data.invoices.map((i, idx) => [
      idx + 1,
      i.invoiceNo,
      i.billType,
      i.dateBs,
      i.customerName,
      i.customerPan || '-',
      i.paymentMode,
      i.taxableAmount,
      i.discountAmount,
      i.vatAmount,
      i.grandTotal,
      i.amountPaid ?? i.grandTotal,
      i.remainingDue ?? 0
    ])
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(salesRows), '1_Sales_Bills');

  // 2. Purchase Sheet
  const purchaseRows = [
    ['क्र.सं.', 'खरिद बिल नं.', 'मिति (B.S.)', 'आपूर्तिकर्ता (Supplier)', 'प्यान नं.', 'सामानको विवरण', 'करयोग्य रकम', 'कर छुट रकम', '१३% भ्याट', 'कुल खरिद रकम', 'भुक्तानी माध्यम'],
    ...data.purchases.map((p, idx) => [
      idx + 1,
      p.purchaseBillNo,
      p.dateBs,
      p.supplierName,
      p.supplierPan || '-',
      p.itemsSummary,
      p.taxableAmount,
      p.exemptAmount,
      p.vatAmount,
      p.grandTotal,
      p.paymentMode
    ])
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(purchaseRows), '2_Purchase_Bills');

  // 3. Party Ledger & Dues
  const partyRows = [
    ['क्र.सं.', 'पार्टीको नाम', 'प्रकार', 'ठेगाना', 'फोन नं.', 'प्यान नं.', 'सुरुवाती बाँकी', 'भुक्तानी/असुली', 'हालको बाँकी (Current Due)'],
    ...data.parties.map((p, idx) => [
      idx + 1,
      p.name,
      p.partyType || p.type || 'CUSTOMER',
      p.address || '-',
      p.phone || '-',
      p.panNo || '-',
      p.openingBalance || 0,
      p.paidAmount || 0,
      p.currentBalance !== undefined ? p.currentBalance : p.openingBalance
    ])
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(partyRows), '3_Party_Ledger');

  // 4. Bank Statement Sheet
  const bankStmt = buildUnifiedBankStatement({
    bankAccounts: data.bankAccounts,
    invoices: data.invoices,
    purchases: data.purchases,
    partyTransactions: data.partyTransactions,
    employeeLedger: data.employeeLedger,
    manualBankEntries: data.company.manualBankEntries,
    selectedBankId: 'ALL',
    periodMode: 'ALL'
  });
  const bankRows = [
    ['क्र.सं.', 'मिति (B.S.)', 'बैंकको नाम', 'भौचर प्रकार', 'विवरण (Particulars)', 'Ref / चेक नं.', 'जम्मा / Deposit (+)', 'भुक्तानी / Withdrawal (-)', 'मौज्दात / Balance'],
    [1, '-', 'सुरुवाती मौज्दात (Opening Balance)', '-', 'Brought Forward', '-', bankStmt.openingBalance, 0, bankStmt.openingBalance],
    ...bankStmt.rows.map((r, idx) => [
      idx + 2,
      r.dateBs,
      r.bankName,
      r.voucherType,
      r.particulars,
      r.referenceNo,
      r.depositCredit,
      r.withdrawalDebit,
      r.runningBalance
    ])
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(bankRows), '4_Bank_Statement');

  // 5. Inventory Stock Sheet
  const invRows = [
    ['क्र.सं.', 'कोड', 'सामानको नाम (नेपाली)', 'Name (English)', 'क्याटगोरी', 'एकाइ', 'खरिद दर', 'बिक्री दर', 'मौज्दात स्टक', 'भ्याट स्टक', 'नन-भ्याट स्टक', 'कुल लागत मूल्य'],
    ...data.items.map((it, idx) => [
      idx + 1,
      it.code,
      it.nameNe,
      it.nameEn,
      it.category,
      it.unit,
      it.purchasePrice,
      it.sellingPrice,
      it.currentStock,
      it.vatStock ?? it.currentStock,
      it.nonVatStock ?? 0,
      it.purchasePrice * (it.currentStock || 0)
    ])
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(invRows), '5_Inventory_Stock');

  // 6. Manufacturing Sheet
  const mfgRows = [
    ['क्र.सं.', 'ब्याच नं.', 'उत्पादन नाम', 'चरण (Stage)', 'लक्ष्य परिमाण', 'तयार परिमाण', 'मेसिन', 'अपरेटर', 'सुरु मिति', 'कुल उत्पादन लागत'],
    ...data.productionBatches.map((b, idx) => [
      idx + 1,
      b.batchNumber,
      b.productNameNe || b.productNameEn,
      b.stage,
      b.targetQuantity,
      b.finishedGoodsQuantity || 0,
      b.machineName || '-',
      b.operatorName || '-',
      b.startedDateBs,
      b.totalProductionCost || 0
    ])
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(mfgRows), '6_Manufacturing');

  // 7. Staff & Roles Sheet
  const staffRows = [
    ['क्र.सं.', 'कर्मचारी आइडी', 'नाम', 'पद (Role)', 'फोन / लगइन ID', 'ज्याला प्रकार', 'मासिक तलब / दैनिक दर', 'सुरुवाती पेस्की', 'स्वीकृत अवस्था'],
    ...data.employees.map((e, idx) => [
      idx + 1,
      e.staffCode || `EMP-00${idx + 1}`,
      e.name,
      e.role,
      e.loginMobile || e.phone,
      e.wageType || 'MONTHLY',
      e.wageType === 'DAILY' ? e.dailyWageRate || 1000 : e.salaryMonthly,
      e.openingDue || 0,
      e.approvalStatus || 'APPROVED'
    ])
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(staffRows), '7_Staff_And_Roles');

  XLSX.writeFile(wb, `KrishiYantra_Master_All_Reports_${todayBs}.xlsx`);
};
