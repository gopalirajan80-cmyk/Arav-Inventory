// Excel Import & Export Engine using SheetJS (XLSX)
// Supports IRD Nepal Anusuchi 5 & 8 and "Thok_Khudra_Kharid_Bikri" spreadsheets

import * as XLSX from 'xlsx';
import { Invoice, PurchaseRecord, Item, ItemCategory } from '../types';

export interface ParsedItemRow {
  code?: string;
  nameEn: string;
  nameNe?: string;
  category: ItemCategory;
  unit: string;
  purchasePrice: number;
  sellingPrice: number;
  currentStock: number;
  minStockAlert: number;
  isVatExempt: boolean;
}

/**
 * Exports Sales Book according to Nepal IRD Anusuchi 5 format
 */
export function exportSalesBookToExcel(invoices: Invoice[], fiscalYear: string = '081/82') {
  const headers = [
    'क्र.सं. (S.N.)',
    'बिजक मिति (Date B.S.)',
    'बिजक नं. (Invoice No.)',
    'खरिदकर्ताको नाम (Buyer Name)',
    'प्यान/भ्याट नं. (Buyer PAN)',
    'कुल बिक्री मूल्य (Total Amount)',
    'कर छुट हुने बिक्री (Exempt Sales)',
    'करयोग्य बिक्री मूल्य (Taxable Amount)',
    'कर रकम १३% (VAT Amount)',
    'कैफियत (Remarks)'
  ];

  const rows = invoices.map((inv, idx) => [
    idx + 1,
    inv.dateBs,
    inv.invoiceNo,
    inv.customerName || 'खुद्रा ग्राहक (Cash/Retail)',
    inv.customerPan || '-',
    inv.grandTotal,
    inv.exemptAmount,
    inv.taxableAmount,
    inv.vatAmount,
    inv.status === 'CANCELLED' ? 'रद्द (Cancelled)' : 'सक्रिय (Active)'
  ]);

  // Compute summary totals
  const totalGrand = invoices.reduce((s, i) => s + (i.status === 'ACTIVE' ? i.grandTotal : 0), 0);
  const totalExempt = invoices.reduce((s, i) => s + (i.status === 'ACTIVE' ? i.exemptAmount : 0), 0);
  const totalTaxable = invoices.reduce((s, i) => s + (i.status === 'ACTIVE' ? i.taxableAmount : 0), 0);
  const totalVat = invoices.reduce((s, i) => s + (i.status === 'ACTIVE' ? i.vatAmount : 0), 0);

  rows.push([
    '',
    '',
    '',
    '',
    'जम्मा (Total)',
    totalGrand,
    totalExempt,
    totalTaxable,
    totalVat,
    ''
  ]);

  const worksheet = XLSX.utils.aoa_to_sheet([
    [`अनुसूची-५ (बिक्री खाता) - आ.व. ${fiscalYear}`],
    ['नेपाल सरकार, आन्तरिक राजस्व विभाग (Inland Revenue Department)'],
    [],
    headers,
    ...rows
  ]);

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sales_Book_Anusuchi_5');
  XLSX.writeFile(workbook, `Sales_Book_Anusuchi_5_${fiscalYear.replace('/', '-')}.xlsx`);
}

/**
 * Exports Purchase Book according to Nepal IRD Anusuchi 8 format
 */
export function exportPurchaseBookToExcel(purchases: PurchaseRecord[], fiscalYear: string = '081/82') {
  const headers = [
    'क्र.सं. (S.N.)',
    'बिजक मिति (Date B.S.)',
    'बिजक नं. (Purchase Bill No.)',
    'आपूर्तिकर्ताको नाम (Supplier Name)',
    'आपूर्तिकर्ताको प्यान (Supplier PAN)',
    'कुल खरिद रकम (Total Amount)',
    'कर छुट खरिद (Exempt Purchase)',
    'करयोग्य रकम (Taxable Base)',
    'भ्याट रकम १३% (Input VAT)',
    'कैफियत (Payment Mode)'
  ];

  const rows = purchases.map((p, idx) => [
    idx + 1,
    p.dateBs,
    p.purchaseBillNo,
    p.supplierName,
    p.supplierPan,
    p.grandTotal,
    p.exemptAmount,
    p.taxableAmount,
    p.vatAmount,
    p.paymentMode
  ]);

  const totalGrand = purchases.reduce((s, p) => s + p.grandTotal, 0);
  const totalExempt = purchases.reduce((s, p) => s + p.exemptAmount, 0);
  const totalTaxable = purchases.reduce((s, p) => s + p.taxableAmount, 0);
  const totalVat = purchases.reduce((s, p) => s + p.vatAmount, 0);

  rows.push([
    '',
    '',
    '',
    '',
    'जम्मा (Total)',
    totalGrand,
    totalExempt,
    totalTaxable,
    totalVat,
    ''
  ]);

  const worksheet = XLSX.utils.aoa_to_sheet([
    [`अनुसूची-८ (खरिद खाता) - आ.व. ${fiscalYear}`],
    ['नेपाल सरकार, आन्तरिक राजस्व विभाग (Inland Revenue Department)'],
    [],
    headers,
    ...rows
  ]);

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Purchase_Book_Anusuchi_8');
  XLSX.writeFile(workbook, `Purchase_Book_Anusuchi_8_${fiscalYear.replace('/', '-')}.xlsx`);
}

/**
 * Exports Inventory Items to Excel
 */
export function exportInventoryToExcel(items: Item[]) {
  const headers = [
    'Item Code',
    'Item Name (English)',
    'Item Name (Nepali)',
    'Category',
    'Unit',
    'Purchase Price (रु)',
    'Selling Price (रु)',
    'Current Stock',
    'Min Stock Alert',
    'VAT Exempt (कर छुट)'
  ];

  const rows = items.map((item) => [
    item.code,
    item.nameEn,
    item.nameNe,
    item.category,
    item.unit,
    item.purchasePrice,
    item.sellingPrice,
    item.currentStock,
    item.minStockAlert,
    item.isVatExempt ? 'Yes' : 'No'
  ]);

  const worksheet = XLSX.utils.aoa_to_sheet([
    ['KrishiYantra ERP - Inventory Stock Report'],
    [],
    headers,
    ...rows
  ]);

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Inventory_Stock');
  XLSX.writeFile(workbook, `KrishiYantra_Stock_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

/**
 * Downloads a pre-formatted Excel template for importing agriculture machinery items
 */
export function downloadAgricultureTemplate() {
  const headers = [
    'Item Code',
    'Item Name (English)*',
    'Item Name (Nepali)',
    'Category*',
    'Unit*',
    'Purchase Price*',
    'Selling Price*',
    'Current Stock*',
    'Min Stock Alert',
    'VAT Exempt (Yes/No)'
  ];

  const sampleRows = [
    ['AG-101', 'Power Tiller 7HP Diesel', 'पावर टिलर ७ एचपी डिजेल', 'TRACTOR_TILLER', 'Set', 115000, 132000, 4, 1, 'No'],
    ['AG-102', 'Submersible Water Pump 1HP', 'सबमर्सिबल पानी पम्प १ एचपी', 'IRRIGATION_PUMP', 'Pcs', 12500, 15500, 12, 3, 'No'],
    ['AG-103', 'Knapsack Battery Sprayer 16L', 'ब्याट्री स्प्रेयर १६ लिटर', 'SPRAYER_TOOLS', 'Pcs', 3800, 4800, 25, 5, 'No'],
    ['AG-104', 'Rotavator Heavy Blade Set', 'रोटाभेटर ब्लेड सेट', 'SPARE_PARTS', 'Set', 4500, 6000, 30, 8, 'No'],
    ['AG-105', 'Hybrid Maize Seed 5Kg Bag', 'मकैको हाइब्रिड बिउ ५ केजी', 'SEEDS_AGRO', 'Bag', 1200, 1450, 50, 10, 'Yes']
  ];

  const notes = [
    ['Instructions for Excel Import (Thok Khudra Kharid Bikri):'],
    ['1. Valid Categories: TRACTOR_TILLER, IRRIGATION_PUMP, SPRAYER_TOOLS, SPARE_PARTS, SEEDS_AGRO, FERTILIZER, PESTICIDES, LIVESTOCK_FEED'],
    ['2. Valid Units: Pcs, Set, Meter, Litre, Kg, Bag'],
    ['3. VAT Exempt: Put "Yes" for tax-exempt agricultural produce/seeds, "No" for 13% VAT machinery.'],
    []
  ];

  const worksheet = XLSX.utils.aoa_to_sheet([
    ...notes,
    headers,
    ...sampleRows
  ]);

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Items_Template');
  XLSX.writeFile(workbook, 'Items_Inventory_Template.xlsx');
}

/**
 * Helper to parse numeric values from Excel cells (supports Nepali digits ०-९, commas, Rs./रु prefixes)
 */
export function parseExcelNumericValue(rawVal: any): number {
  if (rawVal === undefined || rawVal === null || rawVal === '') return 0;
  if (typeof rawVal === 'number') return isNaN(rawVal) ? 0 : rawVal;

  const nepaliDigitMap: Record<string, string> = {
    '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
    '५': '5', '६': '6', '७': '7', '८': '8', '९': '9'
  };

  let str = String(rawVal).trim();
  str = str.replace(/[०-९]/g, (d) => nepaliDigitMap[d] || d);
  str = str.replace(/[^0-9.-]/g, '');
  const parsed = parseFloat(str);
  return isNaN(parsed) ? 0 : parsed;
}

/**
 * Validates IRD PAN/VAT number format (usually 9 digits)
 */
export function validatePanVat(pan: string | number | undefined): { isValid: boolean; error?: string } {
  if (!pan) return { isValid: false, error: 'PAN/VAT is mandatory' };
  const str = String(pan).trim();
  if (!/^\d{9}$/.test(str)) return { isValid: false, error: 'PAN/VAT must be exactly 9 digits' };
  return { isValid: true };
}

/**
 * Validates Date format YYYY-MM-DD or YYYY/MM/DD
 */
export function validateDate(date: string | undefined): { isValid: boolean; error?: string } {
  if (!date) return { isValid: false, error: 'Date is mandatory' };
  const str = String(date).trim();
  if (!/^\d{4}[-/]\d{1,2}[-/]\d{1,2}$/.test(str)) return { isValid: false, error: 'Date must be YYYY-MM-DD or YYYY/MM/DD' };
  return { isValid: true };
}

/**
 * Downloads Excel Template for Customer & Transaction Import (Date, Bill No, Customer Name, Address, Phone Number, PAN Number, Total Amount, Pay Amount, Due Amount)
 */
export function downloadCustomerImportTemplate() {
  const headers = [
    'Date (मिति)*',
    'Bill No (बिल नं.)*',
    'Customer Name (ग्राहकको नाम)*',
    'Address (ठेगाना)*',
    'Phone Number (फोन नम्बर)',
    'PAN Number (प्यान नं.)',
    'Total Amount (कुल रकम)*',
    'Pay Amount (बुझाएको रकम)',
    'Due Amount (बाँकी रकम)*',
    'Remarks (कैफियत)'
  ];

  const sampleRows = [
    ['2081-11-01', 'INV-001', 'चितवन एग्रो फार्म प्रा.लि.', 'गीतानगर, भरतपुर-०६', '९८५५0११२२३', '601245892', 34500, 10000, 24500, 'नियमित ग्राहक'],
    ['2081-11-02', 'INV-002', 'प्रगतिशिल कृषि सहकारी', 'बसन्तपुर, माडी-०३', '९८४५०१२३९९', '602334455', 22200, 7000, 15200, 'उधारो बिल'],
    ['2081-11-03', 'INV-003', 'कालिका फलफूल तथा तरकारी फार्म', 'खैरहनी-०८, चितवन', '९८५५०२३४५६', '603445566', 19800, 0, 19800, 'नगद भुक्तानी बाँकी']
  ];

  const notes = [
    ['Instructions for Customer & Transaction Excel Import:'],
    ['1. Supported columns: Date, Bill No, Customer Name, Address, Phone Number, PAN Number, Total Amount, Pay Amount, Due Amount.'],
    ['2. This automatically updates customer party ledgers and balances.'],
    []
  ];

  const worksheet = XLSX.utils.aoa_to_sheet([
    ...notes,
    headers,
    ...sampleRows
  ]);

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Customer_Transaction_Template');
  XLSX.writeFile(workbook, 'Customer_Transaction_Import_Template.xlsx');
}

/**
 * Downloads Excel Template for Purchase Records (खरिद खाता) Import
 */
export function downloadPurchaseImportTemplate() {
  const headers = [
    'मिति बि.सं. (Date B.S.)*',
    'खरिद बीजक नं. (Bill No)*',
    'आपूर्तिकर्ताको नाम (Supplier Name)*',
    'ठेगाना (Address)',
    'आपूर्तिकर्ता प्यान (Supplier PAN)',
    'सामानको विवरण (Summary)',
    'करयोग्य खरिद रकम (Taxable)',
    'कर छुट खरिद रकम (Exempt)',
    '१३% भ्याट रकम (VAT Amount)',
    'कुल खरिद रकम (Grand Total)*',
    'भुक्तानी माध्यम (CASH / BANK_FONEPAY / CREDIT)'
  ];

  const sampleRows = [
    ['2081-10-15', 'PUR-081-101', 'नेपाल एग्रो टूल्स सप्लायर्स', 'नारायणगढ, चितवन', '600123987', 'पावर टिलर तथा पम्पहरू', 120000, 0, 15600, 135600, 'BANK_FONEPAY'],
    ['2081-10-20', 'PUR-081-102', 'साल्ट ट्रेडिङ कर्पोरेशन', 'काठमाडौँ', '600000001', 'रासायनिक मल अनुदानित', 0, 45000, 0, 45000, 'CASH'],
    ['2081-11-01', 'PUR-081-103', 'किसान बिउबिजन केन्द्र', 'भरतपुर-१०', '600223344', 'हाइब्रिड मकै बिउ', 0, 24000, 0, 24000, 'BANK_FONEPAY']
  ];

  const worksheet = XLSX.utils.aoa_to_sheet([
    ['खरिद विवरण (Purchase Records) Excel Import Template'],
    [],
    headers,
    ...sampleRows
  ]);

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Purchase_Template');
  XLSX.writeFile(workbook, 'Purchase_Records_Template.xlsx');
}

/**
 * Downloads Excel Template for Sales Records (बिक्री खाता) Import
 */
export function downloadSalesImportTemplate() {
  const headers = [
    'मिति बि.सं. (Date B.S.)*',
    'बीजक नं. (Bill No)*',
    'बिल प्रकार (VAT वा NON_VAT)*',
    'खरिदकर्ता/ग्राहकको नाम (Customer Name)*',
    'ग्राहक प्यान (Buyer PAN)',
    'ठेगाना (Address)',
    'करयोग्य बिक्री रकम (Taxable)',
    'कर छुट बिक्री रकम (Exempt)',
    '१३% भ्याट रकम (VAT)',
    'कुल बिक्री रकम (Grand Total)*',
    'भुक्तानी माध्यम (CASH / BANK_FONEPAY / CREDIT)'
  ];

  const sampleRows = [
    ['2081-11-01', 'TI-081/82-0001', 'VAT', 'चितवन एग्रो फार्म प्रा.लि.', '601245892', 'गीतानगर, भरतपुर', 113274.34, 0, 14725.66, 128000, 'BANK_FONEPAY'],
    ['2081-11-02', 'NV-081/82-0001', 'NON_VAT', 'रामबहादुर चौधरी', '', 'माडी, चितवन', 0, 4700, 0, 4700, 'CASH'],
    ['2081-11-03', 'TI-081/82-0002', 'VAT', 'कालिका आधुनिक फलफूल फार्म', '603445566', 'खैरहनी-०८', 15486.73, 0, 2013.27, 17500, 'CREDIT']
  ];

  const worksheet = XLSX.utils.aoa_to_sheet([
    ['बिक्री विवरण (Sales Invoices) Excel Import Template'],
    [],
    headers,
    ...sampleRows
  ]);

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sales_Template');
  XLSX.writeFile(workbook, 'Sales_Records_Template.xlsx');
}

/**
 * Exports Address-wise Customer Outstanding Due report to Excel
 */
export function exportCustomerDuesReportToExcel(
  parties: {
    id: string;
    name: string;
    address?: string;
    phone?: string;
    panNo?: string;
    openingBalance: number;
    currentBalance: number;
  }[],
  fiscalYear: string = '081/82'
) {
  const headers = [
    'क्र.सं. (S.N.)',
    'ठेगाना / स्थान (Address / Location)',
    'ग्राहकको नाम (Customer Name)',
    'सम्पर्क फोन (Phone)',
    'प्यान/भ्याट नं. (PAN / VAT)',
    'पुरानो लिन बाँकी (Opening Due)',
    'हाल उठाउन बाँकी रकम (Net Outstanding Due Rs.)'
  ];

  // Sort by address
  const sorted = [...parties].sort((a, b) => (a.address || '').localeCompare(b.address || ''));

  const rows = sorted.map((p, idx) => [
    idx + 1,
    p.address || 'ठेगाना नखुलेको (Unspecified)',
    p.name,
    p.phone || '-',
    p.panNo || '-',
    p.openingBalance || 0,
    p.currentBalance !== undefined ? p.currentBalance : p.openingBalance
  ]);

  const totalOpening = sorted.reduce((sum, p) => sum + (p.openingBalance || 0), 0);
  const totalDue = sorted.reduce(
    (sum, p) => sum + (p.currentBalance !== undefined ? p.currentBalance : p.openingBalance),
    0
  );

  rows.push([
    'कुल जम्मा (Grand Total)',
    '',
    '',
    '',
    '',
    totalOpening,
    totalDue
  ]);

  const worksheet = XLSX.utils.aoa_to_sheet([
    [`नेपाल कृषि यन्त्र तथा औजार सप्लायर्स - ठेगाना अनुसार ग्राहक बाँकी रकम विवरण`],
    [`आर्थिक वर्ष: ${fiscalYear} | कुल ग्राहक संख्या: ${parties.length}`],
    [],
    headers,
    ...rows
  ]);

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Customer_Dues_By_Address');
  XLSX.writeFile(workbook, `Customer_Dues_By_Address_${fiscalYear.replace('/', '-')}.xlsx`);
}

/**
 * Parses user-uploaded Excel or CSV file buffer
 */
export function parseExcelFile(arrayBuffer: ArrayBuffer): { headers: string[]; rows: any[][] } {
  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];
  const rawData: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

  // Locate the header row (skip empty instruction rows)
  let headerIndex = -1;
  for (let i = 0; i < Math.min(rawData.length, 10); i++) {
    const row = rawData[i];
    if (Array.isArray(row) && row.length >= 2 && row.some((c) => typeof c === 'string' && c.trim().length > 0)) {
      // Check if this looks like a header
      const strRow = row.map((r) => String(r || '').toLowerCase());
      if (
        strRow.some((s) =>
          s.includes('name') ||
          s.includes('customer') ||
          s.includes('due') ||
          s.includes('pay') ||
          s.includes('paid') ||
          s.includes('item') ||
          s.includes('नाम') ||
          s.includes('ग्राहक') ||
          s.includes('बाँकी') ||
          s.includes('भुक्तानी') ||
          s.includes('दर') ||
          s.includes('price') ||
          s.includes('ठेगाना') ||
          s.includes('address') ||
          s.includes('मिति') ||
          s.includes('bill')
        )
      ) {
        headerIndex = i;
        break;
      }
    }
  }

  if (headerIndex === -1 && rawData.length > 0) {
    headerIndex = 0;
  }

  const headers = (rawData[headerIndex] || []).map((h) => String(h || '').trim());
  const rows = rawData.slice(headerIndex + 1).filter((r) => Array.isArray(r) && r.some((c) => c !== undefined && c !== ''));

  return { headers, rows };
}
