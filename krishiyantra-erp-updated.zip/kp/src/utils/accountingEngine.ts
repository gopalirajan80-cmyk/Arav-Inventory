import type {
  Account, AccountingData, FixedAsset, JournalEntry, JournalLine, TaxSettings, TaxSlab
} from '../types/accounting';
import type { Invoice, PurchaseRecord, PartyTransaction, Expense } from '../types';
import { getFiscalYear } from './nepaliCalendar';

export const round2 = (n: number) => Math.round((Number(n) || 0) * 100) / 100;

export const fmtMoney = (n: number) =>
  (n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// ----------------------------------------------------------------------------
// Default Chart of Accounts
// ----------------------------------------------------------------------------
const A = (
  code: string, nameNe: string, nameEn: string, type: Account['type'], isSystem = true
): Account => ({
  id: `acc-${code}`, code, nameNe, nameEn, type, isSystem, isActive: true,
  openingBalance: 0, openingSide: type === 'ASSET' || type === 'EXPENSE' ? 'DR' : 'CR'
});

export const DEFAULT_ACCOUNTS: Account[] = [
  A('1001', 'नगद मौज्दात', 'Cash in Hand', 'ASSET'),
  A('1002', 'बैंक खाता', 'Bank Accounts', 'ASSET'),
  A('1101', 'ग्राहकबाट लिनुपर्ने (देब्टर्स)', 'Accounts Receivable (Debtors)', 'ASSET'),
  A('1201', 'मौज्दात (स्टक)', 'Inventory / Stock', 'ASSET'),
  A('1301', 'भ्याट प्राप्य (इनपुट भ्याट)', 'VAT Receivable (Input VAT)', 'ASSET'),
  A('1401', 'अग्रिम कर / TDS प्राप्य', 'Advance Tax / TDS Receivable', 'ASSET'),
  A('1501', 'स्थिर सम्पत्ति (लागत)', 'Fixed Assets (Cost)', 'ASSET'),
  A('1599', 'सञ्चित ह्रासकट्टी', 'Accumulated Depreciation', 'ASSET'),
  A('2001', 'आपूर्तिकर्तालाई तिर्नुपर्ने (क्रेडिटर्स)', 'Accounts Payable (Creditors)', 'LIABILITY'),
  A('2101', 'भ्याट दायित्व (आउटपुट भ्याट)', 'VAT Payable (Output VAT)', 'LIABILITY'),
  A('2201', 'TDS तिर्नुपर्ने', 'TDS Payable', 'LIABILITY'),
  A('2301', 'ऋण / सापटी', 'Loans & Borrowings', 'LIABILITY'),
  A('2401', 'तलब तिर्नुपर्ने', 'Salary Payable', 'LIABILITY'),
  A('2501', 'आयकर दायित्व', 'Income Tax Payable', 'LIABILITY'),
  A('3001', 'पुँजी', 'Capital', 'EQUITY'),
  A('3002', 'सुरुवाती मौज्दात इक्विटी / सञ्चित नाफा', 'Opening Balance Equity / Retained Earnings', 'EQUITY'),
  A('4001', 'बिक्री आम्दानी', 'Sales Revenue', 'INCOME'),
  A('4101', 'अन्य आम्दानी', 'Other Income', 'INCOME'),
  A('5001', 'खरिद (सामानको लागत)', 'Purchases (COGS)', 'EXPENSE'),
  A('5101', 'तलब तथा ज्याला खर्च', 'Salary & Wages', 'EXPENSE'),
  A('5201', 'भाडा खर्च', 'Rent Expense', 'EXPENSE'),
  A('5301', 'ह्रासकट्टी खर्च', 'Depreciation Expense', 'EXPENSE'),
  A('5401', 'आयकर खर्च', 'Income Tax Expense', 'EXPENSE'),
  A('5999', 'अन्य सामान्य खर्च', 'General & Other Expenses', 'EXPENSE')
];

export const DEFAULT_TAX_SLABS: TaxSlab[] = [
  { width: 500000, rate: 1 },
  { width: 200000, rate: 10 },
  { width: 300000, rate: 20 },
  { width: 1000000, rate: 30 },
  { width: 3000000, rate: 36 },
  { width: null, rate: 39 }
];

export const DEFAULT_TAX_SETTINGS: TaxSettings = {
  payerType: 'COMPANY',
  customRate: 25,
  slabs: DEFAULT_TAX_SLABS
};

export const emptyAccountingData = (): AccountingData => ({
  accounts: DEFAULT_ACCOUNTS.map((a) => ({ ...a })),
  journals: [],
  assets: [],
  budgets: [],
  tds: [],
  taxSettings: { ...DEFAULT_TAX_SETTINGS, slabs: DEFAULT_TAX_SLABS.map((s) => ({ ...s })) },
  taxAdjust: {}
});

/** Merge saved data with defaults (adds any missing system accounts, tolerates old/partial data). */
export const normalizeAccountingData = (raw: any): AccountingData => {
  const base = emptyAccountingData();
  if (!raw || typeof raw !== 'object') return base;
  const accounts: Account[] = Array.isArray(raw.accounts) && raw.accounts.length > 0 ? raw.accounts : base.accounts;
  const have = new Set(accounts.map((a) => a.code));
  DEFAULT_ACCOUNTS.forEach((d) => {
    if (!have.has(d.code)) accounts.push({ ...d });
  });
  return {
    accounts,
    journals: Array.isArray(raw.journals) ? raw.journals : [],
    assets: Array.isArray(raw.assets) ? raw.assets : [],
    budgets: Array.isArray(raw.budgets) ? raw.budgets : [],
    tds: Array.isArray(raw.tds) ? raw.tds : [],
    taxSettings: raw.taxSettings && Array.isArray(raw.taxSettings.slabs) ? raw.taxSettings : base.taxSettings,
    taxAdjust: raw.taxAdjust && typeof raw.taxAdjust === 'object' ? raw.taxAdjust : {}
  };
};

// ----------------------------------------------------------------------------
// BS date helpers (strings compare correctly once normalised to YYYY-MM-DD)
// ----------------------------------------------------------------------------
const DEV: Record<string, string> = { '०': '0', '१': '1', '२': '2', '३': '3', '४': '4', '५': '5', '६': '6', '७': '7', '८': '8', '९': '9' };

export const normBs = (d?: string): string => {
  if (!d) return '';
  const s = d.replace(/[०-९]/g, (c) => DEV[c]).trim().replace(/[\/.]/g, '-');
  const m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s);
  if (!m) return '';
  return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
};

export const fyOfBs = (d?: string): string => {
  const n = normBs(d);
  return n ? getFiscalYear(n) : '';
};

const fyStartNum = (fy: string): number => {
  const first = parseInt((fy || '').split('/')[0], 10);
  if (!Number.isFinite(first)) return 0;
  return first >= 1000 ? first : 2000 + first;
};

export const fyRange = (fy: string): { from: string; to: string } => {
  const y = fyStartNum(fy);
  return { from: `${y}-04-01`, to: `${y + 1}-03-32` };
};

export const nextFy = (fy: string): string => {
  const n = parseInt((fy || '').split('/')[0], 10);
  if (!Number.isFinite(n)) return fy;
  const a = n >= 1000 ? n % 1000 : n;
  return `${String(a + 1).padStart(3, '0')}/${String((a + 2) % 100).padStart(2, '0')}`;
};

export const cmpFy = (a: string, b: string): number => fyStartNum(a) - fyStartNum(b);

/** i = 0..11 -> Shrawan..Ashadh of the fiscal year */
export const fyMonthRange = (fy: string, i: number): { from: string; to: string; label: string } => {
  const y0 = fyStartNum(fy);
  const month = ((3 + i) % 12) + 1;
  const year = month >= 4 ? y0 : y0 + 1;
  const mm = String(month).padStart(2, '0');
  const names = ['बैशाख', 'जेठ', 'असार', 'श्रावण', 'भदौ', 'असोज', 'कार्तिक', 'मंसिर', 'पौष', 'माघ', 'फागुन', 'चैत'];
  // names[] is Baisakh-first, so month 1 -> names[0]
  return { from: `${year}-${mm}-01`, to: `${year}-${mm}-32`, label: names[month - 1] };
};

// ----------------------------------------------------------------------------
// Auto-posting from Billing / Purchase / Vouchers / Expenses
// ----------------------------------------------------------------------------
const bankOrCash = (mode?: string) => (mode === 'BANK_FONEPAY' || mode === 'BANK' ? 'acc-1002' : 'acc-1001');

const mkLines = (pairs: Array<[string, number, number]>): JournalLine[] =>
  pairs
    .map(([accountId, debit, credit]) => ({ accountId, debit: round2(debit), credit: round2(credit) }))
    .filter((l) => l.debit !== 0 || l.credit !== 0);

export const buildAutoJournal = (src: {
  invoices: Invoice[];
  purchases: PurchaseRecord[];
  partyTransactions: PartyTransaction[];
  expenses: Expense[];
}): JournalEntry[] => {
  const out: JournalEntry[] = [];

  src.invoices.forEach((inv) => {
    if (inv.status !== 'ACTIVE') return;
    const gt = round2(inv.grandTotal || 0);
    if (gt === 0) return;
    const vat = round2(inv.vatAmount || 0);
    const paidRaw =
      inv.paymentMode === 'STAFF_SALARY_DEDUCT'
        ? 0
        : inv.amountPaid !== undefined
        ? inv.amountPaid
        : inv.paymentMode === 'CREDIT'
        ? 0
        : gt;
    const paid = round2(Math.max(0, paidRaw));
    const recv = round2(gt - paid);
    const pairs: Array<[string, number, number]> = [
      [bankOrCash(inv.paymentMode), paid, 0],
      ['acc-1101', recv > 0 ? recv : 0, recv < 0 ? -recv : 0],
      ['acc-4001', 0, gt - vat],
      ['acc-2101', 0, vat]
    ];
    out.push({
      id: `auto-inv-${inv.id}`, voucherNo: inv.invoiceNo, dateBs: normBs(inv.dateBs),
      narration: `बिक्री बिल — ${inv.customerName}`, lines: mkLines(pairs), source: 'AUTO'
    });
  });

  src.purchases.forEach((p) => {
    const gt = round2(p.grandTotal || 0);
    if (gt === 0) return;
    const vat = round2(p.vatAmount || 0);
    const counter = p.paymentMode === 'CREDIT' ? 'acc-2001' : bankOrCash(p.paymentMode);
    out.push({
      id: `auto-pur-${p.id}`, voucherNo: p.purchaseBillNo, dateBs: normBs(p.dateBs),
      narration: `खरिद बिल — ${p.supplierName}`,
      lines: mkLines([['acc-5001', gt - vat, 0], ['acc-1301', vat, 0], [counter, 0, gt]]), source: 'AUTO'
    });
  });

  src.partyTransactions.forEach((t) => {
    const amt = round2(t.amount || 0);
    if (amt === 0) return;
    const cash = bankOrCash(t.paymentMode);
    let pairs: Array<[string, number, number]>;
    let narr: string;
    if (t.type === 'COLLECTION_FROM_CUSTOMER') {
      const credit = t.incomeType === 'OTHER_INCOME' ? 'acc-4101' : t.incomeType === 'LOAN_RECEIVED' ? 'acc-2301' : 'acc-1101';
      pairs = [[cash, amt, 0], [credit, 0, amt]];
      narr = `प्राप्ति — ${t.partyName}`;
    } else {
      pairs = [['acc-2001', amt, 0], [cash, 0, amt]];
      narr = `भुक्तानी — ${t.partyName}`;
    }
    out.push({
      id: `auto-ptx-${t.id}`, voucherNo: t.referenceNo || `PT-${t.id.slice(-6)}`, dateBs: normBs(t.dateBs),
      narration: narr, lines: mkLines(pairs), source: 'AUTO'
    });
  });

  src.expenses.forEach((e) => {
    const amt = round2(e.amount || 0);
    if (amt === 0) return;
    const cat = `${e.category || ''} ${e.description || ''}`.toLowerCase();
    const acc = /salary|wage|तलब|ज्याला/.test(cat) ? 'acc-5101' : /rent|भाडा/.test(cat) ? 'acc-5201' : 'acc-5999';
    out.push({
      id: `auto-exp-${e.id}`, voucherNo: e.voucherNo || `EX-${e.id.slice(-6)}`, dateBs: normBs(e.dateBs),
      narration: `खर्च — ${e.category || ''} ${e.paidTo ? '(' + e.paidTo + ')' : ''}`.trim(),
      lines: mkLines([[acc, amt, 0], [bankOrCash(e.paymentMode), 0, amt]]), source: 'AUTO'
    });
  });

  return out.filter((j) => j.dateBs && j.lines.length > 0);
};

// ----------------------------------------------------------------------------
// Ledger / Trial Balance
// ----------------------------------------------------------------------------
export interface TbRow {
  account: Account;
  openingDr: number; openingCr: number;
  periodDr: number; periodCr: number;
  closingDr: number; closingCr: number;
}

const signedOpening = (a: Account) => (a.openingSide === 'DR' ? 1 : -1) * (a.openingBalance || 0);

export const computeTrialBalance = (
  accounts: Account[], entries: JournalEntry[], from: string, to: string
): { rows: TbRow[]; totals: Omit<TbRow, 'account'> } => {
  const pre: Record<string, number> = {};
  const dr: Record<string, number> = {};
  const cr: Record<string, number> = {};
  entries.forEach((e) => {
    const d = normBs(e.dateBs);
    if (!d || d > to) return;
    e.lines.forEach((l) => {
      if (d < from) pre[l.accountId] = (pre[l.accountId] || 0) + l.debit - l.credit;
      else {
        dr[l.accountId] = (dr[l.accountId] || 0) + l.debit;
        cr[l.accountId] = (cr[l.accountId] || 0) + l.credit;
      }
    });
  });
  const rows: TbRow[] = [];
  const totals = { openingDr: 0, openingCr: 0, periodDr: 0, periodCr: 0, closingDr: 0, closingCr: 0 };
  accounts
    .slice()
    .sort((a, b) => a.code.localeCompare(b.code))
    .forEach((a) => {
      const open = round2(signedOpening(a) + (pre[a.id] || 0));
      const pdr = round2(dr[a.id] || 0);
      const pcr = round2(cr[a.id] || 0);
      const close = round2(open + pdr - pcr);
      if (open === 0 && pdr === 0 && pcr === 0) return;
      const row: TbRow = {
        account: a,
        openingDr: open > 0 ? open : 0, openingCr: open < 0 ? -open : 0,
        periodDr: pdr, periodCr: pcr,
        closingDr: close > 0 ? close : 0, closingCr: close < 0 ? -close : 0
      };
      rows.push(row);
      (Object.keys(totals) as Array<keyof typeof totals>).forEach((k) => {
        totals[k] = round2(totals[k] + (row as any)[k]);
      });
    });
  return { rows, totals };
};

export interface LedgerRow {
  dateBs: string; voucherNo: string; narration: string; debit: number; credit: number; balance: number; source: string;
}

export const buildAccountLedger = (
  account: Account, entries: JournalEntry[], from: string, to: string
): { opening: number; rows: LedgerRow[]; closing: number } => {
  let opening = signedOpening(account);
  const lines: Array<{ d: string; e: JournalEntry; l: JournalLine }> = [];
  entries.forEach((e) => {
    const d = normBs(e.dateBs);
    if (!d || d > to) return;
    e.lines.forEach((l) => {
      if (l.accountId !== account.id) return;
      if (d < from) opening += l.debit - l.credit;
      else lines.push({ d, e, l });
    });
  });
  lines.sort((a, b) => (a.d === b.d ? a.e.voucherNo.localeCompare(b.e.voucherNo) : a.d.localeCompare(b.d)));
  let bal = round2(opening);
  const rows = lines.map(({ d, e, l }) => {
    bal = round2(bal + l.debit - l.credit);
    return { dateBs: d, voucherNo: e.voucherNo, narration: l.note || e.narration, debit: l.debit, credit: l.credit, balance: bal, source: e.source };
  });
  return { opening: round2(opening), rows, closing: bal };
};

/** Net activity of an account in a period (income: credit-debit, expense: debit-credit, others: debit-credit). */
export const accountActivity = (
  account: Account, entries: JournalEntry[], from: string, to: string
): number => {
  let dr = 0, cr = 0;
  entries.forEach((e) => {
    const d = normBs(e.dateBs);
    if (!d || d < from || d > to) return;
    e.lines.forEach((l) => {
      if (l.accountId === account.id) { dr += l.debit; cr += l.credit; }
    });
  });
  return round2(account.type === 'INCOME' ? cr - dr : dr - cr);
};

// ----------------------------------------------------------------------------
// Fixed asset depreciation
// ----------------------------------------------------------------------------
export interface DepRow { fy: string; opening: number; dep: number; closing: number; accumulated: number }

export const computeDepreciation = (asset: FixedAsset, upToFy: string): DepRow[] => {
  const rows: DepRow[] = [];
  const start = asset.depStartFy || fyOfBs(asset.purchaseDateBs);
  if (!start) return rows;
  const endFy =
    asset.status === 'DISPOSED' && asset.disposalDateBs
      ? (cmpFy(fyOfBs(asset.disposalDateBs), upToFy) < 0 ? fyOfBs(asset.disposalDateBs) : upToFy)
      : upToFy;
  let fy = start;
  let opening = round2(asset.cost - (asset.openingAccumDep || 0));
  let accumulated = round2(asset.openingAccumDep || 0);
  const salvage = asset.salvageValue || 0;
  let guard = 0;
  while (cmpFy(fy, endFy) <= 0 && guard++ < 80) {
    const room = Math.max(0, opening - salvage);
    const raw =
      asset.method === 'WDV'
        ? (opening * (asset.ratePct || 0)) / 100
        : ((asset.cost - salvage) / Math.max(1, asset.usefulLifeYears || 1));
    let dep = round2(Math.min(room, Math.max(0, raw)));
    if (asset.method === 'SLM' && room - dep < 0.05) dep = round2(room); // paise rounding leftover
    const closing = round2(opening - dep);
    accumulated = round2(accumulated + dep);
    rows.push({ fy, opening, dep, closing, accumulated });
    opening = closing;
    fy = nextFy(fy);
  }
  return rows;
};

// ----------------------------------------------------------------------------
// TDS / Income tax
// ----------------------------------------------------------------------------
export const TDS_PRESETS: Array<{ key: string; ne: string; en: string; rate: number }> = [
  { key: 'SERVICE', ne: 'सेवा शुल्क / ठेक्का (PAN सहित)', en: 'Service fee / contract (with PAN)', rate: 1.5 },
  { key: 'SERVICE_NOPAN', ne: 'सेवा शुल्क (PAN नभएको)', en: 'Service fee (no PAN)', rate: 15 },
  { key: 'RENT', ne: 'भाडा', en: 'Rent', rate: 10 },
  { key: 'COMMISSION', ne: 'कमिसन', en: 'Commission', rate: 15 },
  { key: 'INTEREST', ne: 'ब्याज', en: 'Interest', rate: 15 },
  { key: 'DIVIDEND', ne: 'लाभांश', en: 'Dividend', rate: 5 },
  { key: 'SALARY', ne: 'तलब (कर्मचारी)', en: 'Salary (employee)', rate: 1 },
  { key: 'OTHER', ne: 'अन्य', en: 'Other', rate: 0 }
];

export const computeSlabTax = (income: number, slabs: TaxSlab[]): Array<{ from: number; amount: number; rate: number; tax: number }> => {
  const out: Array<{ from: number; amount: number; rate: number; tax: number }> = [];
  let remaining = Math.max(0, income);
  let from = 0;
  for (const s of slabs) {
    if (remaining <= 0) break;
    const amt = s.width === null ? remaining : Math.min(remaining, s.width);
    out.push({ from, amount: round2(amt), rate: s.rate, tax: round2((amt * s.rate) / 100) });
    remaining -= amt;
    from += amt;
  }
  return out;
};

// ----------------------------------------------------------------------------
// CSV
// ----------------------------------------------------------------------------
export const downloadCsv = (filename: string, rows: Array<Array<string | number>>) => {
  const esc = (v: string | number) => {
    const s = String(v ?? '');
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = '﻿' + rows.map((r) => r.map(esc).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; document.body.appendChild(a); a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};
