// GPS Utility for Geofencing & Distance Calculation
// Enforces Owner-defined workplace location radius for employee attendance

/**
 * Calculates distance between two GPS coordinates in meters using the Haversine formula
 */
export function calculateGpsDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371e3; // Earth radius in meters
  const toRad = (x: number) => (x * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

/**
 * Checks if device location is within allowed radius of workplace
 */
export function isWithinWorkplaceGeofence(
  deviceLat: number,
  deviceLon: number,
  workplaceLat?: number,
  workplaceLon?: number,
  allowedRadiusMeters: number = 200
): {
  isAllowed: boolean;
  distanceMeters: number;
  messageNe: string;
  messageEn: string;
} {
  // If workplace GPS has not been set yet by owner, allow with notice
  if (!workplaceLat || !workplaceLon) {
    return {
      isAllowed: true,
      distanceMeters: 0,
      messageNe: 'मालिकले अझै निश्चित GPS तोक्नुभएको छैन। हाजिरी दर्ता गरियो।',
      messageEn: 'Workplace GPS not yet pinned by owner. Attendance permitted.'
    };
  }

  const distance = calculateGpsDistanceMeters(deviceLat, deviceLon, workplaceLat, workplaceLon);
  const isAllowed = distance <= allowedRadiusMeters;

  return {
    isAllowed,
    distanceMeters: distance,
    messageNe: isAllowed
      ? `तपाईं कार्यस्थल क्षेत्रभित्र हुनुहुन्छ (${distance} मिटर दूरी)। हाजिरी स्वीकृत भयो !`
      : `तपाईं कार्यस्थल भन्दा ${distance} मिटर टाढा हुनुहुन्छ। मालिकले तोकेको परिधि (${allowedRadiusMeters} मिटर) भित्र मात्र हाजिर गर्न सकिन्छ !`,
    messageEn: isAllowed
      ? `Within workplace zone (${distance}m away). Verified!`
      : `Outside workplace zone (${distance}m away). Must be within ${allowedRadiusMeters}m.`
  };
}

/**
 * Fetches current device GPS coordinates
 */
export function getCurrentDeviceGps(): Promise<{ lat: number; lng: number }> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      // Fallback default coordinates (Kathmandu Store HQ)
      resolve({ lat: 27.7172, lng: 85.3240 });
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        resolve({
          lat: Math.round(pos.coords.latitude * 10000) / 10000,
          lng: Math.round(pos.coords.longitude * 10000) / 10000
        });
      },
      () => {
        // Fallback default
        resolve({ lat: 27.7172, lng: 85.3240 });
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  });
}
