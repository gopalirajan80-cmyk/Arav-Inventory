import { getServerUser, isStaffLogin, clearToken } from '../utils/auth';
import React, { createContext, useContext, useState, useEffect, useMemo, useRef } from 'react';
import {
  Item,
  Invoice,
  PurchaseRecord,
  Party,
  PartyTransaction,
  Employee,
  AttendanceRecord,
  AttendanceGroup,
  EmployeeLedgerEntry,
  DailyCashRecord,
  BankAccount,
  CompanyProfile,
  Language,
  UserRole,
  BillType,
  PaymentMode,
  InvoiceItem,
  RawMaterial,
  ProductionBatch,
  ProductionStage,
  DispatchRecord,
  CompanyAccount,
  CompanyDirectoryEntry,
  RecurringInvoice,
  AccountStatus,
  AuditLogEntry,
  AuditActionType,
  StaffWorkCategory,
  Expense,
  Machine,
  MaintenanceLog,
  MachineWorker,
  BranchOffice,
  FieldOrder,
  FieldOrderStatus,
  Quotation,
  BillOfMaterial,
  ProductionOrder,
  ProductionOrderStatus
} from '../types';
import {
  DEFAULT_COMPANY,
  DEFAULT_BANK_ACCOUNTS,
  SAMPLE_AGRICULTURE_ITEMS,
  SAMPLE_EMPLOYEES,
  SAMPLE_PARTIES,
  SAMPLE_PARTY_TRANSACTIONS,
  SAMPLE_PURCHASES,
  SAMPLE_INVOICES,
  SAMPLE_RAW_MATERIALS,
  SAMPLE_PRODUCTION_BATCHES,
  SAMPLE_COMPANY_ACCOUNTS,
  SAMPLE_AUDIT_LOGS,
  SAMPLE_MACHINES,
  STORAGE_KEYS,
  loadStoredData,
  saveStoredData
} from '../utils/storage';
import { isCustomerParty, isSupplierParty } from '../utils/partyTxn';
import { getTodayBsString, getTodayAdString, getFiscalYear, adToBs, formatBsDate, resolveDatePair, bsStringToAdString } from '../utils/nepaliCalendar';
import { calculateInvoiceTotals } from '../utils/vatCalculator';
import { translations } from '../utils/translations';
import { syncCompanyDataToCloud, fetchCompanyDataFromCloud } from '../utils/firebaseSync';

interface CreateInvoiceParams {
  billType: BillType;
  manualInvoiceNo?: string; // प्रयोगकर्ताले आफैँ राखेको बिल नं. (Manual Bill No)
  customerName: string;
  customerPan?: string;
  customerAddress?: string;
  customerPhone?: string;
  partyId?: string;
  isEmployeePurchase?: boolean;
  employeeId?: string;
  employeeName?: string;
  previousDue?: number;
  amountPaid?: number; // आज बुझाएको रकम
  paymentDueDate?: string; // रकम बुझाउने अन्तिम म्याद
  deductStock?: boolean; // स्टक घटाउने (default true)
  items: InvoiceItem[];
  discountPercent: number;
  freightCharge: number;
  paymentMode: PaymentMode;
  bankName?: string;
  bankAccountNo?: string;
  transactionRef?: string;
  photoUrl?: string; // संलग्न बिल / रसिद / सामानको फोटो
  notes?: string;
  billedBy?: string; // बिल तयार गर्ने व्यक्तिको नाम
  customDateBs?: string; // बिल काट्ने म्यानुअल मिति (Manual B.S. Date)
  customDateAd?: string;
  manualExemptAmount?: number | null; // म्यानुअल कर छुट रकम (Manual Non-Taxable / Exempt Amount)
}

interface AppContextType {
  // State
  items: Item[];
  invoices: Invoice[]; // बन्द भइसकेको आ.व. का रेकर्ड लुकाइएको (सक्रिय आ.व. अनुसार)
  purchases: PurchaseRecord[];
  parties: Party[];
  partyTransactions: PartyTransaction[];
  // बन्द आ.व. सहितका पूरा रेकर्ड (ब्याकअप/सिङ्कका लागि मात्र)
  allInvoices: Invoice[];
  allPurchases: PurchaseRecord[];
  allPartyTransactions: PartyTransaction[];
  allExpenses: Expense[];
  bankAccounts: BankAccount[];
  employees: Employee[];
  attendance: AttendanceRecord[];
  employeeLedger: EmployeeLedgerEntry[];
  company: CompanyProfile;
  dailyCash: DailyCashRecord;
  rawMaterials: RawMaterial[];
  productionBatches: ProductionBatch[];
  recurringInvoices: RecurringInvoice[];
  language: Language;
  currentRole: UserRole;
  activeTab: string;
  isOnline: boolean;
  t: typeof translations['ne'];

  // Multi-Company Management (फरक-फरक कम्पनी व्यवस्थापन)
  companiesList: CompanyDirectoryEntry[];
  activeCompanyId: string;
  switchCompany: (companyId: string) => void;
  createNewCompany: (params: {
    name: string;
    panVatNo?: string;
    address?: string;
    phone?: string;
    tagline?: string;
    logoUrl?: string;
    includeStarterCatalog?: boolean;
  }) => CompanyDirectoryEntry;
  deleteCompanyById: (companyId: string, ownerPin?: string) => { success: boolean; message: string };

  // Company Mobile Accounts & Multi-tenant Login
  companyAccounts: CompanyAccount[];
  currentAccount: CompanyAccount | null;
  loginWithMobile: (mobileNumber: string, pin?: string, role?: UserRole) => { success: boolean; message: string; account?: CompanyAccount };
  registerMobileAccount: (data: {
    mobileNumber: string;
    companyName: string;
    ownerName: string;
    panVatNo?: string;
    address?: string;
    pin?: string;
    requestedRole?: UserRole;
  }) => { success: boolean; message: string };
  approveAccount: (accountId: string, role?: UserRole) => void;
  rejectAccount: (accountId: string) => void;
  resetAccountPin: (accountId: string, newPin: string) => { success: boolean; message: string };
  saveCompanyAccount: (accountData: {
    id?: string;
    companyId?: string;
    mobileNumber: string;
    companyName: string;
    ownerName: string;
    panVatNo?: string;
    address?: string;
    assignedRole: UserRole;
    pin?: string;
    status?: AccountStatus;
    allowedTabs?: string[];
  }) => { success: boolean; message: string };
  deleteCompanyAccount: (accountId: string) => { success: boolean; message: string };
  logoutAccount: () => void;
  updatePermissions: (accountId: string, allowedTabs: string[]) => void;
  checkPermission: (tabId: string) => boolean;

  // Setters & Actions
  setLanguage: (lang: Language) => void;
  setCurrentRole: (role: UserRole) => void;
  setActiveTab: (tab: string) => void;

  // Manufacturing & Production
  saveRawMaterial: (material: RawMaterial) => void;
  deleteRawMaterial: (id: string) => void;
  saveProductionBatch: (batch: ProductionBatch) => void;
  deleteProductionBatch: (batchId: string) => void;
  updateBatchStage: (batchId: string, newStage: ProductionStage, additionalDetails?: Partial<ProductionBatch>) => void;
  recordDispatch: (batchId: string | null | undefined, dispatch: Omit<DispatchRecord, 'id'>) => void;
  updateDispatchStatus: (batchId: string | null | undefined, dispatchId: string, status: 'IN_TRANSIT' | 'DELIVERED') => void;
  approveDispatch: (batchId: string | null | undefined, dispatchId: string, approvedBy: string) => void;
  saveRecurringInvoice: (ri: RecurringInvoice) => void;
  deleteRecurringInvoice: (id: string) => void;
  
  // Machine Management
  machines: Machine[];
  // फिल्ड अर्डर (Field Orders)
  fieldOrders: FieldOrder[];
  saveFieldOrder: (order: FieldOrder) => void;
  deleteFieldOrder: (id: string) => void;
  updateFieldOrderStatus: (id: string, status: FieldOrderStatus, extra?: Partial<FieldOrder>, note?: string) => void;
  getNextFieldOrderNo: () => string;
  quotations: Quotation[];
  saveQuotation: (q: Quotation) => void;
  deleteQuotation: (id: string) => void;
  getNextQuotationNo: () => string;
  // उत्पादन सूत्र (BOM) तथा उत्पादन आदेश
  boms: BillOfMaterial[];
  saveBom: (bom: BillOfMaterial) => void;
  deleteBom: (id: string) => void;
  productionOrders: ProductionOrder[];
  saveProductionOrder: (order: ProductionOrder) => void;
  deleteProductionOrder: (id: string) => void;
  getNextProductionOrderNo: () => string;
  releaseProductionOrder: (orderId: string, force?: boolean) => { ok: boolean; message: string; batch?: ProductionBatch };
  completeProductionOrder: (orderId: string) => void;
  saveMachine: (machine: Machine) => void;
  deleteMachine: (id: string) => void;
  addMaintenanceLog: (log: MaintenanceLog) => void;
  assignMachineWorker: (worker: MachineWorker) => void;

  // Billing & Quick Actions & Module Sub-Tabs
  createInvoice: (params: CreateInvoiceParams) => Invoice;
  // बिल सच्याउने (सामान सहित) — स्टक/बैंक/पार्टी बाँकी पुरानो असर हटाएर नयाँ लागू गर्छ, उही बिल नं. मै अपडेट हुन्छ
  updateInvoice: (
    invoiceId: string,
    params: CreateInvoiceParams,
    callbacks?: { onSuccess?: (inv: Invoice) => void; onError?: (message: string) => void; onCancel?: () => void }
  ) => void;
  invoiceToEdit: Invoice | null;
  startEditInvoice: (invoiceId: string) => void;
  clearInvoiceToEdit: () => void;
  cancelInvoice: (invoiceId: string) => void;
  deleteInvoice: (invoiceId: string) => void;
  billingSubTab: 'SALES' | 'PURCHASE' | 'PAYMENT_IN' | 'PAYMENT_OUT' | 'SALES_RETURN' | 'PURCHASE_RETURN' | 'RECURRING';
  setBillingSubTab: (subTab: 'SALES' | 'PURCHASE' | 'PAYMENT_IN' | 'PAYMENT_OUT' | 'SALES_RETURN' | 'PURCHASE_RETURN' | 'RECURRING') => void;
  manufacturingSubTab: 'OVERVIEW' | 'BATCHES' | 'RAW_MATERIALS' | 'WIP_MACHINE' | 'FINISHED_GOODS' | 'PACKAGING' | 'DISPATCHED' | 'MACHINES' | 'REPORTS' | 'BOM' | 'PLANNING';
  setManufacturingSubTab: (subTab: 'OVERVIEW' | 'BATCHES' | 'RAW_MATERIALS' | 'WIP_MACHINE' | 'FINISHED_GOODS' | 'PACKAGING' | 'DISPATCHED' | 'MACHINES' | 'REPORTS' | 'BOM' | 'PLANNING') => void;
  ledgerSubTab: 'ALL' | 'CUSTOMER' | 'SUPPLIER' | 'DUE_ONLY' | 'ADD_PARTY';
  setLedgerSubTab: (subTab: 'ALL' | 'CUSTOMER' | 'SUPPLIER' | 'DUE_ONLY' | 'ADD_PARTY') => void;
  inventorySubTab: 'ALL' | 'ADD_ITEM' | 'RECONCILE' | 'LOW_STOCK' | 'RAW_MATERIALS' | 'FINISHED_GOODS';
  setInventorySubTab: (subTab: 'ALL' | 'ADD_ITEM' | 'RECONCILE' | 'LOW_STOCK' | 'RAW_MATERIALS' | 'FINISHED_GOODS') => void;
  reportSubTab: string;
  setReportSubTab: (subTab: string) => void;
  attendanceSubTab: string;
  setAttendanceSubTab: (subTab: string) => void;
  voucherSubTab: 'COLLECTION' | 'PAYMENT' | 'CUSTOMERS' | 'EXPENSES' | 'CASH_BOOK' | 'BANK_RECONCILIATION';
  setVoucherSubTab: (subTab: 'COLLECTION' | 'PAYMENT' | 'CUSTOMERS' | 'EXPENSES' | 'CASH_BOOK' | 'BANK_RECONCILIATION') => void;
  logisticsSubTab: 'DASHBOARD' | 'DISPATCH_LOG' | 'PENDING_APPROVAL' | 'DRIVER_REPORT';
  setLogisticsSubTab: (subTab: 'DASHBOARD' | 'DISPATCH_LOG' | 'PENDING_APPROVAL' | 'DRIVER_REPORT') => void;
  independentDispatches: DispatchRecord[];
  openPurchaseModalSignal: number;
  triggerQuickPurchase: () => void;
  openDispatchModalSignal: number;
  preselectedBillId: string;
  preselectedBillType: 'SALES' | 'PURCHASE';
  triggerQuickDispatch: (billId: string, type: 'SALES' | 'PURCHASE') => void;

  // Audit Trail (Super Admin)
  auditLogs: AuditLogEntry[];
  logAuditAction: (params: {
    actionType: AuditActionType;
    module: AuditLogEntry['module'];
    severity?: AuditLogEntry['severity'];
    targetId?: string;
    summaryNe: string;
    summaryEn: string;
    details?: string;
  }) => void;
  clearAuditLogs: () => void;
  
  // Inventory
  saveItem: (item: Item) => void;
  deleteItem: (itemId: string) => void;
  adjustStock: (itemId: string, newStock: number) => void;
  reconcileItemStock: (
    itemId: string,
    params: {
      adjustmentQty: number;
      isAbsolute?: boolean;
      reason: string;
      vatStock?: number;
      nonVatStock?: number;
    }
  ) => void;
  
  // Purchases
  recordPurchase: (
    purchase: Omit<PurchaseRecord, 'id'>,
    supplierMeta?: {
      partyId?: string;
      address?: string;
      phone?: string;
      amountPaidToday?: number;
    }
  ) => PurchaseRecord;
  deletePurchase: (purchaseId: string) => void;
  
  // Parties & Credit Ledgers & Transactions
  saveParty: (party: Party) => void;
  deleteParty: (partyId: string) => void;
  updatePartyBalance: (partyId: string, additionalAmount: number) => void;
  recordPartyPayment: (params: {
    partyId: string;
    amount: number;
    dateBs?: string;
    paymentMode: 'CASH' | 'BANK';
    bankAccountId?: string;
    referenceNo?: string;
    notes?: string;
  }) => void;
  recordCustomerCollection: (params: {
    partyId?: string;
    partyName?: string;
    partyPhone?: string;
    partyAddress?: string;
    incomeType?: 'CUSTOMER_COLLECTION' | 'OTHER_INCOME' | 'LOAN_RECEIVED';
    incomeCategory?: string;
    dateBs?: string;
    amount: number;
    paymentMode: 'CASH' | 'BANK';
    bankAccountId?: string;
    referenceNo?: string;
    notes?: string;
  }) => void;
  getPartyOutstandingDue: (partyId: string) => number;
  settleCustomerBankPayment: (params: {
    partyId?: string;
    partyName: string;
    partyPhone?: string;
    amount: number;
    bankAccountId: string;
    referenceNo: string;
    invoiceIds?: string[];
    dateBs?: string;
    notes?: string;
  }) => {
    success: boolean;
    message: string;
    reconciledInvoicesCount: number;
    allocatedAmount: number;
    newBankBalance: number;
    newCustomerBalance: number;
    settledInvoiceNumbers: string[];
  };

  // Banking
  saveBankAccount: (account: BankAccount) => void;
  deleteBankAccount: (id: string) => void;
  recordManualBankEntry: (entry: {
    bankAccountId: string;
    dateBs: string;
    type: 'DEPOSIT' | 'WITHDRAWAL' | 'INTEREST' | 'BANK_CHARGE';
    amount: number;
    referenceNo?: string;
    particulars: string;
  }) => void;
  
  // Expenses
  expenses: Expense[];
  recordExpense: (expense: Omit<Expense, 'id'>) => void;
  deleteExpense: (id: string) => void;
  deletePartyTransaction: (id: string) => void;

  // Attendance & Staff Ledger
  recordAttendance: (params: {
    employeeId: string;
    type: 'IN' | 'OUT';
    latitude?: number;
    longitude?: number;
    locationLabel?: string;
    workCategory?: StaffWorkCategory;
    workDescription?: string;
    siteOrClientName?: string;
    customDateBs?: string;
    photoUrl?: string;
    verificationMethod?: 'FINGERPRINT' | 'FACE_PHOTO' | 'MANUAL_SUPERVISOR' | 'GPS_AUTO';
    deviceType?: 'MOBILE' | 'DESKTOP' | 'SUPERVISOR';
  }) => { success: boolean; message: string };
  saveEmployee: (emp: Employee) => void;
  deleteEmployee: (employeeId: string) => void;
  enrollEmployeeFingerprint: (employeeId: string, fingerName: string) => { success: boolean; message: string };
  enrollEmployeeBiometrics: (
    employeeId: string,
    params: {
      photoUrl?: string;
      fingerName?: string;
    }
  ) => { success: boolean; message: string };
  setEmployeeAttendanceStatus: (
    employeeId: string,
    status: 'PRESENT' | 'ABSENT' | 'HALF_DAY' | 'LEAVE',
    notes?: string,
    workOptions?: {
      workCategory?: StaffWorkCategory;
      workDescription?: string;
      siteOrClientName?: string;
      customDateBs?: string;
    }
  ) => { success: boolean; message: string };
  recordCashAdvance: (employeeId: string, amount: number, notes?: string) => void;
  payEmployeeSalary: (params: {
    employeeId: string;
    amount: number;
    paymentMode: 'CASH' | 'BANK';
    bankAccountId?: string;
    wageType: 'MONTHLY' | 'DAILY';
    daysWorked?: number;
    notes?: string;
  }) => void;
  getEmployeePayrollSummary: (employeeId: string) => {
    wageType: 'MONTHLY' | 'DAILY';
    monthlySalary: number;
    dailyWageRate: number;
    presentDays: number;
    absentDays: number;
    halfDays: number;
    leaveDays: number;
    effectiveDays: number;
    grossSalary: number;
    openingDue: number;
    purchasesTotal: number;
    cashAdvancesTotal: number;
    salaryPaidTotal: number;
    totalDeductions: number;
    netPayable: number;
  };

  // Daily Cash Counter
  updateOpeningCash: (amount: number) => void;

  // Fiscal Year Closing
  lockDateBs: string | undefined;
  setLockDate: (dateBs: string) => void;
  closeFiscalYear: (newFiscalYear: string, reopenCode?: string) => void;
  isFiscalYearClosed: (fy: string) => boolean;
  setFiscalReopenCode: (newCode: string, currentCode?: string) => { success: boolean; message: string };

  // Owner Security & PIN (डाटा मेटाउँदा वा सच्याउँदा अनिवार्य मालिक साँचो)
  verifyOwnerPin: (pin: string) => boolean;
  setOwnerPin: (newPin: string) => void;
  requireOwnerKey: (actionLabel: string, onVerified: () => void, actionType?: 'EDIT' | 'DELETE') => void;
  deleteCompany: (ownerPin: string) => { success: boolean; message: string };

  // Supervisor Group Attendance
  bulkRecordAttendance: (params: {
    employeeIds: string[];
    type: 'IN' | 'OUT' | 'ABSENT' | 'LEAVE';
    photoUrl?: string;
    locationLabel?: string;
    workCategory?: StaffWorkCategory;
    workDescription?: string;
    siteOrClientName?: string;
    customDateBs?: string;
    verificationMethod?: 'FINGERPRINT' | 'FACE_PHOTO' | 'MANUAL_SUPERVISOR';
  }) => { recordedCount: number; skippedCount: number };

  saveAttendanceGroup: (group: AttendanceGroup) => void;
  deleteAttendanceGroup: (groupId: string) => void;

  // Settings & Sync
  updateCompanyProfile: (profile: CompanyProfile, skipOwnerKeyPrompt?: boolean) => void;
  addBankAccount: (bank: BankAccount) => void;
  loadAgricultureStarterCatalog: () => void;
  clearAllData: () => void;
  exportFullBackup: () => void;
  restoreFullBackup: (jsonString: string) => boolean;
  importItemsList: (newItems: Item[]) => void;
  importPartiesList: (newParties: Party[]) => void;
  importPurchasesList: (newPurchases: PurchaseRecord[]) => void;
  fiscalYearsList: string[];
  selectFiscalYear: (fy: string) => { success: boolean; message: string; needsCode?: boolean };
  addNewFiscalYear: (fy: string) => { success: boolean; message: string };
  importInvoicesList: (newInvoices: Invoice[]) => void;
  syncToCloudNow: () => Promise<{ success: boolean; message: string }>;
  pullFromCloudNow: () => Promise<{ success: boolean; message: string }>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const COMPANIES_LIST_STORAGE_KEY = 'krishiyantra_companies_list_v1';
const ACTIVE_COMPANY_ID_STORAGE_KEY = 'krishiyantra_active_company_id_v1';

const getCompanyScopedKey = (baseKey: string, companyId: string): string => {
  if (!companyId || companyId === 'comp-default') return baseKey;
  return `${baseKey}__${companyId}`;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeCompanyId, setActiveCompanyId] = useState<string>(() =>
    loadStoredData<string>(ACTIVE_COMPANY_ID_STORAGE_KEY, 'comp-default')
  );

  const [companiesList, setCompaniesList] = useState<CompanyDirectoryEntry[]>(() => {
    const storedList = loadStoredData<CompanyDirectoryEntry[]>(COMPANIES_LIST_STORAGE_KEY, []);
    if (Array.isArray(storedList) && storedList.length > 0) {
      return storedList;
    }
    const baseComp = loadStoredData<CompanyProfile>(STORAGE_KEYS.COMPANY, DEFAULT_COMPANY);
    return [
      {
        id: 'comp-default',
        name: baseComp.name || DEFAULT_COMPANY.name,
        panVatNo: baseComp.panVatNo || DEFAULT_COMPANY.panVatNo,
        address: baseComp.address || DEFAULT_COMPANY.address,
        phone: baseComp.phone || DEFAULT_COMPANY.phone,
        tagline: baseComp.tagline || DEFAULT_COMPANY.tagline,
        logoUrl: baseComp.logoUrl,
        createdAtBs: '2081-01-01'
      }
    ];
  });

  const [items, setItems] = useState<Item[]>(() =>
    loadStoredData(
      getCompanyScopedKey(STORAGE_KEYS.ITEMS, activeCompanyId),
      activeCompanyId === 'comp-default' ? SAMPLE_AGRICULTURE_ITEMS : []
    )
  );
  const [invoices, setInvoices] = useState<Invoice[]>(() =>
    loadStoredData(
      getCompanyScopedKey(STORAGE_KEYS.INVOICES, activeCompanyId),
      activeCompanyId === 'comp-default' ? SAMPLE_INVOICES : []
    )
  );
  const [purchases, setPurchases] = useState<PurchaseRecord[]>(() =>
    loadStoredData(
      getCompanyScopedKey(STORAGE_KEYS.PURCHASES, activeCompanyId),
      activeCompanyId === 'comp-default' ? SAMPLE_PURCHASES : []
    )
  );
  const [parties, setParties] = useState<Party[]>(() =>
    loadStoredData(
      getCompanyScopedKey(STORAGE_KEYS.PARTIES, activeCompanyId),
      activeCompanyId === 'comp-default' ? SAMPLE_PARTIES : []
    )
  );
  const [employees, setEmployees] = useState<Employee[]>(() =>
    loadStoredData(
      getCompanyScopedKey(STORAGE_KEYS.EMPLOYEES, activeCompanyId),
      activeCompanyId === 'comp-default' ? SAMPLE_EMPLOYEES : []
    )
  );
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() =>
    loadStoredData(getCompanyScopedKey(STORAGE_KEYS.ATTENDANCE, activeCompanyId), [])
  );
  const [employeeLedger, setEmployeeLedger] = useState<EmployeeLedgerEntry[]>(() =>
    loadStoredData(getCompanyScopedKey(STORAGE_KEYS.EMPLOYEE_LEDGER, activeCompanyId), [])
  );
  const [company, setCompany] = useState<CompanyProfile>(() =>
    loadStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), DEFAULT_COMPANY)
  );

  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() =>
    loadStoredData(
      getCompanyScopedKey(STORAGE_KEYS.BANK_ACCOUNTS, activeCompanyId),
      activeCompanyId === 'comp-default' ? DEFAULT_BANK_ACCOUNTS : []
    )
  );

  const [expenses, setExpenses] = useState<Expense[]>(() =>
    loadStoredData(getCompanyScopedKey('expenses', activeCompanyId), [])
  );

  const [partyTransactions, setPartyTransactions] = useState<PartyTransaction[]>(() =>
    loadStoredData(
      getCompanyScopedKey(STORAGE_KEYS.PARTY_TRANSACTIONS, activeCompanyId),
      activeCompanyId === 'comp-default' ? SAMPLE_PARTY_TRANSACTIONS : []
    )
  );

  const [rawMaterials, setRawMaterials] = useState<RawMaterial[]>(() =>
    loadStoredData(
      getCompanyScopedKey(STORAGE_KEYS.RAW_MATERIALS, activeCompanyId),
      activeCompanyId === 'comp-default' ? SAMPLE_RAW_MATERIALS : []
    )
  );

  const [productionBatches, setProductionBatches] = useState<ProductionBatch[]>(() =>
    loadStoredData(
      getCompanyScopedKey(STORAGE_KEYS.PRODUCTION_BATCHES, activeCompanyId),
      activeCompanyId === 'comp-default' ? SAMPLE_PRODUCTION_BATCHES : []
    )
  );

  const [recurringInvoices, setRecurringInvoices] = useState<RecurringInvoice[]>(() =>
    loadStoredData(getCompanyScopedKey('recurring_invoices', activeCompanyId), [])
  );

  const [machines, setMachines] = useState<Machine[]>(() =>
    loadStoredData(getCompanyScopedKey(STORAGE_KEYS.MACHINES, activeCompanyId), SAMPLE_MACHINES)
  );

  const [fieldOrders, setFieldOrders] = useState<FieldOrder[]>(() =>
    loadStoredData<FieldOrder[]>(getCompanyScopedKey(STORAGE_KEYS.FIELD_ORDERS, activeCompanyId), [])
  );
  const [quotations, setQuotations] = useState<Quotation[]>(() =>
    loadStoredData<Quotation[]>(getCompanyScopedKey(STORAGE_KEYS.QUOTATIONS, activeCompanyId), [])
  );
  const [boms, setBoms] = useState<BillOfMaterial[]>(() =>
    loadStoredData<BillOfMaterial[]>(getCompanyScopedKey(STORAGE_KEYS.BOMS, activeCompanyId), [])
  );
  const [productionOrders, setProductionOrders] = useState<ProductionOrder[]>(() =>
    loadStoredData<ProductionOrder[]>(getCompanyScopedKey(STORAGE_KEYS.PRODUCTION_ORDERS, activeCompanyId), [])
  );

  const [independentDispatches, setIndependentDispatches] = useState<DispatchRecord[]>(() =>
    loadStoredData(getCompanyScopedKey('independent_dispatches', activeCompanyId), [])
  );

  const todayBs = getTodayBsString();
  const [dailyCash, setDailyCash] = useState<DailyCashRecord>(() =>
    loadStoredData(getCompanyScopedKey(STORAGE_KEYS.DAILY_CASH, activeCompanyId), {
      id: `cash-${todayBs}`,
      dateBs: todayBs,
      openingCash: 5000,
      totalCashSales: 0,
      totalBankTransfers: 0,
      totalAdvancesGiven: 0,
      closingCashInHand: 5000
    })
  );

  const [language, setLanguageState] = useState<Language>(() =>
    loadStoredData(STORAGE_KEYS.LANGUAGE, 'ne')
  );
  const [voucherSubTab, setVoucherSubTab] = useState<'COLLECTION' | 'PAYMENT' | 'CUSTOMERS' | 'EXPENSES' | 'CASH_BOOK' | 'BANK_RECONCILIATION'>('COLLECTION');
  const [billingSubTab, setBillingSubTab] = useState<'SALES' | 'PURCHASE' | 'PAYMENT_IN' | 'PAYMENT_OUT' | 'SALES_RETURN' | 'PURCHASE_RETURN' | 'RECURRING'>('SALES');
  const [manufacturingSubTab, setManufacturingSubTab] = useState<'OVERVIEW' | 'BATCHES' | 'RAW_MATERIALS' | 'WIP_MACHINE' | 'FINISHED_GOODS' | 'PACKAGING' | 'DISPATCHED' | 'MACHINES' | 'REPORTS' | 'BOM' | 'PLANNING'>('OVERVIEW');
  const [ledgerSubTab, setLedgerSubTab] = useState<'ALL' | 'CUSTOMER' | 'SUPPLIER' | 'DUE_ONLY' | 'ADD_PARTY'>('ALL');
  const [inventorySubTab, setInventorySubTab] = useState<'ALL' | 'ADD_ITEM' | 'RECONCILE' | 'LOW_STOCK' | 'RAW_MATERIALS' | 'FINISHED_GOODS'>('ALL');
  const [logisticsSubTab, setLogisticsSubTab] = useState<'DASHBOARD' | 'DISPATCH_LOG' | 'PENDING_APPROVAL' | 'DRIVER_REPORT'>('DASHBOARD');
  const [reportSubTab, setReportSubTab] = useState<string>('');
  const [attendanceSubTab, setAttendanceSubTab] = useState<string>('DASHBOARD');
  const [openPurchaseModalSignal, setOpenPurchaseModalSignal] = useState<number>(0);
  const [openDispatchModalSignal, setOpenDispatchModalSignal] = useState<number>(0);
  const [preselectedBillId, setPreselectedBillId] = useState<string>('');
  const [preselectedBillType, setPreselectedBillType] = useState<'SALES' | 'PURCHASE'>('SALES');

  const [currentRole, setCurrentRoleState] = useState<UserRole>(() => {
    const srv = getServerUser();
    if (srv && srv.role !== 'OWNER') return srv.role as UserRole; // staff: role comes from the server, fixed
    const stored = loadStoredData<string>(STORAGE_KEYS.USER_ROLE, 'OWNER');
    const prevAcc = loadStoredData<{ id?: string } | null>(STORAGE_KEYS.ACTIVE_ACCOUNT, null);
    if (prevAcc?.id?.startsWith('srv-')) return 'OWNER'; // left over from a staff login on this device
    if (
      stored === 'ADMINISTRATION' ||
      stored === 'SUPER_ADMIN' ||
      stored === 'ADMIN' ||
      stored === 'COMPANY_OWNER'
    ) {
      return 'OWNER';
    }
    return (stored as UserRole) || 'OWNER';
  });

  // Multi-Company Accounts by Mobile Number with Admin Approval (guarantee Super Admin 9855012345 & Owner 9845012399 exist)
  const [companyAccounts, setCompanyAccounts] = useState<CompanyAccount[]>(() => {
    const loaded = loadStoredData<CompanyAccount[]>(STORAGE_KEYS.COMPANY_ACCOUNTS, SAMPLE_COMPANY_ACCOUNTS);
    const list = Array.isArray(loaded) && loaded.length > 0 ? [...loaded] : [...SAMPLE_COMPANY_ACCOUNTS];
    const superAdminTemplate = SAMPLE_COMPANY_ACCOUNTS[0];
    const ownerTemplate = SAMPLE_COMPANY_ACCOUNTS[1];

    const adminIdx = list.findIndex((a) => a.mobileNumber.replace(/\D/g, '') === '9855012345');
    if (adminIdx === -1) {
      list.unshift(superAdminTemplate);
    } else {
      list[adminIdx] = {
        ...list[adminIdx],
        status: 'APPROVED',
        role: 'SUPER_ADMIN',
        assignedRole: 'OWNER',
        pin: list[adminIdx].pin || '1234'
      };
    }

    const ownerIdx = list.findIndex((a) => a.mobileNumber.replace(/\D/g, '') === '9845012399');
    if (ownerIdx === -1) {
      list.push(ownerTemplate);
    } else {
      list[ownerIdx] = {
        ...list[ownerIdx],
        status: 'APPROVED',
        assignedRole: 'OWNER'
      };
    }

    return list;
  });

  const [currentAccount, setCurrentAccount] = useState<CompanyAccount | null>(() => {
    // Staff who logged in with their own ID/password: the account is built from the server's record
    const srv = getServerUser();
    if (srv && srv.role !== 'OWNER') {
      return {
        id: `srv-${srv.id}`,
        mobileNumber: srv.id,
        companyName: '',
        ownerName: srv.name,
        status: 'APPROVED',
        role: 'STAFF',
        assignedRole: srv.role as UserRole,
        registeredDateBs: '',
        allowedTabs: srv.allowedTabs,
      } as CompanyAccount;
    }
    const saved = loadStoredData<CompanyAccount | null>(STORAGE_KEYS.ACTIVE_ACCOUNT, null);
    if (saved && !String(saved.id).startsWith('srv-')) return saved; // never reuse a staff login's account for the owner
    if (typeof window !== 'undefined' && localStorage.getItem('krishiyantra_explicit_logout_v1') === 'true') {
      return null;
    }
    return SAMPLE_COMPANY_ACCOUNTS[0];
  });

  // Super Admin Audit Trail Logs
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() =>
    loadStoredData(STORAGE_KEYS.AUDIT_LOGS, SAMPLE_AUDIT_LOGS)
  );

  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.MACHINES, activeCompanyId), machines);
  }, [machines, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.FIELD_ORDERS, activeCompanyId), fieldOrders);
  }, [fieldOrders, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.QUOTATIONS, activeCompanyId), quotations);
  }, [quotations, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.BOMS, activeCompanyId), boms);
  }, [boms, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PRODUCTION_ORDERS, activeCompanyId), productionOrders);
  }, [productionOrders, activeCompanyId]);

  useEffect(() => {
    saveStoredData(STORAGE_KEYS.AUDIT_LOGS, auditLogs);
  }, [auditLogs]);

  const normalizeDigits = (val: string): string => {
    const devanagariMap: Record<string, string> = {
      '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
      '५': '5', '६': '6', '७': '7', '८': '8', '९': '9'
    };
    return val.replace(/[०-९]/g, (ch) => devanagariMap[ch] || ch);
  };

  const logAuditAction = (params: {
    actionType: AuditActionType;
    module: AuditLogEntry['module'];
    severity?: AuditLogEntry['severity'];
    targetId?: string;
    summaryNe: string;
    summaryEn: string;
    details?: string;
  }) => {
    const now = new Date();
    const entry: AuditLogEntry = {
      id: `aud-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      dateBs: getTodayBsString(),
      dateAd: getTodayAdString(),
      actionType: params.actionType,
      module: params.module,
      severity: params.severity || 'INFO',
      actorName: currentAccount?.ownerName || 'प्रणाली प्रयोगकर्ता (User)',
      actorMobile: currentAccount?.mobileNumber || '9855012345',
      actorRole: currentAccount?.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : currentRole,
      targetId: params.targetId,
      summaryNe: params.summaryNe,
      summaryEn: params.summaryEn,
      details: params.details
    };
    setAuditLogs((prev) => [entry, ...prev]);
  };

  // Mandatory Owner Key Prompt Queue for ANY Delete or Edit operation
  const [ownerKeyPromptQueue, setOwnerKeyPromptQueue] = useState<
    Array<{
      id: string;
      label: string;
      actionType: 'EDIT' | 'DELETE';
      execute: () => void;
      dedupeKey?: string;
      onCancel?: () => void;
    }>
  >([]);
  const [ownerKeyModalInput, setOwnerKeyModalInput] = useState('');
  const [ownerKeyModalError, setOwnerKeyModalError] = useState<string | null>(null);
  const [fiscalCodePrompt, setFiscalCodePrompt] = useState<string | null>(null);
  const [fiscalCodeInput, setFiscalCodeInput] = useState('');
  const [fiscalCodeError, setFiscalCodeError] = useState<string | null>(null);
  const [showOwnerKeyPlain, setShowOwnerKeyPlain] = useState(false);
  const [ownerKeyToast, setOwnerKeyToast] = useState<{ text: string; type: 'success' | 'warn' } | null>(null);

  const showGlobalSecurityToast = (text: string, type: 'success' | 'warn' = 'success') => {
    setOwnerKeyToast({ text, type });
    setTimeout(() => {
      setOwnerKeyToast((prev) => (prev?.text === text ? null : prev));
    }, 3500);
  };

  const requireOwnerKey = (
    actionLabel: string,
    onVerified: () => void,
    actionType: 'EDIT' | 'DELETE' = 'EDIT',
    opts?: { dedupeKey?: string; onCancel?: () => void }
  ) => {
    setOwnerKeyModalError(null);
    setOwnerKeyPromptQueue((prev) => {
      // एउटै कार्य दोहोरिएर (double click / दुई पटक Save) लाइनमा नथपियोस्
      if (opts?.dedupeKey && prev.some((q) => q.dedupeKey === opts.dedupeKey)) return prev;
      return [
        ...prev,
        {
          id: `ok-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          label: actionLabel,
          actionType,
          execute: onVerified,
          dedupeKey: opts?.dedupeKey,
          onCancel: opts?.onCancel
        }
      ];
    });
  };

  const clearAuditLogs = () => {
    requireOwnerKey(
      'अडिट लग इतिहास मेटाउने (Clear Audit Trail Logs)',
      () => {
        setAuditLogs([]);
      },
      'DELETE'
    );
  };

  useEffect(() => {
    saveStoredData(STORAGE_KEYS.COMPANY_ACCOUNTS, companyAccounts);
  }, [companyAccounts]);

  useEffect(() => {
    saveStoredData(STORAGE_KEYS.ACTIVE_ACCOUNT, currentAccount);
  }, [currentAccount]);

  const loginWithMobile = (
    mobileNumber: string,
    pin?: string,
    role?: UserRole
  ): { success: boolean; message: string; account?: CompanyAccount } => {
    if (isStaffLogin()) {
      return { success: false, message: 'कर्मचारी खाताबाट अर्को खातामा बदल्न मिल्दैन। पहिला लगआउट गर्नुहोस्।' };
    }
    const rawInput = normalizeDigits(mobileNumber.trim());
    const cleanDigits = rawInput.replace(/\D/g, '');
    const normalizedPin = pin ? normalizeDigits(pin.trim()) : '';

    // Search by 10-digit mobile number OR username/identifier
    let account = companyAccounts.find((a) => {
      const accMobile = normalizeDigits(a.mobileNumber).replace(/\D/g, '');
      if (cleanDigits.length >= 10 && accMobile.slice(-10) === cleanDigits.slice(-10)) return true;
      if (a.id.toLowerCase() === rawInput.toLowerCase()) return true;
      if ((rawInput.toLowerCase() === 'admin' || rawInput.toLowerCase() === 'superadmin') && a.role === 'SUPER_ADMIN') return true;
      if (rawInput.toLowerCase() === 'owner' && (a.assignedRole === 'OWNER' || a.role === 'COMPANY_OWNER')) return true;
      return false;
    });

    if (!account) {
      return {
        success: false,
        message: `लग-इन आइडी वा मोबाइल नम्बर (${rawInput}) फेला परेन।`
      };
    }

    const isSuperAdminAccount =
      normalizeDigits(account.mobileNumber).replace(/\D/g, '') === '9855012345' ||
      account.role === 'SUPER_ADMIN';

    const isPrimaryOwnerAccount =
      normalizeDigits(account.mobileNumber).replace(/\D/g, '') === '9845012399';

    if (!isSuperAdminAccount && account.status === 'PENDING_APPROVAL') {
      return {
        success: false,
        message: `तपाईँको मोबाइल नम्बर (${account.mobileNumber}) एडमिनबाट स्वीकृतिको पर्खाइमा छ (Pending Admin Approval)।`
      };
    }

    if (!isSuperAdminAccount && account.status === 'REJECTED') {
      return {
        success: false,
        message: `यो खाता एडमिनबाट अस्वीकृत गरिएको छ। कृपया मुख्य एडमिनसँग सम्पर्क गर्नुहोस्।`
      };
    }

    // Verify PIN: a PIN is mandatory and must equal the stored PIN (no master/default PINs)
    {
      const storedPin = account.pin ? normalizeDigits(account.pin.trim()) : '';
      if (!normalizedPin || !storedPin || normalizedPin !== storedPin) {
        return {
          success: false,
          message: 'गलत PIN! कृपया सही PIN राखेर फेरि प्रयास गर्नुहोस् (Incorrect PIN)'
        };
      }
    }

    // Role enforcement: Map SUPER_ADMIN, OWNER, ADMINISTRATION, COMPANY_OWNER roles to OWNER for full access
    let effectiveRole: UserRole = (account.assignedRole as UserRole) || 'OWNER';
    if (
      isSuperAdminAccount ||
      account.role === 'SUPER_ADMIN' ||
      account.role === 'ADMIN' ||
      account.role === 'COMPANY_OWNER' ||
      effectiveRole === 'ADMINISTRATION'
    ) {
      effectiveRole = 'OWNER';
    }

    if (typeof window !== 'undefined') {
      localStorage.removeItem('krishiyantra_explicit_logout_v1');
    }
    setCurrentAccount(account);
    setCurrentRoleState(effectiveRole);
    saveStoredData(STORAGE_KEYS.USER_ROLE, effectiveRole);

    // If account is tied to a specific company in companiesList, switch to that company
    if (account.companyId && companiesList.some((c) => c.id === account.companyId)) {
      if (account.companyId !== activeCompanyId) {
        switchCompany(account.companyId);
      }
    } else {
      const matchedComp = companiesList.find(
        (c) => c.name.trim().toLowerCase() === (account.companyName || '').trim().toLowerCase()
      );
      if (matchedComp && matchedComp.id !== activeCompanyId) {
        switchCompany(matchedComp.id);
      }
    }

    // Record login in Audit Trail
    const now = new Date();
    const loginAudit: AuditLogEntry = {
      id: `aud-${Date.now()}`,
      timestamp: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      dateBs: getTodayBsString(),
      dateAd: getTodayAdString(),
      actionType: 'USER_LOGIN',
      module: 'AUTH',
      severity: 'INFO',
      actorName: account.ownerName,
      actorMobile: account.mobileNumber,
      actorRole: isSuperAdminAccount ? 'SUPER_ADMIN' : effectiveRole,
      targetId: account.mobileNumber,
      summaryNe: `${account.ownerName} (${account.mobileNumber}) लग-इन गरियो`,
      summaryEn: `${account.ownerName} (${account.mobileNumber}) logged in`,
      details: `Mobile: ${account.mobileNumber} | Role: ${isSuperAdminAccount ? 'SUPER_ADMIN' : effectiveRole}`
    };
    setAuditLogs((prev) => [loginAudit, ...prev]);

    return {
      success: true,
      message: `लग-इन सफल भयो! (${account.mobileNumber})`,
      account
    };
  };

  const registerMobileAccount = (data: {
    mobileNumber: string;
    companyName: string;
    ownerName: string;
    panVatNo?: string;
    address?: string;
    pin?: string;
    requestedRole?: UserRole;
  }): { success: boolean; message: string } => {
    const cleanMobile = normalizeDigits(data.mobileNumber.trim()).replace(/\D/g, '');
    if (cleanMobile.length < 10) {
      return { success: false, message: 'कृपया १० अंकको मान्य नेपाली मोबाइल नम्बर हान्नुहोस्।' };
    }

    const existing = companyAccounts.find((a) => normalizeDigits(a.mobileNumber).replace(/\D/g, '') === cleanMobile);
    if (existing) {
      if (existing.status === 'PENDING_APPROVAL') {
        return { success: false, message: 'यो मोबाइल नम्बर पहिले नै दर्ता भई एडमिन स्वीकृतिको पर्खाइमा छ।' };
      }
      return { success: false, message: 'यो मोबाइल नम्बर पहिले नै दर्ता छ। कृपया सिधै लग-इन गर्नुहोस्।' };
    }

    const newAccount: CompanyAccount = {
      id: `acc-${Date.now()}`,
      mobileNumber: cleanMobile,
      companyName: data.companyName.trim() || `कम्पनी (${cleanMobile})`,
      ownerName: data.ownerName.trim() || 'सञ्चालक',
      panVatNo: data.panVatNo?.trim() || '',
      address: data.address?.trim() || '',
      status: 'PENDING_APPROVAL',
      role: 'COMPANY_OWNER',
      assignedRole: data.requestedRole || 'OWNER',
      pin: data.pin?.trim() || '1234',
      registeredDateBs: getTodayBsString(),
      notes: 'अनलाइन मोबाइल दर्ता'
    };

    setCompanyAccounts((prev) => [...prev, newAccount]);

    return {
      success: true,
      message: `तपाईँको मोबाइल नम्बर (${cleanMobile}) सफलतापूर्वक दर्ता भयो ! सुरक्षाको लागि एडमिनले स्वीकृत गरेपछि मात्र खाता सुचारु हुनेछ।`
    };
  };

  const approveAccount = (accountId: string, role?: UserRole) => {
    const today = getTodayBsString();
    const targetAcc = companyAccounts.find((a) => a.id === accountId);
    setCompanyAccounts((prev) =>
      prev.map((a) =>
        a.id === accountId
          ? {
              ...a,
              status: 'APPROVED',
              approvedDateBs: today,
              assignedRole: role || a.assignedRole || 'OWNER'
            }
          : a
      )
    );
    if (targetAcc) {
      logAuditAction({
        actionType: 'ACCOUNT_APPROVED',
        module: 'AUTH',
        severity: 'INFO',
        targetId: targetAcc.mobileNumber,
        summaryNe: `खाता स्वीकृत: ${targetAcc.ownerName} (${targetAcc.mobileNumber}) पद: ${role || targetAcc.assignedRole || 'OWNER'}`,
        summaryEn: `Account Approved: ${targetAcc.ownerName} (${targetAcc.mobileNumber}) as ${role || targetAcc.assignedRole || 'OWNER'}`
      });
    }
  };

  const rejectAccount = (accountId: string) => {
    const targetAcc = companyAccounts.find((a) => a.id === accountId);
    requireOwnerKey(
      `युजर खाता अस्वीकृत गर्ने (Reject Account: ${targetAcc?.ownerName || accountId})`,
      () => {
        setCompanyAccounts((prev) =>
          prev.map((a) =>
            a.id === accountId
              ? { ...a, status: 'REJECTED' }
              : a
          )
        );
        if (targetAcc) {
          logAuditAction({
            actionType: 'ACCOUNT_REJECTED',
            module: 'AUTH',
            severity: 'WARNING',
            targetId: targetAcc.mobileNumber,
            summaryNe: `खाता अस्वीकृत: ${targetAcc.ownerName} (${targetAcc.mobileNumber})`,
            summaryEn: `Account Rejected: ${targetAcc.ownerName} (${targetAcc.mobileNumber})`
          });
        }
      },
      'EDIT'
    );
  };

  const resetAccountPin = (accountId: string, newPin: string): { success: boolean; message: string } => {
    const cleanPin = newPin.trim();
    if (!cleanPin || cleanPin.length < 4) {
      return { success: false, message: 'कृपया कम्तीमा ४ अंकको नयाँ PIN प्रविष्ट गर्नुहोस्।' };
    }

    const acc = companyAccounts.find((a) => a.id === accountId);
    if (!acc) {
      return { success: false, message: 'कम्पनी खाता फेला परेन।' };
    }

    requireOwnerKey(
      `युजर लग-इन PIN सच्याउने (${acc.ownerName} - ${acc.mobileNumber})`,
      () => {
        setCompanyAccounts((prev) =>
          prev.map((a) => (a.id === accountId ? { ...a, pin: cleanPin } : a))
        );

        if (currentAccount?.id === accountId) {
          setCurrentAccount((prev) => (prev ? { ...prev, pin: cleanPin } : null));
        }
      },
      'EDIT'
    );

    return {
      success: true,
      message: `मालिकको साँचो (Owner Key) प्रमाणित भएपछि '${acc.ownerName}' को लग-इन PIN सच्याइनेछ।`
    };
  };

  const logoutAccount = () => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('krishiyantra_explicit_logout_v1', 'true');
    }
    // Server login too: back to the ID/password screen
    clearToken();
    window.dispatchEvent(new Event('ky-auth-expired'));
    setCurrentAccount(null);
    setCurrentRoleState('OWNER');
  };

  const saveCompanyAccount = (data: {
    id?: string;
    companyId?: string;
    mobileNumber: string;
    companyName: string;
    ownerName: string;
    panVatNo?: string;
    address?: string;
    assignedRole: UserRole;
    pin?: string;
    status?: AccountStatus;
    allowedTabs?: string[];
  }): { success: boolean; message: string } => {
    const cleanMobile = data.mobileNumber.trim().replace(/\D/g, '');
    if (cleanMobile.length < 10) {
      return { success: false, message: 'कृपया १० अंकको मान्य नेपाली मोबाइल नम्बर हान्नुहोस्।' };
    }

    if (data.id) {
      const existing = companyAccounts.find((a) => a.id === data.id);
      if (!existing) return { success: false, message: 'युजर खाता फेला परेन।' };

      requireOwnerKey(
        `युजर तथा पद विवरण सच्याउने (${data.ownerName.trim() || existing.ownerName} — ${cleanMobile})`,
        () => {
          setCompanyAccounts((prev) =>
            prev.map((a) =>
              a.id === data.id
                ? {
                    ...a,
                    companyId: data.companyId || a.companyId || activeCompanyId,
                    mobileNumber: cleanMobile,
                    companyName: data.companyName.trim() || a.companyName,
                    ownerName: data.ownerName.trim() || a.ownerName,
                    panVatNo: data.panVatNo?.trim() || a.panVatNo || '',
                    address: data.address?.trim() || a.address || '',
                    assignedRole: data.assignedRole,
                    pin: data.pin?.trim() || a.pin || '1234',
                    status: data.status || a.status,
                    allowedTabs: data.allowedTabs || a.allowedTabs
                  }
                : a
            )
          );

          if (currentAccount?.id === data.id) {
            setCurrentAccount((prev) =>
              prev
                ? {
                    ...prev,
                    companyId: data.companyId || prev.companyId || activeCompanyId,
                    mobileNumber: cleanMobile,
                    companyName: data.companyName.trim() || prev.companyName,
                    ownerName: data.ownerName.trim() || prev.ownerName,
                    assignedRole: data.assignedRole,
                    pin: data.pin?.trim() || prev.pin || '1234',
                    status: data.status || prev.status,
                    allowedTabs: data.allowedTabs || prev.allowedTabs
                  }
                : null
            );
            setCurrentRoleState(data.assignedRole);
          }
        },
        'EDIT'
      );

      return {
        success: true,
        message: `मालिकको साँचो (Owner Key) प्रमाणित भएपछि ${data.ownerName} (${cleanMobile}) को विवरण सच्याइनेछ।`
      };
    } else {
      const duplicate = companyAccounts.find((a) => a.mobileNumber.replace(/\D/g, '') === cleanMobile);
      if (duplicate) {
        return { success: false, message: `मोबाइल नम्बर (${cleanMobile}) पहिले नै दर्ता छ।` };
      }

      const newAcc: CompanyAccount = {
        id: `acc-${Date.now()}`,
        companyId: data.companyId || activeCompanyId,
        mobileNumber: cleanMobile,
        companyName: data.companyName.trim() || company.name || `कम्पनी (${cleanMobile})`,
        ownerName: data.ownerName.trim() || 'युजर',
        panVatNo: data.panVatNo?.trim() || company.panVatNo || '',
        address: data.address?.trim() || company.address || '',
        status: data.status || 'APPROVED',
        role: 'STAFF',
        assignedRole: data.assignedRole,
        pin: data.pin?.trim() || '1234',
        registeredDateBs: getTodayBsString(),
        approvedDateBs: getTodayBsString(),
        notes: 'मालिकबाट थपिएको खाता',
        allowedTabs: data.allowedTabs || []
      };

      setCompanyAccounts((prev) => [...prev, newAcc]);

      return {
        success: true,
        message: `नयाँ युजर ${data.ownerName} (${cleanMobile}) पद '${data.assignedRole}' सहित सफलतापूर्वक थपियो !`
      };
    }
  };

  const deleteCompanyAccount = (accountId: string): { success: boolean; message: string } => {
    const acc = companyAccounts.find((a) => a.id === accountId);
    if (!acc) return { success: false, message: 'खाता फेला परेन।' };

    if (acc.mobileNumber === '9855012345') {
      return { success: false, message: 'मुख्य सुपर एडमिन (९८५५०१२३४५) खाता हटाउन मिल्दैन !' };
    }

    requireOwnerKey(
      `युजर लग-इन खाता मेटाउने (${acc.ownerName} - ${acc.mobileNumber})`,
      () => {
        setCompanyAccounts((prev) => prev.filter((a) => a.id !== accountId));
        if (currentAccount?.id === accountId) {
          logoutAccount();
        }
      },
      'DELETE'
    );

    return {
      success: true,
      message: `मालिकको साँचो (Owner Key) प्रमाणित भएपछि युजर खाता (${acc.ownerName}) हटाइनेछ।`
    };
  };

  const checkPermission = (tabId: string): boolean => {
    if (currentRole === 'OWNER') return true;
    if (!currentAccount) return false;
    
    // Default open tabs for everyone if not explicitly restricted
    const defaultPublicTabs = ['dashboard', 'attendance'];
    if (defaultPublicTabs.includes(tabId)) return true;

    if (!currentAccount.allowedTabs || currentAccount.allowedTabs.length === 0) {
      // If no permissions set for staff, restrict to basic tabs
      const staffDefaultTabs = ['billing', 'vouchers', 'attendance', 'logistics', 'inventory', 'ledger', 'dashboard', 'field_orders'];
      return staffDefaultTabs.includes(tabId);
    }

    return currentAccount.allowedTabs.includes(tabId);
  };

  const updatePermissions = (accountId: string, allowedTabs: string[]) => {
    setCompanyAccounts((prev) =>
      prev.map((a) => (a.id === accountId ? { ...a, allowedTabs } : a))
    );
    if (currentAccount?.id === accountId) {
      setCurrentAccount((prev) => (prev ? { ...prev, allowedTabs } : null));
    }
  };

  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Sync online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const [activeTab, setActiveTabState] = useState<string>('dashboard');
  
  const setActiveTab = (tab: string) => {
    if (checkPermission(tab)) {
      setActiveTabState(tab);
    } else {
      // If not allowed, redirect to dashboard
      setActiveTabState('dashboard');
    }
  };

  // Recalculate daily cash tally whenever invoices or employeeLedger change
  useEffect(() => {
    const todayInvoices = invoices.filter((i) => i.dateBs === todayBs && i.status === 'ACTIVE');
    const cashSales = todayInvoices
      .filter((i) => i.paymentMode === 'CASH')
      .reduce((sum, i) => sum + i.grandTotal, 0);

    const bankTransfers = todayInvoices
      .filter((i) => i.paymentMode === 'BANK_FONEPAY')
      .reduce((sum, i) => sum + i.grandTotal, 0);

    const todayAdvances = employeeLedger
      .filter((l) => l.dateBs === todayBs && l.type === 'CASH_ADVANCE')
      .reduce((sum, l) => sum + l.amount, 0);

    const closingCash = dailyCash.openingCash + cashSales - todayAdvances;

    setDailyCash((prev) => ({
      ...prev,
      dateBs: todayBs,
      totalCashSales: cashSales,
      totalBankTransfers: bankTransfers,
      totalAdvancesGiven: todayAdvances,
      closingCashInHand: closingCash
    }));
  }, [invoices, employeeLedger, todayBs, dailyCash.openingCash]);

  // Save changes to company-scoped localStorage
  useEffect(() => {
    saveStoredData(COMPANIES_LIST_STORAGE_KEY, companiesList);
  }, [companiesList]);
  useEffect(() => {
    saveStoredData(ACTIVE_COMPANY_ID_STORAGE_KEY, activeCompanyId);
  }, [activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.ITEMS, activeCompanyId), items);
  }, [items, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.INVOICES, activeCompanyId), invoices);
  }, [invoices, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PURCHASES, activeCompanyId), purchases);
  }, [purchases, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PARTIES, activeCompanyId), parties);
  }, [parties, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.BANK_ACCOUNTS, activeCompanyId), bankAccounts);
  }, [bankAccounts, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PARTY_TRANSACTIONS, activeCompanyId), partyTransactions);
  }, [partyTransactions, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.RAW_MATERIALS, activeCompanyId), rawMaterials);
  }, [rawMaterials, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PRODUCTION_BATCHES, activeCompanyId), productionBatches);
  }, [productionBatches, activeCompanyId]);

  useEffect(() => {
    saveStoredData(getCompanyScopedKey('independent_dispatches', activeCompanyId), independentDispatches);
  }, [independentDispatches, activeCompanyId]);

  useEffect(() => {
    saveStoredData(getCompanyScopedKey('recurring_invoices', activeCompanyId), recurringInvoices);

    // Auto-generate recurring invoices if due
    const todayBs = getTodayBsString();
    let generatedAny = false;
    const updatedRecurring = recurringInvoices.map((ri) => {
      if (ri.nextRunDateBs <= todayBs) {
        generatedAny = true;
        // Trigger invoice creation
        createInvoice({
          billType: ri.billType,
          customerName: ri.customerName,
          partyId: ri.partyId,
          items: ri.items,
          discountPercent: 0,
          freightCharge: 0,
          paymentMode: 'CREDIT',
          notes: `Recurring Invoice: ${ri.notes || ''}`
        });
        
        // Calculate next run date (simple frequency logic)
        const parts = ri.nextRunDateBs.split('-').map(Number);
        let nextBs = ri.nextRunDateBs;
        if (ri.frequency === 'MONTHLY') {
          parts[1] = parts[1] + 1;
          if (parts[1] > 12) { parts[1] = 1; parts[0] += 1; }
          nextBs = `${parts[0]}-${String(parts[1]).padStart(2, '0')}-${String(parts[2]).padStart(2, '0')}`;
        }
        return { ...ri, lastGeneratedDateBs: todayBs, nextRunDateBs: nextBs };
      }
      return ri;
    });

    if (generatedAny) {
      setRecurringInvoices(updatedRecurring);
    }
  }, [recurringInvoices, activeCompanyId, invoices]); // Need to add createInvoice dependency? No, createInvoice is a function stable ref. Wait, I should add createInvoice to dependencies if it is inside the scope. It is. But I can't add a function if it triggers re-render loop. Ah, createInvoice is defined in AppProvider scope. It shouldn't trigger infinite loops here if I'm careful.

  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.EMPLOYEES, activeCompanyId), employees);
  }, [employees, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.ATTENDANCE, activeCompanyId), attendance);
  }, [attendance, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.EMPLOYEE_LEDGER, activeCompanyId), employeeLedger);
  }, [employeeLedger, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey('expenses', activeCompanyId), expenses);
  }, [expenses, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.DAILY_CASH, activeCompanyId), dailyCash);
  }, [dailyCash, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), company);
  }, [company, activeCompanyId]);
  useEffect(() => {
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.MACHINES, activeCompanyId), machines);
  }, [machines, activeCompanyId]);

  // Multi-Company Switcher (फरक कम्पनी छान्दा सोही कम्पनीको स्टाफ र सम्पूर्ण प्रणाली लोड गर्ने)
  const switchCompany = (targetCompanyId: string) => {
    if (!targetCompanyId || targetCompanyId === activeCompanyId) return;

    // 1. Flush current company state
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.ITEMS, activeCompanyId), items);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.INVOICES, activeCompanyId), invoices);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PURCHASES, activeCompanyId), purchases);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PARTIES, activeCompanyId), parties);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.BANK_ACCOUNTS, activeCompanyId), bankAccounts);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PARTY_TRANSACTIONS, activeCompanyId), partyTransactions);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.RAW_MATERIALS, activeCompanyId), rawMaterials);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PRODUCTION_BATCHES, activeCompanyId), productionBatches);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.EMPLOYEES, activeCompanyId), employees);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.ATTENDANCE, activeCompanyId), attendance);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.EMPLOYEE_LEDGER, activeCompanyId), employeeLedger);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.DAILY_CASH, activeCompanyId), dailyCash);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), company);
    saveStoredData(getCompanyScopedKey('expenses', activeCompanyId), expenses);

    // 2. Load target company state
    const targetDir = companiesList.find((c) => c.id === targetCompanyId);
    const defaultMainBranch: BranchOffice = {
      id: `branch-main-${targetCompanyId}`,
      code: 'BR-01',
      name: `मुख्य शाखा - ${targetDir?.address || 'हेड अफिस'} (Head Office)`,
      address: targetDir?.address || '',
      phone: targetDir?.phone || '',
      email: '',
      managerName: currentAccount?.ownerName || 'सञ्चालक / मुख्य व्यवस्थापक',
      managerMobile: currentAccount?.mobileNumber || targetDir?.phone || '',
      managerPin: '1234',
      isMainBranch: true,
      status: 'ACTIVE',
      billPrefix: 'HO',
      dailyExpenseLimit: 50000,
      maxDiscountPercent: 25,
      permissions: {
        allowSalesBilling: true,
        allowPurchaseEntry: true,
        allowCreditSales: true,
        allowDiscount: true,
        allowStockTransfer: true,
        allowExpenseVoucher: true,
        allowDeleteOrEdit: true,
        allowedTabs: [
          'dashboard',
          'billing',
          'manufacturing',
          'vouchers',
          'ledger',
          'inventory',
          'reports',
          'audit_report',
          'vat_books',
          'accounting',
          'stock_costing',
          'logistics',
          'attendance',
          'excel_wizard',
          'settings'
        ]
      },
      createdAtBs: targetDir?.createdAtBs || getTodayBsString()
    };

    const defaultTargetProfile: CompanyProfile = {
      ...DEFAULT_COMPANY,
      id: targetCompanyId,
      name: targetDir?.name || 'कम्पनी',
      panVatNo: targetDir?.panVatNo || '',
      address: targetDir?.address || '',
      phone: targetDir?.phone || '',
      tagline: targetDir?.tagline || DEFAULT_COMPANY.tagline,
      logoUrl: targetDir?.logoUrl,
      bankAccounts: [],
      branches: targetCompanyId === 'comp-default' ? undefined : [defaultMainBranch],
      activeBranchId: targetCompanyId === 'comp-default' ? undefined : defaultMainBranch.id
    };

    const loadedCompany = loadStoredData<CompanyProfile>(
      getCompanyScopedKey(STORAGE_KEYS.COMPANY, targetCompanyId),
      defaultTargetProfile
    );
    const nextCompany: CompanyProfile =
      targetCompanyId !== 'comp-default' && (!loadedCompany.branches || loadedCompany.branches.length === 0)
        ? {
            ...loadedCompany,
            branches: [
              {
                ...defaultMainBranch,
                address: loadedCompany.address || defaultMainBranch.address,
                phone: loadedCompany.phone || defaultMainBranch.phone,
                email: loadedCompany.email || ''
              }
            ],
            activeBranchId: defaultMainBranch.id
          }
        : loadedCompany;

    const nextBanks = loadStoredData<BankAccount[]>(
      getCompanyScopedKey(STORAGE_KEYS.BANK_ACCOUNTS, targetCompanyId),
      targetCompanyId === 'comp-default' ? DEFAULT_BANK_ACCOUNTS : (nextCompany.bankAccounts || [])
    );
    const nextItems = loadStoredData<Item[]>(
      getCompanyScopedKey(STORAGE_KEYS.ITEMS, targetCompanyId),
      targetCompanyId === 'comp-default' ? SAMPLE_AGRICULTURE_ITEMS : []
    );
    const nextInvoices = loadStoredData<Invoice[]>(
      getCompanyScopedKey(STORAGE_KEYS.INVOICES, targetCompanyId),
      targetCompanyId === 'comp-default' ? SAMPLE_INVOICES : []
    );
    const nextPurchases = loadStoredData<PurchaseRecord[]>(
      getCompanyScopedKey(STORAGE_KEYS.PURCHASES, targetCompanyId),
      targetCompanyId === 'comp-default' ? SAMPLE_PURCHASES : []
    );
    const nextParties = loadStoredData<Party[]>(
      getCompanyScopedKey(STORAGE_KEYS.PARTIES, targetCompanyId),
      targetCompanyId === 'comp-default' ? SAMPLE_PARTIES : []
    );
    const nextPartyTxns = loadStoredData<PartyTransaction[]>(
      getCompanyScopedKey(STORAGE_KEYS.PARTY_TRANSACTIONS, targetCompanyId),
      targetCompanyId === 'comp-default' ? SAMPLE_PARTY_TRANSACTIONS : []
    );
    const nextEmployees = loadStoredData<Employee[]>(
      getCompanyScopedKey(STORAGE_KEYS.EMPLOYEES, targetCompanyId),
      targetCompanyId === 'comp-default' ? SAMPLE_EMPLOYEES : []
    );
    const nextAttendance = loadStoredData<AttendanceRecord[]>(
      getCompanyScopedKey(STORAGE_KEYS.ATTENDANCE, targetCompanyId),
      []
    );
    const nextEmpLedger = loadStoredData<EmployeeLedgerEntry[]>(
      getCompanyScopedKey(STORAGE_KEYS.EMPLOYEE_LEDGER, targetCompanyId),
      []
    );
    const nextRawMaterials = loadStoredData<RawMaterial[]>(
      getCompanyScopedKey(STORAGE_KEYS.RAW_MATERIALS, targetCompanyId),
      targetCompanyId === 'comp-default' ? SAMPLE_RAW_MATERIALS : []
    );
    const nextProdBatches = loadStoredData<ProductionBatch[]>(
      getCompanyScopedKey(STORAGE_KEYS.PRODUCTION_BATCHES, targetCompanyId),
      targetCompanyId === 'comp-default' ? SAMPLE_PRODUCTION_BATCHES : []
    );
    const nextDailyCash = loadStoredData<DailyCashRecord>(
      getCompanyScopedKey(STORAGE_KEYS.DAILY_CASH, targetCompanyId),
      {
        id: `cash-${todayBs}`,
        dateBs: todayBs,
        openingCash: 0,
        totalCashSales: 0,
        totalBankTransfers: 0,
        totalAdvancesGiven: 0,
        closingCashInHand: 0
      }
    );

    const nextExpenses = loadStoredData<Expense[]>(
      getCompanyScopedKey('expenses', targetCompanyId),
      []
    );

    setActiveCompanyId(targetCompanyId);
    setCompany(nextCompany);
    setBankAccounts(nextBanks);
    setItems(nextItems);
    setInvoices(nextInvoices);
    setPurchases(nextPurchases);
    setParties(nextParties);
    setPartyTransactions(nextPartyTxns);
    setEmployees(nextEmployees);
    setAttendance(nextAttendance);
    setEmployeeLedger(nextEmpLedger);
    setRawMaterials(nextRawMaterials);
    setProductionBatches(nextProdBatches);
    setDailyCash(nextDailyCash);
    setExpenses(nextExpenses);
    setFieldOrders(loadStoredData<FieldOrder[]>(getCompanyScopedKey(STORAGE_KEYS.FIELD_ORDERS, targetCompanyId), []));
    setQuotations(loadStoredData<Quotation[]>(getCompanyScopedKey(STORAGE_KEYS.QUOTATIONS, targetCompanyId), []));
    setBoms(loadStoredData<BillOfMaterial[]>(getCompanyScopedKey(STORAGE_KEYS.BOMS, targetCompanyId), []));
    setProductionOrders(loadStoredData<ProductionOrder[]>(getCompanyScopedKey(STORAGE_KEYS.PRODUCTION_ORDERS, targetCompanyId), []));
  };

  // Create New Separate Company with its own isolated branches & ERP system capabilities
  const createNewCompany = (params: {
    name: string;
    panVatNo?: string;
    address?: string;
    phone?: string;
    tagline?: string;
    logoUrl?: string;
    includeStarterCatalog?: boolean;
  }): CompanyDirectoryEntry => {
    // 1. Flush current company state
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.ITEMS, activeCompanyId), items);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.INVOICES, activeCompanyId), invoices);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PURCHASES, activeCompanyId), purchases);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PARTIES, activeCompanyId), parties);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.BANK_ACCOUNTS, activeCompanyId), bankAccounts);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PARTY_TRANSACTIONS, activeCompanyId), partyTransactions);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.RAW_MATERIALS, activeCompanyId), rawMaterials);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PRODUCTION_BATCHES, activeCompanyId), productionBatches);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.EMPLOYEES, activeCompanyId), employees);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.ATTENDANCE, activeCompanyId), attendance);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.EMPLOYEE_LEDGER, activeCompanyId), employeeLedger);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.DAILY_CASH, activeCompanyId), dailyCash);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), company);

    const newId = `comp-${Date.now()}`;
    const newEntry: CompanyDirectoryEntry = {
      id: newId,
      name: params.name.trim() || 'नयाँ कम्पनी / फर्म',
      panVatNo: params.panVatNo?.trim() || '',
      address: params.address?.trim() || '',
      phone: params.phone?.trim() || '',
      tagline: params.tagline?.trim() || 'कृषि औजार, उत्पादन तथा इन्भेन्टरी व्यवस्थापन प्रणाली',
      logoUrl: params.logoUrl,
      createdAtBs: getTodayBsString()
    };

    const initialMainBranch: BranchOffice = {
      id: `branch-main-${newId}`,
      code: 'BR-01',
      name: `मुख्य शाखा - ${newEntry.address || 'हेड अफिस'} (Head Office)`,
      address: newEntry.address || 'मुख्य कार्यालय',
      phone: newEntry.phone || '',
      email: '',
      managerName: currentAccount?.ownerName || 'सञ्चालक / मुख्य व्यवस्थापक',
      managerMobile: currentAccount?.mobileNumber || newEntry.phone || '',
      managerPin: '1234',
      isMainBranch: true,
      status: 'ACTIVE',
      billPrefix: 'HO',
      dailyExpenseLimit: 50000,
      maxDiscountPercent: 25,
      permissions: {
        allowSalesBilling: true,
        allowPurchaseEntry: true,
        allowCreditSales: true,
        allowDiscount: true,
        allowStockTransfer: true,
        allowExpenseVoucher: true,
        allowDeleteOrEdit: true,
        allowedTabs: [
          'dashboard',
          'billing',
          'manufacturing',
          'vouchers',
          'ledger',
          'inventory',
          'reports',
          'audit_report',
          'vat_books',
          'accounting',
          'stock_costing',
          'logistics',
          'attendance',
          'excel_wizard',
          'settings'
        ]
      },
      createdAtBs: getTodayBsString()
    };

    const newProfile: CompanyProfile = {
      ...DEFAULT_COMPANY,
      id: newId,
      name: newEntry.name,
      logoUrl: newEntry.logoUrl,
      panVatNo: newEntry.panVatNo,
      address: newEntry.address,
      phone: newEntry.phone,
      tagline: newEntry.tagline || DEFAULT_COMPANY.tagline,
      bankAccounts: [],
      attendanceGroups: [],
      manualBankEntries: [],
      branches: [initialMainBranch],
      activeBranchId: initialMainBranch.id
    };

    const initialItems = params.includeStarterCatalog ? SAMPLE_AGRICULTURE_ITEMS : [];
    const initialRawMaterials = params.includeStarterCatalog ? SAMPLE_RAW_MATERIALS : [];

    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, newId), newProfile);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.BANK_ACCOUNTS, newId), []);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.ITEMS, newId), initialItems);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.INVOICES, newId), []);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PURCHASES, newId), []);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PARTIES, newId), []);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PARTY_TRANSACTIONS, newId), []);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.EMPLOYEES, newId), []);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.ATTENDANCE, newId), []);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.EMPLOYEE_LEDGER, newId), []);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.RAW_MATERIALS, newId), initialRawMaterials);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.PRODUCTION_BATCHES, newId), []);

    setCompaniesList((prev) => [...prev, newEntry]);
    setActiveCompanyId(newId);
    setCompany(newProfile);
    setBankAccounts([]);
    setItems(initialItems);
    setInvoices([]);
    setPurchases([]);
    setParties([]);
    setPartyTransactions([]);
    setEmployees([]);
    setAttendance([]);
    setEmployeeLedger([]);
    setRawMaterials(initialRawMaterials);
    setProductionBatches([]);
    setFieldOrders([]);
    setQuotations([]);
    setBoms([]);
    setProductionOrders([]);
    setDailyCash({
      id: `cash-${todayBs}`,
      dateBs: todayBs,
      openingCash: 0,
      totalCashSales: 0,
      totalBankTransfers: 0,
      totalAdvancesGiven: 0,
      closingCashInHand: 0
    });

    return newEntry;
  };

  const executeDeleteCompanyById = (companyId: string) => {
    const target = companiesList.find((c) => c.id === companyId);
    if (!target) return;
    if (companiesList.length <= 1) {
      executeDeleteCompany();
      return;
    }

    const remaining = companiesList.filter((c) => c.id !== companyId);
    setCompaniesList(remaining);

    // Clear scoped storage keys for deleted company
    if (typeof window !== 'undefined' && companyId !== 'comp-default') {
      Object.values(STORAGE_KEYS).forEach((baseKey) => {
        localStorage.removeItem(getCompanyScopedKey(baseKey, companyId));
      });
    }

    if (activeCompanyId === companyId && remaining.length > 0) {
      switchCompany(remaining[0].id);
    }
  };

  const deleteCompanyById = (companyId: string, ownerPin?: string): { success: boolean; message: string } => {
    const target = companiesList.find((c) => c.id === companyId);
    if (!target) {
      return { success: false, message: 'कम्पनी फेला परेन।' };
    }
    if (ownerPin && verifyOwnerPin(ownerPin)) {
      executeDeleteCompanyById(companyId);
      return {
        success: true,
        message: `'${target.name}' कम्पनी र सोको डाटा हटाइयो।`
      };
    }

    requireOwnerKey(
      `कम्पनी र सोको सम्पूर्ण डाटा मेटाउने (${target.name})`,
      () => {
        executeDeleteCompanyById(companyId);
      },
      'DELETE'
    );

    return {
      success: true,
      message: `कम्पनी '${target.name}' मेटाउन मालिकको साँचो (Owner Key) प्रविष्ट गर्नुहोस्।`
    };
  };

  // NOTE: cross-device sync is handled by utils/syncEngine.ts (all data is restored/saved automatically).

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    saveStoredData(STORAGE_KEYS.LANGUAGE, lang);
  };

  const setCurrentRole = (role: UserRole) => {
    if (isStaffLogin()) return; // a staff login can never switch itself to another role
    setCurrentRoleState(role);
    saveStoredData(STORAGE_KEYS.USER_ROLE, role);
  };

  const t = translations[language];

  // Billing: Create Invoice with Bank/Account and Staff Deduction tracking
  const createInvoice = (params: CreateInvoiceParams): Invoice => {
    // BS र AD सधैं एउटै मितिबाट मिल्ने गरी (बिलमा BS फेरे AD स्वतः फेरिन्छ)
    const { dateBs, dateAd } = resolveDatePair({ bs: params.customDateBs, ad: params.customDateAd });
    const fiscalYear = company.fiscalYear || getFiscalYear(dateBs);

    const sameTypeInvoices = invoices.filter((i) => i.billType === params.billType);
    // Use highest existing series number (not count) so deleted bills never cause duplicate bill numbers
    const highestSeries = sameTypeInvoices.reduce((max, inv) => {
      const m = /(\d+)\s*$/.exec(inv.invoiceNo || '');
      const n = m ? parseInt(m[1], 10) : 0;
      return Number.isFinite(n) && n > max ? n : max;
    }, 0);
    const nextSeriesNum = Math.max(sameTypeInvoices.length, highestSeries) + 1;
    const seriesPadded = String(nextSeriesNum).padStart(4, '0');
    const prefix = params.billType === 'VAT' ? company.vatBillPrefix : company.nonVatBillPrefix;
    const autoInvoiceNo = `${prefix}-${fiscalYear}-${seriesPadded}`;
    const invoiceNo = params.manualInvoiceNo?.trim() ? params.manualInvoiceNo.trim() : autoInvoiceNo;

    const totals = calculateInvoiceTotals(
      params.items,
      params.discountPercent,
      params.freightCharge,
      params.billType === 'VAT',
      params.manualExemptAmount
    );

    const prevDue = params.previousDue || 0;
    const grandTotal = totals.grandTotal;
    const netTotalDue = prevDue + grandTotal;

    // Calculate actual amount paid today
    const amountPaid = params.amountPaid !== undefined
      ? Math.max(0, params.amountPaid)
      : (params.paymentMode === 'CREDIT' ? 0 : grandTotal);
    
    // Remaining outstanding balance after today's payment
    const remainingDue = Math.max(0, netTotalDue - amountPaid);

    const now = new Date();
    const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    const newInvoice: Invoice = {
      id: `inv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      billType: params.billType,
      invoiceNo,
      seriesNumber: nextSeriesNum,
      fiscalYear,
      dateBs,
      dateAd,
      entryDateBs: getTodayBsString(),
      time,
      customerName: params.customerName.trim() || 'खुद्रा ग्राहक (Cash/Retail)',
      customerPan: params.customerPan?.trim(),
      customerAddress: params.customerAddress?.trim(),
      customerPhone: params.customerPhone?.trim(),
      partyId: params.partyId,
      isEmployeePurchase: params.isEmployeePurchase,
      employeeId: params.employeeId,
      employeeName: params.employeeName,
      previousDue: prevDue,
      netTotalDue: netTotalDue,
      amountPaid: amountPaid,
      remainingDue: remainingDue,
      paymentDueDate: params.paymentDueDate,
      items: params.items,
      subtotal: totals.subtotal,
      discountPercent: params.discountPercent,
      discountAmount: totals.discountAmount,
      freightCharge: totals.freightCharge,
      taxableAmount: totals.taxableAmount,
      exemptAmount: totals.exemptAmount,
      vatAmount: totals.vatAmount,
      grandTotal: totals.grandTotal,
      paymentMode: params.paymentMode,
      bankName: params.bankName,
      bankAccountNo: params.bankAccountNo,
      transactionRef: params.transactionRef,
      photoUrl: params.photoUrl,
      notes: params.notes,
      stockDeducted: params.deductStock !== false,
      editCount: 0,
      status: 'ACTIVE',
      createdRole: currentRole,
      billedBy: params.billedBy || currentAccount?.ownerName || (currentRole === 'OWNER' ? 'Rajan Gopali' : 'काउन्टर कर्मचारी'),
      billedByMobile: currentAccount?.mobileNumber,
      billedByRole: currentAccount?.assignedRole || currentRole
    };

    // If Bank/FonePay payment: Customer deposited in bank -> automatically increase bank balance!
    if (params.paymentMode === 'BANK_FONEPAY' && amountPaid > 0) {
      setBankAccounts((prev) => {
        let matched = false;
        const next = prev.map((acc) => {
          if (
            (params.bankAccountNo && acc.accountNumber === params.bankAccountNo) ||
            (params.bankName && acc.bankName.toLowerCase().includes(params.bankName.toLowerCase().slice(0, 4)))
          ) {
            matched = true;
            return {
              ...acc,
              currentBalance: acc.currentBalance + amountPaid
            };
          }
          return acc;
        });
        if (!matched && next.length > 0) {
          next[0] = {
            ...next[0],
            currentBalance: next[0].currentBalance + amountPaid
          };
        }
        return next;
      });
    }

    // Auto Deduct Stock from Inventory (unless explicitly disabled)
    if (params.deductStock !== false) {
      setItems((prevItems) => {
        const updated = [...prevItems];
        params.items.forEach((line) => {
          const idx = updated.findIndex((it) => it.id === line.itemId);
          if (idx !== -1) {
            const current = updated[idx];
            const ratio = current.secondaryUnitRatio && current.secondaryUnitRatio > 1 ? current.secondaryUnitRatio : 1;
            const stockDelta =
              line.primaryQtyEquivalent !== undefined
                ? line.primaryQtyEquivalent
                : line.unitMode === 'SECONDARY' && ratio > 1
                ? line.quantity / ratio
                : line.quantity;
            const newCurrentStock = Math.max(0, Math.round((current.currentStock - stockDelta) * 10000) / 10000);
            let newVatStock = current.vatStock;
            let newNonVatStock = current.nonVatStock;
            if (params.billType === 'VAT' && current.vatStock !== undefined) {
              newVatStock = Math.max(0, Math.round((current.vatStock - stockDelta) * 10000) / 10000);
            } else if (params.billType === 'NON_VAT' && current.nonVatStock !== undefined) {
              newNonVatStock = Math.max(0, Math.round((current.nonVatStock - stockDelta) * 10000) / 10000);
            }
            updated[idx] = {
              ...current,
              currentStock: newCurrentStock,
              vatStock: newVatStock,
              nonVatStock: newNonVatStock
            };
          }
        });
        return updated;
      });
    }

    // If Employee Purchase: Deduct automatically from attendance / salary ledger!
    if ((params.isEmployeePurchase || params.paymentMode === 'STAFF_SALARY_DEDUCT') && params.employeeId) {
      const deductionEntry: EmployeeLedgerEntry = {
        id: `eledg-${Date.now()}`,
        employeeId: params.employeeId,
        dateBs,
        dateAd,
        type: 'PURCHASE_DEDUCTION',
        amount: totals.grandTotal,
        referenceBillNo: invoiceNo,
        notes: `सामान खरिद बिल नं. ${invoiceNo} (काउन्टरबाट तलब कट्टी)`
      };
      setEmployeeLedger((prev) => [deductionEntry, ...prev]);
    }

    // Update customer ledger / dues if there is remaining due or customer paid
    if (params.partyId) {
      setParties((prevParties) =>
        prevParties.map((p) =>
          p.id === params.partyId
            ? {
                ...p,
                address: params.customerAddress || p.address,
                phone: params.customerPhone || p.phone,
                panNo: params.customerPan || p.panNo,
                currentBalance: remainingDue
              }
            : p
        )
      );
    } else if (params.customerName.trim() && remainingDue > 0) {
      setParties((prevParties) => {
        const cleanName = params.customerName.trim().toLowerCase();
        const cleanAddr = (params.customerAddress || '').trim().toLowerCase();
        const sameNameParties = prevParties.filter(
          (p) => p.name.trim().toLowerCase() === cleanName
        );
        const existing = sameNameParties.find((p) => {
          const pAddr = (p.address || '').trim().toLowerCase();
          if (cleanAddr && pAddr) return pAddr === cleanAddr;
          if (!cleanAddr && sameNameParties.length === 1) return true;
          return pAddr === cleanAddr;
        });

        if (!existing) {
          return [
            ...prevParties,
            {
              id: `pty-${Date.now()}`,
              name: params.customerName.trim(),
              panNo: params.customerPan || '',
              address: params.customerAddress || '',
              phone: params.customerPhone || '',
              partyType: 'CUSTOMER',
              openingBalance: remainingDue,
              currentBalance: remainingDue
            }
          ];
        } else {
          return prevParties.map((p) =>
            p.id === existing.id
              ? {
                  ...p,
                  address: params.customerAddress || p.address,
                  phone: params.customerPhone || p.phone,
                  panNo: params.customerPan || p.panNo,
                  currentBalance: remainingDue
                }
              : p
          );
        }
      });
    }

    setInvoices((prev) => [newInvoice, ...prev]);

    logAuditAction({
      actionType: 'INVOICE_CREATED',
      module: 'BILLING',
      severity: 'INFO',
      targetId: newInvoice.invoiceNo,
      summaryNe: `बिल काटियो: ${newInvoice.invoiceNo} (${newInvoice.billType}) — रु. ${newInvoice.grandTotal.toLocaleString('en-IN')} (${newInvoice.customerName})`,
      summaryEn: `Invoice Created: ${newInvoice.invoiceNo} (${newInvoice.billType}) — Rs. ${newInvoice.grandTotal.toLocaleString('en-IN')} for ${newInvoice.customerName}`,
      details: `Bill No: ${newInvoice.invoiceNo} | Type: ${newInvoice.billType} | Customer: ${newInvoice.customerName} | Mode: ${newInvoice.paymentMode} | Items: ${newInvoice.items.length} | Total: Rs. ${newInvoice.grandTotal}`
    });

    return newInvoice;
  };

  // Cancel bill, restore stock, and reverse employee ledger deduction if applicable
  const cancelInvoice = (invoiceId: string) => {
    const target = invoices.find((i) => i.id === invoiceId);
    if (!target || target.status === 'CANCELLED') return;

    requireOwnerKey(
      `बिक्री बिल रद्द / मेटाउने: ${target.invoiceNo} (${target.customerName} — रु. ${target.grandTotal})`,
      () => {
        setItems((prevItems) => {
          const updated = [...prevItems];
          target.items.forEach((line) => {
            const idx = updated.findIndex((it) => it.id === line.itemId);
            if (idx !== -1) {
              const current = updated[idx];
              const ratio = current.secondaryUnitRatio && current.secondaryUnitRatio > 1 ? current.secondaryUnitRatio : 1;
              const stockDelta =
                line.primaryQtyEquivalent !== undefined
                  ? line.primaryQtyEquivalent
                  : line.unitMode === 'SECONDARY' && ratio > 1
                  ? line.quantity / ratio
                  : line.quantity;
              updated[idx] = {
                ...current,
                currentStock: Math.round((current.currentStock + stockDelta) * 10000) / 10000
              };
            }
          });
          return updated;
        });

        if (target.isEmployeePurchase || target.employeeId) {
          setEmployeeLedger((prev) =>
            prev.filter((entry) => entry.referenceBillNo !== target.invoiceNo)
          );
        }

        if (target.partyId && target.paymentMode === 'CREDIT') {
          setParties((prev) =>
            prev.map((p) =>
              p.id === target.partyId
                ? { ...p, openingBalance: Math.max(0, p.openingBalance - target.grandTotal) }
                : p
            )
          );
        }

        setInvoices((prev) =>
          prev.map((i) => (i.id === invoiceId ? { ...i, status: 'CANCELLED' } : i))
        );

        logAuditAction({
          actionType: 'INVOICE_CANCELLED',
          module: 'BILLING',
          severity: 'CRITICAL',
          targetId: target.invoiceNo,
          summaryNe: `बिल रद्द गरियो: ${target.invoiceNo} (रु. ${target.grandTotal.toLocaleString('en-IN')}) — ग्राहक: ${target.customerName}`,
          summaryEn: `Invoice Cancelled: ${target.invoiceNo} (Rs. ${target.grandTotal.toLocaleString('en-IN')}) — Customer: ${target.customerName}`,
          details: `Cancelled Bill: ${target.invoiceNo} | Reversed Total: Rs. ${target.grandTotal} | Restored Items: ${target.items.map((x) => `${x.name} (+${x.quantity})`).join(', ')}`
        });
      },
      'DELETE'
    );
  };


  // ---------------------------------------------------------------------------
  // बिल सच्याउने (Edit Bill, with items) — पुरानो असर उल्टाएर नयाँ असर लागू गर्छ
  // ---------------------------------------------------------------------------
  const invoicesRef = useRef<Invoice[]>(invoices);
  invoicesRef.current = invoices;
  // एउटै सच्याइ (id + editCount) दोस्रो पटक चल्न नदिन (double save / double Owner-Key execute)
  const appliedInvoiceEditsRef = useRef<Set<string>>(new Set());
  const [invoiceToEditId, setInvoiceToEditId] = useState<string | null>(null);

  const stockDeltaOf = (it: Item | undefined, line: InvoiceItem): number => {
    const ratio = it && it.secondaryUnitRatio && it.secondaryUnitRatio > 1 ? it.secondaryUnitRatio : 1;
    return line.primaryQtyEquivalent !== undefined
      ? line.primaryQtyEquivalent
      : line.unitMode === 'SECONDARY' && ratio > 1
      ? line.quantity / ratio
      : line.quantity;
  };

  const adjustBankFor = (
    accs: BankAccount[],
    ref: { bankAccountNo?: string; bankName?: string },
    delta: number
  ): BankAccount[] => {
    if (!delta) return accs;
    let matched = false;
    const next = accs.map((acc) => {
      if (
        (ref.bankAccountNo && acc.accountNumber === ref.bankAccountNo) ||
        (ref.bankName && acc.bankName.toLowerCase().includes(ref.bankName.toLowerCase().slice(0, 4)))
      ) {
        matched = true;
        return { ...acc, currentBalance: acc.currentBalance + delta };
      }
      return acc;
    });
    if (!matched && next.length > 0) {
      next[0] = { ...next[0], currentBalance: next[0].currentBalance + delta };
    }
    return next;
  };

  const startEditInvoice = (invoiceId: string) => {
    const inv = invoicesRef.current.find((i) => i.id === invoiceId);
    if (!inv) return;
    if (inv.status === 'CANCELLED') {
      showGlobalSecurityToast('रद्द भइसकेको बिल सच्याउन मिल्दैन (Cancelled bill cannot be edited).', 'warn');
      return;
    }
    if (isFiscalYearClosed(inv.fiscalYear) && inv.fiscalYear !== company.fiscalYear) {
      showGlobalSecurityToast('यो बिल बन्द भइसकेको आर्थिक वर्षको हो — सच्याउन पहिले आ.व. फेरि सक्रिय गर्नुहोस्।', 'warn');
      return;
    }
    setInvoiceToEditId(invoiceId);
    setBillingSubTab('SALES');
    setActiveTab('billing');
  };
  const clearInvoiceToEdit = () => setInvoiceToEditId(null);

  const updateInvoice = (
    invoiceId: string,
    params: CreateInvoiceParams,
    callbacks?: { onSuccess?: (inv: Invoice) => void; onError?: (message: string) => void; onCancel?: () => void }
  ) => {
    const old = invoicesRef.current.find((i) => i.id === invoiceId);
    if (!old) {
      callbacks?.onError?.('बिल भेटिएन (Invoice not found)');
      return;
    }
    if (old.status === 'CANCELLED') {
      callbacks?.onError?.('रद्द भइसकेको बिल सच्याउन मिल्दैन');
      return;
    }
    const editKey = `${old.id}:${old.editCount || 0}`;
    if (appliedInvoiceEditsRef.current.has(editKey)) return; // पहिले नै सुरक्षित भइसकेको

    const manualNo = params.manualInvoiceNo?.trim();
    if (manualNo && manualNo.toLowerCase() !== old.invoiceNo.trim().toLowerCase()) {
      const clash = invoicesRef.current.some(
        (i) => i.id !== old.id && i.invoiceNo.trim().toLowerCase() === manualNo.toLowerCase()
      );
      if (clash) {
        callbacks?.onError?.(`बिल नं. ${manualNo} पहिले नै प्रयोगमा छ (Duplicate bill number)`);
        return;
      }
    }

    requireOwnerKey(
      `बिक्री बिल सच्याउने: ${old.invoiceNo} (${old.customerName} — रु. ${old.grandTotal})`,
      () => {
        // दोहोरो execute रोक्ने
        if (appliedInvoiceEditsRef.current.has(editKey)) return;
        const latest = invoicesRef.current.find((i) => i.id === invoiceId);
        if (!latest || latest.status === 'CANCELLED' || (latest.editCount || 0) !== (old.editCount || 0)) {
          callbacks?.onError?.('बिल यसबीच परिवर्तन भइसकेको छ — फेरि खोलेर सच्याउनुहोस्');
          return;
        }
        appliedInvoiceEditsRef.current.add(editKey);

        const hasCustomDate = !!(params.customDateBs || params.customDateAd);
        const dates = hasCustomDate
          ? resolveDatePair({ bs: params.customDateBs, ad: params.customDateAd })
          : { dateBs: old.dateBs, dateAd: old.dateAd };
        const dateBs = dates.dateBs;
        const dateAd = dates.dateAd;

        const totals = calculateInvoiceTotals(
          params.items,
          params.discountPercent,
          params.freightCharge,
          params.billType === 'VAT',
          params.manualExemptAmount
        );
        const prevDue = params.previousDue || 0;
        const grandTotal = totals.grandTotal;
        const netTotalDue = prevDue + grandTotal;
        const amountPaid =
          params.amountPaid !== undefined
            ? Math.max(0, params.amountPaid)
            : params.paymentMode === 'CREDIT'
            ? 0
            : grandTotal;
        const remainingDue = Math.max(0, netTotalDue - amountPaid);
        const newStockDeducted = params.deductStock !== false;
        const oldStockDeducted = old.stockDeducted !== false;
        const oldPaid =
          old.amountPaid !== undefined
            ? old.amountPaid
            : old.paymentMode === 'CREDIT'
            ? 0
            : old.grandTotal;
        const oldRemaining =
          old.remainingDue !== undefined
            ? old.remainingDue
            : Math.max(0, (old.previousDue || 0) + old.grandTotal - oldPaid);

        // 1. गोदाम स्टक: पुरानो फिर्ता, नयाँ घटाउने
        setItems((prevItems) => {
          const updated = [...prevItems];
          if (oldStockDeducted) {
            old.items.forEach((line) => {
              const idx = updated.findIndex((it) => it.id === line.itemId);
              if (idx === -1) return;
              const cur = updated[idx];
              const d = stockDeltaOf(cur, line);
              updated[idx] = {
                ...cur,
                currentStock: Math.round((cur.currentStock + d) * 10000) / 10000,
                vatStock:
                  old.billType === 'VAT' && cur.vatStock !== undefined
                    ? Math.round((cur.vatStock + d) * 10000) / 10000
                    : cur.vatStock,
                nonVatStock:
                  old.billType === 'NON_VAT' && cur.nonVatStock !== undefined
                    ? Math.round((cur.nonVatStock + d) * 10000) / 10000
                    : cur.nonVatStock
              };
            });
          }
          if (newStockDeducted) {
            params.items.forEach((line) => {
              const idx = updated.findIndex((it) => it.id === line.itemId);
              if (idx === -1) return;
              const cur = updated[idx];
              const d = stockDeltaOf(cur, line);
              updated[idx] = {
                ...cur,
                currentStock: Math.max(0, Math.round((cur.currentStock - d) * 10000) / 10000),
                vatStock:
                  params.billType === 'VAT' && cur.vatStock !== undefined
                    ? Math.max(0, Math.round((cur.vatStock - d) * 10000) / 10000)
                    : cur.vatStock,
                nonVatStock:
                  params.billType === 'NON_VAT' && cur.nonVatStock !== undefined
                    ? Math.max(0, Math.round((cur.nonVatStock - d) * 10000) / 10000)
                    : cur.nonVatStock
              };
            });
          }
          return updated;
        });

        // 2. बैंक: पुरानो जम्मा घटाउने, नयाँ थप्ने
        const oldBank = old.paymentMode === 'BANK_FONEPAY' && oldPaid > 0;
        const newBank = params.paymentMode === 'BANK_FONEPAY' && amountPaid > 0;
        if (oldBank || newBank) {
          setBankAccounts((prev) => {
            let next = prev;
            if (oldBank) next = adjustBankFor(next, { bankAccountNo: old.bankAccountNo, bankName: old.bankName }, -oldPaid);
            if (newBank) next = adjustBankFor(next, { bankAccountNo: params.bankAccountNo, bankName: params.bankName }, amountPaid);
            return next;
          });
        }

        // 3. कर्मचारी तलब कट्टी: पुरानो हटाएर नयाँ राख्ने
        const wasStaff = !!(old.isEmployeePurchase || old.employeeId);
        const isStaff = !!((params.isEmployeePurchase || params.paymentMode === 'STAFF_SALARY_DEDUCT') && params.employeeId);
        const finalInvoiceNo = manualNo || old.invoiceNo;
        if (wasStaff || isStaff) {
          setEmployeeLedger((prev) => {
            const kept = prev.filter((e) => e.referenceBillNo !== old.invoiceNo);
            if (!isStaff) return kept;
            const entry: EmployeeLedgerEntry = {
              id: `eledg-${Date.now()}`,
              employeeId: params.employeeId as string,
              dateBs,
              dateAd,
              type: 'PURCHASE_DEDUCTION',
              amount: grandTotal,
              referenceBillNo: finalInvoiceNo,
              notes: `सामान खरिद बिल नं. ${finalInvoiceNo} (काउन्टरबाट तलब कट्टी)`
            };
            return [entry, ...kept];
          });
        }

        // 4. पार्टीको बाँकी: फरकमात्र मिलाउने (पछिका बिलको असर नबिगार्न)
        const sameParty = old.partyId && old.partyId === params.partyId;
        if (old.partyId || params.partyId) {
          setParties((prev) =>
            prev.map((p) => {
              if (sameParty && p.id === params.partyId) {
                const base = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
                return {
                  ...p,
                  address: params.customerAddress || p.address,
                  phone: params.customerPhone || p.phone,
                  panNo: params.customerPan || p.panNo,
                  currentBalance: Math.max(0, base + (remainingDue - oldRemaining))
                };
              }
              if (old.partyId && p.id === old.partyId) {
                const base = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
                return { ...p, currentBalance: Math.max(0, base - Math.max(0, old.grandTotal - oldPaid)) };
              }
              if (params.partyId && p.id === params.partyId) {
                return {
                  ...p,
                  address: params.customerAddress || p.address,
                  phone: params.customerPhone || p.phone,
                  panNo: params.customerPan || p.panNo,
                  currentBalance: remainingDue
                };
              }
              return p;
            })
          );
        }

        // 5. बिल आफैँ — उही id / बिल नं. / सिरिज मै बदल्ने (नयाँ बिल थपिँदैन)
        const updatedInvoice: Invoice = {
          ...old,
          billType: params.billType,
          invoiceNo: finalInvoiceNo,
          dateBs,
          dateAd,
          customerName: params.customerName.trim() || 'खुद्रा ग्राहक (Cash/Retail)',
          customerPan: params.customerPan?.trim(),
          customerAddress: params.customerAddress?.trim(),
          customerPhone: params.customerPhone?.trim(),
          partyId: params.partyId,
          isEmployeePurchase: params.isEmployeePurchase,
          employeeId: params.employeeId,
          employeeName: params.employeeName,
          previousDue: prevDue,
          netTotalDue,
          amountPaid,
          remainingDue,
          paymentDueDate: params.paymentDueDate,
          items: params.items,
          subtotal: totals.subtotal,
          discountPercent: params.discountPercent,
          discountAmount: totals.discountAmount,
          freightCharge: totals.freightCharge,
          taxableAmount: totals.taxableAmount,
          exemptAmount: totals.exemptAmount,
          vatAmount: totals.vatAmount,
          grandTotal,
          paymentMode: params.paymentMode,
          bankName: params.bankName,
          bankAccountNo: params.bankAccountNo,
          transactionRef: params.transactionRef,
          photoUrl: params.photoUrl ?? old.photoUrl,
          notes: params.notes,
          stockDeducted: newStockDeducted,
          editCount: (old.editCount || 0) + 1,
          lastEditedAtBs: getTodayBsString(),
          lastEditedBy: currentAccount?.ownerName || (currentRole === 'OWNER' ? 'Owner' : 'Staff')
        };
        setInvoices((prev) => prev.map((i) => (i.id === invoiceId ? updatedInvoice : i)));

        logAuditAction({
          actionType: 'INVOICE_EDITED',
          module: 'BILLING',
          severity: 'WARNING',
          targetId: updatedInvoice.invoiceNo,
          summaryNe: `बिल सच्याइयो: ${updatedInvoice.invoiceNo} — रु. ${old.grandTotal.toLocaleString('en-IN')} → रु. ${grandTotal.toLocaleString('en-IN')} (${updatedInvoice.customerName})`,
          summaryEn: `Invoice Edited: ${updatedInvoice.invoiceNo} — Rs. ${old.grandTotal.toLocaleString('en-IN')} → Rs. ${grandTotal.toLocaleString('en-IN')} (${updatedInvoice.customerName})`,
          details: `Before: ${old.items.map((x) => `${x.name} x${x.quantity}`).join(', ')} | After: ${params.items.map((x) => `${x.name} x${x.quantity}`).join(', ')}`
        });

        callbacks?.onSuccess?.(updatedInvoice);
      },
      'EDIT',
      {
        dedupeKey: `edit-invoice:${old.id}`,
        onCancel: callbacks?.onCancel
      }
    );
  };

  // Permanently delete a sales bill (Owner Key required). Active bills are reversed first (stock, staff deduction, credit due).
  const deleteInvoice = (invoiceId: string) => {
    const target = invoices.find((i) => i.id === invoiceId);
    if (!target) return;

    requireOwnerKey(
      `बिक्री बिल सदाको लागि मेटाउने: ${target.invoiceNo} (${target.customerName} — रु. ${target.grandTotal})`,
      () => {
        // A cancelled bill already had stock/balance reversed — only reverse if still ACTIVE
        if (target.status !== 'CANCELLED') {
          setItems((prevItems) => {
            const updated = [...prevItems];
            target.items.forEach((line) => {
              const idx = updated.findIndex((it) => it.id === line.itemId);
              if (idx !== -1) {
                const current = updated[idx];
                const ratio = current.secondaryUnitRatio && current.secondaryUnitRatio > 1 ? current.secondaryUnitRatio : 1;
                const stockDelta =
                  line.primaryQtyEquivalent !== undefined
                    ? line.primaryQtyEquivalent
                    : line.unitMode === 'SECONDARY' && ratio > 1
                    ? line.quantity / ratio
                    : line.quantity;
                updated[idx] = {
                  ...current,
                  currentStock: Math.round((current.currentStock + stockDelta) * 10000) / 10000
                };
              }
            });
            return updated;
          });

          if (target.isEmployeePurchase || target.employeeId) {
            setEmployeeLedger((prev) =>
              prev.filter((entry) => entry.referenceBillNo !== target.invoiceNo)
            );
          }

          if (target.partyId && target.paymentMode === 'CREDIT') {
            setParties((prev) =>
              prev.map((p) =>
                p.id === target.partyId
                  ? { ...p, openingBalance: Math.max(0, p.openingBalance - target.grandTotal) }
                  : p
              )
            );
          }
        }

        setInvoices((prev) => prev.filter((i) => i.id !== invoiceId));

        logAuditAction({
          actionType: 'INVOICE_DELETED',
          module: 'BILLING',
          severity: 'CRITICAL',
          targetId: target.invoiceNo,
          summaryNe: `बिल सदाको लागि मेटाइयो: ${target.invoiceNo} (${target.billType}) — रु. ${target.grandTotal.toLocaleString('en-IN')} — ग्राहक: ${target.customerName}`,
          summaryEn: `Invoice Permanently Deleted: ${target.invoiceNo} (${target.billType}) — Rs. ${target.grandTotal.toLocaleString('en-IN')} — Customer: ${target.customerName}`,
          details: `Deleted Bill: ${target.invoiceNo} | Status before delete: ${target.status} | Total: Rs. ${target.grandTotal} | Items: ${target.items.map((x) => `${x.name} (${x.quantity})`).join(', ')}`
        });
      },
      'DELETE'
    );
  };

  // Recurring Invoices
  const saveRecurringInvoice = (ri: RecurringInvoice) => {
    setRecurringInvoices((prev) => {
      const exists = prev.find((i) => i.id === ri.id);
      if (exists) {
        return prev.map((i) => (i.id === ri.id ? ri : i));
      }
      return [...prev, ri];
    });
  };

  const deleteRecurringInvoice = (id: string) => {
    setRecurringInvoices((prev) => prev.filter((i) => i.id !== id));
  };

  // Inventory actions: manages openingStock & currentStock
  const executeSaveItem = (item: Item) => {
    const existing = items.find((i) => i.id === item.id);
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.id === item.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = item;
        return next;
      }
      return [...prev, item];
    });

    if (existing) {
      logAuditAction({
        actionType: 'INVENTORY_UPDATED',
        module: 'INVENTORY',
        severity: existing.currentStock !== item.currentStock ? 'WARNING' : 'INFO',
        targetId: item.code,
        summaryNe: `सामान अद्यावधिक: ${item.nameNe || item.nameEn} (${item.code}) — स्टक: ${existing.currentStock} → ${item.currentStock} ${item.unit}`,
        summaryEn: `Inventory Updated: ${item.nameEn} (${item.code}) — Stock: ${existing.currentStock} → ${item.currentStock} ${item.unit}`,
        details: `Code: ${item.code} | Stock: ${existing.currentStock} → ${item.currentStock} ${item.unit} | Selling Price: Rs. ${existing.sellingPrice} → Rs. ${item.sellingPrice}`
      });
    } else {
      logAuditAction({
        actionType: 'INVENTORY_ADDED',
        module: 'INVENTORY',
        severity: 'INFO',
        targetId: item.code,
        summaryNe: `नयाँ सामान थपियो: ${item.nameNe || item.nameEn} (${item.code}) — सुरुवाती स्टक: ${item.currentStock} ${item.unit}`,
        summaryEn: `New Item Added: ${item.nameEn} (${item.code}) — Initial Stock: ${item.currentStock} ${item.unit}`,
        details: `Code: ${item.code} | Stock: ${item.currentStock} ${item.unit} | Buy: Rs. ${item.purchasePrice} | Sell: Rs. ${item.sellingPrice}`
      });
    }
  };

  const saveItem = (item: Item) => {
    // Purchase bill / stock दर्ता गर्दा master key नचाहिने
    executeSaveItem(item);
  };

  const deleteItem = (itemId: string) => {
    const target = items.find((i) => i.id === itemId);
    requireOwnerKey(
      `सामान मेटाउने: ${target?.nameNe || target?.nameEn || itemId} (${target?.code || ''})`,
      () => {
        setItems((prev) => prev.filter((i) => i.id !== itemId));
        if (target) {
          logAuditAction({
            actionType: 'INVENTORY_DELETED',
            module: 'INVENTORY',
            severity: 'CRITICAL',
            targetId: target.code,
            summaryNe: `सामान हटाइयो (Deleted): ${target.nameNe || target.nameEn} (${target.code}) — मौज्दात थियो: ${target.currentStock} ${target.unit}`,
            summaryEn: `Inventory Deleted: ${target.nameEn} (${target.code}) — Stock at deletion: ${target.currentStock} ${target.unit}`,
            details: `Deleted Item: ${target.nameEn} (${target.code}) | Stock Removed: ${target.currentStock} ${target.unit} | Value: Rs. ${target.currentStock * target.purchasePrice}`
          });
        }
      },
      'DELETE'
    );
  };

  const adjustStock = (itemId: string, newStock: number) => {
    // Purchase bill / stock दर्ता गर्दा master key नचाहिने
    const target = items.find((i) => i.id === itemId);
    const clamped = Math.max(0, newStock);
    setItems((prev) =>
      prev.map((i) => (i.id === itemId ? { ...i, currentStock: clamped } : i))
    );
    if (target) {
      const diff = clamped - target.currentStock;
      const diffLabel = diff >= 0 ? `+${diff}` : `${diff}`;
      logAuditAction({
        actionType: 'STOCK_ADJUSTED',
        module: 'INVENTORY',
        severity: 'INFO',
        targetId: target.code,
        summaryNe: `स्टक दर्ता / मौज्दात: ${target.nameNe || target.nameEn} (${target.code}) को मौज्दात ${target.currentStock} बाट ${clamped} ${target.unit} बनाइयो (${diffLabel})`,
        summaryEn: `Stock Registered: ${target.nameEn} (${target.code}) changed from ${target.currentStock} to ${clamped} ${target.unit} (${diffLabel})`,
        details: `Item: ${target.code} | Old Stock: ${target.currentStock} ${target.unit} | New Stock: ${clamped} ${target.unit} | Delta: ${diffLabel} ${target.unit}`
      });
    }
  };

  // भ्याट र नन-भ्याट स्टक मिलान तथा भौतिक मौज्दात समायोजन
  const reconcileItemStock = (
    itemId: string,
    params: {
      adjustmentQty: number;
      isAbsolute?: boolean;
      reason: string;
      vatStock?: number;
      nonVatStock?: number;
    }
  ) => {
    const target = items.find((i) => i.id === itemId);
    requireOwnerKey(
      `भौतिक स्टक मिलान (Reconcile) सच्याउने: ${target?.nameNe || target?.nameEn || itemId}`,
      () => {
        setItems((prev) =>
          prev.map((it) => {
            if (it.id !== itemId) return it;
            const newStock = params.isAbsolute
              ? Math.max(0, params.adjustmentQty)
              : Math.max(0, it.currentStock + params.adjustmentQty);
            return {
              ...it,
              currentStock: newStock,
              vatStock: params.vatStock !== undefined ? params.vatStock : (it.vatStock ?? newStock),
              nonVatStock: params.nonVatStock !== undefined ? params.nonVatStock : (it.nonVatStock ?? 0)
            };
          })
        );
        if (target) {
          const newStock = params.isAbsolute
            ? Math.max(0, params.adjustmentQty)
            : Math.max(0, target.currentStock + params.adjustmentQty);
          logAuditAction({
            actionType: 'STOCK_RECONCILED',
            module: 'INVENTORY',
            severity: 'WARNING',
            targetId: target.code,
            summaryNe: `भौतिक स्टक मिलान: ${target.nameNe || target.nameEn} (${target.code}) ${target.currentStock} → ${newStock} ${target.unit} (कारण: ${params.reason})`,
            summaryEn: `Stock Reconciled: ${target.nameEn} (${target.code}) ${target.currentStock} → ${newStock} ${target.unit} (Reason: ${params.reason})`,
            details: `Item: ${target.code} | Old: ${target.currentStock} | New: ${newStock} | VAT Stock: ${params.vatStock ?? newStock} | Non-VAT Stock: ${params.nonVatStock ?? 0} | Reason: ${params.reason}`
          });
        }
      },
      'EDIT'
    );
  };

  const recordPurchase = (
    purchaseData: Omit<PurchaseRecord, 'id'>,
    supplierMeta?: {
      partyId?: string;
      address?: string;
      phone?: string;
      amountPaidToday?: number;
    }
  ): PurchaseRecord => {
    // BS र AD मिति सधैं मिल्ने गरी
    const purDates = resolveDatePair({ bs: purchaseData.dateBs, ad: purchaseData.dateAd });
    const newPurchase: PurchaseRecord = {
      ...purchaseData,
      dateBs: purDates.dateBs,
      dateAd: purDates.dateAd,
      id: `pur-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      entryDateBs: getTodayBsString()
    };
    setPurchases((prev) => [newPurchase, ...prev]);

    const supplierNameClean = (purchaseData.supplierName || '').trim();
    const isCashGeneric =
      !supplierNameClean ||
      supplierNameClean === 'नगद आपूर्तिकर्ता' ||
      supplierNameClean.toLowerCase() === 'cash supplier';

    const paidToday =
      supplierMeta?.amountPaidToday !== undefined
        ? Math.max(0, supplierMeta.amountPaidToday)
        : purchaseData.paymentMode === 'CREDIT'
        ? 0
        : purchaseData.grandTotal;
    const unpaidOnThisBill = Math.max(0, purchaseData.grandTotal - paidToday);

    // Sync Supplier Party in Party Ledger & record the bill's payment (for ledger only — NOT a voucher)
    if (!isCashGeneric || supplierMeta?.partyId) {
      // पार्टी पहिले नै यहीं (updater बाहिर) छुट्याउने — नत्र payment रेकर्डमा गलत partyId जान्थ्यो
      const matchedParty = parties.find(
        (p) =>
          (supplierMeta?.partyId && p.id === supplierMeta.partyId) ||
          (isSupplierParty(p) && p.name.trim().toLowerCase() === supplierNameClean.toLowerCase())
      );
      const resolvedPartyId =
        matchedParty?.id || `pty-sup-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      setParties((prevParties) => {
        const existing = prevParties.find((p) => p.id === resolvedPartyId);
        if (existing) {
          const prevBal = existing.currentBalance !== undefined ? existing.currentBalance : existing.openingBalance || 0;
          return prevParties.map((p) =>
            p.id === existing.id
              ? {
                  ...p,
                  panNo: purchaseData.supplierPan || p.panNo,
                  address: supplierMeta?.address || p.address,
                  phone: supplierMeta?.phone || p.phone,
                  paidAmount: (p.paidAmount || 0) + paidToday,
                  currentBalance: Math.max(0, prevBal + unpaidOnThisBill)
                }
              : p
          );
        }
        return [
          {
            id: resolvedPartyId,
            name: supplierNameClean,
            panNo: purchaseData.supplierPan || '',
            address: supplierMeta?.address || 'नेपाल',
            phone: supplierMeta?.phone || '',
            partyType: 'SUPPLIER',
            type: 'SUPPLIER',
            openingBalance: unpaidOnThisBill,
            paidAmount: paidToday,
            currentBalance: unpaidOnThisBill
          },
          ...prevParties
        ];
      });

      if (paidToday > 0) {
        const paymentTxn: PartyTransaction = {
          id: `ptx-pur-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          autoFromPurchase: true,
          partyId: resolvedPartyId,
          partyName: supplierNameClean,
          partyAddress: supplierMeta?.address,
          partyPhone: supplierMeta?.phone,
          dateBs: newPurchase.dateBs,
          dateAd: newPurchase.dateAd,
          type: 'PAYMENT_TO_SUPPLIER',
          amount: paidToday,
          paymentMode: purchaseData.paymentMode === 'BANK_FONEPAY' ? 'BANK' : 'CASH',
          referenceNo: purchaseData.purchaseBillNo,
          notes: `खरिद बिल नं. ${purchaseData.purchaseBillNo} भुक्तानी (${purchaseData.itemsSummary})`
        };
        setPartyTransactions((prev) => [paymentTxn, ...prev]);
      }
    }

    logAuditAction({
      actionType: 'PURCHASE_RECORDED',
      module: 'PURCHASE',
      severity: 'INFO',
      targetId: newPurchase.purchaseBillNo,
      summaryNe: `खरिद बिल दर्ता: ${newPurchase.purchaseBillNo} — रु. ${newPurchase.grandTotal.toLocaleString('en-IN')} (${newPurchase.supplierName})`,
      summaryEn: `Purchase Recorded: ${newPurchase.purchaseBillNo} — Rs. ${newPurchase.grandTotal.toLocaleString('en-IN')} from ${newPurchase.supplierName}`,
      details: `Bill: ${newPurchase.purchaseBillNo} | Supplier: ${newPurchase.supplierName} | Items: ${newPurchase.itemsSummary} | Total: Rs. ${newPurchase.grandTotal}`
    });

    // If purchase paid via bank -> deduct bank balance automatically!
    if (purchaseData.paymentMode === 'BANK_FONEPAY' && paidToday > 0) {
      setBankAccounts((prev) => {
        return prev.map((b, idx) => {
          if (
            (purchaseData.bankAccountId && b.id === purchaseData.bankAccountId) ||
            (purchaseData.bankAccountNo && b.accountNumber === purchaseData.bankAccountNo) ||
            (purchaseData.bankName && b.bankName.toLowerCase().includes(purchaseData.bankName.toLowerCase().slice(0, 4))) ||
            (!purchaseData.bankAccountId && !purchaseData.bankAccountNo && !purchaseData.bankName && idx === 0)
          ) {
            return {
              ...b,
              currentBalance: b.currentBalance - paidToday
            };
          }
          return b;
        });
      });
    }

    return newPurchase;
  };

  // Delete a purchase bill and fully reverse what recording it did:
  // inventory stock, supplier balance / paid amount, supplier payment entry and bank balance.
  const deletePurchase = (purchaseId: string) => {
    const target = purchases.find((p) => p.id === purchaseId);
    if (!target) return;

    requireOwnerKey(
      `खरिद बिल मेटाउने: ${target.purchaseBillNo} (${target.supplierName || ''})`,
      () => {
        const supplierKey = (target.supplierName || '').trim().toLowerCase();

        // 1. Supplier payment entry created when this bill was recorded (linked by bill no + supplier name)
        const payTxns = partyTransactions.filter(
          (tx) =>
            tx.type === 'PAYMENT_TO_SUPPLIER' &&
            tx.referenceNo === target.purchaseBillNo &&
            (tx.partyName || '').trim().toLowerCase() === supplierKey
        );
        const paidFromTxn = payTxns.reduce((sum, tx) => sum + tx.amount, 0);
        const paidToday =
          payTxns.length > 0
            ? paidFromTxn
            : target.paymentMode === 'CREDIT'
            ? 0
            : target.grandTotal;

        // 2. Reverse supplier balance (only when a supplier ledger entry was created/updated for this bill)
        const isCashGeneric =
          !supplierKey || supplierKey === 'नगद आपूर्तिकर्ता' || supplierKey === 'cash supplier';
        const linkedParty =
          (payTxns.length > 0 && parties.find((p) => p.id === payTxns[0].partyId)) ||
          (!isCashGeneric ? parties.find((p) => p.name.trim().toLowerCase() === supplierKey) : undefined);
        if (linkedParty) {
          const paidForParty = payTxns.length > 0 ? paidFromTxn : 0;
          const unpaidOnBill = Math.max(0, target.grandTotal - paidForParty);
          setParties((prev) =>
            prev.map((p) =>
              p.id === linkedParty.id
                ? {
                    ...p,
                    paidAmount: Math.max(0, (p.paidAmount || 0) - paidForParty),
                    currentBalance: Math.max(
                      0,
                      (p.currentBalance !== undefined ? p.currentBalance : p.openingBalance || 0) - unpaidOnBill
                    )
                  }
                : p
            )
          );
        }
        if (payTxns.length > 0) {
          const removeIds = new Set(payTxns.map((tx) => tx.id));
          setPartyTransactions((prev) => prev.filter((tx) => !removeIds.has(tx.id)));
        }

        // 3. Give money back to the bank account if the bill was paid via bank
        if (target.paymentMode === 'BANK_FONEPAY' && paidToday > 0) {
          setBankAccounts((prev) =>
            prev.map((b, idx) => {
              if (
                (target.bankAccountId && b.id === target.bankAccountId) ||
                (target.bankAccountNo && b.accountNumber === target.bankAccountNo) ||
                (target.bankName && b.bankName.toLowerCase().includes(target.bankName.toLowerCase().slice(0, 4))) ||
                (!target.bankAccountId && !target.bankAccountNo && !target.bankName && idx === 0)
              ) {
                return { ...b, currentBalance: b.currentBalance + paidToday };
              }
              return b;
            })
          );
        }

        // 4. Reverse inventory stock added by this bill (same item matching as when it was added)
        const stockNotes: string[] = [];
        if (target.items && target.items.length > 0) {
          setItems((prevItems) => {
            const updated = [...prevItems];
            (target.items || []).forEach((line) => {
              const idx = updated.findIndex(
                (i) =>
                  i.id === line.itemId ||
                  i.nameNe.toLowerCase() === line.name.toLowerCase() ||
                  i.nameEn.toLowerCase() === line.name.toLowerCase()
              );
              if (idx === -1) return;
              const current = updated[idx];
              const ratio = current.secondaryUnitRatio && current.secondaryUnitRatio > 0 ? current.secondaryUnitRatio : 1;
              const qty =
                line.primaryQtyEquivalent !== undefined
                  ? line.primaryQtyEquivalent
                  : line.unitMode === 'SECONDARY'
                  ? line.quantity / ratio
                  : line.quantity;
              if (qty > 0) {
                updated[idx] = {
                  ...current,
                  currentStock: Math.max(0, Math.round((current.currentStock - qty) * 10000) / 10000)
                };
                stockNotes.push(`${line.name} (-${qty})`);
              }
            });
            return updated;
          });
        }

        setPurchases((prev) => prev.filter((p) => p.id !== purchaseId));

        logAuditAction({
          actionType: 'PURCHASE_DELETED',
          module: 'PURCHASE',
          severity: 'CRITICAL',
          targetId: target.purchaseBillNo,
          summaryNe: `खरिद बिल मेटाइयो: ${target.purchaseBillNo} — रु. ${target.grandTotal.toLocaleString('en-IN')} (${target.supplierName})`,
          summaryEn: `Purchase Deleted: ${target.purchaseBillNo} — Rs. ${target.grandTotal.toLocaleString('en-IN')} from ${target.supplierName}`,
          details: `Bill: ${target.purchaseBillNo} | Supplier: ${target.supplierName} | Total: Rs. ${target.grandTotal} | Payment: ${target.paymentMode} | Paid reversed: Rs. ${paidToday} | Stock reversed: ${stockNotes.join(', ') || 'none'}`
        });
      },
      'DELETE'
    );
  };

  const executeSaveParty = (party: Party) => {
    const existingParty = parties.find((p) => p.id === party.id);
    const oldName = existingParty?.name?.trim();
    const newName = party.name.trim();

    setParties((prev) => {
      const idx = prev.findIndex((p) => p.id === party.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = {
          ...party,
          name: newName,
          currentBalance: party.currentBalance !== undefined ? party.currentBalance : party.openingBalance
        };
        return next;
      }
      return [
        ...prev,
        {
          ...party,
          name: newName,
          currentBalance: party.currentBalance !== undefined ? party.currentBalance : party.openingBalance
        }
      ];
    });

    // If customer/supplier was renamed, propagate new name to linked invoices, purchases, and transactions
    if (oldName && newName && oldName !== newName) {
      setInvoices((prev) =>
        prev.map((inv) =>
          inv.partyId === party.id || inv.customerName.trim().toLowerCase() === oldName.toLowerCase()
            ? { ...inv, customerName: newName, customerAddress: party.address || inv.customerAddress, customerPhone: party.phone || inv.customerPhone }
            : inv
        )
      );
      setPurchases((prev) =>
        prev.map((pur) =>
          pur.supplierName.trim().toLowerCase() === oldName.toLowerCase()
            ? { ...pur, supplierName: newName }
            : pur
        )
      );
      setPartyTransactions((prev) =>
        prev.map((tx) =>
          tx.partyId === party.id || tx.partyName.trim().toLowerCase() === oldName.toLowerCase()
            ? { ...tx, partyName: newName, partyAddress: party.address || tx.partyAddress, partyPhone: party.phone || tx.partyPhone }
            : tx
        )
      );
    }
  };

  const saveParty = (party: Party) => {
    const existingParty = parties.find((p) => p.id === party.id);
    if (existingParty) {
      requireOwnerKey(
        `ग्राहक / आपूर्तिकर्ता विवरण सच्याउने: ${party.name}`,
        () => executeSaveParty(party),
        'EDIT'
      );
    } else {
      executeSaveParty(party);
    }
  };

  const deleteParty = (partyId: string) => {
    const target = parties.find((p) => p.id === partyId);
    requireOwnerKey(
      `ग्राहक / आपूर्तिकर्ता खाता मेटाउने: ${target?.name || partyId}`,
      () => {
        setParties((prev) => prev.filter((p) => p.id !== partyId));
      },
      'DELETE'
    );
  };

  const updatePartyBalance = (partyId: string, additionalAmount: number) => {
    const target = parties.find((p) => p.id === partyId);
    requireOwnerKey(
      `पार्टीको बाँकी रकम सच्याउने: ${target?.name || partyId} (रु. ${additionalAmount})`,
      () => {
        setParties((prev) =>
          prev.map((p) =>
            p.id === partyId
              ? {
                  ...p,
                  openingBalance: p.openingBalance + additionalAmount,
                  currentBalance: (p.currentBalance ?? p.openingBalance) + additionalAmount
                }
              : p
          )
        );
      },
      'EDIT'
    );
  };

  // पार्टी/सप्लायरलाई रकम भुक्तानी (नगद वा बैंक): बैंकबाट पठाउँदा बैंक मौज्दात स्वतः घट्ने
  const recordPartyPayment = ({
    partyId,
    amount,
    dateBs: customDateBs,
    paymentMode,
    bankAccountId,
    referenceNo,
    notes
  }: {
    partyId: string;
    amount: number;
    dateBs?: string;
    paymentMode: 'CASH' | 'BANK';
    bankAccountId?: string;
    referenceNo?: string;
    notes?: string;
  }) => {
    const party = parties.find((p) => p.id === partyId);
    if (!party || amount <= 0) return;

    const { dateBs, dateAd } = resolveDatePair({ bs: customDateBs });
    const bank = bankAccounts.find((b) => b.id === bankAccountId);

    const txn: PartyTransaction = {
      id: `ptx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      partyId,
      partyName: party.name,
      partyAddress: party.address,
      partyPhone: party.phone,
      dateBs,
      dateAd,
      type: 'PAYMENT_TO_SUPPLIER',
      amount,
      paymentMode,
      bankAccountId,
      bankName: bank?.bankName,
      bankAccountNo: bank?.accountNumber,
      referenceNo,
      notes: notes || `आपूर्तिकर्ता भुक्तानी (${paymentMode === 'BANK' ? `${bank?.bankName || 'बैंक'}` : 'नगद'})`
    };

    setPartyTransactions((prev) => [txn, ...prev]);

    // Party balance / payable decreases
    setParties((prev) =>
      prev.map((p) =>
        p.id === partyId
          ? {
              ...p,
              currentBalance: Math.max(0, (p.currentBalance ?? p.openingBalance) - amount)
            }
          : p
      )
    );

    // If BANK: selected bank account balance automatically decreases (बैंक मौज्दात घट्ने)
    if (paymentMode === 'BANK' && bankAccountId) {
      setBankAccounts((prev) =>
        prev.map((b) =>
          b.id === bankAccountId
            ? { ...b, currentBalance: b.currentBalance - amount }
            : b
        )
      );
    } else if (paymentMode === 'CASH') {
      // If CASH: counter cash decreases
      setDailyCash((prev) => ({
        ...prev,
        closingCashInHand: Math.max(0, prev.closingCashInHand - amount)
      }));
    }
  };

  // ग्राहकबाट बाँकी रकम असुली वा अन्य आम्दानी / ऋण प्राप्त (नगद वा बैंक): बैंकमा जम्मा गर्दा बैंक मौज्दात बढ्ने
  const recordCustomerCollection = ({
    partyId,
    partyName,
    partyPhone,
    partyAddress,
    incomeType = 'CUSTOMER_COLLECTION',
    incomeCategory,
    dateBs: customDateBs,
    amount,
    paymentMode,
    bankAccountId,
    referenceNo,
    notes
  }: {
    partyId?: string;
    partyName?: string;
    partyPhone?: string;
    partyAddress?: string;
    incomeType?: 'CUSTOMER_COLLECTION' | 'OTHER_INCOME' | 'LOAN_RECEIVED';
    incomeCategory?: string;
    dateBs?: string;
    amount: number;
    paymentMode: 'CASH' | 'BANK';
    bankAccountId?: string;
    referenceNo?: string;
    notes?: string;
  }) => {
    if (amount <= 0) return;
    // पार्टी: id बाट, नभए नाम (र ठेगाना) बाट खोज्ने — नत्र ledger मा असुली पार्टीसँग जोडिँदैन थियो
    let party = partyId ? parties.find((p) => p.id === partyId) : undefined;
    if (!party && incomeType === 'CUSTOMER_COLLECTION' && partyName?.trim()) {
      const nameKey = partyName.trim().toLowerCase();
      const sameName = parties.filter((p) => isCustomerParty(p) && p.name.trim().toLowerCase() === nameKey);
      const addrKey = (partyAddress || '').trim().toLowerCase();
      party =
        sameName.length === 1
          ? sameName[0]
          : sameName.find((p) => addrKey && (p.address || '').trim().toLowerCase() === addrKey);
    }
    if (incomeType === 'CUSTOMER_COLLECTION' && !party && !partyName?.trim()) return;

    const { dateBs, dateAd } = resolveDatePair({ bs: customDateBs });
    const bank = bankAccounts.find((b) => b.id === bankAccountId);

    const resolvedName =
      party?.name ||
      partyName?.trim() ||
      (incomeType === 'LOAN_RECEIVED'
        ? incomeCategory || 'ऋण / सापटी प्राप्त'
        : incomeType === 'OTHER_INCOME'
        ? incomeCategory || 'अन्य आम्दानी'
        : 'ग्राहक असुली');

    const defaultNotes =
      incomeType === 'LOAN_RECEIVED'
        ? `${incomeCategory || 'ऋण / सापटी प्राप्त'} (${paymentMode === 'BANK' ? `${bank?.bankName || 'बैंक'}` : 'नगद'})`
        : incomeType === 'OTHER_INCOME'
        ? `${incomeCategory || 'अन्य आम्दानी'} (${paymentMode === 'BANK' ? `${bank?.bankName || 'बैंक'}` : 'नगद'})`
        : `ग्राहक बाँकी असुली (${paymentMode === 'BANK' ? `${bank?.bankName || 'बैंक'}` : 'नगद'})`;

    const txn: PartyTransaction = {
      id: `ptx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      partyId: party?.id || partyId || `${incomeType.toLowerCase()}-${Date.now()}`,
      partyName: resolvedName,
      partyAddress: party?.address || partyAddress,
      partyPhone: party?.phone || partyPhone,
      dateBs,
      dateAd,
      type: 'COLLECTION_FROM_CUSTOMER',
      incomeType,
      incomeCategory:
        incomeCategory ||
        (incomeType === 'LOAN_RECEIVED'
          ? 'ऋण तथा सापटी प्राप्त (Loan Received)'
          : incomeType === 'OTHER_INCOME'
          ? 'अन्य आम्दानी (Other Income)'
          : 'ग्राहक बक्यौता असुली (Customer Collection)'),
      amount,
      paymentMode,
      bankAccountId,
      bankName: bank?.bankName,
      bankAccountNo: bank?.accountNumber,
      referenceNo,
      notes: notes?.trim() || defaultNotes
    };

    setPartyTransactions((prev) => [txn, ...prev]);

    // Customer Due decreases only if it is a customer collection against an existing party
    if (party && incomeType === 'CUSTOMER_COLLECTION') {
      setParties((prev) =>
        prev.map((p) =>
          p.id === party.id
            ? {
                ...p,
                paidAmount: (p.paidAmount || 0) + amount,
                // बढी तिरे पेस्की (ऋणात्मक) रहन्छ — ledger को चलन्ती मौज्दातसँग सधैं मिल्छ
                currentBalance: (p.currentBalance ?? p.openingBalance) - amount
              }
            : p
        )
      );
    }

    // If BANK: selected bank account balance automatically increases (बैंक मौज्दात बढ्ने)
    if (paymentMode === 'BANK' && bankAccountId) {
      setBankAccounts((prev) =>
        prev.map((b) =>
          b.id === bankAccountId
            ? { ...b, currentBalance: b.currentBalance + amount }
            : b
        )
      );
    } else if (paymentMode === 'CASH') {
      // If CASH: daily cash in hand increases
      setDailyCash((prev) => ({
        ...prev,
        totalCashSales: prev.totalCashSales + amount,
        closingCashInHand: prev.closingCashInHand + amount
      }));
    }
  };

  // भौचर (असुली / भुक्तानी) मेटाउने: पार्टी बाँकी, बैंक मौज्दात र नगद सबै उल्टो मिलाउने
  const deletePartyTransaction = (id: string) => {
    const txn = partyTransactions.find((t) => t.id === id);
    if (!txn) return;
    if (txn.incomeCategory && txn.incomeCategory.includes('Bank Auto-Reconciliation')) {
      alert('यो बैंक स्वतः मिलान (Auto-Reconciliation) को रेकर्ड हो। यसले बिलहरू पनि अपडेट गरेको हुनाले यहाँबाट मेटाउन मिल्दैन।');
      return;
    }
    requireOwnerKey(
      `भौचर मेटाउने: ${txn.partyName} (रु. ${txn.amount})`,
      () => {
        const amount = txn.amount;
        const isCollection = txn.type === 'COLLECTION_FROM_CUSTOMER';

        // पार्टी बाँकी उल्टो
        const isCustomerCollection = isCollection && (txn.incomeType === undefined || txn.incomeType === 'CUSTOMER_COLLECTION');
        if (!isCollection || isCustomerCollection) {
          setParties((prev) =>
            prev.map((p) => {
              if (p.id !== txn.partyId) return p;
              const bal = p.currentBalance ?? p.openingBalance;
              return isCollection
                ? { ...p, paidAmount: Math.max(0, (p.paidAmount || 0) - amount), currentBalance: bal + amount }
                : { ...p, currentBalance: bal + amount };
            })
          );
        }

        // बैंक / नगद उल्टो
        if (txn.paymentMode === 'BANK' && txn.bankAccountId) {
          setBankAccounts((prev) =>
            prev.map((b) =>
              b.id === txn.bankAccountId
                ? { ...b, currentBalance: b.currentBalance + (isCollection ? -amount : amount) }
                : b
            )
          );
        } else if (txn.paymentMode === 'CASH') {
          setDailyCash((prev) =>
            isCollection
              ? {
                  ...prev,
                  totalCashSales: Math.max(0, prev.totalCashSales - amount),
                  closingCashInHand: Math.max(0, prev.closingCashInHand - amount)
                }
              : { ...prev, closingCashInHand: prev.closingCashInHand + amount }
          );
        }

        setPartyTransactions((prev) => prev.filter((t) => t.id !== id));
      },
      'DELETE'
    );
  };

  const getPartyOutstandingDue = (partyId: string): number => {
    const p = parties.find((party) => party.id === partyId);
    if (!p) return 0;
    return p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
  };

  // ग्राहकले बैंकबाट रकम तिर्दा स्वतः सफ्टवेयरको बैंक खातामा मिलान गर्ने (Auto Bank Reconciliation)
  const settleCustomerBankPayment = ({
    partyId,
    partyName,
    partyPhone,
    amount,
    bankAccountId,
    referenceNo,
    invoiceIds,
    dateBs: customDateBs,
    notes
  }: {
    partyId?: string;
    partyName: string;
    partyPhone?: string;
    amount: number;
    bankAccountId: string;
    referenceNo: string;
    invoiceIds?: string[];
    dateBs?: string;
    notes?: string;
  }) => {
    if (amount <= 0) {
      return {
        success: false,
        message: 'भुक्तानी रकम ० भन्दा बढी हुनुपर्दछ।',
        reconciledInvoicesCount: 0,
        allocatedAmount: 0,
        newBankBalance: 0,
        newCustomerBalance: 0,
        settledInvoiceNumbers: []
      };
    }

    const { dateBs, dateAd } = resolveDatePair({ bs: customDateBs });
    let bank = bankAccounts.find((b) => b.id === bankAccountId);
    if (!bank && bankAccounts.length > 0) {
      bank = bankAccounts[0];
    }
    const resolvedBankId = bank?.id || bankAccountId;
    const resolvedBankName = bank?.bankName || 'बैंक खाता';
    const resolvedBankAccNo = bank?.accountNumber || '';

    // 1. Auto-credit the software's bank account (बैंक खातामा रकम स्वतः जम्मा हुने)
    let updatedBankBalance = 0;
    setBankAccounts((prev) => {
      let found = false;
      const next = prev.map((b) => {
        if (b.id === resolvedBankId) {
          found = true;
          const newBal = b.currentBalance + amount;
          updatedBankBalance = newBal;
          return { ...b, currentBalance: newBal };
        }
        return b;
      });
      if (!found && next.length > 0) {
        next[0] = { ...next[0], currentBalance: next[0].currentBalance + amount };
        updatedBankBalance = next[0].currentBalance;
      }
      return next;
    });

    // 2. Identify and reconcile matching customer invoices
    let remainingToAllocate = amount;
    const settledNumbers: string[] = [];
    let reconciledCount = 0;

    setInvoices((prevInvoices) => {
      let candidateIds = invoiceIds && invoiceIds.length > 0 ? invoiceIds : [];
      if (candidateIds.length === 0) {
        const matchingInvs = prevInvoices.filter((inv) => {
          if (inv.status === 'CANCELLED') return false;
          const isPartyMatch =
            (partyId && inv.partyId === partyId) ||
            (partyName && inv.customerName.toLowerCase() === partyName.toLowerCase()) ||
            (partyPhone && inv.customerPhone === partyPhone);
          const hasDue = (inv.remainingDue !== undefined ? inv.remainingDue : inv.grandTotal - (inv.amountPaid || 0)) > 0;
          return isPartyMatch && hasDue;
        });
        candidateIds = matchingInvs.map((i) => i.id);
      }

      const nextInvoices = prevInvoices.map((inv) => {
        if (candidateIds.includes(inv.id) && remainingToAllocate > 0) {
          const currentPaid = inv.amountPaid || 0;
          const currentDue =
            inv.remainingDue !== undefined
              ? inv.remainingDue
              : Math.max(0, inv.grandTotal - currentPaid);

          if (currentDue > 0) {
            const allocate = Math.min(currentDue, remainingToAllocate);
            remainingToAllocate -= allocate;
            reconciledCount++;
            settledNumbers.push(inv.invoiceNo);

            const newPaid = currentPaid + allocate;
            const newDue = Math.max(0, currentDue - allocate);

            return {
              ...inv,
              amountPaid: newPaid,
              remainingDue: newDue,
              bankName: resolvedBankName,
              bankAccountNo: resolvedBankAccNo,
              transactionRef: referenceNo || inv.transactionRef,
              paymentMode: (newDue === 0 ? 'BANK_FONEPAY' : inv.paymentMode) as PaymentMode
            };
          }
        }
        return inv;
      });

      return nextInvoices;
    });

    // 3. Update customer party ledger balance (ग्राहकको बाँकी बक्यौता स्वतः घट्ने)
    let updatedCustomerBalance = 0;
    const party = parties.find(
      (p) =>
        (partyId && p.id === partyId) ||
        (partyName && p.name.toLowerCase() === partyName.toLowerCase()) ||
        (partyPhone && p.phone === partyPhone)
    );

    if (party) {
      setParties((prev) =>
        prev.map((p) => {
          if (p.id === party.id) {
            const currentBal = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
            const newBal = Math.max(0, currentBal - amount);
            updatedCustomerBalance = newBal;
            return {
              ...p,
              paidAmount: (p.paidAmount || 0) + amount,
              currentBalance: newBal
            };
          }
          return p;
        })
      );
    }

    // 4. Record PartyTransaction for audit & accounting
    const txn: PartyTransaction = {
      id: `ptx-${Date.now()}`,
      partyId: party?.id || partyId || `bank-rec-${Date.now()}`,
      partyName: party?.name || partyName,
      partyAddress: party?.address,
      partyPhone: party?.phone || partyPhone,
      dateBs,
      dateAd,
      type: 'COLLECTION_FROM_CUSTOMER',
      incomeType: 'CUSTOMER_COLLECTION',
      incomeCategory: 'बैंक भुक्तानी स्वतः मिलान (Bank Auto-Reconciliation)',
      amount,
      paymentMode: 'BANK',
      bankAccountId: resolvedBankId,
      bankName: resolvedBankName,
      bankAccountNo: resolvedBankAccNo,
      referenceNo,
      notes: notes?.trim() || `बैंक मार्फत प्राप्त रकम स्वतः मिलान (Ref: ${referenceNo})`
    };
    setPartyTransactions((prev) => [txn, ...prev]);

    // 5. Log audit action
    logAuditAction({
      actionType: 'PAYMENT_COLLECTION',
      module: 'BILLING',
      severity: 'INFO',
      targetId: referenceNo,
      summaryNe: `ग्राहक ${party?.name || partyName} को बैंक भुक्तानी रु. ${amount} स्वतः बैंक खाता (${resolvedBankName}) मा मिलान गरियो।`,
      summaryEn: `Customer bank payment Rs. ${amount} auto-reconciled into bank account (${resolvedBankName}).`,
      details: `Ref: ${referenceNo}, Settled Bills: ${settledNumbers.join(', ') || 'None'}`
    });

    return {
      success: true,
      message: `✓ ग्राहक ${party?.name || partyName} बाट प्राप्त रु. ${amount} बैंक खाता (${resolvedBankName}) मा स्वतः मिलान गरियो!`,
      reconciledInvoicesCount: reconciledCount,
      allocatedAmount: amount - remainingToAllocate,
      newBankBalance: updatedBankBalance || (bank ? bank.currentBalance + amount : amount),
      newCustomerBalance: updatedCustomerBalance,
      settledInvoiceNumbers: settledNumbers
    };
  };

  const executeSaveBankAccount = (account: BankAccount) => {
    setBankAccounts((prev) => {
      const idx = prev.findIndex((b) => b.id === account.id);
      let next: BankAccount[];
      if (idx !== -1) {
        next = [...prev];
        next[idx] = account;
      } else {
        next = [...prev, account];
      }
      saveStoredData(getCompanyScopedKey(STORAGE_KEYS.BANK_ACCOUNTS, activeCompanyId), next);
      return next;
    });
    setCompany((prev) => {
      const updated = {
        ...prev,
        bankAccounts: prev.bankAccounts.some((b) => b.id === account.id)
          ? prev.bankAccounts.map((b) => (b.id === account.id ? account : b))
          : [...prev.bankAccounts, account]
      };
      saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), updated);
      return updated;
    });
  };

  const saveBankAccount = (account: BankAccount) => {
    const existingBank = bankAccounts.find((b) => b.id === account.id);
    if (existingBank) {
      requireOwnerKey(
        `बैंक खाता / QR विवरण सच्याउने: ${account.bankName} (${account.accountNumber})`,
        () => executeSaveBankAccount(account),
        'EDIT'
      );
    } else {
      executeSaveBankAccount(account);
    }
  };

  const deleteBankAccount = (id: string) => {
    const target = bankAccounts.find((b) => b.id === id);
    requireOwnerKey(
      `बैंक खाता मेटाउने: ${target?.bankName || ''} (${target?.accountNumber || id})`,
      () => {
        setBankAccounts((prev) => {
          const next = prev.filter((b) => b.id !== id);
          saveStoredData(getCompanyScopedKey(STORAGE_KEYS.BANK_ACCOUNTS, activeCompanyId), next);
          return next;
        });
        setCompany((prev) => {
          const updated = {
            ...prev,
            bankAccounts: prev.bankAccounts.filter((b) => b.id !== id)
          };
          saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), updated);
          return updated;
        });
      },
      'DELETE'
    );
  };

  const recordManualBankEntry = (entry: {
    bankAccountId: string;
    dateBs: string;
    type: 'DEPOSIT' | 'WITHDRAWAL' | 'INTEREST' | 'BANK_CHARGE';
    amount: number;
    referenceNo?: string;
    particulars: string;
  }) => {
    const bank = bankAccounts.find((b) => b.id === entry.bankAccountId) || bankAccounts[0];
    if (!bank || entry.amount <= 0) return;

    const isCredit = entry.type === 'DEPOSIT' || entry.type === 'INTEREST';
    const delta = isCredit ? entry.amount : -entry.amount;

    setBankAccounts((prev) =>
      prev.map((b) =>
        b.id === bank.id ? { ...b, currentBalance: b.currentBalance + delta } : b
      )
    );

    const newEntry = {
      id: `bnk-man-${Date.now()}`,
      bankAccountId: bank.id,
      bankName: bank.bankName,
      dateBs: entry.dateBs || getTodayBsString(),
      dateAd: getTodayAdString(),
      type: entry.type,
      amount: entry.amount,
      referenceNo: entry.referenceNo || '',
      particulars: entry.particulars
    };

    setCompany((prev) => ({
      ...prev,
      bankAccounts: prev.bankAccounts.map((b) =>
        b.id === bank.id ? { ...b, currentBalance: b.currentBalance + delta } : b
      ),
      manualBankEntries: [newEntry, ...(prev.manualBankEntries || [])]
    }));
  };

  // दैनिक खर्च दर्ता र व्यवस्थापन (Daily Expenses Management)
  const recordExpense = (expenseData: Omit<Expense, 'id'>) => {
    if (!expenseData.amount || expenseData.amount <= 0) return;

    const newExpense: Expense = {
      ...expenseData,
      id: `exp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      dateBs: expenseData.dateBs || getTodayBsString()
    };

    setExpenses((prev) => [newExpense, ...prev]);

    if (expenseData.paymentMode === 'BANK' && expenseData.bankAccountId) {
      setBankAccounts((prev) =>
        prev.map((b) =>
          b.id === expenseData.bankAccountId
            ? { ...b, currentBalance: b.currentBalance - expenseData.amount }
            : b
        )
      );
    } else if (expenseData.paymentMode === 'CASH') {
      setDailyCash((prev) => ({
        ...prev,
        closingCashInHand: Math.max(0, prev.closingCashInHand - expenseData.amount)
      }));
    }

    logAuditAction({
      actionType: 'EXPENSE_RECORDED',
      module: 'EXPENSES',
      severity: 'INFO',
      targetId: newExpense.id,
      summaryNe: `दैनिक खर्च दर्ता: ${newExpense.category} - रु. ${newExpense.amount} (${newExpense.paymentMode === 'BANK' ? 'बैंक' : 'नगद'})`,
      summaryEn: `Daily Expense Recorded: ${newExpense.category} - Rs. ${newExpense.amount} (${newExpense.paymentMode})`,
      details: newExpense.description || newExpense.notes || ''
    });
  };

  const deleteExpense = (id: string) => {
    const target = expenses.find((e) => e.id === id);
    if (!target) return;

    requireOwnerKey(
      `दैनिक खर्च विवरण मेटाउने (${target.category} - रु. ${target.amount})`,
      () => {
        setExpenses((prev) => prev.filter((e) => e.id !== id));
        if (target.paymentMode === 'BANK' && target.bankAccountId) {
          setBankAccounts((prev) =>
            prev.map((b) =>
              b.id === target.bankAccountId
                ? { ...b, currentBalance: b.currentBalance + target.amount }
                : b
            )
          );
        } else if (target.paymentMode === 'CASH') {
          setDailyCash((prev) => ({
            ...prev,
            closingCashInHand: prev.closingCashInHand + target.amount
          }));
        }
      },
      'DELETE'
    );
  };

  // हाजिरी दर्ता (एक दिनमा १ पटक मात्र Log In र १ पटक मात्र Log Out, कामको प्रकार र साइट सहित)
  const recordAttendance = ({
    employeeId,
    type,
    latitude,
    longitude,
    locationLabel,
    workCategory,
    workDescription,
    siteOrClientName,
    customDateBs,
    photoUrl,
    verificationMethod,
    deviceType
  }: {
    employeeId: string;
    type: 'IN' | 'OUT';
    latitude?: number;
    longitude?: number;
    locationLabel?: string;
    workCategory?: StaffWorkCategory;
    workDescription?: string;
    siteOrClientName?: string;
    customDateBs?: string;
    photoUrl?: string;
    verificationMethod?: 'FINGERPRINT' | 'FACE_PHOTO' | 'MANUAL_SUPERVISOR' | 'GPS_AUTO';
    deviceType?: 'MOBILE' | 'DESKTOP' | 'SUPERVISOR';
  }): { success: boolean; message: string } => {
    const emp = employees.find((e) => e.id === employeeId);
    if (!emp) {
      return { success: false, message: 'कर्मचारी फेला परेन।' };
    }

    const targetDateBs = (customDateBs && customDateBs.trim()) || getTodayBsString();
    const todayAd = bsStringToAdString(targetDateBs) || getTodayAdString();
    const nowTime = company.autoSetShiftTime
      ? (type === 'IN' ? company.shiftStartTime || '10:00 AM' : company.shiftEndTime || '05:00 PM')
      : new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    // Check existing record for target date
    const existing = attendance.find(
      (a) => a.employeeId === employeeId && a.dateBs === targetDateBs
    );

    if (type === 'IN') {
      if (existing && existing.checkInTime && existing.checkInTime !== '-') {
        // Allow updating workCategory / workDescription / siteOrClientName on existing record
        if (workCategory || workDescription || siteOrClientName) {
          setAttendance((prev) =>
            prev.map((a) =>
              a.employeeId === employeeId && a.dateBs === targetDateBs
                ? {
                    ...a,
                    workCategory: workCategory || a.workCategory,
                    workDescription: workDescription || a.workDescription,
                    siteOrClientName: siteOrClientName !== undefined ? siteOrClientName : a.siteOrClientName,
                    locationLabel: locationLabel || a.locationLabel
                  }
                : a
            )
          );
          return {
            success: true,
            message: `${emp.name} को कामको विवरण (${workDescription || locationLabel || ''}) अद्यावधिक गरियो !`
          };
        }
        return {
          success: false,
          message: `${emp.name} को ${targetDateBs} को Log In (${existing.checkInTime}) पहिले नै दर्ता भइसकेको छ !`
        };
      }

      const newRecord: AttendanceRecord = {
        id: `att-${Date.now()}-${employeeId}`,
        employeeId,
        employeeName: emp.name,
        dateBs: targetDateBs,
        dateAd: todayAd,
        checkInTime: nowTime,
        latitude,
        longitude,
        locationLabel: locationLabel || company.workplaceLocationLabel || 'कार्यस्थल (Store HQ)',
        workCategory: workCategory || 'WORKSHOP_REGULAR',
        workDescription: workDescription || 'नियमित काम (Workshop)',
        siteOrClientName: siteOrClientName || '',
        photoUrl,
        verificationMethod: verificationMethod || 'GPS_AUTO',
        deviceType: deviceType || 'MOBILE',
        status: 'PRESENT',
        isOffline: !isOnline,
        syncedAt: isOnline ? new Date().toLocaleTimeString() : undefined,
        isApproved: verificationMethod === 'FACE_PHOTO' ? false : true
      };

      setAttendance((prev) => {
        const filtered = prev.filter((a) => !(a.employeeId === employeeId && a.dateBs === targetDateBs));
        return [newRecord, ...filtered];
      });
      return {
        success: true,
        message: `${emp.name} को Log In समय ${nowTime} (${newRecord.workDescription}) मा सफलतापूर्वक दर्ता भयो !`
      };
    } else {
      // type === 'OUT'
      if (!existing || !existing.checkInTime || existing.checkInTime === '-') {
        return {
          success: false,
          message: `${emp.name} ले पहिले Log In गर्नुभएको छैन ! पहिले Log In गरेपछि मात्र Log Out गर्न मिल्छ।`
        };
      }

      if (existing.checkOutTime) {
        return {
          success: false,
          message: `${emp.name} को Log Out (${existing.checkOutTime}) पहिले नै दर्ता भइसकेको छ !`
        };
      }

      setAttendance((prev) =>
        prev.map((a) =>
          a.employeeId === employeeId && a.dateBs === targetDateBs
            ? {
                ...a,
                checkOutTime: nowTime,
                workCategory: workCategory || a.workCategory,
                workDescription: workDescription || a.workDescription,
                siteOrClientName: siteOrClientName !== undefined ? siteOrClientName : a.siteOrClientName,
                isOffline: !isOnline,
                syncedAt: isOnline ? new Date().toLocaleTimeString() : a.syncedAt
              }
            : a
        )
      );

      return {
        success: true,
        message: `${emp.name} को Log Out समय ${nowTime} मा सफलतापूर्वक दर्ता भयो !`
      };
    }
  };

  // कर्मचारीको बायोमेट्रिक फिंगरप्रिन्ट पहिले दर्ता/सेट गर्ने (Enroll Fingerprint)
  const enrollEmployeeFingerprint = (
    employeeId: string,
    fingerName: string
  ): { success: boolean; message: string } => {
    const emp = employees.find((e) => e.id === employeeId);
    if (!emp) return { success: false, message: 'कर्मचारी फेला परेन।' };

    const todayBs = getTodayBsString();
    const token = `bio_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    setEmployees((prev) =>
      prev.map((e) =>
        e.id === employeeId
          ? {
              ...e,
              fingerprintEnrolled: true,
              fingerprintHash: token,
              enrolledFingerName: fingerName,
              fingerprintEnrolledDateBs: todayBs
            }
          : e
      )
    );

    return {
      success: true,
      message: `${emp.name} को फिंगरप्रिन्ट (${fingerName}) सफलतापूर्वक दर्ता भयो ! अब फिंगरप्रिन्ट स्क्यान गरी हाजिर गर्न सकिन्छ।`
    };
  };

  // कर्मचारीको आधिकारिक फोटो तथा बायोमेट्रिक पहिले दर्ता गर्ने (Pre-enroll Biometric & Photo)
  const enrollEmployeeBiometrics = (
    employeeId: string,
    params: {
      photoUrl?: string;
      fingerName?: string;
    }
  ): { success: boolean; message: string } => {
    const emp = employees.find((e) => e.id === employeeId);
    if (!emp) return { success: false, message: 'कर्मचारी फेला परेन।' };

    const todayBs = getTodayBsString();
    const token = `bio_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    setEmployees((prev) =>
      prev.map((e) =>
        e.id === employeeId
          ? {
              ...e,
              registeredPhotoUrl: params.photoUrl !== undefined ? params.photoUrl : e.registeredPhotoUrl,
              fingerprintEnrolled: params.fingerName ? true : e.fingerprintEnrolled,
              fingerprintHash: params.fingerName ? token : e.fingerprintHash,
              enrolledFingerName: params.fingerName || e.enrolledFingerName,
              fingerprintEnrolledDateBs: params.fingerName ? todayBs : e.fingerprintEnrolledDateBs
            }
          : e
      )
    );

    return {
      success: true,
      message: `${emp.name} को आधिकारिक फोटो तथा बायोमेट्रिक विवरण सफलतापूर्वक दर्ता भयो !`
    };
  };

  // अनुपस्थित (Absent), आधा दिन (Half Day), बिदा (Leave), वा काम अनुसार उपस्थित (Present) स्थिति तोक्ने
  const setEmployeeAttendanceStatus = (
    employeeId: string,
    status: 'PRESENT' | 'ABSENT' | 'HALF_DAY' | 'LEAVE',
    notes?: string,
    workOptions?: {
      workCategory?: StaffWorkCategory;
      workDescription?: string;
      siteOrClientName?: string;
      customDateBs?: string;
    }
  ): { success: boolean; message: string } => {
    const emp = employees.find((e) => e.id === employeeId);
    if (!emp) return { success: false, message: 'कर्मचारी फेला परेन।' };

    const targetDateBs = (workOptions?.customDateBs && workOptions.customDateBs.trim()) || getTodayBsString();
    const todayAd = bsStringToAdString(targetDateBs) || getTodayAdString();
    const timeStr = company.autoSetShiftTime
      ? company.shiftStartTime || '10:00 AM'
      : new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    setAttendance((prev) => {
      const existingIdx = prev.findIndex((a) => a.employeeId === employeeId && a.dateBs === targetDateBs);
      if (existingIdx !== -1) {
        const updated = [...prev];
        updated[existingIdx] = {
          ...updated[existingIdx],
          status,
          workCategory: workOptions?.workCategory || updated[existingIdx].workCategory,
          workDescription: workOptions?.workDescription || updated[existingIdx].workDescription,
          siteOrClientName:
            workOptions?.siteOrClientName !== undefined
              ? workOptions.siteOrClientName
              : updated[existingIdx].siteOrClientName,
          locationLabel:
            notes ||
            workOptions?.workDescription ||
            (status === 'ABSENT'
              ? 'अनुपस्थित (Absent)'
              : status === 'LEAVE'
              ? 'बिदा (Leave)'
              : status === 'HALF_DAY'
              ? 'आधा दिन (Half Day)'
              : updated[existingIdx].locationLabel),
          checkInTime:
            status === 'ABSENT' || status === 'LEAVE'
              ? '-'
              : updated[existingIdx].checkInTime && updated[existingIdx].checkInTime !== '-'
              ? updated[existingIdx].checkInTime
              : timeStr,
          isOffline: !isOnline
        };
        return updated;
      } else {
        const newRecord: AttendanceRecord = {
          id: `att-${Date.now()}-${employeeId}`,
          employeeId,
          employeeName: emp.name,
          dateBs: targetDateBs,
          dateAd: todayAd,
          checkInTime: status === 'ABSENT' || status === 'LEAVE' ? '-' : timeStr,
          checkOutTime: status === 'PRESENT' && company.autoSetShiftTime ? company.shiftEndTime || '05:00 PM' : undefined,
          status,
          workCategory: workOptions?.workCategory || 'WORKSHOP_REGULAR',
          workDescription: workOptions?.workDescription || notes || '',
          siteOrClientName: workOptions?.siteOrClientName || '',
          locationLabel:
            notes ||
            workOptions?.workDescription ||
            (status === 'ABSENT'
              ? 'अनुपस्थित (Absent)'
              : status === 'LEAVE'
              ? 'स्वीकृत बिदा (Leave)'
              : 'उपस्थित (Present)'),
          verificationMethod: 'MANUAL_SUPERVISOR',
          deviceType: 'DESKTOP',
          isOffline: !isOnline
        };
        return [newRecord, ...prev];
      }
    });

    const statusLabel =
      status === 'ABSENT'
        ? 'अनुपस्थित (Absent)'
        : status === 'LEAVE'
        ? 'स्वीकृत बिदा (Leave)'
        : status === 'HALF_DAY'
        ? 'आधा दिन (Half Day)'
        : 'उपस्थित (Present)';

    return {
      success: true,
      message: `${emp.name} को (${targetDateBs}) हाजिरी '${statusLabel}' ${workOptions?.workDescription ? `- ${workOptions.workDescription}` : ''} सुरक्षित गरियो !`
    };
  };

  const executeSaveEmployee = (emp: Employee) => {
    const existingEmp = employees.find((e) => e.id === emp.id);
    const oldName = existingEmp?.name?.trim();
    const newName = emp.name.trim();

    setEmployees((prev) => {
      const idx = prev.findIndex((e) => e.id === emp.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = { ...emp, name: newName };
        return next;
      }
      return [...prev, { ...emp, name: newName }];
    });

    if (oldName && newName && oldName !== newName) {
      setAttendance((prev) =>
        prev.map((a) => (a.employeeId === emp.id ? { ...a, employeeName: newName } : a))
      );
    }
  };

  const saveEmployee = (emp: Employee) => {
    const existingEmp = employees.find((e) => e.id === emp.id);
    if (existingEmp) {
      requireOwnerKey(
        `कर्मचारी विवरण सच्याउने: ${emp.name} (${emp.role})`,
        () => executeSaveEmployee(emp),
        'EDIT'
      );
    } else {
      executeSaveEmployee(emp);
    }
  };

  const deleteEmployee = (employeeId: string) => {
    const target = employees.find((e) => e.id === employeeId);
    requireOwnerKey(
      `कर्मचारी विवरण मेटाउने: ${target?.name || employeeId}`,
      () => {
        setEmployees((prev) => prev.filter((e) => e.id !== employeeId));
      },
      'DELETE'
    );
  };

  const recordCashAdvance = (employeeId: string, amount: number, notes?: string) => {
    const dateAd = getTodayAdString();
    const todayBs = getTodayBsString();

    const advanceEntry: EmployeeLedgerEntry = {
      id: `eledg-${Date.now()}`,
      employeeId,
      dateBs: todayBs,
      dateAd,
      type: 'CASH_ADVANCE',
      amount,
      notes: notes || 'कर्मचारी नगद पेस्की (Cash Advance Taken)'
    };

    setEmployeeLedger((prev) => [advanceEntry, ...prev]);

    // Counter cash decreases automatically
    setDailyCash((prev) => ({
      ...prev,
      totalAdvancesGiven: prev.totalAdvancesGiven + amount,
      closingCashInHand: Math.max(0, prev.closingCashInHand - amount)
    }));
  };

  // मासिक तलब वा दैनिक हिसाबमा ज्याला भुक्तानी गर्ने (Pay Monthly Salary / Daily Wage)
  const payEmployeeSalary = ({
    employeeId,
    amount,
    paymentMode,
    bankAccountId,
    wageType,
    daysWorked,
    notes
  }: {
    employeeId: string;
    amount: number;
    paymentMode: 'CASH' | 'BANK';
    bankAccountId?: string;
    wageType: 'MONTHLY' | 'DAILY';
    daysWorked?: number;
    notes?: string;
  }) => {
    const emp = employees.find((e) => e.id === employeeId);
    if (!emp || amount <= 0) return;

    const dateBs = getTodayBsString();
    const dateAd = getTodayAdString();
    const bank = bankAccounts.find((b) => b.id === bankAccountId);

    const defaultNotes = wageType === 'DAILY'
      ? `${emp.name} लाई ${daysWorked ? `${daysWorked} दिनको ` : ''}दैनिक ज्याला भुक्तानी (${paymentMode === 'BANK' ? bank?.bankName || 'बैंक' : 'नगद'})`
      : `${emp.name} लाई मासिक तलब भुक्तानी (${paymentMode === 'BANK' ? bank?.bankName || 'बैंक' : 'नगद'})`;

    const paymentEntry: EmployeeLedgerEntry = {
      id: `eledg-sal-${Date.now()}`,
      employeeId,
      dateBs,
      dateAd,
      type: 'SALARY_PAYMENT',
      amount,
      wageType,
      daysWorked,
      paymentMode,
      bankAccountId,
      bankName: bank?.bankName,
      notes: notes || defaultNotes
    };

    setEmployeeLedger((prev) => [paymentEntry, ...prev]);

    // Update Bank or Counter Cash
    if (paymentMode === 'BANK' && bankAccountId) {
      setBankAccounts((prev) =>
        prev.map((b) =>
          b.id === bankAccountId
            ? { ...b, currentBalance: b.currentBalance - amount }
            : b
        )
      );
    } else if (paymentMode === 'CASH') {
      setDailyCash((prev) => ({
        ...prev,
        closingCashInHand: Math.max(0, prev.closingCashInHand - amount)
      }));
    }
  };

  // मासिक तलब वा दैनिक ज्याला अनुसार हिसाब सारांश
  const getEmployeePayrollSummary = (employeeId: string) => {
    const emp = employees.find((e) => e.id === employeeId);
    const wageType: 'MONTHLY' | 'DAILY' = emp?.wageType || 'MONTHLY';
    const monthlySalary = emp ? emp.salaryMonthly : 0;
    const dailyWageRate = emp ? (emp.dailyWageRate || Math.round(monthlySalary / 30)) : 1000;
    const openingDue = emp ? (emp.openingDue || 0) : 0;

    const presentDays = attendance.filter(
      (a) => a.employeeId === employeeId && a.status === 'PRESENT' && a.isApproved
    ).length;

    const halfDays = attendance.filter(
      (a) => a.employeeId === employeeId && a.status === 'HALF_DAY' && a.isApproved
    ).length;

    const absentDays = attendance.filter(
      (a) => a.employeeId === employeeId && a.status === 'ABSENT' && a.isApproved
    ).length;

    const leaveDays = attendance.filter(
      (a) => a.employeeId === employeeId && a.status === 'LEAVE' && a.isApproved
    ).length;

    const effectiveDays = presentDays + (halfDays * 0.5);

    // Gross earnings: if daily, rate * effectiveDays; if monthly, full monthly salary
    const grossSalary = wageType === 'DAILY'
      ? (effectiveDays * dailyWageRate)
      : monthlySalary;

    const empEntries = employeeLedger.filter((l) => l.employeeId === employeeId);
    const purchasesTotal = empEntries
      .filter((e) => e.type === 'PURCHASE_DEDUCTION')
      .reduce((sum, e) => sum + e.amount, 0);

    const cashAdvancesTotal = empEntries
      .filter((e) => e.type === 'CASH_ADVANCE')
      .reduce((sum, e) => sum + e.amount, 0);

    const salaryPaidTotal = empEntries
      .filter((e) => e.type === 'SALARY_PAYMENT')
      .reduce((sum, e) => sum + e.amount, 0);

    const totalDeductions = openingDue + purchasesTotal + cashAdvancesTotal + salaryPaidTotal;
    const netPayable = Math.max(0, grossSalary - totalDeductions);

    return {
      wageType,
      monthlySalary,
      dailyWageRate,
      presentDays,
      absentDays,
      halfDays,
      leaveDays,
      effectiveDays,
      grossSalary,
      openingDue,
      purchasesTotal,
      cashAdvancesTotal,
      salaryPaidTotal,
      totalDeductions,
      netPayable
    };
  };

  const updateOpeningCash = (amount: number) => {
    requireOwnerKey(
      `सुरुवाती नगद मौज्दात (Opening Cash) सच्याउने: रु. ${amount}`,
      () => {
        setDailyCash((prev) => ({
          ...prev,
          openingCash: amount,
          // सुरुवाती नगद फेर्दा खुद नगद (Cash in Hand) पनि सोही अनुसार मिल्ने
          closingCashInHand: Math.max(0, prev.closingCashInHand + (amount - prev.openingCash))
        }));
      },
      'EDIT'
    );
  };

  const [lockDateBs, setLockDateBs] = useState<string | undefined>(company.lockDateBs);

  const setLockDate = (dateBs: string) => {
    setLockDateBs(dateBs);
    updateCompanyProfile({ ...company, lockDateBs: dateBs });
  };
  

  // ===================================================================
  // फिल्ड अर्डर (Field Orders) — फिल्ड स्टाफले टिपेको अर्डर
  // ===================================================================
  const getActorName = (): string =>
    currentAccount?.ownerName || getServerUser()?.name || (currentRole === 'OWNER' ? 'मालिक' : 'कर्मचारी');

  const getNextFieldOrderNo = (): string => {
    const year = (company.fiscalYear || getFiscalYear(getTodayBsString())).replace(/[^0-9/]/g, '').replace('/', '-') || getTodayBsString().slice(0, 4);
    const used = fieldOrders
      .map((o) => o.orderNo.match(/(\d+)$/)?.[1])
      .filter(Boolean)
      .map((n) => parseInt(n as string, 10));
    const next = (used.length ? Math.max(...used) : 0) + 1;
    return `FO-${year}-${String(next).padStart(4, '0')}`;
  };

  const saveFieldOrder = (order: FieldOrder) => {
    const stamped: FieldOrder = { ...order, updatedAt: new Date().toISOString() };
    setFieldOrders((prev) => {
      const idx = prev.findIndex((o) => o.id === order.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = stamped;
        return next;
      }
      return [stamped, ...prev];
    });
  };

  const deleteFieldOrder = (id: string) => {
    const target = fieldOrders.find((o) => o.id === id);
    requireOwnerKey(
      `फिल्ड अर्डर मेटाउने: ${target?.orderNo || id} (${target?.customerName || ''})`,
      () => setFieldOrders((prev) => prev.filter((o) => o.id !== id)),
      'DELETE'
    );
  };

  const updateFieldOrderStatus = (
    id: string,
    status: FieldOrderStatus,
    extra?: Partial<FieldOrder>,
    note?: string
  ) => {
    setFieldOrders((prev) =>
      prev.map((o) => {
        if (o.id !== id) return o;
        const now = new Date();
        return {
          ...o,
          ...extra,
          status,
          updatedAt: now.toISOString(),
          statusHistory: [
            ...(o.statusHistory || []),
            {
              status,
              dateBs: getTodayBsString(),
              time: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
              by: getActorName(),
              note
            }
          ]
        };
      })
    );
  };

  const getNextQuotationNo = (): string => {
    const year = (company.fiscalYear || getFiscalYear(getTodayBsString())).replace(/\//g, '-');
    const used = quotations
      .map((q) => q.quotationNo.match(/(\d+)$/)?.[1])
      .filter(Boolean)
      .map((n) => parseInt(n as string, 10));
    const next = (used.length ? Math.max(...used) : 0) + 1;
    return `QT-${year}-${String(next).padStart(4, '0')}`;
  };

  const saveQuotation = (q: Quotation) => {
    const stamped: Quotation = { ...q, updatedAt: new Date().toISOString() };
    setQuotations((prev) => {
      const idx = prev.findIndex((x) => x.id === q.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = stamped;
        return next;
      }
      return [stamped, ...prev];
    });
  };

  const deleteQuotation = (id: string) => {
    const target = quotations.find((q) => q.id === id);
    requireOwnerKey(
      `कोटेशन मेटाउने: ${target?.quotationNo || id}`,
      () => setQuotations((prev) => prev.filter((q) => q.id !== id)),
      'DELETE'
    );
  };

  // ===================================================================
  // उत्पादन सूत्र (BOM) तथा उत्पादन आदेश (Production Orders)
  // ===================================================================
  const saveBom = (bom: BillOfMaterial) => {
    setBoms((prev) => {
      const idx = prev.findIndex((b) => b.id === bom.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = bom;
        return next;
      }
      return [bom, ...prev];
    });
  };

  const deleteBom = (id: string) => {
    const target = boms.find((b) => b.id === id);
    requireOwnerKey(
      `उत्पादन सूत्र (BOM) मेटाउने: ${target?.productNameNe || id}`,
      () => setBoms((prev) => prev.filter((b) => b.id !== id)),
      'DELETE'
    );
  };

  const getNextProductionOrderNo = (): string => {
    const year = getTodayBsString().slice(0, 4);
    const used = productionOrders
      .map((o) => o.orderNo.match(/(\d+)$/)?.[1])
      .filter(Boolean)
      .map((n) => parseInt(n as string, 10));
    const next = (used.length ? Math.max(...used) : 0) + 1;
    return `PO-${year}-${String(next).padStart(4, '0')}`;
  };

  const saveProductionOrder = (order: ProductionOrder) => {
    setProductionOrders((prev) => {
      const idx = prev.findIndex((o) => o.id === order.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = order;
        return next;
      }
      return [order, ...prev];
    });
    // जोडिएका फिल्ड अर्डरहरूलाई "उत्पादनमा" देखाउने
    if (order.fieldOrderIds?.length && order.status !== 'CANCELLED') {
      setFieldOrders((prev) =>
        prev.map((fo) =>
          order.fieldOrderIds.includes(fo.id)
            ? {
                ...fo,
                productionOrderIds: Array.from(new Set([...(fo.productionOrderIds || []), order.id])),
                status: fo.status === 'SUBMITTED' || fo.status === 'APPROVED' ? 'IN_PRODUCTION' : fo.status
              }
            : fo
        )
      );
    }
  };

  const deleteProductionOrder = (id: string) => {
    const target = productionOrders.find((o) => o.id === id);
    requireOwnerKey(
      `उत्पादन आदेश मेटाउने: ${target?.orderNo || id}`,
      () => setProductionOrders((prev) => prev.filter((o) => o.id !== id)),
      'DELETE'
    );
  };

  /** आदेश जारी: BOM बाट कच्चा पदार्थ निकालेर ब्याच (WIP) बनाउँछ र कच्चा पदार्थ स्टक घटाउँछ */
  const releaseProductionOrder = (orderId: string, force: boolean = false) => {
    const order = productionOrders.find((o) => o.id === orderId);
    if (!order) return { ok: false, message: 'उत्पादन आदेश फेला परेन।' };
    if (order.batchId) return { ok: false, message: 'यो आदेश पहिले नै जारी भइसकेको छ।' };
    const bom = boms.find((b) => b.id === order.bomId);
    if (!bom) return { ok: false, message: 'यो आदेशमा उत्पादन सूत्र (BOM) जोडिएको छैन। पहिले BOM छान्नुहोस्।' };

    const scale = bom.outputQty > 0 ? order.quantity / bom.outputQty : 0;
    const usages = bom.lines.map((l) => {
      const mat = rawMaterials.find((r) => r.id === l.materialId);
      const qty = Math.round(l.qtyPerBatch * scale * (1 + (l.wastagePercent || 0) / 100) * 1000) / 1000;
      const cost = mat?.unitCostPrice || 0;
      return {
        materialId: l.materialId,
        materialName: mat?.nameNe || l.materialName,
        quantityUsed: qty,
        unit: l.unit || mat?.unit || '',
        costPerUnit: cost,
        totalCost: Math.round(qty * cost * 100) / 100
      };
    });

    const shortages = usages.filter((u) => {
      const mat = rawMaterials.find((r) => r.id === u.materialId);
      return !mat || mat.currentStock < u.quantityUsed;
    });
    if (shortages.length > 0 && !force) {
      return {
        ok: false,
        message:
          'कच्चा पदार्थ नपुग: ' +
          shortages
            .map((u) => {
              const mat = rawMaterials.find((r) => r.id === u.materialId);
              return `${u.materialName} (चाहिने ${u.quantityUsed}, मौज्दात ${mat?.currentStock ?? 0})`;
            })
            .join(', ')
      };
    }

    const todayBs = getTodayBsString();
    const todayAd = getTodayAdString();
    const rmCost = usages.reduce((sum, u) => sum + (u.totalCost || 0), 0);
    const laborCost = Math.round((bom.laborCostPerBatch || 0) * scale);
    const electricityCost = Math.round((bom.electricityCostPerBatch || 0) * scale);
    const otherOverheadCost = Math.round((bom.otherCostPerBatch || 0) * scale);
    const totalCost = rmCost + laborCost + electricityCost + otherOverheadCost;
    const machine = machines.find((m) => m.id === order.machineId || m.id === bom.machineId);
    const expectedOut = order.quantity;
    const batchNumber = `BATCH-${todayBs.slice(0, 4)}-${String(productionBatches.length + 1).padStart(3, '0')}`;

    let expiryBs: string | undefined;
    let expiryAd: string | undefined;
    if (bom.shelfLifeDays && bom.shelfLifeDays > 0) {
      const d = new Date();
      d.setDate(d.getDate() + bom.shelfLifeDays);
      expiryAd = d.toISOString().slice(0, 10);
      try {
        expiryBs = formatBsDate(adToBs(d));
      } catch {
        expiryBs = undefined;
      }
    }

    const batch: ProductionBatch = {
      id: `batch-${Date.now()}`,
      batchNumber,
      productNameNe: order.productNameNe,
      productNameEn: order.productNameEn || order.productNameNe,
      stage: 'IN_MACHINE_WIP',
      targetQuantity: expectedOut,
      plannedQuantity: expectedOut,
      finishedItemId: order.productItemId || bom.productItemId,
      productionDateBs: todayBs,
      productionDateAd: todayAd,
      manufactureDateBs: todayBs,
      manufactureDateAd: todayAd,
      expiryDateBs: expiryBs,
      expiryDateAd: expiryAd,
      startedDateBs: todayBs,
      startedDateAd: todayAd,
      inputQuantity: usages.reduce((sum, u) => sum + u.quantityUsed, 0),
      inputUnit: usages[0]?.unit || order.unit,
      outputQuantity: expectedOut,
      outputUnit: order.unit,
      rawMaterialCost: rmCost,
      laborCost,
      electricityCost,
      otherOverheadCost,
      totalProductionCost: totalCost,
      unitManufacturingCost: expectedOut > 0 ? Math.round((totalCost / expectedOut) * 100) / 100 : 0,
      packetSize: bom.packetSize,
      packagingType: bom.packagingType,
      qualityCheckStatus: 'PENDING',
      qcChecks: (bom.qcChecklist || []).map((name) => ({ name, result: 'NA' as const })),
      machineId: machine?.id,
      machineName: machine?.nameNe || order.machineName || bom.machineName,
      supervisorName: order.supervisorName,
      rawMaterialsUsed: usages,
      bomId: bom.id,
      productionOrderId: order.id,
      fieldOrderIds: order.fieldOrderIds,
      notes: `उत्पादन आदेश ${order.orderNo} बाट जारी`,
      status: 'ACTIVE'
    };

    executeSaveProductionBatch(batch);
    setProductionOrders((prev) =>
      prev.map((o) =>
        o.id === orderId ? { ...o, status: 'IN_PROGRESS', batchId: batch.id, batchNumber: batch.batchNumber } : o
      )
    );
    return {
      ok: true,
      message: `ब्याच ${batch.batchNumber} मेसिनमा लोड भयो र कच्चा पदार्थ स्टकबाट घटाइयो।`,
      batch
    };
  };

  /** उत्पादन आदेश पूरा: ब्याचलाई तयारी सामान (Finished Goods) मा सारेर स्टक थप्छ */
  const completeProductionOrder = (orderId: string) => {
    const order = productionOrders.find((o) => o.id === orderId);
    if (!order || !order.batchId) return;
    const batch = productionBatches.find((b) => b.id === order.batchId);
    if (batch && batch.stage === 'IN_MACHINE_WIP') {
      updateBatchStage(batch.id, 'FINISHED_GOODS', {
        finishedGoodsQuantity: order.quantity,
        outputQuantity: order.quantity,
        completionDateBs: getTodayBsString(),
        completionDateAd: getTodayAdString(),
        status: 'COMPLETED'
      });
    }
  };

  // ब्याच तयारी सामानमा सरेपछि: उत्पादन आदेश पूरा, र सबै आदेश पूरा भएका फिल्ड अर्डर "तयार" (READY)
  useEffect(() => {
    const doneStages = ['FINISHED_GOODS', 'PACKAGING', 'DISPATCHED_MARKET'];
    const toComplete = productionOrders.filter((o) => {
      if (o.status !== 'IN_PROGRESS' && o.status !== 'RELEASED') return false;
      const b = productionBatches.find((x) => x.id === o.batchId);
      return !!b && doneStages.includes(b.stage);
    });
    if (toComplete.length === 0) return;
    const doneIds = new Set(toComplete.map((o) => o.id));
    const nextOrders = productionOrders.map((o) =>
      doneIds.has(o.id) ? { ...o, status: 'COMPLETED' as ProductionOrderStatus } : o
    );
    setProductionOrders(nextOrders);
    setFieldOrders((prev) =>
      prev.map((fo) => {
        if (fo.status !== 'IN_PRODUCTION' || !fo.productionOrderIds?.length) return fo;
        const allDone = fo.productionOrderIds.every((pid) => {
          const po = nextOrders.find((x) => x.id === pid);
          return !po || po.status === 'COMPLETED' || po.status === 'CANCELLED';
        });
        if (!allDone) return fo;
        return {
          ...fo,
          status: 'READY' as FieldOrderStatus,
          statusHistory: [
            ...(fo.statusHistory || []),
            { status: 'READY' as FieldOrderStatus, dateBs: getTodayBsString(), time: '', by: 'उत्पादन विभाग', note: 'उत्पादन पूरा भयो' }
          ]
        };
      })
    );
  }, [productionBatches, productionOrders]);

  const saveMachine = (machine: Machine) => {
    setMachines((prev) => {
      const exists = prev.some((m) => m.id === machine.id);
      if (exists) return prev.map((m) => (m.id === machine.id ? machine : m));
      return [...prev, machine];
    });
  };

  const deleteMachine = (id: string) => {
    setMachines((prev) => prev.filter((m) => m.id !== id));
  };

  const addMaintenanceLog = (log: MaintenanceLog) => {
    // Implement maintenance log logic
  };

  const assignMachineWorker = (worker: MachineWorker) => {
    // Implement assignment logic
  };

  const closeFiscalYear = (newFiscalYear: string, reopenCode?: string) => {
    // A reopen code is mandatory: without it a closed year could be re-activated by anyone
    if (!company.fiscalReopenCode && (!reopenCode || reopenCode.trim().length < 4)) return;
    requireOwnerKey(
      `आर्थिक वर्ष क्लोजिङ र रोलओभर (${newFiscalYear})`,
      () => {
        // 1. Update company fiscal year
        setCompany((prev) => ({
          ...prev,
          closedFiscalYears: Array.from(new Set([...(prev.closedFiscalYears || []), prev.fiscalYear])),
          fiscalReopenCode: prev.fiscalReopenCode || (reopenCode || '').trim(),
          fiscalYear: newFiscalYear
        }));

        // 2. Rollover Items: currentStock becomes openingStock
        setItems((prev) =>
          prev.map((item) => ({
            ...item,
            openingStock: item.currentStock
          }))
        );

        // 3. Rollover Parties: current balance becomes opening balance
        setParties((prev) =>
          prev.map((party) => ({
            ...party,
            openingBalance: party.currentBalance !== undefined ? party.currentBalance : party.openingBalance
          }))
        );

        // 4. Rollover Bank Accounts: currentBalance becomes openingBalance
        setBankAccounts((prev) =>
          prev.map((b) => ({
            ...b,
            openingBalance: b.currentBalance
          }))
        );

        // 5. Rollover Daily Cash: closing cash becomes opening cash
        setDailyCash((prev) => ({
          ...prev,
          openingCash: prev.closingCashInHand,
          totalCashSales: 0,
          totalBankTransfers: 0,
          totalAdvancesGiven: 0
        }));
      },
      'EDIT'
    );
  };

  const DEFAULT_FISCAL_YEARS = ['079/80', '080/81', '081/82', '082/83', '083/84'];

  const fiscalYearsList = useMemo(() => {
    const list = Array.isArray(company.fiscalYearsList) && company.fiscalYearsList.length > 0
      ? [...company.fiscalYearsList]
      : [...DEFAULT_FISCAL_YEARS];
    if (company.fiscalYear && !list.includes(company.fiscalYear)) {
      list.push(company.fiscalYear);
    }
    return Array.from(new Set(list));
  }, [company.fiscalYearsList, company.fiscalYear]);

  const isFiscalYearClosed = (fy: string) => (company.closedFiscalYears || []).includes(fy);

  const switchFiscalYearNow = (fy: string) => {
    setCompany((prev) => {
      const updated = { ...prev, fiscalYear: fy };
      saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), updated);
      return updated;
    });
    logAuditAction({
      actionType: 'SETTINGS_UPDATED',
      module: 'SETTINGS',
      summaryNe: `सक्रिय आर्थिक वर्ष परिवर्तन: ${fy}`,
      summaryEn: `Active fiscal year switched to ${fy}`
    });
  };

  /** Closed years can only be re-activated with the reopen code set in Settings. */
  const selectFiscalYear = (fy: string): { success: boolean; message: string; needsCode?: boolean } => {
    if (!fy || fy === company.fiscalYear) return { success: true, message: '' };
    if (isFiscalYearClosed(fy)) {
      if (!company.fiscalReopenCode) {
        return {
          success: false,
          message: 'यो आर्थिक वर्ष बन्द छ। पुन: सक्रिय गर्न पहिले Settings मा Reopen Code सेट गर्नुहोस् (Set the reopen code in Settings first).'
        };
      }
      setFiscalCodeInput('');
      setFiscalCodeError(null);
      setFiscalCodePrompt(fy);
      return { success: false, needsCode: true, message: 'Reopen Code आवश्यक छ' };
    }
    switchFiscalYearNow(fy);
    return { success: true, message: '' };
  };

  const confirmReopenFiscalYear = () => {
    const fy = fiscalCodePrompt;
    if (!fy) return;
    if (company.fiscalReopenCode && fiscalCodeInput.trim() === company.fiscalReopenCode) {
      switchFiscalYearNow(fy);
      setFiscalCodePrompt(null);
      setFiscalCodeInput('');
      setFiscalCodeError(null);
    } else {
      setFiscalCodeError('गलत Code! (Wrong reopen code)');
    }
  };

  const setFiscalReopenCode = (newCode: string, currentCode?: string): { success: boolean; message: string } => {
    const clean = (newCode || '').trim();
    if (clean.length < 4) return { success: false, message: 'Code कम्तिमा ४ अक्षरको हुनुपर्छ (min 4 characters)' };
    if (company.fiscalReopenCode && (currentCode || '').trim() !== company.fiscalReopenCode) {
      return { success: false, message: 'हालको Code मिलेन (Current code is incorrect)' };
    }
    setCompany((prev) => {
      const updated = { ...prev, fiscalReopenCode: clean };
      saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), updated);
      return updated;
    });
    return { success: true, message: 'Reopen Code सुरक्षित भयो (Saved)' };
  };

  const addNewFiscalYear = (newFy: string): { success: boolean; message: string } => {
    const cleanFy = newFy.trim();
    if (!cleanFy) {
      return { success: false, message: 'कृपया नयाँ आर्थिक वर्ष टाइप गर्नुहोस् (जस्तै: 083/84)' };
    }
    const currentList = Array.isArray(company.fiscalYearsList) && company.fiscalYearsList.length > 0
      ? company.fiscalYearsList
      : DEFAULT_FISCAL_YEARS;
    const updatedList = Array.from(new Set([...currentList, cleanFy]));
    
    setCompany((prev) => {
      const updated = {
        ...prev,
        fiscalYear: cleanFy,
        fiscalYearsList: updatedList
      };
      saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), updated);
      return updated;
    });

    logAuditAction({
      actionType: 'SETTINGS_UPDATED',
      module: 'SETTINGS',
      summaryNe: `नयाँ आर्थिक वर्ष थपियो: ${cleanFy}`,
      summaryEn: `New fiscal year added: ${cleanFy}`
    });

    return { success: true, message: `आर्थिक वर्ष ${cleanFy} सफलतापूर्वक थपियो र सक्रिय गरियो।` };
  };

  const verifyOwnerPin = (pin: string): boolean => {
    const expected = normalizeDigits((company.ownerPin || '1234').trim());
    const entered = normalizeDigits((pin || '').trim());
    return entered.length > 0 && entered === expected;
  };

  const setOwnerPin = (newPin: string) => {
    const clean = normalizeDigits(newPin.trim());
    if (!clean) return;
    requireOwnerKey(
      `मालिकको सुरक्षा साँचो (Owner Key) परिवर्तन गर्ने`,
      () => {
        setCompany((prev) => {
          const updated = {
            ...prev,
            ownerPin: clean
          };
          saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), updated);
          return updated;
        });
      },
      'EDIT'
    );
  };

  const executeDeleteCompany = () => {
    const resetProfile: CompanyProfile = {
      name: 'मेरो नयाँ कम्पनी / फर्म',
      panVatNo: '',
      address: '',
      phone: '',
      email: '',
      tagline: 'कृषि औजार तथा इन्भेन्टरी व्यवस्थापन',
      vatBillPrefix: 'TI',
      nonVatBillPrefix: 'NV',
      fiscalYear: '081/82',
      bankAccounts: [],
      ownerPin: '1234',
      workplaceRadiusMeters: 200,
      workplaceLocationLabel: 'मुख्य काउन्टर'
    };

    setCompany(resetProfile);
    setInvoices([]);
    setPurchases([]);
    setParties([]);
    setAttendance([]);
    setEmployeeLedger([]);
    setDailyCash({
      id: `cash-${Date.now()}`,
      dateBs: getTodayBsString(),
      openingCash: 0,
      totalCashSales: 0,
      totalBankTransfers: 0,
      totalAdvancesGiven: 0,
      closingCashInHand: 0
    });
  };

  // कम्पनी / फर्म मेटाउने (Owner Only with PIN check)
  const deleteCompany = (ownerPin: string): { success: boolean; message: string } => {
    if (ownerPin && verifyOwnerPin(ownerPin)) {
      executeDeleteCompany();
      return {
        success: true,
        message: 'कम्पनी विवरण तथा सम्पूर्ण कारोबार सफलतापूर्वक मेटाइयो !'
      };
    }

    requireOwnerKey(
      'कम्पनी विवरण तथा सम्पूर्ण कारोबार रिसेट / मेटाउने',
      () => {
        executeDeleteCompany();
      },
      'DELETE'
    );

    return {
      success: true,
      message: 'कम्पनी मेटाउन मालिकको साँचो (Owner Key) प्रविष्ट गर्नुहोस्।'
    };
  };

  const bulkRecordAttendance = (params: {
    employeeIds: string[];
    type: 'IN' | 'OUT' | 'ABSENT' | 'LEAVE';
    photoUrl?: string;
    locationLabel?: string;
    workCategory?: StaffWorkCategory;
    workDescription?: string;
    siteOrClientName?: string;
    customDateBs?: string;
    verificationMethod?: 'FINGERPRINT' | 'FACE_PHOTO' | 'MANUAL_SUPERVISOR';
  }): { recordedCount: number; skippedCount: number } => {
    const targetDateBs = (params.customDateBs && params.customDateBs.trim()) || getTodayBsString();
    const todayAd = bsStringToAdString(targetDateBs) || getTodayAdString();
    const timeStr = company.autoSetShiftTime
      ? (params.type === 'IN' ? company.shiftStartTime || '10:00 AM' : company.shiftEndTime || '05:00 PM')
      : new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    let recorded = 0;
    let skipped = 0;

    setAttendance((prev) => {
      const updated = [...prev];
      params.employeeIds.forEach((empId) => {
        const emp = employees.find((e) => e.id === empId);
        const existingIdx = updated.findIndex((a) => a.employeeId === empId && a.dateBs === targetDateBs);

        if (params.type === 'ABSENT' || params.type === 'LEAVE') {
          recorded++;
          const newStatus = params.type === 'ABSENT' ? 'ABSENT' : 'LEAVE';
          const defaultLabel = params.type === 'ABSENT' ? 'अनुपस्थित (Bulk Absent)' : 'स्वीकृत बिदा (Bulk Leave)';
          if (existingIdx !== -1) {
            updated[existingIdx] = {
              ...updated[existingIdx],
              status: newStatus,
              checkInTime: '-',
              locationLabel: params.locationLabel || defaultLabel
            };
          } else {
            updated.unshift({
              id: `att-${Date.now()}-${empId}`,
              employeeId: empId,
              employeeName: emp?.name || 'Staff',
              dateBs: targetDateBs,
              dateAd: todayAd,
              checkInTime: '-',
              locationLabel: params.locationLabel || defaultLabel,
              status: newStatus,
              verificationMethod: 'MANUAL_SUPERVISOR',
              deviceType: 'SUPERVISOR',
              isOffline: !isOnline
            });
          }
          return;
        }

        if (params.type === 'IN') {
          if (existingIdx !== -1 && updated[existingIdx].checkInTime && updated[existingIdx].checkInTime !== '-') {
            // Update work category/site if provided
            if (params.workCategory || params.workDescription || params.siteOrClientName) {
              updated[existingIdx] = {
                ...updated[existingIdx],
                workCategory: params.workCategory || updated[existingIdx].workCategory,
                workDescription: params.workDescription || updated[existingIdx].workDescription,
                siteOrClientName: params.siteOrClientName || updated[existingIdx].siteOrClientName,
                locationLabel: params.locationLabel || updated[existingIdx].locationLabel
              };
              recorded++;
              return;
            }
            skipped++;
            return;
          }
          recorded++;
          const newRecord: AttendanceRecord = {
            id: `att-${Date.now()}-${empId}`,
            employeeId: empId,
            employeeName: emp?.name || 'Staff',
            dateBs: targetDateBs,
            dateAd: todayAd,
            checkInTime: timeStr,
            locationLabel: params.locationLabel || 'सुपरभाइजर हाजिरी (Store HQ)',
            workCategory: params.workCategory || 'WORKSHOP_REGULAR',
            workDescription: params.workDescription || 'नियमित काम',
            siteOrClientName: params.siteOrClientName || '',
            photoUrl: params.photoUrl || 'https://avatar.iran.liara.run/public',
            verificationMethod: params.verificationMethod || 'MANUAL_SUPERVISOR',
            deviceType: 'SUPERVISOR',
            status: 'PRESENT',
            isOffline: !isOnline,
            syncedAt: isOnline ? new Date().toLocaleTimeString() : undefined,
            isApproved: false
          };
          if (existingIdx !== -1) {
            updated[existingIdx] = {
              ...updated[existingIdx],
              checkInTime: timeStr,
              status: 'PRESENT',
              workCategory: params.workCategory || updated[existingIdx].workCategory,
              workDescription: params.workDescription || updated[existingIdx].workDescription,
              siteOrClientName: params.siteOrClientName || updated[existingIdx].siteOrClientName,
              verificationMethod: params.verificationMethod || updated[existingIdx].verificationMethod,
              photoUrl: params.photoUrl || updated[existingIdx].photoUrl
            };
          } else {
            updated.unshift(newRecord);
          }
        } else {
          // type === 'OUT'
          if (existingIdx === -1 || !updated[existingIdx].checkInTime || updated[existingIdx].checkInTime === '-' || updated[existingIdx].checkOutTime) {
            skipped++;
            return;
          }
          recorded++;
          updated[existingIdx] = {
            ...updated[existingIdx],
            checkOutTime: timeStr,
            isOffline: !isOnline,
            syncedAt: isOnline ? new Date().toLocaleTimeString() : updated[existingIdx].syncedAt
          };
        }
      });
      return updated;
    });

    return { recordedCount: recorded, skippedCount: skipped };
  };

  const executeSaveAttendanceGroup = (group: AttendanceGroup) => {
    setCompany((prev) => {
      const current = prev.attendanceGroups || [];
      const idx = current.findIndex((g) => g.id === group.id);
      const updated = idx !== -1
        ? current.map((g) => (g.id === group.id ? group : g))
        : [...current, group];
      return {
        ...prev,
        attendanceGroups: updated
      };
    });
  };

  const saveAttendanceGroup = (group: AttendanceGroup) => {
    const exists = (company.attendanceGroups || []).some((g) => g.id === group.id);
    if (exists) {
      requireOwnerKey(
        `हाजिरी समूह सच्याउने: ${group.nameNe || group.nameEn}`,
        () => executeSaveAttendanceGroup(group),
        'EDIT'
      );
    } else {
      executeSaveAttendanceGroup(group);
    }
  };

  const deleteAttendanceGroup = (groupId: string) => {
    const target = (company.attendanceGroups || []).find((g) => g.id === groupId);
    requireOwnerKey(
      `हाजिरी समूह मेटाउने: ${target?.nameNe || target?.nameEn || groupId}`,
      () => {
        setCompany((prev) => ({
          ...prev,
          attendanceGroups: (prev.attendanceGroups || []).filter((g) => g.id !== groupId)
        }));
      },
      'DELETE'
    );
  };

  const executeUpdateCompanyProfile = (profile: CompanyProfile) => {
    const cleanProfile: CompanyProfile = {
      ...profile,
      id: profile.id || activeCompanyId,
      name: (profile.name || '').trim() || 'कृषियन्त्र कृषि औजार तथा सप्लायर्स'
    };
    setCompany(cleanProfile);
    saveStoredData(getCompanyScopedKey(STORAGE_KEYS.COMPANY, activeCompanyId), cleanProfile);

    if (typeof document !== 'undefined' && cleanProfile.name) {
      document.title = cleanProfile.name;
    }

    setCompaniesList((prev) => {
      const exists = prev.some((c) => c.id === activeCompanyId);
      const updated = exists
        ? prev.map((c) =>
            c.id === activeCompanyId
              ? {
                  ...c,
                  name: cleanProfile.name,
                  panVatNo: cleanProfile.panVatNo ?? c.panVatNo,
                  address: cleanProfile.address ?? c.address,
                  phone: cleanProfile.phone ?? c.phone,
                  tagline: cleanProfile.tagline ?? c.tagline,
                  logoUrl: cleanProfile.logoUrl
                }
              : c
          )
        : [
            ...prev,
            {
              id: activeCompanyId,
              name: cleanProfile.name,
              panVatNo: cleanProfile.panVatNo || '',
              address: cleanProfile.address || '',
              phone: cleanProfile.phone || '',
              tagline: cleanProfile.tagline || '',
              logoUrl: cleanProfile.logoUrl,
              createdAtBs: getTodayBsString()
            }
          ];
      saveStoredData(COMPANIES_LIST_STORAGE_KEY, updated);
      return updated;
    });

    if (currentAccount && (!currentAccount.companyId || currentAccount.companyId === activeCompanyId)) {
      const updatedAcc = { ...currentAccount, companyName: cleanProfile.name };
      setCurrentAccount(updatedAcc);
      saveStoredData(STORAGE_KEYS.ACTIVE_ACCOUNT, updatedAcc);
    }
  };

  const updateCompanyProfile = (rawProfile: CompanyProfile, skipOwnerKeyPrompt?: boolean) => {
    // Profile form must not re-activate a closed year or overwrite the lock data
    const profile: CompanyProfile = {
      ...rawProfile,
      fiscalYear:
        rawProfile.fiscalYear !== company.fiscalYear && (company.closedFiscalYears || []).includes(rawProfile.fiscalYear)
          ? company.fiscalYear
          : rawProfile.fiscalYear,
      closedFiscalYears: company.closedFiscalYears,
      fiscalReopenCode: company.fiscalReopenCode
    };
    if (skipOwnerKeyPrompt) {
      executeUpdateCompanyProfile(profile);
      return;
    }
    requireOwnerKey(
      `कम्पनी / मास्टर सेटिङ विवरण सच्याउने (${profile.name || company.name})`,
      () => executeUpdateCompanyProfile(profile),
      'EDIT'
    );
  };

  const addBankAccount = (bank: BankAccount) => {
    setCompany((prev) => ({
      ...prev,
      bankAccounts: [...prev.bankAccounts, bank]
    }));
  };

  const loadAgricultureStarterCatalog = () => {
    setItems(SAMPLE_AGRICULTURE_ITEMS);
    if (employees.length === 0) {
      setEmployees(SAMPLE_EMPLOYEES);
    }
    if (parties.length === 0) {
      setParties(SAMPLE_PARTIES);
    }
  };

  const clearAllData = () => {
    requireOwnerKey(
      'प्रणालीको सम्पूर्ण डाटा खाली / मेटाउने (Clear All System Data)',
      () => {
        if (typeof window !== 'undefined') {
          localStorage.setItem(STORAGE_KEYS.USER_CLEARED, 'true');
        }
        setItems([]);
        setInvoices([]);
        setPurchases([]);
        setParties([]);
        setEmployees([]);
        setAttendance([]);
        setEmployeeLedger([]);
        localStorage.removeItem(STORAGE_KEYS.ITEMS);
        localStorage.removeItem(STORAGE_KEYS.INVOICES);
        localStorage.removeItem(STORAGE_KEYS.PURCHASES);
        localStorage.removeItem(STORAGE_KEYS.PARTIES);
        localStorage.removeItem(STORAGE_KEYS.EMPLOYEES);
        localStorage.removeItem(STORAGE_KEYS.ATTENDANCE);
        localStorage.removeItem(STORAGE_KEYS.EMPLOYEE_LEDGER);
        localStorage.removeItem(STORAGE_KEYS.DAILY_CASH);
      },
      'DELETE'
    );
  };

  const exportFullBackup = () => {
    const backupData = {
      version: '3.1',
      exportDate: new Date().toISOString(),
      company,
      bankAccounts,
      partyTransactions,
      items,
      invoices,
      purchases,
      parties,
      employees,
      attendance,
      employeeLedger,
      dailyCash,
      rawMaterials,
      productionBatches,
      fieldOrders,
      quotations,
      boms,
      productionOrders,
      companyAccounts,
      companiesList
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `KrishiYantra_Backup_${getTodayBsString().replace(/-/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const restoreFullBackup = (jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString);
      if (data.company) setCompany(data.company);
      if (Array.isArray(data.bankAccounts)) setBankAccounts(data.bankAccounts);
      if (Array.isArray(data.partyTransactions)) setPartyTransactions(data.partyTransactions);
      if (Array.isArray(data.items)) setItems(data.items);
      if (Array.isArray(data.invoices)) setInvoices(data.invoices);
      if (Array.isArray(data.purchases)) setPurchases(data.purchases);
      if (Array.isArray(data.parties)) setParties(data.parties);
      if (Array.isArray(data.employees)) setEmployees(data.employees);
      if (Array.isArray(data.attendance)) setAttendance(data.attendance);
      if (Array.isArray(data.employeeLedger)) setEmployeeLedger(data.employeeLedger);
      if (data.dailyCash) setDailyCash(data.dailyCash);
      if (Array.isArray(data.rawMaterials)) setRawMaterials(data.rawMaterials);
      if (Array.isArray(data.productionBatches)) setProductionBatches(data.productionBatches);
      if (Array.isArray(data.fieldOrders)) setFieldOrders(data.fieldOrders);
      if (Array.isArray(data.quotations)) setQuotations(data.quotations);
      if (Array.isArray(data.boms)) setBoms(data.boms);
      if (Array.isArray(data.productionOrders)) setProductionOrders(data.productionOrders);
      if (Array.isArray(data.companyAccounts)) setCompanyAccounts(data.companyAccounts);
      if (Array.isArray(data.companiesList) && data.companiesList.length > 0) setCompaniesList(data.companiesList);
      return true;
    } catch (e) {
      console.error('Failed to restore backup:', e);
      return false;
    }
  };

  const syncToCloudNow = async () => {
    return await syncCompanyDataToCloud(activeCompanyId, {
      company,
      items,
      invoices,
      purchases,
      parties,
      partyTransactions,
      bankAccounts,
      employees,
      attendance,
      employeeLedger,
      rawMaterials,
      productionBatches,
      fieldOrders,
      boms,
      productionOrders,
      dailyCash
    } as any);
  };

  const pullFromCloudNow = async () => {
    const cloudData = await fetchCompanyDataFromCloud(activeCompanyId);
    if (cloudData) {
      if (cloudData.company) setCompany(cloudData.company);
      if (Array.isArray(cloudData.items)) setItems(cloudData.items);
      if (Array.isArray(cloudData.invoices)) setInvoices(cloudData.invoices);
      if (Array.isArray(cloudData.purchases)) setPurchases(cloudData.purchases);
      if (Array.isArray(cloudData.parties)) setParties(cloudData.parties);
      if (Array.isArray(cloudData.partyTransactions)) setPartyTransactions(cloudData.partyTransactions);
      if (Array.isArray(cloudData.bankAccounts)) setBankAccounts(cloudData.bankAccounts);
      if (Array.isArray(cloudData.employees)) setEmployees(cloudData.employees);
      if (Array.isArray(cloudData.attendance)) setAttendance(cloudData.attendance);
      if (Array.isArray(cloudData.employeeLedger)) setEmployeeLedger(cloudData.employeeLedger);
      if (Array.isArray(cloudData.rawMaterials)) setRawMaterials(cloudData.rawMaterials);
      if (Array.isArray(cloudData.productionBatches)) setProductionBatches(cloudData.productionBatches);
      if (Array.isArray((cloudData as any).fieldOrders)) setFieldOrders((cloudData as any).fieldOrders);
      if (Array.isArray((cloudData as any).boms)) setBoms((cloudData as any).boms);
      if (Array.isArray((cloudData as any).productionOrders)) setProductionOrders((cloudData as any).productionOrders);
      if (cloudData.dailyCash) setDailyCash(cloudData.dailyCash);
      return { success: true, message: 'क्लाउड (Cloud) बाट डाटा सफलतापूर्वक सिंक भयो!' };
    }
    return { success: false, message: 'क्लाउडमा कुनै डाटा फेला परेन।' };
  };

  useEffect(() => {
    pullFromCloudNow().catch(() => {});
  }, [activeCompanyId]);

  const importItemsList = (newItems: Item[]) => {
    setItems((prev) => {
      const existingCodes = new Set(prev.map((i) => i.code.toLowerCase()));
      const toAdd = newItems.filter((i) => !existingCodes.has(i.code.toLowerCase()));
      return [...prev, ...toAdd];
    });
  };

  const importPartiesList = (newParties: Party[]) => {
    const todayBs = getTodayBsString();
    const todayAd = getTodayAdString();
    const newTxns: PartyTransaction[] = [];

    setParties((prev) => {
      const updated = [...prev];
      newParties.forEach((incoming, idx) => {
        const cleanName = incoming.name.trim().toLowerCase();
        if (!cleanName) return;

        const existingIdx = updated.findIndex((p) => p.name.trim().toLowerCase() === cleanName);
        let finalPartyId = incoming.id || `pty-imp-${Date.now()}-${idx}`;

        if (existingIdx !== -1) {
          finalPartyId = updated[existingIdx].id;
          updated[existingIdx] = {
            ...updated[existingIdx],
            address: incoming.address || updated[existingIdx].address,
            phone: incoming.phone || updated[existingIdx].phone,
            panNo: incoming.panNo || updated[existingIdx].panNo,
            openingBalance: incoming.openingBalance,
            paidAmount: incoming.paidAmount ?? updated[existingIdx].paidAmount ?? 0,
            currentBalance:
              incoming.currentBalance !== undefined
                ? incoming.currentBalance
                : Math.max(0, incoming.openingBalance - (incoming.paidAmount || 0))
          };
        } else {
          updated.push({
            ...incoming,
            id: finalPartyId,
            partyType: incoming.partyType || 'CUSTOMER',
            type: incoming.type || 'CUSTOMER',
            paidAmount: incoming.paidAmount || 0,
            currentBalance:
              incoming.currentBalance !== undefined
                ? incoming.currentBalance
                : Math.max(0, incoming.openingBalance - (incoming.paidAmount || 0))
          });
        }

        // If Excel row included a Pay Amount > 0, record it in Party Transactions so Ledger Statement shows it
        if (incoming.paidAmount && incoming.paidAmount > 0) {
          newTxns.push({
            id: `ptx-imp-${Date.now()}-${idx}`,
            partyId: finalPartyId,
            partyName: incoming.name.trim(),
            partyAddress: incoming.address,
            partyPhone: incoming.phone,
            dateBs: todayBs,
            dateAd: todayAd,
            type: 'COLLECTION_FROM_CUSTOMER',
            amount: incoming.paidAmount,
            paymentMode: 'CASH',
            referenceNo: `EXCEL-PAY-${idx + 1}`,
            notes: `एक्सेल अपलोडबाट प्राप्त भुक्तानी (Pay Amount from Excel Import)`
          });
        }
      });

      return updated;
    });

    if (newTxns.length > 0) {
      setPartyTransactions((prev) => [...newTxns, ...prev]);
    }
  };

  const importPurchasesList = (newPurchases: PurchaseRecord[]) => {
    setPurchases((prev) => {
      const existingBills = new Set(prev.map((p) => p.purchaseBillNo.trim().toLowerCase()));
      const toAdd = newPurchases.filter((p) => !existingBills.has(p.purchaseBillNo.trim().toLowerCase()));
      return [...prev, ...toAdd];
    });
  };

  const importInvoicesList = (newInvoices: Invoice[]) => {
    setInvoices((prev) => {
      const existingInvs = new Set(prev.map((i) => i.invoiceNo.trim().toLowerCase()));
      const toAdd = newInvoices.filter((i) => !existingInvs.has(i.invoiceNo.trim().toLowerCase()));
      return [...prev, ...toAdd];
    });
  };

  // Manufacturing & Production Management Methods
  const executeSaveRawMaterial = (material: RawMaterial) => {
    setRawMaterials((prev) => {
      const idx = prev.findIndex((r) => r.id === material.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = material;
        return next;
      }
      return [material, ...prev];
    });
  };

  const saveRawMaterial = (material: RawMaterial) => {
    const existing = rawMaterials.some((r) => r.id === material.id);
    if (existing) {
      requireOwnerKey(
        `कच्चा पदार्थ विवरण सच्याउने: ${material.nameNe || material.nameEn}`,
        () => executeSaveRawMaterial(material),
        'EDIT'
      );
    } else {
      executeSaveRawMaterial(material);
    }
  };

  const deleteRawMaterial = (id: string) => {
    const target = rawMaterials.find((r) => r.id === id);
    requireOwnerKey(
      `कच्चा पदार्थ मेटाउने: ${target?.nameNe || target?.nameEn || id}`,
      () => {
        setRawMaterials((prev) => prev.filter((r) => r.id !== id));
      },
      'DELETE'
    );
  };

  const executeSaveProductionBatch = (batch: ProductionBatch) => {
    setProductionBatches((prev) => {
      const idx = prev.findIndex((b) => b.id === batch.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = batch;
        return next;
      }
      return [batch, ...prev];
    });

    // Auto Deduct Issued Raw Materials from Stock
    if (batch.rawMaterialsUsed && batch.rawMaterialsUsed.length > 0) {
      setRawMaterials((prevRm) => {
        const updated = [...prevRm];
        batch.rawMaterialsUsed.forEach((usage) => {
          const rmIdx = updated.findIndex((r) => r.id === usage.materialId);
          if (rmIdx !== -1) {
            updated[rmIdx] = {
              ...updated[rmIdx],
              currentStock: Math.max(0, updated[rmIdx].currentStock - usage.quantityUsed)
            };
          }
        });
        return updated;
      });
    }

    // Auto Add Finished Goods to Stock if directly registered as FINISHED_GOODS
    if (batch.stage === 'FINISHED_GOODS') {
      const qty = batch.outputQuantity || batch.finishedGoodsQuantity || batch.targetQuantity || 0;
      if (qty > 0) {
        setItems((prevItems) => {
          let itemIdx = -1;
          if (batch.finishedItemId) {
            itemIdx = prevItems.findIndex((i) => i.id === batch.finishedItemId);
          }
          if (itemIdx === -1) {
            itemIdx = prevItems.findIndex(
              (i) => i.nameNe.toLowerCase() === batch.productNameNe.toLowerCase() ||
                     i.nameEn.toLowerCase() === batch.productNameEn.toLowerCase()
            );
          }
          if (itemIdx !== -1) {
            const next = [...prevItems];
            next[itemIdx] = {
              ...next[itemIdx],
              currentStock: next[itemIdx].currentStock + qty,
              purchasePrice: batch.unitManufacturingCost || next[itemIdx].purchasePrice
            };
            return next;
          } else {
            const newItem: Item = {
              id: batch.finishedItemId || `item-fg-${Date.now()}`,
              code: `FG-${batch.batchNumber.slice(-4)}`,
              nameNe: batch.productNameNe,
              nameEn: batch.productNameEn,
              category: 'TRACTOR_TILLER',
              unit: batch.outputUnit || 'Set',
              purchasePrice: batch.unitManufacturingCost || 1000,
              sellingPrice: Math.round((batch.unitManufacturingCost || 1000) * 1.25),
              openingStock: qty,
              currentStock: qty,
              minStockAlert: 2,
              isVatExempt: false
            };
            return [newItem, ...prevItems];
          }
        });
      }
    }
  };

  const saveProductionBatch = (batch: ProductionBatch) => {
    const existing = productionBatches.some((b) => b.id === batch.id);
    if (existing) {
      requireOwnerKey(
        `उत्पादन ब्याच सच्याउने: ${batch.batchNumber} (${batch.productNameNe})`,
        () => executeSaveProductionBatch(batch),
        'EDIT'
      );
    } else {
      executeSaveProductionBatch(batch);
    }
  };

  const updateBatchStage = (
    batchId: string,
    newStage: ProductionStage,
    additionalDetails?: Partial<ProductionBatch>
  ) => {
    setProductionBatches((prev) =>
      prev.map((b) => {
        if (b.id !== batchId) return b;
        const updated = {
          ...b,
          stage: newStage,
          ...additionalDetails
        };
        // If moved to FINISHED_GOODS, auto-add to finished goods item inventory
        if (newStage === 'FINISHED_GOODS') {
          const qty = additionalDetails?.outputQuantity || additionalDetails?.finishedGoodsQuantity || b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0;
          if (qty > 0) {
            setItems((prevItems) => {
              let existingIdx = -1;
              const targetId = additionalDetails?.finishedItemId || b.finishedItemId;
              if (targetId) {
                existingIdx = prevItems.findIndex((i) => i.id === targetId);
              }
              if (existingIdx === -1) {
                existingIdx = prevItems.findIndex(
                  (i) => i.nameNe.toLowerCase() === b.productNameNe.toLowerCase() || i.nameEn.toLowerCase() === b.productNameEn.toLowerCase()
                );
              }
              if (existingIdx !== -1) {
                const next = [...prevItems];
                next[existingIdx] = {
                  ...next[existingIdx],
                  currentStock: next[existingIdx].currentStock + qty,
                  purchasePrice: additionalDetails?.unitManufacturingCost || b.unitManufacturingCost || next[existingIdx].purchasePrice
                };
                return next;
              } else {
                const newItem: Item = {
                  id: targetId || `item-fg-${Date.now()}`,
                  code: `FG-${b.batchNumber.slice(-4)}`,
                  nameNe: b.productNameNe,
                  nameEn: b.productNameEn,
                  category: 'TRACTOR_TILLER',
                  unit: additionalDetails?.outputUnit || b.outputUnit || 'Set',
                  purchasePrice: additionalDetails?.unitManufacturingCost || b.unitManufacturingCost || 1000,
                  sellingPrice: Math.round((additionalDetails?.unitManufacturingCost || b.unitManufacturingCost || 1000) * 1.25),
                  openingStock: qty,
                  currentStock: qty,
                  minStockAlert: 2,
                  isVatExempt: false
                };
                return [newItem, ...prevItems];
              }
            });
          }
        }
        return updated;
      })
    );
  };

  const deleteProductionBatch = (batchId: string) => {
    const target = productionBatches.find((b) => b.id === batchId);
    requireOwnerKey(
      `उत्पादन ब्याच मेटाउने: ${target?.batchNumber || batchId} (${target?.productNameNe || ''})`,
      () => {
        setProductionBatches((prev) => prev.filter((b) => b.id !== batchId));
      },
      'DELETE'
    );
  };

  const recordDispatch = (batchId: string | null | undefined, dispatch: Omit<DispatchRecord, 'id'>) => {
    const newDispatch: DispatchRecord = {
      ...dispatch,
      id: `disp-${Date.now()}`
    };
    
    if (batchId) {
      setProductionBatches((prev) =>
        prev.map((b) => {
          if (b.id !== batchId) return b;
          const existingDispatches = b.dispatches || [];
          return {
            ...b,
            stage: 'DISPATCHED_MARKET',
            dispatches: [newDispatch, ...existingDispatches]
          };
        })
      );
    } else {
      setIndependentDispatches((prev) => [newDispatch, ...prev]);
    }

    // Auto Stock Adjustment (Directly update state to avoid Owner PIN prompt on every challan)
    if (newDispatch.items && newDispatch.items.length > 0) {
      setItems((prevItems) => {
        const updatedItems = [...prevItems];
        newDispatch.items.forEach((dItem) => {
          if (dItem.itemId) {
            const idx = updatedItems.findIndex((it) => it.id === dItem.itemId);
            if (idx !== -1) {
              const current = updatedItems[idx];
              // SALES: Decrease stock (-), PURCHASE or MANUFACTURE: Increase stock (+)
              const adj = newDispatch.type === 'SALES' ? -dItem.qty : dItem.qty;
              updatedItems[idx] = {
                ...current,
                currentStock: Math.max(0, Math.round((current.currentStock + adj) * 10000) / 10000)
              };
            }
          }
        });
        return updatedItems;
      });

      // Log the movement
      logAuditAction({
        actionType: 'STOCK_ADJUSTED',
        module: 'INVENTORY',
        severity: 'INFO',
        targetId: newDispatch.challanNo,
        summaryNe: `चलानी (Challan) ${newDispatch.challanNo} द्वारा स्टक मिलान गरियो (${newDispatch.type})`,
        summaryEn: `Stock adjusted via Challan ${newDispatch.challanNo} (${newDispatch.type})`
      });
    }
  };

  const updateDispatchStatus = (batchId: string | null | undefined, dispatchId: string, status: 'IN_TRANSIT' | 'DELIVERED') => {
    if (batchId) {
      setProductionBatches((prev) =>
        prev.map((b) => {
          if (b.id !== batchId) return b;
          return {
            ...b,
            dispatches: (b.dispatches || []).map((d) =>
              d.id === dispatchId ? { ...d, status } : d
            )
          };
        })
      );
    } else {
      setIndependentDispatches((prev) =>
        prev.map((d) => (d.id === dispatchId ? { ...d, status } : d))
      );
    }
  };
  
  const approveDispatch = (batchId: string | null | undefined, dispatchId: string, approvedBy: string) => {
    if (batchId) {
      setProductionBatches((prev) =>
        prev.map((b) => {
          if (b.id !== batchId) return b;
          return {
            ...b,
            dispatches: (b.dispatches || []).map((d) =>
              d.id === dispatchId
                ? {
                    ...d,
                    isApproved: true,
                    approvedBy,
                    approvedDateBs: getTodayBsString()
                  }
                : d
            )
          };
        })
      );
    } else {
      setIndependentDispatches((prev) =>
        prev.map((d) =>
          d.id === dispatchId
            ? {
                ...d,
                isApproved: true,
                approvedBy,
                approvedDateBs: getTodayBsString()
              }
            : d
        )
      );
    }
    
    logAuditAction({
      actionType: 'SETTINGS_UPDATED',
      module: 'SETTINGS',
      summaryNe: `चलानी स्वीकृत गरियो: ${dispatchId} (By: ${approvedBy})`,
      summaryEn: `Dispatch Approved: ${dispatchId} (By: ${approvedBy})`
    });
  };

  const handleSetVoucherSubTab = (subTab: 'COLLECTION' | 'PAYMENT' | 'CUSTOMERS' | 'EXPENSES' | 'CASH_BOOK' | 'BANK_RECONCILIATION') => {
    setVoucherSubTab(subTab);
  };

  const triggerQuickPurchase = () => {
    setActiveTab('vat_books');
    setOpenPurchaseModalSignal((prev) => prev + 1);
  };

  const triggerQuickDispatch = (billId: string, type: 'SALES' | 'PURCHASE') => {
    setPreselectedBillId(billId);
    setPreselectedBillType(type);
    setActiveTab('logistics');
    setOpenDispatchModalSignal((v) => v + 1);
  };

  // ---------------------------------------------------------------------------
  // बन्द भइसकेको आर्थिक वर्षको रेकर्ड नयाँ/सक्रिय आ.व. मा लुकाउने
  // (डाटा मेटिँदैन — ब्याकअप/सिङ्कमा पूरै रहन्छ; आ.व. Reopen Code ले फेरि सक्रिय गरेमा देखिन्छ)
  // ---------------------------------------------------------------------------
  const closedFyKey = (company.closedFiscalYears || []).join('|');
  const isHiddenByClosedFy = (dateBs?: string, recordFy?: string): boolean => {
    const closed = company.closedFiscalYears || [];
    if (closed.length === 0) return false;
    let fy = (recordFy || '').trim();
    if (!fy) {
      const m = /^(\d{4})\s*[-/.]\s*(\d{1,2})/.exec(normalizeDigits((dateBs || '').trim()));
      if (!m) return false; // मिति बुझिएन भने नलुकाउने (डाटा हराउन नदिन)
      fy = getFiscalYear(`${m[1]}-${m[2]}-01`);
    }
    return closed.includes(fy) && fy !== company.fiscalYear;
  };
  const visibleInvoices = useMemo(
    () => invoices.filter((r) => !isHiddenByClosedFy(r.dateBs, r.fiscalYear)),
    [invoices, closedFyKey, company.fiscalYear]
  );
  const visiblePurchases = useMemo(
    () => purchases.filter((r) => !isHiddenByClosedFy(r.dateBs, (r as any).fiscalYear)),
    [purchases, closedFyKey, company.fiscalYear]
  );
  const visiblePartyTransactions = useMemo(
    () => partyTransactions.filter((r) => !isHiddenByClosedFy(r.dateBs, (r as any).fiscalYear)),
    [partyTransactions, closedFyKey, company.fiscalYear]
  );
  const visibleExpenses = useMemo(
    () => expenses.filter((r) => !isHiddenByClosedFy(r.dateBs, (r as any).fiscalYear)),
    [expenses, closedFyKey, company.fiscalYear]
  );
  const invoiceToEdit = useMemo(
    () => (invoiceToEditId ? invoices.find((i) => i.id === invoiceToEditId) || null : null),
    [invoiceToEditId, invoices]
  );

  return (
    <AppContext.Provider
      value={{
        items,
        invoices: visibleInvoices,
        purchases: visiblePurchases,
        parties,
        partyTransactions: visiblePartyTransactions,
        allInvoices: invoices,
        allPurchases: purchases,
        allPartyTransactions: partyTransactions,
        allExpenses: expenses,
        bankAccounts,
        employees,
        attendance,
        employeeLedger,
        company,
        dailyCash,
        rawMaterials,
        productionBatches,
        recurringInvoices,
        language,
        currentRole,
        activeTab,
        isOnline,
        t,
        companyAccounts,
        currentAccount,
        companiesList,
        activeCompanyId,
        switchCompany,
        createNewCompany,
        deleteCompanyById,
        loginWithMobile,
        registerMobileAccount,
        approveAccount,
        rejectAccount,
        resetAccountPin,
        saveCompanyAccount,
        deleteCompanyAccount,
        logoutAccount,
        updatePermissions,
        checkPermission,
        setLanguage,
        setCurrentRole,
        setActiveTab,
        saveRawMaterial,
        deleteRawMaterial,
        saveProductionBatch,
        deleteProductionBatch,
        updateBatchStage,
        recordDispatch,
        updateDispatchStatus,
        saveRecurringInvoice,
        deleteRecurringInvoice,
        createInvoice,
        updateInvoice,
        invoiceToEdit,
        startEditInvoice,
        clearInvoiceToEdit,
        cancelInvoice,
        deleteInvoice,
        saveItem,
        deleteItem,
        adjustStock,
        reconcileItemStock,
        recordPurchase,
        deletePurchase,
        saveParty,
        deleteParty,
        updatePartyBalance,
        recordPartyPayment,
        recordCustomerCollection,
        getPartyOutstandingDue,
        saveBankAccount,
        deleteBankAccount,
        recordManualBankEntry,
        expenses: visibleExpenses,
        recordExpense,
        deleteExpense,
        deletePartyTransaction,
        recordAttendance,
        enrollEmployeeFingerprint,
        enrollEmployeeBiometrics,
        setEmployeeAttendanceStatus,
        saveEmployee,
        deleteEmployee,
        recordCashAdvance,
        payEmployeeSalary,
        getEmployeePayrollSummary,
        updateOpeningCash,
        closeFiscalYear,
        verifyOwnerPin,
        setOwnerPin,
        requireOwnerKey,
        deleteCompany,
        bulkRecordAttendance,
        saveAttendanceGroup,
        deleteAttendanceGroup,
        updateCompanyProfile,
        addBankAccount,
        loadAgricultureStarterCatalog,
        clearAllData,
        exportFullBackup,
        restoreFullBackup,
        importItemsList,
        importPartiesList,
        importPurchasesList,
        importInvoicesList,
        syncToCloudNow,
        pullFromCloudNow,
        fiscalYearsList,
        selectFiscalYear,
        isFiscalYearClosed,
        setFiscalReopenCode,
        addNewFiscalYear,
        voucherSubTab,
        setVoucherSubTab: handleSetVoucherSubTab,
        billingSubTab,
        setBillingSubTab,
        manufacturingSubTab,
        setManufacturingSubTab,
        ledgerSubTab,
        setLedgerSubTab,
        inventorySubTab,
        setInventorySubTab,
        reportSubTab,
        setReportSubTab,
        attendanceSubTab,
        setAttendanceSubTab,
        logisticsSubTab,
        setLogisticsSubTab,
        independentDispatches,
        approveDispatch,
        openPurchaseModalSignal,
        triggerQuickPurchase,
        openDispatchModalSignal,
        preselectedBillId,
        preselectedBillType,
        triggerQuickDispatch,
        auditLogs,
        logAuditAction,
        clearAuditLogs,
        machines,
        fieldOrders,
        quotations,
        saveQuotation,
        deleteQuotation,
        getNextQuotationNo,
        saveFieldOrder,
        deleteFieldOrder,
        updateFieldOrderStatus,
        getNextFieldOrderNo,
        boms,
        saveBom,
        deleteBom,
        productionOrders,
        saveProductionOrder,
        deleteProductionOrder,
        getNextProductionOrderNo,
        releaseProductionOrder,
        completeProductionOrder,
        saveMachine,
        deleteMachine,
        addMaintenanceLog,
        assignMachineWorker,
        lockDateBs,
        setLockDate,
        settleCustomerBankPayment
      }}
    >
      {children}

      {/* Global Security Toast Banner */}
      {ownerKeyToast && (
        <div
          className={`fixed top-4 left-1/2 -translate-x-1/2 z-[10001] px-5 py-3 rounded-2xl shadow-2xl border text-xs font-extrabold flex items-center gap-2.5 ${
            ownerKeyToast.type === 'success'
              ? 'bg-emerald-950 text-emerald-100 border-emerald-400'
              : 'bg-amber-950 text-amber-100 border-amber-400'
          }`}
        >
          <span>{ownerKeyToast.text}</span>
          <button
            type="button"
            onClick={() => setOwnerKeyToast(null)}
            className="text-white/70 hover:text-white cursor-pointer ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* FISCAL YEAR REOPEN CODE MODAL */}
      {fiscalCodePrompt && (
        <div className="fixed inset-0 z-[10001] bg-slate-950/75 flex items-center justify-center p-4">
          <form
            onSubmit={(e) => { e.preventDefault(); confirmReopenFiscalYear(); }}
            className="w-full max-w-sm bg-white rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="px-5 py-4 bg-rose-900 text-white">
              <h3 className="text-sm font-bold">🔒 बन्द आर्थिक वर्ष {fiscalCodePrompt} पुन: सक्रिय गर्ने</h3>
              <p className="text-[11px] text-white/80">Enter the reopen code to activate this closed fiscal year</p>
            </div>
            <div className="p-5 space-y-3">
              <input
                autoFocus
                type="password"
                value={fiscalCodeInput}
                onChange={(e) => { setFiscalCodeInput(e.target.value); setFiscalCodeError(null); }}
                placeholder="Reopen Code"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-center font-mono tracking-widest"
              />
              {fiscalCodeError && <p className="text-xs font-bold text-rose-700">{fiscalCodeError}</p>}
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => { setFiscalCodePrompt(null); setFiscalCodeInput(''); setFiscalCodeError(null); }}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm">रद्द / Cancel</button>
                <button type="submit" className="px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white font-bold rounded-lg text-sm">सक्रिय गर्नुहोस्</button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* GLOBAL MANDATORY OWNER KEY VERIFICATION MODAL FOR ANY DELETE OR EDIT */}
      {ownerKeyPromptQueue.length > 0 && (() => {
        const hasDelete = ownerKeyPromptQueue.some((a) => a.actionType === 'DELETE');
        const isDefaultPin = !company.ownerPin || company.ownerPin.trim() === '1234';

        const handleConfirmOwnerKey = (e: React.FormEvent) => {
          e.preventDefault();
          if (!verifyOwnerPin(ownerKeyModalInput)) {
            setOwnerKeyModalError(
              '❌ गलत मालिक साँचो (Wrong Owner Key)! कृपया सही Owner Key राख्नुहोस्।'
            );
            return;
          }

          const toExecute = [...ownerKeyPromptQueue];
          setOwnerKeyPromptQueue([]);
          setOwnerKeyModalInput('');
          setOwnerKeyModalError(null);

          toExecute.forEach((item) => {
            try {
              item.execute();
            } catch (err) {
              console.error('Owner key action error:', err);
            }
          });

          showGlobalSecurityToast(
            hasDelete
              ? '✅ मालिक साँचो (Owner Key) प्रमाणित भयो! डाटा सफलतापूर्वक मेटाइयो।'
              : '✅ मालिक साँचो (Owner Key) प्रमाणित भयो! विवरण सफलतापूर्वक सच्याइयो।',
            'success'
          );
        };

        const handleCancelOwnerKey = () => {
          ownerKeyPromptQueue.forEach((q) => {
            try { q.onCancel?.(); } catch (err) { console.error(err); }
          });
          setOwnerKeyPromptQueue([]);
          setOwnerKeyModalInput('');
          setOwnerKeyModalError(null);
          showGlobalSecurityToast(
            '⚠️ मालिकको साँचो (Owner Key) नराखिएकोले कार्य रद्द गरियो — कुनै डाटा परिवर्तन भएन।',
            'warn'
          );
        };

        return (
          <div className="fixed inset-0 z-[10000] bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border-2 border-slate-800 overflow-hidden">
              <div
                className={`px-5 py-4 text-white flex items-center justify-between ${
                  hasDelete
                    ? 'bg-gradient-to-r from-rose-800 to-rose-950'
                    : 'bg-gradient-to-r from-amber-700 to-slate-900'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-xl">{hasDelete ? '🗑️' : '🔐'}</span>
                  <div>
                    <h3 className="text-sm font-black tracking-tight">
                      {hasDelete
                        ? 'डाटा मेटाउन मालिकको साँचो (Owner Key) अनिवार्य!'
                        : 'डाटा सच्याउन मालिकको साँचो (Owner Key) अनिवार्य!'}
                    </h3>
                    <p className="text-[11px] text-white/85">
                      Owner Key verification required to {hasDelete ? 'delete' : 'edit/modify'} data
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleCancelOwnerKey}
                  className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleConfirmOwnerKey} className="p-5 space-y-4 text-xs">
                <div
                  className={`p-3 rounded-xl border space-y-1.5 ${
                    hasDelete
                      ? 'bg-rose-50 border-rose-200 text-rose-950'
                      : 'bg-amber-50 border-amber-200 text-amber-950'
                  }`}
                >
                  <div className="font-extrabold text-[11px] uppercase tracking-wider opacity-80">
                    तपाईंले गर्न लाग्नुभएको कार्य (Pending Action):
                  </div>
                  <ul className="space-y-1 font-bold text-xs">
                    {ownerKeyPromptQueue.map((item) => (
                      <li key={item.id} className="flex items-start gap-1.5">
                        <span>{item.actionType === 'DELETE' ? '🗑️' : '✏️'}</span>
                        <span>{item.label}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="font-extrabold text-slate-900 text-xs">
                      🔑 मालिकको गोप्य साँचो (Owner Key / PIN) राख्नुहोस्:*
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowOwnerKeyPlain((prev) => !prev)}
                      className="text-[11px] font-bold text-blue-700 hover:underline cursor-pointer"
                    >
                      {showOwnerKeyPlain ? '🙈 लुकाउनुहोस्' : '👁️ हेर्नुहोस्'}
                    </button>
                  </div>
                  <input
                    type={showOwnerKeyPlain ? 'text' : 'password'}
                    autoFocus
                    required
                    value={ownerKeyModalInput}
                    onChange={(e) => {
                      setOwnerKeyModalInput(e.target.value);
                      if (ownerKeyModalError) setOwnerKeyModalError(null);
                    }}
                    placeholder="मालिकको साँचो (Owner Key) यहाँ टाइप गर्नुहोस्..."
                    className="w-full px-3.5 py-2.5 border-2 border-slate-300 focus:border-slate-900 rounded-xl font-mono text-base font-black tracking-widest text-slate-900 bg-slate-50 focus:bg-white focus:outline-none"
                  />
                  <p className="text-[11px] text-slate-500 mt-1.5">
                    {isDefaultPin
                      ? '💡 सुरुवाती डिफल्ट Owner Key: 1234 (मास्टर सेटिङबाट परिवर्तन गर्न सकिन्छ)'
                      : '🔒 मास्टर सेटिङमा सेट गरिएको मालिकको साँचो (Owner Key) प्रविष्ट गर्नुहोस्।'}
                  </p>
                </div>

                {ownerKeyModalError && (
                  <div className="p-2.5 bg-rose-100 border border-rose-300 text-rose-900 rounded-xl font-bold text-xs">
                    {ownerKeyModalError}
                  </div>
                )}

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={handleCancelOwnerKey}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl cursor-pointer transition"
                  >
                    रद्द गर्नुहोस् (Cancel)
                  </button>
                  <button
                    type="submit"
                    className={`px-5 py-2.5 text-white font-extrabold rounded-xl shadow-md cursor-pointer transition flex items-center gap-1.5 ${
                      hasDelete
                        ? 'bg-rose-700 hover:bg-rose-800'
                        : 'bg-emerald-700 hover:bg-emerald-800'
                    }`}
                  >
                    <span>🔑</span>
                    <span>
                      {hasDelete
                        ? 'प्रमाणित गरी मेटाउनुहोस् (Confirm Delete)'
                        : 'प्रमाणित गरी सच्याउनुहोस् (Confirm Edit)'}
                    </span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
