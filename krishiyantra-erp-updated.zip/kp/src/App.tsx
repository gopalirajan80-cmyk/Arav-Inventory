import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { LoginGate } from './components/LoginGate';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { DashboardScreen } from './components/DashboardScreen';
import { BillingScreen } from './components/BillingScreen';
import { InventoryScreen } from './components/InventoryScreen';
import { VatBookScreen } from './components/VatBookScreen';
import { AttendanceScreen } from './components/AttendanceScreen';
import { ExcelWizardScreen } from './components/ExcelWizardScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { ReportsScreen } from './components/ReportsScreen';
import { VoucherScreen } from './components/VoucherScreen';
import { LedgerScreen } from './components/LedgerScreen';
import { ManufacturingScreen } from './components/ManufacturingScreen';
import { FieldOrdersScreen } from './components/FieldOrdersScreen';
import { LogisticsScreen } from './components/LogisticsScreen';
import { AccountingScreen } from './components/AccountingScreen';
import { StockCostingScreen } from './components/StockCostingScreen';
import { AuditTrailScreen } from './components/AuditTrailScreen';
import AuditReportScreen from './components/AuditReportScreen';
import { InvoicePrintModal } from './components/InvoicePrintModal';
import { MobileAuthModal } from './components/MobileAuthModal';
import { ImsDmsLoginCard } from './components/ImsDmsLoginCard';
import { AutoBackupManager } from './components/AutoBackupManager';
import { BottomStatusBar } from './components/BottomStatusBar';
import {
  LayoutDashboard,
  Receipt,
  Wallet,
  Boxes,
  FileSpreadsheet,
  BookOpenCheck,
  ShieldAlert,
  Clock,
  Smartphone,
  ShieldCheck,
  XCircle,
  CalendarCheck2,
  Factory,
  Plus,
  X,
  Truck,
  ClipboardList
} from 'lucide-react';

const AppContent: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    invoices,
    startEditInvoice,
    cancelInvoice,
    deleteInvoice,
    language,
    currentAccount,
    currentRole,
    setCurrentRole,
    loginWithMobile,
    setBillingSubTab,
    setVoucherSubTab,
    setManufacturingSubTab,
    setLogisticsSubTab,
    setLedgerSubTab,
    setInventorySubTab
  } = useApp();
  const [viewingInvoiceId, setViewingInvoiceId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  // Desktop sidebar: collapsed (icon-only) or expanded. Remembered between visits.
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    try { return localStorage.getItem('ky-sidebar-collapsed') === '1'; } catch { return false; }
  });
  const toggleSidebarCollapsed = () => {
    setIsSidebarCollapsed((prev) => {
      const next = !prev;
      try { localStorage.setItem('ky-sidebar-collapsed', next ? '1' : '0'); } catch { /* ignore */ }
      return next;
    });
  };
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'LOGIN' | 'REGISTER' | 'ADMIN_APPROVAL'>('LOGIN');
  const [isQuickPlusOpen, setIsQuickPlusOpen] = useState(false);

  // Detect dedicated Staff vs Owner URL link (?portal=staff or ?portal=owner, plus ?tab=attendance etc.)
  const portalMode = React.useMemo(() => {
    if (typeof window === 'undefined') return null;
    const params = new URLSearchParams(window.location.search);
    const p = (params.get('portal') || params.get('mode') || '').toLowerCase();
    if (p === 'staff' || p === 'attendance') return 'STAFF_PORTAL';
    if (p === 'owner' || p === 'admin') return 'OWNER_PORTAL';
    return null;
  }, []);

  React.useEffect(() => {
    if (typeof window === 'undefined') return;
    const applyUrlParams = () => {
      const params = new URLSearchParams(window.location.search);
      const requestedTab = (params.get('tab') || '').toLowerCase();
      const subParam = (params.get('sub') || params.get('subTab') || '').toUpperCase();
      const p = (params.get('portal') || params.get('mode') || '').toLowerCase();

      if (portalMode === 'STAFF_PORTAL' && currentRole === 'OWNER' && currentAccount?.mobileNumber !== '9855012345') {
        setCurrentRole('COUNTER_SALES');
        if (requestedTab === 'attendance' || p === 'attendance') {
          setActiveTab('attendance');
        } else {
          setActiveTab('billing');
        }
      } else if (portalMode === 'OWNER_PORTAL') {
        setCurrentRole('OWNER');
      }

      if (requestedTab === 'purchase') {
        setActiveTab('billing');
        setBillingSubTab('PURCHASE');
      } else if (requestedTab === 'manufacture' || requestedTab === 'production' || requestedTab === 'wip') {
        setActiveTab('manufacturing');
        if (['OVERVIEW', 'RAW_MATERIALS', 'WIP_MACHINE', 'FINISHED_GOODS', 'PACKAGING', 'DISPATCHED', 'BATCHES', 'MACHINES', 'REPORTS', 'BOM', 'PLANNING'].includes(subParam)) {
          setManufacturingSubTab(subParam as any);
        }
      } else if (requestedTab === 'party' || requestedTab === 'party_ledger') {
        setActiveTab('ledger');
        if (['ALL', 'CUSTOMER', 'SUPPLIER', 'DUE_ONLY', 'ADD_PARTY'].includes(subParam)) {
          setLedgerSubTab(subParam as any);
        }
      } else if (
        requestedTab &&
        [
          'dashboard',
          'billing',
          'vouchers',
          'ledger',
          'inventory',
          'manufacturing',
          'reports',
          'vat_books',
          'accounting',
          'stock_costing',
          'audit_trail',
          'attendance',
          'logistics',
          'field_orders',
          'excel_wizard',
          'settings'
        ].includes(requestedTab)
      ) {
        setActiveTab(requestedTab);
        if (requestedTab === 'billing' && ['SALES', 'PURCHASE', 'PAYMENT_IN', 'PAYMENT_OUT', 'SALES_RETURN', 'PURCHASE_RETURN'].includes(subParam)) {
          setBillingSubTab(subParam as any);
        } else if (requestedTab === 'manufacturing' && ['OVERVIEW', 'RAW_MATERIALS', 'WIP_MACHINE', 'FINISHED_GOODS', 'PACKAGING', 'DISPATCHED', 'BATCHES', 'MACHINES', 'REPORTS', 'BOM', 'PLANNING'].includes(subParam)) {
          setManufacturingSubTab(subParam as any);
        } else if (requestedTab === 'ledger' && ['ALL', 'CUSTOMER', 'SUPPLIER', 'DUE_ONLY', 'ADD_PARTY'].includes(subParam)) {
          setLedgerSubTab(subParam as any);
        } else if (requestedTab === 'inventory' && ['ALL', 'ADD_ITEM', 'RECONCILE', 'LOW_STOCK', 'RAW_MATERIALS', 'FINISHED_GOODS'].includes(subParam)) {
          setInventorySubTab(subParam as any);
        } else if (requestedTab === 'logistics' && ['DASHBOARD', 'DISPATCH_LOG', 'PENDING_APPROVAL'].includes(subParam)) {
          setLogisticsSubTab(subParam as any);
        }
      } else if (p === 'attendance') {
        setActiveTab('attendance');
      }
    };

    applyUrlParams();

    const handleSubNav = (e: Event) => {
      const detail = (e as CustomEvent).detail || {};
      if (detail.target) {
        setActiveTab(detail.target);
      }
      if (detail.billingSubTab) {
        setBillingSubTab(detail.billingSubTab);
      }
      if (detail.manufacturingSubTab) {
        setManufacturingSubTab(detail.manufacturingSubTab);
      }
      if (detail.logisticsSubTab) {
        setLogisticsSubTab(detail.logisticsSubTab);
      }
      if (detail.ledgerSubTab) {
        setLedgerSubTab(detail.ledgerSubTab);
      }
    };

    window.addEventListener('ims-sub-nav', handleSubNav);
    window.addEventListener('popstate', applyUrlParams);
    return () => {
      window.removeEventListener('ims-sub-nav', handleSubNav);
      window.removeEventListener('popstate', applyUrlParams);
    };
  }, [portalMode]);

  const selectedInvoice = invoices.find((i) => i.id === viewingInvoiceId);
  const isNe = language === 'ne';
  const isPendingApproval = currentAccount?.status === 'PENDING_APPROVAL';
  const isRejected = currentAccount?.status === 'REJECTED';

  const mobileNavItems = [
    { id: 'dashboard', labelNe: 'ड्यासबोर्ड', labelEn: 'Dashboard', icon: LayoutDashboard },
    { id: 'billing', labelNe: 'बिलिङ', labelEn: 'Billing', icon: Receipt },
    { id: 'field_orders', labelNe: 'अर्डर', labelEn: 'Orders', icon: ClipboardList },
    { id: 'manufacturing', labelNe: 'उत्पादन', labelEn: 'WIP', icon: Factory },
    { id: 'vouchers', labelNe: 'असुली', labelEn: 'Collect', icon: Wallet },
    { id: 'ledger', labelNe: 'खाता', labelEn: 'Ledger', icon: BookOpenCheck },
    { id: 'inventory', labelNe: 'स्टक', labelEn: 'Stock', icon: Boxes },
    { id: 'logistics', labelNe: 'चलानी', labelEn: 'Dispatch', icon: Truck },
    { id: 'attendance', labelNe: 'हाजिरी', labelEn: 'Attendance', icon: CalendarCheck2 },
    { id: 'reports', labelNe: 'रिपोर्ट', labelEn: 'Reports', icon: FileSpreadsheet }
  ];

  const allowedMobileTabs = React.useMemo(() => {
    if (portalMode === 'STAFF_PORTAL' || currentRole === 'STAFF') {
      return ['billing', 'vouchers', 'attendance', 'logistics', 'inventory', 'ledger', 'dashboard', 'field_orders'];
    }
    return [
      'dashboard',
      'billing',
      'field_orders',
      'vouchers',
      'ledger',
      'inventory',
      'manufacturing',
      'reports',
      'vat_books',
      'accounting',
      'stock_costing',
      'audit_trail',
      'attendance',
      'excel_wizard',
      'settings'
    ];
  }, [currentRole, portalMode]);

  const filteredMobileNavItems = mobileNavItems.filter((item) =>
    allowedMobileTabs.includes(item.id)
  );

  // If not logged in, show clean Login Card with only Login ID (Mobile Number) & Password/PIN
  if (!currentAccount) {
    return <ImsDmsLoginCard />;
  }

  return (
    <div className={`min-h-screen flex ${activeTab === 'dashboard' ? 'ky-dark-shell text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* 1. Left Sidebar Navigation (Dashboard & Expandable Sub-Menus on the Left) */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        collapsed={isSidebarCollapsed}
        onToggleCollapse={toggleSidebarCollapsed}
      />

      {/* 2. Right Main Application Body */}
      <div className={`flex-1 flex flex-col min-w-0 ${isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-72'} transition-all duration-300`}>
        
        {/* Top Header Navbar */}
        <Navbar onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)} />

        {/* Dynamic Main Workspace Viewport */}
        <main className={`flex-1 w-full px-3 sm:px-6 py-4 sm:py-6 mx-auto ${activeTab === 'dashboard' ? 'max-w-[1760px]' : 'max-w-7xl'}`}>
          <AutoBackupManager />
          {isPendingApproval ? (
            /* Strict Admin Approval Gatekeeper overlay for pending accounts */
            <div className="my-4 sm:my-8 bg-white border-2 border-amber-300 rounded-3xl p-6 sm:p-10 shadow-2xl text-center space-y-6 max-w-2xl mx-auto">
              <div className="w-16 h-16 bg-amber-100 text-amber-700 rounded-2xl flex items-center justify-center mx-auto shadow-inner border border-amber-200">
                <ShieldAlert className="w-10 h-10 animate-pulse" />
              </div>

              <div className="space-y-2">
                <span className="inline-flex items-center gap-1.5 px-3.5 py-1 bg-amber-100 text-amber-900 rounded-full font-bold text-xs border border-amber-300">
                  <Clock className="w-4 h-4 text-amber-700" />
                  <span>{isNe ? '🔒 एडमिन स्वीकृति आवश्यक (Pending Admin Approval)' : '🔒 Pending Admin Approval'}</span>
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
                  {isNe
                    ? 'तपाईँको खाता दर्ता भएको छ तर मुख्य एडमिन (९८५५०१२३४५) को स्वीकृतिको पर्खाइमा छ।'
                    : 'Account Registered. Pending Approval by Super Admin (9855012345).'}
                </h2>
              </div>

              {currentAccount && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-left max-w-md mx-auto space-y-2 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <span className="text-slate-500 font-semibold">{isNe ? 'लग-इन आईडी (मोबाइल):' : 'Login ID (Mobile):'}</span>
                    <span className="font-mono font-bold text-emerald-800">📱 {currentAccount.mobileNumber}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-semibold">{isNe ? 'खाता स्थिति:' : 'Status:'}</span>
                    <span className="px-2 py-0.5 bg-amber-100 text-amber-900 font-bold rounded text-[11px] border border-amber-300">
                      {isNe ? 'पर्खाइमा (PENDING_APPROVAL)' : 'PENDING_APPROVAL'}
                    </span>
                  </div>
                </div>
              )}

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => {
                    setAuthModalTab('ADMIN_APPROVAL');
                    setIsAuthModalOpen(true);
                  }}
                  className="w-full sm:w-auto px-5 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isNe ? 'एडमिन स्वीकृति प्यानल खोल्नुहोस्' : 'Open Admin Approval Panel'}</span>
                </button>

                <button
                  onClick={() => {
                    setAuthModalTab('LOGIN');
                    setIsAuthModalOpen(true);
                  }}
                  className="w-full sm:w-auto px-4 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl shadow-sm transition flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>{isNe ? 'अर्को आईडी लग-इन गर्नुहोस्' : 'Login Other ID'}</span>
                </button>
              </div>
            </div>
          ) : isRejected ? (
            /* Rejected Gatekeeper Overlay */
            <div className="my-4 sm:my-8 bg-white border-2 border-rose-300 rounded-3xl p-6 sm:p-10 shadow-2xl text-center space-y-6 max-w-2xl mx-auto">
              <div className="w-16 h-16 bg-rose-100 text-rose-700 rounded-2xl flex items-center justify-center mx-auto shadow-inner border border-rose-200">
                <XCircle className="w-10 h-10 animate-bounce" />
              </div>

              <div className="space-y-2">
                <span className="inline-flex items-center gap-1.5 px-3.5 py-1 bg-rose-100 text-rose-900 rounded-full font-bold text-xs border border-rose-300">
                  <span>{isNe ? '❌ खाता अस्वीकृत (Account Rejected)' : '❌ Account Rejected'}</span>
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
                  {isNe
                    ? 'यो खाता मुख्य एडमिनबाट अस्वीकृत गरिएको छ।'
                    : 'This account has been rejected by the admin.'}
                </h2>
              </div>

              <div className="pt-2 flex justify-center">
                <button
                  onClick={() => {
                    setAuthModalTab('LOGIN');
                    setIsAuthModalOpen(true);
                  }}
                  className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl shadow-sm transition flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>{isNe ? 'अर्को आईडी लग-इन गर्नुहोस्' : 'Login Other ID'}</span>
                </button>
              </div>
            </div>
          ) : (
            <>
              {activeTab === 'dashboard' && (
                <DashboardScreen onViewInvoice={(id) => setViewingInvoiceId(id)} />
              )}
              {activeTab === 'billing' && <BillingScreen />}
              {activeTab === 'manufacturing' && <ManufacturingScreen />}
              {activeTab === 'field_orders' && <FieldOrdersScreen />}
              {activeTab === 'vouchers' && <VoucherScreen />}
              {activeTab === 'ledger' && <LedgerScreen />}
              {activeTab === 'inventory' && <InventoryScreen />}
              {activeTab === 'reports' && <ReportsScreen />}
              {activeTab === 'vat_books' && <VatBookScreen />}
              {activeTab === 'accounting' && <AccountingScreen />}
              {activeTab === 'stock_costing' && <StockCostingScreen />}
              {activeTab === 'audit_trail' && <AuditReportScreen initialSubTab="AUDIT_TRAIL" />}
              {activeTab === 'audit_report' && <AuditReportScreen initialSubTab="BOTH" />}
              {activeTab === 'attendance' && <AttendanceScreen />}
              {activeTab === 'logistics' && <LogisticsScreen />}
              {activeTab === 'excel_wizard' && <ExcelWizardScreen />}
              {activeTab === 'settings' && <SettingsScreen />}
            </>
          )}
        </main>

        {/* Global Floating '+' Quick Action Menu (Works on all screens, unobstructed by mobile bottom bar) */}
        {!isPendingApproval && !isRejected && (
          <div className="no-print fixed bottom-20 lg:bottom-6 right-5 z-50 flex flex-col items-end gap-2">
            {isQuickPlusOpen && (
              <div className="bg-white rounded-2xl shadow-2xl border-2 border-emerald-500/30 p-2.5 flex flex-col gap-1.5 w-60 mb-1 animate-fadeIn">
                <div className="px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-slate-400 border-b border-slate-100">
                  {isNe ? 'द्रुत कारोबार मेनु (+ Quick Actions)' : '+ Quick Transactions'}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('billing');
                    setBillingSubTab('SALES');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-emerald-50/70 hover:bg-emerald-600 text-slate-800 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '१. बिक्री बिल (Sales / POS)' : '1. Sales (POS)'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('billing');
                    setBillingSubTab('PURCHASE');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-blue-50/70 hover:bg-blue-600 text-slate-800 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '२. खरिद बिल (Purchase)' : '2. Purchase'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('billing');
                    setBillingSubTab('PAYMENT_IN');
                    setVoucherSubTab('COLLECTION');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-teal-50/70 hover:bg-teal-600 text-slate-800 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '३. भुक्तानी प्राप्त (Payment In)' : '3. Payment In'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('billing');
                    setBillingSubTab('PAYMENT_OUT');
                    setVoucherSubTab('PAYMENT');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-amber-50/70 hover:bg-amber-600 text-slate-800 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '४. भुक्तानी (Payment Out)' : '4. Payment Out'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('billing');
                    setBillingSubTab('SALES_RETURN');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-rose-50/70 hover:bg-rose-600 text-slate-800 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '५. बिक्री फिर्ता (Sales Return)' : '5. Sales Return'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('billing');
                    setBillingSubTab('PURCHASE_RETURN');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-purple-50/70 hover:bg-purple-600 text-slate-800 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '६. खरिद फिर्ता (Purchase Return)' : '6. Purchase Return'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('manufacturing');
                    setManufacturingSubTab('WIP_MACHINE');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-indigo-50/70 hover:bg-indigo-600 text-slate-800 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '७. उत्पादन (Production/WIP)' : '7. Production (WIP)'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('field_orders');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-teal-100/80 hover:bg-teal-700 text-teal-950 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '📋 फिल्ड अर्डर / कोटेशन' : '📋 Field Order / Quotation'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                <div className="border-t border-slate-100 my-0.5" />
                <button
                  type="button"
                  onClick={() => {
                    window.history.replaceState(null, '', '/?tab=attendance&workCat=TUNNEL_MAKING');
                    window.dispatchEvent(
                      new CustomEvent('ims-sub-nav', {
                        detail: { target: 'attendance', workCat: 'TUNNEL_MAKING', subTab: 'ATTENDANCE' }
                      })
                    );
                    setActiveTab('attendance');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-emerald-100/80 hover:bg-emerald-700 text-emerald-950 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '७. काम अनुसार हाजिरी (टनेल/प्लास्टिक/ट्याक्टर)' : '7. Work Attendance'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    window.history.replaceState(null, '', '/?tab=attendance&sheet=1');
                    window.dispatchEvent(
                      new CustomEvent('ims-sub-nav', {
                        detail: { target: 'attendance', openMonthlySheet: true }
                      })
                    );
                    setActiveTab('attendance');
                    setIsQuickPlusOpen(false);
                  }}
                  className="px-3.5 py-2.5 bg-amber-100/80 hover:bg-amber-600 text-amber-950 hover:text-white rounded-xl text-xs font-bold text-left transition cursor-pointer flex items-center justify-between"
                >
                  <span>{isNe ? '८. महिनाभरिको हाजिरी सिट प्रिन्ट' : '8. Monthly Attendance Print'}</span>
                  <span className="text-[10px] opacity-75">→</span>
                </button>
                {/* Removed Master Settings link as requested */}
              </div>
            )}

            <button
              type="button"
              onClick={() => setIsQuickPlusOpen((prev) => !prev)}
              title={isNe ? 'नयाँ कारोबार (+ Quick Action)' : '+ Quick Action'}
              className="w-14 h-14 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-full shadow-2xl border-2 border-white flex items-center justify-center transition cursor-pointer"
            >
              {isQuickPlusOpen ? <X className="w-7 h-7" /> : <Plus className="w-8 h-8 stroke-[2.5]" />}
            </button>
          </div>
        )}

        {/* Invoice View/Reprint Modal */}
        {selectedInvoice && (
          <InvoicePrintModal
            invoice={selectedInvoice}
            onClose={() => setViewingInvoiceId(null)}
            onEditInvoice={(id) => {
              setViewingInvoiceId(null);
              startEditInvoice(id);
            }}
            onCancelInvoice={(id) => {
              cancelInvoice(id);
              setViewingInvoiceId(null);
            }}
            onDeleteInvoice={(id) => {
              deleteInvoice(id);
              setViewingInvoiceId(null);
            }}
          />
        )}

        {/* Mobile Authentication & Admin Approval Modal */}
        <MobileAuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          initialTab={authModalTab}
        />

        {/* Bottom Status & Control Bar: Date Sync, Online Pill, Quick Bill, User Profile */}
        <BottomStatusBar />

        {/* Mobile Bottom Quick-Access Thumb Navigation */}
        <nav className="no-print lg:hidden sticky bottom-0 z-30 bg-white border-t border-slate-200 px-1 py-1 flex items-center justify-around shadow-lg">
          {filteredMobileNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center py-1 px-1.5 text-[10px] font-medium transition cursor-pointer ${
                  isActive ? 'text-emerald-700 font-bold' : 'text-slate-500'
                }`}
              >
                <Icon className="w-4 h-4 mb-0.5" />
                <span>{isNe ? item.labelNe : item.labelEn}</span>
              </button>
            );
          })}
        </nav>

        {/* Clean Desktop Footer */}
        <footer className="no-print border-t border-slate-200 bg-white py-3.5 px-4 sm:px-6 mt-auto">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-700">{isNe ? 'कृषियन्त्र ERP' : 'KrishiYantra ERP'}</span>
              <span>·</span>
              <span>नेपाल भ्याट ऐन २०५२ तथा IRD मापदण्ड अनुकूल</span>
              <span>·</span>
              <span className="font-mono text-[11px]">B.S. 2081/82</span>
            </div>

            <div className="flex items-center gap-3 text-[11px]">
              <span>Desktop & Mobile PWA</span>
              <span>·</span>
              <span>Offline-First Local Storage</span>
            </div>
          </div>
        </footer>

      </div>

    </div>
  );
};

export default function App() {
  return (
    <LoginGate>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </LoginGate>
  );
}
