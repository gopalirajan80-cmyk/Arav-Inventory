import { printPage } from '../utils/printHelper';
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Party, PartyType, CustomerCategory, PaymentMode, PartyTransaction, Invoice, PurchaseRecord } from '../types';
import { QRCodeSVG } from 'qrcode.react';
import { CategoryPieChart } from './CategoryPieChart';
import { BalanceConfirmationModal } from './BalanceConfirmationModal';
import { generateStandaloneHtmlReport, triggerDownloadFile } from '../utils/htmlExporter';
import {
  Users,
  BookOpenCheck,
  Search,
  Plus,
  Edit2,
  Trash2,
  Printer,
  Download,
  Share2,
  MessageCircle,
  Smartphone,
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  Building2,
  CheckCircle2,
  X,
  CreditCard,
  MapPin,
  Phone,
  FileText,
  DollarSign,
  TrendingUp,
  Filter,
  Check,
  Bell,
  Send,
  Copy,
  AlertCircle,
  Clock,
  QrCode,
  PieChart,
  Globe,
  FolderDown,
  Store,
  Landmark,
  HelpCircle,
  FileSpreadsheet,
  Upload
} from 'lucide-react';
import {
  parseExcelFile,
  parseExcelNumericValue,
  downloadCustomerImportTemplate
} from '../utils/excelEngine';
import {
  formatCurrency,
  getTodayBsString,
  getTodayAdString,
  toNepaliDigits
} from '../utils/nepaliCalendar';
import {
  shareViaWhatsApp,
  shareViaSms,
  copyMessageToClipboard,
  buildCustomerStatementMessage
} from '../utils/shareUtils';
import { exportReportToExcel, printOrDownloadReportPdf } from '../utils/pdfReportExporter';
import { PaperSizeToggle } from './PaperSizeToggle';

export const LedgerScreen: React.FC = () => {
  const {
    items,
    parties,
    saveParty,
    deleteParty,
    updatePartyBalance,
    invoices,
    purchases,
    partyTransactions,
    recordCustomerCollection,
    recordPartyPayment,
    bankAccounts,
    company,
    ledgerSubTab,
    setLedgerSubTab,
    setActiveTab,
    setBillingSubTab,
    importPartiesList,
    language
  } = useApp();

  const isNe = language === 'ne';
  const [toastMsg, setToastMsg] = useState('');
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 4000);
  };

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [partyTypeFilter, setPartyTypeFilter] = useState<'ALL' | 'CUSTOMER' | 'SUPPLIER'>('CUSTOMER');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | CustomerCategory>('ALL');
  const [balanceStatusFilter, setBalanceStatusFilter] = useState<'ALL' | 'DUE_ONLY' | 'ADVANCE_ONLY' | 'OVERDUE_REMINDER'>('ALL');

  // Selected Party for Detailed Ledger Statement View
  const [viewingPartyId, setViewingPartyId] = useState<string | null>(null);
  const [confirmationPartyId, setConfirmationPartyId] = useState<string | null>(null);

  // Payment Reminder Modal state
  const [reminderParty, setReminderParty] = useState<Party | null>(null);
  const [reminderMessageText, setReminderMessageText] = useState<string>('');

  // Dynamic Fonepay/NepalPay QR Modal state
  const [qrModalParty, setQrModalParty] = useState<Party | null>(null);
  const [qrAmount, setQrAmount] = useState<number>(0);
  const [qrType, setQrType] = useState<'FONEPAY' | 'NEPALPAY' | 'BANK'>('FONEPAY');
  const [qrBankId, setQrBankId] = useState<string>(bankAccounts[0]?.id || '');

  const handleOpenQrModal = (p: Party) => {
    setQrModalParty(p);
    setQrAmount(Math.abs(p.currentBalance ?? p.openingBalance));
    setQrType('FONEPAY');
    setQrBankId(bankAccounts[0]?.id || '');
  };

  const getDynamicQrPayload = (p: Party, amount: number, mode: 'FONEPAY' | 'NEPALPAY' | 'BANK', selectedBankId?: string) => {
    const bank = bankAccounts.find((b) => b.id === selectedBankId) || bankAccounts[0];
    const merchantName = company.name || 'KrishiYantra ERP';
    const accNo = bank?.accountNumber || company.panVatNo || '9800000000';
    const bankName = bank?.bankName || 'Nepal Bank';
    const cleanAmount = (amount || 0).toFixed(2);
    const remarks = `Due Payment - ${p.name.replace(/[^\w\s]/gi, '')}`;

    if (mode === 'FONEPAY') {
      return `fonepay://pay?merchant_name=${encodeURIComponent(merchantName)}&account_no=${accNo}&amount=${cleanAmount}&remarks=${encodeURIComponent(remarks)}&bank=${encodeURIComponent(bankName)}`;
    } else if (mode === 'NEPALPAY') {
      return `nepalpay://pay?merchant=${encodeURIComponent(merchantName)}&acc=${accNo}&amount=${cleanAmount}&ref=${encodeURIComponent(remarks)}`;
    } else {
      return `bank://${encodeURIComponent(bankName)}?account=${accNo}&holder=${encodeURIComponent(bank?.accountHolder || merchantName)}&amount=${cleanAmount}&ref=${encodeURIComponent(remarks)}`;
    }
  };

  // Add / Edit Party Modal state
  const [isPartyModalOpen, setIsPartyModalOpen] = useState(false);
  const [editingParty, setEditingParty] = useState<Party | null>(null);
  const [partyName, setPartyName] = useState('');
  const [partyType, setPartyType] = useState<PartyType>('CUSTOMER');
  const [partyCustomerCategory, setPartyCustomerCategory] = useState<CustomerCategory>('RETAIL');
  const [partyPhone, setPartyPhone] = useState('');
  const [partyAddress, setPartyAddress] = useState('');
  const [partyPan, setPartyPan] = useState('');
  const [partyOpeningBalance, setPartyOpeningBalance] = useState<number>(0);

  React.useEffect(() => {
    if (ledgerSubTab === 'ALL') {
      setPartyTypeFilter('ALL');
      setBalanceStatusFilter('ALL');
    } else if (ledgerSubTab === 'CUSTOMER') {
      setPartyTypeFilter('CUSTOMER');
      setBalanceStatusFilter('ALL');
    } else if (ledgerSubTab === 'SUPPLIER') {
      setPartyTypeFilter('SUPPLIER');
      setBalanceStatusFilter('ALL');
    } else if (ledgerSubTab === 'DUE_ONLY') {
      setPartyTypeFilter('ALL');
      setBalanceStatusFilter('DUE_ONLY');
    } else if (ledgerSubTab === 'ADD_PARTY') {
      setEditingParty(null);
      setPartyName('');
      setPartyPhone('');
      setPartyAddress('');
      setPartyPan('');
      setPartyOpeningBalance(0);
      setIsPartyModalOpen(true);
    }
  }, [ledgerSubTab]);

  // Quick Voucher Collection / Payment Modal state
  const [isVoucherModalOpen, setIsVoucherModalOpen] = useState(false);
  const [voucherParty, setVoucherParty] = useState<Party | null>(null);
  const [voucherType, setVoucherType] = useState<'COLLECTION' | 'PAYMENT'>('COLLECTION');
  const [voucherAmount, setVoucherAmount] = useState<number>(0);
  const [voucherMode, setVoucherMode] = useState<'CASH' | 'BANK'>('CASH');
  const [voucherBankId, setVoucherBankId] = useState<string>(bankAccounts[0]?.id || '');
  const [voucherRef, setVoucherRef] = useState<string>('');
  const [voucherNotes, setVoucherNotes] = useState<string>('');

  // Direct Customer Excel Upload Modal State (Name, Address, Due Amount, Pay Amount)
  const [isExcelUploadModalOpen, setIsExcelUploadModalOpen] = useState(false);
  const [excelFileName, setExcelFileName] = useState('');
  const [excelHeaders, setExcelHeaders] = useState<string[]>([]);
  const [excelRows, setExcelRows] = useState<any[][]>([]);
  const [excelCalcMode, setExcelCalcMode] = useState<'SUBTRACT_PAY' | 'DUE_IS_NET'>('SUBTRACT_PAY');
  const [excelColMap, setExcelColMap] = useState<{
    name: number;
    address: number;
    due: number;
    pay: number;
    phone: number;
    pan: number;
  }>({
    name: -1,
    address: -1,
    due: -1,
    pay: -1,
    phone: -1,
    pan: -1
  });

  const handleCustomerExcelFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setExcelFileName(file.name);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result as ArrayBuffer;
        const { headers, rows } = parseExcelFile(buffer);
        setExcelHeaders(headers);
        setExcelRows(rows);

        const detected = {
          name: -1,
          address: -1,
          due: -1,
          pay: -1,
          phone: -1,
          pan: -1
        };

        headers.forEach((h, idx) => {
          const lower = h.toLowerCase();
          if (
            detected.name === -1 &&
            (lower.includes('name') || lower.includes('customer') || lower.includes('party') || lower.includes('नाम') || lower.includes('ग्राहक'))
          ) {
            detected.name = idx;
          } else if (
            detected.address === -1 &&
            (lower.includes('address') || lower.includes('location') || lower.includes('ठेगाना') || lower.includes('स्थान') || lower.includes('ठाउँ'))
          ) {
            detected.address = idx;
          } else if (
            detected.pay === -1 &&
            (lower.includes('pay') || lower.includes('paid') || lower.includes('received') || lower.includes('भुक्तानी') || lower.includes('बुझाएको') || lower.includes('असुल') || lower.includes('तिरेको'))
          ) {
            detected.pay = idx;
          } else if (
            detected.due === -1 &&
            (lower.includes('due') || lower.includes('balance') || lower.includes('बाँकी') || lower.includes('बक्यौता') || lower.includes('उधारो') || lower.includes('रकम') || lower.includes('amount'))
          ) {
            detected.due = idx;
          } else if (
            detected.phone === -1 &&
            (lower.includes('phone') || lower.includes('mobile') || lower.includes('फोन') || lower.includes('सम्पर्क'))
          ) {
            detected.phone = idx;
          } else if (
            detected.pan === -1 &&
            (lower.includes('pan') || lower.includes('vat') || lower.includes('प्यान'))
          ) {
            detected.pan = idx;
          }
        });

        // Fallback if headers are simple 4 columns (Name, Address, Due, Pay)
        if (detected.name === -1 && headers.length >= 1) detected.name = 0;
        if (detected.address === -1 && headers.length >= 2) detected.address = 1;
        if (detected.due === -1 && headers.length >= 3) detected.due = 2;
        if (detected.pay === -1 && headers.length >= 4) detected.pay = 3;

        setExcelColMap(detected);
      } catch (err) {
        console.error(err);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const parsedExcelCustomers: Party[] = React.useMemo(() => {
    if (excelRows.length === 0 || excelColMap.name < 0) return [];
    const list: Party[] = [];
    excelRows.forEach((row, idx) => {
      const name = String(row[excelColMap.name] || '').trim();
      if (!name || name.toLowerCase().includes('total') || name.includes('जम्मा')) return;

      const address = excelColMap.address >= 0 ? String(row[excelColMap.address] || '').trim() : '';
      const phone = excelColMap.phone >= 0 ? String(row[excelColMap.phone] || '').trim() : '';
      const panNo = excelColMap.pan >= 0 ? String(row[excelColMap.pan] || '').trim() : '';
      const rawDue = excelColMap.due >= 0 ? parseExcelNumericValue(row[excelColMap.due]) : 0;
      const rawPay = excelColMap.pay >= 0 ? parseExcelNumericValue(row[excelColMap.pay]) : 0;

      const openingBalance = excelCalcMode === 'SUBTRACT_PAY' ? rawDue : rawDue + rawPay;
      const currentBalance = excelCalcMode === 'SUBTRACT_PAY' ? Math.max(0, rawDue - rawPay) : rawDue;

      list.push({
        id: `pty-xl-${Date.now()}-${idx}`,
        name,
        address: address || 'ठेगाना नखुलेको',
        phone,
        panNo,
        partyType: 'CUSTOMER',
        type: 'CUSTOMER',
        customerCategory: 'RETAIL',
        openingBalance,
        paidAmount: rawPay,
        currentBalance
      });
    });
    return list;
  }, [excelRows, excelColMap, excelCalcMode]);

  const handleConfirmExcelCustomerImport = () => {
    if (parsedExcelCustomers.length === 0) return;
    importPartiesList(parsedExcelCustomers);
    setIsExcelUploadModalOpen(false);
    setExcelFileName('');
    setExcelHeaders([]);
    setExcelRows([]);
  };

  // Selected party object
  const activeParty = parties.find((p) => p.id === viewingPartyId);

  // Export HTML Report Handler
  const handleDownloadOfflineHtmlReport = () => {
    const html = generateStandaloneHtmlReport({
      company,
      parties,
      items: items || [],
      invoices,
      purchases,
      partyTransactions,
      bankAccounts
    });
    triggerDownloadFile(html, `KrishiYantra_Offline_Report_${getTodayBsString()}.html`, 'text/html');
  };

  // Export Complete JSON Database Backup Handler
  const handleDownloadJsonBackup = () => {
    const backupObj = {
      exportDate: new Date().toISOString(),
      exportDateBs: getTodayBsString(),
      appName: 'KrishiYantra ERP',
      company,
      parties,
      items: items || [],
      invoices,
      purchases,
      partyTransactions,
      bankAccounts
    };
    triggerDownloadFile(
      JSON.stringify(backupObj, null, 2),
      `KrishiYantra_DB_Backup_${getTodayBsString()}.json`,
      'application/json'
    );
  };

  // Build default Payment Due Reminder message
  const generatePaymentReminderMessage = (p: Party): string => {
    const currentDue = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
    let msg = `*भुक्तानी ताकेता (Payment Due Reminder)*\n`;
    msg += `*${company.name}*\n`;
    if (company.phone) msg += `ठेगाना: ${company.address || ''} | फोन: ${company.phone}\n`;
    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `आदरणीय ग्राहक *${p.name}* ज्यू,\n\n`;
    msg += `तपाईंको हाम्रो फर्ममा कुल बाँकी बक्यौता रकम *${formatCurrency(currentDue, isNe)}* रहेको छ।\n\n`;
    msg += `कृपया उक्त रकम यथाशीघ्र भुक्तानी गरी सहयोग गरिदिनुहुन हार्दिक अनुरोध गर्दछौँ।\n`;

    if (bankAccounts && bankAccounts.length > 0) {
      const primaryBank = bankAccounts[0];
      msg += `\n*बैंक/FonePay खाता विवरण:*\n`;
      msg += `बैंक: ${primaryBank.bankName}\n`;
      msg += `खाता नं: *${primaryBank.accountNumber}*\n`;
      msg += `खातावाला: ${primaryBank.accountHolder}\n`;
      if (primaryBank.branch) msg += `शाखा: ${primaryBank.branch}\n`;
    }

    msg += `━━━━━━━━━━━━━━━━━━━━\n`;
    msg += `समयमै रकम भुक्तानी गरी सहयोग गरिदिनुहोला। धन्यवाद !\n`;
    msg += `_${company.name}_`;
    return msg;
  };

  // Open Payment Due Reminder Modal
  const handleOpenReminderModal = (p: Party) => {
    setReminderParty(p);
    setReminderMessageText(generatePaymentReminderMessage(p));
  };

  // Filter parties list based on search term, party type, category, balance status
  const filteredParties = parties.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.address && p.address.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.phone && p.phone.includes(searchTerm)) ||
      (p.panNo && p.panNo.includes(searchTerm));

    const matchesType =
      partyTypeFilter === 'ALL'
        ? true
        : partyTypeFilter === 'CUSTOMER'
        ? (p.partyType || p.type) === 'CUSTOMER' || !(p.partyType || p.type)
        : (p.partyType || p.type) === 'SUPPLIER';

    const matchesCategory =
      categoryFilter === 'ALL'
        ? true
        : (p.customerCategory || 'OTHER') === categoryFilter;

    const currentBal = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
    const matchesBalance =
      balanceStatusFilter === 'ALL'
        ? true
        : balanceStatusFilter === 'DUE_ONLY' || balanceStatusFilter === 'OVERDUE_REMINDER'
        ? currentBal > 0
        : currentBal < 0;

    return matchesSearch && matchesType && matchesCategory && matchesBalance;
  });

  // Overall Financial Summary Metrics
  const totalCustomerReceivable = parties
    .filter((p) => ((p.partyType || p.type) === 'CUSTOMER' || !(p.partyType || p.type)) && (p.currentBalance ?? p.openingBalance) > 0)
    .reduce((sum, p) => sum + (p.currentBalance ?? p.openingBalance), 0);

  const totalSupplierPayable = parties
    .filter((p) => (p.partyType || p.type) === 'SUPPLIER' && (p.currentBalance ?? p.openingBalance) > 0)
    .reduce((sum, p) => sum + (p.currentBalance ?? p.openingBalance), 0);

  const totalCustomerCount = parties.filter((p) => (p.partyType || p.type) === 'CUSTOMER' || !(p.partyType || p.type)).length;
  const totalSupplierCount = parties.filter((p) => (p.partyType || p.type) === 'SUPPLIER').length;

  // Open Add Party Modal
  const handleOpenAddParty = () => {
    setEditingParty(null);
    setPartyName('');
    setPartyType('CUSTOMER');
    setPartyCustomerCategory('RETAIL');
    setPartyPhone('');
    setPartyAddress('');
    setPartyPan('');
    setPartyOpeningBalance(0);
    setIsPartyModalOpen(true);
  };

  // Redirect Party Edit/Rename/Delete to Master Settings (मास्टर सेटिङबाट मात्र सच्याउने)
  const handleOpenEditParty = (p: Party) => {
    setViewingPartyId(null);
    setActiveTab('settings');
    setTimeout(() => {
      window.dispatchEvent(
        new CustomEvent('ims-sub-nav', {
          detail: { target: 'settings', settingsTab: 'CUSTOMERS', partyId: p.id }
        })
      );
    }, 60);
  };

  // Save Party (Add or Edit / Rename)
  const handleSaveParty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partyName.trim()) {
      showToast(isNe ? 'कृपया पार्टी/ग्राहकको नाम प्रविष्ट गर्नुहोस्।' : 'Please enter party name.');
      return;
    }

    const updatedParty: Party = {
      id: editingParty ? editingParty.id : `party-${Date.now()}`,
      name: partyName.trim(),
      partyType: partyType,
      type: partyType,
      customerCategory: partyType === 'CUSTOMER' ? partyCustomerCategory : undefined,
      phone: partyPhone.trim(),
      address: partyAddress.trim(),
      panNo: partyPan.trim(),
      openingBalance: partyOpeningBalance,
      currentBalance: editingParty
        ? (editingParty.currentBalance ?? editingParty.openingBalance) + (partyOpeningBalance - editingParty.openingBalance)
        : partyOpeningBalance
    };

    saveParty(updatedParty);
    setIsPartyModalOpen(false);
    showToast(
      isNe
        ? `पार्टी (${partyName}) सफलतापूर्वक सुरक्षित/रिनेम भयो!`
        : `Party (${partyName}) saved successfully!`
    );
  };

  // Open Voucher Modal for Quick Collection / Payment
  const handleOpenVoucherModal = (party: Party, defaultType?: 'COLLECTION' | 'PAYMENT') => {
    setVoucherParty(party);
    const pType = party.partyType || party.type;
    const calculatedType = defaultType
      ? defaultType
      : pType === 'SUPPLIER'
      ? 'PAYMENT'
      : 'COLLECTION';
    setVoucherType(calculatedType);
    setVoucherAmount(Math.abs(party.currentBalance ?? party.openingBalance));
    setVoucherMode('CASH');
    setVoucherBankId(bankAccounts[0]?.id || '');
    setVoucherRef('');
    setVoucherNotes('');
    setIsVoucherModalOpen(true);
  };

  // Submit Quick Voucher
  const handleSaveVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!voucherParty || voucherAmount <= 0) {
      showToast(isNe ? 'कृपया उपयुक्त रकम प्रविष्ट गर्नुहोस्।' : 'Please enter a valid amount.');
      return;
    }

    if (voucherType === 'COLLECTION') {
      recordCustomerCollection({
        partyId: voucherParty.id,
        amount: voucherAmount,
        paymentMode: voucherMode,
        bankAccountId: voucherMode === 'BANK' ? voucherBankId : undefined,
        referenceNo: voucherRef,
        notes: voucherNotes
      });
      showToast(isNe ? 'ग्राहक असुली भौचर सफलतापूर्वक दर्ता भयो!' : 'Collection voucher recorded!');
    } else {
      recordPartyPayment({
        partyId: voucherParty.id,
        amount: voucherAmount,
        paymentMode: voucherMode,
        bankAccountId: voucherMode === 'BANK' ? voucherBankId : undefined,
        referenceNo: voucherRef,
        notes: voucherNotes
      });
      showToast(isNe ? 'सप्लायर भुक्तानी भौचर सफलतापूर्वक दर्ता भयो!' : 'Payment voucher recorded!');
    }

    setIsVoucherModalOpen(false);
  };

  // Construct Chronological Ledger Statement for Active Viewing Party
  const getPartyLedgerTransactions = (party: Party) => {
    interface LedgerLine {
      id: string;
      dateBs: string;
      dateAd: string;
      typeLabel: string;
      refNo: string;
      debit: number; // बक्यौता बढाउने (Sales/Purchases)
      credit: number; // असुल/भुक्तानी भएको (Collections/Payments)
      runningBalance: number;
      notes?: string;
    }

    const lines: LedgerLine[] = [];
    const cleanName = party.name.trim().toLowerCase();

    // 1. Initial Opening Balance
    if (party.openingBalance !== 0) {
      lines.push({
        id: `opening-${party.id}`,
        dateBs: '2081-04-01',
        dateAd: '2024-07-16',
        typeLabel: isNe ? 'सुरुवाती बक्यौता (Opening Balance)' : 'Opening Balance',
        refNo: 'INIT-001',
        debit: party.openingBalance > 0 ? party.openingBalance : 0,
        credit: party.openingBalance < 0 ? Math.abs(party.openingBalance) : 0,
        runningBalance: party.openingBalance,
        notes: 'प्रणाली सुरु गर्दाको पुरानो बक्यौता मौज्दात'
      });
    }

    // 2. Invoices (Match by partyId OR customerName + address disambiguation)
    const cleanAddr = (party.address || '').trim().toLowerCase();
    const hasSameNamePeers = parties.filter((p) => p.name.trim().toLowerCase() === cleanName).length > 1;
    const partyInvoices = invoices.filter((inv) => {
      if (inv.status !== 'ACTIVE') return false;
      if (inv.partyId) return inv.partyId === party.id;
      if (inv.customerName.trim().toLowerCase() !== cleanName) return false;
      const invAddr = (inv.customerAddress || '').trim().toLowerCase();
      if (hasSameNamePeers || (cleanAddr && invAddr)) {
        return invAddr === cleanAddr;
      }
      return true;
    });
    partyInvoices.forEach((inv) => {
      const paidOnBill =
        inv.amountPaid !== undefined
          ? inv.amountPaid
          : inv.paymentMode === 'CREDIT'
          ? 0
          : inv.grandTotal;
      lines.push({
        id: inv.id,
        dateBs: inv.dateBs,
        dateAd: inv.dateAd,
        typeLabel: isNe ? `बिक्री बिल (${inv.billType})` : `Sales Invoice (${inv.billType})`,
        refNo: inv.invoiceNo,
        debit: inv.grandTotal,
        credit: paidOnBill,
        runningBalance: 0,
        notes: inv.notes || `बिक्री सामान: ${inv.items.length} वटा (${inv.paymentMode})`
      });
    });

    // 3. Purchases (Match by supplierName)
    const partyPurchases = purchases.filter(
      (pur) => pur.supplierName.trim().toLowerCase() === cleanName
    );
    partyPurchases.forEach((pur) => {
      const alreadyHasPaymentTxn = partyTransactions.some(
        (tx) => tx.referenceNo === pur.purchaseBillNo
      );
      const immediateCredit =
        pur.paymentMode === 'CREDIT' || alreadyHasPaymentTxn ? 0 : pur.grandTotal;
      lines.push({
        id: pur.id,
        dateBs: pur.dateBs,
        dateAd: pur.dateAd,
        typeLabel: isNe ? 'सामान खरिद बिल (Purchase)' : 'Purchase Record',
        refNo: pur.purchaseBillNo || pur.id.slice(-6),
        debit: pur.grandTotal,
        credit: immediateCredit,
        runningBalance: 0,
        notes: `खरिद विवरण: ${pur.itemsSummary}`
      });
    });

    // 4. Party Transactions (Collections & Payments Vouchers)
    const partyTxns = partyTransactions.filter((tx) => {
      // partyId कुनै पार्टीसँग मेल खाएमात्र त्यसैबाट छुट्याउने; पुराना/गलत id भए नाम (+ठेगाना) बाट
      if (tx.partyId && parties.some((p) => p.id === tx.partyId)) return tx.partyId === party.id;
      if (tx.partyName.trim().toLowerCase() !== cleanName) return false;
      const txAddr = (tx.partyAddress || '').trim().toLowerCase();
      if (hasSameNamePeers || (cleanAddr && txAddr)) {
        return txAddr === cleanAddr;
      }
      return true;
    });
    partyTxns.forEach((tx) => {
      const isCollection = tx.type === 'COLLECTION_FROM_CUSTOMER';
      lines.push({
        id: tx.id,
        dateBs: tx.dateBs,
        dateAd: tx.dateAd,
        typeLabel: isCollection
          ? (isNe ? 'नगद/बैंक असुली (Receipt)' : 'Customer Collection')
          : (isNe ? 'सप्लायर भुक्तानी (Payment)' : 'Supplier Payment'),
        refNo: tx.referenceNo || tx.id.slice(-6),
        debit: 0,
        credit: tx.amount,
        runningBalance: 0,
        notes: tx.notes
      });
    });

    // Sort chronologically by date
    lines.sort((a, b) => a.dateBs.localeCompare(b.dateBs));

    // Calculate Running Balance
    let accum = 0;
    lines.forEach((line) => {
      accum += line.debit - line.credit;
      line.runningBalance = accum;
    });

    return lines;
  };

  // Export Party Statement as CSV
  const handleExportPartyLedgerCsv = (party: Party) => {
    const lines = getPartyLedgerTransactions(party);
    let csvContent = 'Date (BS),Date (AD),Transaction Type,Ref No,Debit (Rs),Credit (Rs),Running Balance (Rs),Notes\n';

    lines.forEach((l) => {
      csvContent += `"${l.dateBs}","${l.dateAd}","${l.typeLabel}","${l.refNo}",${l.debit},${l.credit},${l.runningBalance},"${l.notes || ''}"\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Ledger_Statement_${party.name.replace(/\s+/g, '_')}_${getTodayBsString()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-16 max-w-7xl mx-auto">
      
      {/* Page Title & Action Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <BookOpenCheck className="w-6 h-6 text-emerald-700" />
            <span>{isNe ? 'ग्राहक तथा सप्लायर खाता (Party Ledger)' : 'Customer & Supplier Ledger'}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {isNe
              ? 'प्रत्येक ग्राहक तथा आपूर्तिकर्ताको सुरुवाती बक्यौता, दैनिक खरिद-बिक्री, असुली तथा भुक्तानी हिसाब'
              : 'Track individual customer & supplier balances, opening dues, and full statement history'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
          <button
            onClick={() => setIsExcelUploadModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-300" />
            <span>{isNe ? '📥 ग्राहक Excel अपलोड' : '📥 Upload Excel'}</span>
          </button>

          <button
            onClick={() =>
              exportReportToExcel({
                title: 'ग्राहक तथा सप्लायर लेजर विवरण (Party Ledger Report)',
                headers: ['नाम (Party)', 'प्रकार', 'ठेगाना', 'फोन', 'PAN नं.', 'सुरुवाती बक्यौता', 'भुक्तानी/असुली', 'हालको खुद बाँकी'],
                rows: filteredParties.map((p) => [
                  p.name,
                  p.partyType || p.type || 'CUSTOMER',
                  p.address || '-',
                  p.phone || '-',
                  p.panNo || '-',
                  p.openingBalance || 0,
                  p.paidAmount || 0,
                  p.currentBalance ?? p.openingBalance
                ]),
                company,
                fileName: 'Party_Ledger_Report'
              })
            }
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{isNe ? 'Excel डाउनलोड' : 'Excel Export'}</span>
          </button>

          <PaperSizeToggle />
          <button
            onClick={() =>
              printOrDownloadReportPdf(
                {
                  title: 'ग्राहक तथा सप्लायर लेजर विवरण (Party Ledger Report)',
                  headers: ['नाम (Party)', 'प्रकार', 'ठेगाना', 'फोन', 'PAN नं.', 'सुरुवाती बक्यौता', 'भुक्तानी/असुली', 'हालको खुद बाँकी'],
                  rows: filteredParties.map((p) => [
                    p.name,
                    p.partyType || p.type || 'CUSTOMER',
                    p.address || '-',
                    p.phone || '-',
                    p.panNo || '-',
                    p.openingBalance || 0,
                    p.paidAmount || 0,
                    p.currentBalance ?? p.openingBalance
                  ]),
                  summaryCards: [
                    { label: 'कुल ग्राहक लिन बाँकी', value: formatCurrency(totalCustomerReceivable, isNe) },
                    { label: 'कुल सप्लायर तिर्न बाँकी', value: formatCurrency(totalSupplierPayable, isNe) }
                  ],
                  company,
                  fileName: 'Party_Ledger_Report'
                },
                'DOWNLOAD_PDF'
              )
            }
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
          >
            <Printer className="w-4 h-4 text-amber-300" />
            <span>{isNe ? 'PDF प्रिन्ट / सेभ' : 'PDF Print / Save'}</span>
          </button>

          <button
            onClick={handleOpenAddParty}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{isNe ? '+ नयाँ पार्टी थप्नुहोस्' : '+ Add Party'}</span>
          </button>
        </div>
      </div>

      {toastMsg && (
        <div className="bg-emerald-900 text-white px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-2 shadow-md">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Financial Summary Metrics Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {/* Total Customer Receivable */}
        <div className="bg-emerald-900 text-white p-4 sm:p-5 rounded-2xl shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-emerald-200 text-xs font-medium mb-1">
            <span className="flex items-center gap-1.5">
              <Users className="w-4 h-4 text-emerald-300" />
              <span>{isNe ? 'कुल ग्राहक लिन बाँकी (Receivables):' : 'Total Customer Receivable:'}</span>
            </span>
            <span className="font-mono text-[11px] bg-emerald-800 px-2 py-0.5 rounded text-emerald-200 font-bold">
              {toNepaliDigits(totalCustomerCount)} {isNe ? 'जना' : 'parties'}
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-white mt-1">
            {formatCurrency(totalCustomerReceivable, isNe)}
          </div>
          <p className="text-[11px] text-emerald-300 mt-2 flex items-center gap-1">
            <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-300" />
            <span>{isNe ? 'ग्राहकहरूबाट बजारबाट असुल गर्नुपर्ने कुल बक्यौता' : 'Total due amount to collect from customers'}</span>
          </p>
        </div>

        {/* Total Supplier Payable */}
        <div className="bg-rose-900 text-white p-4 sm:p-5 rounded-2xl shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-rose-200 text-xs font-medium mb-1">
            <span className="flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-rose-300" />
              <span>{isNe ? 'कुल सप्लायर दिन बाँकी (Payables):' : 'Total Supplier Payable:'}</span>
            </span>
            <span className="font-mono text-[11px] bg-rose-800 px-2 py-0.5 rounded text-rose-200 font-bold">
              {toNepaliDigits(totalSupplierCount)} {isNe ? 'जना' : 'suppliers'}
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-white mt-1">
            {formatCurrency(totalSupplierPayable, isNe)}
          </div>
          <p className="text-[11px] text-rose-300 mt-2 flex items-center gap-1">
            <ArrowUpRight className="w-3.5 h-3.5 text-rose-300" />
            <span>{isNe ? 'आपूर्तिकर्ताहरूलाई बुझाउनुपर्ने साहुको बाँकी रकम' : 'Total amount payable to suppliers/vendors'}</span>
          </p>
        </div>

        {/* Net Outstanding Balance */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 rounded-2xl shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-300 text-xs font-medium mb-1">
            <span className="flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <span>{isNe ? 'खुद खुद बाँकी मौज्दात (Net Dues Balance):' : 'Net Dues Balance:'}</span>
            </span>
            <span className="font-mono text-[11px] bg-slate-800 px-2 py-0.5 rounded text-amber-300 font-bold">
              {isNe ? 'खुद खाता' : 'Net'}
            </span>
          </div>
          <div className={`text-2xl sm:text-3xl font-black font-mono tracking-tight mt-1 ${
            totalCustomerReceivable - totalSupplierPayable >= 0 ? 'text-emerald-400' : 'text-rose-400'
          }`}>
            {formatCurrency(totalCustomerReceivable - totalSupplierPayable, isNe)}
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            {isNe ? '(ग्राहकबाट लिन बाँकी - सप्लायरलाई दिन बाँकी)' : '(Total Customer Due - Total Supplier Due)'}
          </p>
        </div>
      </div>

      {/* D3 Pie Chart Visualization */}
      <CategoryPieChart parties={parties} isNe={isNe} />

      {/* Main Filter & Search Control Panel */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          
          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder={isNe ? 'ग्राहकको नाम, ठेगाना, फोन वा प्यानले खोज्नुहोस्...' : 'Search by party name, phone, PAN...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filter Pills / Tabs */}
          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto text-xs font-semibold">
            {/* Party Type Filter */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => setPartyTypeFilter('ALL')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  partyTypeFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isNe ? 'सबै' : 'All'}
              </button>
              <button
                onClick={() => setPartyTypeFilter('CUSTOMER')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  partyTypeFilter === 'CUSTOMER' ? 'bg-emerald-700 text-white shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isNe ? 'ग्राहक' : 'Customers'}
              </button>
              <button
                onClick={() => setPartyTypeFilter('SUPPLIER')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  partyTypeFilter === 'SUPPLIER' ? 'bg-rose-700 text-white shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isNe ? 'सप्लायर' : 'Suppliers'}
              </button>
            </div>

            {/* Customer Category Filter Dropdown */}
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value as any)}
              className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
            >
              <option value="ALL">{isNe ? 'सबै वर्ग (Categories)' : 'All Categories'}</option>
              <option value="RETAIL">🏪 {isNe ? 'खुद्रा (Retail)' : 'Retail'}</option>
              <option value="WHOLESALE">🏢 {isNe ? 'थोक (Wholesale)' : 'Wholesale'}</option>
              <option value="GOVERNMENT">🏛️ {isNe ? 'सरकारी (Government)' : 'Government'}</option>
              <option value="OTHER">❓ {isNe ? 'अन्य (Other)' : 'Other'}</option>
            </select>

            {/* Balance Status Filter */}
            <select
              value={balanceStatusFilter}
              onChange={(e) => setBalanceStatusFilter(e.target.value as any)}
              className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
            >
              <option value="ALL">{isNe ? 'सबै मौज्दात' : 'All Balances'}</option>
              <option value="OVERDUE_REMINDER">🔔 {isNe ? 'ताकेता बाँकी' : 'Overdue Reminders'}</option>
              <option value="DUE_ONLY">{isNe ? 'लिन/दिन बाँकी (> 0)' : 'Dues Only (> 0)'}</option>
              <option value="ADVANCE_ONLY">{isNe ? 'अग्रिम (< 0)' : 'Advances (< 0)'}</option>
            </select>
          </div>

        </div>
      </div>

      {/* Main Ledger Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-900 text-white font-bold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">पार्टीको प्रकार</th>
                <th className="py-3 px-4">ग्राहक / सप्लायरको नाम</th>
                <th className="py-3 px-4">ठेगाना तथा सम्पर्क</th>
                <th className="py-3 px-4 text-right">कुल बक्यौता (Due Amount)</th>
                <th className="py-3 px-4 text-right">बुझाएको रकम (Pay Amount)</th>
                <th className="py-3 px-4 text-right">हालको खुद बाँकी (Net Due)</th>
                <th className="py-3 px-4 text-center">कार्य तथा भौचर (Actions)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredParties.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500 space-y-2">
                    <BookOpenCheck className="w-10 h-10 text-slate-300 mx-auto" />
                    <p className="font-semibold text-sm">
                      {isNe ? 'कुनै पनि खाता भेटिएन।' : 'No party ledger records found.'}
                    </p>
                    <p className="text-xs text-slate-400">
                      {isNe ? 'माथि "📥 ग्राहक Excel अपलोड" वा "+ नयाँ पार्टी थप्नुहोस्" बटन प्रयोग गर्नुहोस्।' : 'Click "+ Add New Party" or Upload Excel above.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredParties.map((p) => {
                  const currentBal = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
                  const paidFromTxns = partyTransactions
                    .filter((tx) => tx.partyId === p.id)
                    .reduce((s, tx) => s + tx.amount, 0);
                  const displayPaidAmount = paidFromTxns > 0 ? paidFromTxns : (p.paidAmount || 0);
                  const isSupplier = (p.partyType || p.type) === 'SUPPLIER';

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition">
                      
                      {/* Party Type Tag */}
                      <td className="py-3.5 px-4 font-semibold">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[10px] font-bold ${
                          isSupplier
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        }`}>
                          {isSupplier ? <Building2 className="w-3 h-3" /> : <Users className="w-3 h-3" />}
                          <span>{isSupplier ? (isNe ? 'सप्लायर' : 'Supplier') : (isNe ? 'ग्राहक' : 'Customer')}</span>
                        </span>
                      </td>

                      {/* Party Name, Category & PAN */}
                      <td className="py-3.5 px-4 space-y-1">
                        <div className="font-bold text-slate-900 text-sm flex items-center gap-1.5 flex-wrap">
                          <span>{p.name}</span>
                          {!isSupplier && (
                            <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded ${
                              p.customerCategory === 'RETAIL'
                                ? 'bg-emerald-100 text-emerald-800'
                                : p.customerCategory === 'WHOLESALE'
                                ? 'bg-blue-100 text-blue-800'
                                : p.customerCategory === 'GOVERNMENT'
                                ? 'bg-purple-100 text-purple-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}>
                              {p.customerCategory === 'RETAIL' ? (isNe ? 'खुद्रा' : 'Retail') :
                               p.customerCategory === 'WHOLESALE' ? (isNe ? 'थोक' : 'Wholesale') :
                               p.customerCategory === 'GOVERNMENT' ? (isNe ? 'सरकारी' : 'Govt') :
                               (isNe ? 'अन्य' : 'Other')}
                            </span>
                          )}
                        </div>
                        {p.panNo && (
                          <span className="text-[10px] font-mono text-slate-500 block">
                            PAN: {p.panNo}
                          </span>
                        )}
                      </td>

                      {/* Address & Phone */}
                      <td className="py-3.5 px-4 text-slate-600 space-y-0.5">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          <span>{p.address || '-'}</span>
                        </div>
                        <div className="flex items-center gap-1 font-mono text-[11px] text-slate-700">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{p.phone || '-'}</span>
                        </div>
                      </td>

                      {/* Initial / Total Due Amount */}
                      <td className="py-3.5 px-4 text-right font-mono font-semibold text-slate-700">
                        {formatCurrency(p.openingBalance || 0, isNe)}
                      </td>

                      {/* Paid / Received Amount (Pay Amount) */}
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-blue-700">
                        {displayPaidAmount > 0 ? formatCurrency(displayPaidAmount, isNe) : '-'}
                      </td>

                      {/* Current Net Balance */}
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-sm">
                        <span className={currentBal > 0 ? (isSupplier ? 'text-rose-700' : 'text-emerald-700') : currentBal < 0 ? 'text-blue-700' : 'text-slate-400'}>
                          {formatCurrency(currentBal, isNe)}
                        </span>
                        <span className="text-[10px] block font-sans font-normal text-slate-400">
                          {currentBal > 0
                            ? (isSupplier ? (isNe ? 'दिन बाँकी' : 'Payable') : (isNe ? 'लिन बाँकी' : 'Receivable'))
                            : currentBal < 0
                            ? (isNe ? 'अग्रिम जमा (Advance)' : 'Advance')
                            : (isNe ? 'बराबर (Zero)' : 'Zero')}
                        </span>
                        {currentBal > 0 && !isSupplier && (
                          <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-900 border border-amber-300 font-bold px-1.5 py-0.5 rounded text-[10px] mt-1">
                            <AlertCircle className="w-3 h-3 text-amber-700" />
                            <span>{isNe ? 'ताकेता बाँकी' : 'Overdue'}</span>
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5 flex-wrap">
                          {/* Payment Due Reminder Button */}
                          {currentBal > 0 && (
                            <>
                              <button
                                onClick={() => handleOpenQrModal(p)}
                                className="px-2.5 py-1.5 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-[11px] font-semibold transition cursor-pointer flex items-center gap-1 shadow-xs"
                                title={isNe ? 'Fonepay / NepalPay QR कोड सिर्जना गर्नुहोस्' : 'Dynamic Fonepay/NepalPay QR'}
                              >
                                <QrCode className="w-3.5 h-3.5" />
                                <span>{isNe ? 'QR पे' : 'QR Pay'}</span>
                              </button>

                              <button
                                onClick={() => handleOpenReminderModal(p)}
                                className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[11px] font-semibold transition cursor-pointer flex items-center gap-1 shadow-xs"
                                title={isNe ? 'ताकेता (SMS/WhatsApp) पठाउनुहोस्' : 'Send Payment Reminder'}
                              >
                                <Bell className="w-3.5 h-3.5" />
                                <span>{isNe ? 'ताकेता' : 'Reminder'}</span>
                              </button>
                            </>
                          )}

                          {/* View Ledger Statement */}
                          <button
                            onClick={() => setViewingPartyId(p.id)}
                            className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-[11px] font-semibold transition cursor-pointer flex items-center gap-1"
                          >
                            <FileText className="w-3.5 h-3.5 text-emerald-400" />
                            <span>{isNe ? 'लेजर हेर्नुहोस्' : 'Statement'}</span>
                          </button>

                          {/* Quick Collect / Pay */}
                          <button
                            onClick={() => handleOpenVoucherModal(p)}
                            className={`px-2.5 py-1.5 text-white rounded-lg text-[11px] font-semibold transition cursor-pointer flex items-center gap-1 ${
                              isSupplier ? 'bg-rose-700 hover:bg-rose-800' : 'bg-emerald-700 hover:bg-emerald-800'
                            }`}
                          >
                            <Wallet className="w-3.5 h-3.5" />
                            <span>{isSupplier ? (isNe ? 'भुक्तानी' : 'Pay') : (isNe ? 'असुली' : 'Collect')}</span>
                          </button>

                          {/* Edit / Rename / Delete strictly via Master Settings */}
                          <button
                            onClick={() => handleOpenEditParty(p)}
                            className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 rounded-lg transition cursor-pointer flex items-center gap-1 text-[10px] font-bold"
                            title={isNe ? 'मास्टर सेटिङबाट मात्र सच्याउने / रिनेम / मेटाउने' : 'Edit / Rename / Delete in Master Settings'}
                          >
                            <Edit2 className="w-3.5 h-3.5 text-indigo-700" />
                            <span>{isNe ? 'मास्टर सेटिङबाट सच्याउने' : 'Master Edit'}</span>
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: DETAILED LEDGER STATEMENT VIEW (लेजर खाता विवरण)                */}
      {/* ========================================================================= */}
      {activeParty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
            
            {/* Modal Header Banner */}
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white shrink-0">
              <div className="flex items-center gap-2.5">
                <BookOpenCheck className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>{activeParty.name}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                      (activeParty.partyType || activeParty.type) === 'SUPPLIER' ? 'bg-rose-500/30 text-rose-300' : 'bg-emerald-500/30 text-emerald-300'
                    }`}>
                      {(activeParty.partyType || activeParty.type) === 'SUPPLIER' ? 'सप्लायर खाता' : 'ग्राहक खाता'}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-300">
                    {activeParty.address ? `${activeParty.address} · ` : ''}
                    {activeParty.phone ? `फोन: ${activeParty.phone}` : ''}
                    {activeParty.panNo ? ` · PAN: ${activeParty.panNo}` : ''}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  onClick={() => handleOpenEditParty(activeParty)}
                  className="px-2.5 py-1.5 bg-indigo-800 hover:bg-indigo-700 text-amber-300 text-xs font-semibold rounded-lg transition flex items-center gap-1 cursor-pointer border border-indigo-600"
                  title="Edit / Rename / Delete in Master Settings"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{isNe ? '⚙️ मास्टर सेटिङबाट सच्याउने' : '⚙️ Master Edit'}</span>
                </button>

                <button
                  onClick={() => handleOpenQrModal(activeParty)}
                  className="px-3 py-1.5 bg-purple-700 hover:bg-purple-800 text-white text-xs font-semibold rounded-lg transition flex items-center gap-1 cursor-pointer shadow-xs"
                  title="Generate Dynamic Fonepay/NepalPay QR"
                >
                  <QrCode className="w-3.5 h-3.5 text-amber-300" />
                  <span className="hidden sm:inline">{isNe ? 'QR पे' : 'QR Pay'}</span>
                </button>

                <button
                  onClick={() => {
                    const lines = getPartyLedgerTransactions(activeParty);
                    exportReportToExcel({
                      title: `पार्टी लेजर स्टेटमेन्ट - ${activeParty.name}`,
                      subtitle: `ठेगाना: ${activeParty.address || '-'} | फोन: ${activeParty.phone || '-'} | PAN: ${activeParty.panNo || '-'}`,
                      headers: ['मिति (B.S.)', 'कारोबार विवरण', 'बिल / भौचर नं.', 'डेबिट (+)', 'क्रेडिट (-)', 'खुद बाँकी मौज्दात'],
                      rows: lines.map((l) => [l.dateBs, l.typeLabel, l.refNo, l.debit, l.credit, l.runningBalance]),
                      company,
                      fileName: `Party_Statement_${activeParty.name}`
                    });
                  }}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg transition flex items-center gap-1 cursor-pointer"
                  title="Excel Export"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Excel</span>
                </button>

                <button
                  onClick={() => {
                    const lines = getPartyLedgerTransactions(activeParty);
                    printOrDownloadReportPdf(
                      {
                        title: `पार्टी लेजर स्टेटमेन्ट - ${activeParty.name}`,
                        subtitle: `ठेगाना: ${activeParty.address || '-'} | फोन: ${activeParty.phone || '-'} | PAN: ${activeParty.panNo || '-'}`,
                        headers: ['मिति (B.S.)', 'कारोबार विवरण', 'बिल / भौचर नं.', 'डेबिट (+)', 'क्रेडिट (-)', 'खुद बाँकी मौज्दात'],
                        rows: lines.map((l) => [l.dateBs, l.typeLabel, l.refNo, l.debit, l.credit, l.runningBalance]),
                        summaryCards: [
                          { label: 'सुरुवाती बक्यौता', value: formatCurrency(activeParty.openingBalance || 0, isNe) },
                          { label: 'हालको खुद बाँकी', value: formatCurrency(activeParty.currentBalance ?? activeParty.openingBalance, isNe) }
                        ],
                        company,
                        fileName: `Party_Statement_${activeParty.name}`
                      },
                      'DOWNLOAD_PDF'
                    );
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden sm:inline">{isNe ? 'PDF प्रिन्ट' : 'PDF Print'}</span>
                </button>

                <button
                  onClick={() => setConfirmationPartyId(activeParty.id)}
                  className="px-3 py-1.5 bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold rounded-lg transition flex items-center gap-1 cursor-pointer shadow-xs"
                  title="Balance / VAT Confirmation Letter"
                >
                  <FileText className="w-3.5 h-3.5 text-teal-200" />
                  <span className="hidden sm:inline">{isNe ? 'कन्फर्मेसन पत्र' : 'Confirmation Letter'}</span>
                </button>

                {confirmationPartyId === activeParty.id && (
                  <BalanceConfirmationModal
                    party={activeParty}
                    onClose={() => setConfirmationPartyId(null)}
                  />
                )}

                <button
                  onClick={() => setViewingPartyId(null)}
                  className="text-slate-400 hover:text-white p-1 cursor-pointer ml-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Statement Summary Ribbon */}
            <div className="bg-slate-100 px-5 py-3 border-b border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs shrink-0">
              <div>
                <span className="text-[10px] text-slate-500 font-semibold block">{isNe ? 'सुरुवाती बक्यौता:' : 'Opening Due:'}</span>
                <span className="font-mono font-bold text-slate-800">
                  {formatCurrency(activeParty.openingBalance || 0, isNe)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 font-semibold block">{isNe ? 'हालको खुद बाँकी:' : 'Current Balance:'}</span>
                <span className={`font-mono font-bold ${
                  (activeParty.currentBalance ?? activeParty.openingBalance) > 0 ? 'text-rose-700' : 'text-emerald-700'
                }`}>
                  {formatCurrency(activeParty.currentBalance ?? activeParty.openingBalance, isNe)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 font-semibold block">{isNe ? 'मोबाइल शेयर:' : 'Share Statement:'}</span>
                <div className="flex items-center gap-1 mt-0.5">
                  <button
                    onClick={() => shareViaWhatsApp(activeParty.phone || '', buildCustomerStatementMessage(activeParty, company))}
                    className="p-1 bg-emerald-600 text-white rounded hover:bg-emerald-700 cursor-pointer text-[10px] font-bold flex items-center gap-1 px-1.5"
                  >
                    <MessageCircle className="w-3 h-3" />
                    <span>WhatsApp</span>
                  </button>
                  <button
                    onClick={() => shareViaSms(activeParty.phone || '', buildCustomerStatementMessage(activeParty, company))}
                    className="p-1 bg-blue-600 text-white rounded hover:bg-blue-700 cursor-pointer text-[10px] font-bold flex items-center gap-1 px-1.5"
                  >
                    <Smartphone className="w-3 h-3" />
                    <span>SMS</span>
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-end gap-1.5 flex-wrap">
                <button
                  onClick={() => {
                    updatePartyBalance(activeParty.id, 5000);
                    showToast(`${activeParty.name} को खातामा +रु. ५,००० बक्यौता थपियो!`);
                  }}
                  className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-xs"
                >
                  <span>+ उधारो थप्ने</span>
                </button>
                <button
                  onClick={() => {
                    const isSupp = (activeParty.partyType || activeParty.type) === 'SUPPLIER';
                    setViewingPartyId(null);
                    setBillingSubTab(isSupp ? 'PURCHASE' : 'SALES');
                    setActiveTab('billing');
                  }}
                  className="px-2.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-xs"
                >
                  <span>🧾 नयाँ बिल</span>
                </button>
                <button
                  onClick={() => handleOpenVoucherModal(activeParty)}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{(activeParty.partyType || activeParty.type) === 'SUPPLIER' ? (isNe ? '+ भुक्तानी' : '+ Payment') : (isNe ? '+ असुली' : '+ Collect')}</span>
                </button>
              </div>
            </div>

            {/* Chronological Statement Table */}
            <div className="p-5 overflow-y-auto flex-1 space-y-4">
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-800 text-slate-200 font-bold uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3">मिति (B.S. / A.D.)</th>
                      <th className="py-2.5 px-3">कारोबार विवरण (Type)</th>
                      <th className="py-2.5 px-3">बिल / भौचर नं.</th>
                      <th className="py-2.5 px-3 text-right text-rose-300">डेबिट / थप रकम (+)</th>
                      <th className="py-2.5 px-3 text-right text-emerald-300">क्रेडिट / असुल (-)</th>
                      <th className="py-2.5 px-3 text-right">खुद बाँकी मौज्दात</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {getPartyLedgerTransactions(activeParty).map((line) => (
                      <tr key={line.id} className="hover:bg-slate-50 transition">
                        <td className="py-2.5 px-3 text-slate-600 whitespace-nowrap">
                          <span className="font-bold text-slate-900 block">{line.dateBs}</span>
                          <span className="text-[10px] text-slate-400 block">{line.dateAd}</span>
                        </td>
                        <td className="py-2.5 px-3 font-sans">
                          <span className="font-bold text-slate-800 block">{line.typeLabel}</span>
                          {line.notes && <span className="text-[10px] text-slate-500 block">{line.notes}</span>}
                        </td>
                        <td className="py-2.5 px-3 font-bold text-slate-700">{line.refNo}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-rose-700">
                          {line.debit > 0 ? formatCurrency(line.debit, isNe) : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-emerald-700">
                          {line.credit > 0 ? formatCurrency(line.credit, isNe) : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-black text-slate-900">
                          {formatCurrency(line.runningBalance, isNe)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex justify-end shrink-0">
              <button
                onClick={() => setViewingPartyId(null)}
                className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl transition"
              >
                {isNe ? 'बन्द गर्नुहोस्' : 'Close'}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: ADD / EDIT PARTY & OPENING DUES (पार्टी/सुरुवाती बक्यौता)           */}
      {/* ========================================================================= */}
      {isPartyModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>
                  {editingParty
                    ? (isNe ? 'ग्राहक / सप्लायर विवरण सम्पादन' : 'Edit Party & Opening Balance')
                    : (isNe ? 'नयाँ ग्राहक / सप्लायर थप्नुहोस्' : 'Add Customer / Supplier')}
                </span>
              </h3>
              <button onClick={() => setIsPartyModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveParty} className="p-5 space-y-4 text-xs">
              
              {/* Party Type Select */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'पार्टीको प्रकार (Party Type):*' : 'Party Type:*'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPartyType('CUSTOMER')}
                    className={`py-2 px-3 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      partyType === 'CUSTOMER'
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <Users className="w-4 h-4" />
                    <span>{isNe ? 'ग्राहक (Customer)' : 'Customer'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPartyType('SUPPLIER')}
                    className={`py-2 px-3 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      partyType === 'SUPPLIER'
                        ? 'bg-rose-700 text-white border-rose-700 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    <span>{isNe ? 'सप्लायर (Supplier)' : 'Supplier'}</span>
                  </button>
                </div>
              </div>

              {/* Customer Category Select (Only for Customers) */}
              {partyType === 'CUSTOMER' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isNe ? 'ग्राहकको वर्ग (Customer Category):*' : 'Customer Category:*'}
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setPartyCustomerCategory('RETAIL')}
                      className={`py-2 px-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer ${
                        partyCustomerCategory === 'RETAIL'
                          ? 'bg-emerald-100 text-emerald-900 border-emerald-400 font-extrabold shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <Store className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{isNe ? 'खुद्रा (Retail)' : 'Retail'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPartyCustomerCategory('WHOLESALE')}
                      className={`py-2 px-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer ${
                        partyCustomerCategory === 'WHOLESALE'
                          ? 'bg-blue-100 text-blue-900 border-blue-400 font-extrabold shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <Building2 className="w-3.5 h-3.5 text-blue-600" />
                      <span>{isNe ? 'थोक (Wholesale)' : 'Wholesale'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPartyCustomerCategory('GOVERNMENT')}
                      className={`py-2 px-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer ${
                        partyCustomerCategory === 'GOVERNMENT'
                          ? 'bg-purple-100 text-purple-900 border-purple-400 font-extrabold shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <Landmark className="w-3.5 h-3.5 text-purple-600" />
                      <span>{isNe ? 'सरकारी (Govt)' : 'Government'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPartyCustomerCategory('OTHER')}
                      className={`py-2 px-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer ${
                        partyCustomerCategory === 'OTHER'
                          ? 'bg-amber-100 text-amber-900 border-amber-400 font-extrabold shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
                      <span>{isNe ? 'अन्य (Other)' : 'Other'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Party Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'नाम (Customer / Firm Name):*' : 'Name:*'}
                </label>
                <input
                  type="text"
                  required
                  value={partyName}
                  onChange={(e) => setPartyName(e.target.value)}
                  placeholder={isNe ? 'उदा: राम बहादुर श्रेष्ठ / पोखरा एग्रो स्टोर' : 'e.g. Ram Bahadur Shrestha'}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-semibold text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Initial Outstanding Amount (Opening Balance) */}
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1">
                <label className="block text-xs font-bold text-amber-900 mb-1">
                  {isNe ? 'सुरुवाती बक्यौता रकम (Initial Opening Balance Rs):*' : 'Initial Outstanding Balance (Rs):*'}
                </label>
                <input
                  type="number"
                  required
                  value={partyOpeningBalance}
                  onChange={(e) => setPartyOpeningBalance(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-amber-300 rounded-xl font-mono text-base font-bold text-amber-950 bg-white"
                />
                <p className="text-[10px] text-amber-800">
                  {isNe
                    ? 'सफ्टवेयर सुरु गर्नुभन्दा अगाडिको पुरानो बक्यौता रकम (लिन बाँकी भए पोजेटिभ र अग्रिम दिएको भए नेगेटिभ प्रविष्ट गर्नुहोस्)'
                    : 'Enter existing dues from prior system. Positive for due receivables, negative for advances.'}
                </p>
              </div>

              {/* Phone & PAN */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'सम्पर्क फोन:' : 'Phone Number:'}
                  </label>
                  <input
                    type="text"
                    value={partyPhone}
                    onChange={(e) => setPartyPhone(e.target.value)}
                    placeholder="9841000000"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'प्यान नम्बर (PAN):' : 'PAN Number:'}
                  </label>
                  <input
                    type="text"
                    maxLength={9}
                    value={partyPan}
                    onChange={(e) => setPartyPan(e.target.value)}
                    placeholder="600000000"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              {/* Address */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'ठेगाना (Address):' : 'Address:'}
                </label>
                <input
                  type="text"
                  value={partyAddress}
                  onChange={(e) => setPartyAddress(e.target.value)}
                  placeholder="उदा: काठमाडौं-१०, बानेश्वर"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsPartyModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs cursor-pointer"
                >
                  {isNe ? 'सुरक्षित गर्नुहोस्' : 'Save Party'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: QUICK VOUCHER PAYMENT / COLLECTION MODAL                         */}
      {/* ========================================================================= */}
      {isVoucherModalOpen && voucherParty && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className={`px-5 py-4 border-b flex items-center justify-between text-white ${
              voucherType === 'PAYMENT' ? 'bg-rose-900' : 'bg-emerald-900'
            }`}>
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5" />
                <h3 className="text-sm font-bold">
                  {voucherType === 'COLLECTION'
                    ? (isNe ? `ग्राहक असुली (Receipt): ${voucherParty.name}` : `Customer Collection: ${voucherParty.name}`)
                    : (isNe ? `सप्लायर भुक्तानी (Payment): ${voucherParty.name}` : `Supplier Payment: ${voucherParty.name}`)}
                </h3>
              </div>
              <button onClick={() => setIsVoucherModalOpen(false)} className="text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveVoucher} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-slate-100 rounded-xl space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>{isNe ? 'हाल लिन/दिन बाँकी मौज्दात:' : 'Current Due Balance:'}</span>
                  <span className="font-mono font-bold text-slate-900">
                    {formatCurrency(voucherParty.currentBalance ?? voucherParty.openingBalance, isNe)}
                  </span>
                </div>
              </div>

              {/* Amount */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'भुक्तानी / असुली रकम (Rs):*' : 'Voucher Amount (Rs):*'}
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  value={voucherAmount}
                  onChange={(e) => setVoucherAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-xl font-mono text-lg font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Mode: Cash vs Bank */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'भुक्तानी माध्यम (Mode):*' : 'Payment Mode:*'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setVoucherMode('CASH')}
                    className={`py-2 px-3 rounded-xl border font-bold transition cursor-pointer ${
                      voucherMode === 'CASH'
                        ? 'bg-emerald-700 text-white border-emerald-700'
                        : 'bg-slate-50 text-slate-700 border-slate-300'
                    }`}
                  >
                    💵 {isNe ? 'नगद (Cash)' : 'Cash'}
                  </button>

                  <button
                    type="button"
                    onClick={() => setVoucherMode('BANK')}
                    className={`py-2 px-3 rounded-xl border font-bold transition cursor-pointer ${
                      voucherMode === 'BANK'
                        ? 'bg-purple-700 text-white border-purple-700'
                        : 'bg-slate-50 text-slate-700 border-slate-300'
                    }`}
                  >
                    🏦 {isNe ? 'बैंक / FonePay' : 'Bank / FonePay'}
                  </button>
                </div>
              </div>

              {/* Bank Account Dropdown if Bank selected */}
              {voucherMode === 'BANK' && (
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'बैंक खाता छान्नुहोस्:*' : 'Select Bank Account:*'}
                  </label>
                  <select
                    value={voucherBankId}
                    onChange={(e) => setVoucherBankId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold"
                  >
                    {bankAccounts.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.bankName} ({b.accountNumber})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Notes / Ref */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'भौचर टिप्पणी / सन्दर्भ (Notes / Ref):' : 'Transaction Ref / Notes:'}
                </label>
                <input
                  type="text"
                  value={voucherNotes}
                  onChange={(e) => setVoucherNotes(e.target.value)}
                  placeholder={isNe ? 'उदा: असुली रसिद नं. ५०४ / fonepay ref' : 'Notes'}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsVoucherModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl shadow-xs cursor-pointer"
                >
                  {isNe ? 'भौचर सुरक्षित गर्नुहोस्' : 'Save Voucher'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: PAYMENT DUE REMINDER MODAL (भुक्तानी ताकेता म्यासेज)               */}
      {/* ========================================================================= */}
      {reminderParty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col">
            
            {/* Modal Header */}
            <div className="px-5 py-4 border-b border-amber-800 bg-amber-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <Bell className="w-5 h-5 text-amber-300 animate-bounce" />
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>{isNe ? 'भुक्तानी ताकेता म्यासेज (Payment Reminder)' : 'Send Payment Due Reminder'}</span>
                  </h3>
                  <p className="text-[11px] text-amber-200">
                    {reminderParty.name} ({reminderParty.phone || 'फोन उपलब्ध छैन'})
                  </p>
                </div>
              </div>

              <button
                onClick={() => setReminderParty(null)}
                className="text-amber-200 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 text-xs">
              
              {/* Due Balance Highlight Banner */}
              <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-amber-900 block">
                    {isNe ? 'कुल तिर्न बाँकी बक्यौता रकम:' : 'Total Outstanding Balance:'}
                  </span>
                  <span className="text-xl font-black font-mono text-amber-900">
                    {formatCurrency(reminderParty.currentBalance ?? reminderParty.openingBalance, isNe)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 block">{isNe ? 'सम्पर्क फोन:' : 'Contact Phone:'}</span>
                  <span className="font-mono font-bold text-slate-800">{reminderParty.phone || '-'}</span>
                </div>
              </div>

              {/* Editable Reminder Message */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-slate-700">
                    {isNe ? 'ताकेता म्यासेज सामग्री (संशोधन गर्न सकिने):' : 'Editable Reminder Message:'}
                  </label>
                  <button
                    type="button"
                    onClick={() => setReminderMessageText(generatePaymentReminderMessage(reminderParty))}
                    className="text-[10px] text-emerald-700 hover:underline font-semibold cursor-pointer"
                  >
                    {isNe ? 'पुन: रिसेट गर्नुहोस्' : 'Reset Default'}
                  </button>
                </div>
                <textarea
                  rows={8}
                  value={reminderMessageText}
                  onChange={(e) => setReminderMessageText(e.target.value)}
                  className="w-full p-3 border border-slate-300 rounded-xl font-sans text-xs text-slate-800 leading-relaxed focus:ring-2 focus:ring-amber-500 bg-slate-50 font-medium"
                />
              </div>

              {/* Action Buttons: WhatsApp, SMS, Copy, Record Collection */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  
                  {/* WhatsApp */}
                  <button
                    onClick={() => shareViaWhatsApp(reminderParty.phone, reminderMessageText)}
                    className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp {isNe ? 'मा पठाउनुहोस्' : 'Share'}</span>
                  </button>

                  {/* SMS */}
                  <button
                    onClick={() => shareViaSms(reminderParty.phone, reminderMessageText)}
                    className="py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>SMS {isNe ? 'मा पठाउनुहोस्' : 'Send SMS'}</span>
                  </button>

                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  
                  {/* Copy to Clipboard */}
                  <button
                    onClick={async () => {
                      const success = await copyMessageToClipboard(reminderMessageText);
                      if (success) {
                        alert(isNe ? 'ताकेता म्यासेज क्लिपबोर्डमा कपी भयो!' : 'Message copied to clipboard!');
                      }
                    }}
                    className="py-2.5 px-3 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <Copy className="w-4 h-4 text-emerald-400" />
                    <span>{isNe ? 'म्यासेज कपी गर्नुहोस्' : 'Copy Message'}</span>
                  </button>

                  {/* Record Voucher Collection */}
                  <button
                    onClick={() => {
                      const p = reminderParty;
                      setReminderParty(null);
                      handleOpenVoucherModal(p, 'COLLECTION');
                    }}
                    className="py-2.5 px-3 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <Wallet className="w-4 h-4 text-amber-300" />
                    <span>{isNe ? 'नगद/बैंक असुली दर्ता' : 'Record Payment'}</span>
                  </button>

                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex justify-end shrink-0">
              <button
                onClick={() => setReminderParty(null)}
                className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition cursor-pointer text-xs"
              >
                {isNe ? 'बन्द गर्नुहोस्' : 'Close'}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: DYNAMIC FONEPAY / NEPALPAY QR MODAL                              */}
      {/* ========================================================================= */}
      {qrModalParty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col">
            
            {/* Modal Header */}
            <div className={`px-5 py-4 border-b flex items-center justify-between text-white ${
              qrType === 'FONEPAY' ? 'bg-gradient-to-r from-red-700 via-rose-800 to-emerald-800' : qrType === 'NEPALPAY' ? 'bg-gradient-to-r from-blue-800 to-indigo-900' : 'bg-slate-900'
            }`}>
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-white/20 rounded-xl">
                  <QrCode className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>{isNe ? 'डाइनामिक QR भुक्तानी कोड' : 'Dynamic Payment QR Code'}</span>
                  </h3>
                  <p className="text-[11px] text-white/80">
                    {qrModalParty.name} ({qrModalParty.phone || 'फोन उपलब्ध छैन'})
                  </p>
                </div>
              </div>

              <button
                onClick={() => setQrModalParty(null)}
                className="text-white/80 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 text-xs">
              
              {/* QR Provider Selector Tabs */}
              <div className="grid grid-cols-3 gap-1.5 bg-slate-100 p-1.5 rounded-xl font-bold text-center">
                <button
                  type="button"
                  onClick={() => setQrType('FONEPAY')}
                  className={`py-2 px-1 rounded-lg transition cursor-pointer flex items-center justify-center gap-1 ${
                    qrType === 'FONEPAY' ? 'bg-red-700 text-white shadow-xs' : 'text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <span className="text-xs">🔴 FonePay</span>
                </button>

                <button
                  type="button"
                  onClick={() => setQrType('NEPALPAY')}
                  className={`py-2 px-1 rounded-lg transition cursor-pointer flex items-center justify-center gap-1 ${
                    qrType === 'NEPALPAY' ? 'bg-blue-800 text-white shadow-xs' : 'text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <span className="text-xs">🔵 NepalPay</span>
                </button>

                <button
                  type="button"
                  onClick={() => setQrType('BANK')}
                  className={`py-2 px-1 rounded-lg transition cursor-pointer flex items-center justify-center gap-1 ${
                    qrType === 'BANK' ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  <span className="text-xs">🏦 Direct Bank</span>
                </button>
              </div>

              {/* Dynamic Amount Input & Quick Presets */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800 text-xs">
                    {isNe ? 'भुक्तानी गर्नुपर्ने रकम (Rs):*' : 'Dynamic Payment Amount (Rs):*'}
                  </label>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {isNe ? 'कुल बक्यौता:' : 'Full Due:'} {formatCurrency(Math.abs(qrModalParty.currentBalance ?? qrModalParty.openingBalance), isNe)}
                  </span>
                </div>

                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-mono font-bold text-slate-400">रु.</span>
                  <input
                    type="number"
                    min={1}
                    value={qrAmount}
                    onChange={(e) => setQrAmount(parseFloat(e.target.value) || 0)}
                    className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-base text-slate-900 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Quick Presets */}
                <div className="flex items-center gap-1.5 flex-wrap text-[10px]">
                  <button
                    type="button"
                    onClick={() => setQrAmount(Math.abs(qrModalParty.currentBalance ?? qrModalParty.openingBalance))}
                    className="px-2 py-1 bg-white border border-slate-200 rounded hover:bg-slate-100 font-bold text-slate-700 cursor-pointer"
                  >
                    {isNe ? 'सबै रकम (Full)' : 'Full Due'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setQrAmount(Math.round(Math.abs(qrModalParty.currentBalance ?? qrModalParty.openingBalance) / 2))}
                    className="px-2 py-1 bg-white border border-slate-200 rounded hover:bg-slate-100 font-bold text-slate-700 cursor-pointer"
                  >
                    {isNe ? '५०% (आधा)' : '50% Half'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setQrAmount(1000)}
                    className="px-2 py-1 bg-white border border-slate-200 rounded hover:bg-slate-100 font-bold font-mono text-slate-700 cursor-pointer"
                  >
                    रु. १,०००
                  </button>
                  <button
                    type="button"
                    onClick={() => setQrAmount(5000)}
                    className="px-2 py-1 bg-white border border-slate-200 rounded hover:bg-slate-100 font-bold font-mono text-slate-700 cursor-pointer"
                  >
                    रु. ५,०००
                  </button>
                </div>
              </div>

              {/* Bank Account Selection Dropdown if multiple exist */}
              {company.bankAccounts && company.bankAccounts.length > 0 && (
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'प्राप्तकर्ता बैंक खाता छान्नुहोस् (Receiving Bank):' : 'Select Deposit Bank:'}
                  </label>
                  <select
                    value={qrBankId}
                    onChange={(e) => setQrBankId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold bg-white"
                  >
                    {company.bankAccounts.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.bankName} - {b.accountNumber} ({b.accountHolder})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Dynamic QR Display Card */}
              <div className="bg-white border-2 border-dashed border-slate-300 p-4 rounded-2xl flex flex-col items-center justify-center text-center space-y-3 relative overflow-hidden shadow-inner">
                
                {/* QR Brand Header */}
                <div className="flex items-center gap-1.5 font-bold text-xs text-slate-800">
                  <span className={`w-2.5 h-2.5 rounded-full ${qrType === 'FONEPAY' ? 'bg-red-600' : qrType === 'NEPALPAY' ? 'bg-blue-600' : 'bg-emerald-600'}`} />
                  <span>
                    {qrType === 'FONEPAY' ? 'FonePay Dynamic QR' : qrType === 'NEPALPAY' ? 'NepalPay Dynamic QR' : 'Direct Bank Deposit QR'}
                  </span>
                </div>

                {/* SVG QR Code */}
                <div className="p-3 bg-white border border-slate-200 rounded-xl shadow-xs">
                  <QRCodeSVG
                    value={getDynamicQrPayload(qrModalParty, qrAmount, qrType, qrBankId)}
                    size={200}
                    includeMargin={true}
                    level="H"
                  />
                </div>

                {/* Amount & Merchant Details */}
                <div className="space-y-0.5 max-w-xs">
                  <div className="text-xl font-black font-mono text-slate-900">
                    {formatCurrency(qrAmount, isNe)}
                  </div>
                  <p className="text-xs font-bold text-emerald-800">{company.name || 'KrishiYantra ERP'}</p>
                  <p className="text-[10px] font-mono text-slate-500">
                    {company.bankAccounts?.find((b) => b.id === qrBankId)?.bankName || 'Nepal Bank'} · Acc: {company.bankAccounts?.find((b) => b.id === qrBankId)?.accountNumber || '0000000'}
                  </p>
                  <p className="text-[10px] text-slate-400">
                    {isNe ? 'eSewa, Khalti, Fonepay वा जुनसुकै मोबाइल बैंकिङ एपबाट स्क्यान गर्नुहोस्' : 'Scan via any Mobile Banking, Fonepay, eSewa, or Khalti app'}
                  </p>
                </div>
              </div>

              {/* Action Buttons: Print, Share via WhatsApp, Record Collection */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="grid grid-cols-2 gap-2">
                  
                  {/* Print QR Counter Slip */}
                  <button
                    type="button"
                    onClick={() => printPage()}
                    className="py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer text-xs"
                  >
                    <Printer className="w-4 h-4 text-amber-400" />
                    <span>{isNe ? 'QR स्लिप प्रिन्ट' : 'Print QR'}</span>
                  </button>

                  {/* Share QR via WhatsApp */}
                  <button
                    type="button"
                    onClick={() => {
                      const bank = company.bankAccounts?.find((b) => b.id === qrBankId) || company.bankAccounts?.[0];
                      const msg = `*${company.name} - ${qrType === 'FONEPAY' ? 'FonePay QR' : 'NepalPay QR'}*\n` +
                        `ग्राहक: *${qrModalParty.name}*\n` +
                        `बुझाउनुपर्ने रकम: *${formatCurrency(qrAmount, isNe)}*\n` +
                        `बैंक: ${bank?.bankName || ''}\n` +
                        `खाता नं: *${bank?.accountNumber || ''}*\n` +
                        `खातावाला: ${bank?.accountHolder || ''}\n\n` +
                        `कृपया FonePay/NepalPay/eSewa/Khalti बाट स्क्यान गरी रकम भुक्तानी गर्नुहोला। धन्यवाद!`;
                      shareViaWhatsApp(qrModalParty.phone, msg);
                    }}
                    className="py-2.5 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer text-xs"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp {isNe ? 'शेयर' : 'Share'}</span>
                  </button>

                </div>

                {/* Record Collection Button */}
                <button
                  type="button"
                  onClick={() => {
                    const p = qrModalParty;
                    setQrModalParty(null);
                    handleOpenVoucherModal(p, 'COLLECTION');
                  }}
                  className="w-full py-2.5 px-3 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition cursor-pointer text-xs shadow-xs"
                >
                  <Wallet className="w-4 h-4 text-amber-300" />
                  <span>{isNe ? 'भुक्तानी प्राप्त भयो (असुली भौचर दर्ता गर्नुहोस्)' : 'Payment Received (Record Collection)'}</span>
                </button>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex justify-end shrink-0">
              <button
                type="button"
                onClick={() => setQrModalParty(null)}
                className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition cursor-pointer text-xs"
              >
                {isNe ? 'बन्द गर्नुहोस्' : 'Close'}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DIRECT CUSTOMER EXCEL UPLOAD MODAL (Name, Address, Due Amount, Pay Amount) */}
      {/* ========================================================================= */}
      {isExcelUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white shrink-0">
              <div className="flex items-center gap-2.5">
                <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="text-sm sm:text-base font-bold">
                    {isNe
                      ? 'ग्राहकको Excel फाइल सिधै अपलोड गर्नुहोस् (Customer Name, Address, Due Amount, Pay Amount)'
                      : 'Direct Customer Excel Upload (Customer Name, Address, Due Amount, Pay Amount)'}
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    {isNe
                      ? 'तपाईंसँग भएको Excel (.xlsx, .xls, .csv) छान्नुहोस् — नाम, ठेगाना, बक्यौता (Due) र बुझाएको रकम (Pay) स्वतः पार्टी खातामा अपलोड हुन्छ'
                      : 'Upload your Excel file with Customer Name, Address, Due Amount & Pay Amount'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsExcelUploadModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
              {/* Step 1: Upload File & Download Sample Template */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl">
                <div className="flex items-center gap-3">
                  <label className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs cursor-pointer transition">
                    <Upload className="w-4 h-4" />
                    <span>{isNe ? '१. Excel वा CSV फाइल छान्नुहोस् (.xlsx / .csv)' : '1. Choose Excel/CSV File'}</span>
                    <input
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleCustomerExcelFileSelect}
                      className="hidden"
                    />
                  </label>
                  {excelFileName && (
                    <span className="font-mono font-bold text-emerald-950">
                      {excelFileName} ({excelRows.length} rows)
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={downloadCustomerImportTemplate}
                  className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold rounded-xl cursor-pointer transition"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{isNe ? 'नमुना Excel टेम्प्लेट डाउनलोड' : 'Download Sample Excel'}</span>
                </button>
              </div>

              {/* Step 2: Column Mapping & Calculation Mode (when file is loaded) */}
              {excelHeaders.length > 0 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                    <div>
                      <label className="font-bold text-emerald-900 block mb-1">
                        {isNe ? '१. Customer Name *' : '1. Customer Name *'}
                      </label>
                      <select
                        value={excelColMap.name}
                        onChange={(e) => setExcelColMap({ ...excelColMap, name: Number(e.target.value) })}
                        className="w-full px-2 py-1.5 bg-white border border-emerald-400 rounded-lg font-bold"
                      >
                        <option value={-1}>-- छान्नुहोस् --</option>
                        {excelHeaders.map((h, i) => (
                          <option key={i} value={i}>
                            {h || `Col ${i + 1}`}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="font-bold text-slate-800 block mb-1">
                        {isNe ? '२. Address (ठेगाना)' : '2. Address'}
                      </label>
                      <select
                        value={excelColMap.address}
                        onChange={(e) => setExcelColMap({ ...excelColMap, address: Number(e.target.value) })}
                        className="w-full px-2 py-1.5 bg-white border border-slate-300 rounded-lg"
                      >
                        <option value={-1}>-- छान्नुहोस् --</option>
                        {excelHeaders.map((h, i) => (
                          <option key={i} value={i}>
                            {h || `Col ${i + 1}`}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="font-bold text-rose-900 block mb-1">
                        {isNe ? '३. Due Amount (बाँकी)' : '3. Due Amount'}
                      </label>
                      <select
                        value={excelColMap.due}
                        onChange={(e) => setExcelColMap({ ...excelColMap, due: Number(e.target.value) })}
                        className="w-full px-2 py-1.5 bg-white border border-rose-300 rounded-lg font-bold"
                      >
                        <option value={-1}>-- छान्नुहोस् --</option>
                        {excelHeaders.map((h, i) => (
                          <option key={i} value={i}>
                            {h || `Col ${i + 1}`}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="font-bold text-blue-900 block mb-1">
                        {isNe ? '४. Pay Amount (बुझाएको)' : '4. Pay Amount'}
                      </label>
                      <select
                        value={excelColMap.pay}
                        onChange={(e) => setExcelColMap({ ...excelColMap, pay: Number(e.target.value) })}
                        className="w-full px-2 py-1.5 bg-white border border-blue-300 rounded-lg font-bold"
                      >
                        <option value={-1}>-- छान्नुहोस् --</option>
                        {excelHeaders.map((h, i) => (
                          <option key={i} value={i}>
                            {h || `Col ${i + 1}`}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="font-bold text-slate-700 block mb-1">
                        {isNe ? '५. Phone (ऐच्छिक)' : '5. Phone'}
                      </label>
                      <select
                        value={excelColMap.phone}
                        onChange={(e) => setExcelColMap({ ...excelColMap, phone: Number(e.target.value) })}
                        className="w-full px-2 py-1.5 bg-white border border-slate-300 rounded-lg"
                      >
                        <option value={-1}>-- खाली --</option>
                        {excelHeaders.map((h, i) => (
                          <option key={i} value={i}>
                            {h || `Col ${i + 1}`}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="font-bold text-slate-700 block mb-1">
                        {isNe ? '६. PAN (ऐच्छिक)' : '6. PAN'}
                      </label>
                      <select
                        value={excelColMap.pan}
                        onChange={(e) => setExcelColMap({ ...excelColMap, pan: Number(e.target.value) })}
                        className="w-full px-2 py-1.5 bg-white border border-slate-300 rounded-lg"
                      >
                        <option value={-1}>-- खाली --</option>
                        {excelHeaders.map((h, i) => (
                          <option key={i} value={i}>
                            {h || `Col ${i + 1}`}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Calculation Toggle */}
                  <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-100 rounded-xl">
                    <span className="font-bold text-slate-800">
                      {isNe ? 'बाँकी बक्यौता गणना विधि:' : 'Net Balance Calculation:'}
                    </span>
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => setExcelCalcMode('SUBTRACT_PAY')}
                        className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                          excelCalcMode === 'SUBTRACT_PAY'
                            ? 'bg-emerald-700 text-white'
                            : 'bg-white text-slate-700 border border-slate-300'
                        }`}
                      >
                        {isNe ? 'खुद बाँकी = Due Amount - Pay Amount (Due बाट Pay घटाउने)' : 'Net Due = Due Amount - Pay Amount'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setExcelCalcMode('DUE_IS_NET')}
                        className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                          excelCalcMode === 'DUE_IS_NET'
                            ? 'bg-emerald-700 text-white'
                            : 'bg-white text-slate-700 border border-slate-300'
                        }`}
                      >
                        {isNe ? 'Due Amount नै अन्तिम खुद बाँकी हो' : 'Due Amount is Already Net Due'}
                      </button>
                    </div>
                  </div>

                  {/* Preview Table */}
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <div className="px-4 py-2.5 bg-slate-900 text-white flex items-center justify-between font-bold">
                      <span>
                        {isNe
                          ? `अपलोड हुने ग्राहक सूची (${toNepaliDigits(parsedExcelCustomers.length)} जना)`
                          : `Customers Ready to Import (${parsedExcelCustomers.length})`}
                      </span>
                      <span className="font-mono text-emerald-300">
                        {isNe ? 'कुल खुद बाँकी:' : 'Total Net Due:'}{' '}
                        {formatCurrency(
                          parsedExcelCustomers.reduce((s, p) => s + p.currentBalance, 0),
                          isNe
                        )}
                      </span>
                    </div>
                    <div className="max-h-64 overflow-y-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 sticky top-0">
                          <tr>
                            <th className="py-2 px-3">#</th>
                            <th className="py-2 px-3">Customer Name (नाम)</th>
                            <th className="py-2 px-3">Address (ठेगाना)</th>
                            <th className="py-2 px-3 text-right">Due Amount (बक्यौता)</th>
                            <th className="py-2 px-3 text-right">Pay Amount (बुझाएको)</th>
                            <th className="py-2 px-3 text-right">Net Due (खुद बाँकी)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {parsedExcelCustomers.map((c, i) => (
                            <tr key={i} className="hover:bg-slate-50">
                              <td className="py-2 px-3 font-mono text-slate-400">{i + 1}</td>
                              <td className="py-2 px-3 font-bold text-slate-900">{c.name}</td>
                              <td className="py-2 px-3 text-slate-700">{c.address}</td>
                              <td className="py-2 px-3 text-right font-mono font-semibold text-slate-800">
                                {formatCurrency(c.openingBalance, isNe)}
                              </td>
                              <td className="py-2 px-3 text-right font-mono font-bold text-blue-700">
                                {formatCurrency(c.paidAmount || 0, isNe)}
                              </td>
                              <td className="py-2 px-3 text-right font-mono font-bold text-emerald-800">
                                {formatCurrency(c.currentBalance, isNe)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsExcelUploadModalOpen(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl text-xs cursor-pointer"
              >
                {isNe ? 'बन्द गर्नुहोस्' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={parsedExcelCustomers.length === 0}
                onClick={handleConfirmExcelCustomerImport}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {isNe
                    ? `${toNepaliDigits(parsedExcelCustomers.length)} जना ग्राहक खातामा सुरक्षित गर्नुहोस्`
                    : `Import ${parsedExcelCustomers.length} Customers Now`}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
