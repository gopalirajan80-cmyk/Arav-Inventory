import React, { useCallback, useEffect, useState } from 'react';
import { authFetch, clearToken, getToken, setToken, setServerUser } from '../utils/auth';
import { syncEngine } from '../utils/syncClient';
import type { SyncStatus } from '../utils/syncEngine';

type Status = 'checking' | 'locked' | 'syncing' | 'syncfail' | 'open';

export function LoginGate({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<Status>('checking');
  const [loginId, setLoginId] = useState(() => { try { return localStorage.getItem('ky_last_login_id') || ''; } catch { return ''; } });
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [sync, setSync] = useState<SyncStatus>(syncEngine.getStatus());

  // After login: bring this device up to date with the server BEFORE the app starts.
  // (A new / reinstalled device gets all its data back here.)
  const startSync = useCallback(async () => {
    setStatus('syncing');
    const hadToken = !!getToken();
    const r = await syncEngine.init();
    if (!r.ok && hadToken && !getToken()) { setStatus('locked'); return; } // login expired meanwhile
    setStatus(r.ok ? 'open' : 'syncfail');
  }, []);

  useEffect(() => {
    let alive = true;
    const check = async () => {
      try {
        const res = await authFetch('/api/auth-check');
        if (!alive) return;
        if (res.ok) {
          const j = await res.json().catch(() => ({}));
          if (j.user) setServerUser(j.user); // refresh name / permissions the owner may have changed
          await startSync();
        } else setStatus('locked');
      } catch {
        // Offline: a device that already has its data may keep working
        if (!alive) return;
        if (getToken()) await startSync();
        else setStatus('locked');
      }
    };
    check();
    const onExpired = () => { syncEngine.stop(); setStatus('locked'); };
    window.addEventListener('ky-auth-expired', onExpired);
    return () => { alive = false; window.removeEventListener('ky-auth-expired', onExpired); };
  }, [startSync]);

  useEffect(() => syncEngine.subscribe(setSync), []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: loginId.trim(), password }),
      });
      const json = await res.json().catch(() => ({}));
      if (res.ok) {
        setToken(json.token || '');
        setServerUser(json.user || null);
        try { localStorage.setItem('ky_last_login_id', loginId.trim()); } catch {}
        setPassword('');
        await startSync();
      } else {
        setError(json.error || 'लगइन असफल भयो।');
      }
    } catch {
      setError('सर्भरसँग जोडिन सकिएन। इन्टरनेट जाँच गर्नुहोस्।');
    } finally {
      setBusy(false);
    }
  };

  const Shell = ({ children: c }: { children: React.ReactNode }) => (
    <div className="min-h-screen flex items-center justify-center bg-green-50 p-4">
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-lg p-6 space-y-4 text-center">{c}</div>
    </div>
  );

  if (status === 'checking') return <Shell><p className="text-gray-500">लोड हुँदैछ...</p></Shell>;
  if (status === 'syncing') {
    return (
      <Shell>
        <h1 className="text-lg font-bold text-green-700">KrishiYantra ERP</h1>
        <p className="text-gray-600">तपाईंको डाटा सर्भरबाट ल्याउँदैछ...</p>
      </Shell>
    );
  }
  if (status === 'syncfail') {
    return (
      <Shell>
        <h1 className="text-lg font-bold text-green-700">KrishiYantra ERP</h1>
        <p className="text-gray-700">
          यो डिभाइसमा डाटा छैन र सर्भरसँग जोडिन सकिएन। डाटा सुरक्षित राख्न इन्टरनेट जोडेर फेरि प्रयास गर्नुहोस्।
        </p>
        <button onClick={startSync} className="w-full bg-green-700 text-white rounded-lg py-2 font-semibold">
          फेरि प्रयास गर्नुहोस्
        </button>
      </Shell>
    );
  }
  if (status === 'locked') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-green-50 p-4">
        <form onSubmit={submit} className="w-full max-w-sm bg-white rounded-2xl shadow-lg p-6 space-y-4">
          <div className="text-center">
            <h1 className="text-xl font-bold text-green-700">KrishiYantra ERP</h1>
            <p className="text-sm text-gray-500 mt-1">आफ्नो ID र पासवर्ड हाल्नुहोस्</p>
          </div>
          <input
            type="text"
            autoFocus
            autoCapitalize="none"
            autoCorrect="off"
            autoComplete="username"
            value={loginId}
            onChange={(e) => setLoginId(e.target.value)}
            placeholder="लगइन ID / Login ID (मालिक: owner)"
            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-600"
          />
          <input
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="पासवर्ड / Password"
            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-600"
          />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            disabled={busy || !password || !loginId.trim()}
            className="w-full bg-green-700 text-white rounded-lg py-2 font-semibold disabled:opacity-50"
          >
            {busy ? 'जाँच हुँदैछ...' : 'लगइन'}
          </button>
        </form>
      </div>
    );
  }

  // status === 'open'
  return (
    <>
      {children}
      {sync.remoteChanged && (
        <div className="fixed top-2 left-1/2 -translate-x-1/2 z-[9999] bg-emerald-700 text-white text-xs sm:text-sm rounded-xl shadow-lg px-4 py-2 flex items-center gap-3">
          <span>अर्को डिभाइसमा नयाँ डाटा सेभ भयो।</span>
          <button
            onClick={() => { syncEngine.acknowledgeRemote(); window.location.reload(); }}
            className="bg-white text-emerald-800 font-bold rounded-lg px-3 py-1"
          >
            अपडेट गर्नुहोस्
          </button>
        </div>
      )}
      {(sync.pending > 0 || sync.state === 'offline') && (
        <div className="fixed bottom-2 left-2 z-[9999] bg-amber-100 text-amber-900 text-[11px] rounded-lg shadow px-3 py-1 pointer-events-none">
          {sync.state === 'offline'
            ? `⚠ अफलाइन — ${sync.pending} परिवर्तन इन्टरनेट आएपछि सेभ हुन्छ`
            : `⏳ सेभ हुँदैछ (${sync.pending})`}
        </div>
      )}
    </>
  );
}

export function logout() {
  clearToken();
  window.dispatchEvent(new Event('ky-auth-expired'));
}
