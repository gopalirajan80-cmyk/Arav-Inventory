import React, { useEffect, useState } from 'react';
import { Calendar } from 'lucide-react';
import {
  adStringToBsString,
  bsStringToAdString,
  getTodayBsString,
  formatBsDateNepaliText
} from '../utils/nepaliCalendar';

interface Props {
  /** B.S. date, YYYY-MM-DD (single source of truth; A.D. is always derived from it) */
  valueBs: string;
  onChange: (bs: string, ad: string) => void;
  isNe?: boolean;
  className?: string;
  /** hide the small Nepali-text hint under the inputs */
  hideHint?: boolean;
}

/** "20830715" / "2083715" typed quickly -> "2083-07-15" while typing (digits only, max 8). */
const autoFormatBs = (raw: string): string => {
  const digits = raw.replace(/[^\d]/g, '').slice(0, 8);
  if (digits.length <= 4) return digits;
  if (digits.length <= 6) return `${digits.slice(0, 4)}-${digits.slice(4)}`;
  return `${digits.slice(0, 4)}-${digits.slice(4, 6)}-${digits.slice(6)}`;
};

/**
 * B.S. र A.D. मिति एकैसाथ — एउटा फेर्दा अर्को स्वतः मिल्छ।
 * Typing a BS date fills the AD date; picking an AD date fills the BS date.
 */
export const DualDateInput: React.FC<Props> = ({ valueBs, onChange, isNe = true, className = '', hideHint }) => {
  const [bsText, setBsText] = useState<string>(valueBs);
  const adValue = bsStringToAdString(valueBs);
  const isInvalid = !!bsText && bsText.length >= 8 && !bsStringToAdString(bsText);

  // keep the text box in sync when the parent changes the value (reset button, saved bill loaded, ...)
  useEffect(() => {
    setBsText(valueBs);
  }, [valueBs]);

  const handleBsChange = (raw: string) => {
    const formatted = autoFormatBs(raw);
    setBsText(formatted);
    const ad = bsStringToAdString(formatted);
    if (ad) onChange(formatted, ad);
  };

  const handleAdChange = (ad: string) => {
    const bs = adStringToBsString(ad);
    if (bs) {
      setBsText(bs);
      onChange(bs, ad);
    }
  };

  const handleToday = () => {
    const bs = getTodayBsString();
    setBsText(bs);
    onChange(bs, bsStringToAdString(bs));
  };

  return (
    <div className={`flex flex-col items-end gap-0.5 ${className}`}>
      <div className="flex items-center gap-1.5 flex-wrap justify-end">
        <div className="flex flex-col items-start">
          <span className="text-[9px] font-bold text-emerald-800 uppercase leading-none mb-0.5">B.S.</span>
          <input
            type="text"
            inputMode="numeric"
            value={bsText}
            onChange={(e) => handleBsChange(e.target.value)}
            onBlur={() => {
              // wrong / half typed date -> snap back to the last valid one
              if (!bsStringToAdString(bsText)) setBsText(valueBs);
            }}
            placeholder="YYYY-MM-DD"
            maxLength={10}
            className={`w-28 px-2 py-1 bg-white border rounded-lg text-xs font-mono font-black text-slate-800 text-center focus:ring-1 focus:outline-none shadow-2xs ${
              isInvalid
                ? 'border-rose-400 focus:ring-rose-400'
                : 'border-slate-300 hover:border-emerald-500 focus:ring-emerald-500'
            }`}
            title={isNe ? 'बिक्रम सम्वत् मिति (B.S.)' : 'Bikram Sambat date'}
          />
        </div>
        <div className="flex flex-col items-start">
          <span className="text-[9px] font-bold text-blue-800 uppercase leading-none mb-0.5">A.D.</span>
          <input
            type="date"
            value={adValue}
            onChange={(e) => handleAdChange(e.target.value)}
            className="w-32 px-2 py-1 bg-white border border-slate-300 hover:border-blue-500 rounded-lg text-xs font-mono font-bold text-slate-800 focus:ring-1 focus:ring-blue-500 focus:outline-none shadow-2xs"
            title={isNe ? 'अंग्रेजी मिति (A.D.)' : 'Gregorian date'}
          />
        </div>
        <button
          type="button"
          onClick={handleToday}
          className="self-end p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-lg cursor-pointer"
          title={isNe ? 'आजको मिति' : 'Today'}
        >
          <Calendar className="w-3.5 h-3.5" />
        </button>
      </div>
      {!hideHint && (
        <span className={`text-[10px] font-medium ${isInvalid ? 'text-rose-600' : 'text-slate-500'}`}>
          {isInvalid
            ? isNe
              ? 'मिति मिलेन — YYYY-MM-DD मा लेख्नुहोस्'
              : 'Invalid date — use YYYY-MM-DD'
            : valueBs
            ? formatBsDateNepaliText(valueBs)
            : ''}
        </span>
      )}
    </div>
  );
};

export default DualDateInput;
