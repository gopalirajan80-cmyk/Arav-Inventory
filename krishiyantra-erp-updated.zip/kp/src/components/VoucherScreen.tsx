import { InvoicePrintOptions, printArgsFor } from './InvoicePrintOptions';
import { printPage } from '../utils/printHelper';
import { DualDateInput } from './DualDateInput';
import { manualVouchersOnly } from '../utils/partyTxn';
import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Party, Expense, PartyTransaction } from '../types';
import { QRCodeSVG } from 'qrcode.react';
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  Search,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  Calendar,
  X,
  CreditCard,
  BookOpen,
  Printer,
  FileDown,
  FileText,
  Loader2,
  User,
  Hash,
  Building2,
  Share2,
  MessageSquare,
  Send
} from 'lucide-react';
import {
  formatCurrency,
  getTodayBsString,
  toNepaliDigits
} from '../utils/nepaliCalendar';
import { amountInNepaliWords, amountInEnglishWords } from '../utils/vatCalculator';
import { downloadElementAsPdf, triggerReliableHtmlPrint } from '../utils/pdfHelper';
import { PaperSizeToggle } from './PaperSizeToggle';
import { printOrDownloadReportPdf } from '../utils/pdfReportExporter';
import { DailyCashBook } from './DailyCashBook';
import { BankReconciliationView } from './BankReconciliationView';
import { UniversalShareModal } from './UniversalShareModal';

type SubTab = 'COLLECTION' | 'PAYMENT' | 'CUSTOMERS' | 'EXPENSES' | 'CASH_BOOK' | 'BANK_RECONCILIATION';
type ExpenseMode = 'CASH' | 'BANK';

interface PrintableVoucherData {
  id: string;
  voucherType: 'EXPENSE' | 'COLLECTION' | 'PAYMENT';
  voucherNo: string;
  dateBs: string;
  partyOrReceiverName: string;
  partyAddress?: string;
  partyPhone?: string;
  categoryOrTitle: string;
  particulars: string;
  amount: number;
  paymentMode: 'CASH' | 'BANK';
  bankName?: string;
  notes?: string;
}

export const DEFAULT_EXPENSE_CATEGORIES: { id: string; ne: string; en: string }[] = [
  { id: 'EXP_CAT_1', ne: 'खाजा तथा चियापान (Refreshment)', en: 'Tea & Refreshments' },
  { id: 'EXP_CAT_2', ne: 'इन्धन तथा ढुवानी (Fuel & Transport)', en: 'Fuel & Transport' },
  { id: 'EXP_CAT_3', ne: 'मर्मत तथा सम्भार (Maintenance)', en: 'Repair & Maintenance' },
  { id: 'EXP_CAT_4', ne: 'बिजुली, पानी र इन्टरनेट (Utilities)', en: 'Electricity, Water & Internet' },
  { id: 'EXP_CAT_5', ne: 'पसल / गोदाम भाडा (Rent)', en: 'Shop & Warehouse Rent' },
  { id: 'EXP_CAT_6', ne: 'स्टेशनरी र छपाइ (Stationery)', en: 'Stationery & Printing' },
  { id: 'EXP_CAT_7', ne: 'दैनिक ज्याला / लेबर (Daily Labor)', en: 'Daily Labor Charges' },
  { id: 'EXP_CAT_8', ne: 'लोड / अनलोड ज्याला (Loading/Unloading)', en: 'Loading & Unloading' },
  { id: 'EXP_CAT_9', ne: 'टेलिफोन तथा रिचार्ज (Communication)', en: 'Phone & Mobile Recharge' },
  { id: 'EXP_CAT_10', ne: 'अन्य विविध खर्च (Miscellaneous)', en: 'Miscellaneous Expense' }
];

export const DEFAULT_INCOME_CATEGORIES: {
  id: string;
  ne: string;
  en: string;
  incomeType: 'OTHER_INCOME' | 'LOAN_RECEIVED';
}[] = [
  { id: 'INC_CAT_1', ne: 'मर्मत तथा सर्भिसिङ आम्दानी (Repair & Service)', en: 'Repair & Service Income', incomeType: 'OTHER_INCOME' },
  { id: 'INC_CAT_2', ne: 'मेसिनरी / औजार भाडा आम्दानी (Rental Income)', en: 'Equipment Rental Income', incomeType: 'OTHER_INCOME' },
  { id: 'INC_CAT_3', ne: 'सरकारी कृषि अनुदान प्राप्त (Agro Grant)', en: 'Government Agro Grant', incomeType: 'OTHER_INCOME' },
  { id: 'INC_CAT_4', ne: 'पुरानो सामान / कवाडी बिक्री (Scrap Sale)', en: 'Scrap / Old Parts Sale', incomeType: 'OTHER_INCOME' },
  { id: 'INC_CAT_5', ne: 'कमिसन तथा एजेन्सी छुट (Commission)', en: 'Commission & Rebate Income', incomeType: 'OTHER_INCOME' },
  { id: 'INC_CAT_6', ne: 'अन्य विविध आम्दानी (Miscellaneous Income)', en: 'Miscellaneous Other Income', incomeType: 'OTHER_INCOME' },
  { id: 'LOAN_CAT_1', ne: 'बैंक ऋण / ओभरड्राफ्ट प्राप्त (Bank Loan / OD)', en: 'Bank Loan / Overdraft Received', incomeType: 'LOAN_RECEIVED' },
  { id: 'LOAN_CAT_2', ne: 'व्यक्तिगत सापटी / ऋण प्राप्त (Personal Loan)', en: 'Personal Loan / Borrowing', incomeType: 'LOAN_RECEIVED' },
  { id: 'LOAN_CAT_3', ne: 'सहकारी संस्था ऋण प्राप्त (Cooperative Loan)', en: 'Cooperative Loan Received', incomeType: 'LOAN_RECEIVED' },
  { id: 'LOAN_CAT_4', ne: 'साझेदार / मालिक पूँजी थप (Owner Capital Inflow)', en: 'Owner / Partner Capital Injection', incomeType: 'LOAN_RECEIVED' },
  { id: 'LOAN_CAT_5', ne: 'पार्टी / महाजन सापटी (Short-Term Party Loan)', en: 'Short-Term Party Borrowing', incomeType: 'LOAN_RECEIVED' }
];

export const VoucherScreen: React.FC = () => {
  const {
    company,
    updateCompanyProfile,
    setActiveTab,
    parties,
    saveParty,
    deleteParty,
    bankAccounts,
    partyTransactions: allPartyTransactions,
    recordCustomerCollection,
    recordPartyPayment,
    expenses,
    recordExpense,
    deleteExpense,
    deletePartyTransaction,
    voucherSubTab,
    currentAccount,
    language
  } = useApp();

  const isNe = language === 'ne';

  const activeExpenseCategories = useMemo(() => {
    return company.expenseCategories && company.expenseCategories.length > 0
      ? company.expenseCategories
      : DEFAULT_EXPENSE_CATEGORIES;
  }, [company.expenseCategories]);

  const activeIncomeCategories = useMemo(() => {
    return company.incomeCategories && company.incomeCategories.length > 0
      ? company.incomeCategories
      : DEFAULT_INCOME_CATEGORIES;
  }, [company.incomeCategories]);

  const [activeSubTab, setActiveSubTab] = useState<SubTab>(
    (voucherSubTab as SubTab) || 'EXPENSES'
  );

  React.useEffect(() => {
    if (voucherSubTab) {
      setActiveSubTab(voucherSubTab as SubTab);
    }
  }, [voucherSubTab]);

  // खरिद बिलबाट स्वतः बनेका भुक्तानी रेकर्ड भौचर होइनन् — भौचर सूची/गणनामा नदेखाउने
  const partyTransactions = useMemo(() => manualVouchersOnly(allPartyTransactions), [allPartyTransactions]);

  // Suggest next expense voucher number
  const nextExpenseVoucherNo = useMemo(() => {
    const count = expenses.length + 1;
    return `EXP-${String(count).padStart(3, '0')}`;
  }, [expenses.length]);

  // Expense form state
  const [expenseVoucherNo, setExpenseVoucherNo] = useState<string>('');
  const [expenseDateBs, setExpenseDateBs] = useState<string>(getTodayBsString());
  const [expenseAmount, setExpenseAmount] = useState<number>(0);
  const [expensePaidTo, setExpensePaidTo] = useState<string>('');
  const [expenseCategoryMode, setExpenseCategoryMode] = useState<'MASTER' | 'MANUAL'>('MASTER');
  const [expenseCategory, setExpenseCategory] = useState<string>(
    (company.expenseCategories && company.expenseCategories[0]?.ne) || DEFAULT_EXPENSE_CATEGORIES[0].ne
  );
  const [expenseDesc, setExpenseDesc] = useState<string>('');
  const [expenseMode, setExpenseMode] = useState<ExpenseMode>('CASH');
  const [expenseBankId, setExpenseBankId] = useState<string>(bankAccounts[0]?.id || '');
  const [expenseNotes, setExpenseNotes] = useState<string>('');
  const [expenseSearchQuery, setExpenseSearchQuery] = useState<string>('');

  // Customer collection + Other Income + Loan Received form state
  const [collectionEntryType, setCollectionEntryType] = useState<'CUSTOMER_COLLECTION' | 'OTHER_INCOME' | 'LOAN_RECEIVED'>('CUSTOMER_COLLECTION');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [manualPayerOrLenderName, setManualPayerOrLenderName] = useState<string>('');
  const [manualPayerPhone, setManualPayerPhone] = useState<string>('');
  const [manualPayerAddress, setManualPayerAddress] = useState<string>('');
  const [incomeCategoryMode, setIncomeCategoryMode] = useState<'MASTER' | 'MANUAL'>('MASTER');
  const [incomeCategoryInput, setIncomeCategoryInput] = useState<string>(DEFAULT_INCOME_CATEGORIES[0].ne);
  const [collectionDateBs, setCollectionDateBs] = useState<string>(getTodayBsString());
  const [collectionAmount, setCollectionAmount] = useState<number>(0);
  const [collectionMode, setCollectionMode] = useState<'CASH' | 'BANK'>('CASH');
  const [collectionBankId, setCollectionBankId] = useState<string>(bankAccounts[0]?.id || '');
  const [collectionRef, setCollectionRef] = useState<string>('');
  const [collectionNotes, setCollectionNotes] = useState<string>('');
  const [collectionRightTab, setCollectionRightTab] = useState<'VOUCHERS' | 'CUSTOMER_DUES'>('VOUCHERS');

  // Supplier payment form state
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('');
  const [paymentDateBs, setPaymentDateBs] = useState<string>(getTodayBsString());
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMode, setPaymentMode] = useState<'CASH' | 'BANK'>('BANK');
  const [paymentBankId, setPaymentBankId] = useState<string>(bankAccounts[0]?.id || '');
  const [paymentRef, setPaymentRef] = useState<string>('');
  const [paymentNotes, setPaymentNotes] = useState<string>('');

  // Edit/Add Customer Modal state
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Party | null>(null);
  const [custFormName, setCustFormName] = useState('');
  const [custFormAddress, setCustFormAddress] = useState('');
  const [custFormPhone, setCustFormPhone] = useState('');
  const [custFormPan, setCustFormPan] = useState('');
  const [custFormOpeningDue, setCustFormOpeningDue] = useState<number>(0);
  const [custFormType, setCustFormType] = useState<'CUSTOMER' | 'SUPPLIER' | 'BOTH'>('CUSTOMER');

  // Printable Voucher Modal state
  const [printingVoucher, setPrintingVoucher] = useState<PrintableVoucherData | null>(null);
  const [voucherPrintFormat, setVoucherPrintFormat] = useState<'A4' | 'POS_80'>('A4');
  const [isDownloadingVoucherPdf, setIsDownloadingVoucherPdf] = useState(false);

  // Search filter
  const [search, setSearch] = useState('');
  const [successToast, setSuccessToast] = useState('');

  const triggerToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(''), 3500);
  };

  const selectedCustomer = parties.find((p) => p.id === selectedCustomerId);
  const selectedSupplier = parties.find((p) => p.id === selectedSupplierId);

  // Convert an Expense record to PrintableVoucherData
  const buildExpenseVoucherData = (exp: Expense, indexNum?: number): PrintableVoucherData => {
    const bankObj = bankAccounts.find((b) => b.id === exp.bankAccountId);
    const vNo = exp.voucherNo || (indexNum !== undefined ? `EXP-${String(indexNum).padStart(3, '0')}` : `EXP-${exp.id.slice(-4).toUpperCase()}`);
    return {
      id: exp.id,
      voucherType: 'EXPENSE',
      voucherNo: vNo,
      dateBs: exp.dateBs,
      partyOrReceiverName: exp.paidTo || exp.category.split(' (')[0] || (isNe ? 'नगद भुक्तानी (दैनिक खर्च)' : 'Daily Expense Payee'),
      categoryOrTitle: exp.category,
      particulars: exp.description || exp.category,
      amount: exp.amount,
      paymentMode: exp.paymentMode,
      bankName: exp.bankName || (bankObj ? `${bankObj.bankName} (${bankObj.accountNumber})` : undefined),
      notes: exp.notes
    };
  };

  // Convert a PartyTransaction record to PrintableVoucherData
  const buildPartyTxVoucherData = (tx: PartyTransaction): PrintableVoucherData => {
    const isCollection = tx.type === 'COLLECTION_FROM_CUSTOMER';
    const titleText = isCollection
      ? tx.incomeType === 'LOAN_RECEIVED'
        ? tx.incomeCategory || (isNe ? 'ऋण तथा सापटी आम्दानी रसिद' : 'Loan / Borrowing Receipt Voucher')
        : tx.incomeType === 'OTHER_INCOME'
        ? tx.incomeCategory || (isNe ? 'अन्य आम्दानी रसिद भौचर' : 'Other Income Receipt Voucher')
        : tx.incomeCategory || (isNe ? 'ग्राहक उधारो/बाँकी रकम असुली' : 'Customer Due Collection')
      : isNe
      ? 'आपूर्तिकर्ता/साहु रकम भुक्तानी'
      : 'Supplier Account Payment';
    return {
      id: tx.id,
      voucherType: isCollection ? 'COLLECTION' : 'PAYMENT',
      voucherNo: tx.referenceNo || `${isCollection ? 'REC' : 'PAY'}-${tx.id.slice(-4).toUpperCase()}`,
      dateBs: tx.dateBs,
      partyOrReceiverName: tx.partyName,
      partyAddress: tx.partyAddress,
      partyPhone: tx.partyPhone,
      categoryOrTitle: titleText,
      particulars: tx.notes || (isCollection ? titleText : 'आपूर्तिकर्ता खातामा रकम भुक्तानी'),
      amount: tx.amount,
      paymentMode: tx.paymentMode,
      bankName: tx.bankName ? `${tx.bankName}${tx.bankAccountNo ? ` (${tx.bankAccountNo})` : ''}` : undefined,
      notes: tx.notes
    };
  };

  const saveAndOptionallyPrintExpense = (shouldPrint: boolean) => {
    if (expenseAmount <= 0 || !expenseCategory.trim()) return;

    const finalVoucherNo = expenseVoucherNo.trim() || nextExpenseVoucherNo;
    const bankObj = bankAccounts.find((b) => b.id === expenseBankId);
    const newExpenseObj: Omit<Expense, 'id'> = {
      voucherNo: finalVoucherNo,
      dateBs: expenseDateBs || getTodayBsString(),
      amount: expenseAmount,
      paidTo: expensePaidTo.trim() || undefined,
      category: expenseCategory.trim(),
      description: expenseDesc.trim() || expenseCategory.trim(),
      paymentMode: expenseMode,
      bankAccountId: expenseMode === 'BANK' ? expenseBankId : undefined,
      bankName: expenseMode === 'BANK' && bankObj ? bankObj.bankName : undefined,
      notes: expenseNotes.trim()
    };

    recordExpense(newExpenseObj);

    triggerToast(
      isNe
        ? `✓ दैनिक खर्च (${expenseCategory}) रु. ${expenseAmount} सफलतापूर्वक सुरक्षित गरियो!`
        : `✓ Daily expense of Rs. ${expenseAmount} recorded!`
    );

    if (shouldPrint) {
      setPrintingVoucher({
        id: `exp-${Date.now()}`,
        voucherType: 'EXPENSE',
        voucherNo: finalVoucherNo,
        dateBs: newExpenseObj.dateBs,
        partyOrReceiverName: newExpenseObj.paidTo || newExpenseObj.category.split(' (')[0],
        categoryOrTitle: newExpenseObj.category,
        particulars: newExpenseObj.description,
        amount: newExpenseObj.amount,
        paymentMode: newExpenseObj.paymentMode,
        bankName: bankObj && expenseMode === 'BANK' ? `${bankObj.bankName} (${bankObj.accountNumber})` : undefined,
        notes: newExpenseObj.notes
      });
    }

    setExpenseVoucherNo('');
    setExpenseAmount(0);
    setExpensePaidTo('');
    setExpenseDesc('');
    setExpenseNotes('');
  };

  const handleExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveAndOptionallyPrintExpense(false);
  };

  const saveAndOptionallyPrintCollection = (shouldPrint: boolean) => {
    if (collectionAmount <= 0) return;
    if (collectionEntryType === 'CUSTOMER_COLLECTION' && !selectedCustomerId && !manualPayerOrLenderName.trim()) {
      return;
    }

    const prefix =
      collectionEntryType === 'LOAN_RECEIVED'
        ? 'LOAN'
        : collectionEntryType === 'OTHER_INCOME'
        ? 'INC'
        : 'REC';
    const finalRef = collectionRef.trim() || `${prefix}-${String(allPartyTransactions.length + 1).padStart(3, '0')}`;
    const bankObj = bankAccounts.find((b) => b.id === collectionBankId);

    const resolvedTitle =
      collectionEntryType === 'CUSTOMER_COLLECTION'
        ? isNe
          ? 'ग्राहक बक्यौता असुली (Customer Due Collection)'
          : 'Customer Due Collection'
        : incomeCategoryInput.trim() ||
          (collectionEntryType === 'LOAN_RECEIVED'
            ? 'ऋण तथा सापटी प्राप्त (Loan Received)'
            : 'अन्य आम्दानी (Other Income)');

    const resolvedName =
      selectedCustomer?.name ||
      manualPayerOrLenderName.trim() ||
      resolvedTitle.split(' (')[0];

    recordCustomerCollection({
      partyId: selectedCustomerId || undefined,
      partyName: resolvedName,
      partyPhone: selectedCustomer?.phone || manualPayerPhone.trim() || undefined,
      partyAddress: selectedCustomer?.address || manualPayerAddress.trim() || undefined,
      incomeType: collectionEntryType,
      incomeCategory: resolvedTitle,
      dateBs: collectionDateBs || getTodayBsString(),
      amount: collectionAmount,
      paymentMode: collectionMode,
      bankAccountId: collectionMode === 'BANK' ? collectionBankId : undefined,
      referenceNo: finalRef,
      notes: collectionNotes.trim() || `${resolvedTitle} — ${resolvedName}`
    });

    triggerToast(
      collectionEntryType === 'LOAN_RECEIVED'
        ? isNe
          ? `✓ ऋण / सापटी आम्दानी (${resolvedTitle}) रु. ${collectionAmount} सफलतापूर्वक रेकर्ड गरियो!`
          : `✓ Loan received of Rs. ${collectionAmount} recorded!`
        : collectionEntryType === 'OTHER_INCOME'
        ? isNe
          ? `✓ अन्य आम्दानी (${resolvedTitle}) रु. ${collectionAmount} सफलतापूर्वक रेकर्ड गरियो!`
          : `✓ Other income of Rs. ${collectionAmount} recorded!`
        : isNe
        ? `✓ ग्राहक ${resolvedName} बाट रु. ${collectionAmount} असुली खातामा सुरक्षित गरियो!`
        : `✓ Collection of Rs. ${collectionAmount} recorded successfully!`
    );

    if (shouldPrint) {
      setPrintingVoucher({
        id: `rec-${Date.now()}`,
        voucherType: 'COLLECTION',
        voucherNo: finalRef,
        dateBs: collectionDateBs || getTodayBsString(),
        partyOrReceiverName: resolvedName,
        partyAddress: selectedCustomer?.address || manualPayerAddress.trim() || undefined,
        partyPhone: selectedCustomer?.phone || manualPayerPhone.trim() || undefined,
        categoryOrTitle: resolvedTitle,
        particulars:
          collectionNotes.trim() ||
          (collectionEntryType === 'LOAN_RECEIVED'
            ? isNe
              ? `ऋण / सापटी रकम प्राप्त (${resolvedTitle})`
              : `Loan / Borrowing Received (${resolvedTitle})`
            : collectionEntryType === 'OTHER_INCOME'
            ? isNe
              ? `अन्य आम्दानी रकम प्राप्त (${resolvedTitle})`
              : `Other Income Received (${resolvedTitle})`
            : isNe
            ? 'ग्राहकबाट बाँकी रकम असुली'
            : 'Amount received from customer'),
        amount: collectionAmount,
        paymentMode: collectionMode,
        bankName: collectionMode === 'BANK' && bankObj ? `${bankObj.bankName} (${bankObj.accountNumber})` : undefined,
        notes: collectionNotes
      });
    }

    setCollectionAmount(0);
    setCollectionRef('');
    setCollectionNotes('');
    setManualPayerOrLenderName('');
    setManualPayerPhone('');
    setManualPayerAddress('');
  };

  const handleCollectionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveAndOptionallyPrintCollection(false);
  };

  const saveAndOptionallyPrintPayment = (shouldPrint: boolean) => {
    if (!selectedSupplierId || paymentAmount <= 0) return;

    const finalRef = paymentRef.trim() || `PAY-${String(allPartyTransactions.length + 1).padStart(3, '0')}`;
    const bankObj = bankAccounts.find((b) => b.id === paymentBankId);

    recordPartyPayment({
      partyId: selectedSupplierId,
      amount: paymentAmount,
      dateBs: paymentDateBs || getTodayBsString(),
      paymentMode,
      bankAccountId: paymentMode === 'BANK' ? paymentBankId : undefined,
      referenceNo: finalRef,
      notes: paymentNotes
    });

    triggerToast(
      isNe
        ? `✓ आपूर्तिकर्ता ${selectedSupplier?.name || ''} लाई रु. ${paymentAmount} भुक्तानी खातामा सुरक्षित गरियो!`
        : `✓ Payment of Rs. ${paymentAmount} recorded successfully!`
    );

    if (shouldPrint && selectedSupplier) {
      setPrintingVoucher({
        id: `pay-${Date.now()}`,
        voucherType: 'PAYMENT',
        voucherNo: finalRef,
        dateBs: paymentDateBs || getTodayBsString(),
        partyOrReceiverName: selectedSupplier.name,
        partyAddress: selectedSupplier.address,
        partyPhone: selectedSupplier.phone,
        categoryOrTitle: isNe ? 'आपूर्तिकर्ता/साहु रकम भुक्तानी भौचर' : 'Supplier Payment Voucher',
        particulars: paymentNotes.trim() || (isNe ? 'आपूर्तिकर्तालाई रकम भुक्तानी' : 'Payment made to supplier'),
        amount: paymentAmount,
        paymentMode,
        bankName: paymentMode === 'BANK' && bankObj ? `${bankObj.bankName} (${bankObj.accountNumber})` : undefined,
        notes: paymentNotes
      });
    }

    setPaymentAmount(0);
    setPaymentRef('');
    setPaymentNotes('');
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveAndOptionallyPrintPayment(false);
  };

  const openEditCustomer = (party: Party) => {
    setEditingCustomer(party);
    setCustFormName(party.name);
    setCustFormAddress(party.address || '');
    setCustFormPhone(party.phone || '');
    setCustFormPan(party.panNo || '');
    setCustFormOpeningDue(party.currentBalance !== undefined ? party.currentBalance : party.openingBalance);
    setCustFormType(party.partyType || 'CUSTOMER');
    setIsCustomerModalOpen(true);
  };

  const openAddCustomer = () => {
    setEditingCustomer(null);
    setCustFormName('');
    setCustFormAddress('');
    setCustFormPhone('');
    setCustFormPan('');
    setCustFormOpeningDue(0);
    setCustFormType('CUSTOMER');
    setIsCustomerModalOpen(true);
  };

  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    const partyData: Party = {
      id: editingCustomer ? editingCustomer.id : `pty-${Date.now()}`,
      name: custFormName.trim(),
      address: custFormAddress.trim(),
      phone: custFormPhone.trim(),
      panNo: custFormPan.trim(),
      partyType: custFormType,
      openingBalance: custFormOpeningDue,
      currentBalance: custFormOpeningDue
    };

    saveParty(partyData);
    setIsCustomerModalOpen(false);
    triggerToast(
      isNe
        ? `ग्राहक/पार्टी ${partyData.name} को विवरण सुरक्षित गरियो!`
        : `Customer ${partyData.name} saved successfully!`
    );
  };

  const customerList = parties.filter((p) => p.partyType === 'CUSTOMER' || p.partyType === 'BOTH' || !p.partyType);
  const supplierList = parties.filter((p) => p.partyType === 'SUPPLIER' || p.partyType === 'BOTH');

  const filteredParties = parties.filter((p) => {
    const q = search.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      (p.address || '').toLowerCase().includes(q) ||
      (p.phone || '').includes(q) ||
      (p.panNo || '').includes(q)
    );
  });

  const filteredExpensesList = useMemo(() => {
    if (!expenseSearchQuery.trim()) return expenses;
    const q = expenseSearchQuery.trim().toLowerCase();
    return expenses.filter(
      (e) =>
        e.category.toLowerCase().includes(q) ||
        (e.description || '').toLowerCase().includes(q) ||
        (e.paidTo || '').toLowerCase().includes(q) ||
        (e.voucherNo || '').toLowerCase().includes(q) ||
        (e.notes || '').toLowerCase().includes(q) ||
        e.dateBs.includes(q)
    );
  }, [expenses, expenseSearchQuery]);

  const totalExpensesAmount = filteredExpensesList.reduce((sum, e) => sum + e.amount, 0);
  const todayExpensesAmount = expenses
    .filter((e) => e.dateBs === getTodayBsString())
    .reduce((sum, e) => sum + e.amount, 0);

  const handlePrintAllExpensesReport = (mode: 'PRINT' | 'DOWNLOAD') => {
    printOrDownloadReportPdf({
      company,
      titleNe: 'दैनिक खर्च भौचर विवरण रिपोर्ट (Daily Expenses Report)',
      titleEn: 'Daily Expenses Voucher Report',
      subtitleNe: `मिति: ${getTodayBsString()} | जम्मा खर्च संख्या: ${filteredExpensesList.length} | कुल खर्च रकम: ${formatCurrency(totalExpensesAmount, true)}`,
      headers: ['मिति (B.S.)', 'भौचर नं.', 'भुक्तानी पाउने (Paid To)', 'खर्च शीर्षक (Category)', 'विवरण (Particulars)', 'माध्यम', 'रकम (Rs.)'],
      rows: filteredExpensesList.map((e, idx) => [
        e.dateBs,
        e.voucherNo || `EXP-${String(expenses.length - idx).padStart(3, '0')}`,
        e.paidTo || '-',
        e.category,
        e.description || e.notes || '-',
        e.paymentMode === 'BANK' ? e.bankName || 'बैंक (Bank)' : 'नगद (Cash)',
        e.amount
      ]),
      summaryCards: [
        { label: 'आजको दैनिक खर्च (Today)', value: formatCurrency(todayExpensesAmount, true) },
        { label: 'कुल दैनिक खर्च (Total)', value: formatCurrency(totalExpensesAmount, true) },
        { label: 'जम्मा खर्च भौचर संख्या', value: `${filteredExpensesList.length} थान` }
      ],
      fileName: `Daily_Expenses_Report_${getTodayBsString()}`,
      mode
    });
  };

  return (
    <div className="space-y-5">
      {/* Toast Alert */}
      {successToast && (
        <div className="fixed top-20 right-5 z-50 bg-emerald-800 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-emerald-300" />
          <span className="text-xs font-bold">{successToast}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="bg-white p-4 sm:p-5 rounded-xl border border-slate-200 flex flex-col lg:flex-row lg:items-center justify-between gap-3 shadow-xs">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <Wallet className="w-6 h-6 text-emerald-700" />
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {isNe ? 'रकम असुली, भुक्तानी तथा दैनिक खर्च भौचर' : 'Vouchers, Daily Expenses & Collection'}
            </h1>
            <span className="px-2.5 py-0.5 text-[11px] font-bold bg-amber-100 text-amber-900 rounded-md border border-amber-300">
              {isNe ? 'दैनिक खर्च र भौचर प्रिन्ट सहित' : 'With Daily Expense & Voucher Print'}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {isNe
              ? 'दैनिक खर्च हाल्ने (खाजा, भाडा, इन्धन, मर्मत, ज्याला), ग्राहक असुली, पार्टी भुक्तानी र आधिकारिक भौचर प्रिन्ट/PDF'
              : 'Enter daily expenses, customer collections, supplier payments, and print official accounting vouchers'}
          </p>
        </div>

        {/* Quick Tabs + Direct Add Daily Expense CTA */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1.5 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveSubTab('EXPENSES')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'EXPENSES'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-amber-50 text-amber-900 border border-amber-300 hover:bg-amber-100'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>{isNe ? '+ दैनिक खर्च हाल्ने (Daily Expense)' : '+ Daily Expense'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('COLLECTION')}
            className={`px-3 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'COLLECTION'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <ArrowDownLeft className="w-3.5 h-3.5" />
            <span>{isNe ? 'आम्दानी / असुली / ऋण (Income & Loans)' : 'Income, Collection & Loans'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('PAYMENT')}
            className={`px-3 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'PAYMENT'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>{isNe ? 'पार्टी भुक्तानी (Payment)' : 'Payment'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('BANK_RECONCILIATION')}
            className={`px-3 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'BANK_RECONCILIATION'
                ? 'bg-emerald-800 text-white shadow-xs ring-1 ring-emerald-300'
                : 'text-slate-700 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isNe ? '🏦 बैंक भुक्तानी स्वतः मिलान' : 'Bank Auto-Reconcile'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('CASH_BOOK')}
            className={`px-3 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'CASH_BOOK'
                ? 'bg-emerald-900 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>{isNe ? 'दैनिक क्यासबुक (Cash Book)' : 'Cash Book'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('CUSTOMERS')}
            className={`px-3 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'CUSTOMERS'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>{isNe ? 'ग्राहक सूची (Customers)' : 'Customers'}</span>
          </button>
        </div>
      </div>

      {/* Quick Summary Banner with Instant Daily Expense & Voucher Print Info */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div
          onClick={() => setActiveSubTab('EXPENSES')}
          className={`p-4 rounded-xl border transition cursor-pointer flex items-center justify-between ${
            activeSubTab === 'EXPENSES'
              ? 'bg-amber-50/90 border-amber-400 shadow-xs'
              : 'bg-white border-slate-200 hover:border-amber-300'
          }`}
        >
          <div>
            <span className="text-xs font-bold text-amber-900 block">
              {isNe ? 'आजको दैनिक खर्च (Today Expense)' : "Today's Daily Expense"}
            </span>
            <span className="text-xl font-black font-mono text-amber-800 mt-0.5 block">
              {formatCurrency(todayExpensesAmount, isNe)}
            </span>
            <span className="text-[11px] text-slate-500">
              {isNe ? `कुल रेकर्ड खर्च: ${formatCurrency(totalExpensesAmount, isNe)}` : `Total Recorded: ${formatCurrency(totalExpensesAmount, isNe)}`}
            </span>
          </div>
          <span className="px-2.5 py-1.5 bg-amber-600 text-white rounded-lg text-xs font-bold shadow-2xs">
            {isNe ? '+ खर्च थप्नुहोस्' : '+ Add Expense'}
          </span>
        </div>

        <div
          onClick={() => setActiveSubTab('COLLECTION')}
          className={`p-4 rounded-xl border transition cursor-pointer flex items-center justify-between ${
            activeSubTab === 'COLLECTION'
              ? 'bg-emerald-50/90 border-emerald-400 shadow-xs'
              : 'bg-white border-slate-200 hover:border-emerald-300'
          }`}
        >
          <div>
            <span className="text-xs font-bold text-emerald-900 block">
              {isNe ? 'आम्दानी, ग्राहक असुली र ऋण प्राप्त (Income & Loans)' : 'Customer Collection, Other Income & Loans'}
            </span>
            <span className="text-xl font-black font-mono text-emerald-700 mt-0.5 block">
              {formatCurrency(
                partyTransactions
                  .filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER')
                  .reduce((s, t) => s + t.amount, 0),
                isNe
              )}
            </span>
            <span className="text-[11px] text-slate-500">
              {isNe
                ? `${partyTransactions.filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER').length} आम्दानी / असुली / ऋण रसिद`
                : `${partyTransactions.filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER').length} Receipt Vouchers`}
            </span>
          </div>
          <span className="px-2.5 py-1.5 bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs">
            {isNe ? '+ आम्दानी / ऋण' : '+ Add Income'}
          </span>
        </div>

        <div
          onClick={() => setActiveSubTab('PAYMENT')}
          className={`p-4 rounded-xl border transition cursor-pointer flex items-center justify-between ${
            activeSubTab === 'PAYMENT'
              ? 'bg-blue-50/90 border-blue-400 shadow-xs'
              : 'bg-white border-slate-200 hover:border-blue-300'
          }`}
        >
          <div>
            <span className="text-xs font-bold text-blue-900 block">
              {isNe ? 'सप्लायर भुक्तानी भौचर (Payment Vouchers)' : 'Supplier Payment Vouchers'}
            </span>
            <span className="text-xl font-black font-mono text-blue-800 mt-0.5 block">
              {formatCurrency(
                partyTransactions
                  .filter((t) => t.type === 'PAYMENT_TO_SUPPLIER')
                  .reduce((s, t) => s + t.amount, 0),
                isNe
              )}
            </span>
            <span className="text-[11px] text-slate-500">
              {isNe
                ? `${partyTransactions.filter((t) => t.type === 'PAYMENT_TO_SUPPLIER').length} भुक्तानी भौचर`
                : `${partyTransactions.filter((t) => t.type === 'PAYMENT_TO_SUPPLIER').length} Payment Vouchers`}
            </span>
          </div>
          <span className="px-2.5 py-1.5 bg-blue-700 text-white rounded-lg text-xs font-bold shadow-2xs">
            {isNe ? '+ भुक्तानी भौचर' : '+ Payment'}
          </span>
        </div>
      </div>

      {/* SECTION: DAILY EXPENSE RECORDING (दैनिक खर्च हाल्ने र भौचर प्रिन्ट गर्ने) */}
      {activeSubTab === 'EXPENSES' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Expense Form */}
          <div className="lg:col-span-5 bg-white p-5 rounded-xl border-2 border-amber-500/40 shadow-xs space-y-4">
            <div className="pb-2.5 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-100 text-amber-800 rounded-lg">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    {isNe ? 'दैनिक खर्च प्रविष्टि (Daily Expense Voucher)' : 'Record Daily Expense Voucher'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {isNe ? 'खर्च विवरण भरेर सेभ वा सिधै भौचर प्रिन्ट गर्नुहोस्' : 'Fill expense details to save or print voucher immediately'}
                  </p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold px-2 py-1 bg-amber-50 text-amber-900 border border-amber-200 rounded">
                {expenseVoucherNo || nextExpenseVoucherNo}
              </span>
            </div>

            <form onSubmit={handleExpenseSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isNe ? 'भौचर नं. (Voucher No.):' : 'Voucher No:'}
                  </label>
                  <div className="relative">
                    <Hash className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      value={expenseVoucherNo}
                      onChange={(e) => setExpenseVoucherNo(e.target.value)}
                      placeholder={nextExpenseVoucherNo}
                      className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                    />
                  </div>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isNe ? 'मिति (B.S.)*:' : 'Date (B.S.)*:'}
                  </label>
                  <DualDateInput valueBs={expenseDateBs} onChange={(bs) => setExpenseDateBs(bs)} isNe={isNe} className="items-start" />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isNe ? 'खर्च रकम (रु.)*:' : 'Expense Amount (Rs.)*:'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    step="any"
                    required
                    value={expenseAmount || ''}
                    onChange={(e) => setExpenseAmount(parseFloat(e.target.value) || 0)}
                    placeholder="रु. ०.००"
                    className="w-full px-3 py-2 border-2 border-amber-400 rounded-lg font-mono font-black text-base text-amber-950 bg-amber-50/40 focus:outline-none focus:border-amber-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isNe ? 'भुक्तानी पाउने व्यक्ति / फर्म (Paid To):' : 'Paid To (Person / Shop):'}
                  </label>
                  <div className="relative">
                    <User className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      value={expensePaidTo}
                      onChange={(e) => setExpensePaidTo(e.target.value)}
                      placeholder={isNe ? 'उदा: चिया पसल, पेट्रोल पम्प, राम बहादुर...' : 'e.g. Fuel Station, Tea Shop, Staff...'}
                      className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-lg font-medium text-slate-900"
                    />
                  </div>
                </div>
              </div>

              {expenseAmount > 0 && (
                <div className="px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] font-semibold text-amber-950">
                  {isNe
                    ? `अक्षरूपी: ${amountInNepaliWords(expenseAmount)}`
                    : `In Words: ${amountInEnglishWords(expenseAmount)}`}
                </div>
              )}

              <div className="p-3 bg-slate-50/90 border border-slate-200 rounded-xl space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="block font-bold text-slate-800">
                    {isNe ? 'खर्च शीर्षक (Expense Category)*:' : 'Expense Category*:'}
                  </label>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setExpenseCategoryMode('MANUAL');
                        setExpenseCategory('');
                      }}
                      className={`px-2 py-1 rounded text-[11px] font-bold border transition cursor-pointer ${
                        expenseCategoryMode === 'MANUAL'
                          ? 'bg-amber-600 text-white border-amber-600'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-amber-50'
                      }`}
                    >
                      ✏️ {isNe ? 'म्यानुअल लेख्ने (Manual)' : 'Type Manually'}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('settings');
                        setTimeout(() => {
                          window.dispatchEvent(
                            new CustomEvent('ims-sub-nav', {
                              detail: { target: 'settings', settingsTab: 'CATEGORIES' }
                            })
                          );
                        }, 50);
                      }}
                      className="px-2 py-1 rounded text-[11px] font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 transition cursor-pointer"
                      title={isNe ? 'मास्टर सेटिङबाट खर्च शीर्षक थप्ने वा सच्याउने' : 'Configure Expense Categories in Master Settings'}
                    >
                      ⚙️ {isNe ? 'मास्टर सेटिङमा मिलाउने' : 'Master Settings'}
                    </button>
                  </div>
                </div>

                {/* Dropdown selector from Master Settings + Manual Option */}
                <select
                  value={
                    expenseCategoryMode === 'MANUAL'
                      ? '__MANUAL__'
                      : activeExpenseCategories.some((c) => c.ne === expenseCategory || c.en === expenseCategory)
                      ? expenseCategory
                      : '__MANUAL__'
                  }
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val === '__MANUAL__') {
                      setExpenseCategoryMode('MANUAL');
                      setExpenseCategory('');
                    } else {
                      setExpenseCategoryMode('MASTER');
                      setExpenseCategory(val);
                    }
                  }}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900 cursor-pointer focus:outline-none focus:border-amber-600"
                >
                  <optgroup label={isNe ? 'मास्टर सेटिङका खर्च शीर्षकहरू (Master Categories)' : 'Master Expense Categories'}>
                    {activeExpenseCategories.map((preset) => {
                      const val = isNe ? preset.ne : preset.en;
                      return (
                        <option key={preset.id} value={val}>
                          {val}
                        </option>
                      );
                    })}
                  </optgroup>
                  <option value="__MANUAL__">
                    ✏️ {isNe ? 'अन्य / म्यानुअल आफैँ लेख्ने (Write Manually...)' : 'Type Custom Category Manually...'}
                  </option>
                </select>

                {/* Quick Preset Chips from Master Settings */}
                <div className="flex flex-wrap gap-1.5">
                  {activeExpenseCategories.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setExpenseCategoryMode('MASTER');
                        setExpenseCategory(isNe ? preset.ne : preset.en);
                      }}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-medium border transition cursor-pointer ${
                        expenseCategory === preset.ne || expenseCategory === preset.en
                          ? 'bg-amber-600 border-amber-600 text-white font-bold shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-amber-50 hover:border-amber-300'
                      }`}
                    >
                      {isNe ? preset.ne.split(' (')[0] : preset.en}
                    </button>
                  ))}
                </div>

                {/* Manual Text Input + Direct "+ मास्टरमा सेभ" Button */}
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    required
                    value={expenseCategory}
                    onChange={(e) => setExpenseCategory(e.target.value)}
                    placeholder={
                      isNe
                        ? 'यहाँ सिधै म्यानुअल खर्च शीर्षक लेख्नुहोस् (उदा: गोदाम मर्मत, कुरियर खर्च...)'
                        : 'Type custom expense category manually here...'
                    }
                    className="flex-1 px-3 py-2 bg-white border-2 border-amber-400/80 rounded-lg font-bold text-slate-900 focus:outline-none focus:border-amber-600"
                  />
                  {expenseCategory.trim() &&
                    !activeExpenseCategories.some(
                      (c) =>
                        c.ne.toLowerCase() === expenseCategory.trim().toLowerCase() ||
                        c.en.toLowerCase() === expenseCategory.trim().toLowerCase()
                    ) && (
                      <button
                        type="button"
                        onClick={() => {
                          const clean = expenseCategory.trim();
                          if (!clean) return;
                          const newEntry = {
                            id: `EXP_CAT_${Date.now()}`,
                            ne: clean,
                            en: clean
                          };
                          updateCompanyProfile({
                            ...company,
                            expenseCategories: [...activeExpenseCategories, newEntry]
                          });
                          setExpenseCategoryMode('MASTER');
                          triggerToast(
                            isNe
                              ? `✓ '${clean}' खर्च शीर्षक मास्टर सेटिङमा स्थायी रूपमा थपियो!`
                              : `✓ '${clean}' saved to Master Expense Categories!`
                          );
                        }}
                        className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg text-[11px] whitespace-nowrap cursor-pointer shadow-2xs"
                        title={isNe ? 'यो नयाँ खर्च शीर्षक मास्टर सेटिङमा सुरक्षित गर्नुहोस्' : 'Save this category to Master Settings'}
                      >
                        + {isNe ? 'मास्टरमा सेभ' : 'Save to Master'}
                      </button>
                    )}
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNe ? 'खर्चको विस्तृत विवरण (Particulars / Description):' : 'Description / Particulars:'}
                </label>
                <input
                  type="text"
                  value={expenseDesc}
                  onChange={(e) => setExpenseDesc(e.target.value)}
                  placeholder={isNe ? 'जस्तै: वर्कसप स्टाफ चिया खाजा वा डेलिभरी डिजेल ५ लिटर' : 'Details of the daily expense'}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNe ? 'भुक्तानी माध्यम (Payment Mode):' : 'Payment Mode:'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setExpenseMode('CASH')}
                    className={`py-2 rounded-lg font-bold border transition cursor-pointer ${
                      expenseMode === 'CASH'
                        ? 'bg-amber-700 text-white border-amber-700 shadow-2xs'
                        : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    💵 {isNe ? 'काउन्टर नगद (Cash)' : 'Cash'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setExpenseMode('BANK')}
                    className={`py-2 rounded-lg font-bold border transition cursor-pointer ${
                      expenseMode === 'BANK'
                        ? 'bg-amber-700 text-white border-amber-700 shadow-2xs'
                        : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    🏦 {isNe ? 'बैंक / QR भुक्तानी' : 'Bank / QR'}
                  </button>
                </div>
              </div>

              {expenseMode === 'BANK' && (
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isNe ? 'बैंक खाता छान्नुहोस्:' : 'Select Bank Account:'}
                  </label>
                  <select
                    value={expenseBankId}
                    onChange={(e) => setExpenseBankId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white font-semibold text-slate-900"
                  >
                    {bankAccounts.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.bankName} ({b.accountNumber}) - मौज्दात: रु. {b.currentBalance.toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNe ? 'कैफियत / बिल नं. (Notes / Bill Ref):' : 'Notes / Bill Ref:'}
                </label>
                <input
                  type="text"
                  value={expenseNotes}
                  onChange={(e) => setExpenseNotes(e.target.value)}
                  placeholder={isNe ? 'पसलको बिल नं. वा अतिरिक्त टिपोट...' : 'Optional bill ref or notes...'}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                <button
                  type="submit"
                  disabled={expenseAmount <= 0 || !expenseCategory.trim()}
                  className="py-3 px-3 bg-amber-700 hover:bg-amber-800 disabled:opacity-50 text-white font-bold rounded-xl shadow-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isNe ? 'दैनिक खर्च सुरक्षित (Save)' : 'Save Expense'}</span>
                </button>

                <button
                  type="button"
                  disabled={expenseAmount <= 0 || !expenseCategory.trim()}
                  onClick={() => saveAndOptionallyPrintExpense(true)}
                  className="py-3 px-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold rounded-xl shadow-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Printer className="w-4 h-4 text-amber-400" />
                  <span>{isNe ? 'सुरक्षित गरी भौचर प्रिन्ट' : 'Save & Print Voucher'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Expenses List with Individual Voucher Print & Full Report Print */}
          <div className="lg:col-span-7 bg-white p-5 rounded-xl border border-slate-200 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {isNe ? 'दैनिक खर्च भौचरहरूको विवरण (Daily Expense Vouchers)' : 'Daily Expense Vouchers'}
                </h3>
                <p className="text-[11px] text-slate-500">
                  {isNe ? 'प्रत्येक खर्चको छेउमा रहेको "🖨️ भौचर प्रिन्ट" थिचेर भौचर प्रिन्ट वा PDF सेभ गर्नुहोस्' : 'Click Print Voucher on any row to print or download official voucher'}
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => handlePrintAllExpensesReport('DOWNLOAD')}
                  disabled={filteredExpensesList.length === 0}
                  className="px-2.5 py-1.5 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer shadow-2xs"
                >
                  <FileDown className="w-3.5 h-3.5" />
                  <span>{isNe ? 'खर्च सूची PDF' : 'Expenses PDF'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => handlePrintAllExpensesReport('PRINT')}
                  disabled={filteredExpensesList.length === 0}
                  className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer shadow-2xs"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isNe ? 'सबै खर्च प्रिन्ट' : 'Print List'}</span>
                </button>
              </div>
            </div>

            {/* Search & Total Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={expenseSearchQuery}
                  onChange={(e) => setExpenseSearchQuery(e.target.value)}
                  placeholder={isNe ? 'भौचर नं., खर्च शीर्षक, व्यक्ति वा मिति खोज्नुहोस्...' : 'Search expense by category, payee, date...'}
                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs focus:outline-none focus:border-amber-600"
                />
              </div>
              <div className="text-right px-2">
                <span className="text-[10px] text-slate-500 block">{isNe ? 'कुल दैनिक खर्च जम्मा:' : 'Total Filtered Expense:'}</span>
                <span className="text-sm font-mono font-black text-amber-800">
                  {formatCurrency(totalExpensesAmount, isNe)}
                </span>
              </div>
            </div>

            {filteredExpensesList.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                {isNe ? 'हालसम्म कुनै दैनिक खर्च प्रविष्टि गरिएको छैन। बायाँतर्फको फारमबाट खर्च हाल्नुहोस्।' : 'No daily expenses recorded yet.'}
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[460px]">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold sticky top-0">
                    <tr>
                      <th className="py-2.5 px-2.5">{isNe ? 'भौचर / मिति' : 'Voucher / Date'}</th>
                      <th className="py-2.5 px-2.5">{isNe ? 'खर्च शीर्षक र भुक्तानी पाउने' : 'Category & Payee'}</th>
                      <th className="py-2.5 px-2.5">{isNe ? 'विवरण' : 'Particulars'}</th>
                      <th className="py-2.5 px-2.5">{isNe ? 'माध्यम' : 'Mode'}</th>
                      <th className="py-2.5 px-2.5 text-right">{isNe ? 'रकम (Rs.)' : 'Amount'}</th>
                      <th className="py-2.5 px-2.5 text-center">{isNe ? 'भौचर प्रिन्ट / कार्य' : 'Print / Action'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredExpensesList.map((e, idx) => {
                      const vNo = e.voucherNo || `EXP-${String(expenses.length - idx).padStart(3, '0')}`;
                      return (
                        <tr key={e.id} className="hover:bg-amber-50/40 transition">
                          <td className="py-2.5 px-2.5 font-mono">
                            <div className="font-bold text-slate-900">{vNo}</div>
                            <div className="text-[10px] text-slate-500">{e.dateBs}</div>
                          </td>
                          <td className="py-2.5 px-2.5">
                            <div className="font-bold text-slate-900">{e.category}</div>
                            {e.paidTo && (
                              <div className="text-[11px] text-emerald-800 font-semibold">👤 {e.paidTo}</div>
                            )}
                          </td>
                          <td className="py-2.5 px-2.5 text-slate-600">{e.description || e.notes || '-'}</td>
                          <td className="py-2.5 px-2.5 font-mono text-[11px]">
                            <span
                              className={`px-2 py-0.5 rounded font-bold ${
                                e.paymentMode === 'BANK'
                                  ? 'bg-blue-50 text-blue-800 border border-blue-200'
                                  : 'bg-amber-50 text-amber-900 border border-amber-200'
                              }`}
                            >
                              {e.paymentMode === 'BANK' ? (isNe ? 'बैंक' : 'Bank') : (isNe ? 'नगद' : 'Cash')}
                            </span>
                          </td>
                          <td className="py-2.5 px-2.5 text-right font-mono font-bold text-amber-800">
                            {formatCurrency(e.amount, isNe)}
                          </td>
                          <td className="py-2.5 px-2.5 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => setPrintingVoucher(buildExpenseVoucherData(e, expenses.length - idx))}
                                className="px-2.5 py-1 bg-slate-900 hover:bg-emerald-800 text-white rounded-md text-[11px] font-bold flex items-center gap-1 cursor-pointer shadow-2xs transition"
                                title={isNe ? 'भौचर प्रिन्ट वा PDF डाउनलोड गर्नुहोस्' : 'Print or Download Expense Voucher'}
                              >
                                <Printer className="w-3 h-3 text-amber-300" />
                                <span>{isNe ? 'भौचर प्रिन्ट' : 'Print'}</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => deleteExpense(e.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                                title={isNe ? 'खर्च मेटाउनुहोस्' : 'Delete Expense'}
                              >
                                <Trash2 className="w-3.5 h-3.5 inline" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 1: CUSTOMER DUE COLLECTION + OTHER INCOME + LOANS RECEIVED */}
      {activeSubTab === 'COLLECTION' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-6 bg-white p-5 rounded-xl border-2 border-emerald-500/40 shadow-xs space-y-4">
            <div className="pb-2.5 border-b border-slate-200 flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded-lg">
                  <ArrowDownLeft className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    {isNe
                      ? 'आम्दानी, ग्राहक असुली, अन्य आम्दानी तथा ऋण प्रविष्टि'
                      : 'Record Customer Collection, Other Income & Loans'}
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {isNe
                      ? 'ग्राहक बक्यौता असुली, अन्य सेवा/भाडा/अनुदान आम्दानी वा बैंक/व्यक्तिगत ऋण प्राप्त'
                      : 'Customer due receipts, service/rental/grant income, or bank/personal loans received'}
                  </p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold px-2.5 py-1 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded">
                मिति: {collectionDateBs}
              </span>
            </div>

            {/* 3-Way Income / Receipt Type Selector */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 bg-slate-100 p-1.5 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => {
                  setCollectionEntryType('CUSTOMER_COLLECTION');
                }}
                className={`py-2 px-2.5 rounded-lg font-bold transition cursor-pointer text-center ${
                  collectionEntryType === 'CUSTOMER_COLLECTION'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-emerald-50'
                }`}
              >
                👥 {isNe ? 'ग्राहक बक्यौता असुली' : 'Customer Collection'}
              </button>

              <button
                type="button"
                onClick={() => {
                  setCollectionEntryType('OTHER_INCOME');
                  const firstOther = activeIncomeCategories.find((c) => c.incomeType !== 'LOAN_RECEIVED') || DEFAULT_INCOME_CATEGORIES[0];
                  setIncomeCategoryInput(isNe ? firstOther.ne : firstOther.en);
                  setSelectedCustomerId('');
                }}
                className={`py-2 px-2.5 rounded-lg font-bold transition cursor-pointer text-center ${
                  collectionEntryType === 'OTHER_INCOME'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-teal-50'
                }`}
              >
                💰 {isNe ? 'अन्य आम्दानी (Other Income)' : 'Other Income'}
              </button>

              <button
                type="button"
                onClick={() => {
                  setCollectionEntryType('LOAN_RECEIVED');
                  const firstLoan = activeIncomeCategories.find((c) => c.incomeType === 'LOAN_RECEIVED') || DEFAULT_INCOME_CATEGORIES[6];
                  setIncomeCategoryInput(isNe ? firstLoan.ne : firstLoan.en);
                  setSelectedCustomerId('');
                }}
                className={`py-2 px-2.5 rounded-lg font-bold transition cursor-pointer text-center ${
                  collectionEntryType === 'LOAN_RECEIVED'
                    ? 'bg-indigo-700 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-indigo-50'
                }`}
              >
                🏦 {isNe ? 'ऋण / सापटी प्राप्त (Loan)' : 'Loans / Borrowings'}
              </button>
            </div>

            <form onSubmit={handleCollectionSubmit} className="space-y-3.5 text-xs">
              {/* If OTHER_INCOME or LOAN_RECEIVED: Category Selector (Master + Manual) */}
              {collectionEntryType !== 'CUSTOMER_COLLECTION' && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="font-bold text-slate-800">
                      {collectionEntryType === 'LOAN_RECEIVED'
                        ? isNe
                          ? '🏦 ऋण / सापटीको शीर्षक (Loan / Borrowing Category)*:'
                          : 'Loan / Borrowing Category*:'
                        : isNe
                        ? '💰 अन्य आम्दानीको शीर्षक (Other Income Category)*:'
                        : 'Other Income Category*:'}
                    </label>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setIncomeCategoryMode('MANUAL');
                          setIncomeCategoryInput('');
                        }}
                        className={`px-2 py-1 rounded text-[11px] font-bold border transition cursor-pointer ${
                          incomeCategoryMode === 'MANUAL'
                            ? 'bg-emerald-700 text-white border-emerald-700'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-emerald-50'
                        }`}
                      >
                        ✏️ {isNe ? 'म्यानुअल लेख्ने' : 'Type Manually'}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setActiveTab('settings');
                          setTimeout(() => {
                            window.dispatchEvent(
                              new CustomEvent('ims-sub-nav', {
                                detail: { target: 'settings', settingsTab: 'CATEGORIES' }
                              })
                            );
                          }, 50);
                        }}
                        className="px-2 py-1 rounded text-[11px] font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 transition cursor-pointer"
                      >
                        ⚙️ {isNe ? 'मास्टर सेटिङ' : 'Master Settings'}
                      </button>
                    </div>
                  </div>

                  {/* Quick Category Chips */}
                  <div className="flex flex-wrap gap-1.5">
                    {activeIncomeCategories
                      .filter((c) =>
                        collectionEntryType === 'LOAN_RECEIVED'
                          ? c.incomeType === 'LOAN_RECEIVED'
                          : c.incomeType !== 'LOAN_RECEIVED'
                      )
                      .map((preset) => {
                        const val = isNe ? preset.ne : preset.en;
                        return (
                          <button
                            key={preset.id}
                            type="button"
                            onClick={() => {
                              setIncomeCategoryMode('MASTER');
                              setIncomeCategoryInput(val);
                            }}
                            className={`px-2.5 py-1 rounded-md text-[11px] font-medium border transition cursor-pointer ${
                              incomeCategoryInput === preset.ne || incomeCategoryInput === preset.en
                                ? 'bg-emerald-700 border-emerald-700 text-white font-bold shadow-2xs'
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-emerald-50 hover:border-emerald-300'
                            }`}
                          >
                            {isNe ? preset.ne.split(' (')[0] : preset.en}
                          </button>
                        );
                      })}
                  </div>

                  {/* Manual Input + Save to Master */}
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      required
                      value={incomeCategoryInput}
                      onChange={(e) => setIncomeCategoryInput(e.target.value)}
                      placeholder={
                        collectionEntryType === 'LOAN_RECEIVED'
                          ? isNe
                            ? 'ऋण वा सापटीको शीर्षक लेख्नुहोस् (उदा: कृषि विकास बैंक ऋण, राम सापटी...)'
                            : 'Type loan or borrowing category...'
                          : isNe
                          ? 'अन्य आम्दानीको शीर्षक लेख्नुहोस् (उदा: टिलर मर्मत आम्दानी, सरकारी अनुदान...)'
                          : 'Type other income category...'
                      }
                      className="flex-1 px-3 py-2 bg-white border-2 border-emerald-400 rounded-lg font-bold text-slate-900 focus:outline-none focus:border-emerald-700"
                    />
                    {incomeCategoryInput.trim() &&
                      !activeIncomeCategories.some(
                        (c) =>
                          c.ne.toLowerCase() === incomeCategoryInput.trim().toLowerCase() ||
                          c.en.toLowerCase() === incomeCategoryInput.trim().toLowerCase()
                      ) && (
                        <button
                          type="button"
                          onClick={() => {
                            const clean = incomeCategoryInput.trim();
                            if (!clean) return;
                            const newCat = {
                              id: `INC_CAT_${Date.now()}`,
                              ne: clean,
                              en: clean,
                              incomeType: collectionEntryType === 'LOAN_RECEIVED' ? ('LOAN_RECEIVED' as const) : ('OTHER_INCOME' as const)
                            };
                            updateCompanyProfile({
                              ...company,
                              incomeCategories: [...activeIncomeCategories, newCat]
                            });
                            setIncomeCategoryMode('MASTER');
                            triggerToast(
                              isNe
                                ? `✓ '${clean}' आम्दानी/ऋण शीर्षक मास्टर सेटिङमा थपियो!`
                                : `✓ '${clean}' saved to Master Income Categories!`
                            );
                          }}
                          className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg text-[11px] whitespace-nowrap cursor-pointer"
                        >
                          + {isNe ? 'मास्टरमा सेभ' : 'Save to Master'}
                        </button>
                      )}
                  </div>
                </div>
              )}

              {/* Customer / Source / Lender Selection */}
              {collectionEntryType === 'CUSTOMER_COLLECTION' ? (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'ग्राहक छान्नुहोस् (Select Customer)*' : 'Select Customer*'}
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={selectedCustomerId}
                      onChange={(e) => {
                        setSelectedCustomerId(e.target.value);
                        const c = parties.find((p) => p.id === e.target.value);
                        if (c) {
                          setCollectionAmount(c.currentBalance !== undefined ? c.currentBalance : c.openingBalance);
                        }
                      }}
                      className="flex-1 px-3 py-2 border border-slate-300 rounded-lg bg-white font-medium text-xs"
                    >
                      <option value="">-- ग्राहकको नाम छान्नुहोस् --</option>
                      {customerList.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} — 📍 {c.address || 'ठेगाना नभएको'} [बाँकी: रु. {c.currentBalance ?? c.openingBalance}]
                        </option>
                      ))}
                    </select>

                    {selectedCustomer && (
                      <button
                        type="button"
                        onClick={() => openEditCustomer(selectedCustomer)}
                        className="px-2.5 py-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer shrink-0"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>{isNe ? 'सच्याउने' : 'Edit'}</span>
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {collectionEntryType === 'LOAN_RECEIVED'
                        ? isNe
                          ? 'ऋण / सापटी दिने व्यक्ति वा बैंकको नाम*:'
                          : 'Lender / Bank / Institution Name*:'
                        : isNe
                        ? 'रकम बुझाउने व्यक्ति / संस्थाको नाम:'
                        : 'Received From (Person / Organization):'}
                    </label>
                    <input
                      type="text"
                      value={manualPayerOrLenderName}
                      onChange={(e) => setManualPayerOrLenderName(e.target.value)}
                      placeholder={
                        collectionEntryType === 'LOAN_RECEIVED'
                          ? isNe
                            ? 'उदा: राष्ट्रिय वाणिज्य बैंक / हरि प्रसाद शर्मा...'
                            : 'e.g. Nabil Bank / Lender Name...'
                          : isNe
                          ? 'उदा: किसान समूह / नगरपालिका अनुदान / ग्राहक...'
                          : 'e.g. Payer or Grant Office...'
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-semibold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {isNe ? 'सम्पर्क फोन / ठेगाना (ऐच्छिक):' : 'Phone / Address (Optional):'}
                    </label>
                    <input
                      type="text"
                      value={manualPayerPhone}
                      onChange={(e) => setManualPayerPhone(e.target.value)}
                      placeholder={isNe ? 'फोन नं. वा ठेगाना...' : 'Phone or address...'}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {collectionEntryType === 'LOAN_RECEIVED'
                      ? isNe
                        ? 'प्राप्त ऋण / सापटी रकम (रु.)*'
                        : 'Loan Amount (Rs.)*'
                      : collectionEntryType === 'OTHER_INCOME'
                      ? isNe
                        ? 'आम्दानी रकम (रु.)*'
                        : 'Income Amount (Rs.)*'
                      : isNe
                      ? 'असुली रकम (रु.)*'
                      : 'Collection Amount (Rs.)*'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    step="any"
                    required
                    value={collectionAmount || ''}
                    onChange={(e) => setCollectionAmount(parseFloat(e.target.value) || 0)}
                    placeholder="रु. ०.००"
                    className="w-full px-3 py-2 border-2 border-emerald-400 rounded-lg font-mono font-black text-sm text-emerald-950 bg-emerald-50/40"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'मिति (B.S.)*' : 'Date (B.S.)*'}
                  </label>
                  <DualDateInput valueBs={collectionDateBs} onChange={(bs) => setCollectionDateBs(bs)} isNe={isNe} className="items-start" />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">भुक्तानी माध्यम (Mode)*</label>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setCollectionMode('CASH')}
                      className={`py-2 px-2 text-center rounded-lg font-bold border transition cursor-pointer ${
                        collectionMode === 'CASH'
                          ? 'bg-emerald-700 text-white border-emerald-700'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {isNe ? 'नगद (Cash)' : 'Cash'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setCollectionMode('BANK')}
                      className={`py-2 px-2 text-center rounded-lg font-bold border transition cursor-pointer ${
                        collectionMode === 'BANK'
                          ? 'bg-emerald-700 text-white border-emerald-700'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {isNe ? 'बैंक/QR' : 'Bank'}
                    </button>
                  </div>
                </div>
              </div>

              {collectionAmount > 0 && (
                <div className="px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg text-[11px] font-semibold text-emerald-950">
                  {isNe
                    ? `अक्षरूपी: ${amountInNepaliWords(collectionAmount)}`
                    : `In Words: ${amountInEnglishWords(collectionAmount)}`}
                </div>
              )}

              {collectionMode === 'BANK' && (
                <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2">
                  <label className="block text-[11px] font-semibold text-blue-950">
                    जम्मा भएको बैंक खाता छान्नुहोस्:
                  </label>
                  <select
                    value={collectionBankId}
                    onChange={(e) => setCollectionBankId(e.target.value)}
                    className="w-full px-3 py-2 border border-blue-300 rounded-lg bg-white font-medium text-xs text-slate-900"
                  >
                    {bankAccounts.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.bankName} ({acc.accountNumber}) - हाल मौज्दात: रु. {acc.currentBalance.toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">रसिद / भौचर नं.</label>
                  <input
                    type="text"
                    placeholder={
                      collectionEntryType === 'LOAN_RECEIVED'
                        ? 'LOAN-001'
                        : collectionEntryType === 'OTHER_INCOME'
                        ? 'INC-001'
                        : 'REC-104'
                    }
                    value={collectionRef}
                    onChange={(e) => setCollectionRef(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">कैफियत / विवरण (Particulars)</label>
                  <input
                    type="text"
                    placeholder={
                      collectionEntryType === 'LOAN_RECEIVED'
                        ? 'व्याजदर, अवधि वा सापटी सर्त...'
                        : collectionEntryType === 'OTHER_INCOME'
                        ? 'आम्दानीको छोटो विवरण...'
                        : 'बाँकी चुक्ता वा आंशिक असुली'
                    }
                    value={collectionNotes}
                    onChange={(e) => setCollectionNotes(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="submit"
                  disabled={
                    collectionAmount <= 0 ||
                    (collectionEntryType === 'CUSTOMER_COLLECTION' && !selectedCustomerId && !manualPayerOrLenderName.trim())
                  }
                  className="py-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer text-xs"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {collectionEntryType === 'LOAN_RECEIVED'
                      ? isNe
                        ? 'ऋण / सापटी सुरक्षित (Save Loan)'
                        : 'Save Loan Received'
                      : collectionEntryType === 'OTHER_INCOME'
                      ? isNe
                        ? 'अन्य आम्दानी सुरक्षित (Save Income)'
                        : 'Save Other Income'
                      : isNe
                      ? 'असुली सुरक्षित (Save Collection)'
                      : 'Record Collection'}
                  </span>
                </button>

                <button
                  type="button"
                  disabled={
                    collectionAmount <= 0 ||
                    (collectionEntryType === 'CUSTOMER_COLLECTION' && !selectedCustomerId && !manualPayerOrLenderName.trim())
                  }
                  onClick={() => saveAndOptionallyPrintCollection(true)}
                  className="py-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer text-xs"
                >
                  <Printer className="w-4 h-4 text-emerald-400" />
                  <span>{isNe ? 'सुरक्षित गरी रसिद प्रिन्ट' : 'Save & Print Receipt'}</span>
                </button>
              </div>
            </form>
          </div>

          <div className="lg:col-span-6 bg-white p-5 rounded-xl border border-slate-200 space-y-3 flex flex-col">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 flex-wrap gap-2">
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg text-xs">
                <button
                  type="button"
                  onClick={() => setCollectionRightTab('VOUCHERS')}
                  className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                    collectionRightTab === 'VOUCHERS'
                      ? 'bg-emerald-700 text-white'
                      : 'text-slate-700 hover:bg-white'
                  }`}
                >
                  📋 {isNe ? 'आम्दानी / असुली / ऋण रसिदहरू' : 'All Income & Loan Receipts'}
                </button>
                <button
                  type="button"
                  onClick={() => setCollectionRightTab('CUSTOMER_DUES')}
                  className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                    collectionRightTab === 'CUSTOMER_DUES'
                      ? 'bg-emerald-700 text-white'
                      : 'text-slate-700 hover:bg-white'
                  }`}
                >
                  👥 {isNe ? 'उठाउन बाँकी ग्राहकहरू' : 'Customer Dues'}
                </button>
              </div>

              <button
                onClick={openAddCustomer}
                className="text-xs font-semibold text-emerald-700 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isNe ? 'नयाँ ग्राहक' : 'Add Customer'}</span>
              </button>
            </div>

            {collectionRightTab === 'VOUCHERS' ? (
              <div className="overflow-y-auto max-h-[460px] divide-y divide-slate-100 pr-1">
                {partyTransactions.filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER').length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400">
                    {isNe
                      ? 'हालसम्म कुनै आम्दानी, असुली वा ऋण भौचर रेकर्ड भएको छैन।'
                      : 'No income, collection, or loan receipts recorded yet.'}
                  </div>
                ) : (
                  partyTransactions
                    .filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER')
                    .map((tx) => {
                      const badge =
                        tx.incomeType === 'LOAN_RECEIVED'
                          ? { label: isNe ? '🏦 ऋण / सापटी' : 'Loan', cls: 'bg-indigo-100 text-indigo-900 border-indigo-300' }
                          : tx.incomeType === 'OTHER_INCOME'
                          ? { label: isNe ? '💰 अन्य आम्दानी' : 'Other Income', cls: 'bg-teal-100 text-teal-900 border-teal-300' }
                          : { label: isNe ? '👥 ग्राहक असुली' : 'Collection', cls: 'bg-emerald-100 text-emerald-900 border-emerald-300' };
                      return (
                        <div
                          key={tx.id}
                          className="p-2.5 hover:bg-slate-50 rounded-lg transition flex items-center justify-between gap-2 text-xs"
                        >
                          <div className="space-y-0.5 min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${badge.cls}`}>
                                {badge.label}
                              </span>
                              <span className="font-bold text-slate-900 truncate">{tx.partyName}</span>
                              <span className="font-mono text-[10px] text-slate-500">({tx.dateBs})</span>
                            </div>
                            <div className="text-[11px] text-slate-600 truncate">
                              {tx.incomeCategory ? `${tx.incomeCategory} — ` : ''}
                              {tx.notes || ''}
                            </div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <div className="text-right">
                              <div className="font-mono font-black text-emerald-800">
                                {formatCurrency(tx.amount, isNe)}
                              </div>
                              <div className="text-[10px] text-slate-500">
                                {tx.paymentMode === 'BANK' ? tx.bankName || 'बैंक' : 'नगद'}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => setPrintingVoucher(buildPartyTxVoucherData(tx))}
                              className="px-2.5 py-1.5 bg-slate-900 hover:bg-emerald-800 text-white rounded-md text-[11px] font-bold flex items-center gap-1 cursor-pointer shadow-2xs"
                              title={isNe ? 'रसिद / भौचर प्रिन्ट वा PDF सेभ' : 'Print Receipt Voucher'}
                            >
                              <Printer className="w-3 h-3 text-emerald-300" />
                              <span>{isNe ? 'रसिद प्रिन्ट' : 'Print'}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => deletePartyTransaction(tx.id)}
                              className="p-1.5 text-rose-700 hover:bg-rose-50 rounded-md cursor-pointer"
                              title={isNe ? 'रसिद मेटाउनुहोस्' : 'Delete Receipt'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })
                )}
              </div>
            ) : (
              <div className="overflow-y-auto max-h-[460px] divide-y divide-slate-100 pr-1">
                {customerList
                  .filter((c) => (c.currentBalance ?? c.openingBalance) > 0)
                  .map((c) => (
                    <div
                      key={c.id}
                      onClick={() => {
                        setCollectionEntryType('CUSTOMER_COLLECTION');
                        setSelectedCustomerId(c.id);
                        setCollectionAmount(c.currentBalance ?? c.openingBalance);
                      }}
                      className={`p-2.5 rounded-lg transition cursor-pointer flex items-center justify-between text-xs ${
                        selectedCustomerId === c.id ? 'bg-emerald-50 border border-emerald-200' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-slate-900">{c.name}</div>
                        <div className="text-[10px] text-slate-500">📍 {c.address}</div>
                      </div>
                      <div className="text-right font-mono font-bold text-rose-700">
                        {formatCurrency(c.currentBalance ?? c.openingBalance, isNe)}
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: SUPPLIER PAYMENT */}
      {activeSubTab === 'PAYMENT' && (
        <div className="max-w-2xl mx-auto bg-white p-5 rounded-xl border border-slate-200 space-y-4">
          <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-200 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <ArrowUpRight className="w-4 h-4 text-blue-700" />
              {isNe ? 'आपूर्तिकर्ता/पार्टीलाई रकम भुक्तानी (Payment Voucher)' : 'Supplier Payment Voucher'}
            </span>
            <span className="text-xs font-mono text-slate-500">मिति: {getTodayBsString()}</span>
          </h3>

          <form onSubmit={handlePaymentSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                आपूर्तिकर्ता छान्नुहोस् (Select Supplier)*
              </label>
              <select
                value={selectedSupplierId}
                onChange={(e) => {
                  setSelectedSupplierId(e.target.value);
                  const s = parties.find((p) => p.id === e.target.value);
                  if (s) {
                    setPaymentAmount(s.currentBalance ?? s.openingBalance);
                  }
                }}
                required
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white font-medium text-xs"
              >
                <option value="">-- सप्लायर छान्नुहोस् --</option>
                {supplierList.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} - 📍 {s.address} [तिर्न बाँकी: रु. {s.currentBalance ?? s.openingBalance}]
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">भुक्तानी रकम (रु.)*</label>
                <input
                  type="number"
                  min={1}
                  required
                  value={paymentAmount || ''}
                  onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                  placeholder="रु. ०.००"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold text-sm text-blue-950"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">भुक्तानी माध्यम (Mode)*</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMode('CASH')}
                    className={`py-2 px-2 text-center rounded-lg font-bold border transition cursor-pointer ${
                      paymentMode === 'CASH'
                        ? 'bg-blue-700 text-white border-blue-700'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {isNe ? 'नगद (Cash)' : 'Cash'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMode('BANK')}
                    className={`py-2 px-2 text-center rounded-lg font-bold border transition cursor-pointer ${
                      paymentMode === 'BANK'
                        ? 'bg-blue-700 text-white border-blue-700'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {isNe ? 'बैंक ट्रान्सफर/चेक' : 'Bank Transfer'}
                  </button>
                </div>
              </div>
            </div>

            {paymentAmount > 0 && (
              <div className="px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg text-[11px] font-semibold text-blue-950">
                {isNe
                  ? `अक्षरूपी: ${amountInNepaliWords(paymentAmount)}`
                  : `In Words: ${amountInEnglishWords(paymentAmount)}`}
              </div>
            )}

            {paymentMode === 'BANK' && (
              <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2">
                <label className="block text-[11px] font-semibold text-blue-950">बैंक खाता छान्नुहोस्:</label>
                <select
                  value={paymentBankId}
                  onChange={(e) => setPaymentBankId(e.target.value)}
                  className="w-full px-3 py-2 border border-blue-300 rounded-lg bg-white font-medium text-xs text-slate-900"
                >
                  {bankAccounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.bankName} ({acc.accountNumber}) - मौज्दात: रु. {acc.currentBalance.toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                {isNe ? 'भुक्तानी मिति (B.S. / A.D.)*' : 'Payment Date (B.S. / A.D.)*'}
              </label>
              <DualDateInput valueBs={paymentDateBs} onChange={(bs) => setPaymentDateBs(bs)} isNe={isNe} className="items-start" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">चेक नं. / भौचर नं.</label>
                <input
                  type="text"
                  value={paymentRef}
                  onChange={(e) => setPaymentRef(e.target.value)}
                  placeholder="PAY-101"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">कैफियत (Remarks)</label>
                <input
                  type="text"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="submit"
                disabled={!selectedSupplierId || paymentAmount <= 0}
                className="py-3 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer text-xs"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isNe ? 'भुक्तानी सुरक्षित (Save Payment)' : 'Save Payment'}</span>
              </button>

              <button
                type="button"
                disabled={!selectedSupplierId || paymentAmount <= 0}
                onClick={() => saveAndOptionallyPrintPayment(true)}
                className="py-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer text-xs"
              >
                <Printer className="w-4 h-4 text-blue-400" />
                <span>{isNe ? 'सुरक्षित गरी भौचर प्रिन्ट' : 'Save & Print Voucher'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* SECTION 3: CUSTOMER DIRECTORY */}
      {activeSubTab === 'CUSTOMERS' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {isNe ? 'ग्राहक तथा पार्टी विवरण (Customer Directory)' : 'Customer Directory'}
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
                <input
                  type="text"
                  placeholder="ग्राहक वा ठेगाना खोज्नुहोस्..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none"
                />
              </div>
              <button
                onClick={openAddCustomer}
                className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-xs flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isNe ? 'नयाँ ग्राहक थप्नुहोस्' : 'Add Customer'}</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold">
                <tr>
                  <th className="py-2.5 px-3">क्र.सं.</th>
                  <th className="py-2.5 px-3">ग्राहकको नाम</th>
                  <th className="py-2.5 px-3">ठेगाना</th>
                  <th className="py-2.5 px-3">फोन</th>
                  <th className="py-2.5 px-3">प्यान नं.</th>
                  <th className="py-2.5 px-3 text-right">हाल लिन बाँकी</th>
                  <th className="py-2.5 px-3 text-center">कार्य</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredParties.map((p, idx) => (
                  <tr key={p.id} className="hover:bg-slate-50/70">
                    <td className="py-2 px-3 font-mono text-slate-400">{idx + 1}</td>
                    <td className="py-2 px-3 font-bold text-slate-900">{p.name}</td>
                    <td className="py-2 px-3 text-slate-700">{p.address || '-'}</td>
                    <td className="py-2 px-3 font-mono text-slate-600">{p.phone || '-'}</td>
                    <td className="py-2 px-3 font-mono text-slate-600">{p.panNo || '-'}</td>
                    <td className="py-2 px-3 text-right font-mono font-bold text-rose-700">
                      {formatCurrency(p.currentBalance !== undefined ? p.currentBalance : p.openingBalance, isNe)}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => openEditCustomer(p)}
                          className="px-2 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 rounded text-[11px] font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Edit2 className="w-3 h-3" />
                          <span>सच्याउने</span>
                        </button>
                        <button
                          onClick={() => deleteParty(p.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION: BANK AUTO RECONCILIATION (बैंक भुक्तानी स्वतः मिलान) */}
      {activeSubTab === 'BANK_RECONCILIATION' && (
        <BankReconciliationView />
      )}

      {/* SECTION: DAILY CASH BOOK (दैनिक क्यासबुक) */}
      {activeSubTab === 'CASH_BOOK' && (
        <DailyCashBook
          onRecordExpenseClick={() => setActiveSubTab('EXPENSES')}
          onRecordCollectionClick={() => setActiveSubTab('COLLECTION')}
          onRecordPaymentClick={() => setActiveSubTab('PAYMENT')}
        />
      )}

      {/* RECENT TRANSACTIONS LEDGER (Shown on Collection, Payment, Expenses, Customers tabs) */}
      {activeSubTab !== 'CASH_BOOK' && activeSubTab !== 'BANK_RECONCILIATION' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs p-5 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-700" />
              <span>{isNe ? 'हालैका असुली तथा भुक्तानी भौचरहरू (Receipt & Payment Voucher Ledger)' : 'Recent Receipt & Payment Vouchers'}</span>
            </h3>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setActiveSubTab('EXPENSES')}
                className="text-xs font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1 cursor-pointer"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>{isNe ? '+ दैनिक खर्च भौचर थप्नुहोस्' : '+ Add Daily Expense'}</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveSubTab('CASH_BOOK')}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>{isNe ? 'पूर्ण दैनिक क्यासबुक हेर्नुहोस् →' : 'View Full Daily Cash Book →'}</span>
              </button>
            </div>
          </div>

          {partyTransactions.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              {isNe ? 'हालसम्म कुनै असुली वा भुक्तानी भौचर रेकर्ड भएको छैन।' : 'No voucher records found.'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold">
                  <tr>
                    <th className="py-2.5 px-3">मिति (Date BS)</th>
                    <th className="py-2.5 px-3">प्रकार (Type)</th>
                    <th className="py-2.5 px-3">पार्टी/ग्राहकको नाम</th>
                    <th className="py-2.5 px-3">माध्यम (Mode)</th>
                    <th className="py-2.5 px-3">भौचर / रसिद नं.</th>
                    <th className="py-2.5 px-3 text-right">रकम (Amount)</th>
                    <th className="py-2.5 px-3">कैफियत</th>
                    <th className="py-2.5 px-3 text-center">भौचर प्रिन्ट</th>
                    <th className="py-2.5 px-3 text-center">मेटाउने</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {partyTransactions.slice(0, 20).map((txn) => {
                    const isCollection = txn.type === 'COLLECTION_FROM_CUSTOMER';
                    return (
                      <tr key={txn.id} className="hover:bg-slate-50/70">
                        <td className="py-2 px-3 font-mono">{txn.dateBs}</td>
                        <td className="py-2 px-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              isCollection ? 'bg-emerald-100 text-emerald-900' : 'bg-blue-100 text-blue-900'
                            }`}
                          >
                            {isCollection ? 'ग्राहक असुली रसिद' : 'सप्लायर भुक्तानी भौचर'}
                          </span>
                        </td>
                        <td className="py-2 px-3 font-semibold text-slate-900">
                          {txn.partyName}
                          {txn.partyAddress && (
                            <span className="text-[10px] text-slate-500 ml-1">📍 {txn.partyAddress}</span>
                          )}
                        </td>
                        <td className="py-2 px-3">
                          {txn.paymentMode === 'BANK' ? txn.bankName || 'बैंक' : 'नगद (Cash)'}
                        </td>
                        <td className="py-2 px-3 font-mono text-slate-600 font-semibold">{txn.referenceNo || '-'}</td>
                        <td
                          className={`py-2 px-3 text-right font-mono font-bold ${
                            isCollection ? 'text-emerald-700' : 'text-blue-700'
                          }`}
                        >
                          {formatCurrency(txn.amount, isNe)}
                        </td>
                        <td className="py-2 px-3 text-slate-500 text-[11px]">{txn.notes || '-'}</td>
                        <td className="py-2 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => setPrintingVoucher(buildPartyTxVoucherData(txn))}
                            className="px-2.5 py-1 bg-slate-900 hover:bg-emerald-800 text-white rounded-md text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer shadow-2xs transition"
                          >
                            <Printer className="w-3 h-3 text-emerald-300" />
                            <span>{isNe ? 'भौचर प्रिन्ट' : 'Print Voucher'}</span>
                          </button>
                        </td>
                        <td className="py-2 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => deletePartyTransaction(txn.id)}
                            className="px-2 py-1 text-rose-700 hover:bg-rose-50 rounded-md"
                            title={isNe ? 'भौचर मेटाउनुहोस्' : 'Delete Voucher'}
                          >
                            <Trash2 className="w-3.5 h-3.5 inline" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* PRINTABLE ACCOUNTING VOUCHER MODAL (खर्च / असुली / भुक्तानी भौचर प्रिन्ट) */}
      {/* ===================================================================== */}
      {printingVoucher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-6 overflow-y-auto">
          <div className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
            {/* Modal Control Bar */}
            <div className="px-4 py-3 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Printer className="w-4 h-4 text-amber-400" />
                <span className="text-xs sm:text-sm font-bold">
                  {printingVoucher.voucherType === 'EXPENSE'
                    ? isNe
                      ? 'दैनिक खर्च भौचर प्रिन्ट / PDF (Daily Expense Voucher)'
                      : 'Daily Expense Voucher Print / PDF'
                    : printingVoucher.voucherType === 'COLLECTION'
                    ? isNe
                      ? 'रकम असुली रसिद प्रिन्ट / PDF (Receipt Voucher)'
                      : 'Customer Receipt Voucher Print / PDF'
                    : isNe
                    ? 'भुक्तानी भौचर प्रिन्ट / PDF (Payment Voucher)'
                    : 'Supplier Payment Voucher Print / PDF'}
                </span>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <PaperSizeToggle />
                {/* Format Toggle */}
                <div className="flex items-center bg-slate-800 p-0.5 rounded-lg text-[11px] font-bold">
                  <button
                    type="button"
                    onClick={() => setVoucherPrintFormat('A4')}
                    className={`px-2.5 py-1 rounded-md cursor-pointer transition ${
                      voucherPrintFormat === 'A4' ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    A4 / Standard Voucher
                  </button>
                  <button
                    type="button"
                    onClick={() => setVoucherPrintFormat('POS_80')}
                    className={`px-2.5 py-1 rounded-md cursor-pointer transition ${
                      voucherPrintFormat === 'POS_80' ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    80mm Thermal Slip
                  </button>
                </div>

                {/* Download PDF Button */}
                <button
                  type="button"
                  disabled={isDownloadingVoucherPdf}
                  onClick={async () => {
                    try {
                      setIsDownloadingVoucherPdf(true);
                      await downloadElementAsPdf({
                        elementId: 'printable-accounting-voucher',
                        fileName: `Voucher_${printingVoucher.voucherNo}_${printingVoucher.dateBs}.pdf`,
                        format: voucherPrintFormat === 'A4' ? 'a4' : 'pos80',
                        onProgress: setIsDownloadingVoucherPdf
                      });
                    } catch (err) {
                      console.error(err);
                      setIsDownloadingVoucherPdf(false);
                    }
                  }}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  {isDownloadingVoucherPdf ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <FileDown className="w-3.5 h-3.5" />
                  )}
                  <span>{isNe ? 'PDF सेभ गर्नुहोस्' : 'Download PDF'}</span>
                </button>

                <InvoicePrintOptions storageKey="voucher" features={{ copies: true, twoUp: true }} />

                {/* Print Button */}
                <button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById('printable-accounting-voucher');
                    if (el) {
                      printPage(printArgsFor('voucher', { features: { copies: true } }));
                    } else {
                      printPage(printArgsFor('voucher', { features: { copies: true } }));
                    }
                  }}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{isNe ? '🖨️ प्रिन्ट गर्नुहोस् (Print)' : 'Print Voucher'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPrintingVoucher(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Voucher Canvas */}
            <div className="p-4 sm:p-6 bg-slate-100 max-h-[80vh] overflow-y-auto flex justify-center">
              <div
                id="printable-accounting-voucher"
                className={`bg-white text-slate-900 border-2 border-slate-800 shadow-sm ${
                  voucherPrintFormat === 'POS_80' ? 'w-[310px] p-3.5 text-[11px]' : 'w-full max-w-[740px] p-6 text-xs'
                }`}
              >
                {/* Company Header */}
                <div className="text-center border-b-2 border-slate-900 pb-3 mb-4">
                  {company.logoUrl && (
                    <img
                      src={company.logoUrl}
                      alt="Logo"
                      className="h-14 w-auto object-contain mx-auto mb-2 rounded"
                    />
                  )}
                  <div className="text-xl sm:text-2xl font-black text-slate-950 tracking-tight leading-tight uppercase">
                    {company.name}
                  </div>
                  <div className="text-xs font-bold text-slate-700 mt-1">
                    {company.address}
                  </div>
                  <div className="text-[11px] font-semibold text-slate-600 mt-0.5">
                    फोन: <span className="font-mono">{company.phone}</span> | इमेल: {company.email || '-'}
                  </div>
                  <div className="text-[11px] font-mono font-black text-slate-800 mt-1 px-3 py-0.5 bg-slate-100 inline-block rounded border border-slate-300">
                    स्थायी लेखा नं. (PAN / VAT No.): {company.panVatNo} | आ.व. (F.Y.): {company.fiscalYear}
                  </div>

                  <div className="mt-4 flex justify-center">
                    <div className="px-6 py-1.5 rounded border-2 border-slate-900 bg-slate-900 font-black text-xs sm:text-sm uppercase tracking-widest text-white shadow-sm">
                      {printingVoucher.voucherType === 'EXPENSE'
                        ? 'दैनिक खर्च भौचर (DAILY EXPENSE VOUCHER)'
                        : printingVoucher.voucherType === 'COLLECTION'
                        ? 'रकम असुली रसिद (RECEIPT VOUCHER)'
                        : 'पार्टी भुक्तानी भौचर (PAYMENT VOUCHER)'}
                    </div>
                  </div>
                </div>

                {/* Voucher Meta Row */}
                <div className="grid grid-cols-2 gap-2 pb-3 mb-3 border-b border-slate-300 text-xs">
                  <div className="space-y-1">
                    <div>
                      <span className="font-bold text-slate-700">भौचर नं. (Voucher No.): </span>
                      <span className="font-mono font-black text-slate-950">{printingVoucher.voucherNo}</span>
                    </div>
                    <div>
                      <span className="font-bold text-slate-700">
                        {printingVoucher.voucherType === 'COLLECTION'
                          ? 'रकम बुझाउने (Received From): '
                          : 'भुक्तानी पाउने (Paid To): '}
                      </span>
                      <span className="font-black text-slate-950">{printingVoucher.partyOrReceiverName}</span>
                    </div>
                    {printingVoucher.partyAddress && (
                      <div>
                        <span className="font-bold text-slate-700">ठेगाना (Address): </span>
                        <span className="font-semibold text-slate-800">{printingVoucher.partyAddress}</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-1 text-right">
                    <div>
                      <span className="font-bold text-slate-700">मिति (Date B.S.): </span>
                      <span className="font-mono font-bold text-slate-950">{printingVoucher.dateBs}</span>
                    </div>
                    <div>
                      <span className="font-bold text-slate-700">भुक्तानी माध्यम (Mode): </span>
                      <span className="font-bold text-slate-950">
                        {printingVoucher.paymentMode === 'BANK'
                          ? `बैंक / QR (${printingVoucher.bankName || 'Bank'})`
                          : 'काउन्टर नगद (Cash)'}
                      </span>
                    </div>
                    {printingVoucher.partyPhone && (
                      <div>
                        <span className="font-bold text-slate-700">फोन (Phone): </span>
                        <span className="font-mono text-slate-800">{printingVoucher.partyPhone}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Particulars Table */}
                <table className="w-full border-collapse border border-slate-800 text-xs mb-3">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-800 font-bold text-slate-900">
                      <th className="border-r border-slate-800 py-2 px-2.5 w-12 text-center">क्र.सं.</th>
                      <th className="border-r border-slate-800 py-2 px-3 text-left">
                        शीर्षक तथा खर्च/कारोबारको विवरण (Particulars / Description)
                      </th>
                      <th className="py-2 px-3 w-36 text-right">रकम (Amount रु.)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-300">
                      <td className="border-r border-slate-800 py-3 px-2.5 text-center font-mono">१.</td>
                      <td className="border-r border-slate-800 py-3 px-3">
                        <div className="font-bold text-slate-950">{printingVoucher.categoryOrTitle}</div>
                        <div className="text-slate-700 mt-0.5">{printingVoucher.particulars}</div>
                        {printingVoucher.notes && printingVoucher.notes !== printingVoucher.particulars && (
                          <div className="text-[11px] text-slate-500 mt-0.5">कैफियत: {printingVoucher.notes}</div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-black text-sm text-slate-950">
                        {formatCurrency(printingVoucher.amount, isNe)}
                      </td>
                    </tr>
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-100 border-t-2 border-slate-800 font-black text-slate-950">
                      <td colSpan={2} className="border-r border-slate-800 py-2.5 px-3 text-right">
                        कुल जम्मा रकम (Total Voucher Amount):
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-sm">
                        {formatCurrency(printingVoucher.amount, isNe)}
                      </td>
                    </tr>
                  </tfoot>
                </table>

                {/* Amount in Words */}
                <div className="p-2.5 bg-slate-50 border border-slate-400 rounded mb-4 text-xs">
                  <span className="font-bold text-slate-800">अक्षरूपी (In Words): </span>
                  <span className="font-bold text-slate-950">
                    {isNe
                      ? amountInNepaliWords(printingVoucher.amount)
                      : amountInEnglishWords(printingVoucher.amount)}
                  </span>
                </div>

                {/* Signatures & QR Code Verification Footer */}
                <div className="pt-4 mt-2 border-t border-dashed border-slate-400 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-2.5">
                    <div className="p-1.5 border border-slate-300 rounded bg-white">
                      <QRCodeSVG
                        value={`VOUCHER:${printingVoucher.voucherNo}|DATE:${printingVoucher.dateBs}|AMT:NPR ${printingVoucher.amount}|TO:${printingVoucher.partyOrReceiverName}|FIRM:${company.name}`}
                        size={54}
                        level="M"
                      />
                    </div>
                    <div className="text-[10px] text-slate-600 leading-tight">
                      <div className="font-bold text-slate-900">प्रमाणीकरण QR (Scan to Verify)</div>
                      <div>भौचर नं: {printingVoucher.voucherNo}</div>
                      <div>तयार गर्ने: {currentAccount?.ownerName || 'प्रशासक'}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-6 w-full sm:w-auto text-center text-[11px] pt-6">
                    <div>
                      <div className="border-t border-slate-800 pt-1 font-bold text-slate-800 px-2">
                        तयार गर्ने (Prepared By)
                      </div>
                    </div>
                    <div>
                      <div className="border-t border-slate-800 pt-1 font-bold text-slate-800 px-2">
                        स्वीकृत गर्ने (Approved By)
                      </div>
                    </div>
                    <div>
                      <div className="border-t border-slate-800 pt-1 font-bold text-slate-800 px-2">
                        बुझिलिनेको सही (Receiver)
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* EDIT / ADD CUSTOMER MODAL */}
      {isCustomerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                {editingCustomer
                  ? isNe
                    ? 'ग्राहक विवरण तथा पुरानो बाँकी सच्याउने'
                    : 'Edit Customer & Opening Due'
                  : isNe
                  ? 'नयाँ ग्राहक दर्ता'
                  : 'Add New Customer'}
              </h3>
              <button
                onClick={() => setIsCustomerModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomer} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">ग्राहकको नाम*</label>
                <input
                  type="text"
                  required
                  value={custFormName}
                  onChange={(e) => setCustFormName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">ठेगाना*</label>
                <input
                  type="text"
                  required
                  value={custFormAddress}
                  onChange={(e) => setCustFormAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">फोन</label>
                  <input
                    type="text"
                    value={custFormPhone}
                    onChange={(e) => setCustFormPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">प्यान/भ्याट नं.</label>
                  <input
                    type="text"
                    value={custFormPan}
                    onChange={(e) => setCustFormPan(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 space-y-1">
                <label className="block text-[11px] font-bold text-amber-950">
                  पुरानो लिन बाँकी रकम (Opening Due रु.)
                </label>
                <input
                  type="number"
                  min={0}
                  value={custFormOpeningDue}
                  onChange={(e) => setCustFormOpeningDue(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-amber-300 rounded-lg bg-white font-mono font-bold text-amber-950 text-sm"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCustomerModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  रद्द
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer"
                >
                  सुरक्षित गर्नुहोस् (Save)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
