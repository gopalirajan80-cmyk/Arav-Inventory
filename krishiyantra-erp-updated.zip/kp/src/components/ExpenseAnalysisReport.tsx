import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatCurrency, getTodayBsString } from '../utils/nepaliCalendar';
import { BarChart3, TrendingDown, TrendingUp, PieChart, PlusCircle } from 'lucide-react';

const BS_MONTH_NAMES: Record<string, { ne: string; en: string }> = {
  '01': { ne: 'बैशाख', en: 'Baisakh' },
  '02': { ne: 'जेठ', en: 'Jestha' },
  '03': { ne: 'असार', en: 'Ashadh' },
  '04': { ne: 'श्रावण', en: 'Shrawan' },
  '05': { ne: 'भदौ', en: 'Bhadra' },
  '06': { ne: 'असोज', en: 'Ashwin' },
  '07': { ne: 'कार्तिक', en: 'Kartik' },
  '08': { ne: 'मंसिर', en: 'Mangsir' },
  '09': { ne: 'पुष', en: 'Poush' },
  '10': { ne: 'माघ', en: 'Magh' },
  '11': { ne: 'फाल्गुन', en: 'Falgun' },
  '12': { ne: 'चैत', en: 'Chaitra' }
};

export const ExpenseAnalysisReport: React.FC = () => {
  const { expenses, invoices, employeeLedger, language, setActiveTab } = useApp();
  const isNe = language === 'ne';
  const todayBs = getTodayBsString();
  const currentYear = todayBs.substring(0, 4);

  const [selectedYear, setSelectedYear] = useState<string>(currentYear);

  const {
    monthlySeries,
    categoryTotals,
    totalIncomeYear,
    totalExpenseYear,
    maxMonthlyValue
  } = useMemo(() => {
    const monthsMap: Record<
      string,
      {
        monthKey: string;
        monthNum: string;
        income: number;
        expenses: number;
        categories: Record<string, number>;
      }
    > = {};

    // Initialize all 12 months of selected BS year so bar chart is complete
    Object.keys(BS_MONTH_NAMES).forEach((mNum) => {
      const key = `${selectedYear}-${mNum}`;
      monthsMap[key] = {
        monthKey: key,
        monthNum: mNum,
        income: 0,
        expenses: 0,
        categories: {}
      };
    });

    const catTotals: Record<string, number> = {};

    invoices
      .filter((inv) => inv.status === 'ACTIVE' && inv.dateBs.startsWith(selectedYear))
      .forEach((inv) => {
        const mKey = inv.dateBs.substring(0, 7);
        if (!monthsMap[mKey]) {
          monthsMap[mKey] = {
            monthKey: mKey,
            monthNum: mKey.substring(5, 7),
            income: 0,
            expenses: 0,
            categories: {}
          };
        }
        monthsMap[mKey].income += inv.grandTotal;
      });

    expenses
      .filter((exp) => exp.dateBs.startsWith(selectedYear))
      .forEach((exp) => {
        const mKey = exp.dateBs.substring(0, 7);
        if (!monthsMap[mKey]) {
          monthsMap[mKey] = {
            monthKey: mKey,
            monthNum: mKey.substring(5, 7),
            income: 0,
            expenses: 0,
            categories: {}
          };
        }
        monthsMap[mKey].expenses += exp.amount;
        const cat = exp.category || (isNe ? 'अन्य खर्च' : 'Other');
        monthsMap[mKey].categories[cat] = (monthsMap[mKey].categories[cat] || 0) + exp.amount;
        catTotals[cat] = (catTotals[cat] || 0) + exp.amount;
      });

    // Include staff cash advances / salary payments recorded in employeeLedger for holistic expense view
    employeeLedger
      .filter((entry) => entry.dateBs.startsWith(selectedYear) && (entry.type === 'CASH_ADVANCE' || entry.type === 'SALARY_PAYMENT'))
      .forEach((entry) => {
        const mKey = entry.dateBs.substring(0, 7);
        if (monthsMap[mKey]) {
          const cat = isNe ? 'कर्मचारी तलब/पेस्की' : 'Staff Payroll & Advance';
          monthsMap[mKey].expenses += entry.amount;
          monthsMap[mKey].categories[cat] = (monthsMap[mKey].categories[cat] || 0) + entry.amount;
          catTotals[cat] = (catTotals[cat] || 0) + entry.amount;
        }
      });

    const series = Object.values(monthsMap).sort((a, b) => a.monthKey.localeCompare(b.monthKey));
    const totalInc = series.reduce((s, m) => s + m.income, 0);
    const totalExp = series.reduce((s, m) => s + m.expenses, 0);
    const maxVal = Math.max(
      1,
      ...series.map((m) => Math.max(m.income, m.expenses))
    );

    const sortedCategories = Object.entries(catTotals)
      .map(([category, amount]) => ({ category, amount }))
      .sort((a, b) => b.amount - a.amount);

    return {
      monthlySeries: series,
      categoryTotals: sortedCategories,
      totalIncomeYear: totalInc,
      totalExpenseYear: totalExp,
      maxMonthlyValue: maxVal
    };
  }, [expenses, invoices, employeeLedger, selectedYear, isNe]);

  const expenseRatioPercent =
    totalIncomeYear > 0 ? ((totalExpenseYear / totalIncomeYear) * 100).toFixed(1) : '0.0';

  return (
    <div className="space-y-5">
      {/* Top Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{isNe ? `कुल आम्दानी (${selectedYear})` : `Total Income (${selectedYear})`}</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-700 mt-1">
            {formatCurrency(totalIncomeYear, isNe)}
          </div>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            {isNe ? 'कुल सक्रिय बिक्री बीजकबाट' : 'From active sales invoices'}
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{isNe ? `कुल खर्च (${selectedYear})` : `Total Expenses (${selectedYear})`}</span>
            <TrendingDown className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-bold font-mono text-amber-700 mt-1">
            {formatCurrency(totalExpenseYear, isNe)}
          </div>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            {isNe ? 'दैनिक सञ्चालन र कर्मचारी खर्च' : 'Daily operational & staff outlays'}
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>{isNe ? 'खर्च अनुपात (Expense vs Income)' : 'Expense-to-Income Ratio'}</span>
            <PieChart className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1">
            {expenseRatioPercent}%
          </div>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            {isNe ? 'आम्दानीको तुलनामा खर्च प्रतिशत' : 'Percentage of revenue spent'}
          </span>
        </div>

        <div className="bg-emerald-900 text-white p-4 rounded-xl shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs text-emerald-200 block">
              {isNe ? 'खुद बचत (Income - Expense)' : 'Net Cash Surplus'}
            </span>
            <div className="text-xl font-bold font-mono text-white mt-1">
              {formatCurrency(totalIncomeYear - totalExpenseYear, isNe)}
            </div>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('vouchers')}
            className="mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-amber-300 hover:underline cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>{isNe ? '+ नयाँ दैनिक खर्च थप्नुहोस्' : '+ Record Daily Expense'}</span>
          </button>
        </div>
      </div>

      {/* Monthly Bar Chart: Income vs Expenses */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-emerald-700" />
              <span>
                {isNe
                  ? `मासिक आम्दानी र दैनिक खर्च तुलनात्मक बार चार्ट (B.S. ${selectedYear})`
                  : `Monthly Income vs Daily Expenses Bar Chart (B.S. ${selectedYear})`}
              </span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {isNe
                ? 'प्रत्येक महिनाको कुल बिक्री आम्दानी (हरियो) र दैनिक खर्च (सुन्तला) को तुलनात्मक विश्लेषण'
                : 'Side-by-side monthly comparison of total sales income (green) vs daily expenses (amber)'}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 font-semibold text-slate-700">
                <span className="w-3 h-3 rounded-xs bg-emerald-600 inline-block" />
                {isNe ? 'कुल आम्दानी (Income)' : 'Total Income'}
              </span>
              <span className="flex items-center gap-1.5 font-semibold text-slate-700">
                <span className="w-3 h-3 rounded-xs bg-amber-500 inline-block" />
                {isNe ? 'दैनिक खर्च (Expenses)' : 'Daily Expenses'}
              </span>
            </div>

            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono font-bold bg-white"
            >
              <option value="2083">2083 B.S.</option>
              <option value="2082">2082 B.S.</option>
              <option value="2081">2081 B.S.</option>
              <option value="2080">2080 B.S.</option>
            </select>
          </div>
        </div>

        {/* Vertical Bar Chart Grid (12 Months) */}
        <div className="pt-4 pb-2 overflow-x-auto">
          <div className="min-w-[640px] h-64 flex items-end justify-between gap-2 px-2 border-b border-slate-200">
            {monthlySeries.map((m) => {
              const incomeHeightPct = Math.max(
                m.income > 0 ? 6 : 0,
                Math.round((m.income / maxMonthlyValue) * 100)
              );
              const expenseHeightPct = Math.max(
                m.expenses > 0 ? 6 : 0,
                Math.round((m.expenses / maxMonthlyValue) * 100)
              );
              const monthMeta = BS_MONTH_NAMES[m.monthNum] || { ne: m.monthNum, en: m.monthNum };

              return (
                <div
                  key={m.monthKey}
                  className="flex-1 flex flex-col items-center h-full justify-end group relative"
                >
                  {/* Hover Tooltip */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none absolute -top-2 z-20 bg-slate-900 text-white text-[10px] rounded-lg px-2.5 py-1.5 shadow-lg whitespace-nowrap">
                    <div className="font-bold border-b border-slate-700 pb-0.5 mb-0.5">
                      {isNe ? monthMeta.ne : monthMeta.en} ({m.monthKey})
                    </div>
                    <div className="text-emerald-300">
                      {isNe ? 'आम्दानी: ' : 'Income: '}
                      {formatCurrency(m.income, isNe)}
                    </div>
                    <div className="text-amber-300">
                      {isNe ? 'खर्च: ' : 'Expense: '}
                      {formatCurrency(m.expenses, isNe)}
                    </div>
                  </div>

                  {/* Bars Pair */}
                  <div className="w-full flex items-end justify-center gap-1 h-48 px-1">
                    <div
                      style={{ height: `${incomeHeightPct}%` }}
                      className="w-3.5 sm:w-4 bg-emerald-600 hover:bg-emerald-500 rounded-t transition-all"
                      title={`${isNe ? 'आम्दानी' : 'Income'}: ${formatCurrency(m.income, isNe)}`}
                    />
                    <div
                      style={{ height: `${expenseHeightPct}%` }}
                      className="w-3.5 sm:w-4 bg-amber-500 hover:bg-amber-400 rounded-t transition-all"
                      title={`${isNe ? 'खर्च' : 'Expense'}: ${formatCurrency(m.expenses, isNe)}`}
                    />
                  </div>

                  {/* Month Label */}
                  <div className="mt-2 text-[11px] font-bold text-slate-700 text-center">
                    {isNe ? monthMeta.ne : monthMeta.en.slice(0, 3)}
                  </div>
                  <div className="text-[9px] font-mono text-slate-400 pb-1">
                    {m.expenses > 0 ? `रु.${Math.round(m.expenses / 1000)}k` : '-'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Category-wise Spending Breakdown & Monthly Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Category Breakdown */}
        <div className="lg:col-span-5 bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            {isNe ? 'शीर्षक अनुसार खर्च वर्गीकरण (Category Spending Trends)' : 'Spending Breakdown by Category'}
          </h3>

          {categoryTotals.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-400">
              {isNe ? 'यस वर्ष कुनै खर्च रेकर्ड भएको छैन।' : 'No expenses recorded for this year.'}
            </div>
          ) : (
            <div className="space-y-3">
              {categoryTotals.map((item) => {
                const pct = totalExpenseYear > 0 ? Math.round((item.amount / totalExpenseYear) * 100) : 0;
                return (
                  <div key={item.category} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold text-slate-800">{item.category}</span>
                      <span className="font-mono font-bold text-amber-800">
                        {formatCurrency(item.amount, isNe)} ({pct}%)
                      </span>
                    </div>
                    <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500 rounded-full"
                        style={{ width: `${Math.max(4, pct)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Monthly Breakdown Table */}
        <div className="lg:col-span-7 bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
            {isNe ? 'मासिक आम्दानी बनाम खर्च तालिका (Monthly Breakdown)' : 'Monthly Income vs Expense Breakdown'}
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-2 px-3">{isNe ? 'महिना' : 'Month'}</th>
                  <th className="py-2 px-3 text-right">{isNe ? 'कुल आम्दानी' : 'Total Income'}</th>
                  <th className="py-2 px-3 text-right">{isNe ? 'दैनिक खर्च' : 'Total Expense'}</th>
                  <th className="py-2 px-3 text-right">{isNe ? 'खुद बचत' : 'Net Balance'}</th>
                  <th className="py-2 px-3">{isNe ? 'मुख्य खर्च शीर्षकहरू' : 'Top Categories'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {monthlySeries
                  .filter((m) => m.income > 0 || m.expenses > 0)
                  .map((m) => {
                    const meta = BS_MONTH_NAMES[m.monthNum] || { ne: m.monthKey, en: m.monthKey };
                    const net = m.income - m.expenses;
                    const topCats = Object.entries(m.categories)
                      .map(([c, amt]) => `${c}: ${formatCurrency(amt as number, isNe)}`)
                      .join(', ');

                    return (
                      <tr key={m.monthKey} className="hover:bg-slate-50/70">
                        <td className="py-2 px-3 font-bold text-slate-900">
                          {isNe ? meta.ne : meta.en} ({m.monthKey})
                        </td>
                        <td className="py-2 px-3 text-right font-mono text-emerald-700 font-semibold">
                          {formatCurrency(m.income, isNe)}
                        </td>
                        <td className="py-2 px-3 text-right font-mono text-amber-800 font-semibold">
                          {formatCurrency(m.expenses, isNe)}
                        </td>
                        <td
                          className={`py-2 px-3 text-right font-mono font-bold ${
                            net >= 0 ? 'text-emerald-800' : 'text-rose-700'
                          }`}
                        >
                          {formatCurrency(net, isNe)}
                        </td>
                        <td className="py-2 px-3 text-[11px] text-slate-500 max-w-xs truncate">
                          {topCats || '-'}
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
