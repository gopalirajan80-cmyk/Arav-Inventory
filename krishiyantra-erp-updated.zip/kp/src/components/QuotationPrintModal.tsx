import React, { useState } from 'react';
import { FileText, Printer, X, FileDown, Loader2, Smartphone } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Quotation } from '../types';
import { InvoicePrintOptions, InvoicePrintOpts, loadPrintOpts, printArgsFor } from './InvoicePrintOptions';
import { PrintLetterhead, PrintFooter } from './PrintLetterhead';
import { PaperSizeToggle } from './PaperSizeToggle';
import { printPage } from '../utils/printHelper';
import { getPaperSize } from '../utils/paperSize';
import { downloadElementAsPdf, generateElementPdfFile } from '../utils/pdfHelper';
import { formatBsDateNepaliText } from '../utils/nepaliCalendar';
import { amountInNepaliWords, amountInEnglishWords } from '../utils/vatCalculator';
import { buildQuotationMessage } from '../utils/orderUtils';
import { sharePdfFileViaWebShareOrWhatsApp } from '../utils/shareUtils';

interface Props {
  quotation: Quotation;
  onClose: () => void;
  /** Print / PDF / share bhaepachhi (DRAFT -> SENT) parent lai bhanna */
  onPrinted?: () => void;
}

const KEY = 'quotation';
const fmt = (n: number) => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const QuotationPrintModal: React.FC<Props> = ({ quotation: q, onClose, onPrinted }) => {
  const { company, language } = useApp();
  const isNe = language === 'ne';
  const [opts, setOpts] = useState<InvoicePrintOpts>(loadPrintOpts(KEY));
  const [busy, setBusy] = useState<'pdf' | 'wa' | null>(null);

  const isVat = q.billType === 'VAT';
  const banks = (company.bankAccounts || []).slice(0, 3);
  const words = isNe ? amountInNepaliWords(q.grandTotal) : amountInEnglishWords(q.grandTotal);
  const fileName = `${(q.quotationNo || 'QT').replace(/[^a-zA-Z0-9_-]/g, '_')}_Quotation.pdf`;

  const handlePrint = () => {
    printPage(printArgsFor(KEY, { mode: getPaperSize(), isA4: getPaperSize() === 'A4' }));
    onPrinted?.();
  };

  const handlePdf = async () => {
    setBusy('pdf');
    try {
      await downloadElementAsPdf({ elementId: 'printable-quotation', fileName, format: 'a4' });
      onPrinted?.();
    } finally {
      setBusy(null);
    }
  };

  const handleWhatsApp = async () => {
    setBusy('wa');
    try {
      const pdfFile = await generateElementPdfFile({ elementId: 'printable-quotation', fileName, format: 'a4' });
      await sharePdfFileViaWebShareOrWhatsApp({
        title: `Quotation ${q.quotationNo} - ${company.name}`,
        message: buildQuotationMessage(q, company),
        phone: q.customerPhone,
        pdfFile,
        preferDirectWhatsAppNumber: Boolean(q.customerPhone)
      });
      onPrinted?.();
    } catch (e) {
      console.error('Quotation WhatsApp share error', e);
    } finally {
      setBusy(null);
    }
  };

  const th = 'border border-slate-300 py-1.5 px-2';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static print:overflow-visible print:block">
      <div className="relative w-full max-w-4xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[95vh] flex flex-col">
        {/* Control bar (print ma dekhinna) */}
        <div className="no-print bg-slate-900 text-white px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold tracking-tight">
              {isNe ? 'कोटेशन' : 'Quotation'} : {q.quotationNo}
            </h2>
          </div>
          <div className="flex items-center flex-wrap gap-2">
            <PaperSizeToggle />
            <InvoicePrintOptions
              value={opts}
              onChange={setOpts}
              storageKey={KEY}
              features={{ copies: true, twoUp: true, compact: true }}
              isA4={getPaperSize() === 'A4'}
            />
            <button type="button" onClick={handlePdf} disabled={busy !== null} className="ky-btn ky-btn-blue">
              {busy === 'pdf' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />}
              <span>{isNe ? 'PDF डाउनलोड' : 'Download PDF'}</span>
            </button>
            <button type="button" onClick={handlePrint} className="ky-btn ky-btn-green">
              <Printer className="w-4 h-4" />
              <span>{isNe ? 'प्रिन्ट गर्नुहोस्' : 'Print'}</span>
            </button>
            <button type="button" onClick={handleWhatsApp} disabled={busy !== null} className="ky-btn ky-btn-teal">
              {busy === 'wa' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Smartphone className="w-3.5 h-3.5" />}
              <span>WhatsApp PDF</span>
            </button>
            <button type="button" onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-md cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable quotation */}
        <div id="printable-quotation" className="overflow-y-auto p-4 sm:p-8 flex justify-center bg-slate-100 flex-1 print:p-0 print:bg-white print:block">
          <div className="bg-white shadow-md border border-slate-300 text-slate-900 w-full max-w-[800px] p-6 sm:p-8 text-xs font-sans">
            <div className="space-y-4">
              <PrintLetterhead
                company={company as any}
                topNote={isVat ? 'VAT सहितको मूल्य प्रस्ताव' : 'Price Proposal'}
                docTitle="कोटेशन (QUOTATION)"
              />

              {/* Meta grid */}
              <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-3 rounded-sm border border-slate-200">
                <div className="space-y-1">
                  <div>
                    <span className="font-semibold text-slate-700">कोटेशन नं. (Quotation No): </span>
                    <span className="font-mono font-bold text-slate-900 text-sm">{q.quotationNo}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-700">मिति (Date B.S.): </span>
                    <span className="font-bold">{formatBsDateNepaliText(q.dateBs)}</span>
                    <span className="text-slate-500 font-mono text-[11px] ml-1">({q.dateBs})</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-700">Date (A.D.): </span>
                    <span className="font-mono">{q.dateAd}</span>
                  </div>
                  {q.validUntilBs && (
                    <div>
                      <span className="font-semibold text-slate-700">मान्य अवधि (Valid Until): </span>
                      <span className="font-bold text-rose-800">{q.validUntilBs}</span>
                    </div>
                  )}
                  <div>
                    <span className="font-semibold text-slate-700">तयार गर्ने (Prepared By): </span>
                    <span className="font-bold text-emerald-900">{q.preparedBy}</span>
                  </div>
                </div>
                <div className="space-y-1 border-l border-slate-200 pl-4">
                  <div>
                    <span className="font-semibold text-slate-700">श्री (To): </span>
                    <span className="font-bold text-slate-900">{q.customerName}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-700">ठेगाना (Address): </span>
                    <span>{q.customerAddress || '-'}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-700">फोन (Phone): </span>
                    <span className="font-mono">{q.customerPhone || '-'}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-700">प्यान नं. (PAN): </span>
                    <span className="font-mono font-bold">{q.customerPan || '-'}</span>
                  </div>
                </div>
              </div>

              {q.subject && (
                <p className="text-xs">
                  <b>विषय:</b> <span className="underline">{q.subject}</span>
                </p>
              )}
              <p className="text-xs text-slate-700">उपरोक्त सम्बन्धमा तहाँले माग गर्नुभएका सामानहरूको मूल्य प्रस्ताव तल उल्लेख गरिएको छ:</p>

              {/* Items table (same look as sales bill) */}
              <div className="overflow-x-auto">
                <table className="ky-items w-full border-collapse border border-slate-300 text-xs">
                  <thead>
                    <tr className="bg-slate-900 text-white">
                      <th className={th + ' w-8'}>क्र.सं.</th>
                      <th className={th + ' w-16'}>कोड</th>
                      <th className={th + ' text-left'}>सामानको विवरण (Description)</th>
                      <th className={th + ' w-14'}>साइज</th>
                      <th className={th + ' w-12'}>परिमाण</th>
                      <th className={th + ' w-12'}>एकाइ</th>
                      <th className={th + ' text-right w-18'}>दर (रु)</th>
                      <th className={th + ' text-center w-12'}>छुट %</th>
                      <th className={th + ' text-right w-18'}>छुट रकम</th>
                      <th className={th + ' text-right w-22'}>जम्मा (रु)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {q.items.map((l, idx) => {
                      const gross = (l.qty || 0) * (l.rate || 0);
                      const disc = (gross * (l.discountPercent || 0)) / 100;
                      const net = l.amount !== undefined ? l.amount : gross - disc;
                      return (
                        <tr key={idx} className="text-slate-900 odd:bg-white even:bg-slate-100">
                          <td className="border border-slate-300 py-1 px-1.5 text-center font-mono">{idx + 1}</td>
                          <td className="border border-slate-300 py-1 px-2 text-center font-mono text-[11px] font-bold">{l.code || '-'}</td>
                          <td className="border border-slate-300 py-1 px-3">
                            <span className="font-semibold">{l.name}</span>
                            {l.isVatExempt && <span className="block text-[10px] text-emerald-800 font-bold">[कर छुट]</span>}
                            {l.note && <span className="block text-[10px] text-slate-500">{l.note}</span>}
                          </td>
                          <td className="border border-slate-300 py-1 px-2 text-center">{l.size || '-'}</td>
                          <td className="border border-slate-300 py-1 px-2 text-center font-mono font-bold">{l.qty}</td>
                          <td className="border border-slate-300 py-1 px-2 text-center text-[11px]">{l.unit}</td>
                          <td className="border border-slate-300 py-1 px-2 text-right font-mono tabular-nums">{(l.rate || 0).toFixed(2)}</td>
                          <td className="border border-slate-300 py-1 px-1.5 text-center font-mono">{(l.discountPercent || 0) > 0 ? `${l.discountPercent}%` : '-'}</td>
                          <td className="border border-slate-300 py-1 px-2 text-right font-mono tabular-nums text-rose-800">{disc > 0 ? disc.toFixed(2) : '-'}</td>
                          <td className="border border-slate-300 py-1 px-2 text-right font-mono tabular-nums font-bold">{net.toFixed(2)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Words + terms (left) and totals (right) */}
              <div className="grid grid-cols-12 gap-4 items-start" style={{ breakInside: 'avoid' }}>
                <div className="col-span-7 space-y-3">
                  <div className="p-2 border border-slate-300 rounded-sm bg-slate-50">
                    <div className="text-[10px] font-bold text-slate-500 uppercase">अक्षरमा (In Words)</div>
                    <div className="font-semibold">{words}</div>
                  </div>
                  <div className="p-2 border border-slate-300 rounded-sm space-y-0.5 text-[11px]">
                    {q.paymentTerms && (<div><b>भुक्तानी सर्त:</b> {q.paymentTerms}</div>)}
                    {q.deliveryTerms && (<div><b>डेलिभरी सर्त:</b> {q.deliveryTerms}</div>)}
                    {q.warrantyNote && (<div><b>ग्यारेन्टी/वारेन्टी:</b> {q.warrantyNote}</div>)}
                    {q.validUntilBs && (<div><b>वैधता:</b> यो कोटेशन {q.validUntilBs} सम्म मात्र मान्य हुनेछ।</div>)}
                    {q.notes && (<div><b>अन्य:</b> {q.notes}</div>)}
                  </div>
                  {banks.length > 0 && (
                    <div className="text-[11px]">
                      <b>बैंक विवरण:</b>
                      {banks.map((b: any, i: number) => (
                        <div key={i} className="font-mono">{b.bankName} — {b.accountNumber} ({b.accountHolder})</div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="col-span-5">
                  <table className="w-full border-collapse border border-slate-900 text-xs">
                    <tbody>
                      <tr className="border-b border-slate-300">
                        <td className="py-1 px-2 font-medium text-slate-700 border-r border-slate-900">उप-जम्मा (Sub Total)</td>
                        <td className="py-1 px-2 text-right font-mono tabular-nums font-semibold">{fmt(q.subtotal)}</td>
                      </tr>
                      {q.discountAmount > 0 && (
                        <tr className="border-b border-slate-300">
                          <td className="py-1 px-2 font-medium text-slate-700 border-r border-slate-900">छुट ({q.discountPercent}%)</td>
                          <td className="py-1 px-2 text-right font-mono tabular-nums text-rose-700">-{fmt(q.discountAmount)}</td>
                        </tr>
                      )}
                      {isVat && (
                        <tr className="border-b border-slate-300">
                          <td className="py-1 px-2 font-semibold text-slate-800 border-r border-slate-900">१३% भ्याट (VAT 13%)</td>
                          <td className="py-1 px-2 text-right font-mono tabular-nums font-bold text-blue-900">{fmt(q.vatAmount)}</td>
                        </tr>
                      )}
                      {q.freightCharge > 0 && (
                        <tr className="border-b border-slate-300">
                          <td className="py-1 px-2 font-medium text-slate-700 border-r border-slate-900">ढुवानी शुल्क (Freight)</td>
                          <td className="py-1 px-2 text-right font-mono tabular-nums">+{fmt(q.freightCharge)}</td>
                        </tr>
                      )}
                      <tr className="bg-slate-900 text-white font-bold text-sm">
                        <td className="py-1.5 px-2 border-r border-slate-700">कुल जम्मा (Grand Total)</td>
                        <td className="py-1.5 px-2 text-right font-mono tabular-nums text-emerald-400">रू. {fmt(q.grandTotal)}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Signatures */}
              <div className="grid grid-cols-3 gap-6 pt-10 text-center text-[11px] text-slate-700" style={{ breakInside: 'avoid' }}>
                <div className="border-t border-slate-400 pt-1">
                  तयार गर्ने: <b>{q.preparedBy}</b>
                </div>
                <div className="border-t border-slate-400 pt-1">
                  अधिकृत हस्ताक्षर (Authorized Signatory)
                  <div className="text-[9px] text-slate-400">कम्पनी छाप</div>
                </div>
                <div className="border-t border-slate-400 pt-1">ग्राहकको स्वीकृति / दस्तखत</div>
              </div>

              <PrintFooter company={company as any} note="धन्यवाद! हामीलाई मौका दिनुभएकोमा आभारी छौं। (Thank you for your enquiry!)" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
