import { printPage } from '../utils/printHelper';
import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { VoucherScreen } from './VoucherScreen';
import {
  ShoppingCart,
  RotateCcw,
  Plus,
  CheckCircle2,
  Package,
  Search,
  FileText,
  User,
  Hash,
  Sparkles,
  FileSpreadsheet,
  Receipt,
  Scan,
  Camera,
  Trash2,
  Pencil,
  Calendar,
  Wallet,
  Percent,
  Truck,
  Download,
  Printer,
  FileDown,
  Loader2,
  X,
  Save,
  Calculator
} from 'lucide-react';
import { formatCurrency, getTodayBsString, getTodayAdString, toNepaliDigits, resolveDatePair } from '../utils/nepaliCalendar';
import { DualDateInput } from './DualDateInput';
import { NumField } from './NumField';
import { isCustomerParty, isSupplierParty } from '../utils/partyTxn';
import { HandwrittenBillScannerModal } from './HandwrittenBillScannerModal';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { parseExcelFile, parseExcelNumericValue } from '../utils/excelEngine';
import { fileToDataUrl } from '../utils/cameraHelper';
import { exportReportToExcel, printOrDownloadReportPdf } from '../utils/pdfReportExporter';
import { downloadElementAsPdf } from '../utils/pdfHelper';
import { PaperSizeToggle } from './PaperSizeToggle';
import { amountInNepaliWords } from '../utils/vatCalculator';
import { InvoiceItem, Item, ItemCategory, PurchaseRecord, BillType } from '../types';
import { DEFAULT_PRODUCT_CATEGORIES } from './SettingsScreen';
import { authFetch } from '../utils/auth';

interface SalesReturnRecord {
  id: string;
  creditNoteNo: string;
  dateBs: string;
  invoiceNo: string;
  customerName: string;
  returnedItems: {
    itemId?: string;
    itemName: string;
    returnQty: number;
    unitPrice: number;
    lineTotal: number;
  }[];
  totalReturnAmount: number;
  reason: string;
  refundMode: 'CASH' | 'CREDIT_ADJUST' | 'BANK';
}

interface PurchaseReturnRecord {
  id: string;
  debitNoteNo: string;
  dateBs: string;
  purchaseBillNo: string;
  supplierName: string;
  returnedItems: {
    itemId?: string;
    itemName: string;
    returnQty: number;
    unitPrice: number;
    lineTotal: number;
  }[];
  totalReturnAmount: number;
  reason: string;
  refundMode: 'CASH' | 'CREDIT_ADJUST' | 'BANK';
}

const SALES_RETURN_STORAGE_KEY = 'krishiyantra_sales_returns_v1';
const PURCHASE_RETURN_STORAGE_KEY = 'krishiyantra_purchase_returns_v1';

export const BillingSubModules: React.FC = () => {
  const {
    billingSubTab,
    purchases,
    recordPurchase,
    deletePurchase,
    importPurchasesList,
    invoices,
    cancelInvoice,
    items,
    adjustStock,
    saveItem,
    parties,
    saveParty,
    updatePartyBalance,
    logAuditAction,
    company,
    setActiveTab,
    currentAccount,
    currentRole,
    language,
    t
  } = useApp();

  const isNe = language === 'ne';

  // Purchase Entry Form State (Full Parity with Sales POS)
  const [purBillType, setPurBillType] = useState<BillType>('VAT');
  const [purBillNo, setPurBillNo] = useState('');
  const [purDateBs, setPurDateBs] = useState<string>(getTodayBsString());
  const [purSelectedPartyId, setPurSelectedPartyId] = useState('');
  const [purPartySearchQuery, setPurPartySearchQuery] = useState('');
  const [purSupplierName, setPurSupplierName] = useState('');
  const [purSupplierPan, setPurSupplierPan] = useState('');
  const [purSupplierAddress, setPurSupplierAddress] = useState('');
  const [purSupplierPhone, setPurSupplierPhone] = useState('');
  const [purPreviousDue, setPurPreviousDue] = useState<number>(0);

  const [purEntryMode, setPurEntryMode] = useState<'ITEMIZED' | 'LUMP_SUM'>('ITEMIZED');
  const [purLineItems, setPurLineItems] = useState<InvoiceItem[]>([]);
  const [purItemSearch, setPurItemSearch] = useState('');
  const [purItemId, setPurItemId] = useState('');
  const [purItemQty, setPurItemQty] = useState<number>(1);
  const [purItemRate, setPurItemRate] = useState<number>(0);
  const [purItemSize, setPurItemSize] = useState<string>('');
  const [purIsCustomSize, setPurIsCustomSize] = useState<boolean>(false);
  const [purItemIsVatExempt, setPurItemIsVatExempt] = useState<boolean>(false);
  const [purItemDiscountPercent, setPurItemDiscountPercent] = useState<number>(0);
  const [purItemUnitMode, setPurItemUnitMode] = useState<'PRIMARY' | 'SECONDARY'>('PRIMARY');
  const [purIsManualExemptMode, setPurIsManualExemptMode] = useState<boolean>(false);
  const [purManualExemptInput, setPurManualExemptInput] = useState<number | ''>('');

  const [purTaxable, setPurTaxable] = useState<number>(0);
  const [purExempt, setPurExempt] = useState<number>(0);
  const [purDiscountPercent, setPurDiscountPercent] = useState<number>(0);
  const [purFreightCharge, setPurFreightCharge] = useState<number>(0);
  const [purSummary, setPurSummary] = useState('');
  const [purPaymentMode, setPurPaymentMode] = useState<'CASH' | 'CREDIT' | 'BANK_FONEPAY'>('CASH');
  const [purPaymentDueDate, setPurPaymentDueDate] = useState<string>('');
  const [purAmountPaidInput, setPurAmountPaidInput] = useState<number | ''>('');
  const [purPhotoUrl, setPurPhotoUrl] = useState<string>('');
  const [toastMsg, setToastMsg] = useState('');
  const [isAiScanModalOpen, setIsAiScanModalOpen] = useState(false);
  const [isPurBarcodeScannerOpen, setIsPurBarcodeScannerOpen] = useState(false);
  const [createdPurchaseForPrint, setCreatedPurchaseForPrint] = useState<{
    purchase: PurchaseRecord;
    items?: InvoiceItem[];
    supplierAddress?: string;
    supplierPhone?: string;
    subtotal: number;
    discountAmount: number;
    exemptAmount: number;
    taxableAmount: number;
    vatAmount: number;
    grandTotal: number;
    billType: BillType;
  } | null>(null);
  const [isPurGeneratingPdf, setIsPurGeneratingPdf] = useState(false);
  const [purPrintFormat, setPurPrintFormat] = useState<'A4' | '80MM' | '58MM'>('A4');

  // Quick "Add New Item" from within Purchase entry — so an item that isn't
  // in the master Inventory list yet can be registered right here, instead
  // of only being addable as a one-off text line with no stock tracking.
  const [isPurQuickItemOpen, setIsPurQuickItemOpen] = useState(false);
  const [purNewItemQuickName, setPurNewItemQuickName] = useState('');
  const [qaItemName, setQaItemName] = useState('');
  const [qaItemCode, setQaItemCode] = useState('');
  const [qaItemUnit, setQaItemUnit] = useState('Pcs');
  const [qaItemCategory, setQaItemCategory] = useState<ItemCategory>('SPARE_PARTS');
  const [qaItemPurchasePrice, setQaItemPurchasePrice] = useState<number>(0);
  const [qaItemSellingPrice, setQaItemSellingPrice] = useState<number>(0);
  const [qaItemIsVatExempt, setQaItemIsVatExempt] = useState<boolean>(false);

  // =========================================================================
  // SALES RETURN STATE (बिक्री फिर्ता - बिल नं, ग्राहकको नाम वा सामानको नामबाट)
  // =========================================================================
  const [salesReturnRecords, setSalesReturnRecords] = useState<SalesReturnRecord[]>(() => {
    try {
      const saved = localStorage.getItem(SALES_RETURN_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(SALES_RETURN_STORAGE_KEY, JSON.stringify(salesReturnRecords));
    } catch {
      // ignore storage errors
    }
  }, [salesReturnRecords]);

  const [srSearchQuery, setSrSearchQuery] = useState('');
  const [selectedReturnInvoiceId, setSelectedReturnInvoiceId] = useState('');
  const [srManualBillNo, setSrManualBillNo] = useState('');
  const [srCustomerName, setSrCustomerName] = useState('');
  const [srItemSearch, setSrItemSearch] = useState('');
  const [srSelectedItemId, setSrSelectedItemId] = useState('');
  const [srCustomItemName, setSrCustomItemName] = useState('');
  const [srReturnQty, setSrReturnQty] = useState<number>(1);
  const [srUnitPrice, setSrUnitPrice] = useState<number>(0);
  const [srRefundMode, setSrRefundMode] = useState<'CASH' | 'CREDIT_ADJUST' | 'BANK'>('CREDIT_ADJUST');
  const [salesReturnReason, setSalesReturnReason] = useState('ग्राहकबाट सामान फिर्ता / साटफेर (Sales Return)');

  // Per-line selection when an existing invoice is chosen
  const [invoiceLineReturns, setInvoiceLineReturns] = useState<
    Record<number, { selected: boolean; returnQty: number }>
  >({});

  // =========================================================================
  // PURCHASE RETURN STATE (खरिद फिर्ता - बिल नं, सप्लायरको नाम वा सामानबाट)
  // =========================================================================
  const [purchaseReturnRecords, setPurchaseReturnRecords] = useState<PurchaseReturnRecord[]>(() => {
    try {
      const saved = localStorage.getItem(PURCHASE_RETURN_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(PURCHASE_RETURN_STORAGE_KEY, JSON.stringify(purchaseReturnRecords));
    } catch {
      // ignore storage errors
    }
  }, [purchaseReturnRecords]);

  const [prSearchQuery, setPrSearchQuery] = useState('');
  const [selectedPurReturnId, setSelectedPurReturnId] = useState('');
  const [prManualBillNo, setPrManualBillNo] = useState('');
  const [prSupplierName, setPrSupplierName] = useState('');
  const [prItemSearch, setPrItemSearch] = useState('');
  const [purReturnItemId, setPurReturnItemId] = useState('');
  const [prCustomItemName, setPrCustomItemName] = useState('');
  const [purReturnQty, setPurReturnQty] = useState<number>(1);
  const [prUnitPrice, setPrUnitPrice] = useState<number>(0);
  const [purReturnAmount, setPurReturnAmount] = useState<number>(0);
  const [prRefundMode, setPrRefundMode] = useState<'CASH' | 'CREDIT_ADJUST' | 'BANK'>('CREDIT_ADJUST');
  const [purReturnReason, setPurReturnReason] = useState(
    'ड्यामेज वा आपूर्तिकर्तालाई सामान फिर्ता (Purchase Return / Debit Note)'
  );

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 4000);
  };

  // Filtered invoices by Invoice No, Customer Name, or Item Name
  const matchingInvoicesForReturn = useMemo(() => {
    const q = srSearchQuery.trim().toLowerCase();
    if (!q) return invoices;
    return invoices.filter(
      (inv) =>
        inv.invoiceNo.toLowerCase().includes(q) ||
        inv.customerName.toLowerCase().includes(q) ||
        (inv.customerPhone || '').toLowerCase().includes(q) ||
        inv.items.some((it) => it.name.toLowerCase().includes(q))
    );
  }, [invoices, srSearchQuery]);

  // Filtered inventory items for Sales Return item picker
  const filteredSrItems = useMemo(() => {
    const q = srItemSearch.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (it) =>
        it.nameNe.toLowerCase().includes(q) ||
        it.nameEn.toLowerCase().includes(q) ||
        it.code.toLowerCase().includes(q)
    );
  }, [items, srItemSearch]);

  const currentPurItem = items.find((i) => i.id === purItemId);

  const purAvailableSizes = useMemo(() => {
    const sizes = new Set<string>();
    // User requested exact presets: 200gm, 10ml, 1ltr, 6*100mtr
    const standardPresets = [
      '200gm',
      '10ml',
      '1ltr',
      '6*100mtr',
      '500gm',
      '100ml',
      '250ml',
      '5ltr',
      '1 kg',
      '5 kg',
      '10 kg',
      '25 kg',
      '50 kg',
      'Standard',
      'Small',
      'Medium',
      'Large',
      'XL',
      '16mm',
      '20mm',
      '25mm',
      '32mm',
      '1/2"',
      '3/4"',
      '1"',
      '1.5"',
      '2"',
      '3"'
    ];
    standardPresets.forEach((s) => sizes.add(s));
    if (currentPurItem) {
      if (currentPurItem.size && currentPurItem.size.trim()) sizes.add(currentPurItem.size.trim());
      const currentName = (isNe ? currentPurItem.nameNe || currentPurItem.nameEn : currentPurItem.nameEn).trim().toLowerCase();
      items.forEach((it) => {
        const itName = (isNe ? it.nameNe || it.nameEn : it.nameEn).trim().toLowerCase();
        if (itName === currentName && it.size && it.size.trim()) {
          sizes.add(it.size.trim());
        }
      });
    }
    return Array.from(sizes);
  }, [currentPurItem, items, isNe]);

  // Filtered purchase bills by Bill No, Supplier Name, or Item Summary
  const matchingPurchasesForReturn = useMemo(() => {
    const q = prSearchQuery.trim().toLowerCase();
    if (!q) return purchases;
    return purchases.filter(
      (p) =>
        p.purchaseBillNo.toLowerCase().includes(q) ||
        p.supplierName.toLowerCase().includes(q) ||
        (p.supplierPan || '').toLowerCase().includes(q) ||
        p.itemsSummary.toLowerCase().includes(q)
    );
  }, [purchases, prSearchQuery]);

  // Filtered inventory items for Purchase Return item picker
  const filteredPrItems = useMemo(() => {
    const q = prItemSearch.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (it) =>
        it.nameNe.toLowerCase().includes(q) ||
        it.nameEn.toLowerCase().includes(q) ||
        it.code.toLowerCase().includes(q)
    );
  }, [items, prItemSearch]);

  if (billingSubTab === 'PAYMENT_IN' || billingSubTab === 'PAYMENT_OUT') {
    return <VoucherScreen />;
  }

  // ===========================================================================
  // TAB 2: PURCHASE ENTRY (Full Parity with Sales POS)
  // ===========================================================================
  if (billingSubTab === 'PURCHASE') {
    const nextPurBillNoPreview = `PB-${company.fiscalYear || '081/82'}-${String(purchases.length + 1).padStart(4, '0')}`;

    const itemizedGrossSubtotal = purLineItems.reduce((sum, it) => sum + (it.quantity * it.rate), 0);
    const itemizedDiscountTotal = purLineItems.reduce(
      (sum, it) => sum + ((it.quantity * it.rate * (it.discountPercent || 0)) / 100),
      0
    );
    const itemizedNetSubtotal = purLineItems.reduce((sum, it) => sum + it.amount, 0);

    const activeSubtotal = purEntryMode === 'ITEMIZED' && purLineItems.length > 0 ? itemizedGrossSubtotal : purTaxable + purExempt;
    const billDiscountAmt = Math.round((activeSubtotal * (purDiscountPercent || 0)) / 100);
    const totalDiscountAmt = (purEntryMode === 'ITEMIZED' && purLineItems.length > 0 ? itemizedDiscountTotal : 0) + billDiscountAmt;

    const autoExempt = purEntryMode === 'ITEMIZED' && purLineItems.length > 0
      ? purLineItems.filter((it) => it.isVatExempt).reduce((sum, it) => sum + it.amount, 0)
      : purExempt;

    const netExempt = purIsManualExemptMode && purManualExemptInput !== ''
      ? Number(purManualExemptInput)
      : autoExempt;

    // sub total paxe non taxable amount halera taxable amount nekhalne
    const netTaxable = Math.max(0, activeSubtotal - totalDiscountAmt - netExempt + (purFreightCharge || 0));
    const vatAmount = purBillType === 'VAT' ? Math.round(netTaxable * 0.13 * 100) / 100 : 0;
    const grandTotal = Math.round((netTaxable + netExempt + vatAmount) * 100) / 100;
    const netTotalPurDue = purPreviousDue + grandTotal;

    const currentPurItem = items.find((i) => i.id === purItemId);

    // ✏️ खरिद बिलभित्रको सामान फेरि entry row मा ल्याएर सच्याउने
    const handleEditPurLineItem = (idx: number) => {
      const line = purLineItems[idx];
      if (!line) return;
      setPurEntryMode('ITEMIZED');
      setPurItemId(line.itemId);
      setPurItemUnitMode(line.unitMode || 'PRIMARY');
      setPurItemQty(line.quantity);
      setPurItemRate(line.rate);
      setPurItemSize(line.size || '');
      setPurItemDiscountPercent(line.discountPercent || 0);
      setPurItemIsVatExempt(!!line.isVatExempt);
      setPurLineItems(purLineItems.filter((_, i) => i !== idx));
    };

    const handleUpdatePurLineItem = (
      idx: number,
      field: 'name' | 'size' | 'quantity' | 'rate' | 'discountPercent' | 'isVatExempt' | 'unitMode',
      val: any
    ) => {
      const updated = [...purLineItems];
      const target = { ...updated[idx] };
      const matchedItem = items.find((i) => i.id === target.itemId);
      const ratio =
        matchedItem && matchedItem.secondaryUnitRatio && matchedItem.secondaryUnitRatio > 0
          ? matchedItem.secondaryUnitRatio
          : 1;

      if (field === 'name') target.name = String(val);
      if (field === 'size') target.size = String(val);
      if (field === 'quantity') target.quantity = Math.max(0.01, Number(val) || 0);
      if (field === 'rate') target.rate = Math.max(0, Number(val) || 0);
      if (field === 'discountPercent') target.discountPercent = Math.min(100, Math.max(0, Number(val) || 0));
      if (field === 'isVatExempt') target.isVatExempt = Boolean(val);
      if (field === 'unitMode' && matchedItem) {
        const nextMode: 'PRIMARY' | 'SECONDARY' = val === 'SECONDARY' && matchedItem.secondaryUnit ? 'SECONDARY' : 'PRIMARY';
        target.unitMode = nextMode;
        if (nextMode === 'SECONDARY' && matchedItem.secondaryUnit) {
          target.unit = matchedItem.secondaryUnit;
          target.rate =
            matchedItem.secondaryPurchasePrice && matchedItem.secondaryPurchasePrice > 0
              ? matchedItem.secondaryPurchasePrice
              : Math.round((matchedItem.purchasePrice / ratio) * 100) / 100;
        } else {
          target.unit = matchedItem.unit;
          target.rate = matchedItem.purchasePrice;
        }
      }

      target.primaryQtyEquivalent =
        target.unitMode === 'SECONDARY'
          ? Math.round((target.quantity / ratio) * 10000) / 10000
          : target.quantity;

      const disc = target.discountPercent || 0;
      const gross = target.quantity * target.rate;
      target.amount = Math.round((gross * (1 - disc / 100)) * 100) / 100;

      updated[idx] = target;
      setPurLineItems(updated);
    };

    const handleTogglePurUnitMode = (mode: 'PRIMARY' | 'SECONDARY') => {
      setPurItemUnitMode(mode);
      if (!currentPurItem) return;
      if (mode === 'SECONDARY' && currentPurItem.secondaryUnit) {
        const ratio = currentPurItem.secondaryUnitRatio && currentPurItem.secondaryUnitRatio > 0 ? currentPurItem.secondaryUnitRatio : 1;
        const secRate =
          currentPurItem.secondaryPurchasePrice && currentPurItem.secondaryPurchasePrice > 0
            ? currentPurItem.secondaryPurchasePrice
            : Math.round((currentPurItem.purchasePrice / ratio) * 100) / 100;
        setPurItemRate(secRate);
      } else {
        setPurItemRate(currentPurItem.purchasePrice);
      }
    };

    const handleSelectPurByCode = (code: string) => {
      if (!code) {
        setPurItemId('');
        setPurItemUnitMode('PRIMARY');
        setPurItemRate(0);
        setPurItemSize('');
        setPurIsCustomSize(false);
        setPurItemIsVatExempt(false);
        setPurItemDiscountPercent(0);
        return;
      }
      const matched = items.find((i) => i.code.trim().toLowerCase() === code.trim().toLowerCase());
      if (matched) {
        setPurItemId(matched.id);
        setPurItemUnitMode('PRIMARY');
        setPurItemRate(matched.purchasePrice);
        setPurItemSize(matched.size || '');
        setPurIsCustomSize(false);
        setPurItemIsVatExempt(matched.isVatExempt || false);
        setPurItemDiscountPercent(0);
      }
    };

    const handleSelectPurByName = (id: string) => {
      if (!id) {
        setPurItemId('');
        setPurItemUnitMode('PRIMARY');
        setPurItemRate(0);
        setPurItemSize('');
        setPurIsCustomSize(false);
        setPurItemIsVatExempt(false);
        setPurItemDiscountPercent(0);
        return;
      }
      const matched = items.find((i) => i.id === id);
      if (matched) {
        setPurItemId(matched.id);
        setPurItemUnitMode('PRIMARY');
        setPurItemRate(matched.purchasePrice);
        setPurItemSize(matched.size || '');
        setPurIsCustomSize(false);
        setPurItemIsVatExempt(matched.isVatExempt || false);
        setPurItemDiscountPercent(0);
      }
    };

    const purQuickAddCategories: { id: string; labelNe: string; labelEn: string }[] =
      company.productCategories && company.productCategories.length > 0
        ? company.productCategories
        : [...DEFAULT_PRODUCT_CATEGORIES, ...(company.customCategories || [])];

    const handleOpenPurQuickAddItem = () => {
      setQaItemName(purNewItemQuickName.trim());
      setQaItemCode('');
      setQaItemUnit('Pcs');
      setQaItemCategory((purQuickAddCategories[0]?.id as ItemCategory) || 'SPARE_PARTS');
      setQaItemPurchasePrice(0);
      setQaItemSellingPrice(0);
      setQaItemIsVatExempt(false);
      setIsPurQuickItemOpen(true);
    };

    const handleSavePurQuickAddItem = () => {
      if (!qaItemName.trim()) {
        showToast(isNe ? 'सामानको नाम लेख्नुहोस्!' : 'Please enter the item name!');
        return;
      }
      const finalCode = qaItemCode.trim() || `KY-${Date.now().toString().slice(-4)}`;
      const newItem: Item = {
        id: `item-${Date.now()}`,
        code: finalCode,
        nameEn: qaItemName.trim(),
        nameNe: qaItemName.trim(),
        category: qaItemCategory,
        itemType: 'FINISHED_GOODS',
        unit: qaItemUnit.trim() || 'Pcs',
        primaryUnit: qaItemUnit.trim() || 'Pcs',
        purchasePrice: Math.max(0, qaItemPurchasePrice),
        sellingPrice: Math.max(0, qaItemSellingPrice || qaItemPurchasePrice),
        openingStock: 0,
        currentStock: 0,
        minStockAlert: 1,
        isVatExempt: qaItemIsVatExempt
      };
      saveItem(newItem);

      // Auto-select the freshly created item into the draft purchase line
      setPurItemId(newItem.id);
      setPurItemUnitMode('PRIMARY');
      setPurItemRate(newItem.purchasePrice);
      setPurItemSize('');
      setPurIsCustomSize(false);
      setPurItemIsVatExempt(newItem.isVatExempt);
      setPurItemDiscountPercent(0);
      setPurItemSearch('');
      setPurNewItemQuickName('');
      setIsPurQuickItemOpen(false);
      showToast(isNe ? 'नयाँ सामान सूचीमा थपियो!' : 'New item added to inventory!');
    };

    const handleSelectPurSize = (sz: string) => {
      setPurItemSize(sz);
      if (currentPurItem && sz) {
        const currentName = (isNe ? currentPurItem.nameNe || currentPurItem.nameEn : currentPurItem.nameEn).trim().toLowerCase();
        const variantItem = items.find((it) => {
          const itName = (isNe ? it.nameNe || it.nameEn : it.nameEn).trim().toLowerCase();
          return itName === currentName && it.size?.trim().toLowerCase() === sz.trim().toLowerCase();
        });
        if (variantItem && variantItem.id !== currentPurItem.id) {
          setPurItemId(variantItem.id);
          setPurItemUnitMode('PRIMARY');
          setPurItemRate(variantItem.purchasePrice);
          setPurItemIsVatExempt(variantItem.isVatExempt || false);
        }
      }
    };

    const filteredPurParties = parties.filter(isSupplierParty).filter((p) => {
      const q = purPartySearchQuery.trim().toLowerCase();
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        (p.phone || '').toLowerCase().includes(q) ||
        (p.address || '').toLowerCase().includes(q) ||
        (p.panNo || '').toLowerCase().includes(q)
      );
    });

    const filteredPurInventory = items.filter((it) => {
      const q = purItemSearch.trim().toLowerCase();
      if (!q) return true;
      return (
        it.nameNe.toLowerCase().includes(q) ||
        it.nameEn.toLowerCase().includes(q) ||
        it.code.toLowerCase().includes(q)
      );
    });

    const handleSelectPurParty = (partyId: string) => {
      setPurSelectedPartyId(partyId);
      if (!partyId) {
        setPurPreviousDue(0);
        return;
      }
      const p = parties.find((pt) => pt.id === partyId);
      if (p) {
        setPurSupplierName(p.name);
        setPurSupplierPan(p.panNo || '');
        setPurSupplierAddress(p.address || '');
        setPurSupplierPhone(p.phone || '');
        setPurPreviousDue(p.currentBalance !== undefined ? p.currentBalance : p.openingBalance || 0);
      }
    };

    const handleAddPurLineItem = () => {
      if (purItemQty <= 0) return;

      const resolvedItem =
        currentPurItem ||
        (purItemSearch.trim() && filteredPurInventory.length === 1 ? filteredPurInventory[0] : undefined);

      const discPct = Math.min(100, Math.max(0, purItemDiscountPercent || 0));

      if (resolvedItem) {
        const ratio = resolvedItem.secondaryUnitRatio && resolvedItem.secondaryUnitRatio > 0 ? resolvedItem.secondaryUnitRatio : 1;
        const activeUnitMode: 'PRIMARY' | 'SECONDARY' =
          purItemUnitMode === 'SECONDARY' && resolvedItem.secondaryUnit ? 'SECONDARY' : 'PRIMARY';
        const activeUnitLabel =
          activeUnitMode === 'SECONDARY' && resolvedItem.secondaryUnit ? resolvedItem.secondaryUnit : resolvedItem.unit;
        const rateToUse =
          purItemRate > 0
            ? purItemRate
            : activeUnitMode === 'SECONDARY'
            ? resolvedItem.secondaryPurchasePrice || Math.round((resolvedItem.purchasePrice / ratio) * 100) / 100
            : resolvedItem.purchasePrice;
        const sizeToUse = purItemSize.trim() || resolvedItem.size || '';
        const existingIdx = purLineItems.findIndex(
          (l) => l.itemId === resolvedItem.id && (l.unitMode || 'PRIMARY') === activeUnitMode
        );
        if (existingIdx !== -1) {
          const updated = [...purLineItems];
          const newQty = updated[existingIdx].quantity + purItemQty;
          const disc = discPct > 0 ? discPct : (updated[existingIdx].discountPercent || 0);
          const gross = newQty * rateToUse;
          const net = Math.round((gross * (1 - disc / 100)) * 100) / 100;
          const newPrimaryEquiv =
            activeUnitMode === 'SECONDARY' ? Math.round((newQty / ratio) * 10000) / 10000 : newQty;
          updated[existingIdx] = {
            ...updated[existingIdx],
            quantity: newQty,
            unit: activeUnitLabel,
            unitMode: activeUnitMode,
            primaryQtyEquivalent: newPrimaryEquiv,
            rate: rateToUse,
            size: sizeToUse || updated[existingIdx].size || '',
            discountPercent: disc,
            amount: net,
            isVatExempt: purItemIsVatExempt
          };
          setPurLineItems(updated);
        } else {
          const gross = purItemQty * rateToUse;
          const net = Math.round((gross * (1 - discPct / 100)) * 100) / 100;
          const calcPrimaryEquiv =
            activeUnitMode === 'SECONDARY' ? Math.round((purItemQty / ratio) * 10000) / 10000 : purItemQty;
          setPurLineItems([
            ...purLineItems,
            {
              itemId: resolvedItem.id,
              code: resolvedItem.code,
              name: isNe ? resolvedItem.nameNe || resolvedItem.nameEn : resolvedItem.nameEn,
              size: sizeToUse,
              unit: activeUnitLabel,
              unitMode: activeUnitMode,
              primaryQtyEquivalent: calcPrimaryEquiv,
              hsCode: resolvedItem.hsCode || resolvedItem.hsnCode,
              quantity: purItemQty,
              rate: rateToUse,
              discountPercent: discPct,
              amount: net,
              isVatExempt: purItemIsVatExempt
            }
          ]);
        }
      } else if (purItemSearch.trim() || purItemRate > 0) {
        const customName = purItemSearch.trim() || (isNe ? `खरिद सामान #${purLineItems.length + 1}` : `Purchase Item #${purLineItems.length + 1}`);
        const rateToUse = Math.max(0, purItemRate);
        const gross = purItemQty * rateToUse;
        const net = Math.round((gross * (1 - discPct / 100)) * 100) / 100;
        setPurLineItems([
          ...purLineItems,
          {
            itemId: `pur-custom-${Date.now()}`,
            code: `P-${purLineItems.length + 1}`,
            name: customName,
            size: purItemSize.trim(),
            unit: 'Pcs',
            unitMode: 'PRIMARY',
            primaryQtyEquivalent: purItemQty,
            quantity: purItemQty,
            rate: rateToUse,
            discountPercent: discPct,
            amount: net,
            isVatExempt: purItemIsVatExempt
          }
        ]);
      } else {
        showToast(isNe ? 'कृपया सामान छान्नुहोस् वा नाम/दर टाइप गर्नुहोस्!' : 'Please select an item or type item name & rate!');
        return;
      }

      setPurItemId('');
      setPurItemUnitMode('PRIMARY');
      setPurItemQty(1);
      setPurItemRate(0);
      setPurItemSize('');
      setPurIsCustomSize(false);
      setPurItemIsVatExempt(false);
      setPurItemDiscountPercent(0);
      setPurItemSearch('');
    };

    const handlePurBarcodeScanned = (scannedItem: Item, quantity: number = 1) => {
      const rateToUse = scannedItem.purchasePrice || scannedItem.sellingPrice;
      const existingIdx = purLineItems.findIndex((l) => l.itemId === scannedItem.id);
      if (existingIdx !== -1) {
        const updated = [...purLineItems];
        const newQty = updated[existingIdx].quantity + quantity;
        updated[existingIdx] = {
          ...updated[existingIdx],
          quantity: newQty,
          rate: rateToUse,
          amount: newQty * rateToUse
        };
        setPurLineItems(updated);
      } else {
        setPurLineItems((prev) => [
          ...prev,
          {
            itemId: scannedItem.id,
            code: scannedItem.code,
            name: isNe ? scannedItem.nameNe || scannedItem.nameEn : scannedItem.nameEn,
            unit: scannedItem.unit,
            quantity,
            rate: rateToUse,
            amount: quantity * rateToUse,
            isVatExempt: scannedItem.isVatExempt
          }
        ]);
      }
      showToast(`${scannedItem.nameNe || scannedItem.nameEn} (+${quantity}) खरिद बिलमा थपियो!`);
    };

    const handleDirectPurchaseExcelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const buffer = event.target?.result as ArrayBuffer;
          const { headers, rows } = parseExcelFile(buffer);
          if (rows.length === 0) {
            showToast(isNe ? 'एक्सेल फाइलमा कुनै डाटा भेटिएन।' : 'No rows found in Excel file.');
            return;
          }

          let nameIdx = -1;
          let qtyIdx = -1;
          let rateIdx = -1;
          let totalIdx = -1;
          let suppIdx = -1;
          let billIdx = -1;
          let panIdx = -1;
          let dateIdx = -1;
          let unitIdx = -1;

          headers.forEach((h, idx) => {
            const lower = String(h || '').toLowerCase();
            if (nameIdx === -1 && (lower.includes('item') || lower.includes('सामान') || lower.includes('विवरण') || lower.includes('summary') || lower.includes('description') || (lower.includes('name') && !lower.includes('supp')))) {
              nameIdx = idx;
            }
            if (qtyIdx === -1 && (lower.includes('qty') || lower.includes('quantity') || lower.includes('परिमाण') || lower.includes('संख्या'))) {
              qtyIdx = idx;
            }
            if (rateIdx === -1 && (lower.includes('rate') || lower.includes('price') || lower.includes('cost') || lower.includes('दर') || lower.includes('मूल्य'))) {
              rateIdx = idx;
            }
            if (totalIdx === -1 && (lower.includes('total') || lower.includes('amount') || lower.includes('taxable') || lower.includes('जम्मा') || lower.includes('रकम') || lower.includes('करयोग्य'))) {
              totalIdx = idx;
            }
            if (suppIdx === -1 && (lower.includes('supp') || lower.includes('vendor') || lower.includes('आपूर्तिकर्ता') || lower.includes('party') || lower.includes('पार्टी') || lower.includes('नाम'))) {
              suppIdx = idx;
            }
            if (billIdx === -1 && (lower.includes('bill') || lower.includes('inv') || lower.includes('बीजक') || lower.includes('बिल'))) {
              billIdx = idx;
            }
            if (panIdx === -1 && (lower.includes('pan') || lower.includes('प्यान') || lower.includes('vat no'))) {
              panIdx = idx;
            }
            if (dateIdx === -1 && (lower.includes('date') || lower.includes('मिति'))) {
              dateIdx = idx;
            }
            if (unitIdx === -1 && (lower.includes('unit') || lower.includes('एकाइ'))) {
              unitIdx = idx;
            }
          });

          const extractedLines: InvoiceItem[] = [];
          const batchPurchases: PurchaseRecord[] = [];
          let firstSuppName = '';
          let firstSuppPan = '';
          let firstBillNo = '';

          rows.forEach((row, idx) => {
            const firstCell = String(row[0] || '').toLowerCase();
            if (firstCell.includes('total') || firstCell.includes('जम्मा')) return;

            const itemName =
              nameIdx >= 0
                ? String(row[nameIdx] || '').trim()
                : suppIdx >= 0
                ? String(row[suppIdx] || '').trim()
                : String(row[1] || row[0] || '').trim();
            if (!itemName) return;

            if (!firstSuppName && suppIdx >= 0 && row[suppIdx]) firstSuppName = String(row[suppIdx]).trim();
            if (!firstSuppPan && panIdx >= 0 && row[panIdx]) firstSuppPan = String(row[panIdx]).trim();
            if (!firstBillNo && billIdx >= 0 && row[billIdx]) firstBillNo = String(row[billIdx]).trim();

            const qty = qtyIdx >= 0 ? Math.max(1, parseExcelNumericValue(row[qtyIdx]) || 1) : 1;
            const totalVal = totalIdx >= 0 ? parseExcelNumericValue(row[totalIdx]) : 0;
            const rateVal =
              rateIdx >= 0
                ? parseExcelNumericValue(row[rateIdx])
                : totalVal > 0
                ? Math.round((totalVal / qty) * 100) / 100
                : parseExcelNumericValue(row[2]) || 0;
            const lineTotal = totalVal > 0 ? totalVal : qty * rateVal;
            const unitStr = unitIdx >= 0 && row[unitIdx] ? String(row[unitIdx]).trim() : 'Pcs';

            if (lineTotal > 0 || rateVal > 0) {
              extractedLines.push({
                itemId: `xl-pur-${Date.now()}-${idx}`,
                code: `XL-P${idx + 1}`,
                name: itemName,
                unit: unitStr,
                quantity: qty,
                rate: rateVal || lineTotal,
                amount: lineTotal || rateVal * qty,
                isVatExempt: false
              });
            }

            if (billIdx >= 0 && suppIdx >= 0 && lineTotal > 0) {
              const vAmt = purBillType === 'VAT' ? Math.round((lineTotal * 0.13 / 1.13) * 100) / 100 : 0;
              const tAmt = Math.round((lineTotal - vAmt) * 100) / 100;
              batchPurchases.push({
                id: `pur-xl-${Date.now()}-${idx}`,
                purchaseBillNo: String(row[billIdx] || `PB-XL-${idx + 1}`).trim(),
                supplierName: String(row[suppIdx] || 'आपूर्तिकर्ता').trim(),
                supplierPan: panIdx >= 0 ? String(row[panIdx] || '').trim() : '',
                ...(() => {
                  const d = resolveDatePair({ bs: dateIdx >= 0 && row[dateIdx] ? String(row[dateIdx]).trim() : '' });
                  return { dateBs: d.dateBs, dateAd: d.dateAd };
                })(),
                itemsSummary: nameIdx >= 0 && row[nameIdx] ? String(row[nameIdx]).trim() : itemName,
                taxableAmount: tAmt,
                exemptAmount: 0,
                vatAmount: vAmt,
                grandTotal: lineTotal,
                paymentMode: 'CASH'
              });
            }
          });

          if (firstSuppName) setPurSupplierName(firstSuppName);
          if (firstSuppPan) setPurSupplierPan(firstSuppPan);
          if (firstBillNo) setPurBillNo(firstBillNo);

          if (extractedLines.length > 0) {
            setPurEntryMode('ITEMIZED');
            setPurLineItems(extractedLines);
            setPurTaxable(extractedLines.reduce((s, i) => s + i.amount, 0));
            setPurSummary(extractedLines.map((i) => `${i.name} (${i.quantity} ${i.unit})`).join(', '));
          }
          if (batchPurchases.length > 1) {
            importPurchasesList(batchPurchases);
          }

          showToast(
            isNe
              ? `एक्सेल फाइल (${file.name}) बाट ${extractedLines.length} खरिद विवरण सिधै अपलोड भयो!`
              : `Uploaded ${extractedLines.length} purchase rows directly from Excel!`
          );
        } catch (err) {
          console.error('Purchase Excel error:', err);
          showToast(isNe ? 'एक्सेल फाइल पढ्न सकिएन।' : 'Failed to read Excel file.');
        }
      };
      reader.readAsArrayBuffer(file);
      e.target.value = '';
    };

    const handlePurPhotoCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      try {
        const dataUrl = await fileToDataUrl(file, 1400, 1400, 0.85);
        setPurPhotoUrl(dataUrl);
        showToast(isNe ? 'खरिद बिलको फोटो संलग्न भयो र पढिँदैछ...' : 'Purchase bill photo attached & scanning...');

        try {
          const res = await authFetch('/api/scan-handwritten-bill', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              imageBase64: dataUrl,
              mimeType: dataUrl.startsWith('data:image/png') ? 'image/png' : 'image/jpeg'
            })
          });
          const json = await res.json();
          if (res.ok && json.success && json.data) {
            const d = json.data;
            if (d.invoiceNo && !purBillNo) setPurBillNo(d.invoiceNo);
            if (d.customerName && !purSupplierName) setPurSupplierName(d.customerName);
            if (d.customerPan && !purSupplierPan) setPurSupplierPan(d.customerPan);
            if (d.customerAddress && !purSupplierAddress) setPurSupplierAddress(d.customerAddress);
            if (d.customerPhone && !purSupplierPhone) setPurSupplierPhone(d.customerPhone);
            if (Array.isArray(d.items) && d.items.length > 0) {
              const mapped: InvoiceItem[] = d.items.map((it: any, idx: number) => ({
                itemId: `pur-photo-${Date.now()}-${idx}`,
                code: `P-SCAN-${idx + 1}`,
                name: it.name || `खरिद सामान ${idx + 1}`,
                unit: it.unit || 'Pcs',
                quantity: Math.max(1, Number(it.quantity) || 1),
                rate: Number(it.rate) || 0,
                amount: Number(it.amount) || (Math.max(1, Number(it.quantity) || 1) * (Number(it.rate) || 0)),
                isVatExempt: false
              }));
              setPurLineItems(mapped);
              setPurTaxable(mapped.reduce((s, i) => s + i.amount, 0));
              setPurSummary(mapped.map((i) => `${i.name} (${i.quantity} ${i.unit})`).join(', '));
            }
            showToast(isNe ? 'फोटोबाट खरिद बिल विवरण स्वतः भरियो!' : 'Purchase bill details auto-filled from photo!');
          }
        } catch {
          // Keep photo attached
        }
      } catch (err) {
        console.error(err);
      }
    };

    const handleSavePurchase = (e?: React.FormEvent, shouldPrint: boolean = true) => {
      if (e) e.preventDefault();

      // Auto-commit draft row if cashier entered an item but didn't press "+ थप्नुहोस्"
      let finalPurLineItems = [...purLineItems];
      const resolvedDraftItem =
        currentPurItem ||
        (purItemSearch.trim() && filteredPurInventory.length === 1 ? filteredPurInventory[0] : undefined);

      if (resolvedDraftItem && purItemQty > 0) {
        const ratio = resolvedDraftItem.secondaryUnitRatio && resolvedDraftItem.secondaryUnitRatio > 0 ? resolvedDraftItem.secondaryUnitRatio : 1;
        const activeUnitMode: 'PRIMARY' | 'SECONDARY' =
          purItemUnitMode === 'SECONDARY' && resolvedDraftItem.secondaryUnit ? 'SECONDARY' : 'PRIMARY';
        const activeUnitLabel =
          activeUnitMode === 'SECONDARY' && resolvedDraftItem.secondaryUnit ? resolvedDraftItem.secondaryUnit : resolvedDraftItem.unit;
        const rateToUse =
          purItemRate > 0
            ? purItemRate
            : activeUnitMode === 'SECONDARY'
            ? resolvedDraftItem.secondaryPurchasePrice || Math.round((resolvedDraftItem.purchasePrice / ratio) * 100) / 100
            : resolvedDraftItem.purchasePrice;
        const discPct = Math.min(100, Math.max(0, purItemDiscountPercent || 0));
        const gross = purItemQty * rateToUse;
        const net = Math.round((gross * (1 - discPct / 100)) * 100) / 100;
        const calcPrimaryEquiv =
          activeUnitMode === 'SECONDARY' ? Math.round((purItemQty / ratio) * 10000) / 10000 : purItemQty;
        finalPurLineItems.push({
          itemId: resolvedDraftItem.id,
          code: resolvedDraftItem.code,
          name: isNe ? resolvedDraftItem.nameNe || resolvedDraftItem.nameEn : resolvedDraftItem.nameEn,
          size: purItemSize.trim() || resolvedDraftItem.size || '',
          unit: activeUnitLabel,
          unitMode: activeUnitMode,
          primaryQtyEquivalent: calcPrimaryEquiv,
          hsCode: resolvedDraftItem.hsCode || resolvedDraftItem.hsnCode,
          quantity: purItemQty,
          rate: rateToUse,
          discountPercent: discPct,
          amount: net,
          isVatExempt: purItemIsVatExempt
        });
      } else if (purItemRate > 0 && purItemQty > 0 && purItemSearch.trim()) {
        const discPct = Math.min(100, Math.max(0, purItemDiscountPercent || 0));
        const gross = purItemQty * purItemRate;
        const net = Math.round((gross * (1 - discPct / 100)) * 100) / 100;
        finalPurLineItems.push({
          itemId: `pur-custom-${Date.now()}`,
          code: `P-${finalPurLineItems.length + 1}`,
          name: purItemSearch.trim(),
          size: purItemSize.trim(),
          unit: 'थान',
          unitMode: 'PRIMARY',
          primaryQtyEquivalent: purItemQty,
          quantity: purItemQty,
          rate: purItemRate,
          discountPercent: discPct,
          amount: net,
          isVatExempt: purItemIsVatExempt
        });
      }

      if (finalPurLineItems.length === 0 && purTaxable <= 0 && grandTotal <= 0) {
        showToast(isNe ? 'कृपया खरिद सामान वा रकम प्रविष्ट गर्नुहोस्!' : 'Please add purchase items or amount!');
        return;
      }

      const finalSupplier = purSupplierName.trim() || (isNe ? 'नगद आपूर्तिकर्ता' : 'Cash Supplier');

      const summaryText =
        purSummary.trim() ||
        (finalPurLineItems.length > 0
          ? finalPurLineItems.map((l) => `${l.name} (${l.quantity} ${l.unit})`).join(', ')
          : 'कृषि औजार तथा पार्टपुर्जा खरिद');

      // Live recalculation based on finalPurLineItems
      const calcGrossSubtotal = finalPurLineItems.length > 0
        ? finalPurLineItems.reduce((sum, it) => sum + (it.quantity * it.rate), 0)
        : activeSubtotal;
      const calcDiscountTotal = finalPurLineItems.length > 0
        ? finalPurLineItems.reduce((sum, it) => sum + ((it.quantity * it.rate * (it.discountPercent || 0)) / 100), 0)
        : 0;
      const calcBillDisc = Math.round((calcGrossSubtotal * (purDiscountPercent || 0)) / 100);
      const calcTotDisc = calcDiscountTotal + calcBillDisc;
      const calcAutoExempt = finalPurLineItems.length > 0
        ? finalPurLineItems.filter((it) => it.isVatExempt).reduce((sum, it) => sum + it.amount, 0)
        : purExempt;
      const calcNetExempt = purIsManualExemptMode && purManualExemptInput !== ''
        ? Number(purManualExemptInput)
        : calcAutoExempt;
      const calcNetTaxable = Math.max(0, calcGrossSubtotal - calcTotDisc - calcNetExempt + (purFreightCharge || 0));
      const calcVat = purBillType === 'VAT' ? Math.round(calcNetTaxable * 0.13 * 100) / 100 : 0;
      const calcGrand = Math.round((calcNetTaxable + calcNetExempt + calcVat) * 100) / 100;

      const resolvedPaidToday =
        purAmountPaidInput !== ''
          ? Number(purAmountPaidInput)
          : purPaymentMode === 'CREDIT'
          ? 0
          : calcGrand;

      const savedPurRecord: PurchaseRecord = {
        id: `pur-${Date.now()}`,
        purchaseBillNo: purBillNo.trim() || nextPurBillNoPreview,
        supplierName: finalSupplier,
        supplierPan: purSupplierPan.trim(),
        ...(() => {
          const d = resolveDatePair({ bs: purDateBs });
          return { dateBs: d.dateBs, dateAd: d.dateAd };
        })(),
        itemsSummary: summaryText,
        items: finalPurLineItems.length > 0 ? [...finalPurLineItems] : undefined,
        taxableAmount: calcNetTaxable,
        exemptAmount: calcNetExempt,
        vatAmount: calcVat,
        grandTotal: calcGrand,
        paymentMode: purPaymentMode
      };

      // 1. ALWAYS SAVE PURCHASE RECORD TO DATABASE FIRST
      recordPurchase(
        savedPurRecord,
        {
          partyId: purSelectedPartyId || undefined,
          address: purSupplierAddress.trim() || undefined,
          phone: purSupplierPhone.trim() || undefined,
          amountPaidToday: resolvedPaidToday
        }
      );

      // Auto-increment inventory stock for matched items (using primaryQtyEquivalent when secondary unit was selected)
      finalPurLineItems.forEach((line) => {
        const matched = items.find(
          (i) => i.id === line.itemId || i.nameNe.toLowerCase() === line.name.toLowerCase() || i.nameEn.toLowerCase() === line.name.toLowerCase()
        );
        if (matched) {
          const ratio = matched.secondaryUnitRatio && matched.secondaryUnitRatio > 0 ? matched.secondaryUnitRatio : 1;
          const addedPrimaryQty =
            line.primaryQtyEquivalent !== undefined
              ? line.primaryQtyEquivalent
              : line.unitMode === 'SECONDARY'
              ? line.quantity / ratio
              : line.quantity;
          if (addedPrimaryQty > 0) {
            adjustStock(matched.id, Math.round((matched.currentStock + addedPrimaryQty) * 10000) / 10000);
          }
          if (line.size && (!matched.size || matched.size !== line.size)) {
            matched.size = line.size;
          }
        }
      });

      // 2. AFTER SAVING TO DB, OPEN PRINT MODAL IF REQUESTED
      if (shouldPrint) {
        setCreatedPurchaseForPrint({
          purchase: savedPurRecord,
          items: [...finalPurLineItems],
          supplierAddress: purSupplierAddress,
          supplierPhone: purSupplierPhone,
          subtotal: calcGrossSubtotal,
          discountAmount: calcTotDisc,
          exemptAmount: calcNetExempt,
          taxableAmount: calcNetTaxable,
          vatAmount: calcVat,
          grandTotal: calcGrand,
          billType: purBillType
        });
      }

      // Reset form states
      setPurBillNo('');
      setPurSupplierName('');
      setPurSupplierPan('');
      setPurSupplierAddress('');
      setPurSupplierPhone('');
      setPurLineItems([]);
      setPurItemId('');
      setPurItemRate(0);
      setPurItemSize('');
      setPurIsCustomSize(false);
      setPurItemIsVatExempt(false);
      setPurItemDiscountPercent(0);
      setPurItemSearch('');
      setPurTaxable(0);
      setPurExempt(0);
      setPurDiscountPercent(0);
      setPurFreightCharge(0);
      setPurSummary('');
      setPurPhotoUrl('');
      setPurAmountPaidInput('');
      showToast(isNe
        ? `खरिद बिल नं. ${savedPurRecord.purchaseBillNo} सुरक्षित भयो! ${shouldPrint ? 'प्रिन्ट वा PDF डाउनलोड खुल्दैछ...' : ''}`
        : `Purchase bill ${savedPurRecord.purchaseBillNo} recorded! ${shouldPrint ? 'Opening print/PDF...' : ''}`
      );
    };

    return (
      <div className="space-y-5">
        {toastMsg && (
          <div className="bg-emerald-900 text-white px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-2 shadow-md">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMsg}</span>
          </div>
        )}

        {/* Top Purchase Bill Type Selector & Bill Number Indicator (Identical to Sales POS) */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setPurBillType('VAT')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                  purBillType === 'VAT'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Receipt className="w-4 h-4" />
                <span>{isNe ? '१३% भ्याट खरिद बिल (Tax Invoice)' : '13% VAT Purchase Bill'}</span>
              </button>

              <button
                type="button"
                onClick={() => setPurBillType('NON_VAT')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                  purBillType === 'NON_VAT'
                    ? 'bg-slate-800 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <span>{isNe ? 'नन-भ्याट / प्यान खरिद बिल' : 'Non-VAT / Estimation Bill'}</span>
              </button>
            </div>

            {/* AI Handwritten / Photo Bill Scan Button */}
            <button
              type="button"
              onClick={() => setIsAiScanModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-emerald-800 to-teal-800 hover:from-emerald-900 hover:to-teal-900 text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              <span>{isNe ? 'लिखित बिल AI स्क्यान' : 'Scan Handwritten Bill'}</span>
            </button>

            {/* Camera Barcode & QR Scanner Button */}
            <button
              type="button"
              onClick={() => setIsPurBarcodeScannerOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
            >
              <Scan className="w-3.5 h-3.5 text-blue-200" />
              <span>{isNe ? 'बारकोड / QR स्क्यान' : 'Scan Barcode / QR'}</span>
            </button>

            {/* Direct Excel Upload Button */}
            <label
              htmlFor="direct-purchase-excel-input"
              className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
              <span>{isNe ? 'Excel बाट सिधै बिल अपलोड' : 'Direct Excel Bill Upload'}</span>
            </label>
            <input
              type="file"
              id="direct-purchase-excel-input"
              accept=".xlsx,.xls,.csv"
              onChange={handleDirectPurchaseExcelUpload}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => setActiveTab('excel_wizard')}
              className="px-2.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-[11px] font-bold rounded-lg transition cursor-pointer"
            >
              {isNe ? 'म्यापिङ विजार्ड' : 'Excel Wizard'}
            </button>
          </div>

          {/* Editable Manual / Auto Purchase Bill Number & Date Info */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex flex-col">
              <span className="text-[10px] text-emerald-800 uppercase font-bold block mb-0.5">
                {isNe ? 'खरिद बीजक / बिल नं. (Auto वा Manual Entry):' : 'Invoice / Bill No (Auto or Manual):'}
              </span>
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={purBillNo}
                  onChange={(e) => setPurBillNo(e.target.value)}
                  placeholder={nextPurBillNoPreview}
                  className="w-40 sm:w-44 px-2.5 py-1.5 text-xs sm:text-sm font-mono font-bold text-slate-900 bg-emerald-50/60 border border-emerald-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
                />
                {purBillNo && (
                  <button
                    type="button"
                    onClick={() => setPurBillNo('')}
                    className="px-2 py-1 text-[10px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md cursor-pointer"
                  >
                    {isNe ? 'अटो' : 'Auto'}
                  </button>
                )}
              </div>
            </div>

            <div className="h-8 w-px bg-slate-200 hidden sm:block" />

            <div className="text-right">
              <span className="text-[10px] text-slate-500 uppercase font-bold flex items-center justify-end gap-1">
                <Calendar className="w-3 h-3 text-emerald-700" />
                <span>{isNe ? 'खरिद मिति (B.S. / A.D.)' : 'Purchase Date (B.S. / A.D.)'}</span>
              </span>
              <div className="mt-0.5">
                <DualDateInput valueBs={purDateBs} onChange={(bs) => setPurDateBs(bs)} isNe={isNe} />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-5 w-full">
          {/* Top: Supplier Details & Full Width Purchase Room Table */}
          <div className="w-full space-y-4">

            {/* Direct Photo Capture for Purchase Bill / Slip Placed at Top (as requested: 'aslae mathe nae rakhne maping wizard paxe') */}
            <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-emerald-700" />
                  {isNe ? 'फोटो खिचेर बिल / चलान संलग्न गर्नुहोस्' : 'Snap & Attach Photo (Purchase Slip / Goods)'}
                </span>
                {purPhotoUrl && (
                  <button
                    type="button"
                    onClick={() => setPurPhotoUrl('')}
                    className="text-[11px] text-rose-600 font-bold hover:underline cursor-pointer"
                  >
                    {isNe ? 'हटाउनुहोस् (Remove)' : 'Remove'}
                  </button>
                )}
              </div>
              <div className="flex items-center gap-3">
                {purPhotoUrl ? (
                  <img
                    src={purPhotoUrl}
                    alt="Purchase Attachment"
                    className="w-14 h-14 object-cover rounded-lg border-2 border-emerald-400 shadow-xs"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-lg border-2 border-dashed border-emerald-300 flex flex-col items-center justify-center text-emerald-600 bg-white shrink-0">
                    <Camera className="w-5 h-5 text-emerald-500" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <label
                    htmlFor="top-pur-photo-input"
                    className="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-emerald-300 hover:border-emerald-600 hover:bg-emerald-50 text-emerald-900 rounded-lg text-xs font-bold cursor-pointer shadow-2xs transition"
                  >
                    <Camera className="w-4 h-4 text-emerald-700" />
                    <span>{purPhotoUrl ? (isNe ? 'अर्को फोटो लिनुहोस्' : 'Retake Photo') : (isNe ? 'क्यामेराबाट फोटो खिच्नुहोस्' : 'Snap Photo')}</span>
                  </label>
                  <input
                    type="file"
                    id="top-pur-photo-input"
                    accept="image/*"
                    capture="environment"
                    onChange={handlePurPhotoCapture}
                    className="hidden"
                  />
                  <p className="text-[10px] text-slate-500 truncate mt-0.5">
                    {isNe ? 'डिलिभरी चलान, सामानको फोटो वा हस्ताक्षर' : 'Attach delivery slip, goods photo or signature'}
                  </p>
                </div>
              </div>
            </div>

            {/* Supplier Details Card */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-slate-100 gap-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                  <User className="w-4 h-4 text-emerald-700" />
                  <span>{isNe ? 'आपूर्तिकर्ता / सप्लायर विवरण (Supplier & Party Details)' : 'Supplier & Party Details'}</span>
                </div>

                {parties.length > 0 && (
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      placeholder={isNe ? 'फोन वा नामबाट खोज्नुहोस्...' : 'Search by phone/name...'}
                      value={purPartySearchQuery}
                      onChange={(e) => setPurPartySearchQuery(e.target.value)}
                      className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1 text-slate-800 w-36 sm:w-44 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                    <select
                      value={purSelectedPartyId}
                      onChange={(e) => handleSelectPurParty(e.target.value)}
                      className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1 text-slate-700 font-medium max-w-[200px] truncate"
                    >
                      <option value="">{isNe ? '-- पार्टी छान्नुहोस् --' : '-- Select Party --'}</option>
                      {filteredPurParties.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} — 📍 {p.address || '-'} (📞 {p.phone || '-'})
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    {isNe ? 'आपूर्तिकर्ता वा पसलको नाम (Supplier Name)*' : 'Supplier Name*'}
                  </label>
                  <input
                    type="text"
                    list="supplier-parties-list"
                    value={purSupplierName}
                    onChange={(e) => setPurSupplierName(e.target.value)}
                    placeholder={isNe ? 'उदा: चितवन एग्रो सप्लायर्स' : 'e.g. Chitwan Agro Suppliers'}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                  />
                  <datalist id="supplier-parties-list">
                    {parties.filter(isSupplierParty).map((p) => (
                      <option key={p.id} value={p.name} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    {isNe ? 'पान/भ्याट नं (Supplier PAN)' : 'Supplier PAN / VAT'} {purBillType === 'VAT' && <span className="text-emerald-700">(९ अंक)</span>}
                  </label>
                  <input
                    type="text"
                    maxLength={9}
                    value={purSupplierPan}
                    onChange={(e) => setPurSupplierPan(e.target.value)}
                    placeholder="e.g. 601234567"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    {isNe ? 'ठेगाना (Supplier Address)' : 'Address'}
                  </label>
                  <input
                    type="text"
                    value={purSupplierAddress}
                    onChange={(e) => setPurSupplierAddress(e.target.value)}
                    placeholder={isNe ? 'ठेगाना / शहर' : 'Supplier Address'}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    {isNe ? 'सम्पर्क फोन (मोबाइल नं.)' : 'Phone / Mobile'}
                  </label>
                  <input
                    type="text"
                    value={purSupplierPhone}
                    onChange={(e) => setPurSupplierPhone(e.target.value)}
                    placeholder="98xxxxxxxx"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {purPreviousDue > 0 && (
                <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200 flex items-center justify-between text-xs">
                  <span className="font-semibold text-amber-900 flex items-center gap-1.5">
                    <Wallet className="w-3.5 h-3.5 text-amber-700" />
                    <span>{isNe ? 'पुरानो तिर्न/लिन बाँकी खाता (Old Balance):' : 'Previous Balance:'}</span>
                  </span>
                  <span className="font-mono font-bold text-amber-950 text-sm">
                    {formatCurrency(purPreviousDue, isNe)}
                  </span>
                </div>
              )}
            </div>

            {/* Billing Mode & Quick Barcode Scanner */}
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
              <div className="flex items-center gap-1.5 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                <button
                  type="button"
                  onClick={() => setPurEntryMode('ITEMIZED')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-md transition cursor-pointer ${
                    purEntryMode === 'ITEMIZED'
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  📦 {isNe ? 'कोठा तालिका खरिद बिल (Purchase Room Table)' : 'Itemized Room Table'}
                </button>
                <button
                  type="button"
                  onClick={() => setPurEntryMode('LUMP_SUM')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-md transition cursor-pointer ${
                    purEntryMode === 'LUMP_SUM'
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  💰 {isNe ? 'एकमुष्ठ रकम खरिद बिल' : 'Lump-sum Purchase Bill'}
                </button>
              </div>

              <button
                type="button"
                onClick={() => setIsPurBarcodeScannerOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold transition cursor-pointer shadow-2xs"
              >
                <Scan className="w-3.5 h-3.5 text-emerald-700" />
                <span>{isNe ? 'बारकोड / QR स्क्यान' : 'Barcode / QR Scan'}</span>
              </button>
            </div>

            {purEntryMode === 'LUMP_SUM' ? (
              /* Lump-Sum Quick Purchase Panel */
              <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="text-xs font-bold text-slate-800 pb-2 border-b border-slate-100">
                  {isNe ? 'एकमुष्ठ खरिद रकम प्रविष्ट गर्नुहोस्:' : 'Direct Lump-Sum Purchase Entry:'}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {isNe ? 'करयोग्य खरिद रकम (Taxable रु.)' : 'Taxable Amount (NPR)'}
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={purTaxable || ''}
                      onChange={(e) => setPurTaxable(Number(e.target.value) || 0)}
                      placeholder="0"
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl font-mono font-bold focus:border-emerald-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {isNe ? 'कर छुट खरिद रकम (Exempt रु.)' : 'VAT Exempt Amount'}
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={purExempt || ''}
                      onChange={(e) => setPurExempt(Number(e.target.value) || 0)}
                      placeholder="0"
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl font-mono font-bold focus:border-emerald-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            ) : (
              /* Itemized Room Table for Purchase (Exact parity with Sales POS & user screenshot) */
              <div className="bg-white rounded-xl border border-slate-300 overflow-hidden shadow-xs">
                {/* Table Header Bar */}
                <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-300 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <span>📋</span>
                      <span>{isNe ? 'खरिद कोठा तालिका (Purchase Room Table)' : 'Purchase Items Room Table'}</span>
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      ({isNe ? toNepaliDigits(purLineItems.length) : purLineItems.length} {isNe ? 'सामान' : 'Items'})
                    </span>
                  </div>
                  <div className="text-[11px] text-emerald-800 font-medium hidden sm:block">
                    {isNe ? 'सामान छान्दा भ्याट वा कर छुट (Non-VAT) छनौट गर्न सकिन्छ' : 'Toggle VAT / Non-VAT per line item'}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left border-collapse">
                    {/* Table Headers with distinct vertical dividers (room borders) */}
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                      <tr>
                        <th className="py-2.5 px-2 text-center w-12 border-r border-slate-300">
                          {isNe ? 'क्र.सं.' : 'S.N.'}
                        </th>
                        <th className="py-2.5 px-3 border-r border-slate-300 min-w-[300px]">
                          {isNe ? 'सामान कोड र नाम (Code & Item Name)' : 'Item Code & Name'}
                        </th>
                        <th className="py-2 px-2 text-center w-56 border-r border-slate-300">
                          {isNe ? 'साइज (Size)' : 'Size'}
                        </th>
                        <th className="py-2.5 px-2 text-center w-16 border-r border-slate-300">
                          {isNe ? 'परिमाण' : 'Qty'}
                        </th>
                        <th className="py-2.5 px-2 text-right w-24 border-r border-slate-300">
                          {isNe ? 'दर (रु.)' : 'Rate (Rs.)'}
                        </th>
                        <th className="py-2.5 px-2 text-center w-16 border-r border-slate-300">
                          {isNe ? 'छुट (%)' : 'Disc (%)'}
                        </th>
                        <th className="py-2.5 px-2 text-right w-24 border-r border-slate-300">
                          {isNe ? 'छुट रकम (रु.)' : 'Disc Amt (Rs.)'}
                        </th>
                        <th className="py-2.5 px-3 text-right w-28 border-r border-slate-300">
                          {isNe ? 'जम्मा (रु.)' : 'Total (Rs.)'}
                        </th>
                        <th className="py-2.5 px-2 text-center w-28">
                          {isNe ? 'कार्य' : 'Action'}
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {/* Existing Purchase Line Items in Room Format */}
                      {purLineItems.map((line, idx) => {
                        return (
                          <tr key={idx} className="border-b border-slate-300 hover:bg-slate-50/70 transition-colors">
                            {/* S.N. Room */}
                            <td className="py-1 px-2 text-center font-mono font-medium text-slate-700 bg-slate-50/30 border-r border-slate-300">
                              {isNe ? toNepaliDigits(idx + 1) : idx + 1}
                            </td>

                            {/* Particulars Room */}
                            <td className="py-1 px-3 border-r border-slate-300">
                              <div className="font-semibold text-slate-900 leading-tight flex items-center flex-wrap gap-1">
                                {line.code && (
                                  <span className="font-mono text-[10px] bg-slate-100 text-slate-700 px-1 py-0.2 rounded border border-slate-200">
                                    {line.code}
                                  </span>
                                )}
                                <input
                                  type="text"
                                  value={line.name}
                                  onChange={(e) => handleUpdatePurLineItem(idx, 'name', e.target.value)}
                                  className="min-w-[7rem] bg-transparent border-b border-dashed border-slate-300 focus:border-emerald-500 focus:outline-none font-semibold text-slate-900"
                                  title={isNe ? 'नाम सच्याउन सकिन्छ' : 'Edit item name'}
                                />
                                {line.hsCode && (
                                  <span className="font-mono text-[10px] text-slate-600 bg-slate-50 px-1 py-0.2 rounded border border-slate-200">
                                    HS: {line.hsCode}
                                  </span>
                                )}
                                <button
                                  type="button"
                                  onClick={() => handleUpdatePurLineItem(idx, 'isVatExempt', !line.isVatExempt)}
                                  className={`text-[10px] px-1.5 py-0.2 rounded font-bold transition cursor-pointer border shadow-2xs whitespace-nowrap ml-1 ${
                                    line.isVatExempt
                                      ? 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                                      : 'bg-emerald-100 text-emerald-900 border-emerald-300 hover:bg-emerald-200'
                                  }`}
                                  title={isNe ? 'भ्याट वा कर छुट परिवर्तन गर्न क्लिक गर्नुहोस्' : 'Toggle VAT / Non-VAT'}
                                >
                                  {line.isVatExempt ? (isNe ? 'कर छुट (Non-VAT)' : 'Exempt') : (isNe ? '१३% भ्याट' : '13% VAT')}
                                </button>
                              </div>
                              <div className="text-[11px] text-slate-600 flex items-center flex-wrap gap-2 mt-0.5">
                                {line.size && <span>साइज: <strong className="font-mono text-slate-800">{line.size}</strong></span>}
                                <span>परिमाण: <strong className="font-mono text-slate-900">{line.quantity} {line.unit}</strong></span>
                                {line.unitMode === 'SECONDARY' && line.primaryQtyEquivalent !== undefined && (
                                  <span className="text-[10px] bg-blue-50 text-blue-800 px-1.5 py-0.2 rounded border border-blue-200 font-mono">
                                    (स्टक थपिने: +{line.primaryQtyEquivalent} मुख्य एकाइ)
                                  </span>
                                )}
                                <span>खरिद दर: <strong className="font-mono text-slate-900">रु. {line.rate}</strong></span>
                              </div>
                            </td>

                            {/* Size Room (Manual editable input with datalist presets) */}
                            <td className="py-1 px-2 text-center border-r border-slate-300 w-56">
                              <input
                                type="text"
                                list="pur-size-presets"
                                value={line.size || ''}
                                onChange={(e) => handleUpdatePurLineItem(idx, 'size', e.target.value)}
                                placeholder="-"
                                className="w-full text-center bg-transparent border-0 focus:ring-1 focus:ring-emerald-500 rounded py-0.5 text-xs text-slate-700 font-medium"
                              />
                            </td>

                            {/* Quantity Room + Unit Switcher */}
                            <td className="py-1.5 px-2 text-center border-r border-slate-300">
                              <div className="flex flex-col items-center gap-1">
                                <NumField value={line.quantity} onCommit={(n) => handleUpdatePurLineItem(idx, 'quantity', n)} className="w-14 text-center font-mono font-bold bg-transparent border border-slate-200 rounded py-0.5 text-xs focus:ring-1 focus:ring-emerald-500" />
                                {(() => {
                                  const matchedIt = items.find((i) => i.id === line.itemId);
                                  if (matchedIt && matchedIt.secondaryUnit) {
                                    return (
                                      <select
                                        value={line.unitMode || 'PRIMARY'}
                                        onChange={(e) => handleUpdatePurLineItem(idx, 'unitMode', e.target.value)}
                                        className="text-[10px] font-bold bg-emerald-50 text-emerald-900 border border-emerald-300 rounded px-1 py-0.2 cursor-pointer"
                                      >
                                        <option value="PRIMARY">{matchedIt.unit} (मुख्य)</option>
                                        <option value="SECONDARY">{matchedIt.secondaryUnit} (द्वितीय)</option>
                                      </select>
                                    );
                                  }
                                  return <span className="text-[10px] text-slate-500 font-mono">{line.unit}</span>;
                                })()}
                              </div>
                            </td>

                            {/* Rate Room */}
                            <td className="py-1.5 px-2 text-right border-r border-slate-300">
                              <div className="flex items-center justify-end gap-1">
                                <span className="text-slate-400 font-mono text-[10px]">Rs.</span>
                                <NumField value={line.rate} onCommit={(n) => handleUpdatePurLineItem(idx, 'rate', n)} className="w-16 text-right font-mono font-medium bg-transparent border border-slate-200 rounded py-0.5 px-1 text-xs focus:ring-1 focus:ring-emerald-500" />
                              </div>
                            </td>

                            {/* Discount % Room */}
                            <td className="py-1.5 px-2 text-center border-r border-slate-300">
                              <div className="flex items-center justify-center gap-0.5">
                                <NumField value={line.discountPercent || 0} onCommit={(n) => handleUpdatePurLineItem(idx, 'discountPercent', n)} placeholder="0" blankWhenZero className="w-10 text-center font-mono bg-transparent border border-slate-200 rounded py-0.5 text-xs focus:ring-1 focus:ring-emerald-500" />
                                <span className="text-slate-400 text-[10px]">%</span>
                              </div>
                            </td>

                            {/* Discount Amount Room (column ma chut% paxe discount amount dekhaune) */}
                            <td className="py-1.5 px-2 text-right font-mono tabular-nums text-rose-700 font-semibold border-r border-slate-300">
                              <span className="text-slate-400 text-[10px] font-normal mr-0.5">Rs.</span>
                              {(((line.rate * line.quantity) * (line.discountPercent || 0)) / 100).toFixed(2)}
                            </td>

                            {/* Total Amount Room */}
                            <td className="py-1.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900 border-r border-slate-300">
                              <span className="text-slate-400 text-[10px] font-normal mr-1">Rs.</span>
                              {line.amount.toFixed(2)}
                            </td>

                            {/* Action Room */}
                            <td className="py-1.5 px-2 text-center whitespace-nowrap">
                              <button
                                type="button"
                                onClick={() => handleEditPurLineItem(idx)}
                                className="text-blue-600 hover:text-blue-800 hover:bg-blue-50 p-1 rounded transition cursor-pointer mr-0.5"
                                title={isNe ? 'सामान सच्याउनुहोस् (फेरि माथि entry मा आउँछ)' : 'Edit this item (loads back into the entry row)'}
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setPurLineItems(purLineItems.filter((_, i) => i !== idx))}
                                className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1 rounded transition cursor-pointer"
                                title={isNe ? 'यो सामान हटाउनुहोस्' : 'Remove item'}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}

                      {/* Active Draft Entry Row for Purchase (Matching user uploaded screenshot) */}
                      <tr className="border-b border-slate-300 bg-emerald-50/15 hover:bg-emerald-50/30 transition-colors">
                        {/* S.N. Room */}
                        <td className="py-2 px-2 text-center font-mono font-medium text-slate-600 bg-slate-50/40 border-r border-slate-300">
                          {isNe ? toNepaliDigits(purLineItems.length + 1) : purLineItems.length + 1}
                        </td>

                        {/* Dual Select Room: Code and Item Name synchronized */}
                        <td className="py-1.5 px-2 border-r border-slate-300">
                          <div className="space-y-1.5">
                            <div className="grid grid-cols-1 sm:grid-cols-12 gap-1.5">
                              {/* 1. Item Code Selector */}
                              <div className="sm:col-span-4">
                                <label className="block text-[9px] font-bold text-slate-600 mb-0.5">
                                  {isNe ? 'कोड (Item Code):' : 'Item Code:'}
                                </label>
                                <select
                                  value={currentPurItem?.code || ''}
                                  onChange={(e) => handleSelectPurByCode(e.target.value)}
                                  className="w-full px-2 py-1 border border-slate-300 rounded font-mono font-bold text-xs bg-white text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-2xs"
                                >
                                  <option value="">{isNe ? '-- कोड छान्नुहोस् --' : '-- Code --'}</option>
                                  {items.map((it) => (
                                    <option key={it.id} value={it.code}>
                                      [{it.code}] - {it.nameNe || it.nameEn} | {isNe ? 'स्टक' : 'Stock'}: {it.currentStock} {it.unit}
                                    </option>
                                  ))}
                                </select>
                              </div>

                              {/* 2. Item Name Selector */}
                              <div className="sm:col-span-8">
                                <label className="block text-[9px] font-bold text-slate-600 mb-0.5">
                                  {isNe ? 'सामानको नाम (Item Name):' : 'Item Name:'}
                                </label>
                                <select
                                  value={purItemId}
                                  onChange={(e) => handleSelectPurByName(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      handleAddPurLineItem();
                                    }
                                  }}
                                  className="w-full px-2 py-1 border border-slate-300 rounded font-medium text-xs bg-white text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-2xs"
                                >
                                  <option value="">{isNe ? '-- सामानको नाम छान्नुहोस् --' : '-- Select Item Name --'}</option>
                                  {filteredPurInventory.map((it) => (
                                    <option key={it.id} value={it.id}>
                                      {it.nameNe || it.nameEn} [{it.code}] {it.size ? `· ${it.size}` : ''} ({it.unit}) | {isNe ? 'स्टक' : 'Stock'}: {it.currentStock}
                                      {it.hsCode || it.hsnCode ? ` | HS: ${it.hsCode || it.hsnCode}` : ''}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            {/* Quick "Add New Item" — for an item not yet in the master list */}
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                value={purNewItemQuickName}
                                onChange={(e) => setPurNewItemQuickName(e.target.value)}
                                placeholder={isNe ? 'सूचीमा नभएको नयाँ सामानको नाम...' : 'New item name not in the list...'}
                                className="flex-1 px-2 py-1 border border-dashed border-emerald-300 rounded text-[10px] bg-emerald-50/40 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                              />
                              <button
                                type="button"
                                onClick={handleOpenPurQuickAddItem}
                                className="shrink-0 px-2 py-1 bg-emerald-700 hover:bg-emerald-800 text-white text-[10px] font-bold rounded flex items-center gap-1 cursor-pointer"
                                title={isNe ? 'यो सामान सूचीमा नयाँ थप्नुहोस्' : 'Register this as a new item'}
                              >
                                <Plus className="w-3 h-3" />
                                {isNe ? 'नयाँ सामान थप्नुहोस्' : 'Add New Item'}
                              </button>
                            </div>

                            {/* Details badge underneath Code & Name */}
                            {currentPurItem && (
                              <div className="p-1.5 bg-white rounded border border-slate-200 text-[10px] space-y-1 shadow-2xs">
                                <div className="flex items-center flex-wrap gap-2 text-slate-700">
                                  <span>कोड: <strong className="font-mono text-slate-900">[{currentPurItem.code}]</strong></span>
                                  {currentPurItem.hsCode && (
                                    <span>HS: <strong className="font-mono text-slate-900">{currentPurItem.hsCode}</strong></span>
                                  )}
                                  <span>एकाइ: <strong className="text-slate-900">{currentPurItem.unit}</strong></span>
                                  <button
                                    type="button"
                                    onClick={() => setPurItemIsVatExempt(!purItemIsVatExempt)}
                                    className={`px-1.5 py-0.2 rounded font-bold cursor-pointer border ${
                                      purItemIsVatExempt
                                        ? 'bg-amber-100 text-amber-900 border-amber-300'
                                        : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                    }`}
                                  >
                                    {purItemIsVatExempt ? 'कर छुट (Non-VAT)' : '१३% भ्याट (VAT)'}
                                  </button>
                                </div>
                                <div className="flex items-center justify-between text-[10px] text-slate-600 pt-0.5 border-t border-slate-100 flex-wrap gap-1">
                                  <span>
                                    खरिद दर ({purItemUnitMode === 'SECONDARY' && currentPurItem.secondaryUnit ? currentPurItem.secondaryUnit : currentPurItem.unit}):{' '}
                                    <strong className="font-mono text-emerald-700">रु. {purItemRate || currentPurItem.purchasePrice}</strong>
                                  </span>
                                  <span>
                                    स्टक मौज्दात: <strong className="font-mono text-slate-900">{currentPurItem.currentStock} {currentPurItem.unit}</strong>
                                    {currentPurItem.secondaryUnit && currentPurItem.secondaryUnitRatio
                                      ? ` (${Math.round(currentPurItem.currentStock * currentPurItem.secondaryUnitRatio * 100) / 100} ${currentPurItem.secondaryUnit})`
                                      : ''}
                                  </span>
                                </div>
                                {currentPurItem.secondaryUnit && (
                                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100">
                                    <span className="text-[10px] font-bold text-blue-900">
                                      🔄 1 {currentPurItem.unit} = {currentPurItem.secondaryUnitRatio || 1} {currentPurItem.secondaryUnit}
                                    </span>
                                    <div className="flex items-center gap-1">
                                      <button
                                        type="button"
                                        onClick={() => handleTogglePurUnitMode('PRIMARY')}
                                        className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer border ${
                                          purItemUnitMode === 'PRIMARY'
                                            ? 'bg-emerald-700 text-white border-emerald-800'
                                            : 'bg-white text-slate-700 border-slate-300'
                                        }`}
                                      >
                                        मुख्य ({currentPurItem.unit})
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleTogglePurUnitMode('SECONDARY')}
                                        className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer border ${
                                          purItemUnitMode === 'SECONDARY'
                                            ? 'bg-blue-700 text-white border-blue-800'
                                            : 'bg-white text-slate-700 border-slate-300'
                                        }`}
                                      >
                                        द्वितीय ({currentPurItem.secondaryUnit})
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </td>

                        {/* Size Room: Manual input as requested: 'SIZE PURCHASE GARDA MANUL HALNE, SIZE MA JASTAE 200GM, 10ML, 1LTR, 6*100MTR JASTO MANUAL RAKHNE' */}
                        <td className="py-1.5 px-2 border-r border-slate-300 align-top">
                          <div className="space-y-1">
                            <input
                              type="text"
                              list="pur-size-presets"
                              value={purItemSize}
                              onChange={(e) => setPurItemSize(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleAddPurLineItem();
                                }
                              }}
                              placeholder="200gm / 1ltr"
                              className="w-full text-center text-xs font-semibold py-1 px-1 border border-slate-300 rounded bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-2xs"
                              title="म्यानुअल साइज टाइप गर्नुहोस्: 200gm, 10ml, 1ltr, 6*100mtr"
                            />
                            <datalist id="pur-size-presets">
                              {purAvailableSizes.map((sz) => (
                                <option key={sz} value={sz} />
                              ))}
                            </datalist>

                            {/* Quick chip presets */}
                            <div className="flex items-center justify-center flex-wrap gap-1">
                              {['200gm', '10ml', '1ltr', '6*100mtr'].map((szPreset) => (
                                <button
                                  key={szPreset}
                                  type="button"
                                  onClick={() => setPurItemSize(szPreset)}
                                  className={`px-1 py-0.2 rounded text-[9px] font-bold border cursor-pointer ${
                                    purItemSize === szPreset
                                      ? 'bg-emerald-700 text-white border-emerald-800'
                                      : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                                  }`}
                                >
                                  {szPreset}
                                </button>
                              ))}
                            </div>
                          </div>
                        </td>

                        {/* Quantity Room + Unit Switcher */}
                        <td className="py-1.5 px-2 text-center border-r border-slate-300 align-top">
                          <div className="flex flex-col items-center gap-1">
                            <NumField value={purItemQty} onCommit={(n) => setPurItemQty(n)} onEnter={handleAddPurLineItem} className="w-14 text-center font-mono font-bold text-xs border border-slate-300 rounded py-1 bg-white focus:ring-1 focus:ring-emerald-500 shadow-2xs" />
                            {currentPurItem && currentPurItem.secondaryUnit ? (
                              <select
                                value={purItemUnitMode}
                                onChange={(e) => handleTogglePurUnitMode(e.target.value as 'PRIMARY' | 'SECONDARY')}
                                className="text-[10px] font-bold bg-white border border-emerald-400 text-emerald-950 rounded px-1 py-0.5 cursor-pointer"
                              >
                                <option value="PRIMARY">{currentPurItem.unit} (मुख्य)</option>
                                <option value="SECONDARY">{currentPurItem.secondaryUnit} (द्वितीय)</option>
                              </select>
                            ) : (
                              currentPurItem && <span className="text-[10px] text-slate-500 font-mono">{currentPurItem.unit}</span>
                            )}
                          </div>
                        </td>

                        {/* Rate Room */}
                        <td className="py-1.5 px-2 text-right border-r border-slate-300 align-top">
                          <div className="flex items-center justify-end gap-1">
                            <span className="text-slate-400 font-mono text-[10px]">Rs.</span>
                            <NumField value={purItemRate} onCommit={(n) => setPurItemRate(n)} onEnter={handleAddPurLineItem} placeholder="0" blankWhenZero className="w-18 text-right font-mono font-bold text-xs border border-slate-300 rounded py-1 px-1 bg-white focus:ring-1 focus:ring-emerald-500 shadow-2xs" />
                          </div>
                        </td>

                        {/* Discount % Room */}
                        <td className="py-1.5 px-2 text-center border-r border-slate-300 align-top">
                          <div className="flex items-center justify-center gap-0.5">
                            <NumField value={purItemDiscountPercent} onCommit={(n) => setPurItemDiscountPercent(Math.min(100, n))} onEnter={handleAddPurLineItem} placeholder="0" blankWhenZero className="w-10 text-center font-mono text-xs border border-slate-300 rounded py-1 bg-white focus:ring-1 focus:ring-emerald-500 shadow-2xs" />
                            <span className="text-slate-400 text-[10px]">%</span>
                          </div>
                        </td>

                        {/* Discount Amount Room */}
                        <td className="py-1.5 px-2 text-right font-mono tabular-nums text-rose-700 font-bold border-r border-slate-300 align-top pt-2.5">
                          <span className="text-slate-400 text-[10px] font-normal mr-0.5">Rs.</span>
                          {(((purItemRate * purItemQty) * (purItemDiscountPercent || 0)) / 100).toFixed(2)}
                        </td>

                        {/* Total Amount Room */}
                        <td className="py-1.5 px-3 text-right font-mono font-bold tabular-nums text-emerald-900 border-r border-slate-300 align-top pt-2.5">
                          <span className="text-slate-400 text-[10px] font-normal mr-1">Rs.</span>
                          {((purItemRate * purItemQty) * (1 - (purItemDiscountPercent || 0) / 100)).toFixed(2)}
                        </td>

                        {/* Action Room: Add Button with Enter prompt */}
                        <td className="py-1.5 px-2 text-center align-top">
                          <button
                            type="button"
                            onClick={handleAddPurLineItem}
                            disabled={!currentPurItem && !purItemSearch.trim() && purItemRate <= 0}
                            className="w-full py-1.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-lg text-xs shadow-2xs transition flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>{isNe ? 'थप्नुहोस्' : 'Add Item'}</span>
                          </button>
                          <span className="text-[9px] text-slate-400 block mt-0.5">↵ Enter</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Bottom Footer Bar with Add Item Button, Save Purchase, Save & Print, and Count (same column actions) */}
                <div className="p-3 bg-slate-50 border-t border-slate-300 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={handleAddPurLineItem}
                      disabled={!currentPurItem && !purItemSearch.trim() && purItemRate <= 0}
                      className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-700 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs rounded-lg shadow-xs transition cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{isNe ? '+ थप्नुहोस् (Add)' : '+ Add'}</span>
                    </button>

                    {/* Direct Save in same column */}
                    <button
                      type="button"
                      onClick={() => handleSavePurchase(undefined, false)}
                      disabled={purLineItems.length === 0 && !currentPurItem && !purItemSearch.trim() && purItemRate <= 0}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs rounded-lg shadow-xs transition cursor-pointer active:scale-95"
                      title={isNe ? 'खरिद बिल सुरक्षित मात्र गर्नुहोस्' : 'Save purchase bill'}
                    >
                      <Save className="w-4 h-4" />
                      <span>{isNe ? '💾 सुरक्षित गर्नुहोस् (Save)' : 'Save Purchase'}</span>
                    </button>

                    {/* Direct Save & Print in same column */}
                    <button
                      type="button"
                      onClick={() => handleSavePurchase(undefined, true)}
                      disabled={purLineItems.length === 0 && !currentPurItem && !purItemSearch.trim() && purItemRate <= 0}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs rounded-lg shadow-xs transition cursor-pointer ring-2 ring-emerald-600/30 active:scale-95"
                      title={isNe ? 'पहिले सेभ गरी तुरुन्तै प्रिन्ट / PDF डाउनलोड गर्नुहोस्' : 'Save and print purchase bill'}
                    >
                      <Printer className="w-4 h-4" />
                      <span>{isNe ? '🖨️ सेभ र प्रिन्ट (Save & Print)' : 'Save & Print'}</span>
                    </button>

                    <span className="text-[11px] text-slate-500 font-medium hidden sm:inline">
                      ↵ <kbd className="px-1.5 py-0.5 bg-white border border-slate-300 rounded text-[10px] font-mono">Enter</kbd> {isNe ? 'थिचेर थप्न सकिन्छ' : 'to add'}
                    </span>
                  </div>

                  <span className="text-xs font-mono font-bold text-slate-700">
                    {purLineItems.length} {isNe ? 'सामान बिलमा समावेश' : 'Items Added'}
                  </span>
                </div>
              </div>
            )}
          </div>

        {/* Bottom Section: Purchase Calculation, Payment, Notes, Totals & Save Buttons Placed Directly Below Room Table */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Calculator className="w-4 h-4 text-emerald-700" />
              <span>{isNe ? 'खरिद बिल हिसाब-किताब, भुक्तानी तथा फछ्र्यौट (Purchase Bill Summary & Settlement)' : 'Purchase Bill Calculation & Settlement'}</span>
            </h3>
            <span className="text-xs font-mono font-bold text-emerald-950 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
              {isNe ? 'कुल खरिद जम्मा:' : 'Grand Total:'} {formatCurrency(grandTotal, isNe)}
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left Box: Payment Mode, Paid Today, Net Remaining Due, Payment Due Date, Remarks */}
            <div className="lg:col-span-6 space-y-4">
              {/* Payment Mode */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                  {isNe ? 'भुक्तानी माध्यम (Payment Mode)' : 'Payment Mode'}
                </label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPurPaymentMode('CASH')}
                    className={`py-2 px-2 font-semibold rounded-lg border text-center transition cursor-pointer ${
                      purPaymentMode === 'CASH'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {isNe ? 'नगद (Cash)' : 'Cash'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPurPaymentMode('BANK_FONEPAY')}
                    className={`py-2 px-2 font-semibold rounded-lg border text-center transition cursor-pointer ${
                      purPaymentMode === 'BANK_FONEPAY'
                        ? 'bg-blue-600 border-blue-700 text-white shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {isNe ? 'बैंक / QR' : 'Bank / QR'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPurPaymentMode('CREDIT')}
                    className={`py-2 px-2 font-semibold rounded-lg border text-center transition cursor-pointer ${
                      purPaymentMode === 'CREDIT'
                        ? 'bg-amber-50 border-amber-500 text-amber-900 shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {isNe ? 'उधारो (Credit)' : 'Credit'}
                  </button>
                </div>
              </div>

              {/* Paid Amount Today & Net Remaining Due (Matching uploaded image) */}
              <div className="p-3 bg-emerald-50/80 rounded-xl border-2 border-emerald-300 space-y-2 text-xs">
                <div className="flex items-center justify-between font-bold text-emerald-950">
                  <span>{isNe ? 'आज बुझाएको रकम (Paid Amount रु.):' : 'Paid Amount Today (Rs.):'}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setPurAmountPaidInput(grandTotal)}
                      className="px-2 py-0.5 bg-white border border-emerald-400 rounded text-[10px] text-emerald-800 font-bold hover:bg-emerald-100 cursor-pointer shadow-2xs"
                    >
                      पूरा रकम
                    </button>
                    <button
                      type="button"
                      onClick={() => setPurAmountPaidInput(0)}
                      className="px-2 py-0.5 bg-white border border-emerald-400 rounded text-[10px] text-rose-700 font-bold hover:bg-rose-50 cursor-pointer shadow-2xs"
                    >
                      रु. ० (बाँकी)
                    </button>
                  </div>
                </div>
                <input
                  type="number"
                  min={0}
                  value={purAmountPaidInput === '' ? (purPaymentMode === 'CREDIT' ? 0 : grandTotal) : purAmountPaidInput}
                  onChange={(e) => setPurAmountPaidInput(e.target.value === '' ? '' : parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-1.5 border-2 border-emerald-400 rounded-lg bg-white font-mono font-bold text-base text-emerald-950 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />

                {/* Live Net Remaining Balance Calculation */}
                <div className="pt-2 border-t border-emerald-200/80 space-y-1">
                  <div className="flex justify-between text-slate-600 text-[11px]">
                    <span>कुल तिर्नुपर्ने (Previous Due + Bill):</span>
                    <span className="font-mono tabular-nums">{formatCurrency(netTotalPurDue, isNe)}</span>
                  </div>
                  <div className="flex justify-between text-emerald-800 font-semibold text-[11px]">
                    <span>आज भुक्तानी गरेको रकम (Paid Today):</span>
                    <span className="font-mono tabular-nums">
                      -{formatCurrency(purAmountPaidInput !== '' ? Number(purAmountPaidInput) : (purPaymentMode === 'CREDIT' ? 0 : grandTotal), isNe)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-bold text-slate-900 pt-1 border-t border-emerald-300">
                    <span className="text-rose-900 font-bold">{isNe ? 'हालसम्म बाँकी रकम (Remaining Due):' : 'Net Remaining Due:'}</span>
                    <span className="font-mono font-black text-rose-700 text-sm">
                      {formatCurrency(
                        Math.max(
                          0,
                          netTotalPurDue -
                            (purAmountPaidInput !== '' ? Number(purAmountPaidInput) : purPaymentMode === 'CREDIT' ? 0 : grandTotal)
                        ),
                        isNe
                      )}
                    </span>
                  </div>
                </div>
              </div>

              {/* Payment Due Date */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-700 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{isNe ? 'भुक्तानी बुझाउने भाका / म्याद (Due Date)' : 'Payment Due Date'}</span>
                </label>
                <input
                  type="text"
                  placeholder="जस्तै: २०८१-१२-१५ वा १५ दिन"
                  value={purPaymentDueDate}
                  onChange={(e) => setPurPaymentDueDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-xs bg-white font-mono"
                />
              </div>

              {/* Remarks / Summary */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  {isNe ? 'कैफियत (Bill Notes / Remarks)' : 'Remarks / Summary'}
                </label>
                <input
                  type="text"
                  value={purSummary}
                  onChange={(e) => setPurSummary(e.target.value)}
                  placeholder={isNe ? 'उदा: होम डेलिभरी, अग्रिम भुक्तानी आदि' : 'e.g. Spare parts'}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Right Box: Discount, Freight, Calculations, In Words & Save Buttons */}
            <div className="lg:col-span-6 space-y-4">
              {/* Discount & Freight inputs */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1 flex items-center gap-1">
                    <Percent className="w-3 h-3 text-emerald-700" />
                    <span>{isNe ? 'छुट % (Discount)' : 'Discount %'}</span>
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={purDiscountPercent}
                    onChange={(e) => setPurDiscountPercent(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono bg-white font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1 flex items-center gap-1">
                    <Truck className="w-3 h-3 text-emerald-700" />
                    <span>{isNe ? 'ढुवानी खर्च (Freight रु.)' : 'Freight (Rs.)'}</span>
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={purFreightCharge}
                    onChange={(e) => setPurFreightCharge(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono bg-white font-bold"
                  />
                </div>
              </div>

              {/* Totals Breakdown */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between text-slate-700 font-semibold">
                  <span>{isNe ? 'उप-जम्मा (Sub Total):' : 'Sub Total:'}</span>
                  <span className="font-mono tabular-nums">{formatCurrency(activeSubtotal, isNe)}</span>
                </div>

                {totalDiscountAmt > 0 && (
                  <div className="flex justify-between text-rose-700 font-medium">
                    <span>{isNe ? 'छुट रकम (Discount):' : 'Discount:'}</span>
                    <span className="font-mono tabular-nums">-{formatCurrency(totalDiscountAmt, isNe)}</span>
                  </div>
                )}

                {purFreightCharge > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>{isNe ? 'ढुवानी खर्च (Freight):' : 'Freight Charge:'}</span>
                    <span className="font-mono tabular-nums">+{formatCurrency(purFreightCharge, isNe)}</span>
                  </div>
                )}

                <div className="pt-2 pb-1 border-t border-slate-200 space-y-1.5">
                  <div className="flex items-center justify-between text-slate-700 font-medium">
                    <div className="flex items-center gap-1.5">
                      <span>{isNe ? 'अकरयोग्य / कर छुट रकम (VAT Exempt):' : 'Non-Taxable / Exempt:'}</span>
                      <button
                        type="button"
                        onClick={() => {
                          const next = !purIsManualExemptMode;
                          setPurIsManualExemptMode(next);
                          if (!next) {
                            setPurManualExemptInput('');
                          } else {
                            setPurManualExemptInput(autoExempt || 0);
                          }
                        }}
                        className={`text-[10px] px-1.5 py-0.5 rounded font-bold transition cursor-pointer border ${
                          purIsManualExemptMode
                            ? 'bg-emerald-700 text-white border-emerald-800 shadow-2xs'
                            : 'bg-slate-200 hover:bg-slate-300 text-slate-700 border-slate-300'
                        }`}
                        title={isNe ? 'म्यानुअल कर छुट रकम तोक्ने' : 'Toggle manual exempt amount'}
                      >
                        {purIsManualExemptMode ? (isNe ? '✓ म्यानुअल' : 'Manual') : (isNe ? 'स्वतः (Auto)' : 'Auto')}
                      </button>
                    </div>
                    {!purIsManualExemptMode && (
                      <span className="font-mono tabular-nums">{formatCurrency(netExempt, isNe)}</span>
                    )}
                  </div>

                  {purIsManualExemptMode && (
                    <div className="flex items-center gap-2 pl-2">
                      <span className="text-slate-400 font-mono text-[11px]">Rs.</span>
                      <input
                        type="number"
                        min={0}
                        value={purManualExemptInput}
                        onChange={(e) => setPurManualExemptInput(e.target.value === '' ? '' : Math.max(0, parseFloat(e.target.value) || 0))}
                        placeholder="कर छुट रकम टाइप गर्नुहोस्"
                        className="w-full px-2 py-1 bg-white border border-emerald-300 rounded text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      />
                    </div>
                  )}
                </div>

                <div className="flex justify-between text-slate-700 font-semibold pt-1 border-t border-slate-200">
                  <span>{isNe ? 'करयोग्य रकम (Taxable Amount):' : 'Taxable Amount:'}</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatCurrency(netTaxable, isNe)}</span>
                </div>

                {purBillType === 'VAT' && (
                  <div className="flex justify-between text-blue-900 font-bold">
                    <span>{isNe ? '१३% भ्याट रकम (13% VAT):' : '13% Input VAT:'}</span>
                    <span className="font-mono tabular-nums">{formatCurrency(vatAmount, isNe)}</span>
                  </div>
                )}

                <div className="flex justify-between items-center text-sm font-black text-slate-950 pt-2 border-t-2 border-slate-300">
                  <span className="text-emerald-950 font-extrabold">{isNe ? 'कुल खरिद रकम (Grand Total Amount):' : 'Grand Total Amount:'}</span>
                  <span className="font-mono text-emerald-800 text-lg">{formatCurrency(grandTotal, isNe)}</span>
                </div>

                {purPreviousDue > 0 && (
                  <div className="pt-2 border-t border-dashed border-amber-300 space-y-1">
                    <div className="flex justify-between text-amber-900 font-medium">
                      <span>{isNe ? 'पुरानो बाँकी (Previous Due):' : 'Previous Due:'}</span>
                      <span className="font-mono">{formatCurrency(purPreviousDue, isNe)}</span>
                    </div>
                    <div className="flex justify-between text-sm font-extrabold text-slate-950 pt-1 border-t border-slate-300">
                      <span>{isNe ? 'कुल जम्मा बाँकी (Total Due):' : 'Net Total Due:'}</span>
                      <span className="font-mono text-rose-700">{formatCurrency(netTotalPurDue, isNe)}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* In Words Preview */}
              <div className="text-xs text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-200 font-medium">
                <span className="font-bold text-slate-900">अक्षरूपी (In Words): </span>
                <span className="font-semibold text-emerald-950">{amountInNepaliWords(grandTotal)}</span>
              </div>

              {/* Prominent Action Buttons at Bottom */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => handleSavePurchase(undefined, false)}
                  className="py-3.5 bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Save className="w-4.5 h-4.5" />
                  <span>{isNe ? '💾 सुरक्षित गर्नुहोस्' : 'Save'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSavePurchase(undefined, true)}
                  className="py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer ring-2 ring-emerald-600/30 active:scale-95"
                >
                  <Printer className="w-4.5 h-4.5" />
                  <span>{isNe ? '🖨️ बिल सुरक्षित गरी प्रिन्ट गर्नुहोस्' : 'Save & Print Bill'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

        {/* Purchase History Table */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-black text-slate-900">
              {isNe ? `हालसालैका खरिद बिलहरू (${purchases.length})` : `Recent Purchase Bills (${purchases.length})`}
            </h3>
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                type="button"
                onClick={() =>
                  exportReportToExcel({
                    title: 'खरिद बिल विवरण (Purchase Register Report)',
                    headers: ['मिति (B.S.)', 'बिल नं.', 'आपूर्तिकर्ता', 'प्यान नं.', 'सामान विवरण', 'करयोग्य रकम', 'भ्याट', 'कुल रकम', 'भुक्तानी माध्यम'],
                    rows: purchases.map((p) => [
                      p.dateBs,
                      p.purchaseBillNo,
                      p.supplierName,
                      p.supplierPan || '-',
                      p.itemsSummary,
                      p.taxableAmount,
                      p.vatAmount,
                      p.grandTotal,
                      p.paymentMode
                    ]),
                    company,
                    fileName: 'Purchase_Register_Report'
                  })
                }
                className="px-2.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Excel</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  printOrDownloadReportPdf(
                    {
                      title: 'खरिद बिल विवरण (Purchase Register Report)',
                      headers: ['मिति (B.S.)', 'बिल नं.', 'आपूर्तिकर्ता', 'प्यान नं.', 'सामान विवरण', 'करयोग्य रकम', 'भ्याट', 'कुल रकम', 'माध्यम'],
                      rows: purchases.map((p) => [
                        p.dateBs,
                        p.purchaseBillNo,
                        p.supplierName,
                        p.supplierPan || '-',
                        p.itemsSummary,
                        p.taxableAmount,
                        p.vatAmount,
                        p.grandTotal,
                        p.paymentMode
                      ]),
                      company,
                      fileName: 'Purchase_Register_Report'
                    },
                    'DOWNLOAD_PDF'
                  )
                }
                className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>PDF प्रिन्ट / सेभ</span>
              </button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <th className="py-2.5 px-3">{isNe ? 'मिति' : 'Date'}</th>
                  <th className="py-2.5 px-3">{isNe ? 'बिल नं' : 'Bill No'}</th>
                  <th className="py-2.5 px-3">{isNe ? 'आपूर्तिकर्ता' : 'Supplier'}</th>
                  <th className="py-2.5 px-3">{isNe ? 'विवरण' : 'Summary'}</th>
                  <th className="py-2.5 px-3 text-right">{isNe ? 'भ्याट' : 'VAT'}</th>
                  <th className="py-2.5 px-3 text-right">{isNe ? 'कुल रकम' : 'Total'}</th>
                  <th className="py-2.5 px-3 text-center">{isNe ? 'कार्य' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {purchases.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-mono">
                      {p.dateBs}
                      {p.entryDateBs && p.entryDateBs !== p.dateBs && (
                        <span
                          className="block text-[9px] text-slate-400 font-sans"
                          title={isNe ? 'सिस्टममा वास्तविक प्रविष्टि मिति' : 'Actual system entry date'}
                        >
                          {isNe ? 'प्रविष्टि' : 'Entry'}: {p.entryDateBs}
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-800">{p.purchaseBillNo}</td>
                    <td className="py-2.5 px-3 font-bold text-slate-900">{p.supplierName}</td>
                    <td className="py-2.5 px-3 text-slate-600">{p.itemsSummary}</td>
                    <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(p.vatAmount, isNe)}</td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                      {formatCurrency(p.grandTotal, isNe)}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setCreatedPurchaseForPrint({
                              purchase: p,
                              items:
                                p.items && p.items.length > 0
                                  ? p.items
                                  : [
                                      {
                                        itemId: `p-item-${p.id}`,
                                        code: p.purchaseBillNo,
                                        name: p.itemsSummary || (isNe ? 'खरिद गरिएका सामानहरू' : 'Purchased Items'),
                                        unit: 'थान',
                                        quantity: 1,
                                        rate: p.taxableAmount + p.exemptAmount,
                                        amount: p.taxableAmount + p.exemptAmount,
                                        isVatExempt: p.exemptAmount > 0
                                      }
                                    ],
                              supplierAddress: '',
                              supplierPhone: '',
                              subtotal: p.taxableAmount + p.exemptAmount,
                              discountAmount: 0,
                              exemptAmount: p.exemptAmount,
                              taxableAmount: p.taxableAmount,
                              vatAmount: p.vatAmount,
                              grandTotal: p.grandTotal,
                              billType: p.vatAmount > 0 ? 'VAT' : 'NON_VAT'
                            });
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded text-[10px] cursor-pointer shadow-2xs transition"
                          title={isNe ? 'खरिद बिल प्रिन्ट वा PDF डाउनलोड गर्नुहोस्' : 'Print or download purchase bill PDF'}
                        >
                          <Printer className="w-3 h-3" />
                          <span>{isNe ? '📄 PDF / प्रिन्ट' : 'PDF / Print'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setPurBillNo(p.purchaseBillNo);
                            setPurSupplierName(p.supplierName);
                            setPurSupplierPan(p.supplierPan || '');
                            setPurSummary(p.itemsSummary);
                            setPurEntryMode('LUMP_SUM');
                            setPurTaxable(p.taxableAmount);
                            setPurExempt(p.exemptAmount);
                            setPurBillType(p.vatAmount > 0 ? 'VAT' : 'NON_VAT');
                            showToast(`${p.purchaseBillNo} फर्ममा लोड गरियो!`);
                          }}
                          className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 font-bold rounded text-[10px] cursor-pointer"
                        >
                          {isNe ? 'लोड' : 'Load'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            deletePurchase(p.id);
                            showToast(`${p.purchaseBillNo} हटाइयो।`);
                          }}
                          className="p-1 text-rose-600 hover:bg-rose-50 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <HandwrittenBillScannerModal
          isOpen={isAiScanModalOpen}
          onClose={() => setIsAiScanModalOpen(false)}
          onApplyExtractedData={(data) => {
            if (data.invoiceNo) setPurBillNo(data.invoiceNo);
            if (data.customerName) setPurSupplierName(data.customerName);
            if (data.customerPan) setPurSupplierPan(data.customerPan);
            if (data.customerAddress) setPurSupplierAddress(data.customerAddress);
            if (data.customerPhone) setPurSupplierPhone(data.customerPhone);
            if (data.billType) setPurBillType(data.billType);
            if (data.paymentDueDate) setPurPaymentDueDate(data.paymentDueDate);
            if (data.previousDue) setPurPreviousDue(data.previousDue);
            if (data.amountPaid) setPurAmountPaidInput(data.amountPaid);
            if (data.discountPercent) setPurDiscountPercent(data.discountPercent);
            if (data.freightCharge) setPurFreightCharge(data.freightCharge);
            if (data.photoUrl) setPurPhotoUrl(data.photoUrl);
            if (data.lineItems.length > 0) {
              setPurEntryMode('ITEMIZED');
              setPurLineItems(data.lineItems);
              setPurTaxable(data.lineItems.reduce((acc, curr) => acc + curr.amount, 0));
            }
            if (data.notes) setPurSummary(data.notes);
            showToast(isNe ? 'फोटो बिलको विवरण खरिद फर्ममा भरियो!' : 'Photo bill details loaded into purchase form!');
          }}
        />

        <BarcodeScannerModal
          isOpen={isPurBarcodeScannerOpen}
          onClose={() => setIsPurBarcodeScannerOpen(false)}
          onItemScanned={handlePurBarcodeScanned}
        />

        {/* Quick "Add New Item" Modal — register a new master item from Purchase entry */}
        {isPurQuickItemOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
            <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
              <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
                <h3 className="text-sm font-bold text-slate-900">
                  {isNe ? 'नयाँ सामान दर्ता (Add New Item)' : 'Register New Item'}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsPurQuickItemOpen(false)}
                  className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-5 space-y-3 text-xs overflow-y-auto flex-1 min-h-0">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    {isNe ? 'सामानको नाम*' : 'Item Name*'}
                  </label>
                  <input
                    type="text"
                    autoFocus
                    value={qaItemName}
                    onChange={(e) => setQaItemName(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded"
                    placeholder={isNe ? 'जस्तै: Power Tiller 7HP Diesel' : 'e.g. Power Tiller 7HP Diesel'}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {isNe ? 'सामान कोड (खाली छोड्दा स्वतः बन्छ)' : 'Item Code (auto if blank)'}
                    </label>
                    <input
                      type="text"
                      value={qaItemCode}
                      onChange={(e) => setQaItemCode(e.target.value)}
                      className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono"
                      placeholder="KY-0001"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {isNe ? 'एकाइ (Unit)' : 'Unit'}
                    </label>
                    <input
                      type="text"
                      list="pur-quick-item-units"
                      value={qaItemUnit}
                      onChange={(e) => setQaItemUnit(e.target.value)}
                      className="w-full px-2.5 py-2 border border-slate-200 rounded"
                    />
                    <datalist id="pur-quick-item-units">
                      {['Pcs', 'Set', 'Kg', 'Ltr', 'Bag', 'Box', 'Roll', 'Carton', 'Meter', 'Drum'].map((u) => (
                        <option key={u} value={u} />
                      ))}
                    </datalist>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    {isNe ? 'वर्ग (Category)' : 'Category'}
                  </label>
                  <select
                    value={qaItemCategory}
                    onChange={(e) => setQaItemCategory(e.target.value as ItemCategory)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded bg-white cursor-pointer"
                  >
                    {purQuickAddCategories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {isNe ? cat.labelNe : cat.labelEn}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {isNe ? 'खरिद दर' : 'Purchase Price'}
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={qaItemPurchasePrice}
                      onChange={(e) => setQaItemPurchasePrice(parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {isNe ? 'बिक्री दर' : 'Selling Price'}
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={qaItemSellingPrice}
                      onChange={(e) => setQaItemSellingPrice(parseFloat(e.target.value) || 0)}
                      className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono"
                      placeholder={isNe ? 'खाली छोड्दा खरिद दर बराबर' : 'Defaults to purchase price'}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                  <input
                    type="checkbox"
                    id="qaVatExempt"
                    checked={qaItemIsVatExempt}
                    onChange={(e) => setQaItemIsVatExempt(e.target.checked)}
                    className="rounded text-emerald-700 w-4 h-4 cursor-pointer"
                  />
                  <label htmlFor="qaVatExempt" className="text-slate-800 font-medium cursor-pointer">
                    {isNe ? 'यो सामान भ्याट छुट हो (VAT Exempt)' : 'This item is VAT exempt'}
                  </label>
                </div>

                <p className="text-[10px] text-slate-400">
                  {isNe
                    ? 'पछि विस्तृत विवरण (फोटो, HS Code, द्वितीय एकाइ आदि) इन्भेन्टरीबाट सम्पादन गर्न सकिन्छ।'
                    : 'Full details (photo, HS code, secondary unit, etc.) can be edited later from Inventory.'}
                </p>
              </div>

              <div className="flex justify-end gap-2 px-5 py-3.5 border-t border-slate-100 bg-slate-50 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsPurQuickItemOpen(false)}
                  className="px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="button"
                  onClick={handleSavePurQuickAddItem}
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition cursor-pointer"
                >
                  {isNe ? 'थपेर यहि प्रयोग गर्नुहोस्' : 'Add & Use in This Purchase'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Purchase Bill Print & Direct PDF Download Modal */}
        {createdPurchaseForPrint && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto">
            <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-4xl max-h-[96vh] flex flex-col my-auto overflow-hidden animate-in fade-in zoom-in duration-200">
              {/* Top Controls Bar */}
              <div className="px-5 py-3.5 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 shrink-0">
                <div className="flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-emerald-400" />
                  <div>
                    <h3 className="text-sm font-bold leading-tight">
                      {isNe ? 'खरिद बीजक / बिल प्रिन्ट तथा PDF डाउनलोड' : 'Purchase Invoice Print & Direct PDF'}
                    </h3>
                    <p className="text-[11px] text-slate-400 font-mono">
                      {createdPurchaseForPrint.purchase.purchaseBillNo} • {createdPurchaseForPrint.purchase.dateBs}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <PaperSizeToggle />
                  {/* Format Selector */}
                  <div className="flex items-center bg-slate-800 p-0.5 rounded-lg border border-slate-700 text-xs">
                    <button
                      type="button"
                      onClick={() => setPurPrintFormat('A4')}
                      className={`px-2.5 py-1 rounded font-bold transition cursor-pointer ${
                        purPrintFormat === 'A4' ? 'bg-emerald-700 text-white shadow-xs' : 'text-slate-300 hover:text-white'
                      }`}
                    >
                      A4 Full
                    </button>
                    <button
                      type="button"
                      onClick={() => setPurPrintFormat('80MM')}
                      className={`px-2.5 py-1 rounded font-bold transition cursor-pointer ${
                        purPrintFormat === '80MM' ? 'bg-emerald-700 text-white shadow-xs' : 'text-slate-300 hover:text-white'
                      }`}
                    >
                      80mm POS
                    </button>
                  </div>

                  {/* Direct PDF Download Button */}
                  <button
                    type="button"
                    disabled={isPurGeneratingPdf}
                    onClick={async () => {
                      setIsPurGeneratingPdf(true);
                      try {
                        await downloadElementAsPdf({
                          elementId: 'printable-purchase-bill',
                          fileName: `खरिद_बीजक_${createdPurchaseForPrint.purchase.purchaseBillNo}.pdf`,
                          format: purPrintFormat === '80MM' ? 'pos80' : 'a4',
                          onProgress: setIsPurGeneratingPdf
                        });
                        showToast(isNe ? 'खरिद बिलको PDF डाउनलोड सम्पन्न भयो!' : 'Purchase PDF downloaded!');
                      } catch (err) {
                        console.error(err);
                        showToast(isNe ? 'PDF डाउनलोड गर्न सकिएन।' : 'Failed to download PDF.');
                      } finally {
                        setIsPurGeneratingPdf(false);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold rounded-lg shadow-sm cursor-pointer transition active:scale-95"
                  >
                    {isPurGeneratingPdf ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>{isNe ? 'PDF बन्दैछ...' : 'Generating...'}</span>
                      </>
                    ) : (
                      <>
                        <FileDown className="w-3.5 h-3.5" />
                        <span>{isNe ? '📄 सिधै PDF डाउनलोड' : 'Direct PDF'}</span>
                      </>
                    )}
                  </button>

                  {/* Browser Print Button */}
                  <button
                    type="button"
                    onClick={() => printPage()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm cursor-pointer transition active:scale-95"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>{isNe ? '🖨️ प्रिन्ट' : 'Print'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCreatedPurchaseForPrint(null)}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer"
                    title={isNe ? 'बन्द गर्नुहोस्' : 'Close'}
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Printable Body */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100 flex justify-center">
                <div
                  id="printable-purchase-bill"
                  className={`bg-white text-slate-900 border border-slate-300 shadow-sm p-6 sm:p-8 space-y-4 print:border-none print:shadow-none print:p-0 ${
                    purPrintFormat === '80MM' ? 'w-[320px] text-xs' : 'w-full max-w-[210mm] text-xs'
                  }`}
                  style={{ fontFamily: "'Inter', sans-serif" }}
                >
                  {/* Company Header */}
                  <div className="text-center border-b-2 border-slate-900 pb-3 space-y-1">
                    <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-950 uppercase">
                      {company.name}
                    </h1>
                    <p className="text-xs text-slate-700">
                      {company.address} • फोन: {company.phone}
                    </p>
                    <div className="flex items-center justify-center gap-4 text-xs font-mono font-bold text-slate-900 pt-0.5">
                      <span>स्थायी लेखा नं. (PAN): <strong>{company.panVatNo}</strong></span>
                      <span>आ.व.: {company.fiscalYear || '२०८१/८२'}</span>
                    </div>
                    <div className="pt-1.5">
                      <span className="inline-block px-3 py-1 bg-slate-900 text-white text-xs sm:text-sm font-extrabold rounded-md uppercase tracking-wider">
                        {createdPurchaseForPrint.billType === 'VAT'
                          ? (isNe ? 'कर खरिद बीजक (Tax Purchase Invoice)' : 'TAX PURCHASE INVOICE')
                          : (isNe ? 'खरिद बीजक / भौचर (Purchase Bill)' : 'PURCHASE INVOICE')}
                      </span>
                    </div>
                  </div>

                  {/* Metadata & Supplier Info Grid */}
                  <div className="grid grid-cols-2 gap-3 text-xs border border-slate-300 p-3 rounded-lg bg-slate-50/50">
                    <div className="space-y-1">
                      <div>
                        <span className="text-slate-500 font-medium">खरिद बीजक नं: </span>
                        <strong className="font-mono text-slate-950">{createdPurchaseForPrint.purchase.purchaseBillNo}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 font-medium">मिति (B.S.): </span>
                        <strong className="font-mono text-slate-900">{createdPurchaseForPrint.purchase.dateBs}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 font-medium">मिति (A.D.): </span>
                        <span className="font-mono text-slate-700">{createdPurchaseForPrint.purchase.dateAd}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 font-medium">भुक्तानी माध्यम: </span>
                        <strong className="text-slate-900">
                          {createdPurchaseForPrint.purchase.paymentMode === 'CASH'
                            ? 'नगद (Cash)'
                            : createdPurchaseForPrint.purchase.paymentMode === 'CREDIT'
                            ? 'उधारो (Credit)'
                            : 'बैंक / QR (Bank)'}
                        </strong>
                      </div>
                    </div>

                    <div className="space-y-1 text-right">
                      <div>
                        <span className="text-slate-500 font-medium">आपूर्तिकर्ता: </span>
                        <strong className="text-slate-950 text-sm">{createdPurchaseForPrint.purchase.supplierName}</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 font-medium">आपूर्तिकर्ता PAN: </span>
                        <strong className="font-mono text-slate-950">
                          {createdPurchaseForPrint.purchase.supplierPan || 'दर्ता नभएको'}
                        </strong>
                      </div>
                      {createdPurchaseForPrint.supplierAddress && (
                        <div>
                          <span className="text-slate-500 font-medium">ठेगाना: </span>
                          <span className="text-slate-800">{createdPurchaseForPrint.supplierAddress}</span>
                        </div>
                      )}
                      {createdPurchaseForPrint.supplierPhone && (
                        <div>
                          <span className="text-slate-500 font-medium">फोन नं: </span>
                          <span className="font-mono text-slate-800">{createdPurchaseForPrint.supplierPhone}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Items Room Table (Government compliant layout) */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left border-collapse border border-slate-900">
                      <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-900">
                        <tr>
                          <th className="py-2 px-2 text-center w-10 border-r border-slate-900">क्र.सं.</th>
                          <th className="py-2 px-2.5 border-r border-slate-900">सामानको कोड र विवरण (Particulars)</th>
                          <th className="py-2 px-2 text-center w-24 border-r border-slate-900">साइज</th>
                          <th className="py-2 px-2 text-center w-14 border-r border-slate-900">परिमाण</th>
                          <th className="py-2 px-2 text-center w-14 border-r border-slate-900">एकाइ</th>
                          <th className="py-2 px-2 text-right w-20 border-r border-slate-900">दर (रु.)</th>
                          <th className="py-2 px-2 text-center w-14 border-r border-slate-900">छुट (%)</th>
                          <th className="py-2 px-2.5 text-right w-24">जम्मा रकम (रु.)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-300">
                        {createdPurchaseForPrint.items && createdPurchaseForPrint.items.length > 0 ? (
                          createdPurchaseForPrint.items.map((line, idx) => (
                            <tr key={idx} className="border-b border-slate-300">
                              <td className="py-1.5 px-2 text-center font-mono border-r border-slate-900">
                                {isNe ? toNepaliDigits(idx + 1) : idx + 1}
                              </td>
                              <td className="py-1.5 px-2.5 border-r border-slate-900 font-medium text-slate-900">
                                <div>
                                  {line.code && (
                                    <span className="font-mono text-[10px] bg-slate-100 text-slate-800 px-1 py-0.2 rounded mr-1 border border-slate-200">
                                      {line.code}
                                    </span>
                                  )}
                                  <span>{line.name}</span>
                                </div>
                                {line.isVatExempt && (
                                  <span className="text-[9px] text-amber-800 bg-amber-50 px-1 rounded border border-amber-200">
                                    कर छुट (VAT Exempt)
                                  </span>
                                )}
                              </td>
                              <td className="py-1.5 px-2 text-center font-semibold text-slate-800 border-r border-slate-900">
                                {line.size || '-'}
                              </td>
                              <td className="py-1.5 px-2 text-center font-mono font-bold border-r border-slate-900">
                                {line.quantity}
                              </td>
                              <td className="py-1.5 px-2 text-center text-slate-700 border-r border-slate-900">
                                {line.unit || 'थान'}
                              </td>
                              <td className="py-1.5 px-2 text-right font-mono border-r border-slate-900">
                                {line.rate.toFixed(2)}
                              </td>
                              <td className="py-1.5 px-2 text-center font-mono border-r border-slate-900">
                                {line.discountPercent ? `${line.discountPercent}%` : '-'}
                              </td>
                              <td className="py-1.5 px-2.5 text-right font-mono font-bold text-slate-900">
                                {line.amount.toFixed(2)}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td className="py-2 px-2 text-center font-mono border-r border-slate-900">१</td>
                            <td className="py-2 px-2.5 border-r border-slate-900 font-medium" colSpan={2}>
                              {createdPurchaseForPrint.purchase.itemsSummary || 'कृषि औजार तथा पार्टपुर्जा खरिद'}
                            </td>
                            <td className="py-2 px-2 text-center font-mono border-r border-slate-900">१</td>
                            <td className="py-2 px-2 text-center text-slate-700 border-r border-slate-900">जम्मा</td>
                            <td className="py-2 px-2 text-right font-mono border-r border-slate-900">
                              {createdPurchaseForPrint.subtotal.toFixed(2)}
                            </td>
                            <td className="py-2 px-2 text-center font-mono border-r border-slate-900">-</td>
                            <td className="py-2 px-2.5 text-right font-mono font-bold">
                              {createdPurchaseForPrint.subtotal.toFixed(2)}
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Totals Summary Table */}
                  <div className="flex justify-end pt-1">
                    <div className="w-full sm:w-72 border border-slate-900 text-xs">
                      <div className="flex justify-between py-1 px-2.5 border-b border-slate-300">
                        <span className="font-semibold text-slate-700">उप-जम्मा (Sub Total):</span>
                        <span className="font-mono font-bold">{formatCurrency(createdPurchaseForPrint.subtotal, isNe)}</span>
                      </div>
                      {createdPurchaseForPrint.discountAmount > 0 && (
                        <div className="flex justify-between py-1 px-2.5 border-b border-slate-300 text-rose-700">
                          <span>छुट रकम (Discount):</span>
                          <span className="font-mono">-{formatCurrency(createdPurchaseForPrint.discountAmount, isNe)}</span>
                        </div>
                      )}
                      <div className="flex justify-between py-1 px-2.5 border-b border-slate-300">
                        <span className="text-slate-700">अकरयोग्य / कर छुट रकम:</span>
                        <span className="font-mono">{formatCurrency(createdPurchaseForPrint.exemptAmount, isNe)}</span>
                      </div>
                      <div className="flex justify-between py-1 px-2.5 border-b border-slate-300">
                        <span className="font-semibold text-slate-900">करयोग्य रकम (Taxable Amount):</span>
                        <span className="font-mono font-bold">{formatCurrency(createdPurchaseForPrint.taxableAmount, isNe)}</span>
                      </div>
                      {createdPurchaseForPrint.billType === 'VAT' && (
                        <div className="flex justify-between py-1 px-2.5 border-b border-slate-300 text-blue-900 font-bold">
                          <span>१३% भ्याट रकम (13% VAT):</span>
                          <span className="font-mono">{formatCurrency(createdPurchaseForPrint.vatAmount, isNe)}</span>
                        </div>
                      )}
                      <div className="flex justify-between py-1.5 px-2.5 bg-slate-100 font-black text-slate-950 text-sm">
                        <span>कुल जम्मा (Grand Total):</span>
                        <span className="font-mono text-emerald-800">{formatCurrency(createdPurchaseForPrint.grandTotal, isNe)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Words in Nepali */}
                  <div className="p-2.5 bg-slate-50 border border-slate-300 rounded text-xs text-slate-800">
                    <span className="font-bold">अक्षरूपी: </span>
                    <span>{amountInNepaliWords(createdPurchaseForPrint.grandTotal)}</span>
                  </div>

                  {/* Signatures */}
                  <div className="pt-8 grid grid-cols-2 text-center text-xs text-slate-700">
                    <div className="border-t border-slate-400 pt-1.5 mx-6">
                      <p className="font-bold text-slate-900">
                        {currentAccount?.ownerName || (currentRole === 'OWNER' ? 'राजन गोपाली' : 'काउन्टर कर्मचारी')}
                      </p>
                      <p className="text-[11px] text-slate-500">तयार गर्ने / आधिकारिक दस्तखत</p>
                    </div>
                    <div className="border-t border-slate-400 pt-1.5 mx-6">
                      <p className="font-bold text-slate-900">{createdPurchaseForPrint.purchase.supplierName}</p>
                      <p className="text-[11px] text-slate-500">बुझाउने / आपूर्तिकर्ताको दस्तखत</p>
                    </div>
                  </div>

                  <p className="text-[10px] text-center text-slate-400 pt-2">
                    कम्प्युटर प्रणालीबाट जारी गरिएको आधिकारिक खरिद बीजक।
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ===========================================================================
  // TAB 5: SALES RETURN (बिक्री फिर्ता - कुनै पनि सामान, बिल नं वा नामबाट)
  // ===========================================================================
  if (billingSubTab === 'SALES_RETURN') {
    const targetInv = invoices.find((i) => i.id === selectedReturnInvoiceId);
    const directSelectedItem = items.find((i) => i.id === srSelectedItemId);

    const handleSelectInvoiceForReturn = (invId: string) => {
      setSelectedReturnInvoiceId(invId);
      const found = invoices.find((i) => i.id === invId);
      if (found) {
        setSrManualBillNo(found.invoiceNo);
        setSrCustomerName(found.customerName);
        const initLines: Record<number, { selected: boolean; returnQty: number }> = {};
        found.items.forEach((line, idx) => {
          initLines[idx] = { selected: true, returnQty: line.quantity };
        });
        setInvoiceLineReturns(initLines);
      } else {
        setInvoiceLineReturns({});
      }
    };

    // Calculate total return amount from selected invoice lines + optional direct item
    const calculatedSrItems = () => {
      const list: SalesReturnRecord['returnedItems'] = [];
      if (targetInv) {
        targetInv.items.forEach((line, idx) => {
          const state = invoiceLineReturns[idx];
          if (state?.selected && state.returnQty > 0) {
            list.push({
              itemId: line.itemId,
              itemName: line.name,
              returnQty: state.returnQty,
              unitPrice: line.rate,
              lineTotal: state.returnQty * line.rate
            });
          }
        });
      }
      if (directSelectedItem && srReturnQty > 0) {
        const price = srUnitPrice > 0 ? srUnitPrice : directSelectedItem.sellingPrice;
        list.push({
          itemId: directSelectedItem.id,
          itemName: directSelectedItem.nameNe || directSelectedItem.nameEn,
          returnQty: srReturnQty,
          unitPrice: price,
          lineTotal: srReturnQty * price
        });
      } else if (!directSelectedItem && srCustomItemName.trim() && srReturnQty > 0) {
        list.push({
          itemName: srCustomItemName.trim(),
          returnQty: srReturnQty,
          unitPrice: srUnitPrice,
          lineTotal: srReturnQty * srUnitPrice
        });
      }
      return list;
    };

    const previewSrItems = calculatedSrItems();
    const totalSrReturnAmt = previewSrItems.reduce((sum, it) => sum + it.lineTotal, 0);

    const handleProcessSalesReturn = (e: React.FormEvent) => {
      e.preventDefault();
      if (previewSrItems.length === 0) {
        showToast(
          isNe
            ? 'कृपया फिर्ता गर्ने कम्तीमा एउटा सामान छान्नुहोस् वा प्रविष्ट गर्नुहोस्!'
            : 'Please select or enter at least one item to return!'
        );
        return;
      }

      const finalBillNo =
        srManualBillNo.trim() || targetInv?.invoiceNo || `BILL-${Date.now().toString().slice(-4)}`;
      const finalCustomer =
        srCustomerName.trim() || targetInv?.customerName || (isNe ? 'खुद्रा ग्राहक' : 'Walk-in Customer');
      const creditNoteNo = `CRN-${new Date().getFullYear()}-${String(salesReturnRecords.length + 1).padStart(3, '0')}`;

      // 1. Restore Stock for each returned item that matches Inventory
      previewSrItems.forEach((retLine) => {
        if (retLine.itemId) {
          const invItem = items.find((i) => i.id === retLine.itemId);
          if (invItem) {
            adjustStock(invItem.id, invItem.currentStock + retLine.returnQty);
          }
        } else {
          const byName = items.find(
            (i) =>
              i.nameNe.toLowerCase() === retLine.itemName.toLowerCase() ||
              i.nameEn.toLowerCase() === retLine.itemName.toLowerCase()
          );
          if (byName) {
            adjustStock(byName.id, byName.currentStock + retLine.returnQty);
          }
        }
      });

      // 2. If all items of an active invoice were returned completely, mark invoice cancelled/returned
      if (
        targetInv &&
        targetInv.status === 'ACTIVE' &&
        targetInv.items.every((line, idx) => {
          const st = invoiceLineReturns[idx];
          return st?.selected && st.returnQty >= line.quantity;
        })
      ) {
        cancelInvoice(targetInv.id);
      } else if (srRefundMode === 'CREDIT_ADJUST') {
        // Adjust customer party balance if matched
        const matchedParty = parties.find(
          (p) =>
            p.id === targetInv?.partyId ||
            p.name.toLowerCase() === finalCustomer.toLowerCase()
        );
        if (matchedParty) {
          updatePartyBalance(matchedParty.id, (matchedParty.currentBalance ?? matchedParty.openingBalance) - totalSrReturnAmt);
        }
      }

      // 3. Save Sales Return Record
      const newRecord: SalesReturnRecord = {
        id: `sr-${Date.now()}`,
        creditNoteNo,
        dateBs: getTodayBsString(),
        invoiceNo: finalBillNo,
        customerName: finalCustomer,
        returnedItems: previewSrItems,
        totalReturnAmount: totalSrReturnAmt,
        reason: salesReturnReason,
        refundMode: srRefundMode
      };
      setSalesReturnRecords((prev) => [newRecord, ...prev]);

      // 4. Audit Trail Log
      const itemsSummaryText = previewSrItems
        .map((i) => `${i.itemName} (x${i.returnQty})`)
        .join(', ');
      logAuditAction({
        actionType: 'INVOICE_CANCELLED',
        module: 'BILLING',
        severity: 'CRITICAL',
        targetId: `${creditNoteNo} / ${finalBillNo}`,
        summaryNe: `बिक्री फिर्ता (${creditNoteNo}): बिल नं ${finalBillNo} (${finalCustomer}) — सामान: ${itemsSummaryText} | रु. ${totalSrReturnAmt}`,
        summaryEn: `Sales Return (${creditNoteNo}) for Bill #${finalBillNo} (${finalCustomer}) — Items: ${itemsSummaryText}`,
        details: `Reason: ${salesReturnReason} | Refund Mode: ${srRefundMode} | Stock Restored`
      });

      // Reset form
      setSelectedReturnInvoiceId('');
      setInvoiceLineReturns({});
      setSrSelectedItemId('');
      setSrCustomItemName('');
      setSrReturnQty(1);
      setSrUnitPrice(0);
      showToast(
        isNe
          ? `बिक्री फिर्ता (${creditNoteNo}) दर्ता भयो र फिर्ता सामान स्टकमा जोडियो!`
          : `Sales Return (${creditNoteNo}) saved and returned item stock restored!`
      );
    };

    return (
      <div className="space-y-5">
        {toastMsg && (
          <div className="bg-emerald-900 text-white px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-2 shadow-md">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{toastMsg}</span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left: Item-Level Sales Return Form */}
          <form
            onSubmit={handleProcessSalesReturn}
            className="lg:col-span-6 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4"
          >
            <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
              <div className="p-2 bg-rose-100 text-rose-800 rounded-xl">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900">
                  {isNe
                    ? 'बिक्री फिर्ता / क्रेडिट नोट (Item-wise Sales Return)'
                    : 'Sales Return / Credit Note (By Bill No, Name or Item)'}
                </h3>
                <p className="text-[11px] text-slate-500">
                  {isNe
                    ? 'बिल नं (Invoice No), ग्राहकको नाम वा सिधै सामानको नामबाट कुनै पनि सामान फिर्ता लिनुहोस्'
                    : 'Search by Invoice No, Customer Name, or pick any specific item to return into stock'}
                </p>
              </div>
            </div>

            {/* Step 1: Search Invoice by Bill No, Customer Name, or Item Name */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5 text-xs">
              <label className="block font-bold text-slate-800">
                {isNe
                  ? '१. बिल नं (Invoice No), ग्राहकको नाम वा सामानबाट बिल खोज्नुहोस्:'
                  : '1. Search Invoice by Bill No, Customer Name, or Item:'}
              </label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={srSearchQuery}
                  onChange={(e) => setSrSearchQuery(e.target.value)}
                  placeholder={
                    isNe
                      ? 'यहाँ बिल नं (TI-...), ग्राहकको नाम वा सामान टाइप गर्नुहोस्...'
                      : 'Type Invoice No (TI-...), Customer Name, or Item Name...'
                  }
                  className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-xl bg-white focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <select
                value={selectedReturnInvoiceId}
                onChange={(e) => handleSelectInvoiceForReturn(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-bold text-slate-800"
              >
                <option value="">
                  {isNe
                    ? `-- भेटिएका बिलहरू (${matchingInvoicesForReturn.length}) बाट छान्नुहोस् वा तल सिधै भर्नुहोस् --`
                    : `-- Select from matching Invoices (${matchingInvoicesForReturn.length}) or enter manually below --`}
                </option>
                {matchingInvoicesForReturn.map((inv) => (
                  <option key={inv.id} value={inv.id}>
                    #{inv.invoiceNo} | {inv.customerName} | {inv.dateBs} ({formatCurrency(inv.grandTotal, isNe)})
                  </option>
                ))}
              </select>

              {/* Manual / Editable Bill No & Customer Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <div>
                  <label className="block font-bold text-slate-600 mb-1 flex items-center gap-1">
                    <Hash className="w-3 h-3 text-emerald-700" />
                    <span>{isNe ? 'बिल / बीजक नं (Bill/Invoice No)*' : 'Invoice / Bill No*'}</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={srManualBillNo}
                    onChange={(e) => setSrManualBillNo(e.target.value)}
                    placeholder={isNe ? 'उदा: TI-081/82-0001 वा 105' : 'e.g. TI-081/82-0001'}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-600 mb-1 flex items-center gap-1">
                    <User className="w-3 h-3 text-emerald-700" />
                    <span>{isNe ? 'ग्राहक / पार्टीको नाम (Customer Name)*' : 'Customer / Party Name*'}</span>
                  </label>
                  <input
                    type="text"
                    required
                    list="sr-customer-list"
                    value={srCustomerName}
                    onChange={(e) => setSrCustomerName(e.target.value)}
                    placeholder={isNe ? 'ग्राहकको नाम लेख्नुहोस् वा छान्नुहोस्' : 'Customer name'}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-bold"
                  />
                  <datalist id="sr-customer-list">
                    {parties.filter(isCustomerParty).map((p) => (
                      <option key={p.id} value={p.name} />
                    ))}
                  </datalist>
                </div>
              </div>
            </div>

            {/* Step 2A: If an Invoice is selected, show its line items with checkboxes & return qty */}
            {targetInv && (
              <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-black text-amber-950">
                    {isNe
                      ? `बिल #${targetInv.invoiceNo} का सामानहरू (फिर्ता हुने सामान र परिमाण छान्नुहोस्):`
                      : `Items in Invoice #${targetInv.invoiceNo} (Select items & qty to return):`}
                  </span>
                </div>
                <div className="space-y-2">
                  {targetInv.items.map((line, idx) => {
                    const st = invoiceLineReturns[idx] || { selected: false, returnQty: line.quantity };
                    return (
                      <div
                        key={idx}
                        className="flex items-center justify-between gap-2 bg-white p-2.5 rounded-lg border border-amber-200"
                      >
                        <label className="flex items-center gap-2 cursor-pointer flex-1">
                          <input
                            type="checkbox"
                            checked={st.selected}
                            onChange={(e) =>
                              setInvoiceLineReturns((prev) => ({
                                ...prev,
                                [idx]: { ...st, selected: e.target.checked }
                              }))
                            }
                            className="w-4 h-4 accent-rose-600 rounded cursor-pointer"
                          />
                          <div>
                            <div className="font-bold text-slate-900">{line.name}</div>
                            <div className="text-[11px] text-slate-500">
                              {isNe ? 'बिक्री परिमाण:' : 'Sold Qty:'} {line.quantity} {line.unit} ×{' '}
                              {formatCurrency(line.rate, isNe)}
                            </div>
                          </div>
                        </label>

                        {st.selected && (
                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] font-bold text-slate-600">
                              {isNe ? 'फिर्ता Qty:' : 'Return Qty:'}
                            </span>
                            <input
                              type="number"
                              min={1}
                              max={line.quantity}
                              value={st.returnQty}
                              onChange={(e) =>
                                setInvoiceLineReturns((prev) => ({
                                  ...prev,
                                  [idx]: {
                                    ...st,
                                    returnQty: Math.min(line.quantity, Math.max(1, Number(e.target.value)))
                                  }
                                }))
                              }
                              className="w-16 px-2 py-1 border border-slate-300 rounded-lg font-mono font-bold text-center"
                            />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Step 2B: Direct Any-Item Return Picker (कुनै पनि सामान सिधै छान्ने वा नाम लेख्ने) */}
            <div className="p-3.5 bg-rose-50/40 rounded-xl border border-rose-200/80 space-y-2.5 text-xs">
              <label className="block font-bold text-rose-950">
                {isNe
                  ? '२. कुनै पनि सामान छान्नुहोस् वा नाम लेखेर फिर्ता गर्नुहोस् (Return Specific Item):'
                  : '2. Pick Any Inventory Item or Enter Item Name to Return:'}
              </label>

              <input
                type="text"
                value={srItemSearch}
                onChange={(e) => setSrItemSearch(e.target.value)}
                placeholder={isNe ? 'सामानको नाम वा कोड खोज्नुहोस्...' : 'Filter inventory item by name/code...'}
                className="w-full px-3 py-1.5 border border-slate-200 rounded-lg bg-white text-xs"
              />

              <select
                value={srSelectedItemId}
                onChange={(e) => {
                  const id = e.target.value;
                  setSrSelectedItemId(id);
                  const found = items.find((i) => i.id === id);
                  if (found) {
                    setSrUnitPrice(found.sellingPrice);
                    setSrCustomItemName('');
                  }
                }}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-bold"
              >
                <option value="">
                  {isNe ? '-- स्टक सूचीबाट सामान छान्नुहोस् --' : '-- Select Item from Inventory --'}
                </option>
                {filteredSrItems.map((it) => (
                  <option key={it.id} value={it.id}>
                    {it.nameNe || it.nameEn} ({it.code}) — दर: रु.{it.sellingPrice} | मौज्दात: {it.currentStock}
                  </option>
                ))}
              </select>

              {!srSelectedItemId && (
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    {isNe
                      ? 'वा स्टक बाहिरको सामानको नाम सिधै लेख्नुहोस्:'
                      : 'Or type custom item name directly:'}
                  </label>
                  <input
                    type="text"
                    value={srCustomItemName}
                    onChange={(e) => setSrCustomItemName(e.target.value)}
                    placeholder={isNe ? 'उदा: रोटाभेटर ब्लेड सेट' : 'e.g. Rotavator Blade Set'}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isNe ? 'फिर्ता परिमाण (Return Qty)' : 'Return Quantity'}
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={srReturnQty}
                    onChange={(e) => setSrReturnQty(Math.max(1, Number(e.target.value)))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-mono font-bold text-center"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isNe ? 'प्रति एकाइ दर (Rate रु.)' : 'Unit Rate (NPR)'}
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={srUnitPrice || ''}
                    onChange={(e) => setSrUnitPrice(Number(e.target.value))}
                    placeholder="0"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-mono font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Refund Mode & Reason */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNe ? 'हिसाब मिलान माध्यम (Settlement)' : 'Settlement Mode'}
                </label>
                <select
                  value={srRefundMode}
                  onChange={(e) => setSrRefundMode(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 font-bold"
                >
                  <option value="CREDIT_ADJUST">
                    {isNe ? 'पार्टी उधारो खातामा घटाउने (Party Ledger Adjust)' : 'Adjust Party Credit Balance'}
                  </option>
                  <option value="CASH">{isNe ? 'नगद फिर्ता (Cash Refund)' : 'Cash Refund'}</option>
                  <option value="BANK">{isNe ? 'बैंक फिर्ता (Bank Refund)' : 'Bank Refund'}</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNe ? 'फिर्ताको कारण (Reason)*' : 'Return Reason*'}
                </label>
                <input
                  type="text"
                  required
                  value={salesReturnReason}
                  onChange={(e) => setSalesReturnReason(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
            </div>

            {/* Summary & Submit */}
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div>
                <span className="text-slate-600 block">
                  {isNe
                    ? `फिर्ता हुने सामान सङ्ख्या: ${previewSrItems.length} आइटम`
                    : `Returning ${previewSrItems.length} item(s)`}
                </span>
                <span className="text-sm font-black text-rose-800">
                  {isNe ? 'कुल फिर्ता रकम:' : 'Total Sales Return:'} {formatCurrency(totalSrReturnAmt, isNe)}
                </span>
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-xs transition cursor-pointer"
              >
                {isNe ? 'बिक्री फिर्ता र स्टक मिलान गर्नुहोस्' : 'Confirm Sales Return'}
              </button>
            </div>
          </form>

          {/* Right: Sales Return Register Table */}
          <div className="lg:col-span-6 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-black text-slate-900">
                {isNe
                  ? `बिक्री फिर्ता / क्रेडिट नोट रजिष्टर (${salesReturnRecords.length})`
                  : `Sales Return / Credit Note Register (${salesReturnRecords.length})`}
              </h3>
            </div>

            {salesReturnRecords.length === 0 ? (
              <div className="p-10 text-center text-xs text-slate-400">
                <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                {isNe
                  ? 'अहिलेसम्म कुनै सामानको बिक्री फिर्ता दर्ता भएको छैन। बायाँ फारममा बिल नं वा सामान छानेर फिर्ता गर्नुहोस्।'
                  : 'No item sales returns recorded yet. Use the form on the left to return any item by Bill No or Name.'}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                      <th className="py-2.5 px-2.5">{isNe ? 'मिति / CN नं' : 'Date / CN#'}</th>
                      <th className="py-2.5 px-2.5">{isNe ? 'बिल नं र ग्राहक' : 'Bill No & Customer'}</th>
                      <th className="py-2.5 px-2.5">{isNe ? 'फिर्ता सामान र परिमाण' : 'Returned Items'}</th>
                      <th className="py-2.5 px-2.5 text-right">{isNe ? 'फिर्ता रकम' : 'Amount'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {salesReturnRecords.map((rec) => (
                      <tr key={rec.id} className="hover:bg-rose-50/30">
                        <td className="py-2.5 px-2.5">
                          <div className="font-mono font-bold text-rose-700">{rec.creditNoteNo}</div>
                          <div className="text-[10px] font-mono text-slate-500">{rec.dateBs}</div>
                        </td>
                        <td className="py-2.5 px-2.5">
                          <div className="font-mono font-bold text-slate-800">#{rec.invoiceNo}</div>
                          <div className="font-semibold text-slate-700">{rec.customerName}</div>
                        </td>
                        <td className="py-2.5 px-2.5">
                          {rec.returnedItems.map((it, i) => (
                            <div key={i} className="text-slate-800 font-medium">
                              • {it.itemName} <span className="font-mono font-bold">× {it.returnQty}</span>
                            </div>
                          ))}
                          <div className="text-[10px] text-slate-500">{rec.reason}</div>
                        </td>
                        <td className="py-2.5 px-2.5 text-right font-mono font-bold text-rose-600">
                          {formatCurrency(rec.totalReturnAmount, isNe)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ===========================================================================
  // TAB 6: PURCHASE RETURN (खरिद फिर्ता - कुनै पनि सामान, बिल नं वा नामबाट)
  // ===========================================================================
  const selectedPur = purchases.find((p) => p.id === selectedPurReturnId);
  const selectedPurItem = items.find((i) => i.id === purReturnItemId);

  const handleSelectPurchaseForReturn = (purId: string) => {
    setSelectedPurReturnId(purId);
    const found = purchases.find((p) => p.id === purId);
    if (found) {
      setPrManualBillNo(found.purchaseBillNo);
      setPrSupplierName(found.supplierName);
      setPurReturnAmount(found.grandTotal);
      if (!purReturnItemId) {
        setPrCustomItemName(found.itemsSummary);
        setPrUnitPrice(found.grandTotal);
      }
    }
  };

  const calculatedPrAmount =
    purReturnAmount > 0
      ? purReturnAmount
      : prUnitPrice * purReturnQty;

  const handleProcessPurchaseReturn = (e: React.FormEvent) => {
    e.preventDefault();

    const itemName = selectedPurItem
      ? selectedPurItem.nameNe || selectedPurItem.nameEn
      : prCustomItemName.trim() || selectedPur?.itemsSummary || '';

    if (!itemName) {
      showToast(
        isNe
          ? 'कृपया फिर्ता गर्ने सामान छान्नुहोस् वा सामानको नाम लेख्नुहोस्!'
          : 'Please select or enter the item being returned!'
      );
      return;
    }

    const finalBillNo =
      prManualBillNo.trim() || selectedPur?.purchaseBillNo || `PB-${Date.now().toString().slice(-4)}`;
    const finalSupplier =
      prSupplierName.trim() || selectedPur?.supplierName || (isNe ? 'आपूर्तिकर्ता' : 'Supplier');
    const debitNoteNo = `DRN-${new Date().getFullYear()}-${String(purchaseReturnRecords.length + 1).padStart(3, '0')}`;

    // 1. Deduct Stock for the returned item
    if (selectedPurItem && purReturnQty > 0) {
      adjustStock(selectedPurItem.id, Math.max(0, selectedPurItem.currentStock - purReturnQty));
    } else {
      const byName = items.find(
        (i) =>
          i.nameNe.toLowerCase() === itemName.toLowerCase() ||
          i.nameEn.toLowerCase() === itemName.toLowerCase()
      );
      if (byName && purReturnQty > 0) {
        adjustStock(byName.id, Math.max(0, byName.currentStock - purReturnQty));
      }
    }

    // 2. Adjust supplier party balance if matched
    if (prRefundMode === 'CREDIT_ADJUST') {
      const matchedSupplier = parties.find(
        (p) => p.name.toLowerCase() === finalSupplier.toLowerCase()
      );
      if (matchedSupplier) {
        updatePartyBalance(
          matchedSupplier.id,
          (matchedSupplier.currentBalance ?? matchedSupplier.openingBalance) - calculatedPrAmount
        );
      }
    }

    // 3. Save Purchase Return Record
    const newPrRecord: PurchaseReturnRecord = {
      id: `pr-${Date.now()}`,
      debitNoteNo,
      dateBs: getTodayBsString(),
      purchaseBillNo: finalBillNo,
      supplierName: finalSupplier,
      returnedItems: [
        {
          itemId: selectedPurItem?.id,
          itemName,
          returnQty: purReturnQty,
          unitPrice: prUnitPrice || calculatedPrAmount / Math.max(1, purReturnQty),
          lineTotal: calculatedPrAmount
        }
      ],
      totalReturnAmount: calculatedPrAmount,
      reason: purReturnReason,
      refundMode: prRefundMode
    };
    setPurchaseReturnRecords((prev) => [newPrRecord, ...prev]);

    // 4. Audit Trail Log
    logAuditAction({
      actionType: 'STOCK_ADJUSTED',
      module: 'PURCHASE',
      severity: 'WARNING',
      targetId: `${debitNoteNo} / ${finalBillNo}`,
      summaryNe: `खरिद फिर्ता (${debitNoteNo}): बिल नं ${finalBillNo} (${finalSupplier}) — सामान: ${itemName} (x${purReturnQty}) | रु. ${calculatedPrAmount}`,
      summaryEn: `Purchase Return (${debitNoteNo}) for Bill #${finalBillNo} (${finalSupplier}) — Item: ${itemName} (x${purReturnQty})`,
      details: `Reason: ${purReturnReason} | Mode: ${prRefundMode}`
    });

    setSelectedPurReturnId('');
    setPurReturnItemId('');
    setPrCustomItemName('');
    setPurReturnQty(1);
    setPrUnitPrice(0);
    setPurReturnAmount(0);
    showToast(
      isNe
        ? `खरिद फिर्ता (${debitNoteNo}) दर्ता भयो र स्टक मिलान गरियो!`
        : `Purchase Return (${debitNoteNo}) recorded and stock adjusted!`
    );
  };

  return (
    <div className="space-y-5">
      {toastMsg && (
        <div className="bg-emerald-900 text-white px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-2 shadow-md">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Item-Level Purchase Return Form */}
        <form
          onSubmit={handleProcessPurchaseReturn}
          className="lg:col-span-6 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4"
        >
          <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
            <div className="p-2 bg-purple-100 text-purple-800 rounded-xl">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">
                {isNe
                  ? 'खरिद फिर्ता / डेबिट नोट (Item-wise Purchase Return)'
                  : 'Purchase Return / Debit Note (By Bill No, Supplier or Item)'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isNe
                  ? 'बिल नं (Bill No), आपूर्तिकर्ताको नाम वा सिधै सामानको नामबाट कुनै पनि सामान फिर्ता गर्नुहोस्'
                  : 'Search by Purchase Bill No, Supplier Name, or pick any specific item to return'}
              </p>
            </div>
          </div>

          {/* Step 1: Search Purchase Bill by Bill No, Supplier Name, or Item */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5 text-xs">
            <label className="block font-bold text-slate-800">
              {isNe
                ? '१. खरिद बिल नं (Bill No), आपूर्तिकर्ता वा सामानबाट खोज्नुहोस्:'
                : '1. Search Purchase by Bill No, Supplier Name, or Item:'}
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={prSearchQuery}
                onChange={(e) => setPrSearchQuery(e.target.value)}
                placeholder={
                  isNe
                    ? 'खरिद बिल नं (PB-...), सप्लायरको नाम वा सामान टाइप गर्नुहोस्...'
                    : 'Type Bill No (PB-...), Supplier Name, or Item...'
                }
                className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-xl bg-white focus:border-purple-600 focus:outline-none"
              />
            </div>

            <select
              value={selectedPurReturnId}
              onChange={(e) => handleSelectPurchaseForReturn(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-bold text-slate-800"
            >
              <option value="">
                {isNe
                  ? `-- खरिद बिल (${matchingPurchasesForReturn.length}) बाट छान्नुहोस् वा तल सिधै लेख्नुहोस् --`
                  : `-- Select from Purchase Bills (${matchingPurchasesForReturn.length}) or enter manually below --`}
              </option>
              {matchingPurchasesForReturn.map((p) => (
                <option key={p.id} value={p.id}>
                  #{p.purchaseBillNo} | {p.supplierName} | {p.itemsSummary} ({formatCurrency(p.grandTotal, isNe)})
                </option>
              ))}
            </select>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              <div>
                <label className="block font-bold text-slate-600 mb-1 flex items-center gap-1">
                  <Hash className="w-3 h-3 text-purple-700" />
                  <span>{isNe ? 'खरिद बिल नं (Purchase Bill No)*' : 'Purchase Bill No*'}</span>
                </label>
                <input
                  type="text"
                  required
                  value={prManualBillNo}
                  onChange={(e) => setPrManualBillNo(e.target.value)}
                  placeholder={isNe ? 'उदा: PB-2081-01 वा 502' : 'e.g. PB-2081-01'}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-mono font-bold"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-600 mb-1 flex items-center gap-1">
                  <User className="w-3 h-3 text-purple-700" />
                  <span>{isNe ? 'आपूर्तिकर्ताको नाम (Supplier Name)*' : 'Supplier Name*'}</span>
                </label>
                <input
                  type="text"
                  required
                  list="pr-supplier-list"
                  value={prSupplierName}
                  onChange={(e) => setPrSupplierName(e.target.value)}
                  placeholder={isNe ? 'आपूर्तिकर्ता / साहुको नाम' : 'Supplier Name'}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-bold"
                />
                <datalist id="pr-supplier-list">
                  {parties.filter(isSupplierParty).map((p) => (
                    <option key={p.id} value={p.name} />
                  ))}
                </datalist>
              </div>
            </div>
          </div>

          {/* Step 2: Select Any Item from Inventory or Enter Custom Item Name */}
          <div className="p-3.5 bg-purple-50/40 rounded-xl border border-purple-200/80 space-y-2.5 text-xs">
            <label className="block font-bold text-purple-950">
              {isNe
                ? '२. फिर्ता गर्ने कुनै पनि सामान छान्नुहोस् वा नाम लेख्नुहोस् (Select Item to Return):'
                : '2. Select Inventory Item or Type Item Name to Return:'}
            </label>

            <input
              type="text"
              value={prItemSearch}
              onChange={(e) => setPrItemSearch(e.target.value)}
              placeholder={isNe ? 'सामानको नाम वा कोडबाट खोज्नुहोस्...' : 'Search item by name or code...'}
              className="w-full px-3 py-1.5 border border-slate-200 rounded-lg bg-white text-xs"
            />

            <select
              value={purReturnItemId}
              onChange={(e) => {
                const id = e.target.value;
                setPurReturnItemId(id);
                const found = items.find((i) => i.id === id);
                if (found) {
                  setPrUnitPrice(found.purchasePrice);
                  setPurReturnAmount(found.purchasePrice * purReturnQty);
                  setPrCustomItemName('');
                }
              }}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white font-bold"
            >
              <option value="">
                {isNe ? '-- स्टक सूचीबाट फिर्ता गर्ने सामान छान्नुहोस् --' : '-- Choose Item from Inventory --'}
              </option>
              {filteredPrItems.map((it) => (
                <option key={it.id} value={it.id}>
                  {it.nameNe || it.nameEn} ({it.code}) — खरिद दर: रु.{it.purchasePrice} | मौज्दात: {it.currentStock}
                </option>
              ))}
            </select>

            {!purReturnItemId && (
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  {isNe ? 'वा फिर्ता गर्ने सामानको नाम सिधै लेख्नुहोस्:' : 'Or type item name directly:'}
                </label>
                <input
                  type="text"
                  value={prCustomItemName}
                  onChange={(e) => setPrCustomItemName(e.target.value)}
                  placeholder={isNe ? 'उदा: ७ एचपी डिजेल इन्जिन पार्ट्स' : 'e.g. 7HP Diesel Engine Parts'}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-white"
                />
              </div>
            )}

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNe ? 'फिर्ता परिमाण (Qty)' : 'Return Qty'}
                </label>
                <input
                  type="number"
                  min={1}
                  value={purReturnQty}
                  onChange={(e) => {
                    const q = Math.max(1, Number(e.target.value));
                    setPurReturnQty(q);
                    if (prUnitPrice > 0) {
                      setPurReturnAmount(prUnitPrice * q);
                    }
                  }}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded-xl bg-white font-mono font-bold text-center"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNe ? 'एकाइ दर (Rate रु.)' : 'Unit Rate'}
                </label>
                <input
                  type="number"
                  min={0}
                  value={prUnitPrice || ''}
                  onChange={(e) => {
                    const r = Number(e.target.value);
                    setPrUnitPrice(r);
                    setPurReturnAmount(r * purReturnQty);
                  }}
                  placeholder="0"
                  className="w-full px-2.5 py-2 border border-slate-200 rounded-xl bg-white font-mono font-bold"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isNe ? 'कुल फिर्ता रकम (रु.)*' : 'Total Amount*'}
                </label>
                <input
                  type="number"
                  min={0}
                  required
                  value={purReturnAmount || ''}
                  onChange={(e) => setPurReturnAmount(Number(e.target.value))}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded-xl bg-white font-mono font-bold text-purple-800"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                {isNe ? 'हिसाब मिलान (Settlement)' : 'Settlement Mode'}
              </label>
              <select
                value={prRefundMode}
                onChange={(e) => setPrRefundMode(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 font-bold"
              >
                <option value="CREDIT_ADJUST">
                  {isNe ? 'सप्लायर खातामा घटाउने (Supplier Ledger Adjust)' : 'Adjust Supplier Payable'}
                </option>
                <option value="CASH">{isNe ? 'नगद फिर्ता प्राप्त (Cash Refund)' : 'Cash Refund'}</option>
                <option value="BANK">{isNe ? 'बैंक फिर्ता (Bank Refund)' : 'Bank Refund'}</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                {isNe ? 'फिर्ताको कारण (Reason)*' : 'Reason for Purchase Return*'}
              </label>
              <input
                type="text"
                required
                value={purReturnReason}
                onChange={(e) => setPurReturnReason(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl"
              />
            </div>
          </div>

          <div className="p-3.5 bg-purple-50 border border-purple-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <span className="text-slate-600 block">
                {isNe ? `फिर्ता परिमाण: ${purReturnQty} एकाइ` : `Return Qty: ${purReturnQty} units`}
              </span>
              <span className="text-sm font-black text-purple-900">
                {isNe ? 'कुल खरिद फिर्ता:' : 'Total Purchase Return:'}{' '}
                {formatCurrency(calculatedPrAmount, isNe)}
              </span>
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl shadow-xs transition cursor-pointer"
            >
              {isNe ? 'खरिद फिर्ता (Debit Note) दर्ता गर्नुहोस्' : 'Confirm Purchase Return'}
            </button>
          </div>
        </form>

        {/* Right: Purchase Return Register Table */}
        <div className="lg:col-span-6 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-black text-slate-900">
              {isNe
                ? `खरिद फिर्ता / डेबिट नोट रजिष्टर (${purchaseReturnRecords.length})`
                : `Purchase Return / Debit Note Register (${purchaseReturnRecords.length})`}
            </h3>
          </div>

          {purchaseReturnRecords.length === 0 ? (
            <div className="p-10 text-center text-xs text-slate-400">
              <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              {isNe
                ? 'कुनै खरिद फिर्ता दर्ता भएको छैन। बायाँ फारममा बिल नं, सप्लायर वा सामान छानेर खरिद फिर्ता दर्ता गर्नुहोस्।'
                : 'No purchase returns recorded yet. Use the form on the left to return any item by Bill No or Name.'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <th className="py-2.5 px-2.5">{isNe ? 'मिति / DN नं' : 'Date / DN#'}</th>
                    <th className="py-2.5 px-2.5">{isNe ? 'बिल नं र सप्लायर' : 'Bill No & Supplier'}</th>
                    <th className="py-2.5 px-2.5">{isNe ? 'फिर्ता सामान र परिमाण' : 'Returned Item'}</th>
                    <th className="py-2.5 px-2.5 text-right">{isNe ? 'फिर्ता रकम' : 'Amount'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {purchaseReturnRecords.map((pr) => (
                    <tr key={pr.id} className="hover:bg-purple-50/40">
                      <td className="py-2.5 px-2.5">
                        <div className="font-mono font-bold text-purple-800">{pr.debitNoteNo}</div>
                        <div className="text-[10px] font-mono text-slate-500">{pr.dateBs}</div>
                      </td>
                      <td className="py-2.5 px-2.5">
                        <div className="font-mono font-bold text-slate-800">#{pr.purchaseBillNo}</div>
                        <div className="font-semibold text-slate-700">{pr.supplierName}</div>
                      </td>
                      <td className="py-2.5 px-2.5">
                        {pr.returnedItems.map((it, idx) => (
                          <div key={idx} className="text-slate-800 font-medium">
                            • {it.itemName} <span className="font-mono font-bold">× {it.returnQty}</span>
                          </div>
                        ))}
                        <div className="text-[10px] text-slate-500">{pr.reason}</div>
                      </td>
                      <td className="py-2.5 px-2.5 text-right font-mono font-bold text-purple-700">
                        {formatCurrency(pr.totalReturnAmount, isNe)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
