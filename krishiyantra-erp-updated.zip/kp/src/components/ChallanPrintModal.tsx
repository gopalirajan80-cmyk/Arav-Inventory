import { InvoicePrintOptions, printArgsFor } from './InvoicePrintOptions';
import { printPage } from '../utils/printHelper';
import React from 'react';
import { useApp } from '../context/AppContext';
import { DispatchRecord } from '../types';
import { Truck, Printer, X, Download, Loader2 } from 'lucide-react';
import { formatBsDateNepaliText, formatCurrency } from '../utils/nepaliCalendar';
import { downloadElementAsPdf } from '../utils/pdfHelper';
import { PaperSizeToggle } from './PaperSizeToggle';

interface ChallanPrintModalProps {
  dispatch: DispatchRecord;
  onClose: () => void;
}

export const ChallanPrintModal: React.FC<ChallanPrintModalProps> = ({ dispatch, onClose }) => {
  const { company, language } = useApp();
  const isNe = language === 'ne';
  const [isGeneratingPdf, setIsGeneratingPdf] = React.useState(false);

  const handleDownloadPdf = async () => {
    try {
      setIsGeneratingPdf(true);
      await downloadElementAsPdf({
        elementId: 'printable-challan',
        fileName: `Challan_${dispatch.challanNo}.pdf`,
        format: 'a4',
        onProgress: setIsGeneratingPdf
      });
    } catch (err) {
      console.error('PDF export failed', err);
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[95vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black">{isNe ? 'ढुवानी चलानी (Delivery Challan)' : 'Delivery Challan'}</h3>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{dispatch.challanNo}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <PaperSizeToggle />
            <InvoicePrintOptions storageKey="challan" features={{ copies: true, twoUp: true }} />
            <button
              onClick={() => printPage(printArgsFor('challan', { features: { copies: true } }))}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition"
            >
              <Printer className="w-5 h-5" />
            </button>
            <button
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition disabled:opacity-50"
            >
              {isGeneratingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              <span>{isNe ? 'PDF डाउनलोड' : 'Download PDF'}</span>
            </button>
            <button onClick={onClose} className="p-2 text-slate-400 hover:text-white transition">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto bg-slate-100 p-4 sm:p-8 print:p-0 print:bg-white">
          <div id="printable-challan" className="bg-white p-10 rounded-lg shadow-sm border border-slate-200 min-h-full max-w-[210mm] mx-auto print:shadow-none print:border-none">
            {/* Company Header */}
            <div className="border-b-2 border-slate-900 pb-6 mb-8 flex justify-between items-start">
              <div className="space-y-1">
                <h1 className="text-3xl font-black text-slate-900">{company.name}</h1>
                <p className="text-base font-bold text-slate-700">{company.address}</p>
                <p className="text-sm font-medium text-slate-500">
                  PAN/VAT No: <span className="font-mono font-bold text-slate-900">{company.panVatNo}</span>
                </p>
                <p className="text-sm font-medium text-slate-500">
                  Phone: <span className="font-bold text-slate-900">{company.phone}</span> | Email: {company.email || '-'}
                </p>
              </div>
              <div className="text-right">
                <div className="bg-slate-900 text-white px-5 py-2 rounded text-xs font-black uppercase tracking-[0.2em] mb-4 inline-block">
                  {isNe ? 'ढुवानी चलानी' : 'DELIVERY CHALLAN'}
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-bold text-slate-900">{isNe ? 'चलानी नं:' : 'Challan No:'} <span className="font-mono">{dispatch.challanNo}</span></p>
                  <p className="text-sm font-bold text-slate-900">{isNe ? 'मिति:' : 'Date:'} <span className="font-mono">{dispatch.dispatchDateBs}</span></p>
                </div>
              </div>
            </div>

            {/* Party & Vehicle Info */}
            <div className="grid grid-cols-2 gap-12 mb-8">
              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-1">{isNe ? 'चलानी पठाइएको (Consignee)' : 'SHIP TO'}</h4>
                <div className="space-y-1">
                  <p className="text-xl font-black text-slate-900">{dispatch.dealerName}</p>
                  <p className="text-sm font-bold text-slate-600">{dispatch.address || '-'}</p>
                  <p className="text-sm font-bold text-slate-600">{isNe ? 'फोन:' : 'Phone:'} {dispatch.phone || '-'}</p>
                </div>
              </div>
              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-1">{isNe ? 'ढुवानी विवरण (Logistics)' : 'LOGISTICS INFO'}</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-[9px] font-bold text-slate-400 uppercase">{isNe ? 'गाडी नम्बर' : 'Vehicle No'}</p>
                    <p className="text-sm font-black text-slate-900 font-mono uppercase">{dispatch.vehicleNo || '-'}</p>
                  </div>
                  <div>
                    <p className="text-[9px] font-bold text-slate-400 uppercase">{isNe ? 'ड्राइभर' : 'Driver'}</p>
                    <p className="text-sm font-black text-slate-900">{dispatch.driverName || '-'}</p>
                  </div>
                  <div>
                    <p className="text-[9px] font-bold text-slate-400 uppercase">{isNe ? 'स्थिति' : 'Status'}</p>
                    <p className="text-xs font-black text-emerald-700 uppercase">{dispatch.status}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Items Table */}
            <table className="w-full border-collapse border-2 border-slate-900 text-xs mb-8">
              <thead>
                <tr className="bg-slate-100 border-b-2 border-slate-900 font-black">
                  <th className="border border-slate-900 px-3 py-3 text-center w-12">S.N.</th>
                  <th className="border border-slate-900 px-3 py-3 text-left">{isNe ? 'सामानको विवरण (Description)' : 'Description of Goods'}</th>
                  <th className="border border-slate-900 px-3 py-3 text-center w-24">{isNe ? 'परिमाण (Qty)' : 'Quantity'}</th>
                </tr>
              </thead>
              <tbody>
                {dispatch.items.map((item, idx) => (
                  <tr key={idx} className="border-b border-slate-900">
                    <td className="border border-slate-900 px-3 py-3 text-center font-mono font-bold text-slate-500">{idx + 1}</td>
                    <td className="border border-slate-900 px-3 py-3">
                      <div className="flex flex-col">
                        {item.hsCode && (
                          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">
                            HS CODE: {item.hsCode}
                          </span>
                        )}
                        <span className="font-black text-slate-900">{item.particular}</span>
                      </div>
                    </td>
                    <td className="border border-slate-900 px-3 py-3 text-center font-mono font-black text-slate-900 text-base">{item.qty}</td>
                  </tr>
                ))}
                {/* Empty rows to fill space */}
                {Array.from({ length: Math.max(0, 8 - dispatch.items.length) }).map((_, i) => (
                  <tr key={`empty-${i}`} className="border-b border-slate-900 h-12">
                    <td className="border border-slate-900 px-3"></td>
                    <td className="border border-slate-900 px-3"></td>
                    <td className="border border-slate-900 px-3"></td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-50 font-black">
                  <td className="border border-slate-900 px-3 py-4 text-right" colSpan={3}>
                    {isNe ? 'कुल जम्मा परिमाण (Total Quantity):' : 'Total Dispatched Quantity:'}
                  </td>
                  <td className="border border-slate-900 px-3 py-4 text-center font-mono text-xl">
                    {dispatch.items.reduce((sum, item) => sum + item.qty, 0)}
                  </td>
                </tr>
              </tfoot>
            </table>

            {/* Notes */}
            {dispatch.notes && (
              <div className="mb-10 p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{isNe ? 'कैफियत (Notes)' : 'NOTES'}</h4>
                <p className="text-xs text-slate-700 font-medium">{dispatch.notes}</p>
              </div>
            )}

            {/* Signatures */}
            <div className="mt-20 grid grid-cols-3 gap-8 text-center text-xs font-black text-slate-700">
              <div className="space-y-2">
                <div className="border-t-2 border-slate-900 pt-3">
                  {isNe ? 'बुझिलिनेको हस्ताक्षर' : 'Receiver\'s Signature'}
                </div>
                <p className="text-[9px] text-slate-400 font-normal">Date & Time</p>
              </div>
              <div className="space-y-2">
                <div className="border-t-2 border-slate-900 pt-3">
                  {isNe ? 'गाडी चालकको हस्ताक्षर' : 'Driver\'s Signature'}
                </div>
                <p className="text-[9px] text-slate-400 font-normal">{dispatch.driverName || 'Driver'}</p>
              </div>
              <div className="space-y-2">
                <div className="border-t-2 border-slate-900 pt-3">
                  {isNe ? 'अधिकृत हस्ताक्षर' : 'Authorized Signature'}
                </div>
                <p className="text-[9px] text-slate-400 font-normal">{company.name}</p>
              </div>
            </div>

            {/* Footer Disclaimer */}
            <div className="mt-12 text-center text-[10px] text-slate-400 font-medium">
              This is a computer-generated delivery challan for KrishiYantra Agri & Machinery Center.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
