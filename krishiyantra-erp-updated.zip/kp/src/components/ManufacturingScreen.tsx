import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { RawMaterial, ProductionBatch, ProductionStage, RawMaterialUsage } from '../types';
import {
  Factory,
  Boxes,
  Cpu,
  PackageCheck,
  PackageOpen,
  Truck,
  Plus,
  Edit2,
  Trash2,
  Search,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  User,
  Calendar,
  DollarSign,
  Layers,
  Sparkles,
  X,
  FileText,
  Printer,
  Download,
  Table,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Scale,
  ClipboardList
} from 'lucide-react';
import { formatCurrency, getTodayBsString, toNepaliDigits } from '../utils/nepaliCalendar';
import { exportReportToExcel, printOrDownloadReportPdf } from '../utils/pdfReportExporter';
import { ProductionBatchModal } from './ProductionBatchModal';
import { ProductionPassportModal } from './ProductionPassportModal';
import { ProductionReportsView } from './ProductionReportsView';
import { MachinesManagementScreen } from './MachinesManagementScreen';
import { BomManagementScreen } from './BomManagementScreen';
import { ProductionPlanningScreen } from './ProductionPlanningScreen';

export const ManufacturingScreen: React.FC = () => {
  const {
    rawMaterials,
    saveRawMaterial,
    deleteRawMaterial,
    productionBatches,
    saveProductionBatch,
    deleteProductionBatch,
    updateBatchStage,
    recordDispatch,
    updateDispatchStatus,
    employees,
    company,
    manufacturingSubTab,
    setManufacturingSubTab,
    language,
    machines,
    items
  } = useApp();

  const isNe = language === 'ne';
  const [toastMsg, setToastMsg] = useState('');
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 4000);
  };

  // Active Sub-Tab
  const [activeTab, setActiveTab] = useState<
    'OVERVIEW' | 'BATCHES' | 'RAW_MATERIALS' | 'WIP_MACHINE' | 'FINISHED_GOODS' | 'PACKAGING' | 'DISPATCHED' | 'MACHINES' | 'REPORTS' | 'BOM' | 'PLANNING'
  >(manufacturingSubTab || 'OVERVIEW');

  React.useEffect(() => {
    if (manufacturingSubTab) {
      setActiveTab(manufacturingSubTab as any);
    }
  }, [manufacturingSubTab]);

  // Search & Filters for All Batches table
  const [searchTerm, setSearchTerm] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('ALL');
  const [qcFilter, setQcFilter] = useState<string>('ALL');

  // Selected Batch for Passport Modal
  const [selectedBatchForPassport, setSelectedBatchForPassport] = useState<ProductionBatch | null>(null);

  // 1. Add / Edit Raw Material Modal State
  const [isRmModalOpen, setIsRmModalOpen] = useState(false);
  const [editingRm, setEditingRm] = useState<RawMaterial | null>(null);
  const [rmCode, setRmCode] = useState('');
  const [rmNameNe, setRmNameNe] = useState('');
  const [rmNameEn, setRmNameEn] = useState('');
  const [rmCategory, setRmCategory] = useState('STEEL_METALS');
  const [rmUnit, setRmUnit] = useState('Kg');
  const [rmStock, setRmStock] = useState<number>(100);
  const [rmCost, setRmCost] = useState<number>(100);
  const [rmMinAlert, setRmMinAlert] = useState<number>(20);
  const [rmSupplier, setRmSupplier] = useState('');

  // 2. Production Batch Modal State (New Batch)
  const [isBatchModalOpen, setIsBatchModalOpen] = useState(false);

  // 3. Move to Finished Goods Modal
  const [finishingBatch, setFinishingBatch] = useState<ProductionBatch | null>(null);
  const [fgQuantity, setFgQuantity] = useState<number>(10);
  const [wastagePercent, setWastagePercent] = useState<number>(0);
  const [overheadCosts, setOverheadCosts] = useState<{description: string; amount: number}[]>([]);

  // 4. Move to Packaging Modal
  const [packagingBatch, setPackagingBatch] = useState<ProductionBatch | null>(null);
  const [pkgType, setPkgType] = useState('काठको भारी प्याकिङ बाकस (Heavy Wooden Crate)');

  // 5. Dispatch to Market Modal
  const [dispatchBatch, setDispatchBatch] = useState<ProductionBatch | null>(null);
  const [dealerName, setDealerName] = useState('');
  const [dealerAddress, setDealerAddress] = useState('');
  const [dealerPhone, setDealerPhone] = useState('');
  const [dispatchQty, setDispatchQty] = useState<number>(1);
  const [vehicleNo, setVehicleNo] = useState('');
  const [driverName, setDriverName] = useState('');
  const [dispatchNotes, setDispatchNotes] = useState('');

  // Stage Pipeline Counts
  const wipBatches = productionBatches.filter((b) => b.stage === 'IN_MACHINE_WIP');
  const fgBatches = productionBatches.filter((b) => b.stage === 'FINISHED_GOODS');
  const pkgBatches = productionBatches.filter((b) => b.stage === 'PACKAGING');
  const dispatchedBatches = productionBatches.filter((b) => b.stage === 'DISPATCHED_MARKET');

  const totalRawMaterialValuation = rawMaterials.reduce(
    (sum, r) => sum + r.currentStock * r.unitCostPrice,
    0
  );

  // Dashboard KPI Calculations
  const todayBs = getTodayBsString();
  const currentMonthBs = todayBs.slice(0, 7);

  const todayBatches = productionBatches.filter(
    (b) => (b.productionDateBs && b.productionDateBs === todayBs) || b.startedDateBs === todayBs
  );
  const todayOutputQty = todayBatches.reduce(
    (sum, b) => sum + (b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0),
    0
  );

  const monthBatches = productionBatches.filter(
    (b) =>
      (b.productionDateBs && b.productionDateBs.startsWith(currentMonthBs)) ||
      (b.startedDateBs && b.startedDateBs.startsWith(currentMonthBs))
  );
  const monthOutputQty = monthBatches.reduce(
    (sum, b) => sum + (b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0),
    0
  );

  const batchesWithYield = productionBatches.filter((b) => typeof b.yieldPercent === 'number' && b.yieldPercent > 0);
  const averageYieldPercent =
    batchesWithYield.length > 0
      ? (batchesWithYield.reduce((sum, b) => sum + (b.yieldPercent || 0), 0) / batchesWithYield.length).toFixed(1)
      : '95.0';

  const batchesWithWastage = productionBatches.filter((b) => typeof b.wastagePercent === 'number');
  const averageWastagePercent =
    batchesWithWastage.length > 0
      ? (batchesWithWastage.reduce((sum, b) => sum + (b.wastagePercent || 0), 0) / batchesWithWastage.length).toFixed(1)
      : '5.0';

  // Open Add RM Modal
  const handleOpenAddRm = () => {
    setEditingRm(null);
    setRmCode(`RM-${Date.now().toString().slice(-4)}`);
    setRmNameNe('');
    setRmNameEn('');
    setRmCategory('STEEL_METALS');
    setRmUnit('Kg');
    setRmStock(100);
    setRmCost(150);
    setRmMinAlert(20);
    setRmSupplier('');
    setIsRmModalOpen(true);
  };

  // Open Edit RM Modal
  const handleOpenEditRm = (rm: RawMaterial) => {
    setEditingRm(rm);
    setRmCode(rm.code);
    setRmNameNe(rm.nameNe);
    setRmNameEn(rm.nameEn);
    setRmCategory(rm.category);
    setRmUnit(rm.unit);
    setRmStock(rm.currentStock);
    setRmCost(rm.unitCostPrice);
    setRmMinAlert(rm.minStockAlert);
    setRmSupplier(rm.supplierName || '');
    setIsRmModalOpen(true);
  };

  // Save Raw Material
  const handleSaveRmSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rmNameNe.trim()) {
      showToast(isNe ? 'कृपया कच्चा पदार्थको नेपाली नाम प्रविष्ट गर्नुहोस्।' : 'Please enter material name.');
      return;
    }

    const rm: RawMaterial = {
      id: editingRm ? editingRm.id : `rm-${Date.now()}`,
      code: rmCode,
      nameNe: rmNameNe.trim(),
      nameEn: rmNameEn.trim() || rmNameNe.trim(),
      category: rmCategory,
      unit: rmUnit,
      currentStock: rmStock,
      unitCostPrice: rmCost,
      minStockAlert: rmMinAlert,
      supplierName: rmSupplier.trim(),
      lastPurchasedDateBs: getTodayBsString()
    };

    saveRawMaterial(rm);
    setIsRmModalOpen(false);
    showToast(isNe ? 'कच्चा पदार्थ विवरण सुरक्षित भयो!' : 'Raw Material saved!');
  };

  // Callback when ProductionBatchModal creates a batch
  const handleBatchCreated = (newBatch: ProductionBatch) => {
    saveProductionBatch(newBatch);
    setIsBatchModalOpen(false);
    showToast(
      newBatch.stage === 'FINISHED_GOODS'
        ? (isNe
            ? `ब्याच ${newBatch.batchNumber} तयारी सामानमा दाखिला भई मौज्दात स्वतः अपडेट भयो!`
            : `Batch ${newBatch.batchNumber} saved and synchronized with finished goods inventory!`)
        : (isNe
            ? `ब्याच ${newBatch.batchNumber} मेसिनमा लोड भई उत्पादन प्रक्रिया (WIP) सुरु भयो!`
            : `Batch ${newBatch.batchNumber} started in machine (WIP)!`)
    );
  };

  // Submit Move to Finished Goods
  const handleFinishBatchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!finishingBatch) return;

    const totalRmCost = finishingBatch.rawMaterialsUsed.reduce(
      (sum, u) => sum + u.quantityUsed * u.costPerUnit,
      0
    );
    const totalOverhead = overheadCosts.reduce((sum, o) => sum + o.amount, 0);
    const totalProductionCost = totalRmCost + totalOverhead;
    
    // Adjust for wastage: effective quantity reduced by wastage %
    const effectiveQty = fgQuantity * (1 - wastagePercent / 100);
    const unitMfgCost = effectiveQty > 0 ? Math.round(totalProductionCost / effectiveQty) : totalProductionCost;

    updateBatchStage(finishingBatch.id, 'FINISHED_GOODS', {
      finishedGoodsQuantity: fgQuantity,
      completionDateBs: getTodayBsString(),
      totalProductionCost: totalProductionCost,
      unitManufacturingCost: unitMfgCost,
      wastagePercent,
      overheadCosts,
      productionDateBs: getTodayBsString(),
      expiryDateBs: getTodayBsString() // Simple default for now
    });

    setFinishingBatch(null);
    setOverheadCosts([]);
    setWastagePercent(0);
    showToast(isNe ? 'सामान तयारी अवस्था (Finished Goods) र स्टकमा सरेको छ!' : 'Batch moved to Finished Goods!');
  };

  // Submit Move to Packaging
  const handlePackagingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!packagingBatch) return;

    updateBatchStage(packagingBatch.id, 'PACKAGING', {
      packagingType: pkgType,
      packedQuantity: packagingBatch.finishedGoodsQuantity || packagingBatch.targetQuantity,
      packedDateBs: getTodayBsString()
    });

    setPackagingBatch(null);
    showToast(isNe ? 'सामान प्याकिङ (Packaging) मा दाखिला भयो!' : 'Moved to Packaging!');
  };

  // Submit Dispatch to Market
  const handleDispatchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dispatchBatch || !dealerName.trim()) {
      showToast(isNe ? 'कृपया ग्राहक / डिलरको नाम लेख्नुहोस्।' : 'Please enter dealer name.');
      return;
    }

    recordDispatch(dispatchBatch.id, {
      challanNo: `CH-MFG-${Date.now().toString().slice(-6)}`,
      type: 'SALES',
      dealerName: dealerName.trim(),
      address: dealerAddress.trim(),
      phone: dealerPhone.trim(),
      items: [
        {
          id: `di-${Date.now()}`,
          sn: 1,
          particular: isNe ? dispatchBatch.productNameNe : dispatchBatch.productNameEn,
          qty: dispatchQty,
          rate: 0,
          total: 0
        }
      ],
      dispatchedQuantity: dispatchQty,
      dispatchDateBs: getTodayBsString(),
      vehicleNo: vehicleNo.trim(),
      driverName: driverName.trim(),
      notes: dispatchNotes.trim(),
      status: 'IN_TRANSIT'
    });

    setDispatchBatch(null);
    showToast(isNe ? 'सामान बजारमा रवाना (Dispatched) गरियो!' : 'Dispatched to Market!');
  };

  return (
    <div className="space-y-6 pb-16 max-w-7xl mx-auto">
      
      {/* Title & Pipeline Nav Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 text-white p-5 rounded-2xl shadow-md border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/30">
            <Factory className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
              <span>{isNe ? 'म्यानुफ्याक्चरिङ तथा उत्पादन व्यवस्थापन' : 'Manufacturing & Production System'}</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              {isNe
                ? 'कच्चा पदार्थ खरिद, मेसिनमा रहेको (WIP), तयारी सामान, प्याकिङ र बजार आपूर्ति ट्र्याकिङ'
                : 'Complete Production Lifecycle: Raw Materials -> WIP Machines -> Finished Goods -> Packaging -> Dispatched Market'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setActiveTab('OVERVIEW')}
            className={`px-3 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-xs ${
              activeTab === 'OVERVIEW'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{isNe ? 'सबै चरण (Pipeline)' : 'All Pipeline'}</span>
          </button>

          <button
            onClick={() => setActiveTab('PLANNING')}
            className={`px-3 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-xs ${
              activeTab === 'PLANNING'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
            }`}
          >
            <ClipboardList className="w-4 h-4" />
            <span>{isNe ? 'उत्पादन योजना / आदेश' : 'Planning & Orders'}</span>
          </button>

          <button
            onClick={() => setActiveTab('BOM')}
            className={`px-3 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-xs ${
              activeTab === 'BOM'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
            }`}
          >
            <Scale className="w-4 h-4" />
            <span>{isNe ? 'उत्पादन सूत्र (BOM)' : 'BOM / Recipe'}</span>
          </button>

          <button
            onClick={() => setActiveTab('BATCHES')}
            className={`px-3 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-xs ${
              activeTab === 'BATCHES'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
            }`}
          >
            <Table className="w-4 h-4" />
            <span>{isNe ? 'ब्याच सूची (All Batches)' : 'All Batches'}</span>
          </button>

          <button
            onClick={() => setActiveTab('MACHINES')}
            className={`px-3 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-xs ${
              activeTab === 'MACHINES'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
            }`}
          >
            <Factory className="w-4 h-4" />
            <span>{isNe ? 'मेसिनहरू (Machines)' : 'Machines'}</span>
          </button>

          <button
            onClick={() => setActiveTab('REPORTS')}
            className={`px-3 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-xs ${
              activeTab === 'REPORTS'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{isNe ? 'उत्पादन प्रतिवेदन (Reports)' : 'Production Reports'}</span>
          </button>

          <button
            onClick={handleOpenAddRm}
            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-xs"
          >
            <Boxes className="w-4 h-4" />
            <span>{isNe ? '+ कच्चा पदार्थ' : '+ Add RM'}</span>
          </button>

          <button
            onClick={() => setIsBatchModalOpen(true)}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-xs"
          >
            <Cpu className="w-4 h-4 text-amber-300" />
            <span>{isNe ? '⚙️ नयाँ उत्पादन ब्याच (+ New Batch)' : '+ New Production Batch'}</span>
          </button>

          <button
            onClick={() =>
              printOrDownloadReportPdf(
                {
                  title: 'म्यानुफ्याक्चरिङ तथा उत्पादन विवरण (Manufacturing & Production Report)',
                  headers: ['ब्याच नं.', 'उत्पादन नाम', 'चरण (Stage)', 'लक्ष्य परिमाण', 'तयारी परिमाण', 'मेसिन', 'अपरेटर', 'सुरु मिति', 'कुल लागत'],
                  rows: productionBatches.map((b) => [
                    b.batchNumber,
                    b.productNameNe || b.productNameEn,
                    b.stage,
                    b.targetQuantity,
                    b.finishedGoodsQuantity || 0,
                    b.machineName || '-',
                    b.operatorName || '-',
                    b.startedDateBs,
                    b.totalProductionCost || 0
                  ]),
                  company,
                  fileName: 'Manufacturing_Production_Report'
                },
                'DOWNLOAD_PDF'
              )
            }
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1 border border-slate-700 shadow-xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>PDF प्रिन्ट</span>
          </button>
        </div>
      </div>

      {toastMsg && (
        <div className="bg-emerald-900 text-white px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-2 shadow-md">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DASHBOARD CARDS: TODAY, MONTH, YIELD %, WASTAGE %, RAW MATERIAL VALUATION */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {/* Card 1: Today's Production */}
        <div className="p-4 bg-gradient-to-br from-purple-900 to-indigo-900 text-white rounded-2xl shadow-sm border border-purple-800">
          <div className="flex items-center justify-between text-purple-200">
            <span className="text-[10px] uppercase font-bold tracking-wider">आजको उत्पादन</span>
            <Calendar className="w-4 h-4 text-purple-300" />
          </div>
          <div className="text-xl sm:text-2xl font-black font-mono text-white mt-1">
            {toNepaliDigits(todayOutputQty)} <span className="text-xs font-normal text-purple-200">थान/Kg</span>
          </div>
          <div className="text-[10px] text-purple-300 mt-1">
            आज मिति: {todayBs} ({toNepaliDigits(todayBatches.length)} ब्याच)
          </div>
        </div>

        {/* Card 2: This Month's Total Output */}
        <div className="p-4 bg-gradient-to-br from-blue-900 to-cyan-950 text-white rounded-2xl shadow-sm border border-blue-800">
          <div className="flex items-center justify-between text-blue-200">
            <span className="text-[10px] uppercase font-bold tracking-wider">यो महिनाको उत्पादन</span>
            <TrendingUp className="w-4 h-4 text-cyan-300" />
          </div>
          <div className="text-xl sm:text-2xl font-black font-mono text-white mt-1">
            {toNepaliDigits(monthOutputQty)} <span className="text-xs font-normal text-cyan-200">थान/Kg</span>
          </div>
          <div className="text-[10px] text-blue-300 mt-1">
            {currentMonthBs} महिनाभर ({toNepaliDigits(monthBatches.length)} ब्याच)
          </div>
        </div>

        {/* Card 3: Average Yield % */}
        <div className="p-4 bg-gradient-to-br from-emerald-900 to-teal-950 text-white rounded-2xl shadow-sm border border-emerald-800">
          <div className="flex items-center justify-between text-emerald-200">
            <span className="text-[10px] uppercase font-bold tracking-wider">औसत उत्पादन प्राप्ति</span>
            <Scale className="w-4 h-4 text-emerald-300" />
          </div>
          <div className="text-xl sm:text-2xl font-black font-mono text-emerald-200 mt-1">
            {toNepaliDigits(averageYieldPercent)}%
          </div>
          <div className="text-[10px] text-emerald-400 mt-1">
            औसत Yield (तयारी ÷ कच्चा इनपुट)
          </div>
        </div>

        {/* Card 4: Average Wastage % */}
        <div className="p-4 bg-gradient-to-br from-amber-900 to-orange-950 text-white rounded-2xl shadow-sm border border-amber-800">
          <div className="flex items-center justify-between text-amber-200">
            <span className="text-[10px] uppercase font-bold tracking-wider">औसत तौल ह्रास / वेस्टेज</span>
            <TrendingDown className="w-4 h-4 text-amber-300" />
          </div>
          <div className="text-xl sm:text-2xl font-black font-mono text-amber-200 mt-1">
            {toNepaliDigits(averageWastagePercent)}%
          </div>
          <div className="text-[10px] text-amber-300 mt-1">
            मोइस्चर लस र स्वाभाविक ह्रास
          </div>
        </div>

        {/* Card 5: Raw Materials Valuation */}
        <div className="p-4 bg-white rounded-2xl shadow-sm border border-slate-200 text-slate-800">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] uppercase font-bold tracking-wider">कच्चा पदार्थ मौज्दात</span>
            <Boxes className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-lg sm:text-xl font-black font-mono text-emerald-800 mt-1">
            {formatCurrency(totalRawMaterialValuation, isNe)}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            {toNepaliDigits(rawMaterials.length)} प्रकारका कच्चा पदार्थ
          </div>
        </div>
      </div>

      {/* Production Lifecycle 5-Stage Pipeline Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {/* Stage 1: Raw Materials */}
        <button
          onClick={() => setActiveTab('RAW_MATERIALS')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer space-y-1 ${
            activeTab === 'RAW_MATERIALS' ? 'bg-emerald-900 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500' : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <Boxes className={`w-5 h-5 ${activeTab === 'RAW_MATERIALS' ? 'text-emerald-300' : 'text-emerald-600'}`} />
            <span className="font-mono text-xs font-black px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-700">
              {toNepaliDigits(rawMaterials.length)}
            </span>
          </div>
          <div className="text-xs font-bold">
            {isNe ? '१. कच्चा पदार्थ (Raw)' : '1. Raw Materials'}
          </div>
          <div className="text-[10px] opacity-80 font-mono">
            {formatCurrency(totalRawMaterialValuation, isNe)}
          </div>
        </button>

        {/* Stage 2: Machine WIP */}
        <button
          onClick={() => setActiveTab('WIP_MACHINE')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer space-y-1 ${
            activeTab === 'WIP_MACHINE' ? 'bg-purple-900 text-white border-purple-700 shadow-md ring-2 ring-purple-500' : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <Cpu className={`w-5 h-5 ${activeTab === 'WIP_MACHINE' ? 'text-purple-300' : 'text-purple-600'}`} />
            <span className="font-mono text-xs font-black px-2 py-0.5 rounded bg-purple-500/20 text-purple-700">
              {toNepaliDigits(wipBatches.length)}
            </span>
          </div>
          <div className="text-xs font-bold">
            {isNe ? '२. मेसिनमा रहेको (WIP)' : '2. Machine WIP'}
          </div>
          <div className="text-[10px] opacity-80">
            {isNe ? 'उत्पादन प्रक्रियामा' : 'In Processing'}
          </div>
        </button>

        {/* Stage 3: Finished Goods */}
        <button
          onClick={() => setActiveTab('FINISHED_GOODS')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer space-y-1 ${
            activeTab === 'FINISHED_GOODS' ? 'bg-blue-900 text-white border-blue-700 shadow-md ring-2 ring-blue-500' : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <PackageCheck className={`w-5 h-5 ${activeTab === 'FINISHED_GOODS' ? 'text-blue-300' : 'text-blue-600'}`} />
            <span className="font-mono text-xs font-black px-2 py-0.5 rounded bg-blue-500/20 text-blue-700">
              {toNepaliDigits(fgBatches.length)}
            </span>
          </div>
          <div className="text-xs font-bold">
            {isNe ? '३. तयारी सामान (FG)' : '3. Finished Goods'}
          </div>
          <div className="text-[10px] opacity-80">
            {isNe ? 'तयारी मौज्दात' : 'Ready Stock'}
          </div>
        </button>

        {/* Stage 4: Packaging */}
        <button
          onClick={() => setActiveTab('PACKAGING')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer space-y-1 ${
            activeTab === 'PACKAGING' ? 'bg-amber-900 text-white border-amber-700 shadow-md ring-2 ring-amber-500' : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <PackageOpen className={`w-5 h-5 ${activeTab === 'PACKAGING' ? 'text-amber-300' : 'text-amber-600'}`} />
            <span className="font-mono text-xs font-black px-2 py-0.5 rounded bg-amber-500/20 text-amber-700">
              {toNepaliDigits(pkgBatches.length)}
            </span>
          </div>
          <div className="text-xs font-bold">
            {isNe ? '४. हाल प्याकिङ सामान' : '4. Packaging Stock'}
          </div>
          <div className="text-[10px] opacity-80">
            {isNe ? 'प्याकिङ बाकस' : 'In Packaging'}
          </div>
        </button>

        {/* Stage 5: Dispatched Market */}
        <button
          onClick={() => setActiveTab('DISPATCHED')}
          className={`p-3.5 rounded-2xl border text-left transition cursor-pointer space-y-1 ${
            activeTab === 'DISPATCHED' ? 'bg-indigo-900 text-white border-indigo-700 shadow-md ring-2 ring-indigo-500' : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <Truck className={`w-5 h-5 ${activeTab === 'DISPATCHED' ? 'text-indigo-300' : 'text-indigo-600'}`} />
            <span className="font-mono text-xs font-black px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-700">
              {toNepaliDigits(dispatchedBatches.length)}
            </span>
          </div>
          <div className="text-xs font-bold">
            {isNe ? '५. बजारमा पठाइएको' : '5. Dispatched Market'}
          </div>
          <div className="text-[10px] opacity-80">
            {isNe ? 'डिलर/आपूर्ति' : 'Market Supply'}
          </div>
        </button>
      </div>

      {/* Main Content Area Based on Active Tab */}
      
      {/* ========================================================================= */}
      {/* TAB: ALL PRODUCTION BATCHES TABLE VIEW (SEARCH / FILTER / PASSPORT)       */}
      {/* ========================================================================= */}
      {activeTab === 'BATCHES' && (
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Table className="w-5 h-5 text-purple-700" />
                <span>{isNe ? 'सबै उत्पादन ब्याचहरूको विस्तृत तालिका (Production Batches Master)' : 'Production Batches Master Registry'}</span>
              </h2>
              <p className="text-xs text-slate-500">
                {isNe
                  ? 'प्रत्येक ब्याचको इनपुट-आउटपुट तौल, प्राप्ति %, तौल ह्रास %, प्रति एकाइ लागत र गुणस्तर'
                  : 'Complete batch tracking with BOM weights, yield/wastage %, per-unit cost, QC status & passport'}
              </p>
            </div>

            <button
              onClick={() => setIsBatchModalOpen(true)}
              className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>{isNe ? '+ नयाँ ब्याच प्रविष्टि (+ New Batch)' : '+ New Production Batch'}</span>
            </button>
          </div>

          {/* Search & Filter Toolbar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ब्याच नं., सामानको नाम वा अपरेटर खोज्नुहोस्..."
                className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap text-xs">
              <div className="flex items-center gap-1">
                <span className="font-bold text-slate-600">चरण (Stage):</span>
                <select
                  value={stageFilter}
                  onChange={(e) => setStageFilter(e.target.value)}
                  className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-xl font-medium"
                >
                  <option value="ALL">सबै चरण (All Stages)</option>
                  <option value="IN_MACHINE_WIP">मेसिनमा रहेको (WIP)</option>
                  <option value="FINISHED_GOODS">तयारी सामान (Finished Goods)</option>
                  <option value="PACKAGING">प्याकिङ शाखा (Packaging)</option>
                  <option value="DISPATCHED_MARKET">बजार आपूर्ति (Dispatched)</option>
                </select>
              </div>

              <div className="flex items-center gap-1">
                <span className="font-bold text-slate-600">गुणस्तर (QC):</span>
                <select
                  value={qcFilter}
                  onChange={(e) => setQcFilter(e.target.value)}
                  className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-xl font-medium"
                >
                  <option value="ALL">सबै स्थिति (All QC)</option>
                  <option value="PASS">✓ पास (Passed)</option>
                  <option value="PENDING">⏳ परीक्षण बाँकी (Pending)</option>
                  <option value="FAIL">✕ फेल (Failed)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Batches Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-900 text-white font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-3">ब्याच नं.</th>
                  <th className="py-3 px-3">उत्पादन मिति</th>
                  <th className="py-3 px-3">उत्पादित सामान</th>
                  <th className="py-3 px-3 text-center">चरण</th>
                  <th className="py-3 px-3 text-right">इनपुट तौल</th>
                  <th className="py-3 px-3 text-right">आउटपुट</th>
                  <th className="py-3 px-3 text-center">Yield %</th>
                  <th className="py-3 px-3 text-center">Wastage %</th>
                  <th className="py-3 px-3 text-right">कुल लागत</th>
                  <th className="py-3 px-3 text-right">प्रति एकाइ</th>
                  <th className="py-3 px-3 text-center">QC</th>
                  <th className="py-3 px-3 text-center">कार्य</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {productionBatches
                  .filter((b) => {
                    if (stageFilter !== 'ALL' && b.stage !== stageFilter) return false;
                    if (qcFilter !== 'ALL' && (b.qualityCheckStatus || 'PASS') !== qcFilter) return false;
                    if (searchTerm) {
                      const q = searchTerm.toLowerCase();
                      const str = `${b.batchNumber} ${b.productNameNe} ${b.productNameEn || ''} ${b.operatorName || ''}`.toLowerCase();
                      if (!str.includes(q)) return false;
                    }
                    return true;
                  })
                  .map((b) => {
                    const inQ = b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0);
                    const outQ = b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0;
                    const yPct = typeof b.yieldPercent === 'number' ? b.yieldPercent : inQ > 0 ? Math.round((outQ / inQ) * 1000) / 10 : 100;
                    const wPct = typeof b.wastagePercent === 'number' ? b.wastagePercent : Math.max(0, 100 - yPct);

                    return (
                      <tr key={b.id} className="hover:bg-slate-50 transition">
                        <td className="py-3 px-3 font-mono font-black text-purple-900">
                          {b.batchNumber}
                        </td>
                        <td className="py-3 px-3 font-mono text-slate-700 whitespace-nowrap">
                          {b.productionDateBs || b.startedDateBs}
                          {b.productionDateAd ? <span className="block text-[10px] text-slate-400 font-normal">{b.productionDateAd}</span> : null}
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-bold text-slate-900">{b.productNameNe}</div>
                          {b.packetSize ? (
                            <span className="text-[10px] text-slate-500 font-mono">
                              प्याकेट: {b.packetSize} ({b.packetsProduced || outQ} पाउच)
                            </span>
                          ) : null}
                        </td>
                        <td className="py-3 px-3 text-center whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            b.stage === 'IN_MACHINE_WIP'
                              ? 'bg-purple-100 text-purple-900'
                              : b.stage === 'FINISHED_GOODS'
                              ? 'bg-blue-100 text-blue-900'
                              : b.stage === 'PACKAGING'
                              ? 'bg-amber-100 text-amber-900'
                              : 'bg-indigo-100 text-indigo-900'
                          }`}>
                            {b.stage === 'IN_MACHINE_WIP'
                              ? 'मेसिन (WIP)'
                              : b.stage === 'FINISHED_GOODS'
                              ? 'तयारी (FG)'
                              : b.stage === 'PACKAGING'
                              ? 'प्याकिङ'
                              : 'बजार रवाना'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-700">
                          {toNepaliDigits(inQ)} {b.inputUnit || 'Kg'}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-blue-800">
                          {toNepaliDigits(outQ)} {b.outputUnit || 'Kg'}
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-black text-emerald-700">
                          {toNepaliDigits(yPct)}%
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-bold text-amber-700">
                          {toNepaliDigits(wPct)}%
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                          रु. {(b.totalProductionCost || 0).toLocaleString()}
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-purple-900">
                          रु. {(b.unitManufacturingCost || 0).toLocaleString()}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            b.qualityCheckStatus === 'PASS'
                              ? 'bg-emerald-100 text-emerald-800'
                              : b.qualityCheckStatus === 'PENDING'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {b.qualityCheckStatus === 'PASS' ? '✓ पास' : b.qualityCheckStatus === 'PENDING' ? '⏳ परीक्षण' : '✕ फेल'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => setSelectedBatchForPassport(b)}
                              className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-800 font-bold rounded-lg text-[10px] transition cursor-pointer border border-purple-200"
                              title="ब्याच पासपोर्ट तथा प्रिन्ट प्रमाणपत्र"
                            >
                              पासपोर्ट / प्रिन्ट
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteProductionBatch(b.id)}
                              className="p-1 text-slate-400 hover:text-red-600 rounded transition cursor-pointer"
                              title="ब्याच मेटाउनुहोस्"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB: PRODUCTION REPORTS (BATCH-WISE, DAILY/MONTHLY, WASTAGE, EXCEL/PDF)   */}
      {/* ========================================================================= */}
      {activeTab === 'REPORTS' && <ProductionReportsView />}

      {/* ========================================================================= */}
      {/* TAB: MACHINES MANAGEMENT SCREEN                                           */}
      {/* ========================================================================= */}
      {activeTab === 'MACHINES' && <MachinesManagementScreen />}
      {activeTab === 'BOM' && <BomManagementScreen />}
      {activeTab === 'PLANNING' && <ProductionPlanningScreen />}

      {/* ========================================================================= */}
      {/* TAB 1: OVERVIEW DASHBOARD & RAW MATERIALS                                 */}
      {/* ========================================================================= */}
      {(activeTab === 'OVERVIEW' || activeTab === 'RAW_MATERIALS') && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Boxes className="w-5 h-5 text-emerald-700" />
                <span>{isNe ? 'कच्चा पदार्थ खरिद तथा मौज्दात (Raw Materials Inventory)' : 'Raw Materials Purchase & Inventory'}</span>
              </h2>
              <p className="text-xs text-slate-500">
                {isNe ? 'म्यानुफ्याक्चरिङका लागि आवश्यक स्टिल, इन्जिन, पाइप, बेयरिङ, र प्याकिङ सामान' : 'Track raw metal sheets, engines, hardware parts, packaging boxes'}
              </p>
            </div>

            <button
              onClick={handleOpenAddRm}
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>{isNe ? '+ नयाँ कच्चा पदार्थ थप्नुहोस्' : '+ Add Raw Material'}</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-900 text-white font-bold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">कोड</th>
                  <th className="py-3 px-4">कच्चा पदार्थको नाम</th>
                  <th className="py-3 px-4">वर्ग</th>
                  <th className="py-3 px-4 text-right">प्रति एकाइ लागत मूल्य</th>
                  <th className="py-3 px-4 text-right">हालको मौज्दात</th>
                  <th className="py-3 px-4 text-right">कुल मौज्दात मूल्य</th>
                  <th className="py-3 px-4">मुख्य आपूर्तिकर्ता</th>
                  <th className="py-3 px-4 text-center">कार्य</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rawMaterials.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      कुनै पनि कच्चा पदार्थ दर्ता गरिएको छैन।
                    </td>
                  </tr>
                ) : (
                  rawMaterials.map((rm) => (
                    <tr key={rm.id} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-4 font-mono font-bold text-slate-700">{rm.code}</td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{rm.nameNe}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{rm.nameEn}</div>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-600">{rm.category}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-800">
                        {formatCurrency(rm.unitCostPrice, isNe)} / {rm.unit}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-black text-sm">
                        <span className={rm.currentStock <= rm.minStockAlert ? 'text-rose-700' : 'text-emerald-700'}>
                          {toNepaliDigits(rm.currentStock)} {rm.unit}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-black text-slate-900">
                        {formatCurrency(rm.currentStock * rm.unitCostPrice, isNe)}
                      </td>
                      <td className="py-3 px-4 text-slate-600">{rm.supplierName || '-'}</td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => {
                              saveRawMaterial({
                                ...rm,
                                currentStock: rm.currentStock + 25,
                                lastPurchasedDateBs: getTodayBsString()
                              });
                              showToast(`${rm.nameNe} मा +25 ${rm.unit} स्टक थपियो!`);
                            }}
                            className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold rounded-lg text-[10px] cursor-pointer"
                          >
                            + स्टक
                          </button>
                          <button
                            onClick={() => handleOpenEditRm(rm)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              deleteRawMaterial(rm.id);
                              showToast(`${rm.nameNe} हटाइयो।`);
                            }}
                            className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: WORK IN PROGRESS (IN MACHINE / WORKSHOP)                           */}
      {/* ========================================================================= */}
      {(activeTab === 'OVERVIEW' || activeTab === 'WIP_MACHINE') && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Cpu className="w-5 h-5 text-purple-700" />
                <span>{isNe ? 'मेसिन तथा वर्कसपमा रहेको सामग्री (Work in Progress - WIP)' : 'In-Machine Processing (WIP)'}</span>
              </h2>
              <p className="text-xs text-slate-500">
                {isNe ? 'हाल वर्कसप, सीएनसी मेसिन, वेल्डिङ वा एसेम्ब्ली लाइनमा रहेका ब्याज उत्पादनहरू' : 'Active batches currently loaded into production machinery'}
              </p>
            </div>

            <button
              onClick={() => setIsBatchModalOpen(true)}
              className="px-3.5 py-2 bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5"
            >
              <Cpu className="w-4 h-4 text-amber-300" />
              <span>{isNe ? '+ मेसिनमा नयाँ ब्याच लोड गर्नुहोस्' : '+ Start WIP Batch'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {wipBatches.length === 0 ? (
              <div className="col-span-2 py-12 text-center text-slate-400">
                हाल मेसिनमा कुनै पनि उत्पादन प्रक्रिया चालु छैन।
              </div>
            ) : (
              wipBatches.map((b) => {
                const totalRmCost = b.rawMaterialsUsed.reduce(
                  (sum, u) => sum + u.quantityUsed * u.costPerUnit,
                  0
                );
                return (
                  <div key={b.id} className="p-4 bg-purple-50/50 border border-purple-200 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-black bg-purple-200 text-purple-900 px-2.5 py-1 rounded-lg">
                        {b.batchNumber}
                      </span>
                      <span className="text-[11px] font-bold text-purple-800 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>सुरु मिति: {b.startedDateBs}</span>
                      </span>
                    </div>

                    <div>
                      <h3 className="font-black text-slate-900 text-sm">{b.productNameNe}</h3>
                      <p className="text-xs text-slate-600 mt-0.5">
                        मेसिन: <b>{b.machineName || 'वर्कसप युनिट'}</b> | अपरेटर: <b>{b.operatorName || 'प्राविधिक'}</b>
                      </p>
                    </div>

                    {/* Issued Raw Materials List */}
                    <div className="bg-white p-3 rounded-xl border border-purple-100 text-xs space-y-1">
                      <div className="font-bold text-slate-700 mb-1">प्रयोग गरिएको कच्चा पदार्थ:</div>
                      {b.rawMaterialsUsed.map((u, i) => (
                        <div key={i} className="flex justify-between text-slate-600 font-mono text-[11px]">
                          <span>• {u.materialName}</span>
                          <span className="font-bold">{u.quantityUsed} {u.unit} (रु. {u.quantityUsed * u.costPerUnit})</span>
                        </div>
                      ))}
                      <div className="border-t border-slate-100 pt-1 flex justify-between font-bold text-purple-900 mt-1">
                        <span>कुल कच्चा पदार्थ लागत्त:</span>
                        <span>{formatCurrency(totalRmCost, isNe)}</span>
                      </div>
                    </div>

                    {/* Action: Move to Finished Goods or Delete */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setFinishingBatch(b);
                          setFgQuantity(b.targetQuantity);
                        }}
                        className="flex-1 py-2.5 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                      >
                        <PackageCheck className="w-4 h-4 text-amber-300" />
                        <span>{isNe ? 'उत्पादन सम्पन्न (तयारी सामानमा सार्नुहोस्)' : 'Complete & Move to FG'}</span>
                      </button>
                      <button
                        onClick={() => {
                          deleteProductionBatch(b.id);
                          showToast(`${b.batchNumber} हटाइयो।`);
                        }}
                        className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: FINISHED GOODS                                                     */}
      {/* ========================================================================= */}
      {(activeTab === 'OVERVIEW' || activeTab === 'FINISHED_GOODS') && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <PackageCheck className="w-5 h-5 text-blue-700" />
                <span>{isNe ? 'तयारी सामग्री विवरण (Finished Goods Inventory)' : 'Finished Goods Stock'}</span>
              </h2>
              <p className="text-xs text-slate-500">
                {isNe ? 'मेसिन तथा वर्कसपबाट तयार भइसकेका पावर टिलर, पम्प, रोटेभेटर ब्लेड आदि' : 'Completed manufactured products with calculated unit cost'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {fgBatches.length === 0 ? (
              <div className="col-span-2 py-12 text-center text-slate-400">
                तयारी सामग्री मौज्दात खाली छ।
              </div>
            ) : (
              fgBatches.map((b) => (
                <div key={b.id} className="p-4 bg-blue-50/50 border border-blue-200 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-black bg-blue-200 text-blue-900 px-2.5 py-1 rounded-lg">
                      {b.batchNumber}
                    </span>
                    <span className="text-xs font-bold text-blue-900 font-mono">
                      सम्पन्न: {b.completionDateBs}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-black text-slate-900 text-sm">{b.productNameNe}</h3>
                    <div className="flex items-center gap-4 text-xs font-bold text-slate-700 mt-1">
                      <span>तयारी सङ्ख्या: <b className="font-mono text-emerald-700 text-sm">{b.finishedGoodsQuantity} थान</b></span>
                      <span>प्रति एकाइ लागत: <b className="font-mono text-purple-700">{formatCurrency(b.unitManufacturingCost || 0, isNe)}</b></span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setPackagingBatch(b);
                      setPkgType('काठको भारी प्याकिङ बाकस (Heavy Wooden Crate)');
                    }}
                    className="w-full py-2 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <PackageOpen className="w-4 h-4" />
                    <span>{isNe ? 'प्याकिङ शाखामा पठाउनुहोस् (Move to Packaging)' : 'Move to Packaging'}</span>
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: PACKAGING STOCK                                                    */}
      {/* ========================================================================= */}
      {(activeTab === 'OVERVIEW' || activeTab === 'PACKAGING') && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <PackageOpen className="w-5 h-5 text-amber-700" />
                <span>{isNe ? 'हाल प्याकिङ सामानको विवरण (Packaging & Packed Goods)' : 'Packaging & Ready Dispatch Stock'}</span>
              </h2>
              <p className="text-xs text-slate-500">
                {isNe ? 'काठको बाकस, कार्टुन तथा प्लास्टिक सिरिन्क प्याकिङ भइसकेको तयारी मौज्दात' : 'Packed goods ready for dispatch'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pkgBatches.length === 0 ? (
              <div className="col-span-2 py-12 text-center text-slate-400">
                हाल प्याकिङ शाखामा कुनै सामान छैन।
              </div>
            ) : (
              pkgBatches.map((b) => (
                <div key={b.id} className="p-4 bg-amber-50/50 border border-amber-200 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-black bg-amber-200 text-amber-900 px-2.5 py-1 rounded-lg">
                      {b.batchNumber}
                    </span>
                    <span className="text-xs font-bold text-amber-900">
                      प्याकिङ मिति: {b.packedDateBs}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-black text-slate-900 text-sm">{b.productNameNe}</h3>
                    <p className="text-xs text-slate-600 mt-0.5">
                      प्याकिङ प्रकार: <b>{b.packagingType || 'प्लास्टिक/बाकस'}</b> | परिमाण: <b>{b.packedQuantity} थान</b>
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setDispatchBatch(b);
                      setDealerName('');
                      setDealerAddress('');
                      setDealerPhone('');
                      setDispatchQty(b.packedQuantity || 1);
                      setVehicleNo('');
                      setDriverName('');
                      setDispatchNotes('');
                    }}
                    className="w-full py-2 px-3 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <Truck className="w-4 h-4 text-amber-300" />
                    <span>{isNe ? 'बजार तथा डिलरमा पठाउनुहोस् (Dispatch to Market)' : 'Dispatch to Market'}</span>
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: DISPATCHED TO MARKET                                               */}
      {/* ========================================================================= */}
      {(activeTab === 'OVERVIEW' || activeTab === 'DISPATCHED') && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Truck className="w-5 h-5 text-indigo-700" />
                <span>{isNe ? 'बजारमा पठाइएको सामान विवरण (Dispatched & Market Supply Tracker)' : 'Market Supply Tracker'}</span>
              </h2>
              <p className="text-xs text-slate-500">
                {isNe ? 'डिलर, शाखा कार्यालय तथा सहकारीहरूमा गाडीबाट आपूर्ति गरिएको सामान ट्र्याकिङ' : 'Track machinery dispatched to dealers, cooperatives, and markets'}
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-900 text-white font-bold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">मिति</th>
                  <th className="py-3 px-4">सामान / ब्याच नं.</th>
                  <th className="py-3 px-4">डिलर / ग्राहकको नाम</th>
                  <th className="py-3 px-4 text-right">पठाइएको सङ्ख्या</th>
                  <th className="py-3 px-4">गाडी नं. / चालक</th>
                  <th className="py-3 px-4 text-center">स्थिति</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {dispatchedBatches.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400">
                      बजारमा पठाइएको कुनै रेकर्ड छैन।
                    </td>
                  </tr>
                ) : (
                  dispatchedBatches.flatMap((b) =>
                    (b.dispatches || []).map((d) => (
                      <tr key={d.id} className="hover:bg-slate-50 transition">
                        <td className="py-3 px-4 font-mono font-bold text-slate-700">{d.dispatchDateBs}</td>
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900">{b.productNameNe}</div>
                          <span className="font-mono text-[10px] text-purple-700 font-bold">{b.batchNumber}</span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900">{d.dealerName}</div>
                          <div className="text-[10px] text-slate-500">{d.address} {d.phone ? `· ${d.phone}` : ''}</div>
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-black text-emerald-800 text-sm">
                          {toNepaliDigits(d.dispatchedQuantity)} थान
                        </td>
                        <td className="py-3 px-4 text-slate-700 font-mono">
                          <div>{d.vehicleNo || '-'}</div>
                          <div className="text-[10px] text-slate-500">{d.driverName}</div>
                        </td>
                        <td className="py-3 px-4 text-center font-bold">
                          <button
                            type="button"
                            onClick={() => {
                              const nextStatus = d.status === 'DELIVERED' ? 'IN_TRANSIT' : 'DELIVERED';
                              updateDispatchStatus(b.id, d.id, nextStatus);
                              showToast(
                                nextStatus === 'DELIVERED'
                                  ? `${d.dealerName} को सामान 'पुगिसकेको (Delivered)' मा अद्यावधिक भयो!`
                                  : `${d.dealerName} को सामान 'बाटोमा (In Transit)' मा राखियो!`
                              );
                            }}
                            className={`px-2.5 py-1 rounded-md text-[10px] cursor-pointer transition ${
                              d.status === 'DELIVERED'
                                ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800'
                                : 'bg-amber-100 hover:bg-amber-200 text-amber-800'
                            }`}
                          >
                            {d.status === 'DELIVERED'
                              ? isNe
                                ? '✓ पुगिसकेको (Delivered)'
                                : '✓ Delivered'
                              : isNe
                              ? '🚚 बाटोमा (Click to Deliver)'
                              : '🚚 In Transit'}
                          </button>
                        </td>
                      </tr>
                    ))
                  )
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: ADD / EDIT RAW MATERIAL MODAL                                    */}
      {/* ========================================================================= */}
      {isRmModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white shrink-0">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Boxes className="w-4 h-4 text-emerald-400" />
                <span>{editingRm ? 'कच्चा पदार्थ विवरण सम्पादन' : 'नयाँ कच्चा पदार्थ दर्ता गर्नुहोस'}</span>
              </h3>
              <button onClick={() => setIsRmModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveRmSubmit} className="p-5 space-y-3.5 text-xs overflow-y-auto flex-1 min-h-0">
              <div>
                <label className="block font-bold text-slate-700 mb-1">कच्चा पदार्थको नाम (नेपालीमा):*</label>
                <input
                  type="text"
                  required
                  value={rmNameNe}
                  onChange={(e) => setRmNameNe(e.target.value)}
                  placeholder="उदा: स्टिल पाता / एमएस सीट २ एमएम"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">English Name:</label>
                <input
                  type="text"
                  value={rmNameEn}
                  onChange={(e) => setRmNameEn(e.target.value)}
                  placeholder="e.g. MS Steel Sheet 2mm Heavy Grade"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">इकाइ (Unit):*</label>
                  <select
                    value={rmUnit}
                    onChange={(e) => setRmUnit(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold bg-white"
                  >
                    <option value="Kg">Kg (किलोग्राम)</option>
                    <option value="Meter">Meter (मिटर)</option>
                    <option value="Sheet">Sheet (पाता)</option>
                    <option value="Pc">Pc (थान)</option>
                    <option value="Set">Set (सेट)</option>
                    <option value="Litre">Litre (लिटर)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">प्रति एकाइ लागत (Rs):*</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={rmCost}
                    onChange={(e) => setRmCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">हालको मौज्दात स्टक:*</label>
                  <input
                    type="number"
                    required
                    value={rmStock}
                    onChange={(e) => setRmStock(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-emerald-800"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">न्यूनतम स्टक सचेत (Alert):</label>
                  <input
                    type="number"
                    value={rmMinAlert}
                    onChange={(e) => setRmMinAlert(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">मुख्य आपूर्तिकर्ता (Supplier):</label>
                <input
                  type="text"
                  value={rmSupplier}
                  onChange={(e) => setRmSupplier(e.target.value)}
                  placeholder="उदा: नेपाल स्टिल एण्ड एग्रो"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsRmModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  रद्द
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs cursor-pointer"
                >
                  सुरक्षित गर्नुहोस्
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: FULL PRODUCTION BATCH MODAL (MULTI-RM, YIELD/LOSS, OVERHEADS)     */}
      {/* ========================================================================= */}
      <ProductionBatchModal
        isOpen={isBatchModalOpen}
        onClose={() => setIsBatchModalOpen(false)}
        onSuccess={handleBatchCreated}
      />

      {/* ========================================================================= */}
      {/* MODAL: BATCH PASSPORT & PRINT MODAL                                       */}
      {/* ========================================================================= */}
      <ProductionPassportModal
        batch={selectedBatchForPassport}
        onClose={() => setSelectedBatchForPassport(null)}
      />

      {/* ========================================================================= */}
      {/* MODAL 3: MOVE TO FINISHED GOODS                                           */}
      {/* ========================================================================= */}
      {finishingBatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-5 py-4 border-b border-emerald-800 bg-emerald-900 text-white flex items-center justify-between shrink-0">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <PackageCheck className="w-5 h-5 text-amber-300" />
                <span>तयारी सामान दाखिला (Finish WIP Batch)</span>
              </h3>
              <button onClick={() => setFinishingBatch(null)} className="text-emerald-200 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleFinishBatchSubmit} className="p-5 space-y-4 text-xs overflow-y-auto flex-1 min-h-0">
              <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                <div className="font-mono text-xs font-bold text-emerald-900">{finishingBatch.batchNumber}</div>
                <div className="font-black text-slate-900 text-sm mt-0.5">{finishingBatch.productNameNe}</div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">तयारी परिमाण (Qty):*</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={fgQuantity}
                    onChange={(e) => setFgQuantity(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-sm font-bold text-emerald-900"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Wastage %:</label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={wastagePercent}
                    onChange={(e) => setWastagePercent(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-sm text-rose-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">अप्रत्यक्ष खर्च (Overhead Costs):</label>
                <div className="space-y-1.5">
                  {overheadCosts.map((o, i) => (
                    <div key={i} className="flex gap-2">
                      <input type="text" value={o.description} placeholder="विवरण" className="flex-1 px-2 py-1 text-[10px] border border-slate-300 rounded-md" onChange={(e) => {
                        const next = [...overheadCosts];
                        next[i].description = e.target.value;
                        setOverheadCosts(next);
                      }} />
                      <input type="number" value={o.amount} placeholder="रकम" className="w-16 px-2 py-1 text-[10px] border border-slate-300 rounded-md" onChange={(e) => {
                        const next = [...overheadCosts];
                        next[i].amount = parseFloat(e.target.value) || 0;
                        setOverheadCosts(next);
                      }} />
                      <button type="button" onClick={() => setOverheadCosts(overheadCosts.filter((_, idx) => idx !== i))} className="text-rose-500">x</button>
                    </div>
                  ))}
                  <button type="button" onClick={() => setOverheadCosts([...overheadCosts, { description: '', amount: 0 }])} className="text-blue-600 text-[10px] font-bold">+ खर्च थप्नुहोस्</button>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setFinishingBatch(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  रद्द
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs cursor-pointer"
                >
                  तयारी मौज्दातमा सेभ गर्नुहोस्
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3.5: MOVE TO PACKAGING MODAL                                        */}
      {/* ========================================================================= */}
      {packagingBatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-amber-800 bg-amber-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <PackageOpen className="w-5 h-5 text-amber-300" />
                <span>प्याकिङ शाखामा दाखिला गर्नुहोस् (Move to Packaging)</span>
              </h3>
              <button onClick={() => setPackagingBatch(null)} className="text-amber-200 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handlePackagingSubmit} className="p-5 space-y-4 text-xs">
              <div className="bg-amber-50 p-3 rounded-xl border border-amber-200">
                <div className="font-mono text-xs font-bold text-amber-950">{packagingBatch.batchNumber}</div>
                <div className="font-black text-slate-900 text-sm mt-0.5">{packagingBatch.productNameNe}</div>
                <div className="text-[11px] font-bold text-emerald-800 mt-1">
                  तयारी मौज्दात परिमाण: {packagingBatch.finishedGoodsQuantity || packagingBatch.targetQuantity} थान
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">प्याकिङको प्रकार / सामग्री (Packaging Type):*</label>
                <select
                  value={pkgType}
                  onChange={(e) => setPkgType(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-xl font-medium bg-white"
                >
                  <option value="काठको भारी प्याकिङ बाकस (Heavy Wooden Crate)">काठको भारी प्याकिङ बाकस (Heavy Wooden Crate)</option>
                  <option value="कार्टुन बाकस तथा थर्मोकोल (Carton Box & Thermocol)">कार्टुन बाकस तथा थर्मोकोल (Carton Box)</option>
                  <option value="हेभी प्लास्टिक सिरिन्क प्याक (Heavy Shrink Wrap)">हेभी प्लास्टिक सिरिन्क प्याक (Heavy Shrink Wrap)</option>
                  <option value="फलाम स्ट्रयापिङ तथा प्यालेट (Metal Strapped Pallet)">फलाम स्ट्रयापिङ तथा प्यालेट (Metal Strapped Pallet)</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setPackagingBatch(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-semibold"
                >
                  रद्द
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-700 hover:bg-amber-800 text-white font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <PackageOpen className="w-4 h-4" />
                  <span>प्याकिङ मौज्दातमा सेभ गरी सार्नुहोस्</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: DISPATCH TO MARKET MODAL                                         */}
      {/* ========================================================================= */}
      {dispatchBatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col">
            <div className="px-5 py-4 border-b border-indigo-800 bg-indigo-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Truck className="w-5 h-5 text-amber-300" />
                <span>बजारमा सामान चलानी / आपूर्ति (Dispatch to Market)</span>
              </h3>
              <button onClick={() => setDispatchBatch(null)} className="text-indigo-200 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleDispatchSubmit} className="p-5 space-y-3.5 text-xs">
              <div className="bg-indigo-50 p-3 rounded-xl border border-indigo-200">
                <span className="font-mono text-xs font-bold text-indigo-900">{dispatchBatch.batchNumber}</span>
                <div className="font-black text-slate-900 text-sm mt-0.5">{dispatchBatch.productNameNe}</div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">डिलर / ग्राहक / सहकारीको नाम:*</label>
                <input
                  type="text"
                  required
                  value={dealerName}
                  onChange={(e) => setDealerName(e.target.value)}
                  placeholder="उदा: पोखरा एग्रो विकास सप्लायर्स"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">ठेगाना:</label>
                  <input
                    type="text"
                    value={dealerAddress}
                    onChange={(e) => setDealerAddress(e.target.value)}
                    placeholder="उदा: पोखरा-०९"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">रवाना परिमाण:*</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={dispatchQty}
                    onChange={(e) => setDispatchQty(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-indigo-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">गाडी नम्बर (Vehicle No):</label>
                  <input
                    type="text"
                    value={vehicleNo}
                    onChange={(e) => setVehicleNo(e.target.value)}
                    placeholder="उदा: बा २ प ४५२१"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">चालकको नाम (Driver):</label>
                  <input
                    type="text"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    placeholder="उदा: माधव नेपाल"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">कैफियत (Dispatch Notes):</label>
                <input
                  type="text"
                  value={dispatchNotes}
                  onChange={(e) => setDispatchNotes(e.target.value)}
                  placeholder="उदा: ३ महिना पछि रकम बुझाउने सर्तमा पठाइएको"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setDispatchBatch(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  रद्द
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-700 hover:bg-indigo-800 text-white font-bold rounded-xl shadow-xs cursor-pointer"
                >
                  गाडीमा लोड गरी बजार रवाना गर्नुहोस्
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 6: MACHINES MANAGEMENT                                                */}
      {/* ========================================================================= */}
      {(activeTab === 'OVERVIEW' || activeTab === 'MACHINES') && (
        <MachinesManagementScreen />
      )}
    </div>
  );
};
