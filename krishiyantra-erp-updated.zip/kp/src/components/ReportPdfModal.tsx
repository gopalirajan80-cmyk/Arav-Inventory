import { InvoicePrintOptions, printArgsFor } from './InvoicePrintOptions';
import { printPage } from '../utils/printHelper';
import React from 'react';
import { PaperSizeToggle } from './PaperSizeToggle';
import { useApp } from '../context/AppContext';
import {
  Printer,
  Download,
  X,
  Building2,
  FileText,
  Share2,
  CheckCircle,
  FileSpreadsheet
} from 'lucide-react';
import { formatCurrency, formatBsDateNepaliText, getTodayBsString } from '../utils/nepaliCalendar';

export interface ReportPdfData {
  titleEn: string;
  titleNe: string;
  subtitleEn?: string;
  subtitleNe?: string;
  periodText?: string;
  kpiCards?: { label: string; value: string | number; color?: string }[];
  headers: string[];
  rows: (string | number)[][];
  alignRightCols?: number[]; // indices of columns to align right (numbers/currency)
  footerNote?: string;
}

interface ReportPdfModalProps {
  data: ReportPdfData;
  onClose: () => void;
  onExportExcel?: () => void;
}

export const ReportPdfModal: React.FC<ReportPdfModalProps> = ({
  data,
  onClose,
  onExportExcel
}) => {
  const { company, language } = useApp();
  const isNe = language === 'ne';
  const todayBs = getTodayBsString();

  const handlePrint = () => {
    printPage(printArgsFor('report', { features: { copies: false } }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[96vh] flex flex-col">
        
        {/* Top Control Bar (Hidden when printing via .no-print) */}
        <div className="no-print bg-slate-900 text-white px-4 py-3 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-sm font-bold tracking-tight">
                {isNe ? data.titleNe : data.titleEn} (PDF View & Print)
              </h2>
              <span className="text-[10px] text-slate-400 block font-mono">
                {company.name} · आ.व. {company.fiscalYear} · {todayBs}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onExportExcel && (
              <button
                onClick={onExportExcel}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-300" />
                <span>Excel</span>
              </button>
            )}

            <PaperSizeToggle />
            {/* Print / Save as PDF Button */}
            <InvoicePrintOptions storageKey="report" features={{}} />
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>{isNe ? 'PDF सेभ / प्रिन्ट गर्नुहोस्' : 'Print / Save as PDF'}</span>
            </button>

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable A4 Report Canvas */}
        <div className="overflow-y-auto p-4 sm:p-8 flex justify-center bg-slate-100 flex-1">
          <div
            id="printable-report"
            className="w-full max-w-[850px] bg-white shadow-md border border-slate-200 p-6 sm:p-10 text-xs font-sans text-slate-900 rounded-lg space-y-5"
          >
            {/* Header: Company Name, PAN, Address */}
            <div className="border-b-2 border-slate-900 pb-4 flex flex-col sm:flex-row justify-between items-start gap-4">
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  {company.name}
                </h1>
                <p className="text-xs text-slate-600 mt-0.5">
                  {company.address} {company.phone && `· फोन: ${company.phone}`}
                </p>
                <p className="text-[11px] font-mono text-slate-500">
                  {company.email && `इमेल: ${company.email} · `}स्थायी लेखा नं. (PAN/VAT): <strong className="text-slate-900">{company.panVatNo}</strong>
                </p>
              </div>

              <div className="sm:text-right font-mono text-xs space-y-0.5">
                <span className="inline-block px-2.5 py-1 bg-slate-900 text-white rounded text-[11px] font-bold tracking-wide">
                  {isNe ? 'आधिकारिक वित्तीय रिपोर्ट' : 'Financial Statement'}
                </span>
                <div className="text-slate-700 text-[11px] pt-1">
                  मिति: <strong>{todayBs}</strong> (बि.सं.)
                </div>
                <div className="text-slate-500 text-[10px]">
                  आर्थिक वर्ष: {company.fiscalYear}
                </div>
              </div>
            </div>

            {/* Report Title & Subtitle Banner */}
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {isNe ? data.titleNe : data.titleEn}
                </h2>
                <p className="text-[11px] text-slate-500">
                  {isNe ? data.subtitleNe : data.subtitleEn}
                </p>
              </div>
              {data.periodText && (
                <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-900 text-[11px] font-semibold rounded-md font-mono">
                  {data.periodText}
                </span>
              )}
            </div>

            {/* KPI Metric Summary Tiles */}
            {data.kpiCards && data.kpiCards.length > 0 && (
              <div className={`grid grid-cols-2 sm:grid-cols-${Math.min(data.kpiCards.length, 4)} gap-2.5`}>
                {data.kpiCards.map((kpi, idx) => (
                  <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-center">
                    <span className="text-[10px] font-medium text-slate-500 block truncate">
                      {kpi.label}
                    </span>
                    <span className={`text-sm sm:text-base font-mono font-bold block mt-0.5 ${kpi.color || 'text-slate-900'}`}>
                      {typeof kpi.value === 'number' ? formatCurrency(kpi.value, isNe) : kpi.value}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Detailed Data Table */}
            <div className="border border-slate-300 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                  <tr>
                    {data.headers.map((h, idx) => (
                      <th
                        key={idx}
                        className={`py-2 px-2.5 border-r border-slate-200 last:border-r-0 ${
                          data.alignRightCols?.includes(idx) ? 'text-right' : 'text-left'
                        }`}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-sans">
                  {data.rows.map((row, rIdx) => (
                    <tr key={rIdx} className={rIdx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}>
                      {row.map((cell, cIdx) => (
                        <td
                          key={cIdx}
                          className={`py-2 px-2.5 border-r border-slate-200 last:border-r-0 ${
                            data.alignRightCols?.includes(cIdx)
                              ? 'text-right font-mono font-medium'
                              : 'text-left'
                          }`}
                        >
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Footer Note */}
            {data.footerNote && (
              <p className="text-[11px] text-slate-500 italic pt-1">
                * {data.footerNote}
              </p>
            )}

            {/* Authorized Signatures & IRD Verification Seals */}
            <div className="pt-8 border-t border-slate-200 flex justify-between items-end text-xs text-slate-600">
              <div className="space-y-1">
                <div className="w-36 border-b border-slate-400 pb-1" />
                <span className="text-[10px] block">तयार गर्ने (Prepared By)</span>
              </div>

              <div className="text-center font-mono text-[10px] text-slate-400">
                <span>{company.name} Computer ERP System</span>
                <span className="block">{todayBs}</span>
              </div>

              <div className="space-y-1 text-right">
                <div className="w-36 border-b border-slate-400 pb-1 ml-auto" />
                <span className="text-[10px] block">अधिकृत हस्ताक्षर (Authorized Signatory)</span>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
