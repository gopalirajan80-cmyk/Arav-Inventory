import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Laptop,
  Smartphone,
  RefreshCw,
  CheckCircle2,
  X,
  Edit3,
  RotateCcw,
  Sparkles
} from 'lucide-react';
import {
  getTodayBsString,
  getDeviceLiveBsString,
  getDateSyncMode,
  setManualOverrideDate,
  formatBsDateNepaliText,
  getDeviceClockDetails,
  NEPALI_MONTHS_NE,
  toNepaliDigits
} from '../utils/nepaliCalendar';

interface DateManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DateManagementModal: React.FC<DateManagementModalProps> = ({ isOpen, onClose }) => {
  const [syncMode, setSyncMode] = useState<'AUTO' | 'MANUAL'>('AUTO');
  const [deviceDetails, setDeviceDetails] = useState(getDeviceClockDetails());
  const [manualInput, setManualInput] = useState<string>('');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const currentMode = getDateSyncMode();
    setSyncMode(currentMode);
    const details = getDeviceClockDetails();
    setDeviceDetails(details);
    setManualInput(details.activeBsStr);
    setSaveSuccessMsg(null);
  }, [isOpen]);

  const handleRefreshDeviceClock = () => {
    setDeviceDetails(getDeviceClockDetails());
    setSaveSuccessMsg('कम्प्युटर र मोबाइल घडी सफलतापूर्वक रिफ्रेस भयो!');
    setTimeout(() => setSaveSuccessMsg(null), 3000);
  };

  const handleApplyManualDate = () => {
    const trimmed = manualInput.trim().replace(/\//g, '-');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
      alert('कृपया सही मिति ढाँचा राख्नुहोस् (YYYY-MM-DD, उदा: 2083-07-13)');
      return;
    }
    setManualOverrideDate(trimmed);
    setSyncMode('MANUAL');
    setDeviceDetails(getDeviceClockDetails());
    setSaveSuccessMsg(`म्यानुअल मिति सेट भयो: ${trimmed} (${formatBsDateNepaliText(trimmed)})`);
    setTimeout(() => {
      setSaveSuccessMsg(null);
      onClose();
    }, 1500);
  };

  const handleResetToAuto = () => {
    setManualOverrideDate(null);
    setSyncMode('AUTO');
    const details = getDeviceClockDetails();
    setDeviceDetails(details);
    setManualInput(details.liveBsStr);
    setSaveSuccessMsg('कम्प्युटर तथा मोबाइल घडी अनुसार अटो-सिंक मितिमा फर्काइयो!');
    setTimeout(() => {
      setSaveSuccessMsg(null);
      onClose();
    }, 1500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-emerald-950 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-base font-black">मिति व्यवस्थापन तथा सच्याउने (Date Settings)</h2>
              <p className="text-xs text-emerald-100">
                कम्प्युटर र मोबाइल अनुसार अटो-सिंक वा म्यानुअल मिति
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Alert */}
        {saveSuccessMsg && (
          <div className="mx-6 mt-4 p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>{saveSuccessMsg}</span>
          </div>
        )}

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Live Device Clock Banner */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700">
              <span className="flex items-center gap-1.5">
                <Laptop className="w-4 h-4 text-emerald-700" />
                <Smartphone className="w-4 h-4 text-emerald-700" />
                <span>तपाईंको कम्प्युटर / मोबाइल घडीको मिति:</span>
              </span>
              <button
                type="button"
                onClick={handleRefreshDeviceClock}
                className="text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer text-[11px]"
              >
                <RefreshCw className="w-3 h-3" />
                <span>ताजा गर्नुहोस्</span>
              </button>
            </div>

            <div className="flex items-baseline justify-between flex-wrap gap-2 pt-1">
              <div>
                <div className="text-2xl font-black font-mono text-emerald-900 tracking-tight">
                  {deviceDetails.liveBsStr}
                </div>
                <div className="text-xs font-bold text-slate-800">
                  {formatBsDateNepaliText(deviceDetails.liveBsStr)} ({deviceDetails.dayNe})
                </div>
              </div>
              <div className="text-right text-xs text-slate-500 font-mono">
                <div>ई.सं. (A.D.): {deviceDetails.adDateStr}</div>
                <div>घडी समय: {deviceDetails.timeFormatted}</div>
              </div>
            </div>
          </div>

          {/* Sync Mode Selection */}
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
              मिति छान्ने माध्यम (Date Mode):
            </label>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={handleResetToAuto}
                className={`p-3.5 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                  syncMode === 'AUTO'
                    ? 'bg-emerald-50 border-emerald-500 shadow-xs ring-2 ring-emerald-500/20'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-xs text-slate-900">⚡ अटो-सिंक (घडी अनुसार)</span>
                  {syncMode === 'AUTO' && <CheckCircle2 className="w-4 h-4 text-emerald-700" />}
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  कम्प्युटर र फोनको घडी अनुसार प्रत्येक दिन स्वतः नयाँ मिति सर्नेछ।
                </p>
              </button>

              <button
                type="button"
                onClick={() => setSyncMode('MANUAL')}
                className={`p-3.5 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                  syncMode === 'MANUAL'
                    ? 'bg-amber-50 border-amber-500 shadow-xs ring-2 ring-amber-500/20'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-xs text-slate-900">✏️ म्यानुअल मिति (Override)</span>
                  {syncMode === 'MANUAL' && <Edit3 className="w-4 h-4 text-amber-700" />}
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  आफ्नो इच्छा अनुसार कुनै पनि अघिल्लो वा पछिल्लो मिति मिलाउनुहोस्।
                </p>
              </button>
            </div>
          </div>

          {/* Manual Date Input Section */}
          <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                <Edit3 className="w-3.5 h-3.5 text-amber-700" />
                <span>म्यानुअल मिति टाइप / सच्याउने (YYYY-MM-DD):</span>
              </span>
              {syncMode === 'MANUAL' && (
                <span className="text-[10px] font-bold bg-amber-200 text-amber-950 px-1.5 py-0.5 rounded">
                  म्यानुअल सक्रिय
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={manualInput}
                onChange={(e) => setManualInput(e.target.value)}
                placeholder="2083-07-13"
                className="flex-1 px-3 py-2 bg-white border border-amber-300 rounded-xl font-mono font-black text-sm text-amber-950 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <button
                type="button"
                onClick={handleApplyManualDate}
                className="px-4 py-2 bg-amber-700 hover:bg-amber-800 text-white font-bold text-xs rounded-xl transition cursor-pointer shadow-xs"
              >
                लागू गर्नुहोस्
              </button>
            </div>

            {/* Quick Helper Presets */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px]">
              <span className="text-amber-800 font-semibold">छिटो छान्नुहोस्:</span>
              <button
                type="button"
                onClick={() => setManualInput(deviceDetails.liveBsStr)}
                className="px-2 py-0.5 bg-white border border-amber-300 rounded text-amber-950 hover:bg-amber-100 cursor-pointer"
              >
                कम्प्युटर घडी मिति ({deviceDetails.liveBsStr})
              </button>
              <button
                type="button"
                onClick={() => {
                  const parts = deviceDetails.liveBsStr.split('-');
                  const d = Math.max(1, parseInt(parts[2], 10) - 1);
                  setManualInput(`${parts[0]}-${parts[1]}-${String(d).padStart(2, '0')}`);
                }}
                className="px-2 py-0.5 bg-white border border-amber-300 rounded text-amber-950 hover:bg-amber-100 cursor-pointer"
              >
                हिजोको मिति (-१ दिन)
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between text-xs">
          {syncMode === 'MANUAL' ? (
            <button
              type="button"
              onClick={handleResetToAuto}
              className="flex items-center gap-1.5 text-emerald-800 hover:text-emerald-950 font-bold cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>अटो-सिंक घडीमा फर्काउनुहोस्</span>
            </button>
          ) : (
            <span className="text-slate-500">हाल घडीसँग स्वतः अटो-सिंक भइरहेको छ ✓</span>
          )}
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg cursor-pointer"
          >
            बन्द गर्नुहोस्
          </button>
        </div>
      </div>
    </div>
  );
};
