import { printPage } from '../utils/printHelper';
import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  Download,
  Plus,
  Scale,
  X,
  Receipt,
  ShoppingCart,
  Calendar,
  Search,
  Printer,
  FileSpreadsheet,
  TrendingUp,
  TrendingDown,
  Eye,
  Filter,
  Trash2,
  Truck,
  Layers
} from 'lucide-react';
import {
  formatCurrency,
  getTodayBsString,
  getTodayAdString,
  toNepaliDigits,
  NEPALI_MONTHS_NE,
  NEPALI_MONTHS_EN
} from '../utils/nepaliCalendar';
import { exportSalesBookToExcel, exportPurchaseBookToExcel } from '../utils/excelEngine';
import { InvoicePrintModal } from './InvoicePrintModal';
import { BatchInvoicePrintModal } from './BatchInvoicePrintModal';
import { Invoice, Party } from '../types';
import { BalanceConfirmationModal } from './BalanceConfirmationModal';
import { PartyVatReport } from './PartyVatReport';
import { printOrDownloadReportPdf } from '../utils/pdfReportExporter';
import { FileDown, FileText } from 'lucide-react';

interface MonthlyKharidBikriRow {
  monthCode: string; // '01' .. '12'
  monthIndex: number; // 0 .. 11
  monthNameNe: string;
  monthNameEn: string;
  salesCount: number;
  salesTaxable: number;
  salesExempt: number;
  salesVat: number;
  salesGrand: number;
  purchaseCount: number;
  purchaseTaxable: number;
  purchaseExempt: number;
  purchaseVat: number;
  purchaseGrand: number;
  netVat: number; // salesVat - purchaseVat
  netTradeDiff: number; // salesGrand - purchaseGrand
}

// Helper to extract { year, monthCode } from BS date string like "2083-07-12" or "2081/04/15"
function parseBsYearMonth(dateBs: string): { year: string; monthCode: string } {
  if (!dateBs) return { year: '', monthCode: '' };
  const normalized = dateBs.trim().replace(/\//g, '-');
  const parts = normalized.split('-');
  const year = parts[0] || '';
  const rawMonth = parts[1] ? parseInt(parts[1], 10) : 0;
  const monthCode = rawMonth >= 1 && rawMonth <= 12 ? String(rawMonth).padStart(2, '0') : '';
  return { year, monthCode };
}

export const VatBookScreen: React.FC = () => {
  const {
    invoices,
    purchases,
    parties,
    fiscalYearsList,
    company,
    language,
    recordPurchase,
    deletePurchase,
    startEditInvoice,
    cancelInvoice,
    deleteInvoice,
    openPurchaseModalSignal,
    triggerQuickDispatch,
    t
  } = useApp();

  const isNe = language === 'ne';
  const [activeTab, setActiveTab] = useState<'SUMMARY' | 'SALES' | 'PURCHASE' | 'PARTY_CONFIRMATION' | 'PARTY_VAT'>('SUMMARY');
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false);
  const [selectedConfirmationPartyKey, setSelectedConfirmationPartyKey] = useState<string>('ALL');
  const [confirmParty, setConfirmParty] = useState<Party | null>(null);

  // Month & Year Filters
  const [selectedYear, setSelectedYear] = useState<string>('ALL');
  const [selectedMonth, setSelectedMonth] = useState<string>('ALL'); // 'ALL' | '01' .. '12'
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showOnlyActiveMonths, setShowOnlyActiveMonths] = useState<boolean>(false);

  React.useEffect(() => {
    if (openPurchaseModalSignal > 0) {
      setActiveTab('PURCHASE');
      setIsPurchaseModalOpen(true);
    }
  }, [openPurchaseModalSignal]);

  // New Purchase Record state
  const [purBillNo, setPurBillNo] = useState('');
  const [purSupplierName, setPurSupplierName] = useState('');
  const [purSupplierPan, setPurSupplierPan] = useState('');
  const [purDateBs, setPurDateBs] = useState(getTodayBsString());
  const [purTaxable, setPurTaxable] = useState<number>(0);
  const [purExempt, setPurExempt] = useState<number>(0);
  const [purSummary, setPurSummary] = useState('');

  // Multi-Select & Batch Print Invoices State (बिक्री खाता बहु-चयन तथा एकैसाथ प्रिन्ट)
  const [selectedInvoiceIds, setSelectedInvoiceIds] = useState<string[]>([]);
  const [selectedPurchaseIds, setSelectedPurchaseIds] = useState<string[]>([]);
  const [selectedMonthCodes, setSelectedMonthCodes] = useState<string[]>([]);
  const [viewInvoice, setViewInvoice] = useState<Invoice | null>(null);
  const [isBatchPrintOpen, setIsBatchPrintOpen] = useState<boolean>(false);

  const activeInvoices = useMemo(
    () => invoices.filter((i) => i.status === 'ACTIVE'),
    [invoices]
  );

  // Extract all available BS years from invoices, purchases, and today
  const availableYears = useMemo(() => {
    const yearsSet = new Set<string>();
    const todayYear = parseBsYearMonth(getTodayBsString()).year;
    if (todayYear) yearsSet.add(todayYear);

    activeInvoices.forEach((inv) => {
      const { year } = parseBsYearMonth(inv.dateBs);
      if (year) yearsSet.add(year);
    });
    purchases.forEach((pur) => {
      const { year } = parseBsYearMonth(pur.dateBs);
      if (year) yearsSet.add(year);
    });

    return Array.from(yearsSet).sort((a, b) => b.localeCompare(a));
  }, [activeInvoices, purchases]);

  // Helper to match either B.S. Year (e.g., "2081") or Fiscal Year (e.g., "081/82")
  const doesRecordMatchYearOrFy = (dateBs: string, recordFy?: string) => {
    if (selectedYear === 'ALL') return true;
    if (selectedYear.includes('/')) {
      if (recordFy && recordFy === selectedYear) return true;
      const parts = selectedYear.split('/');
      const startYr = parts[0].length === 3 ? `2${parts[0]}` : parts[0];
      const endYr = parts[1].length === 2 ? `20${parts[1]}` : parts[1];
      const { year, monthCode } = parseBsYearMonth(dateBs);
      const mo = parseInt(monthCode || '0', 10);
      if (year === startYr && mo >= 4) return true;
      if (year === endYr && mo >= 1 && mo <= 3) return true;
      return year === startYr || year === endYr;
    }
    return parseBsYearMonth(dateBs).year === selectedYear;
  };

  // Filter by Year / Fiscal Year first (used for the 12-month breakdown table)
  const yearFilteredInvoices = useMemo(() => {
    if (selectedYear === 'ALL') return activeInvoices;
    return activeInvoices.filter((inv) => doesRecordMatchYearOrFy(inv.dateBs, inv.fiscalYear));
  }, [activeInvoices, selectedYear]);

  const yearFilteredPurchases = useMemo(() => {
    if (selectedYear === 'ALL') return purchases;
    return purchases.filter((pur) => doesRecordMatchYearOrFy(pur.dateBs));
  }, [purchases, selectedYear]);

  // Filter by both Year, Month, and Search Query (used for Sales Book, Purchase Book, and Selected Period KPI cards)
  const filteredInvoices = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return yearFilteredInvoices.filter((inv) => {
      if (selectedMonth !== 'ALL') {
        const { monthCode } = parseBsYearMonth(inv.dateBs);
        if (monthCode !== selectedMonth) return false;
      }
      if (q) {
        const matchNo = inv.invoiceNo.toLowerCase().includes(q);
        const matchName = inv.customerName.toLowerCase().includes(q);
        const matchPan = (inv.customerPan || '').toLowerCase().includes(q);
        if (!matchNo && !matchName && !matchPan) return false;
      }
      return true;
    });
  }, [yearFilteredInvoices, selectedMonth, searchQuery]);

  const filteredPurchases = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return yearFilteredPurchases.filter((pur) => {
      if (selectedMonth !== 'ALL') {
        const { monthCode } = parseBsYearMonth(pur.dateBs);
        if (monthCode !== selectedMonth) return false;
      }
      if (q) {
        const matchNo = pur.purchaseBillNo.toLowerCase().includes(q);
        const matchName = pur.supplierName.toLowerCase().includes(q);
        const matchPan = (pur.supplierPan || '').toLowerCase().includes(q);
        const matchItems = (pur.itemsSummary || '').toLowerCase().includes(q);
        if (!matchNo && !matchName && !matchPan && !matchItems) return false;
      }
      return true;
    });
  }, [yearFilteredPurchases, selectedMonth, searchQuery]);

  // Compute Selected Period Sales Book totals
  const totalSalesGrand = filteredInvoices.reduce((s, i) => s + i.grandTotal, 0);
  const totalSalesExempt = filteredInvoices.reduce((s, i) => s + i.exemptAmount, 0);
  const totalSalesTaxable = filteredInvoices.reduce((s, i) => s + i.taxableAmount, 0);
  const totalSalesVat = filteredInvoices.reduce((s, i) => s + i.vatAmount, 0);

  // Batch Multi-Select Handlers
  const handleToggleSelectInvoice = (id: string) => {
    setSelectedInvoiceIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const isAllInvoicesSelected =
    filteredInvoices.length > 0 &&
    filteredInvoices.every((inv) => selectedInvoiceIds.includes(inv.id));

  const handleToggleSelectAllInvoices = () => {
    if (isAllInvoicesSelected) {
      setSelectedInvoiceIds([]);
    } else {
      setSelectedInvoiceIds(filteredInvoices.map((inv) => inv.id));
    }
  };

  const selectedInvoicesForBatch = useMemo(() => {
    return filteredInvoices.filter((inv) => selectedInvoiceIds.includes(inv.id));
  }, [filteredInvoices, selectedInvoiceIds]);

  // Compute Selected Period Purchase Book totals
  const totalPurGrand = filteredPurchases.reduce((s, p) => s + p.grandTotal, 0);
  const totalPurExempt = filteredPurchases.reduce((s, p) => s + p.exemptAmount, 0);
  const totalPurTaxable = filteredPurchases.reduce((s, p) => s + p.taxableAmount, 0);
  const totalPurVat = filteredPurchases.reduce((s, p) => s + p.vatAmount, 0);

  // Net VAT & Net Trade Balance for Selected Period
  const netVat = totalSalesVat - totalPurVat;
  const netTradeBalance = totalSalesGrand - totalPurGrand;

  // Compute 12-Month Breakdown Table (Baisakh 01 to Chaitra 12)
  const monthlyBreakdown: MonthlyKharidBikriRow[] = useMemo(() => {
    return NEPALI_MONTHS_NE.map((nameNe, idx) => {
      const monthCode = String(idx + 1).padStart(2, '0');
      const monthInvs = yearFilteredInvoices.filter(
        (inv) => parseBsYearMonth(inv.dateBs).monthCode === monthCode
      );
      const monthPurs = yearFilteredPurchases.filter(
        (pur) => parseBsYearMonth(pur.dateBs).monthCode === monthCode
      );

      const salesTaxable = monthInvs.reduce((s, i) => s + i.taxableAmount, 0);
      const salesExempt = monthInvs.reduce((s, i) => s + i.exemptAmount, 0);
      const salesVat = monthInvs.reduce((s, i) => s + i.vatAmount, 0);
      const salesGrand = monthInvs.reduce((s, i) => s + i.grandTotal, 0);

      const purchaseTaxable = monthPurs.reduce((s, p) => s + p.taxableAmount, 0);
      const purchaseExempt = monthPurs.reduce((s, p) => s + p.exemptAmount, 0);
      const purchaseVat = monthPurs.reduce((s, p) => s + p.vatAmount, 0);
      const purchaseGrand = monthPurs.reduce((s, p) => s + p.grandTotal, 0);

      return {
        monthCode,
        monthIndex: idx,
        monthNameNe: nameNe,
        monthNameEn: NEPALI_MONTHS_EN[idx],
        salesCount: monthInvs.length,
        salesTaxable,
        salesExempt,
        salesVat,
        salesGrand,
        purchaseCount: monthPurs.length,
        purchaseTaxable,
        purchaseExempt,
        purchaseVat,
        purchaseGrand,
        netVat: salesVat - purchaseVat,
        netTradeDiff: salesGrand - purchaseGrand
      };
    });
  }, [yearFilteredInvoices, yearFilteredPurchases]);

  const displayedMonthlyRows = useMemo(() => {
    if (!showOnlyActiveMonths) return monthlyBreakdown;
    return monthlyBreakdown.filter((r) => r.salesCount > 0 || r.purchaseCount > 0);
  }, [monthlyBreakdown, showOnlyActiveMonths]);

  // Selected Month Label
  const selectedMonthLabel = useMemo(() => {
    if (selectedMonth === 'ALL') {
      return isNe ? 'सबै १२ महिना (वार्षिक कुल)' : 'All 12 Months (Annual Total)';
    }
    const idx = parseInt(selectedMonth, 10) - 1;
    const mNe = NEPALI_MONTHS_NE[idx] || '';
    const mEn = NEPALI_MONTHS_EN[idx] || '';
    return isNe ? `${toNepaliDigits(selectedMonth)} - ${mNe} महिना` : `${selectedMonth} - ${mEn}`;
  }, [selectedMonth, isNe]);

  // Export Monthly Kharid-Bikri Summary to CSV
  const handleExportMonthlySummaryCsv = () => {
    const headers = [
      'Month Code',
      'Month (Nepali)',
      'Month (English)',
      'Sales Bills',
      'Taxable Sales (NPR)',
      'Exempt Sales (NPR)',
      '13% Output VAT (NPR)',
      'Total Sales (NPR)',
      'Purchase Bills',
      'Taxable Purchase (NPR)',
      'Exempt Purchase (NPR)',
      '13% Input VAT (NPR)',
      'Total Purchase (NPR)',
      'Net VAT Payable/Credit (NPR)'
    ];

    const rows = monthlyBreakdown.map((r) => [
      r.monthCode,
      r.monthNameNe,
      r.monthNameEn,
      r.salesCount,
      r.salesTaxable.toFixed(2),
      r.salesExempt.toFixed(2),
      r.salesVat.toFixed(2),
      r.salesGrand.toFixed(2),
      r.purchaseCount,
      r.purchaseTaxable.toFixed(2),
      r.purchaseExempt.toFixed(2),
      r.purchaseVat.toFixed(2),
      r.purchaseGrand.toFixed(2),
      r.netVat.toFixed(2)
    ]);

    const csvContent =
      '\uFEFF' +
      [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Monthly_Kharid_Bikri_VAT_Summary_${selectedYear}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSavePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!purSupplierName.trim()) {
      return;
    }

    const vatAmount = Math.round(purTaxable * 0.13 * 100) / 100;
    const grandTotal = purTaxable + purExempt + vatAmount;

    recordPurchase({
      purchaseBillNo: purBillNo.trim() || `PB-${Date.now().toString().slice(-4)}`,
      supplierName: purSupplierName.trim(),
      supplierPan: purSupplierPan.trim(),
      dateBs: purDateBs.trim() || getTodayBsString(),
      dateAd: getTodayAdString(),
      itemsSummary: purSummary || 'कृषि औजार तथा मेसिनरी खरिद',
      taxableAmount: purTaxable,
      exemptAmount: purExempt,
      vatAmount,
      grandTotal,
      paymentMode: 'CASH'
    });

    setIsPurchaseModalOpen(false);
    setPurBillNo('');
    setPurSupplierName('');
    setPurSupplierPan('');
    setPurTaxable(0);
    setPurExempt(0);
    setPurSummary('');
  };

  // छानिएको (checkbox) भए त्यही मात्र print/export, नछानिए सबै
  const salesReportRows = selectedInvoiceIds.length > 0 ? filteredInvoices.filter((i) => selectedInvoiceIds.includes(i.id)) : filteredInvoices;
  const purReportRows = selectedPurchaseIds.length > 0 ? filteredPurchases.filter((p) => selectedPurchaseIds.includes(p.id)) : filteredPurchases;
  const rsGrand = salesReportRows.reduce((s, i) => s + i.grandTotal, 0);
  const rsExempt = salesReportRows.reduce((s, i) => s + i.exemptAmount, 0);
  const rsTaxable = salesReportRows.reduce((s, i) => s + i.taxableAmount, 0);
  const rsVat = salesReportRows.reduce((s, i) => s + i.vatAmount, 0);
  const rpGrand = purReportRows.reduce((s, p) => s + p.grandTotal, 0);
  const rpExempt = purReportRows.reduce((s, p) => s + p.exemptAmount, 0);
  const rpTaxable = purReportRows.reduce((s, p) => s + p.taxableAmount, 0);
  const rpVat = purReportRows.reduce((s, p) => s + p.vatAmount, 0);
  const togglePurchase = (id: string) =>
    setSelectedPurchaseIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  const isAllPurSelected = filteredPurchases.length > 0 && filteredPurchases.every((p) => selectedPurchaseIds.includes(p.id));
  const toggleMonthCode = (code: string) =>
    setSelectedMonthCodes((prev) => (prev.includes(code) ? prev.filter((x) => x !== code) : [...prev, code]));

const selM = monthlyBreakdown.filter((r) => selectedMonthCodes.includes(r.monthCode));
  const useSelM = selM.length > 0;
  const sm = (f: (r: MonthlyKharidBikriRow) => number) => selM.reduce((a, r) => a + f(r), 0);

  const handleExportSalesBookPdf = () => {
    printOrDownloadReportPdf({
      company,
      titleNe: 'बिक्री खाता (अनुसूची ५)',
      titleEn: 'Sales Book (Anusuchi 5)',
      periodLabel: selectedMonthLabel,
      headers: [
        'बीजक नं.',
        'मिति (B.S.)',
        'ग्राहकको नाम',
        'प्यान नं.',
        'करयोग्य बिक्री',
        'छुट',
        '१३% भ्याट',
        'कुल रकम'
      ],
      rows: salesReportRows.map((inv) => [
        inv.invoiceNo,
        inv.dateBs,
        inv.customerName,
        inv.customerPan || '-',
        inv.taxableAmount.toFixed(2),
        inv.discountAmount.toFixed(2),
        inv.vatAmount.toFixed(2),
        inv.grandTotal.toFixed(2)
      ]),
      summaryCards: [
        { label: 'कुल बिक्री (Grand Total)', value: formatCurrency(rsGrand, isNe) },
        { label: 'जम्मा करयोग्य (Taxable)', value: formatCurrency(rsTaxable, isNe) },
        { label: 'कुल भ्याट (Output VAT)', value: formatCurrency(rsVat, isNe) }
      ],
      fileName: `Sales_Book_${selectedYear}_${selectedMonth}`,
      mode: 'DOWNLOAD'
    });
  };

  const handleExportPurchaseBookPdf = () => {
    printOrDownloadReportPdf({
      company,
      titleNe: 'खरिद खाता (अनुसूची ८)',
      titleEn: 'Purchase Book (Anusuchi 8)',
      periodLabel: selectedMonthLabel,
      headers: [
        'खरिद बिल नं.',
        'मिति (B.S.)',
        'आपूर्तिकर्ता',
        'प्यान नं.',
        'करयोग्य खरिद',
        'छुट',
        '१३% भ्याट',
        'कुल खरिद'
      ],
      rows: purReportRows.map((pur) => [
        pur.purchaseBillNo,
        pur.dateBs,
        pur.supplierName,
        pur.supplierPan || '-',
        pur.taxableAmount.toFixed(2),
        pur.exemptAmount.toFixed(2),
        pur.vatAmount.toFixed(2),
        pur.grandTotal.toFixed(2)
      ]),
      summaryCards: [
        { label: 'कुल खरिद (Grand Total)', value: formatCurrency(rpGrand, isNe) },
        { label: 'जम्मा करयोग्य (Taxable)', value: formatCurrency(rpTaxable, isNe) },
        { label: 'कुल भ्याट (Input VAT)', value: formatCurrency(rpVat, isNe) }
      ],
      fileName: `Purchase_Book_${selectedYear}_${selectedMonth}`,
      mode: 'DOWNLOAD'
    });
  };

  return (
    <div className="space-y-4">
      {/* Top Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {t.vatBooksTitle}
            </h1>
            <span className="px-2.5 py-0.5 text-[11px] font-bold bg-emerald-100 text-emerald-900 rounded-md border border-emerald-200">
              {isNe ? 'मासिक खरिद–बिक्री तथा भ्याट सारांश सहित' : 'With Monthly Purchase & Sales Summary'}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {isNe
              ? 'आन्तरिक राजस्व विभाग (IRD) अनुसूची ५ (बिक्री खाता), अनुसूची ८ (खरिद खाता) र मासिक खरिद–बिक्री रिपोर्ट'
              : 'Official Nepal IRD Sales Book (Anusuchi 5), Purchase Book (Anusuchi 8) & Monthly Purchase-Sales Summary'}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start lg:self-auto flex-wrap">
          <button
            onClick={handleExportMonthlySummaryCsv}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isNe ? 'मासिक सारांश डाउनलोड (CSV)' : 'Export Monthly Summary'}</span>
          </button>

          <button
            onClick={() => exportSalesBookToExcel(filteredInvoices, company.fiscalYear)}
            disabled={filteredInvoices.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
            title="Export Sales Book as Excel"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isNe ? 'Excel (बिक्री)' : 'Sales Excel'}</span>
          </button>

          <button
            onClick={handleExportSalesBookPdf}
            disabled={filteredInvoices.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 bg-blue-900 hover:bg-slate-900 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
            title="Export Sales Book as PDF"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>{isNe ? 'PDF (बिक्री)' : 'Sales PDF'}</span>
          </button>

          <button
            onClick={() => exportPurchaseBookToExcel(filteredPurchases, company.fiscalYear)}
            disabled={filteredPurchases.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-50 text-slate-800 text-xs font-semibold rounded-lg transition cursor-pointer"
            title="Export Purchase Book as Excel"
          >
            <Download className="w-3.5 h-3.5 text-emerald-700" />
            <span>{isNe ? 'Excel (खरिद)' : 'Purchase Excel'}</span>
          </button>

          <button
            onClick={handleExportPurchaseBookPdf}
            disabled={filteredPurchases.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 border border-emerald-800 bg-emerald-900 hover:bg-emerald-950 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition cursor-pointer"
            title="Export Purchase Book as PDF"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>{isNe ? 'PDF (खरिद)' : 'Purchase PDF'}</span>
          </button>

          <button
            onClick={() => setIsPurchaseModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{t.recordNewPurchase}</span>
          </button>
        </div>
      </div>

      {/* Month & Year Filter Panel (मासिक खरिद–बिक्री फिल्टर बार) */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
              <Calendar className="w-4 h-4 text-emerald-700" />
              <span>{isNe ? 'महिना र वर्ष अनुसार खरिद–बिक्री हेर्नुहोस्:' : 'Filter Purchase & Sales by Nepali Month:'}</span>
            </div>

            {/* Fiscal Year & B.S. Year Selector */}
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="px-2.5 py-1.5 text-xs font-bold bg-slate-100 border border-slate-300 rounded-lg text-slate-900 cursor-pointer"
            >
              <option value="ALL">{isNe ? 'सबै आर्थिक वर्ष / वर्ष (All Years)' : 'All Fiscal / B.S. Years'}</option>
              <optgroup label={isNe ? 'आर्थिक वर्ष (Fiscal Year)' : 'Fiscal Years'}>
                {Array.from(new Set([company.fiscalYear, ...(fiscalYearsList || []), '082/83', '081/82', '080/81'])).map(
                  (fy) => (
                    <option key={`fy-${fy}`} value={fy}>
                      {isNe ? `आ.व. ${toNepaliDigits(fy)}` : `F.Y. ${fy}`}
                    </option>
                  )
                )}
              </optgroup>
              <optgroup label={isNe ? 'वि.सं. वर्ष (B.S. Year)' : 'B.S. Years'}>
                {availableYears.map((yr) => (
                  <option key={yr} value={yr}>
                    {isNe ? `वि.सं. ${toNepaliDigits(yr)}` : `B.S. ${yr}`}
                  </option>
                ))}
              </optgroup>
            </select>

            {/* Dropdown Month Selector for quick mobile access */}
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="px-2.5 py-1.5 text-xs font-bold bg-emerald-50 border border-emerald-300 rounded-lg text-emerald-950 cursor-pointer"
            >
              <option value="ALL">{isNe ? 'सबै १२ महिना (बैशाख – चैत)' : 'All 12 Months (Baisakh - Chaitra)'}</option>
              {NEPALI_MONTHS_NE.map((mNe, idx) => {
                const code = String(idx + 1).padStart(2, '0');
                const row = monthlyBreakdown[idx];
                const totalTx = row ? row.salesCount + row.purchaseCount : 0;
                return (
                  <option key={code} value={code}>
                    {isNe
                      ? `${toNepaliDigits(code)} - ${mNe} (${toNepaliDigits(totalTx)} कारोबार)`
                      : `${code} - ${NEPALI_MONTHS_EN[idx]} (${totalTx} records)`}
                  </option>
                );
              })}
            </select>

            {selectedMonth !== 'ALL' && (
              <button
                onClick={() => setSelectedMonth('ALL')}
                className="px-2.5 py-1 text-[11px] font-semibold bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-md cursor-pointer transition"
              >
                {isNe ? 'फिल्टर हटाउनुहोस् (सबै महिना)' : 'Reset Month'}
              </button>
            )}
          </div>

          {/* Search box */}
          <div className="relative w-full md:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isNe ? 'बिल नं., पार्टी नाम वा प्यान खोज्नुहोस्...' : 'Search bill no, party, PAN...'}
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-600"
            />
          </div>
        </div>

        {/* 12 Nepali Month Interactive Selector Bar (बैशाख देखि चैत) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <button
            onClick={() => setSelectedMonth('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer border ${
              selectedMonth === 'ALL'
                ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
            }`}
          >
            {isNe ? 'सबै १२ महिना' : 'All Months'}
          </button>

          {monthlyBreakdown.map((m) => {
            const hasActivity = m.salesCount > 0 || m.purchaseCount > 0;
            const isSelected = selectedMonth === m.monthCode;
            return (
              <button
                key={m.monthCode}
                onClick={() => setSelectedMonth(m.monthCode)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer border flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                    : hasActivity
                    ? 'bg-emerald-50/70 text-emerald-950 border-emerald-200 hover:bg-emerald-100/70'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <span>{isNe ? m.monthNameNe : m.monthNameEn}</span>
                {hasActivity && (
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-bold ${
                      isSelected ? 'bg-white text-emerald-900' : 'bg-emerald-200/80 text-emerald-900'
                    }`}
                  >
                    {isNe ? toNepaliDigits(m.salesCount + m.purchaseCount) : m.salesCount + m.purchaseCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Month / Period Instant Kharid-Bikri KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Card 1: Monthly Sales Summary */}
        <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-blue-900">
              {isNe ? `कुल बिक्री (${selectedMonthLabel})` : `Total Sales (${selectedMonthLabel})`}
            </span>
            <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-blue-100 text-blue-900 rounded">
              {isNe ? `${toNepaliDigits(filteredInvoices.length)} बिल` : `${filteredInvoices.length} Bills`}
            </span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 tabular-nums">
            {formatCurrency(totalSalesGrand, isNe)}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-600 pt-1 border-t border-slate-100 font-mono">
            <span>{isNe ? 'करयोग्य:' : 'Taxable:'} {formatCurrency(totalSalesTaxable, isNe)}</span>
            <span className="font-bold text-blue-800">
              {isNe ? 'भ्याट:' : 'VAT:'} {formatCurrency(totalSalesVat, isNe)}
            </span>
          </div>
        </div>

        {/* Card 2: Monthly Purchase Summary */}
        <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-900">
              {isNe ? `कुल खरिद (${selectedMonthLabel})` : `Total Purchase (${selectedMonthLabel})`}
            </span>
            <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-emerald-100 text-emerald-900 rounded">
              {isNe ? `${toNepaliDigits(filteredPurchases.length)} बिल` : `${filteredPurchases.length} Bills`}
            </span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 tabular-nums">
            {formatCurrency(totalPurGrand, isNe)}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-600 pt-1 border-t border-slate-100 font-mono">
            <span>{isNe ? 'करयोग्य:' : 'Taxable:'} {formatCurrency(totalPurTaxable, isNe)}</span>
            <span className="font-bold text-emerald-800">
              {isNe ? 'भ्याट:' : 'VAT:'} {formatCurrency(totalPurVat, isNe)}
            </span>
          </div>
        </div>

        {/* Card 3: Kharid-Bikri Net Difference */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700">
              {isNe ? 'खरिद–बिक्री खुद अन्तर' : 'Sales vs Purchase Margin'}
            </span>
            {netTradeBalance >= 0 ? (
              <TrendingUp className="w-4 h-4 text-emerald-600" />
            ) : (
              <TrendingDown className="w-4 h-4 text-amber-600" />
            )}
          </div>
          <div
            className={`text-xl font-bold font-mono tabular-nums ${
              netTradeBalance >= 0 ? 'text-emerald-800' : 'text-amber-800'
            }`}
          >
            {formatCurrency(Math.abs(netTradeBalance), isNe)}
          </div>
          <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-100">
            {netTradeBalance >= 0
              ? isNe
                ? 'खरिद भन्दा बिक्री बढी (सकारात्मक व्यापार)'
                : 'Sales exceed purchases in period'
              : isNe
              ? 'बिक्री भन्दा खरिद/स्टक लगानी बढी'
              : 'Purchases exceed sales in period'}
          </div>
        </div>

        {/* Card 4: Net VAT Payable / Credit */}
        <div
          className={`p-4 rounded-xl border shadow-xs space-y-1.5 ${
            netVat >= 0 ? 'bg-purple-50/70 border-purple-200' : 'bg-amber-50/70 border-amber-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">
              {netVat >= 0
                ? isNe
                  ? 'खुद भ्याट तिर्नुपर्ने (Payable)'
                  : 'Net VAT Payable to IRD'
                : isNe
                ? 'भ्याट क्रेडिट (Receivable)'
                : 'Net VAT Credit Carryover'}
            </span>
            <Scale className="w-4 h-4 text-purple-800" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-950 tabular-nums">
            {formatCurrency(Math.abs(netVat), isNe)}
          </div>
          <div className="text-[11px] text-slate-600 pt-1 border-t border-slate-200/60 font-mono">
            {isNe ? 'बिक्री भ्याट - खरिद भ्याट' : 'Output VAT (13%) - Input VAT (13%)'}
          </div>
        </div>
      </div>

      {/* Main Tabs Selector */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 rounded-xl w-full sm:w-fit flex-wrap">
        <button
          onClick={() => setActiveTab('SUMMARY')}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
            activeTab === 'SUMMARY'
              ? 'bg-white text-emerald-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Scale className="w-4 h-4 text-emerald-700" />
          <span>
            {isNe
              ? 'मासिक खरिद–बिक्री तथा भ्याट सारांश (Monthly Summary)'
              : 'Monthly Purchase & Sales Summary'}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('SALES')}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
            activeTab === 'SALES'
              ? 'bg-white text-emerald-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Receipt className="w-4 h-4 text-blue-700" />
          <span>
            {t.tabSalesBook} ({isNe ? toNepaliDigits(filteredInvoices.length) : filteredInvoices.length})
          </span>
        </button>

        <button
          onClick={() => setActiveTab('PURCHASE')}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
            activeTab === 'PURCHASE'
              ? 'bg-white text-emerald-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <ShoppingCart className="w-4 h-4 text-emerald-700" />
          <span>
            {t.tabPurchaseBook} ({isNe ? toNepaliDigits(filteredPurchases.length) : filteredPurchases.length})
          </span>
        </button>

        <button
          onClick={() => setActiveTab('PARTY_VAT')}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
            activeTab === 'PARTY_VAT'
              ? 'bg-white text-emerald-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="w-4 h-4 text-emerald-700" />
          <span>{isNe ? 'पार्टी अनुसार VAT रिपोर्ट' : 'Party-wise VAT Report'}</span>
        </button>

        <button
          onClick={() => setActiveTab('PARTY_CONFIRMATION')}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
            activeTab === 'PARTY_CONFIRMATION'
              ? 'bg-white text-emerald-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="w-4 h-4 text-purple-700" />
          <span>
            {isNe ? '🤝 पार्टी कन्फर्मेसन पत्र (Party Confirmation)' : '🤝 Party VAT Confirmation'}
          </span>
        </button>
      </div>

      {/* TAB 1: MONTHLY KHARID-BIKRI & VAT SUMMARY REPORT */}
      {activeTab === 'SUMMARY' && (
        <div data-print-target className="space-y-5">
          {/* Section A: 12-Month Kharid-Bikri & VAT Summary Table */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50">
              <div>
                <h2 className="text-sm sm:text-base font-bold text-slate-900">
                  {isNe
                    ? 'मासिक खरिद–बिक्री तथा भ्याट विवरण सारांश तालिका (बैशाख देखि चैत)'
                    : 'Month-by-Month Purchase, Sales & VAT Summary Report (Baisakh to Chaitra)'}
                </h2>
                <p className="text-[11px] text-slate-500 mt-0.5 font-mono">
                  {isNe
                    ? `फर्म: ${company.name} · प्यान नं: ${company.panVatNo} · कुनै पनि महिनामा क्लिक गरी सो महिनाको बिलहरू हेर्नुहोस्`
                    : `Company: ${company.name} · PAN: ${company.panVatNo} · Click any month row to inspect bills`}
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => setShowOnlyActiveMonths((prev) => !prev)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                    showOnlyActiveMonths
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  <Filter className="w-3.5 h-3.5" />
                  <span>
                    {showOnlyActiveMonths
                      ? isNe
                        ? 'सबै १२ महिना देखाउनुहोस्'
                        : 'Show All 12 Months'
                      : isNe
                      ? 'कारोबार भएका महिना मात्र'
                      : 'Active Months Only'}
                  </span>
                </button>

                <button
                  onClick={() => printPage()}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{isNe ? 'प्रिन्ट रिपोर्ट' : 'Print'}</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-300 text-slate-800 font-bold">
                    <th rowSpan={2} className="py-2.5 px-3 border-r border-slate-200">
                      {isNe ? 'महिना (Month)' : 'Month'}
                    </th>
                    <th
                      colSpan={4}
                      className="py-2 px-3 text-center bg-blue-50/80 text-blue-950 border-r border-slate-200"
                    >
                      {isNe ? 'बिक्री विवरण (Sales - अनुसूची ५)' : 'Sales Summary (Anusuchi 5)'}
                    </th>
                    <th
                      colSpan={4}
                      className="py-2 px-3 text-center bg-emerald-50/80 text-emerald-950 border-r border-slate-200"
                    >
                      {isNe ? 'खरिद विवरण (Purchase - अनुसूची ८)' : 'Purchase Summary (Anusuchi 8)'}
                    </th>
                    <th
                      colSpan={2}
                      className="py-2 px-3 text-center bg-purple-50/80 text-purple-950"
                    >
                      {isNe ? 'मासिक भ्याट मिलान' : 'VAT Reconciliation'}
                    </th>
                  </tr>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] text-slate-700 font-bold">
                    {/* Sales columns */}
                    <th className="py-2 px-2.5 text-center bg-blue-50/40">{isNe ? 'बिल' : 'Bills'}</th>
                    <th className="py-2 px-2.5 text-right bg-blue-50/40">{isNe ? 'करयोग्य बिक्री' : 'Taxable'}</th>
                    <th className="py-2 px-2.5 text-right bg-blue-50/40">{isNe ? '१३% भ्याट' : '13% VAT'}</th>
                    <th className="py-2 px-2.5 text-right bg-blue-50/40 border-r border-slate-200">
                      {isNe ? 'कुल बिक्री' : 'Total Sales'}
                    </th>

                    {/* Purchase columns */}
                    <th className="py-2 px-2.5 text-center bg-emerald-50/40">{isNe ? 'बिल' : 'Bills'}</th>
                    <th className="py-2 px-2.5 text-right bg-emerald-50/40">{isNe ? 'करयोग्य खरिद' : 'Taxable'}</th>
                    <th className="py-2 px-2.5 text-right bg-emerald-50/40">{isNe ? '१३% भ्याट' : '13% VAT'}</th>
                    <th className="py-2 px-2.5 text-right bg-emerald-50/40 border-r border-slate-200">
                      {isNe ? 'कुल खरिद' : 'Total Purchase'}
                    </th>

                    {/* Net VAT & Action */}
                    <th className="py-2 px-2.5 text-right bg-purple-50/40">
                      {isNe ? 'खुद भ्याट (Payable/Credit)' : 'Net VAT'}
                    </th>
                    <th className="py-2 px-2.5 text-center bg-purple-50/40">{isNe ? 'हेर्नुहोस्' : 'View'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {displayedMonthlyRows.length === 0 ? (
                    <tr>
                      <td colSpan={11} className="py-8 text-center text-slate-400">
                        {isNe ? 'छानिएको वर्षमा कुनै खरिद वा बिक्री रेकर्ड भेटिएन।' : 'No monthly records found.'}
                      </td>
                    </tr>
                  ) : (
                    displayedMonthlyRows.map((row) => {
                      const isRowSelected = selectedMonth === row.monthCode;
                      const hasData = row.salesCount > 0 || row.purchaseCount > 0;
                      return (
                        <tr
                          key={row.monthCode}
                          onClick={() => setSelectedMonth(row.monthCode)}
                          className={`transition cursor-pointer ${
                            selectedMonthCodes.length > 0 && !selectedMonthCodes.includes(row.monthCode) ? 'no-print ' : ''
                          }${
                            isRowSelected
                              ? 'bg-emerald-50/90 font-semibold'
                              : hasData
                              ? 'hover:bg-slate-50'
                              : 'text-slate-400 hover:bg-slate-50/50'
                          }`}
                        >
                          <td className="py-2.5 px-3 border-r border-slate-100 font-bold text-slate-900 whitespace-nowrap">
                            <input
                              type="checkbox"
                              checked={selectedMonthCodes.includes(row.monthCode)}
                              onClick={(e) => e.stopPropagation()}
                              onChange={() => toggleMonthCode(row.monthCode)}
                              className="w-4 h-4 rounded cursor-pointer mr-2 align-middle"
                              title={isNe ? 'प्रिन्टका लागि छान्नुहोस्' : 'Select for print'}
                            />
                            <span className="font-mono text-slate-500 mr-1.5">
                              {isNe ? toNepaliDigits(row.monthCode) : row.monthCode}.
                            </span>
                            <span>{isNe ? row.monthNameNe : row.monthNameEn}</span>
                          </td>

                          {/* Sales Data */}
                          <td className="py-2.5 px-2.5 text-center font-mono">
                            {row.salesCount > 0
                              ? isNe
                                ? toNepaliDigits(row.salesCount)
                                : row.salesCount
                              : '-'}
                          </td>
                          <td className="py-2.5 px-2.5 text-right font-mono tabular-nums">
                            {row.salesTaxable > 0 ? row.salesTaxable.toFixed(2) : '-'}
                          </td>
                          <td className="py-2.5 px-2.5 text-right font-mono tabular-nums font-semibold text-blue-900">
                            {row.salesVat > 0 ? row.salesVat.toFixed(2) : '-'}
                          </td>
                          <td className="py-2.5 px-2.5 text-right font-mono tabular-nums font-bold text-slate-900 border-r border-slate-100">
                            {row.salesGrand > 0 ? row.salesGrand.toFixed(2) : '-'}
                          </td>

                          {/* Purchase Data */}
                          <td className="py-2.5 px-2.5 text-center font-mono">
                            {row.purchaseCount > 0
                              ? isNe
                                ? toNepaliDigits(row.purchaseCount)
                                : row.purchaseCount
                              : '-'}
                          </td>
                          <td className="py-2.5 px-2.5 text-right font-mono tabular-nums">
                            {row.purchaseTaxable > 0 ? row.purchaseTaxable.toFixed(2) : '-'}
                          </td>
                          <td className="py-2.5 px-2.5 text-right font-mono tabular-nums font-semibold text-emerald-800">
                            {row.purchaseVat > 0 ? row.purchaseVat.toFixed(2) : '-'}
                          </td>
                          <td className="py-2.5 px-2.5 text-right font-mono tabular-nums font-bold text-slate-900 border-r border-slate-100">
                            {row.purchaseGrand > 0 ? row.purchaseGrand.toFixed(2) : '-'}
                          </td>

                          {/* Net VAT */}
                          <td className="py-2.5 px-2.5 text-right font-mono tabular-nums font-bold">
                            {!hasData ? (
                              '-'
                            ) : (
                              <span
                                className={`px-2 py-0.5 rounded text-[11px] ${
                                  row.netVat >= 0
                                    ? 'bg-purple-100 text-purple-900'
                                    : 'bg-amber-100 text-amber-900'
                                }`}
                              >
                                {row.netVat >= 0 ? '+' : '-'}
                                {Math.abs(row.netVat).toFixed(2)}
                              </span>
                            )}
                          </td>

                          <td className="py-2.5 px-2.5 text-center">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedMonth(row.monthCode);
                              }}
                              className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded border border-emerald-200 cursor-pointer"
                            >
                              <Eye className="w-3 h-3" />
                              <span>{isNe ? 'विवरण' : 'Inspect'}</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
                <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300 text-slate-900">
                  <tr>
                    <td className="py-3 px-3 border-r border-slate-200">
                      {useSelM ? (isNe ? 'छानिएका महिनाको जम्मा:' : 'Selected months total:') : isNe ? 'वार्षिक कुल जम्मा (Total):' : 'Annual Grand Total:'}
                    </td>
                    <td className="py-3 px-2.5 text-center font-mono">
                      {isNe
                        ? toNepaliDigits(useSelM ? sm((r) => r.salesCount) : yearFilteredInvoices.length)
                        : useSelM ? sm((r) => r.salesCount) : yearFilteredInvoices.length}
                    </td>
                    <td className="py-3 px-2.5 text-right font-mono tabular-nums">
                      {(useSelM ? sm((r) => r.salesTaxable) : yearFilteredInvoices.reduce((s, i) => s + i.taxableAmount, 0)).toFixed(2)}
                    </td>
                    <td className="py-3 px-2.5 text-right font-mono tabular-nums text-blue-900">
                      {(useSelM ? sm((r) => r.salesVat) : yearFilteredInvoices.reduce((s, i) => s + i.vatAmount, 0)).toFixed(2)}
                    </td>
                    <td className="py-3 px-2.5 text-right font-mono tabular-nums text-blue-950 border-r border-slate-200">
                      {(useSelM ? sm((r) => r.salesGrand) : yearFilteredInvoices.reduce((s, i) => s + i.grandTotal, 0)).toFixed(2)}
                    </td>

                    <td className="py-3 px-2.5 text-center font-mono">
                      {isNe
                        ? toNepaliDigits(useSelM ? sm((r) => r.purchaseCount) : yearFilteredPurchases.length)
                        : useSelM ? sm((r) => r.purchaseCount) : yearFilteredPurchases.length}
                    </td>
                    <td className="py-3 px-2.5 text-right font-mono tabular-nums">
                      {(useSelM ? sm((r) => r.purchaseTaxable) : yearFilteredPurchases.reduce((s, p) => s + p.taxableAmount, 0)).toFixed(2)}
                    </td>
                    <td className="py-3 px-2.5 text-right font-mono tabular-nums text-emerald-800">
                      {(useSelM ? sm((r) => r.purchaseVat) : yearFilteredPurchases.reduce((s, p) => s + p.vatAmount, 0)).toFixed(2)}
                    </td>
                    <td className="py-3 px-2.5 text-right font-mono tabular-nums text-emerald-950 border-r border-slate-200">
                      {(useSelM ? sm((r) => r.purchaseGrand) : yearFilteredPurchases.reduce((s, p) => s + p.grandTotal, 0)).toFixed(2)}
                    </td>

                    <td colSpan={2} className="py-3 px-3 text-right font-mono tabular-nums text-purple-950">
                      {(
                        useSelM
                          ? sm((r) => r.salesVat) - sm((r) => r.purchaseVat)
                          : yearFilteredInvoices.reduce((s, i) => s + i.vatAmount, 0) -
                            yearFilteredPurchases.reduce((s, p) => s + p.vatAmount, 0)
                      ).toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Section B: Side-by-Side Monthly Kharid & Bikri Detailed Breakdown for Selected Month */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Left: Selected Month Sales Bills */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="px-4 py-3 bg-blue-50/70 border-b border-blue-200 flex items-center justify-between">
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-blue-950">
                    {isNe
                      ? `बिक्री बिल सारांश (${selectedMonthLabel})`
                      : `Sales Bills (${selectedMonthLabel})`}
                  </h3>
                  <p className="text-[11px] text-blue-800">
                    {isNe
                      ? `जम्मा ${toNepaliDigits(filteredInvoices.length)} बिल · भ्याट छुट: ${formatCurrency(totalSalesExempt, isNe)}`
                      : `${filteredInvoices.length} bills · Exempt: ${formatCurrency(totalSalesExempt, isNe)}`}
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('SALES')}
                  className="px-2.5 py-1 text-[11px] font-bold bg-white text-blue-900 rounded border border-blue-200 hover:bg-blue-100 cursor-pointer"
                >
                  {isNe ? 'पूर्ण बिक्री खाता हेर्नुहोस्' : 'Open Sales Book'}
                </button>
              </div>

              {filteredInvoices.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  {isNe ? 'यस महिनामा कुनै बिक्री बिल छैन।' : 'No sales bills in this period.'}
                </div>
              ) : (
                <div className="overflow-x-auto max-h-72">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-bold sticky top-0">
                      <tr>
                        <th className="py-2 px-3">{isNe ? 'मिति' : 'Date'}</th>
                        <th className="py-2 px-3">{isNe ? 'बिल नं.' : 'Invoice'}</th>
                        <th className="py-2 px-3">{isNe ? 'ग्राहक' : 'Customer'}</th>
                        <th className="py-2 px-3 text-right">{isNe ? '१३% भ्याट' : 'VAT'}</th>
                        <th className="py-2 px-3 text-right">{isNe ? 'जम्मा' : 'Total'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredInvoices.map((inv) => (
                        <tr key={inv.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono text-slate-600">{inv.dateBs}</td>
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{inv.invoiceNo}</td>
                          <td className="py-2 px-3 text-slate-800 truncate max-w-[140px]">{inv.customerName}</td>
                          <td className="py-2 px-3 text-right font-mono text-blue-800">{inv.vatAmount.toFixed(2)}</td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">
                            {inv.grandTotal.toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Right: Selected Month Purchase Bills */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="px-4 py-3 bg-emerald-50/70 border-b border-emerald-200 flex items-center justify-between">
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-emerald-950">
                    {isNe
                      ? `खरिद बिल सारांश (${selectedMonthLabel})`
                      : `Purchase Bills (${selectedMonthLabel})`}
                  </h3>
                  <p className="text-[11px] text-emerald-800">
                    {isNe
                      ? `जम्मा ${toNepaliDigits(filteredPurchases.length)} बिल · भ्याट छुट: ${formatCurrency(totalPurExempt, isNe)}`
                      : `${filteredPurchases.length} bills · Exempt: ${formatCurrency(totalPurExempt, isNe)}`}
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('PURCHASE')}
                  className="px-2.5 py-1 text-[11px] font-bold bg-white text-emerald-900 rounded border border-emerald-200 hover:bg-emerald-100 cursor-pointer"
                >
                  {isNe ? 'पूर्ण खरिद खाता हेर्नुहोस्' : 'Open Purchase Book'}
                </button>
              </div>

              {filteredPurchases.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  {isNe ? 'यस महिनामा कुनै खरिद बिल छैन।' : 'No purchase bills in this period.'}
                </div>
              ) : (
                <div className="overflow-x-auto max-h-72">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-bold sticky top-0">
                      <tr>
                        <th className="py-2 px-3">{isNe ? 'मिति' : 'Date'}</th>
                        <th className="py-2 px-3">{isNe ? 'बिल नं.' : 'Bill No'}</th>
                        <th className="py-2 px-3">{isNe ? 'आपूर्तिकर्ता' : 'Supplier'}</th>
                        <th className="py-2 px-3 text-right">{isNe ? '१३% भ्याट' : 'VAT'}</th>
                        <th className="py-2 px-3 text-right">{isNe ? 'जम्मा' : 'Total'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredPurchases.map((pur) => (
                        <tr key={pur.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono text-slate-600">{pur.dateBs}</td>
                          <td className="py-2 px-3 font-mono font-semibold text-slate-900">{pur.purchaseBillNo}</td>
                          <td className="py-2 px-3 text-slate-800 truncate max-w-[140px]">{pur.supplierName}</td>
                          <td className="py-2 px-3 text-right font-mono text-emerald-800">{pur.vatAmount.toFixed(2)}</td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">
                            {pur.grandTotal.toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SALES BOOK (अनुसूची ५ - बिक्री खाता) */}
      {activeTab === 'SALES' && (
        <div data-print-target className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs space-y-4">
          <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                अनुसूची-५ (नियम २३ को उपनियम (१) को खण्ड (छ) सँग सम्बन्धित) - बिक्री खाता ({selectedMonthLabel})
              </h2>
              <p className="text-[11px] text-slate-500 font-mono">
                करदाताको नाम: {company.name} · प्यान नं: {company.panVatNo} · आ.व.: {company.fiscalYear}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-xs font-mono font-bold text-slate-700">
                कुल रेकर्ड: {isNe ? toNepaliDigits(filteredInvoices.length) : filteredInvoices.length}
              </div>
              {filteredInvoices.length > 0 && (
                <button
                  type="button"
                  onClick={handleToggleSelectAllInvoices}
                  className="px-2.5 py-1 text-[11px] font-bold bg-slate-200 hover:bg-slate-300 text-slate-800 rounded transition cursor-pointer"
                >
                  {isAllInvoicesSelected ? (isNe ? 'छनौट हटाउनुहोस्' : 'Deselect All') : (isNe ? 'सबै छान्नुहोस्' : 'Select All')}
                </button>
              )}
            </div>
          </div>

          {/* Sticky Batch Print Action Bar */}
          {selectedInvoiceIds.length > 0 && (
            <div className="mx-4 p-3 bg-slate-900 text-white rounded-xl flex flex-wrap items-center justify-between gap-3 shadow-md border border-slate-700">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-400" />
                <span className="text-xs sm:text-sm font-bold">
                  {isNe
                    ? `✓ ${toNepaliDigits(selectedInvoiceIds.length)} वटा बिक्री बिलहरू छानिएका छन्`
                    : `✓ ${selectedInvoiceIds.length} Sales Invoices Selected`}
                </span>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setIsBatchPrintOpen(true)}
                  className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-lg shadow-xs transition cursor-pointer flex items-center gap-1.5 active:scale-95"
                >
                  <Printer className="w-4 h-4 text-slate-950" />
                  <span>{isNe ? '🖨️ एकैसाथ प्रिन्ट गर्नुहोस् (Batch Print)' : 'Batch Print Selected'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsBatchPrintOpen(true)}
                  className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg shadow-xs transition cursor-pointer flex items-center gap-1.5 active:scale-95"
                >
                  <FileDown className="w-4 h-4 text-white" />
                  <span>{isNe ? '📄 बैच PDF डाउनलोड' : 'Batch PDF Download'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedInvoiceIds([])}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
                >
                  {isNe ? 'हटाउनुहोस् (Clear)' : 'Clear Selection'}
                </button>
              </div>
            </div>
          )}

          {filteredInvoices.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-xs">
              {isNe
                ? 'छानिएको महिनामा बिक्री खातामा कुनै रेकर्ड छैन।'
                : 'No sales records found for the selected month.'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold">
                  <tr>
                    <th className="py-2.5 px-3 w-10 text-center">
                      <input
                        type="checkbox"
                        checked={isAllInvoicesSelected}
                        onChange={handleToggleSelectAllInvoices}
                        className="w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer"
                        title={isNe ? 'सबै बिलहरू छान्नुहोस्' : 'Select All Invoices'}
                      />
                    </th>
                    <th className="py-2.5 px-3">मिति (B.S.)</th>
                    <th className="py-2.5 px-3">बीजक नं. (Invoice No)</th>
                    <th className="py-2.5 px-3">खरिदकर्ताको नाम (Buyer)</th>
                    <th className="py-2.5 px-3">प्यान नं. (PAN)</th>
                    <th className="py-2.5 px-3 text-right">कुल बिक्री (Total)</th>
                    <th className="py-2.5 px-3 text-right">कर छुट (Exempt)</th>
                    <th className="py-2.5 px-3 text-right">करयोग्य (Taxable)</th>
                    <th className="py-2.5 px-3 text-right">१३% भ्याट (VAT)</th>
                    <th className="py-2.5 px-3 text-center">कार्य (Action)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredInvoices.map((inv) => {
                    const isSelected = selectedInvoiceIds.includes(inv.id);
                    return (
                      <tr
                        key={inv.id}
                        className={`hover:bg-slate-50/70 transition ${
                          isSelected ? 'bg-emerald-50/70 font-medium' : ''
                        } ${selectedInvoiceIds.length > 0 && !isSelected ? 'no-print' : ''}`}
                      >
                        <td className="py-2.5 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleSelectInvoice(inv.id)}
                            className="w-4 h-4 rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 cursor-pointer"
                          />
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-600">{inv.dateBs}</td>
                        <td className="py-2.5 px-3 font-mono font-medium text-slate-900">{inv.invoiceNo}</td>
                        <td className="py-2.5 px-3 text-slate-800">{inv.customerName}</td>
                        <td className="py-2.5 px-3 font-mono text-slate-600">{inv.customerPan || '-'}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold">
                          {inv.grandTotal.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                          {inv.exemptAmount.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                          {inv.taxableAmount.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-blue-900">
                          {inv.vatAmount.toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setViewInvoice(inv)}
                              title={isNe ? 'बीजक प्रिन्ट वा PDF हेर्नुहोस्' : 'Print / View Invoice'}
                              className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-[10px] font-bold cursor-pointer inline-flex items-center gap-1 shadow-2xs transition active:scale-95"
                            >
                              <Printer className="w-3 h-3" />
                              <span>{isNe ? '📄 प्रिन्ट/PDF' : 'Print/PDF'}</span>
                            </button>
                            {inv.status === 'ACTIVE' && (
                              <button
                                type="button"
                                onClick={() => startEditInvoice(inv.id)}
                                title="बिल सच्याउनुहोस् (सामान सहित, Owner Key अनिवार्य)"
                                className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded text-[10px] font-bold cursor-pointer inline-flex items-center gap-1"
                              >
                                <span>✏️</span>
                                <span>सच्याउने</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => cancelInvoice(inv.id)}
                              title="बिल रद्द / मेटाउने (Owner Key अनिवार्य)"
                              className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded text-[10px] font-bold cursor-pointer inline-flex items-center gap-1"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>रद्द</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteInvoice(inv.id)}
                              title="बिल सदाको लागि मेटाउने (Owner Key अनिवार्य)"
                              className="px-2 py-1 bg-rose-700 hover:bg-rose-800 text-white rounded text-[10px] font-bold cursor-pointer inline-flex items-center gap-1"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>मेटाउने</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300">
                  <tr>
                    <td colSpan={5} className="py-3 px-3 text-right text-slate-900">
                      {selectedInvoiceIds.length > 0 ? (isNe ? 'छानिएको जम्मा:' : 'Selected total:') : `जम्मा (${selectedMonthLabel}):`}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-800 text-sm">
                      {rsGrand.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {rsExempt.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {rsTaxable.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-blue-900 text-sm">
                      {rsVat.toFixed(2)}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: PURCHASE BOOK (अनुसूची ८) */}
      {activeTab === 'PURCHASE' && (
        <div data-print-target className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs space-y-4">
          <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-50">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                अनुसूची-८ (नियम २३ को उपनियम (१) को खण्ड (ज) सँग सम्बन्धित) - खरिद खाता ({selectedMonthLabel})
              </h2>
              <p className="text-[11px] text-slate-500 font-mono">
                करदाताको नाम: {company.name} · प्यान नं: {company.panVatNo} · आ.व.: {company.fiscalYear}
              </p>
            </div>
            <div className="text-xs font-mono font-bold text-slate-700">
              कुल खरिद रेकर्ड: {isNe ? toNepaliDigits(filteredPurchases.length) : filteredPurchases.length}
            </div>
          </div>

          {filteredPurchases.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-xs">
              {isNe
                ? 'छानिएको महिनामा खरिद खातामा कुनै रेकर्ड छैन। माथिबाट "नयाँ खरिद प्रविष्टि" थिच्नुहोस्।'
                : 'No purchase records in Anusuchi 8 for the selected month.'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-bold">
                  <tr>
                    <th className="py-2.5 px-3 w-10 text-center">
                      <input
                        type="checkbox"
                        checked={isAllPurSelected}
                        onChange={() => setSelectedPurchaseIds(isAllPurSelected ? [] : filteredPurchases.map((p) => p.id))}
                        className="w-4 h-4 rounded cursor-pointer"
                        title={isNe ? 'सबै छान्नुहोस्' : 'Select all'}
                      />
                    </th>
                    <th className="py-2.5 px-3">मिति (B.S.)</th>
                    <th className="py-2.5 px-3">खरिद बीजक नं. (Bill No)</th>
                    <th className="py-2.5 px-3">आपूर्तिकर्ता (Supplier)</th>
                    <th className="py-2.5 px-3">प्यान नं. (PAN)</th>
                    <th className="py-2.5 px-3">विवरण (Items)</th>
                    <th className="py-2.5 px-3 text-right">कुल खरिद (Total)</th>
                    <th className="py-2.5 px-3 text-right">कर छुट (Exempt)</th>
                    <th className="py-2.5 px-3 text-right">करयोग्य रकम (Taxable)</th>
                    <th className="py-2.5 px-3 text-right">१३% इनपुट भ्याट (Input VAT)</th>
                    <th className="py-2.5 px-3 text-center">कार्य (Action)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredPurchases.map((pur) => (
                    <tr
                      key={pur.id}
                      className={`hover:bg-slate-50/70 ${selectedPurchaseIds.includes(pur.id) ? 'bg-emerald-50/70' : ''} ${
                        selectedPurchaseIds.length > 0 && !selectedPurchaseIds.includes(pur.id) ? 'no-print' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 text-center">
                        <input
                          type="checkbox"
                          checked={selectedPurchaseIds.includes(pur.id)}
                          onChange={() => togglePurchase(pur.id)}
                          className="w-4 h-4 rounded cursor-pointer"
                        />
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-600">{pur.dateBs}</td>
                      <td className="py-2.5 px-3 font-mono font-medium text-slate-900">{pur.purchaseBillNo}</td>
                      <td className="py-2.5 px-3 text-slate-800">{pur.supplierName}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-600">{pur.supplierPan || '-'}</td>
                      <td className="py-2.5 px-3 text-slate-600 max-w-[180px] truncate">{pur.itemsSummary || '-'}</td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold">
                        {pur.grandTotal.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                        {pur.exemptAmount.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                        {pur.taxableAmount.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-emerald-800">
                        {pur.vatAmount.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-center flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => triggerQuickDispatch(pur.id, 'PURCHASE')}
                          title={isNe ? 'यो खरिद बिलबाट चलानी बनाउनुहोस्' : 'Create dispatch from this bill'}
                          className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded text-[10px] font-bold cursor-pointer inline-flex items-center gap-1"
                        >
                          <Truck className="w-3 h-3" />
                          <span>चलानी</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => deletePurchase(pur.id)}
                          title="खरिद बिल मेटाउने (Owner Key अनिवार्य)"
                          className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded text-[10px] font-bold cursor-pointer inline-flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>हटाउने</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300">
                  <tr>
                    <td colSpan={6} className="py-3 px-3 text-right text-slate-900">
                      {selectedPurchaseIds.length > 0 ? (isNe ? 'छानिएको जम्मा:' : 'Selected total:') : `जम्मा (${selectedMonthLabel}):`}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-900 text-sm">
                      {rpGrand.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {rpExempt.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">
                      {rpTaxable.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-800 text-sm">
                      {rpVat.toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: PARTY VAT CONFIRMATION LETTER (अनुसूची १३ / पार्टी खरिद-बिक्री कन्फर्मेसन पत्र) */}
      {/* TAB: PARTY-WISE VAT REPORT (VAT / exempt, sales / purchase, per party, per month) */}
      {activeTab === 'PARTY_VAT' && (
        <PartyVatReport
          invoices={yearFilteredInvoices}
          purchases={yearFilteredPurchases}
          initialMonth={selectedMonth}
          yearLabel={selectedYear === 'ALL' ? (isNe ? 'सबै' : 'All') : selectedYear}
          isNe={isNe}
          company={company}
        />
      )}

      {activeTab === 'PARTY_CONFIRMATION' && (
        <div data-print-target className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {isNe
                  ? '🤝 वार्षिक खरिद–बिक्री तथा भ्याट कारोबार कन्फर्मेसन पत्र (अनुसूची १३ / Party Confirmation)'
                  : '🤝 Official Party Purchase & Sales VAT Confirmation Letter'}
              </h2>
              <p className="text-xs text-slate-500">
                {isNe
                  ? `छानिएको आर्थिक वर्ष (${selectedYear === 'ALL' ? company.fiscalYear : selectedYear}) मा ग्राहक र आपूर्तिकर्तासँग भएको कुल करयोग्य, कर छुट र १३% भ्याट कारोबार मिलान पत्र`
                  : 'Annual party-wise taxable, tax-exempt and 13% VAT reconciliation statement'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => printPage()}
                className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isNe ? 'कन्फर्मेसन पत्र प्रिन्ट (Print)' : 'Print Confirmation'}</span>
              </button>
            </div>
          </div>

          {(() => {
            const partyMap = new Map<
              string,
              {
                name: string;
                pan: string;
                salesTaxable: number;
                salesExempt: number;
                salesVat: number;
                salesGrand: number;
                purTaxable: number;
                purExempt: number;
                purVat: number;
                purGrand: number;
              }
            >();

            filteredInvoices.forEach((inv) => {
              const key = `${inv.customerName.trim().toLowerCase()}|${inv.customerPan || ''}`;
              const existing = partyMap.get(key) || {
                name: inv.customerName,
                pan: inv.customerPan || '-',
                salesTaxable: 0,
                salesExempt: 0,
                salesVat: 0,
                salesGrand: 0,
                purTaxable: 0,
                purExempt: 0,
                purVat: 0,
                purGrand: 0
              };
              existing.salesTaxable += inv.taxableAmount;
              existing.salesExempt += inv.exemptAmount;
              existing.salesVat += inv.vatAmount;
              existing.salesGrand += inv.grandTotal;
              partyMap.set(key, existing);
            });

            filteredPurchases.forEach((pur) => {
              const key = `${pur.supplierName.trim().toLowerCase()}|${pur.supplierPan || ''}`;
              const existing = partyMap.get(key) || {
                name: pur.supplierName,
                pan: pur.supplierPan || '-',
                salesTaxable: 0,
                salesExempt: 0,
                salesVat: 0,
                salesGrand: 0,
                purTaxable: 0,
                purExempt: 0,
                purVat: 0,
                purGrand: 0
              };
              existing.purTaxable += pur.taxableAmount;
              existing.purExempt += pur.exemptAmount;
              existing.purVat += pur.vatAmount;
              existing.purGrand += pur.grandTotal;
              partyMap.set(key, existing);
            });

            const partyRows = Array.from(partyMap.values());
            const filteredPartyRows =
              selectedConfirmationPartyKey === 'ALL'
                ? partyRows
                : partyRows.filter((r) => `${r.name}|${r.pan}` === selectedConfirmationPartyKey);

            return (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center gap-3">
                  <label className="text-xs font-bold text-slate-700">
                    {isNe ? 'पार्टी छान्नुहोस् (Select Party):' : 'Select Party:'}
                  </label>
                  <select
                    value={selectedConfirmationPartyKey}
                    onChange={(e) => setSelectedConfirmationPartyKey(e.target.value)}
                    className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 bg-white"
                  >
                    <option value="ALL">{isNe ? 'सबै पार्टीको सारांश (All Parties)' : 'All Parties'}</option>
                    {partyRows.map((p, i) => (
                      <option key={i} value={`${p.name}|${p.pan}`}>
                        {p.name} (PAN: {p.pan})
                      </option>
                    ))}
                  </select>
                </div>

                  <div className="border border-slate-300 p-6 bg-white space-y-4 text-[13px] text-slate-900 leading-snug">
                  {/* Letterhead + title (Balance Confirmation Report design) */}
                  <div className="flex justify-between items-start gap-6">
                    <div>
                      <h3 className="text-lg font-bold">{company.name}</h3>
                      {company.address && <p>{company.address}</p>}
                      {company.phone && <p>Phone: {company.phone}</p>}
                      {company.email && <p>{company.email}</p>}
                      {company.panVatNo && <p className="font-semibold">PAN: {company.panVatNo}</p>}
                    </div>
                    <div className="text-center">
                      <h2 className="text-lg font-bold">VAT Transaction Confirmation Report</h2>
                      <p className="text-[12px] font-semibold mt-1">
                        {isNe ? 'आ.व.' : 'F.Y.'} {selectedYear === 'ALL' ? company.fiscalYear : selectedYear} · {selectedMonthLabel}
                      </p>
                    </div>
                  </div>

                  <p>Date: {getTodayBsString()}</p>
                  <div>
                    <p>To,</p>
                    <p>The Manager</p>
                    {selectedConfirmationPartyKey !== 'ALL' && filteredPartyRows[0] && (
                      <div className="grid grid-cols-[70px_1fr] gap-y-1 mt-1">
                        <span>Party:</span><span className="font-semibold">{filteredPartyRows[0].name}</span>
                        <span>PAN:</span><span className="font-semibold">{filteredPartyRows[0].pan}</span>
                      </div>
                    )}
                  </div>

                  <p className="font-semibold">Subject: VAT TRANSACTION CONFIRMATION LETTER (अनुसूची १३)</p>
                  <p>Dear Sir/Madam,</p>
                  <p>
                    With reference to above, we are sending you the following information regarding VAT transactions (sales &amp; purchase) for your confirmation.
                  </p>

                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border-collapse bg-white">
                      <thead>
                        <tr className="bg-slate-800 text-white font-bold">
                          <th className="py-2 px-2 text-left">क्र.सं.</th>
                          <th className="py-2 px-2 text-left">Particulars (Party Name)</th>
                          <th className="py-2 px-2 text-left">PAN/VAT</th>
                          <th className="py-2 px-2 text-right">Taxable Sales</th>
                          <th className="py-2 px-2 text-right">Exempt Sales</th>
                          <th className="py-2 px-2 text-right">Sales VAT</th>
                          <th className="py-2 px-2 text-right">Total Sales</th>
                          <th className="py-2 px-2 text-right">Taxable Purchase</th>
                          <th className="py-2 px-2 text-right">Exempt Purchase</th>
                          <th className="py-2 px-2 text-right">Purchase VAT</th>
                          <th className="py-2 px-2 text-right">Total Purchase</th>
                          <th className="py-2 px-2 no-print"></th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredPartyRows.map((r, idx) => (
                          <tr key={idx} className="border-b border-dotted border-slate-500">
                            <td className="py-2 px-2 font-mono">{idx + 1}</td>
                            <td className="py-2 px-2 font-semibold">{r.name}</td>
                            <td className="py-2 px-2 font-mono">{r.pan}</td>
                            <td className="py-2 px-2 text-right font-mono">{r.salesTaxable.toFixed(2)}</td>
                            <td className="py-2 px-2 text-right font-mono">{r.salesExempt.toFixed(2)}</td>
                            <td className="py-2 px-2 text-right font-mono">{r.salesVat.toFixed(2)}</td>
                            <td className="py-2 px-2 text-right font-mono font-bold">{(r.salesTaxable + r.salesExempt + r.salesVat).toFixed(2)}</td>
                            <td className="py-2 px-2 text-right font-mono">{r.purTaxable.toFixed(2)}</td>
                            <td className="py-2 px-2 text-right font-mono">{r.purExempt.toFixed(2)}</td>
                            <td className="py-2 px-2 text-right font-mono">{r.purVat.toFixed(2)}</td>
                            <td className="py-2 px-2 text-right font-mono font-bold">{(r.purTaxable + r.purExempt + r.purVat).toFixed(2)}</td>
                            <td className="py-2 px-2 no-print">
                              <button
                                type="button"
                                onClick={() => {
                                  const found = parties.find((pp) => pp.name.trim().toLowerCase() === r.name.trim().toLowerCase());
                                  setConfirmParty(
                                    found || ({ id: '', name: r.name, panNo: r.pan === '-' ? '' : r.pan, address: '', openingBalance: 0, currentBalance: 0 } as Party)
                                  );
                                }}
                                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded text-[10px] font-bold cursor-pointer whitespace-nowrap"
                              >
                                {isNe ? 'ब्यालेन्स पत्र' : 'Balance Letter'}
                              </button>
                            </td>
                          </tr>
                        ))}
                        <tr className="border-t-2 border-slate-900 font-bold">
                          <td className="py-2 px-2" colSpan={3}>Total</td>
                          <td className="py-2 px-2 text-right font-mono">{filteredPartyRows.reduce((s, r) => s + r.salesTaxable, 0).toFixed(2)}</td>
                          <td className="py-2 px-2 text-right font-mono">{filteredPartyRows.reduce((s, r) => s + r.salesExempt, 0).toFixed(2)}</td>
                          <td className="py-2 px-2 text-right font-mono">{filteredPartyRows.reduce((s, r) => s + r.salesVat, 0).toFixed(2)}</td>
                          <td className="py-2 px-2 text-right font-mono">{filteredPartyRows.reduce((s, r) => s + r.salesTaxable + r.salesExempt + r.salesVat, 0).toFixed(2)}</td>
                          <td className="py-2 px-2 text-right font-mono">{filteredPartyRows.reduce((s, r) => s + r.purTaxable, 0).toFixed(2)}</td>
                          <td className="py-2 px-2 text-right font-mono">{filteredPartyRows.reduce((s, r) => s + r.purExempt, 0).toFixed(2)}</td>
                          <td className="py-2 px-2 text-right font-mono">{filteredPartyRows.reduce((s, r) => s + r.purVat, 0).toFixed(2)}</td>
                          <td className="py-2 px-2 text-right font-mono">{filteredPartyRows.reduce((s, r) => s + r.purTaxable + r.purExempt + r.purVat, 0).toFixed(2)}</td>
                          <td className="no-print"></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <p className="text-[12px]">
                    Please send us the received copy with sign &amp; official stamp on this letter within 15 days of its receipt, failing to which the details provided by us will be treated as final confirmed at your end.
                  </p>
                  <p>Sincerely yours,</p>

                  <div className="grid grid-cols-2 gap-8 pt-2">
                    <div className="pt-14">
                      <div className="border-t border-slate-700 w-48" />
                      <p className="text-[12px] text-slate-600 mt-1">{company.name}</p>
                    </div>
                    <div>
                      <p className="text-[12px]">We confirm the Transaction/Balance mentioned above are correct according to our books of accounts.</p>
                      <div className="grid grid-cols-[90px_1fr] gap-y-5 mt-6 items-end">
                        <span>Signature:</span><span className="border-b border-slate-700 h-5" />
                        <span>Full Name:</span><span className="border-b border-slate-700 h-5" />
                        <span>Designation:</span><span className="border-b border-slate-700 h-5" />
                        <span>Date:</span><span className="border-b border-slate-700 h-5" />
                      </div>
                    </div>
                  </div>
                  <p className="text-center text-[11px] font-semibold pt-2">page 1 of 1</p>
                  </div>
              </div>
            );
          })()}
        </div>
      )}

      {confirmParty && <BalanceConfirmationModal party={confirmParty} onClose={() => setConfirmParty(null)} />}

      {/* Record Purchase Modal */}
      {isPurchaseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                नयाँ खरिद प्रविष्टि (Record Supplier Purchase)
              </h3>
              <button
                onClick={() => setIsPurchaseModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePurchase} className="p-5 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    आपूर्तिकर्ताको नाम (Supplier)*
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. नेपाल एग्रो इम्पोर्टर्स प्रा.लि."
                    value={purSupplierName}
                    onChange={(e) => setPurSupplierName(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    आपूर्तिकर्ता प्यान नं. (Supplier PAN)
                  </label>
                  <input
                    type="text"
                    maxLength={9}
                    placeholder="9 digits"
                    value={purSupplierPan}
                    onChange={(e) => setPurSupplierPan(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    खरिद बीजक नं. (Supplier Bill No.)*
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. TI-081/82-0452"
                    value={purBillNo}
                    onChange={(e) => setPurBillNo(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    खरिद मिति (B.S. Date YYYY-MM-DD)*
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="2083-07-12"
                    value={purDateBs}
                    onChange={(e) => setPurDateBs(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    करयोग्य खरिद रकम (Taxable Base)*
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={purTaxable}
                    onChange={(e) => setPurTaxable(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    कर छुट खरिद रकम (Exempt Purchase)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={purExempt}
                    onChange={(e) => setPurExempt(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono"
                  />
                </div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-lg text-xs space-y-1 border border-emerald-200">
                <div className="flex justify-between text-slate-700">
                  <span>१३% इनपुट भ्याट (Auto 13%):</span>
                  <span className="font-mono font-bold">{(purTaxable * 0.13).toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-emerald-950 text-sm pt-1 border-t border-emerald-200">
                  <span>कुल खरिद रकम (Grand Total):</span>
                  <span className="font-mono">{(purTaxable * 1.13 + purExempt).toFixed(2)}</span>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  सामानको संक्षिप्त विवरण (Summary / Items)
                </label>
                <input
                  type="text"
                  placeholder="जस्तै: १० थान रोटाभेटर ब्लेड, ५ थान टिलर"
                  value={purSummary}
                  onChange={(e) => setPurSummary(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsPurchaseModalOpen(false)}
                  className="px-3 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded"
                >
                  {t.close}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded shadow-xs cursor-pointer"
                >
                  खरिद खातामा सुरक्षित गर्नुहोस्
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Single Invoice Print / View Modal */}
      {viewInvoice && (
        <InvoicePrintModal
          invoice={viewInvoice}
          onClose={() => setViewInvoice(null)}
          onEditInvoice={(id) => {
            setViewInvoice(null);
            startEditInvoice(id);
          }}
          onCancelInvoice={(id) => {
            cancelInvoice(id);
            setViewInvoice(null);
          }}
          onDeleteInvoice={(id) => {
            deleteInvoice(id);
            setViewInvoice(null);
          }}
        />
      )}

      {/* Batch Invoice Print Modal */}
      {isBatchPrintOpen && selectedInvoicesForBatch.length > 0 && (
        <BatchInvoicePrintModal
          invoices={selectedInvoicesForBatch}
          onClose={() => setIsBatchPrintOpen(false)}
        />
      )}
    </div>
  );
};
