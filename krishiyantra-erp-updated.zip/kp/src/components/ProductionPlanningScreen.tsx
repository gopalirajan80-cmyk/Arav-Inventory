import React, { useMemo, useState } from 'react';
import { Factory, Plus, X, Save, Play, CheckCircle2, Trash2, AlertTriangle, Edit2, ClipboardList, ShoppingCart, MessageCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FieldOrderPriority, ProductionOrder, ProductionOrderStatus } from '../types';
import { bomRequirements } from '../utils/bomUtils';
import { adStringToBs, addDaysAd } from '../utils/orderUtils';
import { getTodayBsString } from '../utils/nepaliCalendar';
import { shareViaWhatsApp } from '../utils/shareUtils';

const PO_STATUS: Record<ProductionOrderStatus, { ne: string; cls: string }> = {
  PLANNED: { ne: 'योजनाबद्ध', cls: 'bg-slate-100 text-slate-700 border-slate-300' },
  RELEASED: { ne: 'जारी', cls: 'bg-blue-100 text-blue-800 border-blue-300' },
  IN_PROGRESS: { ne: 'उत्पादन चलिरहेको', cls: 'bg-purple-100 text-purple-800 border-purple-300' },
  COMPLETED: { ne: 'पूरा', cls: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
  CANCELLED: { ne: 'रद्द', cls: 'bg-rose-100 text-rose-800 border-rose-300' }
};

export const ProductionPlanningScreen: React.FC = () => {
  const {
    fieldOrders,
    items,
    boms,
    rawMaterials,
    machines,
    employees,
    productionOrders,
    saveProductionOrder,
    deleteProductionOrder,
    getNextProductionOrderNo,
    releaseProductionOrder,
    completeProductionOrder,
    productionBatches,
    currentAccount,
    language,
    setManufacturingSubTab,
    company
  } = useApp();
  const isNe = language === 'ne';
  const [form, setForm] = useState<ProductionOrder | null>(null);
  const [dueAd, setDueAd] = useState(addDaysAd(7));
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [err, setErr] = useState('');

  const activePo = (o: ProductionOrder) => ['PLANNED', 'RELEASED', 'IN_PROGRESS'].includes(o.status);

  // ---------- A. अर्डर माग बनाम स्टक ----------
  const demand = useMemo(() => {
    const open = fieldOrders.filter((o) => ['SUBMITTED', 'APPROVED', 'IN_PRODUCTION'].includes(o.status));
    const map = new Map<string, { itemId: string; name: string; unit: string; ordered: number; orderIds: Set<string>; urgent: boolean; earliest?: string }>();
    open.forEach((o) =>
      o.items.forEach((l) => {
        const r = map.get(l.itemId) || { itemId: l.itemId, name: l.name, unit: l.unit, ordered: 0, orderIds: new Set<string>(), urgent: false, earliest: undefined };
        r.ordered += l.qty;
        r.orderIds.add(o.id);
        if (o.priority === 'URGENT') r.urgent = true;
        if (o.expectedDeliveryBs && (!r.earliest || o.expectedDeliveryBs < r.earliest)) r.earliest = o.expectedDeliveryBs;
        map.set(l.itemId, r);
      })
    );
    return Array.from(map.values())
      .map((r) => {
        const stock = items.find((i) => i.id === r.itemId)?.currentStock ?? 0;
        const planned = productionOrders.filter((p) => activePo(p) && p.productItemId === r.itemId).reduce((s, p) => s + p.quantity, 0);
        const shortfall = Math.max(0, r.ordered - stock - planned);
        return { ...r, stock, planned, shortfall, hasBom: boms.some((b) => b.productItemId === r.itemId && b.isActive) };
      })
      .sort((a, b) => Number(b.shortfall > 0) - Number(a.shortfall > 0) || Number(b.urgent) - Number(a.urgent));
  }, [fieldOrders, items, productionOrders, boms]);

  // ---------- B. कच्चा पदार्थ आवश्यकता (योजनाबद्ध आदेशहरूका लागि) ----------
  const materialNeeds = useMemo(() => {
    const map = new Map<string, { materialId: string; name: string; unit: string; required: number; stock: number; unitCost: number }>();
    productionOrders
      .filter((o) => o.status === 'PLANNED')
      .forEach((o) => {
        const bom = boms.find((b) => b.id === o.bomId);
        bomRequirements(bom, o.quantity, rawMaterials).forEach((r) => {
          const cur = map.get(r.materialId) || { materialId: r.materialId, name: r.name, unit: r.unit, required: 0, stock: r.stock, unitCost: r.unitCost };
          cur.required += r.required;
          map.set(r.materialId, cur);
        });
      });
    return Array.from(map.values())
      .map((r) => ({ ...r, shortage: Math.max(0, Math.round((r.required - r.stock) * 1000) / 1000) }))
      .sort((a, b) => b.shortage - a.shortage);
  }, [productionOrders, boms, rawMaterials]);
  const shortMaterials = materialNeeds.filter((m) => m.shortage > 0);

  const openNew = (seed?: { itemId?: string; name?: string; unit?: string; qty?: number; orderIds?: string[]; due?: string }) => {
    const bom = seed?.itemId ? boms.find((b) => b.productItemId === seed.itemId && b.isActive) : undefined;
    const item = seed?.itemId ? items.find((i) => i.id === seed.itemId) : undefined;
    const due = addDaysAd(7);
    setDueAd(due);
    setErr('');
    setForm({
      id: `po-${Date.now()}`,
      orderNo: getNextProductionOrderNo(),
      bomId: bom?.id,
      productItemId: seed?.itemId,
      productNameNe: item?.nameNe || bom?.productNameNe || seed?.name || '',
      productNameEn: item?.nameEn || bom?.productNameEn,
      quantity: seed?.qty && seed.qty > 0 ? seed.qty : bom?.outputQty || 1,
      unit: item?.unit || bom?.outputUnit || seed?.unit || 'Pcs',
      createdDateBs: getTodayBsString(),
      dueDateBs: seed?.due || adStringToBs(due),
      priority: 'NORMAL',
      fieldOrderIds: seed?.orderIds || [],
      machineId: bom?.machineId,
      machineName: bom?.machineName,
      status: 'PLANNED',
      createdBy: currentAccount?.ownerName
    });
  };

  const saveForm = () => {
    if (!form) return;
    if (!form.productNameNe.trim()) return setErr(isNe ? 'उत्पादनको नाम चाहिन्छ।' : 'Product required.');
    if (!(form.quantity > 0)) return setErr(isNe ? 'परिमाण शून्यभन्दा बढी हुनुपर्छ।' : 'Quantity must be > 0.');
    saveProductionOrder(form);
    setForm(null);
  };

  const release = (o: ProductionOrder) => {
    let res = releaseProductionOrder(o.id);
    if (!res.ok && res.message.startsWith('कच्चा पदार्थ नपुग')) {
      if (window.confirm(`${res.message}\n\n${isNe ? 'तैपनि जारी गर्ने? (स्टक शून्यमा झर्नेछ)' : 'Release anyway?'}`)) {
        res = releaseProductionOrder(o.id, true);
      }
    }
    setMsg({ ok: res.ok, text: res.message });
  };

  const formReqs = form ? bomRequirements(boms.find((b) => b.id === form.bomId), form.quantity, rawMaterials) : [];
  const openOrdersForItem = form?.productItemId
    ? fieldOrders.filter((o) => ['SUBMITTED', 'APPROVED', 'IN_PRODUCTION'].includes(o.status) && o.items.some((l) => l.itemId === form.productItemId))
    : [];
  const inp = 'w-full px-2.5 py-2 border border-slate-300 rounded-lg text-sm';
  const lbl = 'text-[11px] font-bold text-slate-600';

  const shareShortages = () => {
    const text =
      `*${company.name}* — कच्चा पदार्थ खरिद सूची (${getTodayBsString()})\n` +
      shortMaterials.map((m, i) => `${i + 1}. ${m.name}: ${m.shortage} ${m.unit} चाहिने (मौज्दात ${m.stock}, आवश्यक ${Math.round(m.required * 1000) / 1000})`).join('\n');
    shareViaWhatsApp(undefined, text);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-purple-600" />
            {isNe ? 'उत्पादन योजना (Production Planning)' : 'Production Planning'}
          </h2>
          <p className="text-xs text-slate-500">
            {isNe ? 'फिल्ड अर्डरको माग, तयारी सामानको स्टक र कच्चा पदार्थ हेरेर उत्पादन आदेश बनाउनुहोस्' : 'Plan production from field-order demand, finished stock and raw material availability'}
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setManufacturingSubTab('BOM')} className="px-3 py-2 text-xs font-bold border border-slate-300 bg-white rounded-xl">
            {isNe ? 'उत्पादन सूत्र (BOM)' : 'BOMs'}
          </button>
          <button onClick={() => openNew()} className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-sm font-black rounded-xl flex items-center gap-1.5">
            <Plus className="w-4 h-4" />
            {isNe ? 'नयाँ उत्पादन आदेश' : 'New production order'}
          </button>
        </div>
      </div>

      {msg && (
        <div className={`text-sm font-bold rounded-xl px-3 py-2 border flex items-center justify-between gap-2 ${msg.ok ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : 'bg-rose-50 border-rose-300 text-rose-800'}`}>
          <span>{msg.text}</span>
          <button onClick={() => setMsg(null)}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* A. माग */}
      <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b font-black text-sm">{isNe ? '१. खुला अर्डरको माग बनाम स्टक' : '1. Open order demand vs stock'}</div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="text-left p-2">{isNe ? 'सामान' : 'Item'}</th>
                <th className="text-right p-2">{isNe ? 'अर्डर' : 'Ordered'}</th>
                <th className="text-right p-2">{isNe ? 'स्टक' : 'Stock'}</th>
                <th className="text-right p-2">{isNe ? 'योजनामा' : 'Planned'}</th>
                <th className="text-right p-2">{isNe ? 'बनाउनुपर्ने' : 'To make'}</th>
                <th className="p-2" />
              </tr>
            </thead>
            <tbody>
              {demand.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-400">
                    {isNe ? 'कुनै खुला फिल्ड अर्डर छैन' : 'No open field orders'}
                  </td>
                </tr>
              )}
              {demand.map((r) => (
                <tr key={r.itemId} className="border-t">
                  <td className="p-2">
                    <div className="font-bold">{r.name}</div>
                    <div className="text-[10px] text-slate-500">
                      {r.orderIds.size} {isNe ? 'अर्डर' : 'orders'}
                      {r.earliest ? ` · ${isNe ? 'सबैभन्दा चाँडो' : 'earliest'} ${r.earliest}` : ''}
                      {r.urgent ? ' · ⚡' : ''}
                    </div>
                  </td>
                  <td className="p-2 text-right">{r.ordered} {r.unit}</td>
                  <td className="p-2 text-right">{r.stock}</td>
                  <td className="p-2 text-right">{r.planned}</td>
                  <td className={`p-2 text-right font-black ${r.shortfall > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>{r.shortfall > 0 ? r.shortfall : '✓'}</td>
                  <td className="p-2 text-right">
                    {r.shortfall > 0 && (
                      <button
                        onClick={() => openNew({ itemId: r.itemId, name: r.name, unit: r.unit, qty: r.shortfall, orderIds: Array.from(r.orderIds), due: r.earliest })}
                        className="px-2.5 py-1.5 bg-purple-600 text-white font-bold rounded-lg whitespace-nowrap"
                      >
                        {isNe ? 'आदेश बनाउ' : 'Plan'}
                        {!r.hasBom ? ' ⚠' : ''}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* B. कच्चा पदार्थ */}
      {materialNeeds.length > 0 && (
        <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b flex items-center justify-between">
            <span className="font-black text-sm">{isNe ? '२. योजनाबद्ध आदेशका लागि कच्चा पदार्थ आवश्यकता' : '2. Raw material requirement (planned orders)'}</span>
            {shortMaterials.length > 0 && (
              <button onClick={shareShortages} className="px-2.5 py-1.5 text-xs font-bold bg-green-600 text-white rounded-lg flex items-center gap-1">
                <ShoppingCart className="w-3.5 h-3.5" />
                <MessageCircle className="w-3.5 h-3.5" />
                {isNe ? 'खरिद सूची पठाउनुहोस्' : 'Share purchase list'}
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="text-left p-2">{isNe ? 'कच्चा पदार्थ' : 'Material'}</th>
                  <th className="text-right p-2">{isNe ? 'चाहिने' : 'Required'}</th>
                  <th className="text-right p-2">{isNe ? 'मौज्दात' : 'In stock'}</th>
                  <th className="text-right p-2">{isNe ? 'कम' : 'Short'}</th>
                </tr>
              </thead>
              <tbody>
                {materialNeeds.map((m) => (
                  <tr key={m.materialId} className={`border-t ${m.shortage > 0 ? 'bg-rose-50/60' : ''}`}>
                    <td className="p-2 font-bold">{m.name}</td>
                    <td className="p-2 text-right">{Math.round(m.required * 1000) / 1000} {m.unit}</td>
                    <td className="p-2 text-right">{m.stock}</td>
                    <td className={`p-2 text-right font-black ${m.shortage > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>{m.shortage > 0 ? m.shortage : '✓'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* C. उत्पादन आदेश */}
      <section className="space-y-2">
        <h3 className="font-black text-sm text-slate-900">{isNe ? '३. उत्पादन आदेशहरू' : '3. Production orders'}</h3>
        {productionOrders.length === 0 ? (
          <div className="text-center text-sm text-slate-400 py-10 bg-white border border-dashed border-slate-300 rounded-2xl">
            {isNe ? 'अहिलेसम्म कुनै उत्पादन आदेश छैन।' : 'No production orders.'}
          </div>
        ) : (
          productionOrders.map((o) => {
            const batch = productionBatches.find((b) => b.id === o.batchId);
            const linked = fieldOrders.filter((f) => o.fieldOrderIds.includes(f.id));
            return (
              <div key={o.id} className="bg-white border border-slate-200 rounded-2xl p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-mono text-xs font-black">{o.orderNo}</span>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${PO_STATUS[o.status].cls}`}>{PO_STATUS[o.status].ne}</span>
                      {o.priority === 'URGENT' && <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full bg-rose-600 text-white">⚡ {isNe ? 'जरुरी' : 'Urgent'}</span>}
                    </div>
                    <div className="font-bold text-slate-900">{o.productNameNe}</div>
                    <div className="text-[11px] text-slate-500">
                      {isNe ? 'तयार हुनुपर्ने' : 'Due'}: {o.dueDateBs || '-'}
                      {o.machineName ? ` · ${o.machineName}` : ''}
                      {o.supervisorName ? ` · ${o.supervisorName}` : ''}
                      {o.batchNumber ? ` · ${isNe ? 'ब्याच' : 'batch'} ${o.batchNumber}${batch ? ` (${batch.stage})` : ''}` : ''}
                    </div>
                    {linked.length > 0 && (
                      <div className="text-[11px] text-slate-500">
                        {isNe ? 'अर्डर' : 'Orders'}: {linked.map((l) => `${l.orderNo} (${l.customerName})`).join(', ')}
                      </div>
                    )}
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-base font-black text-purple-800">{o.quantity}</div>
                    <div className="text-[10px] text-slate-500">{o.unit}</div>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {o.status === 'PLANNED' && (
                    <>
                      <button onClick={() => release(o)} className="px-2.5 py-1.5 text-xs font-bold bg-purple-600 text-white rounded-lg flex items-center gap-1">
                        <Play className="w-3.5 h-3.5" />
                        {isNe ? 'जारी गरी उत्पादन सुरु' : 'Release & start'}
                      </button>
                      <button
                        onClick={() => {
                          setForm(o);
                          setDueAd(addDaysAd(7));
                          setErr('');
                        }}
                        className="px-2.5 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg flex items-center gap-1"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        {isNe ? 'सच्याउनुहोस्' : 'Edit'}
                      </button>
                    </>
                  )}
                  {(o.status === 'IN_PROGRESS' || o.status === 'RELEASED') && batch?.stage === 'IN_MACHINE_WIP' && (
                    <button
                      onClick={() => {
                        completeProductionOrder(o.id);
                        setMsg({ ok: true, text: isNe ? `${o.orderNo} पूरा भयो — तयारी सामान स्टकमा थपियो।` : 'Completed — stock updated.' });
                      }}
                      className="px-2.5 py-1.5 text-xs font-bold bg-emerald-600 text-white rounded-lg flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {isNe ? 'उत्पादन पूरा (स्टकमा थप्नुहोस्)' : 'Complete & add to stock'}
                    </button>
                  )}
                  {o.status === 'PLANNED' && (
                    <button onClick={() => saveProductionOrder({ ...o, status: 'CANCELLED' })} className="px-2.5 py-1.5 text-xs font-bold bg-rose-50 text-rose-800 border border-rose-300 rounded-lg">
                      {isNe ? 'रद्द' : 'Cancel'}
                    </button>
                  )}
                  <button onClick={() => deleteProductionOrder(o.id)} className="px-2 py-1.5 text-xs text-rose-600 border border-rose-200 rounded-lg ml-auto">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </section>

      {/* उत्पादन आदेश फारम */}
      {form && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl my-auto max-h-[94vh] flex flex-col">
            <div className="px-4 py-3 bg-slate-900 text-white rounded-t-2xl flex items-center justify-between">
              <h3 className="font-black text-sm flex items-center gap-2">
                <Factory className="w-4 h-4" />
                {isNe ? 'उत्पादन आदेश' : 'Production order'} — {form.orderNo}
              </h3>
              <button onClick={() => setForm(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 space-y-3 overflow-y-auto text-xs">
              <label className={lbl}>
                {isNe ? 'बनाउने सामान (तयारी सामान)' : 'Product'}
                <select
                  value={form.productItemId || ''}
                  onChange={(e) => {
                    const it = items.find((i) => i.id === e.target.value);
                    const bom = boms.find((b) => b.productItemId === e.target.value && b.isActive);
                    setForm({
                      ...form,
                      productItemId: e.target.value || undefined,
                      productNameNe: it?.nameNe || form.productNameNe,
                      productNameEn: it?.nameEn,
                      unit: it?.unit || form.unit,
                      bomId: bom?.id,
                      machineId: bom?.machineId ?? form.machineId,
                      machineName: bom?.machineName ?? form.machineName
                    });
                  }}
                  className={inp + ' mt-0.5 bg-white font-normal'}
                >
                  <option value="">{isNe ? '-- छान्नुहोस् --' : '-- select --'}</option>
                  {items.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.nameNe} · {isNe ? 'स्टक' : 'stock'} {i.currentStock}
                    </option>
                  ))}
                </select>
              </label>
              <label className={lbl}>
                {isNe ? 'उत्पादन सूत्र (BOM)' : 'BOM'}
                <select
                  value={form.bomId || ''}
                  onChange={(e) => {
                    const b = boms.find((x) => x.id === e.target.value);
                    setForm({ ...form, bomId: e.target.value || undefined, productNameNe: form.productNameNe || b?.productNameNe || '', machineId: b?.machineId ?? form.machineId, machineName: b?.machineName ?? form.machineName });
                  }}
                  className={inp + ' mt-0.5 bg-white font-normal'}
                >
                  <option value="">{isNe ? '-- सूत्र छान्नुहोस् (जारी गर्न अनिवार्य) --' : '-- select BOM --'}</option>
                  {boms
                    .filter((b) => b.isActive)
                    .map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.code} · {b.productNameNe}
                      </option>
                    ))}
                </select>
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <label className={lbl + ' col-span-2'}>
                  {isNe ? 'उत्पादनको नाम' : 'Name'}
                  <input value={form.productNameNe} onChange={(e) => setForm({ ...form, productNameNe: e.target.value })} className={inp + ' mt-0.5 font-bold'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'परिमाण' : 'Quantity'}
                  <input type="number" min={0} step="any" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'एकाइ' : 'Unit'}
                  <input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl + ' col-span-2'}>
                  {isNe ? 'तयार हुनुपर्ने मिति' : 'Due date'}
                  <input
                    type="date"
                    value={dueAd}
                    onChange={(e) => {
                      setDueAd(e.target.value);
                      setForm({ ...form, dueDateBs: adStringToBs(e.target.value) });
                    }}
                    className={inp + ' mt-0.5 font-normal'}
                  />
                  <span className="font-mono text-emerald-800">{form.dueDateBs}</span>
                </label>
                <label className={lbl}>
                  {isNe ? 'प्राथमिकता' : 'Priority'}
                  <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value as FieldOrderPriority })} className={inp + ' mt-0.5 bg-white font-normal'}>
                    <option value="NORMAL">{isNe ? 'सामान्य' : 'Normal'}</option>
                    <option value="URGENT">{isNe ? 'जरुरी' : 'Urgent'}</option>
                  </select>
                </label>
                <label className={lbl}>
                  {isNe ? 'मेसिन' : 'Machine'}
                  <select
                    value={form.machineId || ''}
                    onChange={(e) => {
                      const m = machines.find((x) => x.id === e.target.value);
                      setForm({ ...form, machineId: e.target.value || undefined, machineName: m?.nameNe });
                    }}
                    className={inp + ' mt-0.5 bg-white font-normal'}
                  >
                    <option value="">--</option>
                    {machines.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.nameNe}
                      </option>
                    ))}
                  </select>
                </label>
                <label className={lbl + ' col-span-2 sm:col-span-4'}>
                  {isNe ? 'सुपरभाइजर' : 'Supervisor'}
                  <select value={form.supervisorName || ''} onChange={(e) => setForm({ ...form, supervisorName: e.target.value || undefined })} className={inp + ' mt-0.5 bg-white font-normal'}>
                    <option value="">--</option>
                    {employees.map((e) => (
                      <option key={e.id} value={e.name}>
                        {e.name} ({e.role})
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              {openOrdersForItem.length > 0 && (
                <div className="border border-slate-200 rounded-xl p-2 space-y-1">
                  <div className="font-bold text-slate-700">{isNe ? 'यो उत्पादन कुन अर्डरका लागि हो?' : 'Link to field orders'}</div>
                  {openOrdersForItem.map((o) => (
                    <label key={o.id} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={form.fieldOrderIds.includes(o.id)}
                        onChange={(e) =>
                          setForm({
                            ...form,
                            fieldOrderIds: e.target.checked ? [...form.fieldOrderIds, o.id] : form.fieldOrderIds.filter((x) => x !== o.id)
                          })
                        }
                      />
                      <span>
                        {o.orderNo} — {o.customerName} ({o.items.find((l) => l.itemId === form.productItemId)?.qty} {o.items.find((l) => l.itemId === form.productItemId)?.unit})
                      </span>
                    </label>
                  ))}
                </div>
              )}

              {formReqs.length > 0 ? (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-3 py-2 bg-slate-50 font-bold">{isNe ? 'चाहिने कच्चा पदार्थ (BOM अनुसार)' : 'Materials required'}</div>
                  <table className="w-full">
                    <tbody>
                      {formReqs.map((r) => (
                        <tr key={r.materialId} className={`border-t ${r.shortage > 0 ? 'bg-rose-50' : ''}`}>
                          <td className="p-2">{r.name}</td>
                          <td className="p-2 text-right">{r.required} {r.unit}</td>
                          <td className={`p-2 text-right font-bold ${r.shortage > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>
                            {r.shortage > 0 ? `${isNe ? 'कम' : 'short'} ${r.shortage}` : '✓'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-2 py-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  {isNe ? 'BOM छान्नुभएको छैन — कच्चा पदार्थ गणना र उत्पादन जारी गर्न BOM चाहिन्छ।' : 'Select a BOM to compute materials.'}
                </div>
              )}

              <label className={lbl}>
                {isNe ? 'टिप्पणी' : 'Notes'}
                <textarea value={form.notes || ''} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} className={inp + ' mt-0.5 font-normal'} />
              </label>
              {err && <div className="text-sm font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-2">{err}</div>}
            </div>
            <div className="px-4 py-3 border-t flex justify-end gap-2">
              <button onClick={() => setForm(null)} className="px-4 py-2 text-sm font-bold border border-slate-300 rounded-xl">
                {isNe ? 'रद्द' : 'Cancel'}
              </button>
              <button onClick={saveForm} className="px-5 py-2 text-sm font-black bg-purple-600 text-white rounded-xl flex items-center gap-1.5">
                <Save className="w-4 h-4" />
                {isNe ? 'सेभ गर्नुहोस्' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
