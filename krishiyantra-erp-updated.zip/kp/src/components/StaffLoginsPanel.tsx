import React, { useCallback, useEffect, useState } from 'react';
import { staffApi, type StaffAccount } from '../utils/auth';

const ROLES: { id: string; ne: string }[] = [
  { id: 'STAFF', ne: 'कर्मचारी (Staff)' },
  { id: 'COUNTER_SALES', ne: 'काउन्टर बिक्री' },
  { id: 'SALESMAN', ne: 'सेल्सम्यान' },
  { id: 'SUPERVISOR', ne: 'सुपरभाइजर' },
  { id: 'ACCOUNTANT', ne: 'लेखापाल' },
];
const TABS: { id: string; ne: string }[] = [
  { id: 'dashboard', ne: 'ड्यासबोर्ड' }, { id: 'billing', ne: 'बिलिङ' }, { id: 'field_orders', ne: 'फिल्ड अर्डर/कोटेशन' }, { id: 'vouchers', ne: 'भौचर/असुली' },
  { id: 'ledger', ne: 'खाता' }, { id: 'inventory', ne: 'स्टक' }, { id: 'manufacturing', ne: 'उत्पादन' },
  { id: 'logistics', ne: 'चलानी' }, { id: 'attendance', ne: 'हाजिरी' }, { id: 'reports', ne: 'रिपोर्ट' },
  { id: 'vat_books', ne: 'भ्याट बुक' }, { id: 'audit_trail', ne: 'अडिट' }, { id: 'excel_wizard', ne: 'एक्सेल' },
];
const DEFAULT_TABS = ['dashboard', 'billing', 'field_orders', 'vouchers', 'ledger', 'inventory', 'logistics', 'attendance'];

const box = 'w-full border border-slate-300 rounded-lg px-3 py-2 text-sm';

export const StaffLoginsPanel: React.FC = () => {
  const [users, setUsers] = useState<StaffAccount[]>([]);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [form, setForm] = useState({ id: '', name: '', password: '', role: 'STAFF', allowedTabs: DEFAULT_TABS });
  const [editing, setEditing] = useState<string | null>(null);
  const [editTabs, setEditTabs] = useState<string[]>([]);
  const [resetFor, setResetFor] = useState<string | null>(null);
  const [newPw, setNewPw] = useState('');

  const load = useCallback(async () => {
    const r = await staffApi.list();
    if (r.ok) setUsers(r.data.users); else setMsg({ ok: false, text: r.error || '' });
  }, []);
  useEffect(() => { load(); }, [load]);

  const done = async (r: { ok: boolean; error?: string }, okText: string) => {
    setMsg({ ok: r.ok, text: r.ok ? okText : r.error || 'असफल भयो।' });
    if (r.ok) await load();
    return r.ok;
  };
  const toggle = (list: string[], id: string) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    if (await done(await staffApi.create(form), `✓ ${form.name} को खाता बन्यो। ID: ${form.id.toLowerCase()}`))
      setForm({ id: '', name: '', password: '', role: 'STAFF', allowedTabs: DEFAULT_TABS });
  };

  return (
    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-6">
      <div>
        <h2 className="text-base font-bold text-slate-900">कर्मचारी लगइन (Staff ID & Password)</h2>
        <p className="text-xs text-slate-500 mt-1">
          हरेक कर्मचारीको आफ्नै ID र पासवर्ड। कर्मचारीले ID/पासवर्डले लगइन गरेपछि तपाईंले दिएका ट्याब मात्र देख्छ।
          पासवर्ड बदल्दा वा खाता बन्द गर्दा उनी सबै डिभाइसबाट लगआउट हुन्छन्। मालिकको ID: <b>owner</b>।
        </p>
      </div>

      {msg && <div className={`text-sm rounded-lg px-3 py-2 ${msg.ok ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-700'}`}>{msg.text}</div>}

      <form onSubmit={create} className="grid sm:grid-cols-2 gap-3 p-4 rounded-xl bg-slate-50 border border-slate-200">
        <div className="sm:col-span-2 font-semibold text-sm">+ नयाँ कर्मचारी खाता</div>
        <input className={box} placeholder="नाम (जस्तै: राम बहादुर)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <input className={box} placeholder="लगइन ID (जस्तै: ram01)" autoCapitalize="none" value={form.id} onChange={(e) => setForm({ ...form, id: e.target.value })} required />
        <input className={box} placeholder="पासवर्ड (कम्तीमा ६ अक्षर)" type="text" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required minLength={6} />
        <select className={box} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
          {ROLES.map((r) => <option key={r.id} value={r.id}>{r.ne}</option>)}
        </select>
        <div className="sm:col-span-2">
          <div className="text-xs font-semibold text-slate-600 mb-1">देख्न पाउने ट्याबहरू</div>
          <div className="flex flex-wrap gap-2">
            {TABS.map((t) => (
              <label key={t.id} className="flex items-center gap-1 text-xs border rounded-full px-2 py-1 bg-white">
                <input type="checkbox" checked={form.allowedTabs.includes(t.id)} onChange={() => setForm({ ...form, allowedTabs: toggle(form.allowedTabs, t.id) })} />
                {t.ne}
              </label>
            ))}
          </div>
        </div>
        <button className="sm:col-span-2 bg-emerald-700 text-white rounded-lg py-2 font-semibold text-sm">खाता बनाउनुहोस्</button>
      </form>

      <div className="space-y-3">
        {users.length === 0 && <p className="text-sm text-slate-500">अहिलेसम्म कुनै कर्मचारी खाता छैन।</p>}
        {users.map((u) => (
          <div key={u.id} className={`border rounded-xl p-3 space-y-2 ${u.active ? 'border-slate-200' : 'border-red-200 bg-red-50/40'}`}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="font-semibold text-sm">{u.name} {!u.active && <span className="text-xs text-red-600">(बन्द)</span>}</div>
                <div className="text-xs text-slate-500 font-mono">ID: {u.id} · {ROLES.find((r) => r.id === u.role)?.ne || u.role}</div>
              </div>
              <div className="flex flex-wrap gap-2 text-xs">
                <button className="px-2 py-1 rounded border" onClick={() => { setResetFor(resetFor === u.id ? null : u.id); setNewPw(''); }}>पासवर्ड बदल्ने</button>
                <button className="px-2 py-1 rounded border" onClick={() => { setEditing(editing === u.id ? null : u.id); setEditTabs(u.allowedTabs.length ? u.allowedTabs : DEFAULT_TABS); }}>ट्याब अनुमति</button>
                <button className="px-2 py-1 rounded border" onClick={async () => done(await staffApi.update(u.id, { active: !u.active }), u.active ? '✓ खाता बन्द भयो' : '✓ खाता खुल्यो')}>{u.active ? 'बन्द गर्ने' : 'खोल्ने'}</button>
                <button className="px-2 py-1 rounded border text-red-700 border-red-300" onClick={async () => { if (confirm(`${u.name} को खाता सदाका लागि मेटाउने?`)) done(await staffApi.remove(u.id), '✓ खाता मेटियो'); }}>मेटाउने</button>
              </div>
            </div>
            {resetFor === u.id && (
              <div className="flex gap-2">
                <input className={box} placeholder="नयाँ पासवर्ड (कम्तीमा ६)" value={newPw} onChange={(e) => setNewPw(e.target.value)} />
                <button className="bg-emerald-700 text-white rounded-lg px-3 text-sm" onClick={async () => { if (await done(await staffApi.update(u.id, { password: newPw }), '✓ पासवर्ड बदलियो') ) { setResetFor(null); setNewPw(''); } }}>सेभ</button>
              </div>
            )}
            {editing === u.id && (
              <div className="space-y-2">
                <div className="flex flex-wrap gap-2">
                  {TABS.map((t) => (
                    <label key={t.id} className="flex items-center gap-1 text-xs border rounded-full px-2 py-1 bg-white">
                      <input type="checkbox" checked={editTabs.includes(t.id)} onChange={() => setEditTabs(toggle(editTabs, t.id))} />
                      {t.ne}
                    </label>
                  ))}
                </div>
                <button className="bg-emerald-700 text-white rounded-lg px-3 py-1 text-sm" onClick={async () => { if (await done(await staffApi.update(u.id, { allowedTabs: editTabs }), '✓ अनुमति सेभ भयो (अर्को लगइनमा लागू हुन्छ)')) setEditing(null); }}>अनुमति सेभ</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
