import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  Building2,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Search,
  FileText,
  DollarSign,
  Send,
  MessageSquare,
  Share2,
  RefreshCw,
  Wallet,
  Receipt,
  AlertCircle,
  Copy,
  ExternalLink,
  QrCode
} from 'lucide-react';
import { formatCurrency, getTodayBsString } from '../utils/nepaliCalendar';
import { UniversalShareModal } from './UniversalShareModal';
import { buildBankSettlementReceiptMessage } from '../utils/shareUtils';
import { QRCodeSVG } from 'qrcode.react';

interface BankReconciliationViewProps {
  preselectedPartyId?: string;
  preselectedInvoiceId?: string;
  onSuccess?: () => void;
}

export const BankReconciliationView: React.FC<BankReconciliationViewProps> = ({
  preselectedPartyId,
  preselectedInvoiceId,
  onSuccess
}) => {
  const {
    bankAccounts,
    parties,
    invoices,
    settleCustomerBankPayment,
    partyTransactions,
    company,
    language
  } = useApp();

  const isNe = language === 'ne';

  // Bank selection
  const [selectedBankId, setSelectedBankId] = useState<string>(
    bankAccounts[0]?.id || ''
  );

  // Customer selection
  const [selectedPartyId, setSelectedPartyId] = useState<string>(
    preselectedPartyId || ''
  );
  const [partySearchQuery, setPartySearchQuery] = useState<string>('');

  // Payment details
  const [amount, setAmount] = useState<number>(0);
  const [referenceNo, setReferenceNo] = useState<string>('');
  const [paymentDateBs, setPaymentDateBs] = useState<string>(getTodayBsString());
  const [notes, setNotes] = useState<string>('');

  // Selected invoice IDs for reconciliation
  const [selectedInvoiceIds, setSelectedInvoiceIds] = useState<string[]>(
    preselectedInvoiceId ? [preselectedInvoiceId] : []
  );

  // Bank SMS / Notification Parser state
  const [smsText, setSmsText] = useState<string>('');
  const [isSmsParsed, setIsSmsParsed] = useState<boolean>(false);

  // Success / WhatsApp Receipt Modal State
  const [shareReceiptModalOpen, setShareReceiptModalOpen] = useState(false);
  const [shareReceiptMessage, setShareReceiptMessage] = useState('');
  const [shareRecipientName, setShareRecipientName] = useState('');
  const [shareRecipientPhone, setShareRecipientPhone] = useState('');

  // Toast / feedback message
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Active bank object
  const activeBank = useMemo(() => {
    return bankAccounts.find((b) => b.id === selectedBankId) || bankAccounts[0];
  }, [bankAccounts, selectedBankId]);

  // Active customer object
  const activeParty = useMemo(() => {
    return parties.find((p) => p.id === selectedPartyId);
  }, [parties, selectedPartyId]);

  // Filtered parties list for dropdown/search
  const filteredParties = useMemo(() => {
    if (!partySearchQuery.trim()) return parties;
    const q = partySearchQuery.toLowerCase();
    return parties.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        (p.phone && p.phone.includes(q)) ||
        (p.panNo && p.panNo.includes(q))
    );
  }, [parties, partySearchQuery]);

  // Unpaid or partially paid active invoices for selected customer
  const customerUnpaidInvoices = useMemo(() => {
    if (!activeParty) return [];
    return invoices.filter((inv) => {
      if (inv.status === 'CANCELLED') return false;
      const isMatch =
        inv.partyId === activeParty.id ||
        inv.customerName.toLowerCase() === activeParty.name.toLowerCase() ||
        (activeParty.phone && inv.customerPhone === activeParty.phone);
      const due =
        inv.remainingDue !== undefined
          ? inv.remainingDue
          : Math.max(0, inv.grandTotal - (inv.amountPaid || 0));
      return isMatch && due > 0;
    });
  }, [invoices, activeParty]);

  // Auto-set amount when preselected invoice or invoices selection changes
  React.useEffect(() => {
    if (preselectedInvoiceId) {
      const inv = invoices.find((i) => i.id === preselectedInvoiceId);
      if (inv) {
        const due =
          inv.remainingDue !== undefined
            ? inv.remainingDue
            : Math.max(0, inv.grandTotal - (inv.amountPaid || 0));
        setAmount(due);
        if (inv.partyId) setSelectedPartyId(inv.partyId);
      }
    }
  }, [preselectedInvoiceId, invoices]);

  // Auto-calculate sum of selected invoices
  const sumOfSelectedInvoices = useMemo(() => {
    return customerUnpaidInvoices
      .filter((inv) => selectedInvoiceIds.includes(inv.id))
      .reduce((sum, inv) => {
        const due =
          inv.remainingDue !== undefined
            ? inv.remainingDue
            : Math.max(0, inv.grandTotal - (inv.amountPaid || 0));
        return sum + due;
      }, 0);
  }, [customerUnpaidInvoices, selectedInvoiceIds]);

  const handleSelectAllInvoices = () => {
    const allIds = customerUnpaidInvoices.map((i) => i.id);
    setSelectedInvoiceIds(allIds);
    const totalDue = customerUnpaidInvoices.reduce((sum, inv) => {
      const due =
        inv.remainingDue !== undefined
          ? inv.remainingDue
          : Math.max(0, inv.grandTotal - (inv.amountPaid || 0));
      return sum + due;
    }, 0);
    setAmount(totalDue);
  };

  const handleToggleInvoice = (invId: string, invDue: number) => {
    if (selectedInvoiceIds.includes(invId)) {
      const next = selectedInvoiceIds.filter((id) => id !== invId);
      setSelectedInvoiceIds(next);
      setAmount((prev) => Math.max(0, prev - invDue));
    } else {
      setSelectedInvoiceIds((prev) => [...prev, invId]);
      setAmount((prev) => prev + invDue);
    }
  };

  // Smart Bank SMS / Notification Parser
  const handleParseSms = () => {
    if (!smsText.trim()) return;

    // Extract amount: looks for "NPR 25,000" or "Rs. 25000" or "Credited with ... 25000"
    const amountMatch = smsText.match(/(?:NPR|Rs\.?|रू|रु\.?|NPR\.)\s*([\d,]+(?:\.\d+)?)/i) ||
      smsText.match(/(?:credited|deposited|received)\s+(?:with\s+)?([\d,]+(?:\.\d+)?)/i);

    if (amountMatch && amountMatch[1]) {
      const cleanNum = parseFloat(amountMatch[1].replace(/,/g, ''));
      if (!isNaN(cleanNum)) {
        setAmount(cleanNum);
      }
    }

    // Extract Ref/UTR: looks for "Ref: 12345" or "UTR: 12345" or "TxnId: 12345"
    const refMatch = smsText.match(/(?:Ref|UTR|Txn(?:\s*Id)?|Receipt|Fonepay)\s*[:#\-]?\s*([a-zA-Z0-9_\-]+)/i);
    if (refMatch && refMatch[1]) {
      setReferenceNo(refMatch[1]);
    } else {
      setReferenceNo(`BANK-${Date.now().toString().slice(-6)}`);
    }

    // Try matching customer by phone or name
    const phoneMatch = smsText.match(/(?:98\d{8}|97\d{8})/);
    if (phoneMatch) {
      const matchedParty = parties.find(
        (p) => p.phone && p.phone.replace(/\D/g, '').includes(phoneMatch[0])
      );
      if (matchedParty) {
        setSelectedPartyId(matchedParty.id);
      }
    } else {
      // Search party name in text
      const matchedParty = parties.find((p) =>
        smsText.toLowerCase().includes(p.name.toLowerCase().trim())
      );
      if (matchedParty) {
        setSelectedPartyId(matchedParty.id);
      }
    }

    setIsSmsParsed(true);
    setTimeout(() => setIsSmsParsed(false), 3000);
  };

  // Submit Bank Auto-Reconciliation
  const handleReconcileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) {
      alert(isNe ? 'कृपया मान्य भुक्तानी रकम राख्नुहोस्।' : 'Please enter a valid amount.');
      return;
    }
    if (!activeBank) {
      alert(isNe ? 'कृपया बैंक खाता छान्नुहोस्।' : 'Please select a bank account.');
      return;
    }

    const partyName = activeParty ? activeParty.name : partySearchQuery.trim() || 'ग्राहक';
    const finalRef = referenceNo.trim() || `TRX-${Date.now().toString().slice(-6)}`;

    const res = settleCustomerBankPayment({
      partyId: activeParty?.id,
      partyName,
      partyPhone: activeParty?.phone,
      amount,
      bankAccountId: activeBank.id,
      referenceNo: finalRef,
      invoiceIds: selectedInvoiceIds,
      dateBs: paymentDateBs,
      notes: notes.trim() || `बैंक मार्फत भुक्तानी स्वतः मिलान (Ref: ${finalRef})`
    });

    if (res.success) {
      setSuccessToast(res.message);

      // Prepare WhatsApp / SMS confirmation receipt
      const receiptMsg = buildBankSettlementReceiptMessage(
        {
          customerName: partyName,
          amount,
          bankName: activeBank.bankName,
          referenceNo: finalRef,
          dateBs: paymentDateBs,
          settledInvoices: res.settledInvoiceNumbers,
          remainingBalance: res.newCustomerBalance
        },
        company
      );

      setShareRecipientName(partyName);
      setShareRecipientPhone(activeParty?.phone || '');
      setShareReceiptMessage(receiptMsg);
      setShareReceiptModalOpen(true);

      // Reset form
      setAmount(0);
      setReferenceNo('');
      setSelectedInvoiceIds([]);
      setSmsText('');
      setNotes('');

      if (onSuccess) onSuccess();
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner: Bank Accounts Live Balances & Auto-Reconciliation Info */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white p-5 rounded-2xl shadow-md border border-emerald-800/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-emerald-500/20 text-emerald-300 rounded-lg">
                <Building2 className="w-5 h-5" />
              </span>
              <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                {isNe ? 'बैंक भुक्तानी तथा स्वतः मिलान प्रणाली' : 'Bank Payment & Auto-Reconciliation'}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white">
              {isNe ? 'ग्राहकले बैंकमा तिर्दा स्वतः बैंक खाता र बिल मिलान' : 'Automatic Bank Reconciliation for Customer Payments'}
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              {isNe
                ? 'ग्राहकले मोबाइल बैंकिङ, Fonepay, eSewa, ConnectIPS वा बैंक भौचर मार्फत रकम तिर्दा सो रकम सिधै सफ्टवेयरको बैंक मौज्दातमा जम्मा हुनेछ र सम्बन्धित ग्राहकको बाँकी बिल स्वतः चुक्ता हुनेछ।'
                : 'Customer bank payments automatically credit the software live bank balance, reduce party dues, and mark invoices as paid with a full audit trail.'}
            </p>
          </div>

          {/* Quick Bank Summary Cards */}
          <div className="flex flex-wrap items-center gap-2.5">
            {bankAccounts.map((b) => (
              <div
                key={b.id}
                onClick={() => setSelectedBankId(b.id)}
                className={`p-3 rounded-xl border transition cursor-pointer flex flex-col justify-between min-w-[170px] ${
                  selectedBankId === b.id
                    ? 'bg-emerald-800/80 border-emerald-400 shadow-md ring-2 ring-emerald-400/50'
                    : 'bg-white/5 hover:bg-white/10 border-white/10'
                }`}
              >
                <div className="flex items-center justify-between text-[11px] text-emerald-200">
                  <span className="font-bold truncate max-w-[120px]">{b.bankName}</span>
                  {selectedBankId === b.id && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />}
                </div>
                <div className="text-base font-black font-mono text-white mt-1">
                  {formatCurrency(b.currentBalance, isNe)}
                </div>
                <div className="text-[10px] text-slate-400 font-mono truncate">
                  खाता: {b.accountNumber}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Success Banner */}
      {successToast && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center justify-between gap-3 text-emerald-900 text-xs font-bold animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{successToast}</span>
          </div>
          <button
            onClick={() => setSuccessToast(null)}
            className="text-emerald-700 hover:text-emerald-900 font-extrabold cursor-pointer text-sm"
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Reconciliation Grid: Left Form + Right Bank QR / Invoices */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left Column: Form & Smart Parser (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Wallet className="w-4 h-4 text-emerald-700" />
                <span>{isNe ? '१. बैंक जम्मा तथा ग्राहक विवरण' : '1. Bank & Customer Details'}</span>
              </h3>
              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                बैंक खाता: {activeBank.bankName}
              </span>
            </div>

            {/* Smart Bank SMS / Text Auto-Parser Tool */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                <span className="flex items-center gap-1.5 text-emerald-800">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  {isNe ? 'बैंक SMS वा सन्देशबाट स्वतः पत्ता लगाउने (Smart Parser):' : 'Auto-Parse from Bank SMS / Notification:'}
                </span>
                {isSmsParsed && (
                  <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> पत्ता लाग्यो !
                  </span>
                )}
              </div>
              <div className="flex gap-2">
                <textarea
                  rows={2}
                  value={smsText}
                  onChange={(e) => setSmsText(e.target.value)}
                  placeholder={
                    isNe
                      ? "मोबाइलमा आएको बैंक SMS यहाँ पेस्ट गर्नुहोस् (उदा: AC 0210... Credited NPR 25,000 on 2081/11/02 by Fonepay Ref: 9845123456 - Ram Thapa)..."
                      : "Paste bank credit SMS here..."
                  }
                  className="w-full p-2 text-xs border border-slate-300 rounded-lg bg-white outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 font-mono text-slate-800"
                />
                <button
                  type="button"
                  onClick={handleParseSms}
                  className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shrink-0 transition flex flex-col items-center justify-center gap-1 shadow-2xs cursor-pointer"
                  title="SMS बाट रकम र रेफरेन्स स्वतः निकाल्नुहोस्"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>{isNe ? 'अटो-स्क्यान' : 'Parse'}</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleReconcileSubmit} className="space-y-4">
              
              {/* Bank Account Picker */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'रकम जम्मा भएको कम्पनीको बैंक खाता:' : 'Target Company Bank Account:'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {bankAccounts.map((b) => (
                    <label
                      key={b.id}
                      className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition ${
                        selectedBankId === b.id
                          ? 'bg-emerald-50 border-emerald-500 shadow-2xs ring-1 ring-emerald-500'
                          : 'bg-white hover:bg-slate-50 border-slate-200'
                      }`}
                    >
                      <input
                        type="radio"
                        name="bankAccount"
                        value={b.id}
                        checked={selectedBankId === b.id}
                        onChange={() => setSelectedBankId(b.id)}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <div className="text-xs">
                        <div className="font-bold text-slate-900">{b.bankName}</div>
                        <div className="font-mono text-slate-600 text-[11px]">{b.accountNumber}</div>
                        <div className="text-emerald-700 font-bold font-mono text-[11px]">
                          मौज्दात: {formatCurrency(b.currentBalance, isNe)}
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Customer Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                  <span>{isNe ? 'रकम तिर्ने ग्राहक / पार्टी छान्नुहोस्:' : 'Select Customer / Payer:'}</span>
                  {activeParty && (
                    <span className="text-[11px] font-bold text-rose-600">
                      हाल बाँकी बक्यौता: {formatCurrency(activeParty.currentBalance ?? activeParty.openingBalance, isNe)}
                    </span>
                  )}
                </label>
                <div className="relative">
                  <select
                    value={selectedPartyId}
                    onChange={(e) => {
                      setSelectedPartyId(e.target.value);
                      setSelectedInvoiceIds([]);
                    }}
                    className="w-full px-3 py-2.5 border border-slate-300 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-emerald-600 outline-none bg-white text-slate-900"
                  >
                    <option value="">-- ग्राहक छान्नुहोस् (Choose Customer) --</option>
                    {filteredParties.map((p) => {
                      const due = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
                      return (
                        <option key={p.id} value={p.id}>
                          {p.name} {p.phone ? `(${p.phone})` : ''} — बाँकी: रु. {due}
                        </option>
                      );
                    })}
                  </select>
                </div>
              </div>

              {/* Amount & Date & Reference Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Received Amount */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isNe ? 'प्राप्त रकम (NPR):' : 'Received Amount (NPR):'}
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="1"
                      step="any"
                      required
                      value={amount || ''}
                      onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                      className="w-full pl-3 pr-3 py-2 border border-slate-300 rounded-xl text-sm font-mono font-bold text-emerald-800 focus:ring-2 focus:ring-emerald-600 outline-none"
                    />
                  </div>
                </div>

                {/* Bank Ref / UTR / Fonepay Code */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isNe ? 'बैंक भौचर / UTR / Ref नं:' : 'Bank Ref / UTR No:'}
                  </label>
                  <input
                    type="text"
                    required
                    value={referenceNo}
                    onChange={(e) => setReferenceNo(e.target.value)}
                    placeholder="उदा: TRX-98234, IPS-8832"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-mono font-semibold focus:ring-2 focus:ring-emerald-600 outline-none"
                  />
                </div>

                {/* Payment Date */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isNe ? 'जम्मा भएको मिति (B.S.):' : 'Payment Date (B.S.):'}
                  </label>
                  <input
                    type="text"
                    required
                    value={paymentDateBs}
                    onChange={(e) => setPaymentDateBs(e.target.value)}
                    placeholder="२०८१/११/०२"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-mono focus:ring-2 focus:ring-emerald-600 outline-none"
                  />
                </div>
              </div>

              {/* Remarks / Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'कैफियत / टिप्पणी (Remarks):' : 'Remarks / Note:'}
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={isNe ? 'उदा: Fonepay QR मार्फत प्राप्त रकम' : 'e.g. Received via Fonepay QR'}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-emerald-600 outline-none"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={amount <= 0 || !activeBank}
                  className="w-full py-3 bg-gradient-to-r from-emerald-700 to-emerald-900 hover:from-emerald-800 hover:to-emerald-950 text-white rounded-xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed group"
                >
                  <CheckCircle2 className="w-5 h-5 text-emerald-300 group-hover:scale-110 transition" />
                  <span>
                    {isNe
                      ? `स्वतः बैंक खातामा मिलान गर्नुहोस् (रु. ${amount.toLocaleString()})`
                      : `Auto Reconcile & Deposit into Bank (Rs. ${amount.toLocaleString()})`}
                  </span>
                </button>
              </div>

            </form>

          </div>
        </div>

        {/* Right Column: Pending Invoices Matcher & Bank QR (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Pending Invoices for selected Customer */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-1.5">
                <Receipt className="w-4 h-4 text-emerald-700" />
                <h4 className="text-xs font-bold text-slate-900">
                  {isNe ? 'ग्राहकका बाँकी बिलहरू (Unpaid Invoices)' : 'Pending Invoices to Settle'}
                </h4>
              </div>
              {customerUnpaidInvoices.length > 0 && (
                <button
                  type="button"
                  onClick={handleSelectAllInvoices}
                  className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 underline cursor-pointer"
                >
                  {isNe ? 'सबै छान्नुहोस्' : 'Select All'}
                </button>
              )}
            </div>

            {customerUnpaidInvoices.length === 0 ? (
              <div className="p-6 text-center text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <p className="text-xs">
                  {activeParty
                    ? isNe
                      ? `यस ग्राहक (${activeParty.name}) को कुनै पनि बिल बाँकी छैन। भुक्तानी खातामा पेश्की वा असुलीको रूपमा जम्मा हुनेछ।`
                      : 'No unpaid invoices found for this customer. Payment will be credited as advance/collection.'
                    : isNe
                    ? 'बाँकी बिल हेर्न माथि ग्राहक छान्नुहोस्।'
                    : 'Select a customer to view pending bills.'}
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {customerUnpaidInvoices.map((inv) => {
                  const due =
                    inv.remainingDue !== undefined
                      ? inv.remainingDue
                      : Math.max(0, inv.grandTotal - (inv.amountPaid || 0));
                  const isChecked = selectedInvoiceIds.includes(inv.id);
                  return (
                    <div
                      key={inv.id}
                      onClick={() => handleToggleInvoice(inv.id, due)}
                      className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                        isChecked
                          ? 'bg-emerald-50 border-emerald-400 shadow-2xs'
                          : 'bg-white hover:bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="rounded text-emerald-700 focus:ring-emerald-600"
                        />
                        <div>
                          <div className="text-xs font-mono font-bold text-slate-900">
                            {inv.invoiceNo}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            मिति: {inv.dateBs} | कुल: रु. {inv.grandTotal}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs font-mono font-bold text-rose-600">
                          बाँकी: रु. {due}
                        </div>
                        {inv.amountPaid && inv.amountPaid > 0 && (
                          <div className="text-[10px] text-emerald-700 font-mono">
                            बुझाइसकेको: रु. {inv.amountPaid}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Sum of selected invoices info */}
            {selectedInvoiceIds.length > 0 && (
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-bold">
                <span className="text-slate-600">छानिएका बिलहरूको कुल बाँकी:</span>
                <span className="font-mono text-emerald-800">
                  {formatCurrency(sumOfSelectedInvoices, isNe)}
                </span>
              </div>
            )}
          </div>

          {/* Company Bank QR for Instant Customer Payment */}
          {activeBank && (
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                  <QrCode className="w-4 h-4 text-emerald-700" />
                  <span>{isNe ? 'कम्पनीको बैंक QR कोड (Instant Scan & Pay)' : 'Company Bank QR Code'}</span>
                </div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                  नेपाल पे / FonePay
                </span>
              </div>

              <div className="flex items-center gap-3 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100">
                <div className="bg-white p-2 rounded-xl shadow-xs border border-emerald-200 shrink-0">
                  <QRCodeSVG
                    value={`Bank:${activeBank.bankName};Acc:${activeBank.accountNumber};Name:${activeBank.accountHolder};Amt:${amount > 0 ? amount : ''}`}
                    size={90}
                  />
                </div>
                <div className="text-xs space-y-1">
                  <div className="font-bold text-emerald-950">{activeBank.bankName}</div>
                  <div className="font-mono text-slate-800 font-bold">खाता: {activeBank.accountNumber}</div>
                  <div className="text-slate-600">खातावाला: {activeBank.accountHolder}</div>
                  <div className="text-[10px] text-emerald-800 font-semibold">
                    {isNe
                      ? 'ग्राहकले यो QR स्क्यान गरी तिर्नासाथ यहाँबाट स्वतः खातामा मिलान गर्न सक्नुहुन्छ।'
                      : 'Customer scans this QR to pay instantly.'}
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Universal Share Modal for Payment Receipt */}
      <UniversalShareModal
        isOpen={shareReceiptModalOpen}
        onClose={() => setShareReceiptModalOpen(false)}
        title={isNe ? 'बैंक भुक्तानी रसिद WhatsApp / Message मा पठाउनुहोस्' : 'Send Bank Payment Receipt via WhatsApp / SMS'}
        recipientName={shareRecipientName}
        initialPhone={shareRecipientPhone}
        message={shareReceiptMessage}
        bankDetails={activeBank}
      />

    </div>
  );
};
