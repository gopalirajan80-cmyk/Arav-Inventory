import React, { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { generateBackupPayload } from '../utils/backupUtils';
import { uploadBackupToDrive, getAccessToken } from '../utils/googleDrive';

export const AutoBackupManager: React.FC = () => {
  const {
    company,
    items,
    allInvoices: invoices,
    allPurchases: purchases,
    parties,
    allPartyTransactions: partyTransactions,
    bankAccounts,
    employees,
    attendance,
    employeeLedger,
    rawMaterials,
    productionBatches
  } = useApp();

  useEffect(() => {
    const performAutoBackup = async () => {
      // Only attempt backup if signed in
      const token = await getAccessToken();
      if (!token) return;

      const lastBackupStr = localStorage.getItem('lastAutoBackupTime');
      const now = Date.now();
      const twentyFourHours = 24 * 60 * 60 * 1000;

      if (!lastBackupStr || now - parseInt(lastBackupStr) > twentyFourHours) {
        try {
          const payload = generateBackupPayload({
            company,
            items,
            invoices,
            purchases,
            parties,
            partyTransactions,
            bankAccounts,
            employees,
            attendance,
            employeeLedger,
            rawMaterials,
            productionBatches
          });

          const fileName = `KrishiYantra_AutoBackup_${company.name.replace(/[^a-zA-Z0-9]/g, '_')}_${payload.exportDateBs}.json`;
          
          await uploadBackupToDrive({
            fileName,
            content: JSON.stringify(payload, null, 2),
            mimeType: 'application/json'
          });

          localStorage.setItem('lastAutoBackupTime', now.toString());
          console.log('Automated backup successful');
        } catch (err) {
          console.error('Automated backup failed', err);
        }
      }
    };

    // Run check on mount
    performAutoBackup();
  }, [
    company,
    items,
    invoices,
    purchases,
    parties,
    partyTransactions,
    bankAccounts,
    employees,
    attendance,
    employeeLedger,
    rawMaterials,
    productionBatches
  ]);

  return null;
};
