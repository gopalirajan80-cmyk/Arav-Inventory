import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  initAuth,
  googleSignIn,
  logoutGoogle,
  getAccessToken,
  uploadBackupToDrive,
  listDriveBackups,
  downloadDriveBackupText,
  deleteDriveFile,
  DriveBackupFile
} from '../utils/googleDrive';
import { generateBackupPayload } from '../utils/backupUtils';
import { User } from 'firebase/auth';
import {
  Cloud,
  CheckCircle2,
  AlertTriangle,
  Upload,
  Download,
  Trash2,
  RefreshCw,
  X,
  Database,
  FileSpreadsheet,
  HardDrive,
  ExternalLink
} from 'lucide-react';
import { getTodayBsString } from '../utils/nepaliCalendar';

interface GoogleDriveBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GoogleDriveBackupModal: React.FC<GoogleDriveBackupModalProps> = ({ isOpen, onClose }) => {
  const {
    company,
    items,
    allInvoices: invoices,
    allPurchases: purchases,
    parties,
    allPartyTransactions: partyTransactions,
    bankAccounts,
    employees,
    attendance,
    employeeLedger,
    rawMaterials,
    productionBatches,
    restoreFullBackup,
    requireOwnerKey
  } = useApp();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isLoadingBackups, setIsLoadingBackups] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [driveFiles, setDriveFiles] = useState<DriveBackupFile[]>([]);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Destructive delete confirmation modal state
  const [confirmDeleteFile, setConfirmDeleteFile] = useState<DriveBackupFile | null>(null);
  // Restore confirmation modal state
  const [confirmRestoreFile, setConfirmRestoreFile] = useState<DriveBackupFile | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const unsubscribe = initAuth(
      (user) => {
        setCurrentUser(user);
        fetchFiles();
      },
      () => {
        setCurrentUser(null);
        setDriveFiles([]);
      }
    );

    return () => unsubscribe();
  }, [isOpen]);

  const fetchFiles = async () => {
    setIsLoadingBackups(true);
    try {
      const files = await listDriveBackups();
      setDriveFiles(files);
    } catch (err: any) {
      console.error('Fetch drive files failed', err);
    } finally {
      setIsLoadingBackups(false);
    }
  };

  const handleSignIn = async () => {
    setIsSigningIn(true);
    setStatusMessage(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setCurrentUser(res.user);
        setStatusMessage({ text: 'गुगल खाता सफलतापूर्वक जोडिएको छ।', type: 'success' });
        await fetchFiles();
      }
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'गुगल लग-इन हुन सकेन', type: 'error' });
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    await logoutGoogle();
    setCurrentUser(null);
    setDriveFiles([]);
    setStatusMessage({ text: 'गुगल खाताबाट बाहिरिनुभयो।', type: 'info' });
  };

  // Upload full ERP JSON backup to Google Drive
  const handleBackupNow = async () => {
    setIsUploading(true);
    setStatusMessage(null);
    try {
      const backupPayload = generateBackupPayload({
        company,
        items,
        invoices,
        purchases,
        parties,
        partyTransactions,
        bankAccounts,
        employees,
        attendance,
        employeeLedger,
        rawMaterials,
        productionBatches
      });

      const fileName = `KrishiYantra_CloudBackup_${company.name.replace(/[^a-zA-Z0-9]/g, '_')}_${backupPayload.exportDateBs}.json`;
      const jsonContent = JSON.stringify(backupPayload, null, 2);

      await uploadBackupToDrive({
        fileName,
        content: jsonContent,
        mimeType: 'application/json'
      });

      setStatusMessage({
        text: `गुगल ड्राइभमा सफलतापूर्वक ब्याकअप सुरक्षित भयो: ${fileName}`,
        type: 'success'
      });
      await fetchFiles();
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'ब्याकअप अपलोड असफल भयो', type: 'error' });
    } finally {
      setIsUploading(false);
    }
  };

  // Restore from Drive with confirmation
  const handleExecuteRestore = async () => {
    if (!confirmRestoreFile) return;
    setStatusMessage(null);
    try {
      const content = await downloadDriveBackupText(confirmRestoreFile.id);
      requireOwnerKey(
        `गुगल ड्राइभ ब्याकअप रिस्टोर गर्ने (${confirmRestoreFile.name})`,
        () => {
          const success = restoreFullBackup(content);
          if (success) {
            setStatusMessage({ text: 'ब्याकअप सफलतापूर्वक प्रणालीमा रिस्टोर भयो!', type: 'success' });
            setConfirmRestoreFile(null);
          } else {
            setStatusMessage({ text: 'ब्याकअप फाइल रिस्टोर गर्न सकिएन। ढाँचा मिलेन।', type: 'error' });
          }
        },
        'EDIT'
      );
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'डाउनलोड वा रिस्टोर असफल', type: 'error' });
    }
  };

  // Delete file from Drive with confirmation
  const handleExecuteDelete = async () => {
    if (!confirmDeleteFile) return;
    try {
      await deleteDriveFile(confirmDeleteFile.id);
      setStatusMessage({ text: 'गुगल ड्राइभबाट ब्याकअप फाइल हटाइयो।', type: 'success' });
      setConfirmDeleteFile(null);
      await fetchFiles();
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'फाइल हटाउन सकिएन', type: 'error' });
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-800 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Cloud className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-base font-black">गुगल ड्राइभ क्लाउड ब्याकअप (Google Drive Sync)</h2>
              <p className="text-xs text-emerald-100">
                तपाईंको आफ्नै Google Drive खातामा सम्पूर्ण व्यापार डाटा सुरक्षित गर्नुहोस्
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Status Alert */}
          {statusMessage && (
            <div
              className={`p-3.5 rounded-xl border text-xs font-semibold flex items-center justify-between ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                  : statusMessage.type === 'error'
                  ? 'bg-rose-50 text-rose-900 border-rose-300'
                  : 'bg-blue-50 text-blue-900 border-blue-300'
              }`}
            >
              <span>{statusMessage.text}</span>
              <button
                type="button"
                onClick={() => setStatusMessage(null)}
                className="text-slate-500 hover:text-slate-900 ml-2"
              >
                ✕
              </button>
            </div>
          )}

          {/* Google Auth Status Box */}
          {!currentUser ? (
            <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl text-center space-y-4">
              <div className="w-12 h-12 bg-white rounded-full shadow-xs mx-auto flex items-center justify-center border border-slate-200">
                <HardDrive className="w-6 h-6 text-emerald-700" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">गुगल ड्राइभ जोडिएको छैन</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                  क्लाउड ब्याकअप लिन तथा सुरक्षित राख्न आफ्नो Google खाताबाट लग-इन गर्नुहोस्।
                </p>
              </div>

              {/* Official GSI Material Button Style as required by skill */}
              <button
                type="button"
                onClick={handleSignIn}
                disabled={isSigningIn}
                className="inline-flex items-center gap-3 px-5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 hover:shadow-md rounded-xl text-xs font-bold text-slate-800 transition cursor-pointer disabled:opacity-50"
              >
                <svg className="w-4 h-4" viewBox="0 0 48 48">
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  />
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  />
                </svg>
                <span>{isSigningIn ? 'लग-इन गरिँदै...' : 'Sign in with Google'}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Connected User Profile Banner */}
              <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-xl flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  {currentUser.photoURL ? (
                    <img
                      src={currentUser.photoURL}
                      alt={currentUser.displayName || ''}
                      className="w-10 h-10 rounded-full border border-emerald-300"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-emerald-700 text-white font-bold flex items-center justify-center">
                      {(currentUser.displayName || currentUser.email || 'G').charAt(0)}
                    </div>
                  )}
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-slate-900 text-sm">
                        {currentUser.displayName || 'Google User'}
                      </span>
                      <span className="px-1.5 py-0.2 text-[9px] font-bold bg-emerald-200 text-emerald-950 rounded">
                        जोडिएको ✓
                      </span>
                    </div>
                    <span className="text-xs text-slate-600 font-mono">{currentUser.email}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleBackupNow}
                    disabled={isUploading}
                    className="flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer disabled:opacity-50"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isUploading ? 'अपलोड हुँदै...' : 'गुगल ड्राइभमा अहिले ब्याकअप लिनुहोस्'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSignOut}
                    className="px-3 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    बाहिरिनुहोस्
                  </button>
                </div>
              </div>

              {/* Backups List on Google Drive */}
              <div className="space-y-2">
                <div className="flex items-center justify-between pt-2">
                  <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5 text-emerald-700" />
                    <span>गुगल ड्राइभमा रहेका ब्याकअपहरू ({driveFiles.length})</span>
                  </h3>
                  <button
                    type="button"
                    onClick={fetchFiles}
                    disabled={isLoadingBackups}
                    className="text-xs font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className={`w-3 h-3 ${isLoadingBackups ? 'animate-spin' : ''}`} />
                    <span>ताजा गर्नुहोस्</span>
                  </button>
                </div>

                {isLoadingBackups ? (
                  <div className="p-8 text-center text-xs text-slate-500">
                    गुगल ड्राइभबाट ब्याकअप सूची लोड हुँदैछ...
                  </div>
                ) : driveFiles.length === 0 ? (
                  <div className="p-6 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-center text-xs text-slate-500">
                    गुगल ड्राइभमा हाल कुनै ब्याकअप भेटिएन। माथिको <strong>"अहिले ब्याकअप लिनुहोस्"</strong> बटन थिचेर ब्याकअप राख्नुहोस्।
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white max-h-60 overflow-y-auto">
                    {driveFiles.map((file) => (
                      <div
                        key={file.id}
                        className="p-3 hover:bg-slate-50 flex items-center justify-between gap-3 transition"
                      >
                        <div className="min-w-0">
                          <p className="font-bold text-slate-800 text-xs truncate" title={file.name}>
                            📁 {file.name}
                          </p>
                          <p className="text-[10px] text-slate-500 mt-0.5">
                            {file.createdTime
                              ? new Date(file.createdTime).toLocaleString('ne-NP')
                              : 'मिति उपलब्ध छैन'}{' '}
                            · {file.size ? `${(Number(file.size) / 1024).toFixed(1)} KB` : ''}
                          </p>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => setConfirmRestoreFile(file)}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                            title="यो ब्याकअप रिस्टोर गर्नुहोस्"
                          >
                            <Download className="w-3 h-3" />
                            <span>रिस्टोर</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setConfirmDeleteFile(file)}
                            className="p-1 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 rounded-lg cursor-pointer"
                            title="ड्राइभबाट मेटाउनुहोस्"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>सुरक्षित Google Drive v3 REST API</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg cursor-pointer"
          >
            बन्द गर्नुहोस्
          </button>
        </div>
      </div>

      {/* Mandatory User Confirmation Dialog for File Deletion as required by Skill */}
      {confirmDeleteFile && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-rose-200 space-y-4">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-700" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-slate-900">गुगल ड्राइभबाट ब्याकअप मेटाउने?</h3>
                <p className="text-xs text-rose-600 font-semibold">यो कार्य रद्द गर्न सकिँदैन।</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200 font-mono">
              फाइल: <strong>{confirmDeleteFile.name}</strong>
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteFile(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                रद्द गर्नुहोस्
              </button>
              <button
                type="button"
                onClick={handleExecuteDelete}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                मेटाउनुहोस् (Delete)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mandatory Confirmation Dialog for Restore */}
      {confirmRestoreFile && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-amber-200 space-y-4">
            <div className="flex items-center gap-3 text-amber-700">
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-amber-700" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-slate-900">गुगल ड्राइभ ब्याकअप रिस्टोर गर्ने?</h3>
                <p className="text-xs text-amber-700 font-semibold">
                  हाल प्रणालीमा भएको डाटा यो ब्याकअपले प्रतिस्थापन गर्नेछ।
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200 font-mono">
              फाइल: <strong>{confirmRestoreFile.name}</strong>
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmRestoreFile(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                रद्द गर्नुहोस्
              </button>
              <button
                type="button"
                onClick={handleExecuteRestore}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                अगाडि बढ्नुहोस् (Restore)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
