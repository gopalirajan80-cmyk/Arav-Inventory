import { printPage } from '../utils/printHelper';
import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Truck,
  Plus,
  Search,
  Calendar,
  User,
  MapPin,
  CheckCircle2,
  Clock,
  Navigation,
  CheckCircle,
  XCircle,
  FileText,
  AlertCircle,
  Printer,
  Download,
  FileDown,
  Loader2,
  Trash2,
  Hash,
  Tag
} from 'lucide-react';
import {
  getTodayBsString,
  formatCurrency,
  formatBsDateNepaliText,
  getFiscalYear,
  parseBsYearMonth
} from '../utils/nepaliCalendar';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { DispatchItem, DispatchRecord, InvoiceItem } from '../types';
import { downloadElementAsPdf } from '../utils/pdfHelper';
import { ChallanPrintModal } from './ChallanPrintModal';

export const LogisticsScreen: React.FC = () => {
  const {
    productionBatches,
    recordDispatch,
    updateDispatchStatus,
    approveDispatch,
    logisticsSubTab,
    setLogisticsSubTab,
    language,
    currentRole,
    currentAccount,
    employees,
    parties,
    items: inventoryItems,
    independentDispatches,
    invoices,
    purchases,
    company,
    openDispatchModalSignal,
    preselectedBillId,
    preselectedBillType
  } = useApp();

  const isNe = language === 'ne';
  const todayBs = getTodayBsString();
  const isAdminOrManager = ['OWNER', 'ACCOUNTANT', 'ADMINISTRATION', 'SUPERVISOR', 'STAFF'].includes(currentRole);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [batchId, setBatchId] = useState('');
  const [challanNo, setChallanNo] = useState('');
  const [dispatchType, setDispatchType] = useState<'SALES' | 'PURCHASE' | 'MANUFACTURE'>('SALES');
  const [partyId, setPartyId] = useState('');
  const [dealerName, setDealerName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [vehicleNo, setVehicleNo] = useState('');
  const [driverName, setDriverName] = useState('');
  const [freight, setFreight] = useState(0);
  const [advance, setAdvance] = useState(0);
  const [balancePaid, setBalancePaid] = useState(0);
  const [notes, setNotes] = useState('');
  const [dispatchDateBs, setDispatchDateBs] = useState(todayBs);

  // Quick Select State
  const [selectedBillId, setSelectedBillId] = useState('');

  // Particulars State
  const [particulars, setParticulars] = useState<Omit<DispatchItem, 'id'>[]>([
    { sn: 1, itemId: '', particular: '', qty: 0, rate: 0, total: 0 }
  ]);

  // Derived Financials
  const subtotal = useMemo(() => {
    return particulars.reduce((sum, item) => sum + (item.total || 0), 0);
  }, [particulars]);

  // Auto-generate Challan No
  useEffect(() => {
    if (isModalOpen && !challanNo) {
      const count = (productionBatches.reduce((acc, b) => acc + (b.dispatches?.length || 0), 0)) + independentDispatches.length;
      setChallanNo(`CH-${todayBs.replace(/\//g, '')}-${(count + 1).toString().padStart(3, '0')}`);
    }
  }, [isModalOpen, productionBatches, independentDispatches, todayBs, challanNo]);

  // Sync Party Details
  useEffect(() => {
    if (partyId) {
      const party = parties.find(p => p.id === partyId);
      if (party) {
        setDealerName(party.name);
        setAddress(party.address || '');
        setPhone(party.phone || '');
      }
    }
  }, [partyId, parties]);

  // Sync Bill Details
  useEffect(() => {
    if (selectedBillId) {
      if (dispatchType === 'SALES') {
        const inv = invoices.find(i => i.id === selectedBillId);
        if (inv) {
          setDealerName(inv.customerName);
          setAddress(inv.customerAddress || '');
          setPhone(inv.customerPhone || '');
          setPartyId(inv.partyId || '');
          setParticulars(inv.items.map((it, idx) => ({
            sn: idx + 1,
            itemId: it.itemId,
            particular: it.name,
            hsCode: it.hsCode,
            qty: it.quantity,
            rate: it.rate,
            total: it.amount
          })));
          setNotes(`Invoice No: ${inv.invoiceNo}`);
        }
      } else if (dispatchType === 'PURCHASE') {
        const pur = purchases.find(p => p.id === selectedBillId);
        if (pur) {
          setDealerName(pur.supplierName);
          setParticulars([{
            sn: 1,
            itemId: '',
            particular: pur.itemsSummary,
            hsCode: pur.hsCode,
            qty: 1,
            rate: pur.taxableAmount,
            total: pur.taxableAmount
          }]);
          setNotes(`Purchase Bill: ${pur.purchaseBillNo}`);
        }
      }
    }
  }, [selectedBillId, dispatchType, invoices, purchases]);

  useEffect(() => {
    if (openDispatchModalSignal > 0) {
      setDispatchType(preselectedBillType);
      setSelectedBillId(preselectedBillId);
      setIsModalOpen(true);
    }
  }, [openDispatchModalSignal, preselectedBillId, preselectedBillType]);

  // Search/Filter State
  const [searchQuery, setSearchSearchQuery] = useState('');
  const [driverReportPeriod, setDriverReportPeriod] = useState<'TODAY' | 'THIS_MONTH' | 'THIS_YEAR' | 'ALL' | 'CUSTOM_MONTH' | 'CUSTOM_YEAR'>('ALL');
  const [selectedDriverForReport, setSelectedDriverForReport] = useState<string>('ALL');
  const [selectedYearForReport, setSelectedYearForReport] = useState<string>(todayBs.split('/')[0]);
  const [selectedMonthForReport, setSelectedMonthForReport] = useState<string>(todayBs.split('/')[1]);
  const [isDriverDetailModalOpen, setIsDriverDetailModalOpen] = useState(false);
  const [activeDriverName, setActiveDriverName] = useState('');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [printChallan, setPrintChallan] = useState<DispatchRecord | null>(null);

  // Derived Data
  const allDispatches = useMemo(() => {
    const list: any[] = [];
    
    // Dispatches linked to batches
    productionBatches.forEach((batch) => {
      if (batch.dispatches) {
        batch.dispatches.forEach((d) => {
          list.push({
            ...d,
            batchId: batch.id,
            batchNumber: batch.batchNumber,
            productName: isNe ? batch.productNameNe : batch.productNameEn
          });
        });
      }
    });

    // Independent dispatches
    independentDispatches.forEach((d) => {
      list.push({
        ...d,
        batchId: null,
        batchNumber: 'INDEPENDENT',
        productName: '-'
      });
    });

    return list.sort((a, b) => b.dispatchDateBs.localeCompare(a.dispatchDateBs));
  }, [productionBatches, independentDispatches, isNe]);

  const filteredDispatches = useMemo(() => {
    return allDispatches.filter((d) => {
      const q = searchQuery.toLowerCase();
      return (
        (d.dealerName || '').toLowerCase().includes(q) ||
        (d.driverName || '').toLowerCase().includes(q) ||
        (d.vehicleNo || '').toLowerCase().includes(q) ||
        (d.challanNo || '').toLowerCase().includes(q)
      );
    });
  }, [allDispatches, searchQuery]);

  const driverReport = useMemo(() => {
    const report: Record<string, { driverName: string; trips: number; totalFreight: number; totalAdvance: number; totalBalancePaid: number; vehicles: Set<string> }> = {};
    
    const filteredForReport = allDispatches.filter(d => {
      if (driverReportPeriod === 'ALL') return true;
      if (driverReportPeriod === 'TODAY') return d.dispatchDateBs === todayBs;
      
      const parts = d.dispatchDateBs.split('/');
      const dYear = parts[0];
      const dMonth = parts[1];
      
      const tParts = todayBs.split('/');
      const tYear = tParts[0];
      const tMonth = tParts[1];
      
      if (driverReportPeriod === 'THIS_MONTH') return dYear === tYear && dMonth === tMonth;
      if (driverReportPeriod === 'THIS_YEAR') return dYear === tYear;
      if (driverReportPeriod === 'CUSTOM_MONTH') return dYear === selectedYearForReport && dMonth === selectedMonthForReport;
      if (driverReportPeriod === 'CUSTOM_YEAR') return dYear === selectedYearForReport;
      
      return true;
    });

    filteredForReport.forEach(d => {
      const name = d.driverName?.trim() || (isNe ? 'नाम नभएको ड्राइभर' : 'Unnamed Driver');
      if (!report[name]) {
        report[name] = { driverName: name, trips: 0, totalFreight: 0, totalAdvance: 0, totalBalancePaid: 0, vehicles: new Set() };
      }
      report[name].trips += 1;
      report[name].totalFreight += (d.freightPaid || 0);
      report[name].totalAdvance += (d.driverAdvance || 0);
      report[name].totalBalancePaid += (d.balanceAmountPaid || 0);
      if (d.vehicleNo) report[name].vehicles.add(d.vehicleNo);
    });

    return Object.values(report).sort((a, b) => b.totalFreight - a.totalFreight);
  }, [allDispatches, isNe, driverReportPeriod, todayBs, selectedYearForReport, selectedMonthForReport]);

  const uniqueDriversList = useMemo(() => {
    const drivers = new Set<string>();
    allDispatches.forEach(d => {
      if (d.driverName) drivers.add(d.driverName.trim());
    });
    return Array.from(drivers).sort();
  }, [allDispatches]);

  const yearsList = useMemo(() => {
    const years = new Set<string>();
    allDispatches.forEach(d => {
      const y = d.dispatchDateBs.split('/')[0];
      if (y) years.add(y);
    });
    // Add current year if not present
    years.add(todayBs.split('/')[0]);
    return Array.from(years).sort((a, b) => b.localeCompare(a));
  }, [allDispatches, todayBs]);

  const monthsList = [
    { id: '01', ne: 'बैशाख', en: 'Baisakh' },
    { id: '02', ne: 'जेठ', en: 'Jestha' },
    { id: '03', ne: 'असार', en: 'Ashad' },
    { id: '04', ne: 'साउन', en: 'Shrawan' },
    { id: '05', ne: 'भदौ', en: 'Bhadra' },
    { id: '06', ne: 'असोज', en: 'Ashwin' },
    { id: '07', ne: 'कात्तिक', en: 'Kartik' },
    { id: '08', ne: 'मंसिर', en: 'Mangsir' },
    { id: '09', ne: 'पुष', en: 'Poush' },
    { id: '10', ne: 'माघ', en: 'Magh' },
    { id: '11', ne: 'फागुन', en: 'Falgun' },
    { id: '12', ne: 'चैत', en: 'Chaitra' },
  ];

  const exportDriverReportPdf = async () => {
    try {
      setIsGeneratingPdf(true);
      await downloadElementAsPdf({
        elementId: 'driver-report-table-container',
        fileName: `Driver_Freight_Report_${todayBs}_${driverReportPeriod}.pdf`,
        format: 'a4',
        onProgress: setIsGeneratingPdf
      });
    } catch (err) {
      console.error('PDF export failed', err);
      setIsGeneratingPdf(false);
    }
  };

  const exportSingleDriverReportPdf = async (name: string) => {
    setActiveDriverName(name);
    setIsDriverDetailModalOpen(true);
  };

  const handleDownloadActiveDriverPdf = async () => {
    try {
      setIsGeneratingPdf(true);
      await downloadElementAsPdf({
        elementId: 'single-driver-report-printable',
        fileName: `Driver_Detail_${activeDriverName}_${todayBs}.pdf`,
        format: 'a4',
        onProgress: setIsGeneratingPdf
      });
    } catch (err) {
      console.error('PDF export failed', err);
      setIsGeneratingPdf(false);
    }
  };

  const pendingApprovals = useMemo(() => {
    return allDispatches.filter((d) => !d.isApproved);
  }, [allDispatches]);

  // Handlers
  const handleAddRow = () => {
    setParticulars([...particulars, { sn: particulars.length + 1, itemId: '', particular: '', qty: 0, rate: 0, total: 0 }]);
  };

  const handleRemoveRow = (index: number) => {
    if (particulars.length === 1) return;
    const newList = particulars.filter((_, i) => i !== index).map((item, i) => ({ ...item, sn: i + 1 }));
    setParticulars(newList);
  };

  const handleItemChange = (index: number, field: keyof Omit<DispatchItem, 'id' | 'sn'>, value: any) => {
    const newList = [...particulars];
    const item = { ...newList[index] };

    if (field === 'itemId') {
      const invItem = inventoryItems.find(i => i.id === value);
      if (invItem) {
        item.itemId = value;
        item.particular = isNe ? invItem.nameNe : invItem.nameEn;
        item.hsCode = invItem.hsCode;
        item.rate = dispatchType === 'SALES' ? invItem.sellingPrice : invItem.purchasePrice;
      } else {
        item.itemId = '';
      }
    } else {
      (item as any)[field] = value;
    }

    item.total = (item.qty || 0) * (item.rate || 0);
    newList[index] = item;
    setParticulars(newList);
  };

  const handleSaveDispatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (dispatchType === 'MANUFACTURE' && !batchId) return alert(isNe ? 'उत्पादन ब्याच छान्नुहोस्' : 'Select production batch');
    if (!dealerName) return alert(isNe ? 'पार्टीको नाम लेख्नुहोस्' : 'Enter party name');

    const finalItems: DispatchItem[] = particulars
      .filter(p => p.particular || p.itemId)
      .map(p => ({ ...p, id: `di-${Date.now()}-${Math.random()}` }));

    recordDispatch(batchId || null, {
      challanNo,
      type: dispatchType,
      dealerName,
      partyId,
      address,
      phone,
      items: finalItems,
      dispatchedQuantity: finalItems.reduce((sum, item) => sum + item.qty, 0),
      dispatchDateBs,
      vehicleNo,
      driverName,
      freightPaid: freight,
      driverAdvance: advance,
      balanceAmountPaid: balancePaid,
      purchaseAmount: dispatchType === 'PURCHASE' ? subtotal : 0,
      salesAmount: dispatchType === 'SALES' ? subtotal : 0,
      notes,
      status: 'IN_TRANSIT'
    });

    setIsModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setBatchId('');
    setChallanNo('');
    setDispatchType('SALES');
    setSelectedBillId('');
    setPartyId('');
    setDealerName('');
    setAddress('');
    setPhone('');
    setVehicleNo('');
    setDriverName('');
    setFreight(0);
    setAdvance(0);
    setBalancePaid(0);
    setParticulars([{ sn: 1, itemId: '', particular: '', qty: 0, rate: 0, total: 0 }]);
    setNotes('');
    setDispatchDateBs(todayBs);
  };

  const handleApprove = (batchId: string | null, dispatchId: string) => {
    const approverName = currentAccount?.ownerName || 'Staff';
    if (confirm(isNe ? `के तपाईं यो चलानी स्वीकृत गर्न चाहनुहुन्छ?` : `Approve this dispatch?`)) {
      approveDispatch(batchId, dispatchId, approverName);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-lg">
              <Truck className="w-6 h-6" />
            </div>
            <span>{isNe ? 'ढुवानी तथा चलानी ड्यासबोर्ड' : 'Logistics & Dispatch Dashboard'}</span>
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            {isNe ? 'ड्राइभर भाडा, पेस्की, खरिद र चलानी अनुमोदन व्यवस्थापन' : 'Manage driver freight, advances, purchases, and dispatch approvals'}
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md transition transform active:scale-95 cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          <span>{isNe ? 'नयाँ चलानी इन्ट्री' : 'New Dispatch Entry'}</span>
        </button>
      </div>

      {/* Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
        <button
          onClick={() => setLogisticsSubTab('DASHBOARD')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            logisticsSubTab === 'DASHBOARD' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/50'
          }`}
        >
          <Navigation className="w-4 h-4" />
          <span>{isNe ? '१. मुख्य ड्यासबोर्ड' : '1. Overview'}</span>
        </button>
        <button
          onClick={() => setLogisticsSubTab('DISPATCH_LOG')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            logisticsSubTab === 'DISPATCH_LOG' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/50'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>{isNe ? '२. चलानी लग (Full Log)' : '2. Dispatch Log'}</span>
        </button>
        <button
          onClick={() => setLogisticsSubTab('PENDING_APPROVAL')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 relative ${
            logisticsSubTab === 'PENDING_APPROVAL' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/50'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>{isNe ? '३. स्वीकृत हुन बाँकी' : '3. Pending Approvals'}</span>
          {pendingApprovals.length > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white text-[10px] flex items-center justify-center rounded-full border-2 border-white font-black animate-pulse">
              {pendingApprovals.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setLogisticsSubTab('DRIVER_REPORT')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
            logisticsSubTab === 'DRIVER_REPORT' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-white/50'
          }`}
        >
          <User className="w-4 h-4" />
          <span>{isNe ? '४. ड्राइभर रिपोर्ट' : '4. Driver Report'}</span>
        </button>
      </div>

      {/* DASHBOARD VIEW */}
      {logisticsSubTab === 'DASHBOARD' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">कुल चलानी (Total)</span>
              <div className="flex items-center justify-between mt-2">
                <span className="text-2xl font-black text-slate-900">{allDispatches.length}</span>
                <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Truck className="w-5 h-5" />
                </div>
              </div>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] font-black uppercase text-rose-500 tracking-wider">अनुमोदन बाँकी (Pending)</span>
              <div className="flex items-center justify-between mt-2">
                <span className="text-2xl font-black text-rose-600">{pendingApprovals.length}</span>
                <div className="w-10 h-10 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center">
                  <Clock className="w-5 h-5" />
                </div>
              </div>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] font-black uppercase text-emerald-500 tracking-wider">वितरित (Delivered)</span>
              <div className="flex items-center justify-between mt-2">
                <span className="text-2xl font-black text-emerald-600">{allDispatches.filter(d => d.status === 'DELIVERED').length}</span>
                <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              </div>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] font-black uppercase text-amber-500 tracking-wider">बाटोमा (In Transit)</span>
              <div className="flex items-center justify-between mt-2">
                <span className="text-2xl font-black text-amber-600">{allDispatches.filter(d => d.status === 'IN_TRANSIT').length}</span>
                <div className="w-10 h-10 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center">
                  <Navigation className="w-5 h-5" />
                </div>
              </div>
            </div>
          </div>

          {/* Quick List (Recent) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">{isNe ? 'हालैका चलानीहरू' : 'Recent Dispatches'}</h3>
              <button onClick={() => setLogisticsSubTab('DISPATCH_LOG')} className="text-xs text-blue-600 font-bold hover:underline">
                {isNe ? 'सबै हेर्नुहोस्' : 'View All'}
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-bold">
                  <tr>
                    <th className="px-4 py-3">{isNe ? 'चलानी नं' : 'Challan No'}</th>
                    <th className="px-4 py-3">{isNe ? 'मिति' : 'Date'}</th>
                    <th className="px-4 py-3">{isNe ? 'पार्टी/ग्राहक' : 'Party'}</th>
                    <th className="px-4 py-3 text-right">{isNe ? 'रकम' : 'Amount'}</th>
                    <th className="px-4 py-3 text-center">{isNe ? 'प्रकार' : 'Type'}</th>
                    <th className="px-4 py-3 text-center">{isNe ? 'स्थिति' : 'Status'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {allDispatches.slice(0, 5).map((d) => (
                    <tr key={d.id} className="hover:bg-slate-50 transition">
                      <td className="px-4 py-3 font-mono font-bold text-blue-700">{d.challanNo || '-'}</td>
                      <td className="px-4 py-3 font-mono">{d.dispatchDateBs}</td>
                      <td className="px-4 py-3 font-bold">{d.dealerName}</td>
                      <td className="px-4 py-3 text-right font-mono font-bold">
                        रु. {(d.salesAmount || d.purchaseAmount || 0).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${d.type === 'SALES' ? 'bg-emerald-100 text-emerald-800' : 'bg-indigo-100 text-indigo-800'}`}>
                          {d.type === 'SALES' ? (isNe ? 'बिक्री' : 'Sales') : (isNe ? 'खरिद' : 'Purchase')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${d.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                          {d.status === 'DELIVERED' ? (isNe ? 'पुग्यो' : 'Delivered') : (isNe ? 'बाटोमा' : 'Transit')}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* DISPATCH LOG VIEW */}
      {logisticsSubTab === 'DISPATCH_LOG' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Search Bar */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs flex items-center gap-3">
            <Search className="w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder={isNe ? 'चलानी नं, पार्टी, ड्राइभर वा गाडी नम्बरबाट खोज्नुहोस्...' : 'Search by challan, party, driver, or vehicle...'}
              className="flex-1 bg-transparent border-none outline-none text-sm font-medium"
              value={searchQuery}
              onChange={(e) => setSearchSearchQuery(e.target.value)}
            />
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 font-black border-b border-slate-200 uppercase tracking-widest text-[10px]">
                  <tr>
                    <th className="px-4 py-4">{isNe ? 'चलानी नं' : 'Challan No'}</th>
                    <th className="px-4 py-4">{isNe ? 'मिति' : 'Date'}</th>
                    <th className="px-4 py-4">{isNe ? 'पार्टी/ग्राहक' : 'Party / Client'}</th>
                    <th className="px-4 py-4">{isNe ? 'गाडी/ड्राइभर' : 'Vehicle/Driver'}</th>
                    <th className="px-4 py-4 text-right">{isNe ? 'भाडा' : 'Freight'}</th>
                    <th className="px-4 py-4 text-right">{isNe ? 'कुल रकम' : 'Total'}</th>
                    <th className="px-4 py-4 text-center">{isNe ? 'प्रकार' : 'Type'}</th>
                    <th className="px-4 py-4 text-center">{isNe ? 'स्थिति' : 'Status'}</th>
                    <th className="px-4 py-4 text-center">{isNe ? 'अनुमोदन' : 'Approval'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredDispatches.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-12 text-center text-slate-400 italic">
                        {isNe ? 'कुनै चलानी रेकर्ड फेला परेन।' : 'No dispatch records found.'}
                      </td>
                    </tr>
                  ) : (
                    filteredDispatches.map((d) => (
                      <tr key={d.id} className="hover:bg-slate-50/80 transition group">
                        <td className="px-4 py-4 font-mono font-bold text-blue-700">{d.challanNo || '-'}</td>
                        <td className="px-4 py-4 font-mono font-bold text-slate-900">{d.dispatchDateBs}</td>
                        <td className="px-4 py-4">
                          <div className="font-bold text-slate-900">{d.dealerName}</div>
                          <div className="text-[10px] text-slate-500 font-bold">{d.address}</div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="font-semibold text-slate-700">{d.driverName || '-'}</div>
                          <div className="text-[10px] font-mono text-slate-400">{d.vehicleNo || '-'}</div>
                        </td>
                        <td className="px-4 py-4 text-right font-mono font-black text-blue-700">रु. {d.freightPaid?.toLocaleString()}</td>
                        <td className="px-4 py-4 text-right font-mono font-bold text-slate-900">रु. {(d.salesAmount || d.purchaseAmount || 0).toLocaleString()}</td>
                        <td className="px-4 py-4 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${d.type === 'SALES' ? 'bg-emerald-100 text-emerald-800' : 'bg-indigo-100 text-indigo-800'}`}>
                            {d.type === 'SALES' ? (isNe ? 'बिक्री' : 'Sales') : (isNe ? 'खरिद' : 'Purchase')}
                          </span>
                        </td>
                        <td className="px-4 py-4 text-center">
                          <select
                            value={d.status}
                            onChange={(e) => updateDispatchStatus(d.batchId, d.id, e.target.value as any)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-black border-none cursor-pointer focus:ring-2 focus:ring-blue-500 ${
                              d.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            <option value="IN_TRANSIT">{isNe ? 'बाटोमा' : 'In Transit'}</option>
                            <option value="DELIVERED">{isNe ? 'पुग्यो' : 'Delivered'}</option>
                          </select>
                        </td>
                        <td className="px-4 py-4 text-center">
                          {d.isApproved ? (
                            <div className="flex flex-col items-center">
                              <span className="text-emerald-600 flex items-center gap-1">
                                <CheckCircle className="w-4 h-4" />
                                <span className="text-[10px] font-black uppercase">Approved</span>
                              </span>
                              <span className="text-[9px] text-slate-400">By {d.approvedBy}</span>
                            </div>
                          ) : (
                            isAdminOrManager ? (
                              <button
                                onClick={() => handleApprove(d.batchId, d.id)}
                                className="px-3 py-1 bg-amber-100 hover:bg-amber-500 text-amber-800 hover:text-white rounded-lg text-[10px] font-black transition cursor-pointer border border-amber-300"
                              >
                                {isNe ? 'स्वीकृत गर्नुहोस्' : 'APPROVE NOW'}
                              </button>
                            ) : (
                              <span className="text-rose-500 flex items-center justify-center gap-1">
                                <AlertCircle className="w-4 h-4" />
                                <span className="text-[10px] font-bold">{isNe ? 'प्रतीक्षामा' : 'Pending'}</span>
                              </span>
                            )
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* PENDING APPROVAL VIEW */}
      {logisticsSubTab === 'PENDING_APPROVAL' && (
        <div className="space-y-4 animate-fadeIn">
          {pendingApprovals.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border-2 border-dashed border-slate-200 text-center space-y-3">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-lg font-black text-slate-900">{isNe ? 'सबै चलानी स्वीकृत भइसकेका छन्!' : 'All Dispatches Approved!'}</h3>
              <p className="text-sm text-slate-500 max-w-xs mx-auto">
                {isNe ? 'स्वीकृत गर्न बाँकी कुनै पनि चलानी रेकर्ड छैनन्।' : 'There are no pending dispatch records requiring approval at this time.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingApprovals.map((d) => (
                <div key={d.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-3 bg-rose-50 text-rose-600 rounded-bl-2xl">
                    <Clock className="w-5 h-5" />
                  </div>
                  
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">{d.challanNo}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[8px] font-black ${d.type === 'SALES' ? 'bg-emerald-100 text-emerald-800' : 'bg-indigo-100 text-indigo-800'}`}>
                        {d.type}
                      </span>
                    </div>
                    <h3 className="text-lg font-black text-slate-900">{d.dealerName}</h3>
                    <p className="text-xs font-bold text-slate-500 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {d.dispatchDateBs}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 block uppercase">Driver / Vehicle</span>
                      <p className="text-xs font-bold text-slate-800">{d.driverName || '-'} ({d.vehicleNo || '-'})</p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-bold text-slate-400 block uppercase">Total Freight</span>
                      <p className="text-sm font-black text-blue-700">रु. {d.freightPaid?.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <div className="text-center">
                      <span className="text-[9px] font-bold text-slate-400 block">Advance</span>
                      <p className="text-[11px] font-bold text-rose-600">रु. {d.driverAdvance?.toLocaleString() || 0}</p>
                    </div>
                    <div className="text-center border-x border-slate-200 col-span-2">
                      <span className="text-[9px] font-bold text-slate-400 block">Items Total</span>
                      <p className="text-[11px] font-bold text-slate-900">रु. {(d.salesAmount || d.purchaseAmount || 0).toLocaleString()}</p>
                    </div>
                    <div className="text-center">
                      <span className="text-[9px] font-bold text-slate-400 block">Total Qty</span>
                      <p className="text-[11px] font-bold text-slate-900">{d.dispatchedQuantity}</p>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-1">
                    {isAdminOrManager ? (
                      <button
                        onClick={() => handleApprove(d.batchId, d.id)}
                        className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>APPROVE NOW</span>
                      </button>
                    ) : (
                      <div className="flex-1 py-2.5 bg-rose-50 text-rose-700 font-black text-xs rounded-xl border border-rose-200 flex items-center justify-center gap-2">
                        <AlertCircle className="w-4 h-4" />
                        <span>AWAITING MANAGER APPROVAL</span>
                      </div>
                    )}
                    <button 
                      onClick={() => setPrintChallan(d)}
                      className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition cursor-pointer"
                    >
                      <Printer className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
      {/* DRIVER REPORT VIEW */}
      {logisticsSubTab === 'DRIVER_REPORT' && (
        <div className="space-y-6 animate-fadeIn">
          <div id="driver-report-table-container" className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 bg-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">
                  {isNe ? 'ड्राइभर तथा ढुवानी रिपोर्ट (Driver Freight Report)' : 'Driver & Freight Report Summary'}
                </h3>
                <div className="flex flex-wrap gap-4 mt-2">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{isNe ? 'अवधि (Period)' : 'Period'}</label>
                    <select
                      value={driverReportPeriod}
                      onChange={(e) => setDriverReportPeriod(e.target.value as any)}
                      className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:ring-2 focus:ring-blue-500 outline-none shadow-xs"
                    >
                      <option value="TODAY">{isNe ? 'आज (Today)' : 'Today'}</option>
                      <option value="THIS_MONTH">{isNe ? 'यो महिना (This Month)' : 'This Month'}</option>
                      <option value="THIS_YEAR">{isNe ? 'यो बार्षिक (This Year)' : 'This Year'}</option>
                      <option value="CUSTOM_MONTH">{isNe ? 'महिना अनुसार (By Month)' : 'By Month'}</option>
                      <option value="CUSTOM_YEAR">{isNe ? 'बर्ष अनुसार (By Year)' : 'By Year'}</option>
                      <option value="ALL">{isNe ? 'सबै समय (All Time)' : 'All Time'}</option>
                    </select>
                  </div>

                  {(driverReportPeriod === 'CUSTOM_MONTH' || driverReportPeriod === 'CUSTOM_YEAR') && (
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{isNe ? 'बर्ष (Year)' : 'Year'}</label>
                      <select
                        value={selectedYearForReport}
                        onChange={(e) => setSelectedYearForReport(e.target.value)}
                        className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:ring-2 focus:ring-blue-500 outline-none shadow-xs"
                      >
                        {yearsList.map(y => (
                          <option key={y} value={y}>{y}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  {driverReportPeriod === 'CUSTOM_MONTH' && (
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{isNe ? 'महिना (Month)' : 'Month'}</label>
                      <select
                        value={selectedMonthForReport}
                        onChange={(e) => setSelectedMonthForReport(e.target.value)}
                        className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:ring-2 focus:ring-blue-500 outline-none shadow-xs"
                      >
                        {monthsList.map(m => (
                          <option key={m.id} value={m.id}>{isNe ? m.ne : m.en}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{isNe ? 'ड्राइभर (Driver)' : 'Driver'}</label>
                    <select
                      value={selectedDriverForReport}
                      onChange={(e) => setSelectedDriverForReport(e.target.value)}
                      className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:ring-2 focus:ring-blue-500 outline-none shadow-xs"
                    >
                      <option value="ALL">{isNe ? 'सबै ड्राइभर (All Drivers)' : 'All Drivers'}</option>
                      {uniqueDriversList.map(name => (
                        <option key={name} value={name}>{name}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => printPage()}
                  className="p-2.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-slate-600 transition shadow-xs flex items-center gap-2 text-xs font-bold"
                >
                  <Printer className="w-4 h-4" />
                  <span>{isNe ? 'प्रिन्ट' : 'Print'}</span>
                </button>
                <button
                  onClick={exportDriverReportPdf}
                  className="p-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition shadow-md flex items-center gap-2 text-xs font-bold"
                >
                  <Download className="w-4 h-4" />
                  <span>{isNe ? 'PDF डाउनलोड' : 'Download PDF'}</span>
                </button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-600 font-black uppercase text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-5 py-4">{isNe ? 'ड्राइभरको नाम' : 'Driver Name'}</th>
                    <th className="px-5 py-4 text-center">{isNe ? 'ट्रिप संख्या' : 'Trips'}</th>
                    <th className="px-5 py-4">{isNe ? 'गाडी नम्बरहरू' : 'Vehicles'}</th>
                    <th className="px-5 py-4 text-right">{isNe ? 'कुल भाडा (Agreed)' : 'Agreed Freight'}</th>
                    <th className="px-5 py-4 text-right">{isNe ? 'कुल पेस्की (Advance)' : 'Total Advance'}</th>
                    <th className="px-5 py-4 text-right">{isNe ? 'चुक्ता भाडा (Paid)' : 'Paid Balance'}</th>
                    <th className="px-5 py-4 text-right">{isNe ? 'बाँकी (Net Owed)' : 'Net Owed'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {driverReport.filter(r => selectedDriverForReport === 'ALL' || r.driverName === selectedDriverForReport).length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-5 py-12 text-center text-slate-400 italic">
                        {isNe ? 'कुनै ड्राइभर रेकर्ड फेला परेन।' : 'No driver records found.'}
                      </td>
                    </tr>
                  ) : (
                    driverReport.filter(r => selectedDriverForReport === 'ALL' || r.driverName === selectedDriverForReport).map((row, idx) => (
                      <tr 
                        key={idx} 
                        onClick={() => exportSingleDriverReportPdf(row.driverName)}
                        className="hover:bg-blue-50/50 transition group cursor-pointer"
                        title={isNe ? 'ड्राइभरको विस्तृत रिपोर्ट डाउनलोड गर्न क्लिक गर्नुहोस्' : 'Click to download detailed driver report'}
                      >
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-black border border-slate-200">
                              {row.driverName.charAt(0)}
                            </div>
                            <span className="font-bold text-slate-900 text-sm">{row.driverName}</span>
                          </div>
                        </td>
                        <td className="px-5 py-4 text-center">
                          <span className="px-2.5 py-1 bg-blue-50 text-blue-700 rounded-lg font-black border border-blue-100">
                            {row.trips}
                          </span>
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex flex-wrap gap-1">
                            {Array.from(row.vehicles).map((v, vIdx) => (
                              <span key={vIdx} className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[9px] font-mono font-bold border border-slate-200">
                                {v}
                              </span>
                            ))}
                            {row.vehicles.size === 0 && <span className="text-slate-400">-</span>}
                          </div>
                        </td>
                        <td className="px-5 py-4 text-right font-mono font-black text-slate-900">
                          रु. {row.totalFreight.toLocaleString()}
                        </td>
                        <td className="px-5 py-4 text-right font-mono font-black text-rose-600">
                          रु. {row.totalAdvance.toLocaleString()}
                        </td>
                        <td className="px-5 py-4 text-right font-mono font-black text-indigo-600">
                          रु. {row.totalBalancePaid.toLocaleString()}
                        </td>
                        <td className="px-5 py-4 text-right">
                          <span className={`font-mono font-black text-sm ${row.totalFreight - row.totalAdvance - row.totalBalancePaid >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                            रु. {(row.totalFreight - row.totalAdvance - row.totalBalancePaid).toLocaleString()}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                {driverReport.length > 0 && (
                  <tfoot className="bg-slate-50 font-black border-t-2 border-slate-200">
                    <tr>
                      <td className="px-5 py-4" colSpan={3}>{isNe ? 'जम्मा (Grand Total):' : 'Grand Total:'}</td>
                      <td className="px-5 py-4 text-right font-mono text-blue-700">
                        रु. {driverReport.reduce((sum, r) => sum + r.totalFreight, 0).toLocaleString()}
                      </td>
                      <td className="px-5 py-4 text-right font-mono text-rose-700">
                        रु. {driverReport.reduce((sum, r) => sum + r.totalAdvance, 0).toLocaleString()}
                      </td>
                      <td className="px-5 py-4 text-right font-mono text-indigo-700">
                        रु. {driverReport.reduce((sum, r) => sum + r.totalBalancePaid, 0).toLocaleString()}
                      </td>
                      <td className="px-5 py-4 text-right font-mono text-emerald-700 text-sm">
                        रु. {driverReport.reduce((sum, r) => sum + (r.totalFreight - r.totalAdvance - r.totalBalancePaid), 0).toLocaleString()}
                      </td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: NEW DISPATCH ENTRY */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-modalScale">
            {/* Header */}
            <div className="px-6 py-5 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-lg">
                  <Truck className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-xl font-black">{isNe ? 'नयाँ चलानी / भौचर इन्ट्री' : 'New Challan / Voucher Entry'}</h3>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{isNe ? 'खरिद तथा बिक्री चलानी व्यवस्थापन' : 'Manage Purchase & Sales Dispatches'}</p>
                </div>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white p-2 transition cursor-pointer bg-slate-800 rounded-xl">
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSaveDispatch} className="p-6 space-y-6">
              {/* Voucher Header Info */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-5 bg-slate-50 rounded-2xl border border-slate-200 shadow-inner">
                <div className="md:col-span-1">
                  <label className="block text-[10px] font-black text-slate-500 mb-1 uppercase tracking-widest">{isNe ? 'चलानी मिति (Date)' : 'Challan Date'}</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={dispatchDateBs}
                      onChange={(e) => setDispatchDateBs(e.target.value)}
                      placeholder="YYYY-MM-DD"
                      className="w-full pl-9 pr-4 py-2.5 border-2 border-slate-200 rounded-xl font-mono font-bold text-slate-900 bg-white focus:border-blue-500 outline-none"
                    />
                  </div>
                </div>

                <div className="md:col-span-1">
                  <label className="block text-[10px] font-black text-slate-500 mb-1 uppercase tracking-widest">{isNe ? 'चलानी नम्बर (No.)' : 'Challan No.'}</label>
                  <div className="relative">
                    <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={challanNo}
                      onChange={(e) => setChallanNo(e.target.value)}
                      className="w-full pl-9 pr-4 py-2.5 border-2 border-slate-200 rounded-xl font-mono font-bold text-slate-900 bg-white focus:border-blue-500 outline-none"
                    />
                  </div>
                </div>

                <div className="md:col-span-1">
                  <label className="block text-[10px] font-black text-slate-500 mb-1 uppercase tracking-widest">{isNe ? 'चलानीको प्रकार (Type)' : 'Challan Type'}</label>
                  <select
                    value={dispatchType}
                    onChange={(e) => {
                      setDispatchType(e.target.value as any);
                      setSelectedBillId('');
                      if (e.target.value !== 'MANUFACTURE') setBatchId('');
                    }}
                    className={`w-full px-4 py-2.5 border-2 rounded-xl font-black outline-none transition ${
                      dispatchType === 'SALES' ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : 
                      dispatchType === 'PURCHASE' ? 'border-indigo-200 bg-indigo-50 text-indigo-800' :
                      'border-purple-200 bg-purple-50 text-purple-800'
                    }`}
                  >
                    <option value="SALES">{isNe ? 'बिक्री चलानी (Sales)' : 'Sales Challan'}</option>
                    <option value="PURCHASE">{isNe ? 'खरिद चलानी (Purchase)' : 'Purchase Challan'}</option>
                    <option value="MANUFACTURE">{isNe ? 'उत्पादन चलानी (Manufacture)' : 'Manufacture Challan'}</option>
                  </select>
                </div>

                <div className="md:col-span-1">
                  {dispatchType === 'MANUFACTURE' ? (
                    <>
                      <label className="block text-[10px] font-black text-slate-500 mb-1 uppercase tracking-widest">{isNe ? 'उत्पादन ब्याच (Batch)' : 'Batch Reference'}</label>
                      <select
                        required
                        value={batchId}
                        onChange={(e) => setBatchId(e.target.value)}
                        className="w-full px-4 py-2.5 border-2 border-slate-200 rounded-xl font-bold text-slate-900 bg-white focus:border-blue-500 outline-none"
                      >
                        <option value="">{isNe ? 'ब्याच छान्नुहोस्' : 'Select Batch'}</option>
                        {productionBatches.map(b => (
                          <option key={b.id} value={b.id}>{b.batchNumber} — {isNe ? b.productNameNe : b.productNameEn}</option>
                        ))}
                      </select>
                    </>
                  ) : (
                    <>
                      <label className="block text-[10px] font-black text-slate-500 mb-1 uppercase tracking-widest">
                        {dispatchType === 'SALES' ? (isNe ? 'बिक्री बिल छान्नुहोस्' : 'Select Sales Bill') : (isNe ? 'खरिद बिल छान्नुहोस्' : 'Select Purchase Bill')}
                      </label>
                      <select
                        value={selectedBillId}
                        onChange={(e) => setSelectedBillId(e.target.value)}
                        className="w-full px-4 py-2.5 border-2 border-slate-200 rounded-xl font-bold text-slate-900 bg-white focus:border-blue-500 outline-none"
                      >
                        <option value="">{isNe ? '--- बिल छान्नुहोस् ---' : '--- Select Bill ---'}</option>
                        {dispatchType === 'SALES' ? (
                          invoices.filter(i => i.status === 'ACTIVE').map(inv => (
                            <option key={inv.id} value={inv.id}>{inv.invoiceNo} - {inv.customerName} (रु. {inv.grandTotal})</option>
                          ))
                        ) : (
                          purchases.map(pur => (
                            <option key={pur.id} value={pur.id}>{pur.purchaseBillNo} - {pur.supplierName} (रु. {pur.grandTotal})</option>
                          ))
                        )}
                      </select>
                    </>
                  )}
                </div>
              </div>

              {/* Party & Logistics Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Party Details */}
                <div className="space-y-4 p-5 bg-white border border-slate-200 rounded-2xl shadow-sm">
                  <div className="flex items-center gap-2 mb-2">
                    <User className="w-5 h-5 text-blue-600" />
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">{isNe ? 'पार्टी विवरण' : 'Party Details'}</h4>
                  </div>
                  
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">{isNe ? 'पार्टी छान्नुहोस् (Select Party)' : 'Select Party'}</label>
                    <select
                      value={partyId}
                      onChange={(e) => setPartyId(e.target.value)}
                      className="w-full px-4 py-2.5 border-2 border-slate-100 rounded-xl font-bold text-slate-900 bg-slate-50 focus:border-blue-500 outline-none"
                    >
                      <option value="">{isNe ? 'पार्टी छान्नुहोस् (पर्छ भने)' : 'Select Existing Party (Optional)'}</option>
                      {parties.map(p => (
                        <option key={p.id} value={p.id}>{p.name} ({p.address})</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">{isNe ? 'पार्टीको नाम (Party Name):*' : 'Party Name:*'}</label>
                    <input
                      type="text"
                      required
                      placeholder={isNe ? 'पार्टीको नाम लेख्नुहोस्' : 'Enter party name'}
                      value={dealerName}
                      onChange={(e) => setDealerName(e.target.value)}
                      className="w-full px-4 py-2.5 border-2 border-slate-100 rounded-xl font-bold text-slate-900 bg-slate-50 focus:border-blue-500 outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">{isNe ? 'ठेगाना (Address)' : 'Address'}</label>
                      <input
                        type="text"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        className="w-full px-4 py-2.5 border-2 border-slate-100 rounded-xl font-bold text-slate-900 bg-slate-50 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">{isNe ? 'फोन (Phone)' : 'Phone'}</label>
                      <input
                        type="text"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-4 py-2.5 border-2 border-slate-100 rounded-xl font-bold text-slate-900 bg-slate-50 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Driver & Vehicle */}
                <div className="space-y-4 p-5 bg-white border border-slate-200 rounded-2xl shadow-sm">
                  <div className="flex items-center gap-2 mb-2">
                    <Navigation className="w-5 h-5 text-indigo-600" />
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">{isNe ? 'ढुवानी विवरण' : 'Logistics Details'}</h4>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">{isNe ? 'ड्राइभरको नाम' : 'Driver Name'}</label>
                      <input
                        type="text"
                        list="driver-names-list"
                        value={driverName}
                        onChange={(e) => setDriverName(e.target.value)}
                        className="w-full px-4 py-2.5 border-2 border-slate-100 rounded-xl font-bold bg-slate-50 focus:border-indigo-500 outline-none"
                      />
                      <datalist id="driver-names-list">
                        {employees.map(e => (
                          <option key={e.id} value={e.name} />
                        ))}
                      </datalist>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">{isNe ? 'गाडी नम्बर' : 'Vehicle No'}</label>
                      <input
                        type="text"
                        value={vehicleNo}
                        onChange={(e) => setVehicleNo(e.target.value)}
                        className="w-full px-4 py-2.5 border-2 border-slate-100 rounded-xl font-mono font-bold bg-slate-50 focus:border-indigo-500 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">{isNe ? 'कुल भाडा (Total)' : 'Total Freight'}</label>
                      <input
                        type="number"
                        value={freight}
                        onChange={(e) => setFreight(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2.5 border-2 border-slate-100 rounded-xl font-mono font-bold bg-slate-50 text-blue-700 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">{isNe ? 'पेस्की (Advance)' : 'Advance'}</label>
                      <input
                        type="number"
                        value={advance}
                        onChange={(e) => setAdvance(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2.5 border-2 border-slate-100 rounded-xl font-mono font-bold bg-slate-50 text-rose-600 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">{isNe ? 'चुक्ता (Paid)' : 'Paid Balance'}</label>
                      <input
                        type="number"
                        value={balancePaid}
                        onChange={(e) => setBalancePaid(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2.5 border-2 border-slate-100 rounded-xl font-mono font-bold bg-slate-50 text-indigo-700 outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Particulars Table */}
              <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                <div className="px-5 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4 text-slate-600" />
                    <h4 className="text-xs font-black text-slate-700 uppercase tracking-widest">{isNe ? 'सामानको विवरण (Particulars)' : 'Items / Particulars'}</h4>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddRow}
                    className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-black rounded-lg transition flex items-center gap-1.5 cursor-pointer shadow-md"
                  >
                    <Plus className="w-3 h-3" />
                    {isNe ? 'थप्नुहोस्' : 'ADD ITEM'}
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-100 text-slate-600 font-black uppercase text-[10px] tracking-wider">
                      <tr>
                        <th className="px-4 py-3 w-12 text-center">S.N.</th>
                        <th className="px-4 py-3 w-28">HS Code</th>
                        <th className="px-4 py-3">{isNe ? 'सामान / विवरण (Particulars)' : 'Item / Particular'}</th>
                        <th className="px-4 py-3 w-24 text-center">{isNe ? 'एकाइ' : 'Qty'}</th>
                        <th className="px-4 py-3 w-32 text-right">{isNe ? 'दर (Rate)' : 'Rate'}</th>
                        <th className="px-4 py-3 w-36 text-right">{isNe ? 'जम्मा (Total)' : 'Total'}</th>
                        <th className="px-4 py-3 w-12"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {particulars.map((item, index) => (
                        <tr key={index} className="hover:bg-slate-50/50 transition">
                          <td className="px-4 py-3 text-center font-bold text-slate-400">{item.sn}</td>
                          <td className="px-4 py-3">
                            <input
                              type="text"
                              placeholder="HS Code"
                              value={item.hsCode || ''}
                              onChange={(e) => handleItemChange(index, 'hsCode', e.target.value)}
                              className="w-full px-2 py-1.5 border border-slate-200 rounded-lg font-mono text-[10px]"
                            />
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex flex-col gap-1">
                              <select
                                value={item.itemId}
                                onChange={(e) => handleItemChange(index, 'itemId', e.target.value)}
                                className="w-full px-2 py-1.5 border border-slate-200 rounded-lg font-bold text-slate-900 bg-white focus:border-blue-500 outline-none"
                              >
                                <option value="">{isNe ? '--- सामान छान्नुहोस् ---' : '--- Select Item ---'}</option>
                                {inventoryItems.map(inv => (
                                  <option key={inv.id} value={inv.id}>
                                    {inv.code} - {isNe ? inv.nameNe : inv.nameEn} (Stock: {inv.currentStock})
                                  </option>
                                ))}
                              </select>
                              {!item.itemId && (
                                <input
                                  type="text"
                                  placeholder={isNe ? 'म्यानुअल विवरण...' : 'Manual particular...'}
                                  value={item.particular}
                                  onChange={(e) => handleItemChange(index, 'particular', e.target.value)}
                                  className="w-full px-2 py-1.5 border border-slate-100 rounded-lg bg-slate-50 text-[10px] font-medium"
                                />
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <input
                              type="number"
                              min={0}
                              value={item.qty}
                              onChange={(e) => handleItemChange(index, 'qty', parseFloat(e.target.value) || 0)}
                              className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-center font-mono font-bold bg-white"
                            />
                          </td>
                          <td className="px-4 py-3">
                            <input
                              type="number"
                              min={0}
                              value={item.rate}
                              onChange={(e) => handleItemChange(index, 'rate', parseFloat(e.target.value) || 0)}
                              className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-right font-mono font-bold bg-white"
                            />
                          </td>
                          <td className="px-4 py-3 text-right font-mono font-black text-slate-900">
                            रु. {item.total?.toLocaleString()}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveRow(index)}
                              className="p-1.5 text-slate-300 hover:text-rose-500 transition cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Totals Section */}
                <div className="p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex-1 w-full max-w-sm">
                    <label className="block text-[10px] font-black text-slate-400 mb-1 uppercase tracking-widest">{isNe ? 'कैफियत (Notes)' : 'Additional Notes'}</label>
                    <textarea
                      rows={2}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder={isNe ? 'यहाँ केहि थप विवरण लेख्नुहोस्...' : 'Enter any notes...'}
                      className="w-full px-4 py-2 border-2 border-slate-200 rounded-xl bg-white text-xs font-medium outline-none focus:border-blue-500"
                    />
                  </div>
                  <div className="w-full sm:w-64 space-y-2">
                    <div className="flex items-center justify-between text-slate-500 font-bold">
                      <span>{isNe ? 'आइटम उप-जम्मा:' : 'Items Subtotal:'}</span>
                      <span className="font-mono">रु. {subtotal.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-t border-slate-300">
                      <span className="text-sm font-black text-slate-900">{isNe ? 'कुल चलानी रकम:' : 'Total Amount:'}</span>
                      <span className="text-lg font-black text-blue-700 font-mono">रु. {subtotal.toLocaleString()}</span>
                    </div>
                    <div className="text-[10px] font-black text-right text-slate-400 italic">
                      * {dispatchType === 'SALES' ? (isNe ? 'यो बिक्रीमा रेकर्ड हुनेछ' : 'Will record as Sales') : (isNe ? 'यो खरिदमा रेकर्ड हुनेछ' : 'Will record as Purchase')}
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-4 bg-slate-100 hover:bg-slate-200 text-slate-600 font-black rounded-2xl transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <XCircle className="w-5 h-5" />
                  <span>{isNe ? 'रद्द' : 'Cancel'}</span>
                </button>
                <button
                  type="submit"
                  className="flex-[2] py-4 bg-blue-600 hover:bg-blue-700 text-white font-black rounded-2xl shadow-xl transition transform active:scale-95 cursor-pointer flex items-center justify-center gap-3"
                >
                  <CheckCircle className="w-6 h-6" />
                  <span className="text-lg uppercase tracking-wide">{isNe ? 'चलानी सुरक्षित गर्नुहोस्' : 'Save & Confirm Challan'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* MODAL: DRIVER DETAIL REPORT */}
      {isDriverDetailModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[95vh] flex flex-col">
            {/* Header */}
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white">
                  <User className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black">{isNe ? 'ड्राइभर विस्तृत रिपोर्ट' : 'Driver Detailed Report'}</h3>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">{activeDriverName}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadActiveDriverPdf}
                  disabled={isGeneratingPdf}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition disabled:opacity-50"
                >
                  {isGeneratingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                  <span>{isNe ? 'PDF डाउनलोड' : 'Download PDF'}</span>
                </button>
                <button 
                  onClick={() => setIsDriverDetailModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-white transition"
                >
                  <XCircle className="w-6 h-6" />
                </button>
              </div>
            </div>

            {/* Printable Content */}
            <div className="flex-1 overflow-y-auto bg-slate-50 p-4 sm:p-8">
              <div id="single-driver-report-printable" className="bg-white p-8 rounded-lg shadow-sm border border-slate-200 min-h-full">
                {/* Company Header */}
                <div className="border-b-2 border-slate-900 pb-4 mb-6 flex justify-between items-start">
                  <div>
                    <h1 className="text-2xl font-black text-slate-900">{company.name}</h1>
                    <p className="text-sm font-bold text-slate-600">{company.address}</p>
                    <p className="text-xs font-medium text-slate-500">
                      PAN: {company.panVatNo} | Ph: {company.phone}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="bg-slate-900 text-white px-3 py-1 rounded text-[10px] font-black uppercase tracking-widest mb-2 inline-block">
                      {isNe ? 'ड्राइभर रिपोर्ट' : 'DRIVER REPORT'}
                    </div>
                    <p className="text-xs font-mono font-bold text-slate-900">{isNe ? 'मिति:' : 'Date:'} {todayBs}</p>
                  </div>
                </div>

                <div className="mb-6">
                  <div className="grid grid-cols-2 gap-8">
                    <div>
                      <span className="text-[10px] font-black text-slate-400 uppercase block tracking-wider">{isNe ? 'ड्राइभरको नाम' : 'Driver Name'}</span>
                      <p className="text-lg font-black text-slate-900 underline decoration-blue-500 underline-offset-4">{activeDriverName}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-black text-slate-400 uppercase block tracking-wider">{isNe ? 'अवधि' : 'Period'}</span>
                      <p className="text-sm font-bold text-slate-700">{driverReportPeriod}</p>
                    </div>
                  </div>
                </div>

                {/* Report Table */}
                <table className="w-full border-collapse border-2 border-slate-900 text-xs">
                  <thead>
                    <tr className="bg-slate-100 border-b-2 border-slate-900 font-black">
                      <th className="border border-slate-900 px-3 py-2 text-left">{isNe ? 'मिति' : 'Date'}</th>
                      <th className="border border-slate-900 px-3 py-2 text-left">{isNe ? 'चलानी नं' : 'Challan No'}</th>
                      <th className="border border-slate-900 px-3 py-2 text-left">{isNe ? 'पार्टी/ग्राहक' : 'Party'}</th>
                      <th className="border border-slate-900 px-3 py-2 text-left">{isNe ? 'गाडी नं' : 'Vehicle'}</th>
                      <th className="border border-slate-900 px-3 py-2 text-right">{isNe ? 'भाडा (Agreed)' : 'Agreed'}</th>
                      <th className="border border-slate-900 px-3 py-2 text-right">{isNe ? 'पेस्की (Advance)' : 'Advance'}</th>
                      <th className="border border-slate-900 px-3 py-2 text-right">{isNe ? 'चुक्ता (Paid)' : 'Paid'}</th>
                      <th className="border border-slate-900 px-3 py-2 text-right">{isNe ? 'बाँकी (Net)' : 'Net'}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allDispatches
                      .filter(d => (d.driverName?.trim() || (isNe ? 'नाम नभएको ड्राइभर' : 'Unnamed Driver')) === activeDriverName)
                      .filter(d => {
                        if (driverReportPeriod === 'ALL') return true;
                        if (driverReportPeriod === 'TODAY') return d.dispatchDateBs === todayBs;
                        const { year: dYear, monthCode: dMonth } = parseBsYearMonth(d.dispatchDateBs);
                        const { year: tYear, monthCode: tMonth } = parseBsYearMonth(todayBs);
                        if (driverReportPeriod === 'THIS_MONTH') return dYear === tYear && dMonth === tMonth;
                        if (driverReportPeriod === 'THIS_YEAR') return getFiscalYear(d.dispatchDateBs) === getFiscalYear(todayBs);
                        return true;
                      })
                      .map((d, i) => {
                        const net = (d.freightPaid || 0) - (d.driverAdvance || 0) - (d.balanceAmountPaid || 0);
                        return (
                          <tr key={i} className="border-b border-slate-300">
                            <td className="border border-slate-900 px-3 py-2 font-mono">{d.dispatchDateBs}</td>
                            <td className="border border-slate-900 px-3 py-2 font-bold text-blue-700">{d.challanNo}</td>
                            <td className="border border-slate-900 px-3 py-2 font-semibold">{d.dealerName}</td>
                            <td className="border border-slate-900 px-3 py-2 font-mono">{d.vehicleNo || '-'}</td>
                            <td className="border border-slate-900 px-3 py-2 text-right font-mono">{d.freightPaid?.toLocaleString()}</td>
                            <td className="border border-slate-900 px-3 py-2 text-right font-mono text-rose-600">{d.driverAdvance?.toLocaleString()}</td>
                            <td className="border border-slate-900 px-3 py-2 text-right font-mono text-indigo-600">{d.balanceAmountPaid?.toLocaleString()}</td>
                            <td className="border border-slate-900 px-3 py-2 text-right font-mono font-bold">{net.toLocaleString()}</td>
                          </tr>
                        );
                      })}
                  </tbody>
                  <tfoot className="bg-slate-50 font-black border-t-2 border-slate-900">
                    {(() => {
                      const filtered = allDispatches
                        .filter(d => (d.driverName?.trim() || (isNe ? 'नाम नभएको ड्राइभर' : 'Unnamed Driver')) === activeDriverName)
                        .filter(d => {
                          if (driverReportPeriod === 'ALL') return true;
                          if (driverReportPeriod === 'TODAY') return d.dispatchDateBs === todayBs;
                          const { year: dYear, monthCode: dMonth } = parseBsYearMonth(d.dispatchDateBs);
                          const { year: tYear, monthCode: tMonth } = parseBsYearMonth(todayBs);
                          if (driverReportPeriod === 'THIS_MONTH') return dYear === tYear && dMonth === tMonth;
                          if (driverReportPeriod === 'THIS_YEAR') return getFiscalYear(d.dispatchDateBs) === getFiscalYear(todayBs);
                          return true;
                        });
                      return (
                        <tr>
                          <td className="border border-slate-900 px-3 py-3" colSpan={4}>{isNe ? 'जम्मा (Total):' : 'Total:'}</td>
                          <td className="border border-slate-900 px-3 py-3 text-right font-mono">
                            {filtered.reduce((sum, d) => sum + (d.freightPaid || 0), 0).toLocaleString()}
                          </td>
                          <td className="border border-slate-900 px-3 py-3 text-right font-mono text-rose-700">
                            {filtered.reduce((sum, d) => sum + (d.driverAdvance || 0), 0).toLocaleString()}
                          </td>
                          <td className="border border-slate-900 px-3 py-3 text-right font-mono text-indigo-700">
                            {filtered.reduce((sum, d) => sum + (d.balanceAmountPaid || 0), 0).toLocaleString()}
                          </td>
                          <td className="border border-slate-900 px-3 py-3 text-right font-mono text-lg underline decoration-double">
                            {filtered.reduce((sum, d) => sum + ((d.freightPaid || 0) - (d.driverAdvance || 0) - (d.balanceAmountPaid || 0)), 0).toLocaleString()}
                          </td>
                        </tr>
                      );
                    })()}
                  </tfoot>
                </table>

                <div className="mt-12 grid grid-cols-2 gap-12 text-center text-xs font-bold text-slate-600">
                  <div className="border-t border-slate-400 pt-2">
                    {isNe ? 'ड्राइभरको हस्ताक्षर' : 'Driver Signature'}
                  </div>
                  <div className="border-t border-slate-400 pt-2">
                    {isNe ? 'अधिकृत हस्ताक्षर' : 'Authorized Signatory'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {printChallan && (
        <ChallanPrintModal 
          dispatch={printChallan} 
          onClose={() => setPrintChallan(null)} 
        />
      )}
    </div>
  );
};
