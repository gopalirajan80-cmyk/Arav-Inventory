import React, { useState, useMemo, useEffect } from 'react';
import { DualDateInput } from './DualDateInput';
import { isCustomerParty, isSupplierParty } from '../utils/partyTxn';
import { NumField } from './NumField';
import { useApp } from '../context/AppContext';
import { BillType, PaymentMode, InvoiceItem, Item } from '../types';
import {
  Receipt,
  Plus,
  Trash2,
  Pencil,
  Printer,
  Search,
  User,
  CreditCard,
  Truck,
  Percent,
  Check,
  AlertCircle,
  Briefcase,
  Wallet,
  Camera,
  Image as ImageIcon,
  Sparkles,
  Calendar,
  Edit2,
  X,
  Scan,
  CheckCircle2,
  QrCode,
  Phone,
  MapPin,
  Copy,
  ChevronDown,
  AlertTriangle,
  FileSpreadsheet,
  Save,
  Calculator
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import {
  formatCurrency,
  getTodayBsString,
  getTodayAdString,
  formatBsDateNepaliText,
  toNepaliDigits
} from '../utils/nepaliCalendar';
import { calculateInvoiceTotals, amountInNepaliWords } from '../utils/vatCalculator';
import { fileToDataUrl } from '../utils/cameraHelper';
import { parseExcelFile, parseExcelNumericValue } from '../utils/excelEngine';
import { InvoicePrintModal } from './InvoicePrintModal';
import { HandwrittenBillScannerModal } from './HandwrittenBillScannerModal';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { BillingSubModules } from './BillingSubModules';
import { RecurringInvoicesScreen } from './RecurringInvoicesScreen';
import { Party, Invoice } from '../types';
import { validatePan } from '../utils/validation';
import { authFetch } from '../utils/auth';

export const BillingScreen: React.FC = () => {
  const {
    items,
    company,
    parties,
    saveParty,
    employees,
    invoices,
    language,
    createInvoice,
    updateInvoice,
    invoiceToEdit,
    clearInvoiceToEdit,
    startEditInvoice,
    importInvoicesList,
    cancelInvoice,
    deleteInvoice,
    getEmployeePayrollSummary,
    billingSubTab,
    setBillingSubTab,
    setVoucherSubTab,
    setActiveTab,
    currentAccount,
    currentRole,
    t
  } = useApp();

  const isNe = language === 'ne';

  // Bill configuration state
  const [billType, setBillType] = useState<BillType>('VAT');
  const [manualInvoiceNo, setManualInvoiceNo] = useState<string>('');
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('CASH');

  // Bank Deposit / Transfer state
  const [selectedBankAccountId, setSelectedBankAccountId] = useState<string>(
    company.bankAccounts?.[0]?.id || ''
  );
  const [bankName, setBankName] = useState<string>(
    company.bankAccounts?.[0]?.bankName || ''
  );
  const [bankAccountNo, setBankAccountNo] = useState<string>(
    company.bankAccounts?.[0]?.accountNumber || ''
  );
  const [transactionRef, setTransactionRef] = useState<string>('');

  // Customer / Employee Mode state
  const [isStaffPurchase, setIsStaffPurchase] = useState<boolean>(false);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>('');

  // Customer fields state
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPan, setCustomerPan] = useState<string>('');
  const [customerPanError, setCustomerPanError] = useState<boolean>(false);
  const handleCustomerPanChange = (pan: string) => {
    setCustomerPan(pan);
    setCustomerPanError(pan.length > 0 && !validatePan(pan));
  };
  const [customerAddress, setCustomerAddress] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [selectedPartyId, setSelectedPartyId] = useState<string>('');
  const [previousDue, setPreviousDue] = useState<number>(0);
  const [customerSearchQuery, setCustomerSearchQuery] = useState<string>('');

  // Bank QR Code Modal state
  const [isBankQrModalOpen, setIsBankQrModalOpen] = useState<boolean>(false);
  const [copiedBankAcc, setCopiedBankAcc] = useState<boolean>(false);
  const [qrSelectedBankId, setQrSelectedBankId] = useState<string>(company.bankAccounts?.[0]?.id || '');
  const [qrTxnRef, setQrTxnRef] = useState<string>('');

  // Line items state
  const [lineItems, setLineItems] = useState<InvoiceItem[]>([]);
  
  // Billing Entry Mode: Itemized vs Lump-sum
  const [billingEntryMode, setBillingEntryMode] = useState<'ITEMIZED' | 'LUMP_SUM'>('ITEMIZED');
  
  // Lump-sum Amount Entry state
  const [lumpSumName, setLumpSumName] = useState<string>('एकमुष्ठ बिक्री रकम');
  const [lumpSumAmount, setLumpSumAmount] = useState<number | ''>('');
  const [lumpSumUnit, setLumpSumUnit] = useState<string>('जम्मा');
  const [lumpSumHsCode, setLumpSumHsCode] = useState<string>('');
  const [lumpSumIsVatExempt, setLumpSumIsVatExempt] = useState<boolean>(false);

  // Current adding item state
  const [selectedItemId, setSelectedItemId] = useState<string>('');
  const [inputQty, setInputQty] = useState<number>(1);
  const [inputRate, setInputRate] = useState<number>(0);
  const [inputSize, setInputSize] = useState<string>('');
  const [isCustomSize, setIsCustomSize] = useState<boolean>(false);
  const [inputDiscount, setInputDiscount] = useState<number>(0);
  const [inputIsVatExempt, setInputIsVatExempt] = useState<boolean>(false);
  const [inputUnitMode, setInputUnitMode] = useState<'PRIMARY' | 'SECONDARY'>('PRIMARY');
  const [itemSearch, setItemSearch] = useState<string>('');
  
  // Manual VAT Exemption setting under Subtotal
  const [manualExemptInput, setManualExemptInput] = useState<number | ''>('');
  const [isManualExemptMode, setIsManualExemptMode] = useState<boolean>(false);

  // Bill-level adjustments
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [freightCharge, setFreightCharge] = useState<number>(0);
  const [notes, setNotes] = useState<string>('');
  const [billPhotoUrl, setBillPhotoUrl] = useState<string>('');

  // AI Handwritten Bill Scanner Modal
  const [isAiScanModalOpen, setIsAiScanModalOpen] = useState<boolean>(false);

  // Camera Barcode & QR Scanner Modal
  const [isBarcodeScannerOpen, setIsBarcodeScannerOpen] = useState<boolean>(false);
  const [scanToast, setScanToast] = useState<{ message: string; type: 'success' | 'info' } | null>(null);

  // Due Date & Paid Amount & Stock Deduct Configuration
  const [amountPaidInput, setAmountPaidInput] = useState<number | ''>('');
  const [paymentDueDate, setPaymentDueDate] = useState<string>('');
  const [deductStockOnNonVat, setDeductStockOnNonVat] = useState<boolean>(true);
  const [billDateBs, setBillDateBs] = useState<string>(getTodayBsString());

  // ✏️ बिल सच्याउने (Edit) मोड — सामान सहित पूरै बिल फारममा लोड हुन्छ
  const [editingInvoiceId, setEditingInvoiceId] = useState<string | null>(null);
  const [isSavingBill, setIsSavingBill] = useState<boolean>(false);
  // ref: दोहोरो क्लिक / F2 + क्लिक एकैछिन आए पनि एक पटक मात्र सुरक्षित गर्न (state ले ढिलो अपडेट हुन्छ)
  const savingLockRef = React.useRef<boolean>(false);

  const resetBillForm = () => {
    handleClearDraftRow();
    setManualInvoiceNo('');
    setLineItems([]);
    setTransactionRef('');
    setBillPhotoUrl('');
    setAmountPaidInput('');
    setPaymentDueDate('');
    setCustomerName('');
    setCustomerPan('');
    setCustomerAddress('');
    setCustomerPhone('');
    setSelectedPartyId('');
    setSelectedEmployeeId('');
    setIsStaffPurchase(false);
    setPreviousDue(0);
    setDiscountPercent(0);
    setFreightCharge(0);
    setNotes('');
    setPaymentMode('CASH');
    setIsManualExemptMode(false);
    setManualExemptInput('');
    setBillDateBs(getTodayBsString());
  };

  useEffect(() => {
    if (!invoiceToEdit) return;
    const inv = invoiceToEdit;
    handleClearDraftRow();
    setEditingInvoiceId(inv.id);
    setBillType(inv.billType);
    setManualInvoiceNo(inv.invoiceNo);
    setBillDateBs(inv.dateBs);
    setPaymentMode(inv.paymentMode);
    setCustomerName(inv.customerName || '');
    setCustomerPan(inv.customerPan || '');
    setCustomerAddress(inv.customerAddress || '');
    setCustomerPhone(inv.customerPhone || '');
    setSelectedPartyId(inv.partyId || '');
    setIsStaffPurchase(!!(inv.isEmployeePurchase || inv.employeeId));
    setSelectedEmployeeId(inv.employeeId || '');
    setPreviousDue(inv.previousDue || 0);
    setLineItems(inv.items.map((l) => ({ ...l })));
    setDiscountPercent(inv.discountPercent || 0);
    setFreightCharge(inv.freightCharge || 0);
    setNotes(inv.notes || '');
    setBillPhotoUrl(inv.photoUrl || '');
    setAmountPaidInput(inv.amountPaid !== undefined ? inv.amountPaid : '');
    setPaymentDueDate(inv.paymentDueDate || '');
    setTransactionRef(inv.transactionRef || '');
    if (inv.bankName) setBankName(inv.bankName);
    if (inv.bankAccountNo) setBankAccountNo(inv.bankAccountNo);
    if (inv.billType === 'NON_VAT') setDeductStockOnNonVat(inv.stockDeducted !== false);
    setIsManualExemptMode(false);
    setManualExemptInput('');
    savingLockRef.current = false;
    setIsSavingBill(false);
    // एक पटक लोड भएपछि context को सङ्केत हटाउने (नत्र फेरि-फेरि लोड हुन्छ)
    clearInvoiceToEdit();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [invoiceToEdit]);

  const cancelEditMode = () => {
    setEditingInvoiceId(null);
    savingLockRef.current = false;
    setIsSavingBill(false);
    resetBillForm();
  };

  useEffect(() => {
    const handleDateSync = (e: any) => {
      setBillDateBs(e?.detail?.date || getTodayBsString());
    };
    window.addEventListener('ims-date-sync-changed', handleDateSync);
    return () => window.removeEventListener('ims-date-sync-changed', handleDateSync);
  }, []);

  // Customer inline Edit / Create Modal state
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState<boolean>(false);
  const [editCustName, setEditCustName] = useState<string>('');
  const [editCustAddress, setEditCustAddress] = useState<string>('');
  const [editCustPhone, setEditCustPhone] = useState<string>('');
  const [editCustPan, setEditCustPan] = useState<string>('');
  const [editCustOpeningDue, setEditCustOpeningDue] = useState<number>(0);

  const openCustomerEditModal = () => {
    if (selectedPartyId) {
      setActiveTab('settings');
      setTimeout(() => {
        window.dispatchEvent(
          new CustomEvent('ims-sub-nav', {
            detail: { target: 'settings', settingsTab: 'CUSTOMERS', partyId: selectedPartyId }
          })
        );
      }, 60);
      return;
    }
    setEditCustName(customerName);
    setEditCustAddress(customerAddress);
    setEditCustPhone(customerPhone);
    setEditCustPan(customerPan);
    setEditCustOpeningDue(previousDue);
    setIsCustomerModalOpen(true);
  };

  const handleSaveCustomerModal = (e: React.FormEvent) => {
    e.preventDefault();
    const partyToSave: Party = {
      id: selectedPartyId || `pty-${Date.now()}`,
      name: editCustName.trim() || 'ग्राहक',
      address: editCustAddress.trim(),
      phone: editCustPhone.trim(),
      panNo: editCustPan.trim(),
      partyType: 'CUSTOMER',
      openingBalance: editCustOpeningDue,
      currentBalance: editCustOpeningDue
    };
    saveParty(partyToSave);
    setSelectedPartyId(partyToSave.id);
    setCustomerName(partyToSave.name);
    setCustomerAddress(partyToSave.address);
    setCustomerPhone(partyToSave.phone);
    setCustomerPan(partyToSave.panNo);
    setPreviousDue(editCustOpeningDue);
    setIsCustomerModalOpen(false);
  };

  // Handler for data applied from AI Handwritten Bill Scanner
  const handleApplyExtractedBill = (data: {
    invoiceNo?: string;
    customerName: string;
    customerPan: string;
    customerAddress: string;
    customerPhone: string;
    billType: 'VAT' | 'NON_VAT';
    paymentDueDate: string;
    previousDue: number;
    amountPaid: number;
    discountPercent: number;
    freightCharge: number;
    notes: string;
    lineItems: InvoiceItem[];
    photoUrl: string;
  }) => {
    if (data.invoiceNo) setManualInvoiceNo(data.invoiceNo);
    if (data.customerName) setCustomerName(data.customerName);
    if (data.customerPan) setCustomerPan(data.customerPan);
    if (data.customerAddress) setCustomerAddress(data.customerAddress);
    if (data.customerPhone) setCustomerPhone(data.customerPhone);
    if (data.billType) setBillType(data.billType);
    if (data.paymentDueDate) setPaymentDueDate(data.paymentDueDate);
    if (data.previousDue) setPreviousDue(data.previousDue);
    if (data.amountPaid) setAmountPaidInput(data.amountPaid);
    if (data.discountPercent) setDiscountPercent(data.discountPercent);
    if (data.freightCharge) setFreightCharge(data.freightCharge);
    if (data.notes) setNotes(data.notes);
    if (data.lineItems.length > 0) setLineItems(data.lineItems);
    if (data.photoUrl) setBillPhotoUrl(data.photoUrl);
    setScanToast({
      message: isNe ? 'फोटो बिलको विवरण बिलिङ फर्ममा भरियो!' : 'Photo bill details loaded into form!',
      type: 'success'
    });
    setTimeout(() => setScanToast(null), 3500);
  };

  // Direct Excel Upload into Sales Bill or Sales Register
  const handleDirectSalesExcelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const buffer = event.target?.result as ArrayBuffer;
        const { headers, rows } = parseExcelFile(buffer);
        if (rows.length === 0) {
          setScanToast({
            message: isNe ? 'एक्सेल फाइलमा कुनै डाटा भेटिएन।' : 'No rows found in Excel file.',
            type: 'info'
          });
          setTimeout(() => setScanToast(null), 3500);
          return;
        }

        // Detect columns
        let nameIdx = -1;
        let qtyIdx = -1;
        let rateIdx = -1;
        let totalIdx = -1;
        let custIdx = -1;
        let billIdx = -1;
        let panIdx = -1;
        let addrIdx = -1;
        let dateIdx = -1;
        let unitIdx = -1;

        headers.forEach((h, idx) => {
          const lower = String(h || '').toLowerCase();
          if (nameIdx === -1 && (lower.includes('item') || lower.includes('सामान') || lower.includes('विवरण') || lower.includes('description') || lower.includes('particular') || (lower.includes('name') && !lower.includes('cust') && !lower.includes('buyer')))) {
            nameIdx = idx;
          }
          if (qtyIdx === -1 && (lower.includes('qty') || lower.includes('quantity') || lower.includes('परिमाण') || lower.includes('संख्या'))) {
            qtyIdx = idx;
          }
          if (rateIdx === -1 && (lower.includes('rate') || lower.includes('price') || lower.includes('दर') || lower.includes('मूल्य'))) {
            rateIdx = idx;
          }
          if (totalIdx === -1 && (lower.includes('total') || lower.includes('amount') || lower.includes('जम्मा') || lower.includes('रकम') || lower.includes('राशि'))) {
            totalIdx = idx;
          }
          if (custIdx === -1 && (lower.includes('cust') || lower.includes('buyer') || lower.includes('ग्राहक') || lower.includes('खरिदकर्ता') || lower.includes('party') || lower.includes('पार्टी') || lower.includes('नाम'))) {
            custIdx = idx;
          }
          if (billIdx === -1 && (lower.includes('bill') || lower.includes('inv') || lower.includes('बीजक') || lower.includes('बिल'))) {
            billIdx = idx;
          }
          if (panIdx === -1 && (lower.includes('pan') || lower.includes('प्यान') || lower.includes('vat no'))) {
            panIdx = idx;
          }
          if (addrIdx === -1 && (lower.includes('addr') || lower.includes('ठेगाना') || lower.includes('स्थान'))) {
            addrIdx = idx;
          }
          if (dateIdx === -1 && (lower.includes('date') || lower.includes('मिति'))) {
            dateIdx = idx;
          }
          if (unitIdx === -1 && (lower.includes('unit') || lower.includes('एकाइ'))) {
            unitIdx = idx;
          }
        });

        const extractedLines: InvoiceItem[] = [];
        const batchInvoices: Invoice[] = [];
        let firstCustName = '';
        let firstCustPan = '';
        let firstCustAddr = '';
        let firstBillNo = '';

        rows.forEach((row, idx) => {
          const firstCell = String(row[0] || '').toLowerCase();
          if (firstCell.includes('total') || firstCell.includes('जम्मा')) return;

          const itemName =
            nameIdx >= 0
              ? String(row[nameIdx] || '').trim()
              : custIdx >= 0
              ? String(row[custIdx] || '').trim()
              : String(row[1] || row[0] || '').trim();
          if (!itemName) return;

          if (!firstCustName && custIdx >= 0 && row[custIdx]) firstCustName = String(row[custIdx]).trim();
          if (!firstCustPan && panIdx >= 0 && row[panIdx]) firstCustPan = String(row[panIdx]).trim();
          if (!firstCustAddr && addrIdx >= 0 && row[addrIdx]) firstCustAddr = String(row[addrIdx]).trim();
          if (!firstBillNo && billIdx >= 0 && row[billIdx]) firstBillNo = String(row[billIdx]).trim();

          const qty = qtyIdx >= 0 ? Math.max(1, parseExcelNumericValue(row[qtyIdx]) || 1) : 1;
          const totalVal = totalIdx >= 0 ? parseExcelNumericValue(row[totalIdx]) : 0;
          const rateVal =
            rateIdx >= 0
              ? parseExcelNumericValue(row[rateIdx])
              : totalVal > 0
              ? Math.round((totalVal / qty) * 100) / 100
              : parseExcelNumericValue(row[2]) || 0;
          const lineTotal = totalVal > 0 ? totalVal : qty * rateVal;
          const unitStr = unitIdx >= 0 && row[unitIdx] ? String(row[unitIdx]).trim() : 'Pcs';

          if (lineTotal > 0 || rateVal > 0) {
            extractedLines.push({
              itemId: `xl-sale-${Date.now()}-${idx}`,
              code: `XL-${idx + 1}`,
              name: itemName,
              unit: unitStr,
              quantity: qty,
              rate: rateVal || lineTotal,
              amount: lineTotal || rateVal * qty,
              isVatExempt: false
            });
          }

          // If this is a multi-invoice register sheet (has Bill No & Customer & Total), prepare batch invoice record
          if (billIdx >= 0 && custIdx >= 0 && lineTotal > 0) {
            const vatAmt = billType === 'VAT' ? Math.round((lineTotal * 0.13 / 1.13) * 100) / 100 : 0;
            const taxAmt = Math.round((lineTotal - vatAmt) * 100) / 100;
            batchInvoices.push({
              id: `inv-xl-${Date.now()}-${idx}`,
              billType,
              invoiceNo: String(row[billIdx] || `XL-INV-${idx + 1}`).trim(),
              seriesNumber: invoices.length + idx + 1,
              fiscalYear: company.fiscalYear || '081/82',
              dateBs: dateIdx >= 0 && row[dateIdx] ? String(row[dateIdx]).trim() : getTodayBsString(),
              dateAd: getTodayAdString(),
              time: '12:00 PM',
              customerName: String(row[custIdx] || 'खुद्रा ग्राहक').trim(),
              customerPan: panIdx >= 0 ? String(row[panIdx] || '').trim() : '',
              customerAddress: addrIdx >= 0 ? String(row[addrIdx] || '').trim() : '',
              items: [
                {
                  itemId: `xl-item-${idx}`,
                  code: `XL-${idx + 1}`,
                  name: nameIdx >= 0 && row[nameIdx] ? String(row[nameIdx]).trim() : 'एक्सेल बिक्री सामान',
                  unit: unitStr,
                  quantity: qty,
                  rate: taxAmt / qty,
                  amount: taxAmt,
                  isVatExempt: false
                }
              ],
              subtotal: taxAmt,
              discountPercent: 0,
              discountAmount: 0,
              freightCharge: 0,
              taxableAmount: taxAmt,
              exemptAmount: 0,
              vatAmount: vatAmt,
              grandTotal: lineTotal,
              paymentMode: 'CASH',
              status: 'ACTIVE',
              createdRole: 'OWNER'
            });
          }
        });

        if (firstCustName) setCustomerName(firstCustName);
        if (firstCustPan) setCustomerPan(firstCustPan);
        if (firstCustAddr) setCustomerAddress(firstCustAddr);
        if (firstBillNo) setManualInvoiceNo(firstBillNo);

        if (extractedLines.length > 0) {
          setLineItems(extractedLines);
        }
        if (batchInvoices.length > 1) {
          importInvoicesList(batchInvoices);
        }

        setScanToast({
          message: isNe
            ? `एक्सेल फाइल (${file.name}) बाट ${extractedLines.length} विवरण सिधै बिलमा अपलोड भयो!`
            : `Loaded ${extractedLines.length} rows directly from Excel (${file.name})!`,
          type: 'success'
        });
        setTimeout(() => setScanToast(null), 4000);
      } catch (err) {
        console.error('Excel upload error:', err);
        setScanToast({
          message: isNe ? 'एक्सेल फाइल पढ्न समस्या भयो।' : 'Failed to parse Excel file.',
          type: 'info'
        });
        setTimeout(() => setScanToast(null), 3500);
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  const handleBarcodeItemScanned = (scannedItem: Item, quantity: number = 1) => {
    const existingIdx = lineItems.findIndex(
      (l) => l.itemId === scannedItem.id || l.code.toLowerCase() === scannedItem.code.toLowerCase()
    );
    if (existingIdx !== -1) {
      const updated = [...lineItems];
      const newQty = updated[existingIdx].quantity + quantity;
      updated[existingIdx] = {
        ...updated[existingIdx],
        quantity: newQty,
        rate: scannedItem.sellingPrice,
        amount: newQty * scannedItem.sellingPrice
      };
      setLineItems(updated);
    } else {
      const newLine: InvoiceItem = {
        itemId: scannedItem.id,
        code: scannedItem.code,
        name: isNe ? scannedItem.nameNe || scannedItem.nameEn : scannedItem.nameEn,
        unit: scannedItem.unit,
        quantity,
        rate: scannedItem.sellingPrice,
        amount: quantity * scannedItem.sellingPrice,
        isVatExempt: scannedItem.isVatExempt
      };
      setLineItems((prev) => [...prev, newLine]);
    }

    const itemName = isNe ? scannedItem.nameNe || scannedItem.nameEn : scannedItem.nameEn;
    setScanToast({
      message: `${itemName} (+${quantity} ${scannedItem.unit}) बिलमा थपियो`,
      type: 'success'
    });
    setTimeout(() => {
      setScanToast(null);
    }, 3000);
  };

  const handleBillPhotoCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await fileToDataUrl(file, 1400, 1400, 0.85);
      setBillPhotoUrl(dataUrl);
      setScanToast({
        message: isNe ? 'फोटो संलग्न भयो र बिल विवरण पढिँदैछ...' : 'Photo attached & scanning bill details...',
        type: 'info'
      });

      // Automatically call AI OCR in background so direct photo upload also populates bill fields if available
      try {
        const res = await authFetch('/api/scan-handwritten-bill', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: dataUrl,
            mimeType: dataUrl.startsWith('data:image/png') ? 'image/png' : 'image/jpeg'
          })
        });
        const json = await res.json();
        if (res.ok && json.success && json.data) {
          const d = json.data;
          if (d.invoiceNo && !manualInvoiceNo) setManualInvoiceNo(d.invoiceNo);
          if (d.customerName && !customerName) setCustomerName(d.customerName);
          if (d.customerPan && !customerPan) setCustomerPan(d.customerPan);
          if (d.customerAddress && !customerAddress) setCustomerAddress(d.customerAddress);
          if (d.customerPhone && !customerPhone) setCustomerPhone(d.customerPhone);
          if (Array.isArray(d.items) && d.items.length > 0 && lineItems.length === 0) {
            const mapped: InvoiceItem[] = d.items.map((it: any, idx: number) => ({
              itemId: `photo-sale-${Date.now()}-${idx}`,
              code: `PHOTO-${idx + 1}`,
              name: it.name || `सामान ${idx + 1}`,
              unit: it.unit || 'Pcs',
              quantity: Math.max(1, Number(it.quantity) || 1),
              rate: Number(it.rate) || 0,
              amount: Number(it.amount) || (Math.max(1, Number(it.quantity) || 1) * (Number(it.rate) || 0)),
              isVatExempt: false
            }));
            setLineItems(mapped);
          }
          setScanToast({
            message: isNe ? 'फोटोबाट बिल विवरण स्वतः भरियो!' : 'Bill details auto-filled from photo!',
            type: 'success'
          });
        }
      } catch {
        // Keep photo attached even if background OCR is unavailable
      }
      setTimeout(() => setScanToast(null), 3500);
    } catch (err) {
      console.error('Failed to capture photo', err);
    }
  };

  // Print modal trigger
  const [createdInvoice, setCreatedInvoice] = useState<any | null>(null);

  // Compute Next Bill Number preview
  const sameTypeInvoices = invoices.filter((i) => i.billType === billType);
  const nextSeq = sameTypeInvoices.length + 1;
  const prefix = billType === 'VAT' ? company.vatBillPrefix : company.nonVatBillPrefix;
  const nextBillNoPreview = `${prefix}-${company.fiscalYear}-${String(nextSeq).padStart(4, '0')}`;

  const currentItem = items.find((i) => i.id === selectedItemId);

  // Utility to convert Nepali digits to English digits for matching phone numbers and codes
  const normalizeDigits = (str: string) => {
    const map: { [key: string]: string } = {
      '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
      '५': '5', '६': '6', '७': '7', '८': '8', '९': '9'
    };
    return (str || '').replace(/[०-९]/g, (d) => map[d] || d);
  };

  // Live phone match against parties
  const phoneMatches = useMemo(() => {
    const q = normalizeDigits(customerPhone.trim());
    if (q.length < 5) return [];
    return parties.filter(isCustomerParty).filter((p) => {
      const pPhone = normalizeDigits(p.phone || '');
      return pPhone.length >= 5 && pPhone.includes(q);
    });
  }, [customerPhone, parties]);

  // Same-name (duplicate customer) check: alert cashier to verify by address or mobile
  const sameNameMatches = useMemo(() => {
    const nameQuery = customerName.trim().toLowerCase();
    if (nameQuery.length < 2) return [];
    const matches = parties.filter(isCustomerParty).filter(
      (p) => p.name.trim().toLowerCase() === nameQuery || p.name.trim().toLowerCase().includes(nameQuery)
    );
    return matches.length > 1 ? matches : [];
  }, [customerName, parties]);

  // Filtered parties for search dropdown (Name, Phone, Address, PAN)
  const filteredParties = useMemo(() => {
    const q = normalizeDigits(customerSearchQuery.trim().toLowerCase());
    const customerParties = parties.filter(isCustomerParty);
    if (!q) return customerParties;
    return customerParties.filter((p) => {
      const nameMatch = p.name.toLowerCase().includes(q);
      const phoneMatch = normalizeDigits(p.phone || '').includes(q);
      const addrMatch = (p.address || '').toLowerCase().includes(q);
      const panMatch = (p.panNo || '').toLowerCase().includes(q);
      return nameMatch || phoneMatch || addrMatch || panMatch;
    });
  }, [customerSearchQuery, parties]);

  // Handle selecting Party from dropdown
  const handleSelectParty = (partyId: string) => {
    setSelectedPartyId(partyId);
    if (!partyId) {
      setPreviousDue(0);
      return;
    }
    const p = parties.find((party) => party.id === partyId);
    if (p) {
      setCustomerName(p.name);
      setCustomerPan(p.panNo || '');
      setCustomerAddress(p.address || '');
      setCustomerPhone(p.phone || '');
      setPreviousDue(p.currentBalance !== undefined ? p.currentBalance : (p.openingBalance || 0));
    }
  };

  // Handle Staff Purchase Selection
  const handleSelectEmployee = (empId: string) => {
    setSelectedEmployeeId(empId);
    if (!empId) {
      setPreviousDue(0);
      return;
    }
    const emp = employees.find((e) => e.id === empId);
    if (emp) {
      setCustomerName(`${emp.name} (कर्मचारी)`);
      setCustomerPhone(emp.phone);
      setCustomerAddress('कार्यरत कर्मचारी (In-House Staff)');
      setPaymentMode('STAFF_SALARY_DEDUCT');

      // Check current employee dues (opening advance + previous purchases)
      const summary = getEmployeePayrollSummary(empId);
      setPreviousDue(summary.totalDeductions || 0);
    }
  };

  const handleToggleStaffPurchase = (enabled: boolean) => {
    setIsStaffPurchase(enabled);
    if (enabled) {
      setSelectedPartyId('');
      setPaymentMode('STAFF_SALARY_DEDUCT');
      if (employees.length > 0) {
        handleSelectEmployee(employees[0].id);
      }
    } else {
      setSelectedEmployeeId('');
      setCustomerName('');
      setCustomerPhone('');
      setCustomerAddress('');
      setPaymentMode('CASH');
      setPreviousDue(0);
    }
  };

  // Available size options for selected item (item's size, variant sizes in inventory, and common standards)
  const availableSizes = useMemo(() => {
    if (!currentItem) return [];
    const sizes = new Set<string>();
    if (currentItem.size && currentItem.size.trim()) sizes.add(currentItem.size.trim());
    const currentName = (isNe ? currentItem.nameNe || currentItem.nameEn : currentItem.nameEn).trim().toLowerCase();
    items.forEach((it) => {
      const itName = (isNe ? it.nameNe || it.nameEn : it.nameEn).trim().toLowerCase();
      if (itName === currentName && it.size && it.size.trim()) {
        sizes.add(it.size.trim());
      }
    });
    const standardPresets = ['Standard', 'Small', 'Medium', 'Large', 'XL', '16mm', '20mm', '25mm', '32mm', '1/2"', '3/4"', '1"', '1.5"', '2"', '3"', '२४ ब्लेड', '३६ ब्लेड', '४२ ब्लेड', '1 kg', '5 kg', '10 kg', '25 kg', '50 kg', '100ml', '250ml', '500ml', '1 Litre', '5 Litre'];
    standardPresets.forEach((s) => sizes.add(s));
    return Array.from(sizes);
  }, [currentItem, items, isNe]);

  const handleSelectItem = (item: Item) => {
    setSelectedItemId(item.id);
    setInputUnitMode('PRIMARY');
    setInputRate(item.sellingPrice);
    setInputQty(1);
    setInputSize(item.size || '');
    setIsCustomSize(false);
    setInputIsVatExempt(item.isVatExempt || false);
  };

  const handleToggleInputUnitMode = (mode: 'PRIMARY' | 'SECONDARY') => {
    setInputUnitMode(mode);
    if (!currentItem) return;
    if (mode === 'SECONDARY' && currentItem.secondaryUnit) {
      const ratio = currentItem.secondaryUnitRatio && currentItem.secondaryUnitRatio > 0 ? currentItem.secondaryUnitRatio : 1;
      const secRate =
        currentItem.secondarySellingPrice && currentItem.secondarySellingPrice > 0
          ? currentItem.secondarySellingPrice
          : Math.round((currentItem.sellingPrice / ratio) * 100) / 100;
      setInputRate(secRate);
    } else {
      setInputRate(currentItem.sellingPrice);
    }
  };

  const handleSelectByCode = (code: string) => {
    if (!code) {
      handleClearDraftRow();
      return;
    }
    const matched = items.find((i) => i.code.trim().toLowerCase() === code.trim().toLowerCase());
    if (matched) {
      handleSelectItem(matched);
    }
  };

  const handleSelectByName = (itemId: string) => {
    if (!itemId) {
      handleClearDraftRow();
      return;
    }
    const matched = items.find((i) => i.id === itemId);
    if (matched) {
      handleSelectItem(matched);
    }
  };

  const handleSelectSize = (sz: string) => {
    setInputSize(sz);
    if (currentItem && sz) {
      const currentName = (isNe ? currentItem.nameNe || currentItem.nameEn : currentItem.nameEn).trim().toLowerCase();
      const variantItem = items.find((it) => {
        const itName = (isNe ? it.nameNe || it.nameEn : it.nameEn).trim().toLowerCase();
        return itName === currentName && it.size?.trim().toLowerCase() === sz.trim().toLowerCase();
      });
      if (variantItem && variantItem.id !== currentItem.id) {
        setSelectedItemId(variantItem.id);
        setInputUnitMode('PRIMARY');
        setInputRate(variantItem.sellingPrice);
        setInputIsVatExempt(variantItem.isVatExempt || false);
      }
    }
  };

  const handleAddLineItem = () => {
    if (!currentItem || inputQty <= 0) return;

    const lineDiscount = Math.min(100, Math.max(0, inputDiscount || 0));
    const grossAmount = inputQty * inputRate;
    const finalAmount = Math.round((grossAmount * (1 - lineDiscount / 100)) * 100) / 100;

    const ratio = currentItem.secondaryUnitRatio && currentItem.secondaryUnitRatio > 0 ? currentItem.secondaryUnitRatio : 1;
    const activeUnitMode: 'PRIMARY' | 'SECONDARY' =
      inputUnitMode === 'SECONDARY' && currentItem.secondaryUnit ? 'SECONDARY' : 'PRIMARY';
    const activeUnitLabel =
      activeUnitMode === 'SECONDARY' && currentItem.secondaryUnit ? currentItem.secondaryUnit : currentItem.unit;
    const calcPrimaryEquiv =
      activeUnitMode === 'SECONDARY' ? Math.round((inputQty / ratio) * 10000) / 10000 : inputQty;

    const existingIdx = lineItems.findIndex(
      (l) => l.itemId === currentItem.id && (l.unitMode || 'PRIMARY') === activeUnitMode
    );
    if (existingIdx !== -1) {
      const updated = [...lineItems];
      const newQty = updated[existingIdx].quantity + inputQty;
      const newGross = newQty * inputRate;
      const disc = lineDiscount > 0 ? lineDiscount : (updated[existingIdx].discountPercent || 0);
      const newPrimaryEquiv =
        activeUnitMode === 'SECONDARY' ? Math.round((newQty / ratio) * 10000) / 10000 : newQty;
      updated[existingIdx] = {
        ...updated[existingIdx],
        quantity: newQty,
        unit: activeUnitLabel,
        unitMode: activeUnitMode,
        primaryQtyEquivalent: newPrimaryEquiv,
        rate: inputRate,
        size: inputSize.trim() || updated[existingIdx].size || currentItem.size || '',
        discountPercent: disc,
        amount: Math.round((newGross * (1 - disc / 100)) * 100) / 100,
        isVatExempt: inputIsVatExempt,
        hsCode: currentItem.hsCode || currentItem.hsnCode
      };
      setLineItems(updated);
    } else {
      const newLine: InvoiceItem = {
        itemId: currentItem.id,
        code: currentItem.code || `ITM-${lineItems.length + 1}`,
        name: isNe ? currentItem.nameNe || currentItem.nameEn : currentItem.nameEn,
        size: inputSize.trim() || currentItem.size || '',
        unit: activeUnitLabel,
        unitMode: activeUnitMode,
        primaryQtyEquivalent: calcPrimaryEquiv,
        hsCode: currentItem.hsCode || currentItem.hsnCode,
        quantity: inputQty,
        rate: inputRate,
        discountPercent: lineDiscount,
        amount: finalAmount,
        isVatExempt: inputIsVatExempt
      };
      setLineItems([...lineItems, newLine]);
    }

    setSelectedItemId('');
    setInputQty(1);
    setInputRate(0);
    setInputSize('');
    setIsCustomSize(false);
    setInputDiscount(0);
    setInputIsVatExempt(false);
    setInputUnitMode('PRIMARY');
    setItemSearch('');
  };

  const handleUpdateLineItem = (
    idx: number,
    field: 'name' | 'size' | 'quantity' | 'rate' | 'discountPercent' | 'isVatExempt' | 'unitMode',
    val: any
  ) => {
    const updated = [...lineItems];
    const target = { ...updated[idx] };
    const matchedItem = items.find((i) => i.id === target.itemId);
    const ratio =
      matchedItem && matchedItem.secondaryUnitRatio && matchedItem.secondaryUnitRatio > 0
        ? matchedItem.secondaryUnitRatio
        : 1;

    if (field === 'name') target.name = String(val);
    if (field === 'size') target.size = String(val);
    if (field === 'quantity') target.quantity = Math.max(0.01, Number(val) || 0);
    if (field === 'rate') target.rate = Math.max(0, Number(val) || 0);
    if (field === 'discountPercent') target.discountPercent = Math.min(100, Math.max(0, Number(val) || 0));
    if (field === 'isVatExempt') target.isVatExempt = Boolean(val);
    if (field === 'unitMode' && matchedItem) {
      const nextMode: 'PRIMARY' | 'SECONDARY' = val === 'SECONDARY' && matchedItem.secondaryUnit ? 'SECONDARY' : 'PRIMARY';
      target.unitMode = nextMode;
      if (nextMode === 'SECONDARY' && matchedItem.secondaryUnit) {
        target.unit = matchedItem.secondaryUnit;
        target.rate =
          matchedItem.secondarySellingPrice && matchedItem.secondarySellingPrice > 0
            ? matchedItem.secondarySellingPrice
            : Math.round((matchedItem.sellingPrice / ratio) * 100) / 100;
      } else {
        target.unit = matchedItem.unit;
        target.rate = matchedItem.sellingPrice;
      }
    }

    target.primaryQtyEquivalent =
      target.unitMode === 'SECONDARY'
        ? Math.round((target.quantity / ratio) * 10000) / 10000
        : target.quantity;

    const disc = target.discountPercent || 0;
    const gross = target.quantity * target.rate;
    target.amount = Math.round((gross * (1 - disc / 100)) * 100) / 100;

    updated[idx] = target;
    setLineItems(updated);
  };

  const handleClearDraftRow = () => {
    setSelectedItemId('');
    setInputQty(1);
    setInputRate(0);
    setInputSize('');
    setIsCustomSize(false);
    setInputDiscount(0);
    setInputIsVatExempt(false);
    setInputUnitMode('PRIMARY');
  };

  const handleAddLumpSumItem = () => {
    const amt = typeof lumpSumAmount === 'number' ? lumpSumAmount : parseFloat(lumpSumAmount as any) || 0;
    if (amt <= 0) {
      setScanToast({
        message: isNe ? 'कृपया उपयुक्त एकमुष्ठ बिक्री रकम राख्नुहोस्।' : 'Please enter a valid lump-sum amount.',
        type: 'info'
      });
      setTimeout(() => setScanToast(null), 3000);
      return;
    }

    const newLine: InvoiceItem = {
      itemId: `lumpsum-${Date.now()}`,
      code: 'LUMP-SUM',
      name: lumpSumName.trim() || (isNe ? 'एकमुष्ठ बिक्री रकम' : 'Lump-sum Sales Amount'),
      unit: lumpSumUnit.trim() || (isNe ? 'जम्मा' : 'Total'),
      hsCode: lumpSumHsCode.trim(),
      quantity: 1,
      rate: amt,
      amount: amt,
      isVatExempt: lumpSumIsVatExempt
    };

    setLineItems((prev) => [...prev, newLine]);
    setLumpSumAmount('');
  };

  const handleRemoveLineItem = (idx: number) => {
    setLineItems(lineItems.filter((_, i) => i !== idx));
  };

  // ✏️ बिलभित्र भइसकेको सामान फेरि entry row मा ल्याएर सामान/साइज/परिमाण/दर सबै सच्याउने
  const handleEditLineItem = (idx: number) => {
    const line = lineItems[idx];
    if (!line) return;
    if (line.itemId.startsWith('lumpsum-')) {
      setBillingEntryMode('LUMP_SUM');
      setLumpSumName(line.name);
      setLumpSumAmount(line.amount);
      setLumpSumUnit(line.unit);
      setLumpSumHsCode(line.hsCode || '');
      setLumpSumIsVatExempt(!!line.isVatExempt);
    } else {
      setBillingEntryMode('ITEMIZED');
      setSelectedItemId(line.itemId);
      setInputUnitMode(line.unitMode || 'PRIMARY');
      setInputQty(line.quantity);
      setInputRate(line.rate);
      setInputSize(line.size || '');
      setInputDiscount(line.discountPercent || 0);
      setInputIsVatExempt(!!line.isVatExempt);
    }
    setLineItems(lineItems.filter((_, i) => i !== idx));
  };

  // Live Totals calculation with optional manual VAT exempt amount
  const resolvedManualExempt = isManualExemptMode && manualExemptInput !== '' ? Number(manualExemptInput) : null;
  const totals = calculateInvoiceTotals(
    lineItems,
    discountPercent,
    freightCharge,
    billType === 'VAT',
    resolvedManualExempt
  );

  const netTotalDue = previousDue + totals.grandTotal;

  // Save invoice first to database, then optionally trigger print modal
  const handleSaveBill = (shouldOpenPrint: boolean = false) => {
    // Double-save guard: पहिलो Save पूरा नहुँदै फेरि थिचिए/F2 आए बेवास्ता गर्ने
    if (savingLockRef.current) return;
    let finalItems = [...lineItems];
    if (currentItem && inputQty > 0) {
      const lineDiscount = Math.min(100, Math.max(0, inputDiscount || 0));
      const grossAmount = inputQty * inputRate;
      const finalAmount = Math.round((grossAmount * (1 - lineDiscount / 100)) * 100) / 100;
      const ratio = currentItem.secondaryUnitRatio && currentItem.secondaryUnitRatio > 0 ? currentItem.secondaryUnitRatio : 1;
      const activeUnitMode: 'PRIMARY' | 'SECONDARY' =
        inputUnitMode === 'SECONDARY' && currentItem.secondaryUnit ? 'SECONDARY' : 'PRIMARY';
      const activeUnitLabel =
        activeUnitMode === 'SECONDARY' && currentItem.secondaryUnit ? currentItem.secondaryUnit : currentItem.unit;
      const calcPrimaryEquiv =
        activeUnitMode === 'SECONDARY' ? Math.round((inputQty / ratio) * 10000) / 10000 : inputQty;

      finalItems.push({
        itemId: currentItem.id,
        code: currentItem.code || `ITM-${finalItems.length + 1}`,
        name: isNe ? currentItem.nameNe || currentItem.nameEn : currentItem.nameEn,
        size: inputSize.trim() || currentItem.size || '',
        unit: activeUnitLabel,
        unitMode: activeUnitMode,
        primaryQtyEquivalent: calcPrimaryEquiv,
        hsCode: currentItem.hsCode || currentItem.hsnCode,
        quantity: inputQty,
        rate: inputRate,
        discountPercent: lineDiscount,
        amount: finalAmount,
        isVatExempt: inputIsVatExempt
      });
    }

    if (finalItems.length === 0) {
      setScanToast({
        message: isNe ? 'कृपया बिलमा सामान छान्नुहोस् वा थप्नुहोस्।' : 'Please select or add at least one line item.',
        type: 'info'
      });
      setTimeout(() => setScanToast(null), 3000);
      return;
    }

    if (isStaffPurchase && !selectedEmployeeId) {
      setScanToast({
        message: isNe ? 'कृपया सम्बन्धित कर्मचारी छान्नुहोस्।' : 'Please select the staff member.',
        type: 'info'
      });
      setTimeout(() => setScanToast(null), 3000);
      return;
    }

    const selectedEmp = employees.find((e) => e.id === selectedEmployeeId);

    savingLockRef.current = true;
    setIsSavingBill(true);
    let releaseLockInFinally = true;

    try {
      const actualPaid =
        amountPaidInput !== ''
          ? Number(amountPaidInput)
          : paymentMode === 'CREDIT'
          ? 0
          : totals.grandTotal;

      const billParams = {
        billType,
        customDateBs: billDateBs.trim() || undefined,
        manualInvoiceNo: manualInvoiceNo.trim() || undefined,
        customerName: customerName || (isNe ? 'खुद्रा ग्राहक' : 'Cash Customer'),
        customerPan,
        customerAddress,
        customerPhone,
        billedBy: currentAccount?.ownerName || (currentRole === 'OWNER' ? 'राजन गोपाली' : 'काउन्टर कर्मचारी'),
        partyId: selectedPartyId || undefined,
        isEmployeePurchase: isStaffPurchase,
        employeeId: isStaffPurchase ? selectedEmployeeId : undefined,
        employeeName: isStaffPurchase && selectedEmp ? selectedEmp.name : undefined,
        previousDue: previousDue,
        amountPaid: actualPaid,
        paymentDueDate: paymentDueDate || undefined,
        deductStock: billType === 'VAT' ? true : deductStockOnNonVat,
        items: finalItems,
        discountPercent,
        freightCharge,
        paymentMode,
        bankName: paymentMode === 'BANK_FONEPAY' ? bankName : undefined,
        bankAccountNo: paymentMode === 'BANK_FONEPAY' ? bankAccountNo : undefined,
        transactionRef: paymentMode === 'BANK_FONEPAY' ? transactionRef : undefined,
        photoUrl: billPhotoUrl || undefined,
        notes: isStaffPurchase
          ? `कर्मचारी सामान खरिद (हाजिरी/तलब कट्टी) - ${notes}`
          : notes,
        manualExemptAmount: resolvedManualExempt
      };

      // ✏️ EDIT MODE: उही बिल अपडेट हुन्छ (नयाँ बिल बन्दैन)
      if (editingInvoiceId) {
        releaseLockInFinally = false; // Owner Key पुष्टि/रद्द नभएसम्म लक राख्ने
        updateInvoice(editingInvoiceId, { ...billParams, customDateBs: billDateBs.trim() || undefined }, {
          onSuccess: (updated) => {
            if (shouldOpenPrint) setCreatedInvoice(updated);
            setScanToast({
              message: isNe
                ? `बिल नं. ${updated.invoiceNo} सच्याइयो र सुरक्षित भयो!`
                : `Invoice ${updated.invoiceNo} updated successfully!`,
              type: 'success'
            });
            setTimeout(() => setScanToast(null), 4000);
            setEditingInvoiceId(null);
            resetBillForm();
            savingLockRef.current = false;
            setIsSavingBill(false);
          },
          onError: (message) => {
            setScanToast({ message, type: 'error' as any });
            setTimeout(() => setScanToast(null), 4000);
            savingLockRef.current = false;
            setIsSavingBill(false);
          },
          onCancel: () => {
            savingLockRef.current = false;
            setIsSavingBill(false);
          }
        });
        return;
      }

      // 1. ALWAYS SAVE INVOICE TO DATABASE FIRST
      const inv = createInvoice(billParams);

      // 2. AFTER SAVING TO DB, OPEN PRINT MODAL IF REQUESTED
      if (shouldOpenPrint) {
        setCreatedInvoice(inv);
      }

      // 3. TRIGGER AUTOMATED SMS RECEIPT
      if (inv.customerPhone && /^[9][78]\d{8}$/.test(inv.customerPhone)) {
        const smsMessage = `KrishiYantra ERP: ${inv.invoiceNo} Bill Total: Rs.${inv.grandTotal.toFixed(2)}. Thank you for shopping with us!`;
        import('../utils/smsUtils').then(smsUtils => {
          smsUtils.sendSmsReceipt(inv.customerPhone!, smsMessage).catch(err => console.error('SMS trigger failed', err));
        });
      }

      setScanToast({
        message: isNe
          ? `बिल नं. ${inv.invoiceNo} सुरक्षित भयो! ${shouldOpenPrint ? 'प्रिन्ट वा PDF डाउनलोड खुल्दैछ...' : ''}`
          : `Invoice ${inv.invoiceNo} saved! ${shouldOpenPrint ? 'Opening print/PDF...' : ''}`,
        type: 'success'
      });
      setTimeout(() => setScanToast(null), 4000);

      // Reset form & draft row
      handleClearDraftRow();
      setManualInvoiceNo('');
      setLineItems([]);
      setTransactionRef('');
      setBillPhotoUrl('');
      setAmountPaidInput('');
      setPaymentDueDate('');
      if (!isStaffPurchase) {
        setCustomerName('');
        setCustomerPan('');
        setCustomerAddress('');
        setCustomerPhone('');
        setSelectedPartyId('');
        setPreviousDue(0);
      }
      setDiscountPercent(0);
      setFreightCharge(0);
      setNotes('');
    } catch (err: any) {
      console.error('Invoice creation error:', err);
      setScanToast({
        message: isNe ? `बिल सुरक्षित गर्न सकिएन: ${err?.message || 'अज्ञात समस्या'}` : `Failed to save invoice: ${err?.message || 'Error'}`,
        type: 'error' as any
      });
      setTimeout(() => setScanToast(null), 4000);
    } finally {
      if (releaseLockInFinally) {
        // थोरै ढिलो खोल्ने — लगातार दोहोरो क्लिक पनि रोकिन्छ
        setTimeout(() => {
          savingLockRef.current = false;
          setIsSavingBill(false);
        }, 600);
      }
    }
  };

  const handleSaveAndPrint = () => handleSaveBill(true);

  // ---- Keyboard shortcuts (Sales billing) ----
  // F2 or Ctrl/Cmd+S -> save bill, Esc -> close the customer pop-up.
  // The latest handler is kept in a ref so the listener never uses stale state.
  const shortcutRef = React.useRef<{ save: () => void; closeModal: () => void; modalOpen: boolean; active: boolean }>({
    save: () => {}, closeModal: () => {}, modalOpen: false, active: false
  });
  shortcutRef.current = {
    save: () => handleSaveBill(false),
    closeModal: () => setIsCustomerModalOpen(false),
    modalOpen: isCustomerModalOpen,
    active: billingSubTab === 'SALES'
  };
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const r = shortcutRef.current;
      if (e.key === 'Escape' && r.modalOpen) {
        e.preventDefault();
        r.closeModal();
        return;
      }
      if (!r.active || r.modalOpen) return;
      const isSave = e.key === 'F2' || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's');
      if (isSave) {
        e.preventDefault(); // stop the browser's "Save page" dialog
        r.save();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const filteredItems = items.filter((it) => {
    const q = itemSearch.toLowerCase();
    return (
      it.nameEn.toLowerCase().includes(q) ||
      it.nameNe.toLowerCase().includes(q) ||
      it.code.toLowerCase().includes(q)
    );
  });

  const billingSubTabItems: {
    id: 'SALES' | 'PURCHASE' | 'PAYMENT_IN' | 'PAYMENT_OUT' | 'SALES_RETURN' | 'PURCHASE_RETURN' | 'RECURRING';
    labelNe: string;
    labelEn: string;
  }[] = [
    { id: 'SALES', labelNe: '१. बिक्री (Sales / POS)', labelEn: '1. Sales (POS)' },
    { id: 'PURCHASE', labelNe: '२. खरिद (Purchase)', labelEn: '2. Purchase' },
    { id: 'PAYMENT_IN', labelNe: '३. भुक्तानी प्राप्त (Payment In)', labelEn: '3. Payment In' },
    { id: 'PAYMENT_OUT', labelNe: '४. भुक्तानी (Payment Out)', labelEn: '4. Payment Out' },
    { id: 'SALES_RETURN', labelNe: '५. बिक्री फिर्ता (Sales Return)', labelEn: '5. Sales Return' },
    { id: 'PURCHASE_RETURN', labelNe: '६. खरिद फिर्ता (Purchase Return)', labelEn: '6. Purchase Return' },
    { id: 'RECURRING', labelNe: '७. दोहोरिने बिल (Recurring)', labelEn: '7. Recurring' }
  ];

  return (
    <div className="space-y-5">
      {/* Unified Billing & Transactions 6-Tab Sub-Navigation Bar */}
      <div className="bg-white p-2.5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-1.5 overflow-x-auto">
        {billingSubTabItems.map((tab) => {
          const isCurrent = billingSubTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setBillingSubTab(tab.id);
                if (tab.id === 'PAYMENT_IN') setVoucherSubTab('COLLECTION');
                if (tab.id === 'PAYMENT_OUT') setVoucherSubTab('PAYMENT');
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                isCurrent
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'bg-slate-50 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 border border-slate-200/70'
              }`}
            >
              {isNe ? tab.labelNe : tab.labelEn}
            </button>
          );
        })}
      </div>

      {billingSubTab === 'RECURRING' ? (
        <RecurringInvoicesScreen />
      ) : billingSubTab !== 'SALES' ? (
        <BillingSubModules />
      ) : (
        <>
      {editingInvoiceId && (
        <div className="bg-amber-50 border-2 border-amber-400 rounded-xl p-3 flex flex-wrap items-center justify-between gap-2">
          <div className="text-xs text-amber-950">
            <span className="font-extrabold">✏️ {isNe ? 'बिल सच्याउने मोड' : 'Editing Bill'}: </span>
            <span className="font-mono font-bold">{manualInvoiceNo}</span>
            <span className="ml-2">
              {isNe
                ? 'सामान, परिमाण, दर, ग्राहक सबै सच्याउन सकिन्छ। Save गर्दा यही बिल अपडेट हुन्छ (नयाँ बिल बन्दैन)।'
                : 'Edit items, qty, rate, customer. Saving updates this same bill (no new bill is created).'}
            </span>
          </div>
          <button
            type="button"
            onClick={cancelEditMode}
            className="px-3 py-1.5 bg-white border border-amber-400 text-amber-900 hover:bg-amber-100 rounded-lg text-[11px] font-bold cursor-pointer"
          >
            {isNe ? '✖ सच्याइ रद्द गर्नुहोस्' : 'Cancel Edit'}
          </button>
        </div>
      )}
      {/* Top Bill Type Selector & Bill Number Indicator */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        
        {/* Bill Type Switcher & AI Handwritten Scan */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setBillType('VAT')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                billType === 'VAT'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Receipt className="w-4 h-4" />
              <span>{t.billTypeVat}</span>
            </button>

            <button
              onClick={() => setBillType('NON_VAT')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                billType === 'NON_VAT'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>{t.billTypeNonVat}</span>
            </button>
          </div>

          {/* AI Handwritten Scan Button */}
          <button
            type="button"
            onClick={() => setIsAiScanModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-emerald-800 to-teal-800 hover:from-emerald-900 hover:to-teal-900 text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
            <span>{isNe ? 'लिखित बिल AI स्क्यान' : 'Scan Handwritten Bill'}</span>
          </button>

          {/* Camera Barcode & QR Scanner Button */}
          <button
            type="button"
            onClick={() => setIsBarcodeScannerOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
          >
            <Scan className="w-3.5 h-3.5 text-blue-200" />
            <span>{isNe ? 'बारकोड / QR स्क्यान' : 'Scan Barcode / QR'}</span>
          </button>

          {/* Direct Excel Upload Button */}
          <label
            htmlFor="direct-sales-excel-input"
            className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
            <span>{isNe ? 'Excel बाट सिधै बिल अपलोड' : 'Direct Excel Bill Upload'}</span>
          </label>
          <input
            type="file"
            id="direct-sales-excel-input"
            accept=".xlsx,.xls,.csv"
            onChange={handleDirectSalesExcelUpload}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => setActiveTab('excel_wizard')}
            className="px-2.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-[11px] font-bold rounded-lg transition cursor-pointer"
            title={isNe ? 'एक्सेल कोलम म्यापिङ विजार्ड खोल्नुहोस्' : 'Open Excel Column Mapping Wizard'}
          >
            {isNe ? 'म्यापिङ विजार्ड' : 'Excel Wizard'}
          </button>

          {/* Non-VAT Stock Deduct Toggle */}
          {billType === 'NON_VAT' && (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-amber-50 rounded-lg border border-amber-200 text-xs">
              <input
                type="checkbox"
                id="deductNonVatStock"
                checked={deductStockOnNonVat}
                onChange={(e) => setDeductStockOnNonVat(e.target.checked)}
                className="rounded text-emerald-700 w-3.5 h-3.5 cursor-pointer"
              />
              <label htmlFor="deductNonVatStock" className="text-amber-950 font-medium cursor-pointer text-[11px]">
                {isNe ? 'नन-भ्याटमा स्टक घटाउने' : 'Deduct Non-VAT stock'}
              </label>
            </div>
          )}
        </div>

        {/* Editable Manual / Auto Bill Number & Date Info */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex flex-col">
            <span className="text-[10px] text-emerald-800 uppercase font-bold block mb-0.5">
              {isNe ? 'बीजक / बिल नं. (Auto वा Manual Entry):' : 'Invoice / Bill No (Auto or Manual):'}
            </span>
            <div className="flex items-center gap-1.5">
              <input
                type="text"
                value={manualInvoiceNo}
                onChange={(e) => setManualInvoiceNo(e.target.value)}
                placeholder={nextBillNoPreview}
                title={isNe ? 'यहाँ आफैँ बिल नं टाइप गर्न सकिन्छ वा खाली छोड्दा अटो नं आउँछ' : 'Type manual bill number or leave blank for auto'}
                className="w-40 sm:w-44 px-2.5 py-1.5 text-xs sm:text-sm font-mono font-bold text-slate-900 bg-emerald-50/60 border border-emerald-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white"
              />
              {manualInvoiceNo && (
                <button
                  type="button"
                  onClick={() => setManualInvoiceNo('')}
                  className="px-2 py-1 text-[10px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md cursor-pointer"
                  title={isNe ? 'अटो नम्बरमा फर्काउनुहोस्' : 'Reset to Auto'}
                >
                  {isNe ? 'अटो' : 'Auto'}
                </button>
              )}
            </div>
          </div>

          <div className="h-8 w-px bg-slate-200 hidden sm:block" />

          {/* Biller / Cashier Info */}
          <div className="flex items-center gap-2 bg-emerald-50/80 border border-emerald-200 px-3 py-1.5 rounded-lg shadow-2xs">
            <div className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-[11px] shrink-0">
              {(currentAccount?.ownerName || 'R').charAt(0).toUpperCase()}
            </div>
            <div className="text-left leading-tight">
              <span className="text-[10px] text-emerald-800 font-medium block">
                {isNe ? 'बिलिङ गर्ने' : 'Billed By'}:
              </span>
              <span className="text-xs font-bold text-slate-900 block truncate max-w-[130px]">
                {currentAccount?.ownerName || (isNe ? 'राजन गोपाली' : 'Rajan Gopali')}
              </span>
            </div>
          </div>

          <div className="h-8 w-px bg-slate-200 hidden sm:block" />

          {/* Manual Bill Date Selector & Editor */}
          <div className="text-right">
            <span className="text-[10px] text-slate-500 uppercase font-bold flex items-center justify-end gap-1">
              <Calendar className="w-3 h-3 text-emerald-700" />
              <span>{isNe ? 'बिल मिति (B.S. / A.D.)' : 'Bill Date (B.S. / A.D.)'}</span>
            </span>
            <div className="mt-0.5">
              <DualDateInput valueBs={billDateBs} onChange={(bs) => setBillDateBs(bs)} isNe={isNe} />
            </div>
          </div>
        </div>

      </div>

      <div className="space-y-5 w-full">
        
        {/* Top: Customer Details & Full Width Sales Room Table */}
        <div className="w-full space-y-4">
          
          {/* Direct Photo Capture for Sales Bill / Slip Placed at Top */}
          <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Camera className="w-4 h-4 text-emerald-700" />
                {isNe ? 'फोटो खिचेर बिल / चलान संलग्न गर्नुहोस्' : 'Snap & Attach Photo (Slip / Goods)'}
              </span>
              {billPhotoUrl && (
                <button
                  type="button"
                  onClick={() => setBillPhotoUrl('')}
                  className="text-[11px] text-rose-600 font-bold hover:underline cursor-pointer"
                >
                  {isNe ? 'हटाउनुहोस् (Remove)' : 'Remove'}
                </button>
              )}
            </div>
            <div className="flex items-center gap-3">
              {billPhotoUrl ? (
                <img
                  src={billPhotoUrl}
                  alt="Bill Attachment"
                  className="w-14 h-14 object-cover rounded-lg border-2 border-emerald-400 shadow-xs"
                />
              ) : (
                <div className="w-14 h-14 rounded-lg border-2 border-dashed border-emerald-300 flex flex-col items-center justify-center text-emerald-600 bg-white shrink-0">
                  <Camera className="w-5 h-5 text-emerald-500" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <label
                  htmlFor="top-bill-photo-input"
                  className="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-emerald-300 hover:border-emerald-600 hover:bg-emerald-50 text-emerald-900 rounded-lg text-xs font-bold cursor-pointer shadow-2xs transition"
                >
                  <Camera className="w-4 h-4 text-emerald-700" />
                  <span>{billPhotoUrl ? (isNe ? 'अर्को फोटो लिनुहोस्' : 'Retake Photo') : (isNe ? 'क्यामेराबाट फोटो खिच्नुहोस्' : 'Snap Photo')}</span>
                </label>
                <input
                  type="file"
                  id="top-bill-photo-input"
                  accept="image/*"
                  capture="environment"
                  onChange={handleBillPhotoCapture}
                  className="hidden"
                />
                <p className="text-[10px] text-slate-500 truncate mt-0.5">
                  {isNe ? 'डिलिभरी चलान, सामानको फोटो वा हस्ताक्षर' : 'Attach delivery slip, goods photo or signature'}
                </p>
              </div>
            </div>
          </div>

          {/* Customer & Staff Details Box */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-slate-100 gap-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                <User className="w-4 h-4 text-emerald-700" />
                <span>{t.customerDetails}</span>
              </div>

              {/* Staff Purchase Toggle Button */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleStaffPurchase(!isStaffPurchase)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                    isStaffPurchase
                      ? 'bg-purple-100 border-purple-300 text-purple-900'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Briefcase className="w-3.5 h-3.5 text-purple-700" />
                  <span>{isNe ? 'कर्मचारी खरिद (तलब कट्टी)' : 'Staff Purchase'}</span>
                </button>

                {/* Quick Select from Existing Parties */}
                {!isStaffPurchase && parties.length > 0 && (
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      placeholder={isNe ? 'फोन वा नामबाट खोज्नुहोस्...' : 'Search by phone/name...'}
                      value={customerSearchQuery}
                      onChange={(e) => setCustomerSearchQuery(e.target.value)}
                      className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1 text-slate-800 w-36 sm:w-44 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                    <select
                      value={selectedPartyId}
                      onChange={(e) => handleSelectParty(e.target.value)}
                      className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1 text-slate-700 font-medium max-w-[200px] truncate"
                    >
                      <option value="">{isNe ? '-- सुरक्षित ग्राहक छान्नुहोस् --' : '-- Select Party --'}</option>
                      {filteredParties.map((p) => {
                        const bal = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
                        return (
                          <option key={p.id} value={p.id}>
                            {p.name} — 📍 {p.address || 'ठेगाना नभएको'} (📞 {p.phone || 'फोन छैन'}) {bal > 0 ? `[बाँकी: रु. ${bal}]` : ''}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                )}
              </div>
            </div>

            {/* If Staff Purchase: Show Employee Dropdown */}
            {isStaffPurchase ? (
              <div className="p-3 bg-purple-50 rounded-lg border border-purple-200 space-y-2 text-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <label className="font-semibold text-purple-950 flex items-center gap-1">
                    <Briefcase className="w-4 h-4 text-purple-700" />
                    <span>{isNe ? 'कर्मचारी छान्नुहोस् (खरिद रकम हाजिरी/तलबबाट स्वतः काटिनेछ):' : 'Select Employee (Amount will deduct from salary):'}</span>
                  </label>
                  
                  <select
                    value={selectedEmployeeId}
                    onChange={(e) => handleSelectEmployee(e.target.value)}
                    className="px-3 py-1.5 bg-white border border-purple-300 rounded font-semibold text-slate-900 focus:outline-none"
                  >
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.name} (तलब: रु. {emp.salaryMonthly})
                      </option>
                    ))}
                  </select>
                </div>

                {selectedEmployeeId && (
                  <div className="flex items-center justify-between text-[11px] text-purple-900 pt-1 border-t border-purple-200/80 font-mono">
                    <span>
                      {isNe ? 'यो खरिद रकम महिनाको अन्त्यमा तलब सिटबाट कट्टी हुनेछ।' : 'This invoice total will be deducted from monthly payroll.'}
                    </span>
                    {previousDue > 0 && (
                      <span className="font-bold text-amber-900">
                        पुरानो लिन बाँकी/पेस्की: रु. {previousDue}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ) : (
              /* Regular Customer Fields */
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {t.customerName}
                    </label>
                    <input
                      type="text"
                      placeholder={t.cashCustomer}
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {t.customerPan} {billType === 'VAT' && <span className="text-emerald-700">(९ अंक)</span>}
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 601234567"
                      maxLength={9}
                      value={customerPan}
                      onChange={(e) => handleCustomerPanChange(e.target.value)}
                      className={`w-full px-3 py-2 border ${customerPanError ? 'border-rose-500' : 'border-slate-200'} rounded-lg font-mono focus:outline-none focus:ring-1 ${customerPanError ? 'focus:ring-rose-500' : 'focus:ring-emerald-500'}`}
                    />
                    {customerPanError && <p className="text-[10px] text-rose-600 font-bold mt-1">अमान्य प्यान नम्बर (९ अंक हुनुपर्छ)</p>}
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {t.customerAddress}
                    </label>
                    <input
                      type="text"
                      placeholder={isNe ? 'ठेगाना / गाउँपालिका' : 'Address'}
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      {t.customerPhone} (मोबाइल नं.)
                    </label>
                    <input
                      type="text"
                      placeholder="९८xxxxxxxx"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                {/* Mobile Phone Match Auto-Detection Alert */}
                {phoneMatches.length > 0 && selectedPartyId !== phoneMatches[0].id && (
                  <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded-lg text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 text-emerald-950 font-medium">
                      <Phone className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                      <span>
                        {isNe ? 'यो मोबाइल नं. भएको ग्राहक खातामा भेटियो:' : 'Matched customer by mobile:'}{' '}
                        <strong>{phoneMatches[0].name}</strong> (📍 {phoneMatches[0].address || 'ठेगाना नभएको'}){' '}
                        [बाँकी: रु. {phoneMatches[0].currentBalance ?? phoneMatches[0].openingBalance}]
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleSelectParty(phoneMatches[0].id)}
                      className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-[11px] font-bold cursor-pointer shrink-0"
                    >
                      {isNe ? 'यो ग्राहक लोड गर्नुहोस्' : 'Auto-Fill Customer'}
                    </button>
                  </div>
                )}

                {/* Same-Name Disambiguation Alert (उस्तै नाम भएको ग्राहक पहिचान) */}
                {sameNameMatches.length > 1 && (
                  <div className="p-2.5 bg-amber-50 border border-amber-300 rounded-xl text-xs space-y-2">
                    <div className="flex items-center gap-1.5 font-bold text-amber-900">
                      <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                      <span>
                        {isNe
                          ? `⚠️ '${customerName}' नाम गरेका ${sameNameMatches.length} जना ग्राहकहरू छन्! कृपया ठेगाना वा फोन नम्बरबाट सही ग्राहक छान्नुहोस्:`
                          : `Multiple customers share the name '${customerName}'. Disambiguate by address or phone:`}
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {sameNameMatches.map((m) => {
                        const isThisSelected = selectedPartyId === m.id;
                        const bal = m.currentBalance !== undefined ? m.currentBalance : m.openingBalance;
                        return (
                          <div
                            key={m.id}
                            onClick={() => handleSelectParty(m.id)}
                            className={`p-2 rounded-lg border text-left cursor-pointer transition flex flex-col justify-between ${
                              isThisSelected
                                ? 'bg-emerald-100 border-emerald-600 shadow-2xs'
                                : 'bg-white border-amber-200 hover:bg-amber-100/60'
                            }`}
                          >
                            <div className="font-bold text-slate-900 flex items-center justify-between">
                              <span>{m.name}</span>
                              {isThisSelected && (
                                <span className="text-[10px] bg-emerald-700 text-white px-1.5 py-0.2 rounded">
                                  छानिएको
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-600 flex items-center gap-1 mt-0.5">
                              <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                              <span>{m.address || 'ठेगाना नखुलेको'}</span>
                            </div>
                            <div className="text-[11px] text-slate-600 flex items-center gap-1">
                              <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                              <span>{m.phone || 'फोन छैन'}</span>
                            </div>
                            <div className="text-[11px] font-mono font-bold text-rose-700 mt-1">
                              बाँकी: रु. {bal}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Previous Balance / Old Dues Indicator (पुरानो लिन बाँकी) */}
            {previousDue > 0 && (
              <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200 flex items-center justify-between text-xs">
                <span className="font-semibold text-amber-900 flex items-center gap-1.5">
                  <Wallet className="w-3.5 h-3.5 text-amber-700" />
                  <span>{isNe ? 'ग्राहकको पुरानो लिन बाँकी खाता (Old Due):' : 'Previous Outstanding Balance:'}</span>
                </span>
                <span className="font-mono font-bold text-amber-950 text-sm">
                  {formatCurrency(previousDue, isNe)}
                </span>
              </div>
            )}

            {/* Edit / Register Customer Button (Existing Customer Edits Routed Strictly to Master Settings) */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              {selectedPartyId ? (
                <button
                  type="button"
                  onClick={openCustomerEditModal}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-900 bg-indigo-50 hover:bg-indigo-100 border border-indigo-300 rounded-lg cursor-pointer transition shadow-2xs"
                >
                  <Edit2 className="w-3.5 h-3.5 text-indigo-700" />
                  <span>{isNe ? '⚙️ मास्टर सेटिङबाट ग्राहक सच्याउने / रिनेम' : '⚙️ Edit Customer in Master Settings'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={openCustomerEditModal}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg cursor-pointer transition shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{isNe ? '+ नयाँ ग्राहक दर्ता तथा पुरानो बाँकी' : '+ New Customer & Opening Due'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Billing Mode & Quick Barcode Scanner */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex items-center gap-1.5 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setBillingEntryMode('ITEMIZED')}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition cursor-pointer ${
                  billingEntryMode === 'ITEMIZED'
                    ? 'bg-emerald-700 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                📦 {isNe ? 'कोठा तालिका बिल (Itemized Room Table)' : 'Itemized Table Bill'}
              </button>
              <button
                type="button"
                onClick={() => setBillingEntryMode('LUMP_SUM')}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition cursor-pointer ${
                  billingEntryMode === 'LUMP_SUM'
                    ? 'bg-emerald-700 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                💰 {isNe ? 'एकमुष्ठ रकम बिल' : 'Lump-sum Bill'}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsBarcodeScannerOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold transition cursor-pointer shadow-2xs"
              >
                <Scan className="w-3.5 h-3.5 text-emerald-700" />
                <span>{isNe ? 'बारकोड / QR स्क्यान' : 'Barcode / QR Scan'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsAiScanModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-300 rounded-lg text-xs font-bold transition cursor-pointer shadow-2xs"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-700" />
                <span>{isNe ? 'फोटो बिल स्क्यान' : 'Photo Bill Scan'}</span>
              </button>
            </div>
          </div>

          {billingEntryMode === 'LUMP_SUM' ? (
            /* Lump-sum Quick Bill Entry Panel */
            <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="text-xs font-bold text-slate-800 flex items-center justify-between pb-2 border-b border-slate-100">
                <span>{isNe ? 'सामानको नाम नराखी सिधै एकमुष्ठ रकम राख्नुहोस्:' : 'Direct Lump-Sum Billing (No Item Name Required):'}</span>
                <span className="text-[11px] text-emerald-800 font-medium">
                  {isNe ? '(भ्याट तथा कुल हिसाब स्वतः हिसाब हुन्छ)' : '(Auto VAT & Totals calculation)'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    विवरण / नाम (Description)
                  </label>
                  <input
                    type="text"
                    value={lumpSumName}
                    onChange={(e) => setLumpSumName(e.target.value)}
                    placeholder="उदा: एकमुष्ठ बिक्री रकम"
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    एकमुष्ठ बिक्री रकम (रु.)*
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={lumpSumAmount}
                    onChange={(e) => setLumpSumAmount(e.target.value === '' ? '' : parseFloat(e.target.value) || 0)}
                    placeholder="उदा: ५०००"
                    className="w-full px-2.5 py-1.5 border border-emerald-400 rounded-lg bg-white text-xs font-mono font-bold text-emerald-950"
                  />
                </div>

                <div className="flex items-center gap-2 pt-2 sm:col-span-2">
                  <input
                    type="checkbox"
                    id="lumpSumVatExempt"
                    checked={lumpSumIsVatExempt}
                    onChange={(e) => setLumpSumIsVatExempt(e.target.checked)}
                    className="rounded text-emerald-700 w-4 h-4 cursor-pointer"
                  />
                  <label htmlFor="lumpSumVatExempt" className="text-xs font-medium text-slate-800 cursor-pointer">
                    कर छुट हुने रकम (VAT Exempt / Non-Taxable)
                  </label>
                </div>
              </div>

              <button
                type="button"
                onClick={handleAddLumpSumItem}
                className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg text-xs transition shadow-2xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isNe ? 'एकमुष्ठ रकम बिलमा थप्नुहोस् (Add Lump-Sum Amount)' : 'Add Lump-Sum Amount'}</span>
              </button>
            </div>
          ) : (
            /* Structured Room-Wala Grid Table matching user screenshot (image_5b4aade8.png) */
            <div className="bg-white rounded-xl border border-slate-300 shadow-2xs overflow-hidden">
              <div className="px-4 py-2 bg-slate-50 border-b border-slate-300 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <span>📋</span>
                    <span>{isNe ? 'बिक्री कोठा तालिका (Sales Room Table)' : 'Sales Items Room Table'}</span>
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">
                    ({isNe ? toNepaliDigits(lineItems.length) : lineItems.length} {isNe ? 'सामान' : 'Items'})
                  </span>
                </div>
                <div className="text-[11px] text-emerald-800 font-medium hidden sm:block">
                  {isNe ? 'सामान छान्दा भ्याट वा कर छुट (Non-VAT) छनौट गर्न सकिन्छ' : 'Toggle VAT / Non-VAT per line item'}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse">
                  {/* Table Headers with distinct vertical dividers (room borders) */}
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                    <tr>
                      <th className="py-2.5 px-2 text-center w-12 border-r border-slate-300">
                        {isNe ? 'क्र.सं.' : 'S.N.'}
                      </th>
                      <th className="py-2.5 px-3 border-r border-slate-300 min-w-[300px]">
                        {isNe ? 'सामान कोड र नाम (Code & Item Name)' : 'Item Code & Name'}
                      </th>
                      <th className="py-2 px-2 text-center w-56 border-r border-slate-300">
                        {isNe ? 'साइज (Size)' : 'Size'}
                      </th>
                      <th className="py-2.5 px-2 text-center w-16 border-r border-slate-300">
                        {isNe ? 'परिमाण' : 'Qty'}
                      </th>
                      <th className="py-2.5 px-2 text-right w-24 border-r border-slate-300">
                        {isNe ? 'दर (रु.)' : 'Rate (Rs.)'}
                      </th>
                      <th className="py-2.5 px-2 text-center w-16 border-r border-slate-300">
                        {isNe ? 'छुट (%)' : 'Disc (%)'}
                      </th>
                      <th className="py-2.5 px-2 text-right w-24 border-r border-slate-300">
                        {isNe ? 'छुट रकम (रु.)' : 'Disc Amt (Rs.)'}
                      </th>
                      <th className="py-2.5 px-3 text-right w-28 border-r border-slate-300">
                        {isNe ? 'जम्मा (रु.)' : 'Total (Rs.)'}
                      </th>
                      <th className="py-2.5 px-2 text-center w-28">
                        {isNe ? 'कार्य' : 'Action'}
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {/* Existing Line Items in Room Format */}
                    {lineItems.map((line, idx) => {
                      return (
                        <tr key={idx} className="border-b border-slate-300 hover:bg-slate-50/70 transition-colors">
                          {/* S.N. Room */}
                          <td className="py-1 px-2 text-center font-mono font-medium text-slate-700 bg-slate-50/30 border-r border-slate-300">
                            {isNe ? toNepaliDigits(idx + 1) : idx + 1}
                          </td>

                          {/* Particulars Room with Item Code, Name, HS Code, Size, Qty, Rate, VAT toggle */}
                          <td className="py-1 px-3 border-r border-slate-300">
                            <div className="font-semibold text-slate-900 leading-tight flex items-center flex-wrap gap-1">
                              {line.code && (
                                <span className="font-mono text-[10px] bg-slate-100 text-slate-700 px-1 py-0.2 rounded border border-slate-200">
                                  {line.code}
                                </span>
                              )}
                              <input
                                  type="text"
                                  value={line.name}
                                  onChange={(e) => handleUpdateLineItem(idx, 'name', e.target.value)}
                                  className="min-w-[7rem] bg-transparent border-b border-dashed border-slate-300 focus:border-emerald-500 focus:outline-none font-semibold text-slate-900"
                                  title={isNe ? 'नाम सच्याउन सकिन्छ' : 'Edit item name'}
                                />
                              {line.hsCode && (
                                <span className="font-mono text-[10px] text-slate-600 bg-slate-50 px-1 py-0.2 rounded border border-slate-200">
                                  HS: {line.hsCode}
                                </span>
                              )}
                              <button
                                type="button"
                                onClick={() => handleUpdateLineItem(idx, 'isVatExempt', !line.isVatExempt)}
                                className={`text-[10px] px-1.5 py-0.2 rounded font-bold transition cursor-pointer border shadow-2xs whitespace-nowrap ml-1 ${
                                  line.isVatExempt
                                    ? 'bg-amber-100 text-amber-900 border-amber-300 hover:bg-amber-200'
                                    : 'bg-emerald-100 text-emerald-900 border-emerald-300 hover:bg-emerald-200'
                                }`}
                                title={isNe ? 'भ्याट वा कर छुट परिवर्तन गर्न क्लिक गर्नुहोस्' : 'Click to toggle VAT / VAT Exempt'}
                              >
                                {line.isVatExempt ? (isNe ? 'कर छुट (Non-VAT)' : 'Exempt') : (isNe ? '१३% भ्याट' : '13% VAT')}
                              </button>
                            </div>
                            <div className="text-[11px] text-slate-600 flex items-center flex-wrap gap-2 mt-0.5">
                              {line.size && <span>साइज: <strong className="font-mono text-slate-800">{line.size}</strong></span>}
                              <span>परिमाण: <strong className="font-mono text-slate-900">{line.quantity} {line.unit}</strong></span>
                              {line.unitMode === 'SECONDARY' && line.primaryQtyEquivalent !== undefined && (
                                <span className="text-[10px] bg-blue-50 text-blue-800 px-1.5 py-0.2 rounded border border-blue-200 font-mono">
                                  (स्टक कट्टी: {line.primaryQtyEquivalent} मुख्य एकाइ)
                                </span>
                              )}
                              <span>दर: <strong className="font-mono text-slate-900">रु. {line.rate}</strong></span>
                            </div>
                          </td>

                          {/* Size Room */}
                          <td className="py-1 px-2 text-center border-r border-slate-300 w-56">
                            <input
                              type="text"
                              value={line.size || ''}
                              onChange={(e) => handleUpdateLineItem(idx, 'size', e.target.value)}
                              placeholder="-"
                              className="w-full text-center bg-transparent border-0 focus:ring-1 focus:ring-emerald-500 rounded py-0.5 text-xs text-slate-700 font-medium"
                            />
                          </td>

                          {/* Quantity Room + Unit Switcher */}
                          <td className="py-1 px-2 text-center border-r border-slate-300">
                            <div className="flex flex-col items-center gap-1">
                              <NumField value={line.quantity} onCommit={(n) => handleUpdateLineItem(idx, 'quantity', n)} className="w-14 text-center font-mono font-bold bg-transparent border border-slate-200 rounded py-0.5 text-xs focus:ring-1 focus:ring-emerald-500" />
                              {(() => {
                                const matchedIt = items.find((i) => i.id === line.itemId);
                                if (matchedIt && matchedIt.secondaryUnit) {
                                  return (
                                    <select
                                      value={line.unitMode || 'PRIMARY'}
                                      onChange={(e) => handleUpdateLineItem(idx, 'unitMode', e.target.value)}
                                      className="text-[10px] font-bold bg-emerald-50 text-emerald-900 border border-emerald-300 rounded px-1 py-0.2 cursor-pointer"
                                      title="मुख्य वा द्वितीय एकाइ छान्नुहोस्"
                                    >
                                      <option value="PRIMARY">{matchedIt.unit} (मुख्य)</option>
                                      <option value="SECONDARY">{matchedIt.secondaryUnit} (द्वितीय)</option>
                                    </select>
                                  );
                                }
                                return <span className="text-[10px] text-slate-500 font-mono">{line.unit}</span>;
                              })()}
                            </div>
                          </td>

                          {/* Rate Room with Rs. */}
                          <td className="py-1 px-2 text-right border-r border-slate-300">
                            <div className="flex items-center justify-end gap-1">
                              <span className="text-slate-400 font-mono text-[10px]">Rs.</span>
                              <NumField value={line.rate} onCommit={(n) => handleUpdateLineItem(idx, 'rate', n)} className="w-16 text-right font-mono font-medium bg-transparent border border-slate-200 rounded py-0.5 px-1 text-xs focus:ring-1 focus:ring-emerald-500" />
                            </div>
                          </td>

                          {/* Discount % Room */}
                          <td className="py-1.5 px-2 text-center border-r border-slate-300">
                            <div className="flex items-center justify-center gap-0.5">
                              <NumField value={line.discountPercent || 0} onCommit={(n) => handleUpdateLineItem(idx, 'discountPercent', n)} placeholder="0" blankWhenZero className="w-10 text-center font-mono bg-transparent border border-slate-200 rounded py-0.5 text-xs focus:ring-1 focus:ring-emerald-500" />
                              <span className="text-slate-400 text-[10px]">%</span>
                            </div>
                          </td>

                          {/* Discount Amount Room (column ma chut% paxe discount amount dekhaune, vat ko column hataune) */}
                          <td className="py-1.5 px-2 text-right font-mono tabular-nums text-rose-700 font-semibold border-r border-slate-300">
                            <span className="text-slate-400 text-[10px] font-normal mr-0.5">Rs.</span>
                            {(((line.rate * line.quantity) * (line.discountPercent || 0)) / 100).toFixed(2)}
                          </td>

                          {/* Total Amount Room with Rs. */}
                          <td className="py-1.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900 border-r border-slate-300">
                            <span className="text-slate-400 text-[10px] font-normal mr-1">Rs.</span>
                            {line.amount.toFixed(2)}
                          </td>

                          {/* Action Room (Edit + Red Trash Icon) */}
                          <td className="py-1.5 px-2 text-center whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => handleEditLineItem(idx)}
                              className="text-blue-600 hover:text-blue-800 hover:bg-blue-50 p-1 rounded transition cursor-pointer mr-0.5"
                              title={isNe ? 'सामान सच्याउनुहोस् (फेरि माथि entry मा आउँछ)' : 'Edit this item (loads back into the entry row)'}
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveLineItem(idx)}
                              className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1 rounded transition cursor-pointer"
                              title={isNe ? 'यो सामान हटाउनुहोस्' : 'Remove item'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}

                    {/* Active Entry Row with Code -> Name sync, Size selector, and Add button */}
                    <tr className="border-b border-slate-300 bg-emerald-50/15 hover:bg-emerald-50/30 transition-colors">
                      {/* S.N. Room */}
                      <td className="py-2 px-2 text-center font-mono font-medium text-slate-600 bg-slate-50/40 border-r border-slate-300">
                        {isNe ? toNepaliDigits(lineItems.length + 1) : lineItems.length + 1}
                      </td>

                      {/* Dropdown Room: Code select garda auto saman ko name aune, ra saman ko name select garda auto code aune */}
                      <td className="py-1.5 px-2 border-r border-slate-300">
                        <div className="space-y-1.5">
                          <div className="grid grid-cols-1 sm:grid-cols-12 gap-1.5">
                            {/* 1. Item Name selector - सामानको नाम छान्दा कोड स्वतः सेट हुन्छ */}
                            <div className="sm:col-span-8">
                              <label className="block text-[9px] font-bold text-slate-600 mb-0.5">
                                {isNe ? 'सामानको नाम छान्नुहोस् (Select Item Name):' : 'Select Item Name:'}
                              </label>
                              <select
                                value={selectedItemId}
                                onChange={(e) => handleSelectByName(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    e.preventDefault();
                                    handleAddLineItem();
                                  }
                                }}
                                className="w-full py-1.5 px-2 border border-slate-300 rounded bg-white text-xs font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer shadow-2xs"
                              >
                                <option value="">{isNe ? '-- सामानको नाम छान्नुहोस् --' : '-- Select Item Name --'}</option>
                                {items.map((it) => (
                                  <option key={it.id} value={it.id} disabled={it.currentStock <= 0}>
                                    {isNe ? it.nameNe || it.nameEn : it.nameEn} [{it.code}] {(it.hsCode || it.hsnCode) ? `| HS: ${it.hsCode || it.hsnCode}` : ''} | स्टक: {it.currentStock} {it.unit}
                                  </option>
                                ))}
                              </select>
                            </div>

                            {/* 2. Item Code - सामानको नामबाट कोड आफै आउने */}
                            <div className="sm:col-span-4">
                              <label className="block text-[9px] font-bold text-slate-600 mb-0.5">
                                {isNe ? 'सामान कोड (Auto Code):' : 'Item Code:'}
                              </label>
                              <div className="relative">
                                <input
                                  type="text"
                                  readOnly
                                  value={currentItem?.code || ''}
                                  placeholder={isNe ? 'नामबाट कोड स्वतः आउँछ' : 'Auto Code'}
                                  className="w-full py-1.5 px-2 border border-emerald-300 rounded bg-emerald-50/70 font-mono font-bold text-xs text-emerald-950 focus:outline-none shadow-2xs"
                                />
                              </div>
                            </div>
                          </div>

                          {/* Selected item details strip */}
                          {currentItem && (
                            <div className="p-1.5 bg-slate-50 rounded border border-slate-200 text-[10px] space-y-1">
                              <div className="flex items-center justify-between text-slate-700 flex-wrap gap-1">
                                <div className="flex items-center gap-1.5 font-mono">
                                  <span>कोड: <strong className="text-slate-900">{currentItem.code}</strong></span>
                                  {(currentItem.hsCode || currentItem.hsnCode) && (
                                    <span className="bg-slate-200/80 px-1 py-0.2 rounded text-slate-800 font-medium">
                                      HS: {currentItem.hsCode || currentItem.hsnCode}
                                    </span>
                                  )}
                                  <span className="text-slate-500">एकाइ: {currentItem.unit}</span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setInputIsVatExempt(!inputIsVatExempt)}
                                  className={`px-1.5 py-0.5 rounded font-bold border transition cursor-pointer ${
                                    inputIsVatExempt
                                      ? 'bg-amber-100 text-amber-900 border-amber-300'
                                      : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                  }`}
                                >
                                  {inputIsVatExempt ? 'कर छुट (Non-VAT)' : '१३% भ्याट (VAT)'}
                                </button>
                              </div>
                              <div className="text-slate-600 flex items-center justify-between flex-wrap gap-1">
                                <span>
                                  बिक्री दर ({inputUnitMode === 'SECONDARY' && currentItem.secondaryUnit ? currentItem.secondaryUnit : currentItem.unit}):{' '}
                                  <strong className="font-mono text-slate-900">रु. {inputRate || currentItem.sellingPrice}</strong>
                                </span>
                                <span className="font-mono font-semibold text-emerald-800">
                                  स्टक मौज्दात: {currentItem.currentStock} {currentItem.unit}
                                  {currentItem.secondaryUnit && currentItem.secondaryUnitRatio
                                    ? ` (${Math.round(currentItem.currentStock * currentItem.secondaryUnitRatio * 100) / 100} ${currentItem.secondaryUnit})`
                                    : ''}
                                </span>
                              </div>
                              {currentItem.secondaryUnit && (
                                <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-200/80">
                                  <span className="text-[10px] font-bold text-blue-900">
                                    🔄 एकाइ रूपान्तरण: 1 {currentItem.unit} = {currentItem.secondaryUnitRatio || 1} {currentItem.secondaryUnit}
                                  </span>
                                  <div className="flex items-center gap-1">
                                    <button
                                      type="button"
                                      onClick={() => handleToggleInputUnitMode('PRIMARY')}
                                      className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer border ${
                                        inputUnitMode === 'PRIMARY'
                                          ? 'bg-emerald-700 text-white border-emerald-800'
                                          : 'bg-white text-slate-700 border-slate-300'
                                      }`}
                                    >
                                      मुख्य ({currentItem.unit})
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleToggleInputUnitMode('SECONDARY')}
                                      className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer border ${
                                        inputUnitMode === 'SECONDARY'
                                          ? 'bg-blue-700 text-white border-blue-800'
                                          : 'bg-white text-slate-700 border-slate-300'
                                      }`}
                                    >
                                      द्वितीय ({currentItem.secondaryUnit})
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Size Room: सामानको नाम आउँदा साइज (Size) छनौट गर्न मिल्ने */}
                      <td className="py-1.5 px-2 text-center border-r border-slate-300">
                        <div className="space-y-1">
                          {isCustomSize ? (
                            <div className="flex items-center gap-1">
                              <input
                                type="text"
                                placeholder="साइज..."
                                value={inputSize}
                                onChange={(e) => setInputSize(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    e.preventDefault();
                                    handleAddLineItem();
                                  }
                                }}
                                className="w-full text-center bg-white border border-emerald-400 rounded py-1 px-1 text-xs font-semibold focus:ring-1 focus:ring-emerald-500"
                                autoFocus
                              />
                              <button
                                type="button"
                                onClick={() => setIsCustomSize(false)}
                                className="text-slate-400 hover:text-slate-700 text-xs px-1"
                                title="साइज सूचीमा फर्कनुहोस्"
                              >
                                ✕
                              </button>
                            </div>
                          ) : (
                            <select
                              value={inputSize}
                              onChange={(e) => {
                                if (e.target.value === '__CUSTOM__') {
                                  setIsCustomSize(true);
                                  setInputSize('');
                                } else {
                                  handleSelectSize(e.target.value);
                                }
                              }}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleAddLineItem();
                                }
                              }}
                              className="w-full text-center bg-white border border-slate-300 rounded py-1 px-1 text-xs font-semibold text-slate-800 focus:ring-1 focus:ring-emerald-500 cursor-pointer shadow-2xs"
                            >
                              <option value="">-- साइज छान्नुहोस् --</option>
                              {availableSizes.map((sz) => (
                                <option key={sz} value={sz}>
                                  {sz} {currentItem?.size === sz ? '(डिफल्ट)' : ''}
                                </option>
                              ))}
                              <option value="__CUSTOM__">✏️ टाइप गर्ने (Custom)</option>
                            </select>
                          )}
                          {currentItem?.size && !isCustomSize && (
                            <div className="text-[9px] text-slate-500 font-mono">
                              डिफल्ट: {currentItem.size}
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Quantity Room + Unit Dropdown */}
                      <td className="py-1.5 px-2 text-center border-r border-slate-300">
                        <div className="flex flex-col items-center gap-1">
                          <NumField value={inputQty} onCommit={(n) => setInputQty(n)} onEnter={handleAddLineItem} className="w-14 text-center font-mono font-bold bg-white border border-slate-200 rounded py-1 text-xs focus:ring-1 focus:ring-emerald-500 shadow-2xs" />
                          {currentItem && currentItem.secondaryUnit ? (
                            <select
                              value={inputUnitMode}
                              onChange={(e) => handleToggleInputUnitMode(e.target.value as 'PRIMARY' | 'SECONDARY')}
                              className="text-[10px] font-bold bg-white border border-emerald-400 text-emerald-950 rounded px-1 py-0.5 cursor-pointer"
                            >
                              <option value="PRIMARY">{currentItem.unit} (मुख्य)</option>
                              <option value="SECONDARY">{currentItem.secondaryUnit} (द्वितीय)</option>
                            </select>
                          ) : (
                            currentItem && <span className="text-[10px] text-slate-500 font-mono">{currentItem.unit}</span>
                          )}
                        </div>
                      </td>

                      {/* Rate Room with Rs. */}
                      <td className="py-1.5 px-2 text-right border-r border-slate-300">
                        <div className="flex items-center justify-end gap-1">
                          <span className="text-slate-400 font-mono text-[10px]">Rs.</span>
                          <NumField value={inputRate} onCommit={(n) => setInputRate(n)} onEnter={handleAddLineItem} placeholder="Rs." blankWhenZero className="w-16 text-right font-mono font-medium bg-white border border-slate-200 rounded py-1 px-1 text-xs placeholder:text-slate-400 focus:ring-1 focus:ring-emerald-500 shadow-2xs" />
                        </div>
                      </td>

                      {/* Discount % Room */}
                      <td className="py-1.5 px-2 text-center border-r border-slate-300">
                        <div className="flex items-center justify-center gap-0.5">
                          <NumField value={inputDiscount} onCommit={(n) => setInputDiscount(Math.min(100, n))} onEnter={handleAddLineItem} placeholder="%" blankWhenZero className="w-10 text-center font-mono bg-white border border-slate-200 rounded py-1 text-xs placeholder:text-slate-400 focus:ring-1 focus:ring-emerald-500 shadow-2xs" />
                          <span className="text-slate-400 text-[10px]">%</span>
                        </div>
                      </td>

                      {/* Discount Amount Room (column ma chut% paxe discount amount dekhaune, vat ko column hataune) */}
                      <td className="py-1.5 px-2 text-right font-mono tabular-nums text-rose-700 font-semibold border-r border-slate-300">
                        <span className="text-slate-400 text-[10px] font-normal mr-0.5">Rs.</span>
                        {(((inputQty * inputRate) * (inputDiscount || 0)) / 100).toFixed(2)}
                      </td>

                      {/* Amount Room with Rs. */}
                      <td className="py-1.5 px-3 text-right font-mono font-bold text-slate-900 border-r border-slate-300">
                        <span className="text-slate-400 text-[10px] font-normal mr-1">Rs.</span>
                        {(((inputQty * inputRate) * (1 - (inputDiscount || 0) / 100)) || 0).toFixed(2)}
                      </td>

                      {/* Action Room: थप्नुहोस् (Add button) & Clear Draft */}
                      <td className="py-1.5 px-2 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={handleAddLineItem}
                            disabled={!currentItem}
                            className={`px-2.5 py-1.5 rounded-md text-xs font-bold transition flex items-center gap-1 cursor-pointer shadow-2xs whitespace-nowrap ${
                              currentItem
                                ? 'bg-emerald-700 hover:bg-emerald-800 text-white active:scale-95'
                                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                            }`}
                            title={isNe ? 'बिलमा सामान थप्नुहोस् (Add Item)' : 'Add Item'}
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>{isNe ? 'थप्नुहोस्' : 'Add'}</span>
                          </button>
                          {currentItem && (
                            <button
                              type="button"
                              onClick={handleClearDraftRow}
                              className="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1.5 rounded transition cursor-pointer"
                              title={isNe ? 'खाली गर्नुहोस्' : 'Clear draft row'}
                            >
                              <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Bottom bar with dedicated "+ थप्नुहोस्" button, Save Bill, Save & Print, and Enter keyboard hint (same column action) */}
              <div className="px-4 py-3 bg-slate-50 border-t border-slate-300 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={handleAddLineItem}
                    disabled={!currentItem}
                    className={`px-3 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-2xs cursor-pointer ${
                      currentItem
                        ? 'bg-slate-700 hover:bg-slate-800 text-white active:scale-95'
                        : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    }`}
                  >
                    <Plus className="w-4 h-4" />
                    <span>{isNe ? '+ थप्नुहोस् (Add)' : '+ Add'}</span>
                  </button>

                  {/* Direct Save in same column */}
                  <button
                    type="button"
                    onClick={() => handleSaveBill(false)}
                    disabled={lineItems.length === 0 && !currentItem}
                    className="px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer bg-blue-700 hover:bg-blue-800 text-white disabled:opacity-50 disabled:cursor-not-allowed active:scale-95"
                    title={isNe ? 'बिल सुरक्षित मात्र गर्नुहोस्' : 'Save bill to database'}
                  >
                    <Save className="w-4 h-4" />
                    <span>{isNe ? '💾 सुरक्षित गर्नुहोस् (Save)' : 'Save Bill'}</span>
                  </button>

                  {/* Direct Save & Print in same column */}
                  <button
                    type="button"
                    onClick={() => handleSaveBill(true)}
                    disabled={lineItems.length === 0 && !currentItem}
                    className="px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer bg-emerald-700 hover:bg-emerald-800 text-white disabled:opacity-50 disabled:cursor-not-allowed ring-2 ring-emerald-600/30 active:scale-95"
                    title={isNe ? 'पहिले सेभ गरी तुरुन्तै प्रिन्ट / PDF डाउनलोड गर्नुहोस्' : 'Save bill and open Print / Direct PDF'}
                  >
                    <Printer className="w-4 h-4" />
                    <span>{isNe ? '🖨️ सेभ र प्रिन्ट (Save & Print)' : 'Save & Print'}</span>
                  </button>

                  <div className="flex items-center gap-1 text-[11px] text-slate-500 hidden sm:flex">
                    <span className="px-1.5 py-0.5 bg-white border border-slate-300 rounded font-mono font-bold text-[10px] text-slate-700">
                      ↵ Enter
                    </span>
                    <span>{isNe ? 'थिचेर थप्न सकिन्छ' : 'to add'}</span>
                  </div>
                </div>

                <div className="font-mono text-slate-700 text-xs font-bold">
                  {lineItems.length} {isNe ? 'सामान बिलमा समावेश' : 'items added'}
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Bottom Section: Calculation, Payment, Notes, Totals & Save Buttons Placed Directly Below Room Table */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Calculator className="w-4 h-4 text-emerald-700" />
              <span>{isNe ? 'विक्री बिल हिसाब-किताब, भुक्तानी तथा फछ्र्यौट (Bill Summary & Settlement)' : 'Invoice Calculation & Settlement'}</span>
            </h3>
            <span className="text-xs font-mono font-bold text-emerald-950 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
              {isNe ? 'कुल जम्मा:' : 'Grand Total:'} {formatCurrency(totals.grandTotal, isNe)}
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left Box: Payment Mode, Bank QR, Paid Amount Today & Due */}
            <div className="lg:col-span-6 space-y-4">
              {/* Payment Mode Selector */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1.5">
                  {t.paymentMode}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPaymentMode('CASH')}
                    className={`py-2 px-2 font-semibold rounded-lg border text-center transition cursor-pointer ${
                      paymentMode === 'CASH'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {t.payCash}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentMode('BANK_FONEPAY');
                      if (company.bankAccounts && company.bankAccounts.length > 0 && !selectedBankAccountId) {
                        const firstAcc = company.bankAccounts[0];
                        setSelectedBankAccountId(firstAcc.id);
                        setQrSelectedBankId(firstAcc.id);
                        setBankName(firstAcc.bankName);
                        setBankAccountNo(firstAcc.accountNumber);
                      }
                    }}
                    className={`py-2 px-2 font-semibold rounded-lg border text-center transition cursor-pointer ${
                      paymentMode === 'BANK_FONEPAY'
                        ? 'bg-blue-600 border-blue-700 text-white shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {t.payBank}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMode('CREDIT')}
                    className={`py-2 px-2 font-semibold rounded-lg border text-center transition cursor-pointer ${
                      paymentMode === 'CREDIT'
                        ? 'bg-amber-50 border-amber-500 text-amber-900 shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {t.payCredit}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMode('STAFF_SALARY_DEDUCT')}
                    className={`py-2 px-2 font-semibold rounded-lg border text-center transition cursor-pointer ${
                      paymentMode === 'STAFF_SALARY_DEDUCT'
                        ? 'bg-purple-50 border-purple-500 text-purple-900 shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {isNe ? 'कर्मचारी तलब कट्टी' : 'Salary Deduct'}
                  </button>
                </div>

                {/* Direct Instant Bank QR Button */}
                {paymentMode !== 'BANK_FONEPAY' && (
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentMode('BANK_FONEPAY');
                      if (company.bankAccounts && company.bankAccounts.length > 0 && !selectedBankAccountId) {
                        const firstAcc = company.bankAccounts[0];
                        setSelectedBankAccountId(firstAcc.id);
                        setQrSelectedBankId(firstAcc.id);
                        setBankName(firstAcc.bankName);
                        setBankAccountNo(firstAcc.accountNumber);
                      }
                    }}
                    className="w-full mt-2 py-2 px-3 bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 hover:from-blue-800 hover:to-indigo-900 text-white font-bold text-xs rounded-lg shadow-sm transition flex items-center justify-center gap-2 cursor-pointer border border-blue-600/40"
                  >
                    <QrCode className="w-4 h-4 text-blue-200" />
                    <span>{isNe ? '📱 बैंक भुक्तानी / सिधै QR कोड देखाउनुहोस् (Scan & Pay)' : '📱 Bank Payment / Show Direct QR Code'}</span>
                  </button>
                )}

                {/* Direct Inline Bank QR & Account Details */}
                {paymentMode === 'BANK_FONEPAY' && (() => {
                  const activeBank =
                    (company.bankAccounts || []).find((acc) => acc.id === selectedBankAccountId) ||
                    (company.bankAccounts || [])[0];
                  const livePayAmount =
                    amountPaidInput !== '' && Number(amountPaidInput) > 0
                      ? Number(amountPaidInput)
                      : totals.grandTotal;
                  const inlineQrPayload = activeBank
                    ? `https://fonepay.com/pay?ac=${encodeURIComponent(activeBank.accountNumber)}&bank=${encodeURIComponent(activeBank.bankName)}&name=${encodeURIComponent(activeBank.accountHolder || company.name)}&amt=${livePayAmount}&ref=BILL-${nextBillNoPreview}`
                    : `BILL-${nextBillNoPreview}: Rs. ${livePayAmount}`;

                  return (
                    <div className="mt-3 p-3 bg-gradient-to-b from-blue-50/90 to-indigo-50/60 border-2 border-blue-300 rounded-xl space-y-3 text-xs shadow-xs">
                      <div className="flex items-center justify-between border-b border-blue-200/80 pb-2">
                        <div className="flex items-center gap-1.5">
                          <QrCode className="w-4 h-4 text-blue-700" />
                          <span className="font-extrabold text-blue-950">
                            {isNe ? 'सिधै बैंक QR स्क्यान र भुक्तानी (Direct Bank QR):' : 'Direct Bank QR & Account Payment:'}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            if (selectedBankAccountId) setQrSelectedBankId(selectedBankAccountId);
                            setIsBankQrModalOpen(true);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-[11px] font-bold cursor-pointer shadow-2xs"
                        >
                          <QrCode className="w-3 h-3" />
                          <span>{isNe ? 'ठूलो QR स्क्रिन' : 'Full Screen QR'}</span>
                        </button>
                      </div>

                      {/* Bank Account Selector */}
                      <div>
                        <label className="block text-[10px] font-bold text-blue-900 mb-1">
                          {isNe ? 'भुक्तानी जम्मा हुने बैंक खाता छान्नुहोस्:' : 'Select Receiving Bank Account:'}
                        </label>
                        <select
                          value={selectedBankAccountId || activeBank?.id || ''}
                          onChange={(e) => {
                            const bId = e.target.value;
                            setSelectedBankAccountId(bId);
                            setQrSelectedBankId(bId);
                            const b = (company.bankAccounts || []).find((acc) => acc.id === bId);
                            if (b) {
                              setBankName(b.bankName);
                              setBankAccountNo(b.accountNumber);
                            }
                          }}
                          className="w-full px-2.5 py-1.5 border border-blue-300 rounded-lg bg-white text-xs font-bold text-slate-900"
                        >
                          {(company.bankAccounts || []).map((acc) => (
                            <option key={acc.id} value={acc.id}>
                              {acc.bankName} — खाता नं: {acc.accountNumber} ({acc.accountHolder || company.name})
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Inline Direct QR Display Box */}
                      <div className="bg-white rounded-xl border border-blue-200 p-3 flex flex-col sm:flex-row items-center gap-3.5 shadow-xs">
                        <div className="flex flex-col items-center justify-center p-2 bg-slate-50 rounded-xl border border-slate-200 shrink-0">
                          {activeBank?.qrCodeUrl ? (
                            <img
                              src={activeBank.qrCodeUrl}
                              alt={activeBank.bankName}
                              className="w-32 h-32 object-contain rounded-lg bg-white"
                            />
                          ) : (
                            <QRCodeSVG
                              value={inlineQrPayload}
                              size={120}
                              level="M"
                              includeMargin={false}
                            />
                          )}
                          <span className="mt-1 text-[9px] font-extrabold text-blue-900 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                            {activeBank?.qrCodeUrl ? 'आधिकारिक बैंक QR' : 'FonePay / Smart QR'}
                          </span>
                        </div>

                        <div className="flex-1 w-full space-y-1.5 text-center sm:text-left">
                          <div className="bg-blue-50/90 border border-blue-200 rounded-lg p-2">
                            <div className="text-[10px] font-semibold text-blue-800">
                              {isNe ? 'ग्राहकले स्क्यान गरी तिर्ने रकम:' : 'Scan & Pay Amount:'}
                            </div>
                            <div className="text-base font-black text-blue-950 font-mono">
                              रु. {livePayAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </div>
                          </div>

                          {activeBank && (
                            <div className="space-y-0.5 text-[11px] text-slate-700">
                              <div><span className="text-slate-500">बैंक: </span><strong className="text-slate-900">{activeBank.bankName}</strong></div>
                              <div><span className="text-slate-500">खातावाला: </span><strong className="text-slate-900">{activeBank.accountHolder || company.name}</strong></div>
                              <div className="flex items-center justify-center sm:justify-start gap-1">
                                <span className="text-slate-500">खाता नं: </span>
                                <span className="font-mono font-bold text-slate-950 bg-slate-100 px-1 py-0.2 rounded border border-slate-200">{activeBank.accountNumber}</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    navigator.clipboard.writeText(activeBank.accountNumber);
                                    setCopiedBankAcc(true);
                                    setTimeout(() => setCopiedBankAcc(false), 2000);
                                  }}
                                  className="px-1.5 py-0.2 bg-slate-100 text-slate-700 rounded text-[9px] font-bold cursor-pointer border border-slate-300"
                                >
                                  {copiedBankAcc ? '✓ कपी' : 'कपी'}
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Amount Paid Today & Live Net Remaining Due */}
              <div className="p-3 bg-emerald-50/80 rounded-xl border-2 border-emerald-300 space-y-2 text-xs">
                <div className="flex items-center justify-between font-bold text-emerald-950">
                  <span>{isNe ? 'आज बुझाएको रकम (Paid Amount रु.):' : 'Paid Amount Today (Rs.):'}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setAmountPaidInput(totals.grandTotal)}
                      className="px-2 py-0.5 bg-white border border-emerald-400 rounded text-[10px] text-emerald-800 font-bold hover:bg-emerald-100 cursor-pointer shadow-2xs"
                    >
                      पूरा रकम
                    </button>
                    <button
                      type="button"
                      onClick={() => setAmountPaidInput(0)}
                      className="px-2 py-0.5 bg-white border border-emerald-400 rounded text-[10px] text-rose-700 font-bold hover:bg-rose-50 cursor-pointer shadow-2xs"
                    >
                      रु. ० (बाँकी)
                    </button>
                  </div>
                </div>
                <input
                  type="number"
                  min={0}
                  value={amountPaidInput === '' ? (paymentMode === 'CREDIT' ? 0 : totals.grandTotal) : amountPaidInput}
                  onChange={(e) => setAmountPaidInput(e.target.value === '' ? '' : parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-1.5 border-2 border-emerald-400 rounded-lg bg-white font-mono font-bold text-base text-emerald-950 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />

                {/* Live Remaining Balance Calculation */}
                <div className="pt-2 border-t border-emerald-200/80 space-y-1">
                  <div className="flex justify-between text-slate-600 text-[11px]">
                    <span>कुल तिर्नुपर्ने (Previous Due + Bill):</span>
                    <span className="font-mono tabular-nums">{formatCurrency(netTotalDue, isNe)}</span>
                  </div>
                  <div className="flex justify-between text-emerald-800 font-semibold text-[11px]">
                    <span>आज बुझाएको रकम (Paid Today):</span>
                    <span className="font-mono tabular-nums">
                      -{formatCurrency(amountPaidInput !== '' ? Number(amountPaidInput) : (paymentMode === 'CREDIT' ? 0 : totals.grandTotal), isNe)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs font-bold text-slate-900 pt-1 border-t border-emerald-300">
                    <span className="text-rose-900 font-bold">{isNe ? 'हालसम्म बाँकी रकम (Remaining Due):' : 'Net Remaining Due:'}</span>
                    <span className="font-mono font-black text-rose-700 text-sm">
                      {formatCurrency(
                        Math.max(
                          0,
                          netTotalDue - (amountPaidInput !== '' ? Number(amountPaidInput) : (paymentMode === 'CREDIT' ? 0 : totals.grandTotal))
                        ),
                        isNe
                      )}
                    </span>
                  </div>
                </div>
              </div>

              {/* Payment Due Date */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-semibold text-slate-700 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{isNe ? 'रकम बुझाउने म्याद / भाका (Payment Due Date)' : 'Payment Due Date'}</span>
                  </label>
                  {paymentDueDate && (
                    <button
                      type="button"
                      onClick={() => setPaymentDueDate('')}
                      className="text-[10px] text-rose-600 hover:underline cursor-pointer"
                    >
                      {isNe ? 'हटाउनुहोस्' : 'Clear'}
                    </button>
                  )}
                </div>
                <input
                  type="text"
                  placeholder="जस्तै: २०८१-१२-१५ वा १५ दिन"
                  value={paymentDueDate}
                  onChange={(e) => setPaymentDueDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-xs bg-white font-mono"
                />
                <div className="flex items-center gap-1.5 pt-0.5">
                  {['७ दिन', '१५ दिन', '३० दिन', '१ महिना'].map((chip) => (
                    <button
                      key={chip}
                      type="button"
                      onClick={() => setPaymentDueDate(chip)}
                      className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 rounded text-[10px] font-medium text-slate-600 cursor-pointer"
                    >
                      {chip}
                    </button>
                  ))}
                </div>
              </div>

              {/* Notes / Remarks input */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  कैफियत (Bill Notes / Remarks)
                </label>
                <input
                  type="text"
                  placeholder="जस्तै: होम डेलिभरी, अग्रिम भुक्तानी आदि"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Right Box: Discount, Freight, Calculations, Words & Action Buttons */}
            <div className="lg:col-span-6 space-y-4">
              {/* Discount & Freight inputs */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1 flex items-center gap-1">
                    <Percent className="w-3 h-3 text-emerald-700" />
                    <span>{t.discount}</span>
                  </label>
                  <input
                    type="number"
                    inputMode="decimal"
                    min={0}
                    max={100}
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono bg-white font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1 flex items-center gap-1">
                    <Truck className="w-3 h-3 text-emerald-700" />
                    <span>{t.freight}</span>
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={freightCharge}
                    onChange={(e) => setFreightCharge(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 border border-slate-200 rounded font-mono bg-white font-bold"
                  />
                </div>
              </div>

              {/* Calculations Breakdown */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between text-slate-700 font-semibold">
                  <span>{isNe ? 'उप-जम्मा (Sub Total):' : 'Sub Total:'}</span>
                  <span className="font-mono tabular-nums">{formatCurrency(totals.subtotal, isNe)}</span>
                </div>

                {totals.discountAmount > 0 && (
                  <div className="flex justify-between text-rose-700">
                    <span>{isNe ? `छुट (${discountPercent}%):` : `Discount (${discountPercent}%):`}</span>
                    <span className="font-mono tabular-nums">-{formatCurrency(totals.discountAmount, isNe)}</span>
                  </div>
                )}

                {totals.freightCharge > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>{isNe ? 'ढुवानी शुल्क (Freight):' : 'Freight Charge:'}</span>
                    <span className="font-mono tabular-nums">+{formatCurrency(totals.freightCharge, isNe)}</span>
                  </div>
                )}

                <div className="pt-2 pb-1 border-t border-slate-200 space-y-1.5">
                  <div className="flex items-center justify-between text-slate-700 font-medium">
                    <div className="flex items-center gap-1.5">
                      <span>{isNe ? 'अकरयोग्य / कर छुट रकम (VAT Exempt):' : 'Non-Taxable / Exempt:'}</span>
                      <button
                        type="button"
                        onClick={() => {
                          const next = !isManualExemptMode;
                          setIsManualExemptMode(next);
                          if (!next) {
                            setManualExemptInput('');
                          } else {
                            setManualExemptInput(totals.exemptAmount || 0);
                          }
                        }}
                        className={`text-[10px] px-1.5 py-0.5 rounded font-bold transition cursor-pointer border ${
                          isManualExemptMode
                            ? 'bg-emerald-700 text-white border-emerald-800 shadow-2xs'
                            : 'bg-slate-200 hover:bg-slate-300 text-slate-700 border-slate-300'
                        }`}
                        title={isNe ? 'म्यानुअल कर छुट रकम तोक्ने' : 'Toggle manual exempt amount'}
                      >
                        {isManualExemptMode ? (isNe ? '✓ म्यानुअल' : 'Manual') : (isNe ? 'स्वतः (Auto)' : 'Auto')}
                      </button>
                    </div>

                    {!isManualExemptMode ? (
                      <span className="font-mono font-bold text-slate-800 tabular-nums">
                        {formatCurrency(totals.exemptAmount, isNe)}
                      </span>
                    ) : (
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-slate-500 font-mono">रु.</span>
                        <input
                          type="number"
                          min={0}
                          max={totals.subtotal}
                          value={manualExemptInput}
                          onChange={(e) => setManualExemptInput(e.target.value === '' ? '' : Math.max(0, parseFloat(e.target.value) || 0))}
                          placeholder="०.००"
                          className="w-28 px-2 py-0.5 border border-emerald-400 rounded bg-white text-right font-mono font-bold text-xs text-emerald-950 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex justify-between text-slate-700 font-medium">
                  <span>{isNe ? 'करयोग्य रकम (Taxable Amount):' : 'Taxable Amount:'}</span>
                  <span className="font-mono tabular-nums">{formatCurrency(totals.taxableAmount, isNe)}</span>
                </div>

                {billType === 'VAT' && (
                  <div className="flex justify-between text-blue-900 font-bold">
                    <span>{isNe ? '१३% भ्याट (13% Tax / VAT Amount):' : '13% Tax / VAT Amount:'}</span>
                    <span className="font-mono tabular-nums">{formatCurrency(totals.vatAmount, isNe)}</span>
                  </div>
                )}

                <div className="flex justify-between items-center text-sm font-bold text-slate-900 pt-2 border-t border-slate-300">
                  <span className="text-emerald-950 font-extrabold">{isNe ? 'कुल जम्मा रकम (Grand Total Amount):' : 'Grand Total Amount:'}</span>
                  <span className="font-mono text-emerald-800 tabular-nums text-lg font-black">
                    {formatCurrency(totals.grandTotal, isNe)}
                  </span>
                </div>

                {previousDue > 0 && (
                  <div className="pt-2 border-t border-dashed border-amber-300 space-y-1">
                    <div className="flex justify-between text-amber-900 font-medium">
                      <span>{isNe ? 'पुरानो लिन बाँकी (Previous Due):' : 'Previous Due:'}</span>
                      <span className="font-mono">{formatCurrency(previousDue, isNe)}</span>
                    </div>
                    <div className="flex justify-between text-sm sm:text-base font-extrabold text-slate-950 pt-1 border-t border-slate-300">
                      <span>{isNe ? 'कुल जम्मा बाँकी (Total Due):' : 'Net Total Due:'}</span>
                      <span className="font-mono text-rose-700">
                        {formatCurrency(netTotalDue, isNe)}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* In Words Preview */}
              <div className="text-xs text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-200 font-medium">
                <span className="font-bold text-slate-900">अक्षरूपी (In Words): </span>
                <span className="font-semibold text-emerald-950">{amountInNepaliWords(totals.grandTotal)}</span>
              </div>

              {/* Prominent Action Buttons at Bottom */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => handleSaveBill(false)}
                  disabled={isSavingBill || (lineItems.length === 0 && !selectedItemId)}
                  className="py-3.5 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Save className="w-4.5 h-4.5" />
                  <span>{editingInvoiceId ? (isNe ? '💾 सच्याइ सुरक्षित गर्नुहोस्' : 'Save Changes') : (isNe ? '💾 सुरक्षित गर्नुहोस्' : 'Save Bill')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSaveBill(true)}
                  disabled={isSavingBill || (lineItems.length === 0 && !selectedItemId)}
                  className="py-3.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer ring-2 ring-emerald-600/30 active:scale-95"
                >
                  <Printer className="w-4.5 h-4.5" />
                  <span>{editingInvoiceId ? (isNe ? '🖨️ सच्याएर प्रिन्ट गर्नुहोस्' : 'Update & Print') : (isNe ? '🖨️ बिल सुरक्षित गरी प्रिन्ट गर्नुहोस्' : 'Save & Print Bill')}</span>
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Recent Invoices Quick Re-Print & Direct PDF Download Bar */}
      {invoices.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Receipt className="w-4 h-4 text-emerald-700" />
              <span>{isNe ? `हालसालै जारी गरिएका बिक्री बिलहरू (${invoices.length})` : `Recent Sales Invoices (${invoices.length})`}</span>
            </span>
            <span className="text-[11px] text-slate-500">
              {isNe ? 'कुनै पनि बिल सिधै PDF वा प्रिन्ट गर्न क्लिक गर्नुहोस्' : 'Click to print or download PDF'}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-2 px-2.5">बिल नं.</th>
                  <th className="py-2 px-2.5">मिति (B.S.)</th>
                  <th className="py-2 px-2.5">ग्राहक</th>
                  <th className="py-2 px-2.5 text-right">जम्मा रकम</th>
                  <th className="py-2 px-2.5 text-center">प्रकार</th>
                  <th className="py-2 px-2.5 text-center">कार्य</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.slice(0, 5).map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-2 px-2.5 font-mono font-bold text-slate-900">{inv.invoiceNo}</td>
                    <td className="py-2 px-2.5 text-slate-600 font-mono">
                      {inv.dateBs}
                      {inv.entryDateBs && inv.entryDateBs !== inv.dateBs && (
                        <span
                          className="block text-[9px] text-slate-400 font-sans"
                          title={isNe ? 'सिस्टममा वास्तविक प्रविष्टि मिति' : 'Actual system entry date'}
                        >
                          {isNe ? 'प्रविष्टि' : 'Entry'}: {inv.entryDateBs}
                        </span>
                      )}
                    </td>
                    <td className="py-2 px-2.5 font-medium text-slate-800">{inv.customerName}</td>
                    <td className="py-2 px-2.5 text-right font-mono font-bold text-emerald-700">
                      {formatCurrency(inv.grandTotal, isNe)}
                    </td>
                    <td className="py-2 px-2.5 text-center">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        inv.billType === 'VAT' ? 'bg-blue-100 text-blue-900' : 'bg-slate-100 text-slate-800'
                      }`}>
                        {inv.billType}
                      </span>
                    </td>
                    <td className="py-2 px-2.5 text-center space-x-1.5 whitespace-nowrap">
                      {inv.status === 'ACTIVE' && (
                        <button
                          type="button"
                          onClick={() => startEditInvoice(inv.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-md text-[11px] font-bold transition cursor-pointer shadow-2xs"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>{isNe ? 'सच्याउने' : 'Edit'}</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setCreatedInvoice(inv)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-[11px] font-bold transition cursor-pointer shadow-2xs"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>{isNe ? '📄 PDF / प्रिन्ट' : 'PDF / Print'}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Invoice Print & Share Modal */}
      {createdInvoice && (
        <InvoicePrintModal
          invoice={createdInvoice}
          onClose={() => setCreatedInvoice(null)}
          onEditInvoice={(id) => {
            setCreatedInvoice(null);
            startEditInvoice(id);
          }}
          onCancelInvoice={(id) => {
            cancelInvoice(id);
            setCreatedInvoice(null);
          }}
          onDeleteInvoice={(id) => {
            deleteInvoice(id);
            setCreatedInvoice(null);
          }}
        />
      )}

      {/* AI Handwritten Bill Scanner Modal */}
      <HandwrittenBillScannerModal
        isOpen={isAiScanModalOpen}
        onClose={() => setIsAiScanModalOpen(false)}
        onApplyExtractedData={handleApplyExtractedBill}
      />

      {/* Inline Edit/Add Customer Modal */}
      {isCustomerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                {isNe ? 'ग्राहकको नाम, ठेगाना र पुरानो बाँकी सच्याउने' : 'Edit Customer & Opening Due'}
              </h3>
              <button
                type="button"
                onClick={() => setIsCustomerModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomerModal} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  ग्राहकको नाम (Customer Name)*
                </label>
                <input
                  type="text"
                  required
                  value={editCustName}
                  onChange={(e) => setEditCustName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  ठेगाना (Address)*
                </label>
                <input
                  type="text"
                  required
                  placeholder="जस्तै: भरतपुर-०६, चितवन"
                  value={editCustAddress}
                  onChange={(e) => setEditCustAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    सम्पर्क फोन (Phone)
                  </label>
                  <input
                    type="text"
                    placeholder="९८xxxxxxxx"
                    value={editCustPhone}
                    onChange={(e) => setEditCustPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    प्यान नं. (PAN No)
                  </label>
                  <input
                    type="text"
                    maxLength={9}
                    placeholder="९ अंकको प्यान"
                    value={editCustPan}
                    onChange={(e) => setEditCustPan(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 space-y-1">
                <label className="block text-[11px] font-bold text-amber-950">
                  पुरानो लिन बाँकी रकम (Opening Due / Old Balance रु.)
                </label>
                <input
                  type="number"
                  min={0}
                  value={editCustOpeningDue}
                  onChange={(e) => setEditCustOpeningDue(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-amber-300 rounded-lg bg-white font-mono font-bold text-amber-950 text-sm"
                />
                <p className="text-[10px] text-amber-800">
                  {isNe ? 'यो ग्राहकको पहिलेको बाँकी खाता रकम यहाँ राख्नुहोस्।' : 'Set the customer opening debt.'}
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCustomerModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  रद्द
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs"
                >
                  सुरक्षित गर्नुहोस् (Save)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Barcode & QR Camera Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isBarcodeScannerOpen}
        onClose={() => setIsBarcodeScannerOpen(false)}
        onItemScanned={handleBarcodeItemScanned}
      />

      {/* Bank QR Code (FonePay / Scan & Pay) Modal */}
      {isBankQrModalOpen && (() => {
        const activeBank = (company.bankAccounts || []).find((b) => b.id === qrSelectedBankId) || (company.bankAccounts || [])[0];
        const payAmount = (amountPaidInput !== '' && Number(amountPaidInput) > 0) ? Number(amountPaidInput) : totals.grandTotal;
        const qrPayload = activeBank
          ? `https://fonepay.com/pay?ac=${encodeURIComponent(activeBank.accountNumber)}&bank=${encodeURIComponent(activeBank.bankName)}&name=${encodeURIComponent(activeBank.accountHolder || company.name)}&amt=${payAmount}&ref=BILL-${nextBillNoPreview}`
          : `BILL-${nextBillNoPreview}: Rs. ${payAmount}`;

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
            <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
              {/* Header */}
              <div className="px-5 py-3.5 bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-white/20 rounded-lg">
                    <QrCode className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold leading-tight">
                      {isNe ? 'बैंक QR कोड भुक्तानी (Scan & Pay)' : 'Bank QR Payment (Scan & Pay)'}
                    </h3>
                    <p className="text-[10px] text-blue-100">
                      FonePay / eSewa / Mobile Banking बाट स्क्यान गरी भुक्तानी गर्नुहोस्
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsBankQrModalOpen(false)}
                  className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-5 space-y-4 text-xs">
                {/* Bank Account Selector if multiple */}
                {(company.bankAccounts || []).length > 1 && (
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      {isNe ? 'भुक्तानी प्राप्त हुने बैंक खाता छान्नुहोस्:' : 'Select Receiving Bank Account:'}
                    </label>
                    <select
                      value={activeBank?.id || ''}
                      onChange={(e) => setQrSelectedBankId(e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-slate-50 font-medium text-slate-800 focus:outline-none"
                    >
                      {(company.bankAccounts || []).map((acc) => (
                        <option key={acc.id} value={acc.id}>
                          {acc.bankName} — खाता नं: {acc.accountNumber} ({acc.accountHolder || company.name})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Amount to Pay Banner */}
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center">
                  <span className="text-[11px] font-medium text-blue-800 block">
                    {isNe ? 'ग्राहकले भुक्तानी गर्नुपर्ने रकम (Amount to Pay):' : 'Amount to Pay:'}
                  </span>
                  <div className="text-2xl font-black text-blue-900 font-mono tracking-tight my-0.5">
                    रु. {payAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                  <span className="text-[10px] text-blue-700 block">
                    बिल नं: <span className="font-mono font-bold">{nextBillNoPreview}</span> • {customerName || 'नगद ग्राहक'}
                  </span>
                </div>

                {/* QR Code Container */}
                <div className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-2xl border border-slate-200/80 shadow-inner">
                  <div className="p-3 bg-white rounded-xl shadow-md border border-slate-100 flex items-center justify-center">
                    {activeBank?.qrCodeUrl ? (
                      <img
                        src={activeBank.qrCodeUrl}
                        alt={activeBank.bankName}
                        className="w-52 h-52 object-contain rounded-lg"
                      />
                    ) : (
                      <QRCodeSVG
                        value={qrPayload}
                        size={200}
                        level="M"
                        includeMargin={false}
                      />
                    )}
                  </div>
                  <div className="mt-2 text-center">
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-700">
                      <span>{company.name}</span>
                    </span>
                    <p className="text-[10px] text-slate-500">
                      कुनै पनि बैंकिङ वा वालेट एपबाट सिधै स्क्यान गर्नुहोस्
                    </p>
                  </div>
                </div>

                {/* Bank Account Details with Copy Button */}
                {activeBank ? (
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5 text-[11px]">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">बैंकको नाम:</span>
                      <span className="font-bold text-slate-900">{activeBank.bankName}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">खातावालाको नाम:</span>
                      <span className="font-bold text-slate-900">{activeBank.accountHolder || company.name}</span>
                    </div>
                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/70">
                      <span className="text-slate-500">खाता नं. (A/C No):</span>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono font-bold text-slate-950 text-xs bg-white px-2 py-0.5 border border-slate-200 rounded">
                          {activeBank.accountNumber}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(activeBank.accountNumber);
                            setCopiedBankAcc(true);
                            setTimeout(() => setCopiedBankAcc(false), 2000);
                          }}
                          className="inline-flex items-center gap-1 px-2 py-1 bg-white hover:bg-slate-100 border border-slate-300 rounded text-[10px] font-semibold text-slate-700 cursor-pointer"
                          title="खाता नम्बर कपी गर्नुहोस्"
                        >
                          {copiedBankAcc ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-700 font-bold">कपी भयो</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3 text-slate-500" />
                              <span>कपी</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                    {activeBank.branch && (
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">शाखा:</span>
                        <span className="text-slate-700">{activeBank.branch}</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-3 bg-amber-50 text-amber-900 rounded-lg text-center text-xs">
                    कम्पनी सेटिङमा बैंक खाता थपिएको छैन। Settings मा गएर खाता थप्नुहोस्।
                  </div>
                )}

                {/* Transaction Ref Entry */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    FonePay / ट्रान्सफर Reference / Trace No. (वैकल्पिक)
                  </label>
                  <input
                    type="text"
                    placeholder="जस्तै: FP-1049284 / TRACE-8849"
                    value={qrTxnRef}
                    onChange={(e) => setQrTxnRef(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg font-mono text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                  />
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsBankQrModalOpen(false)}
                    className="px-3 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
                  >
                    बन्द गर्नुहोस्
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentMode('BANK_FONEPAY');
                      setAmountPaidInput(payAmount);
                      if (activeBank) {
                        setSelectedBankAccountId(activeBank.id);
                        setBankName(activeBank.bankName);
                        setBankAccountNo(activeBank.accountNumber);
                      }
                      if (qrTxnRef.trim()) {
                        setTransactionRef(qrTxnRef.trim());
                      }
                      setIsBankQrModalOpen(false);
                      setScanToast({
                        message: `QR भुक्तानी रु. ${payAmount} स्वीकार गरियो!`,
                        type: 'success'
                      });
                      setTimeout(() => setScanToast(null), 3000);
                    }}
                    className="px-4 py-2 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-lg shadow-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4 text-white" />
                    <span>भुक्तानी भयो (Confirm & Mark Paid)</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Floating Scan Feedback Toast */}
      {scanToast && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-emerald-500/50 flex items-center gap-3 text-xs font-semibold animate-in slide-in-from-bottom">
          <div className="p-1 bg-emerald-500 text-slate-950 rounded-full">
            <CheckCircle2 className="w-3.5 h-3.5" />
          </div>
          <span className="font-medium text-emerald-100">{scanToast.message}</span>
        </div>
      )}
        </>
      )}

    </div>
  );
};
