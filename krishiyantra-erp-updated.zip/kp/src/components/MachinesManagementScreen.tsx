import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Machine, MaintenanceLog, MachineWorker } from '../types';
import { Factory, Plus, Trash2, Edit2, Wrench, Users, Zap } from 'lucide-react';
import { formatCurrency, getTodayBsString } from '../utils/nepaliCalendar';

export const MachinesManagementScreen: React.FC = () => {
  const { machines, saveMachine, deleteMachine, employees, language } = useApp();
  const isNe = language === 'ne';
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMachine, setEditingMachine] = useState<Machine | null>(null);
  
  // Form states
  const [nameNe, setNameNe] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [code, setCode] = useState('');
  const [power, setPower] = useState<number>(0);
  const [status, setStatus] = useState<'ACTIVE' | 'IN_MAINTENANCE' | 'INACTIVE'>('ACTIVE');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const machine: Machine = {
      id: editingMachine ? editingMachine.id : `mach-${Date.now()}`,
      nameNe,
      nameEn,
      code,
      powerConsumptionPerHr: power,
      purchaseDateBs: editingMachine ? editingMachine.purchaseDateBs : getTodayBsString(),
      status
    };
    saveMachine(machine);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center bg-white p-4 rounded-xl shadow-xs border">
        <h2 className="text-lg font-bold">{isNe ? 'मेसिन व्यवस्थापन' : 'Machine Management'}</h2>
        <button 
          onClick={() => { setEditingMachine(null); setIsModalOpen(true); }}
          className="px-4 py-2 bg-emerald-700 text-white rounded-lg font-bold flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> {isNe ? 'नयाँ मेसिन' : 'Add Machine'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {machines.map(machine => (
          <div key={machine.id} className="bg-white p-4 rounded-xl border shadow-sm">
            <div className="flex justify-between">
              <h3 className="font-bold text-lg">{isNe ? machine.nameNe : machine.nameEn}</h3>
              <span className={`px-2 py-1 rounded text-xs ${machine.status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{machine.status}</span>
            </div>
            <p className="text-sm text-slate-600">Code: {machine.code}</p>
            <p className="text-sm text-slate-600 flex items-center gap-1"><Zap className="w-4 h-4" /> {machine.powerConsumptionPerHr} kWh</p>
            <div className="flex gap-2 mt-4">
              <button onClick={() => { setEditingMachine(machine); setNameNe(machine.nameNe); setNameEn(machine.nameEn); setCode(machine.code); setPower(machine.powerConsumptionPerHr); setStatus(machine.status); setIsModalOpen(true); }} className="p-2 bg-slate-100 rounded"><Edit2 className="w-4 h-4" /></button>
              <button onClick={() => deleteMachine(machine.id)} className="p-2 bg-red-100 text-red-700 rounded"><Trash2 className="w-4 h-4" /></button>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
          <form onSubmit={handleSave} className="bg-white p-6 rounded-xl shadow-2xl w-full max-w-md space-y-4">
            <h3 className="font-bold text-lg">{editingMachine ? 'Edit Machine' : 'Add Machine'}</h3>
            <input className="w-full p-2 border rounded" placeholder="Name (Nepali)" value={nameNe} onChange={e => setNameNe(e.target.value)} required />
            <input className="w-full p-2 border rounded" placeholder="Name (English)" value={nameEn} onChange={e => setNameEn(e.target.value)} required />
            <input className="w-full p-2 border rounded" placeholder="Machine Code" value={code} onChange={e => setCode(e.target.value)} required />
            <input type="number" className="w-full p-2 border rounded" placeholder="Power Consumption (kWh)" value={power} onChange={e => setPower(Number(e.target.value))} required />
            <button type="submit" className="w-full py-2 bg-emerald-700 text-white rounded font-bold">{isNe ? 'सुरक्षित गर्नुहोस्' : 'Save'}</button>
            <button type="button" onClick={() => setIsModalOpen(false)} className="w-full py-2 bg-slate-200 rounded font-bold">{isNe ? 'रद्द' : 'Cancel'}</button>
          </form>
        </div>
      )}
    </div>
  );
};
