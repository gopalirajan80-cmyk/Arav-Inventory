import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { RawMaterial, ProductionBatch, RawMaterialUsage, QcCheckResult } from '../types';
import { bomRequirements } from '../utils/bomUtils';
import {
  Cpu,
  Boxes,
  Plus,
  Trash2,
  X,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  Package,
  Calendar,
  Sparkles,
  ShieldCheck,
  Scale
} from 'lucide-react';
import {
  getTodayBsString,
  adToBs,
  bsToAd,
  formatBsDate,
  toNepaliDigits
} from '../utils/nepaliCalendar';

interface ProductionBatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (batch: ProductionBatch) => void;
}

interface RawMaterialRow {
  rowId: string;
  materialId: string;
  materialName: string;
  quantity: number;
  unit: string;
  rate: number;
  availableStock: number;
}

export const ProductionBatchModal: React.FC<ProductionBatchModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const { rawMaterials, employees, machines, items, productionBatches, boms, language } = useApp();
  const isNe = language === 'ne';

  // 1. Batch Identity & Dual Dates
  const [batchNo, setBatchNo] = useState('');
  const [isManualBatchNo, setIsManualBatchNo] = useState(false);
  const [productionDateBs, setProductionDateBs] = useState(getTodayBsString());
  const [productionDateAd, setProductionDateAd] = useState('');

  // Manufacture & Expiry Dates
  const [mfgDateBs, setMfgDateBs] = useState(getTodayBsString());
  const [mfgDateAd, setMfgDateAd] = useState('');
  const [expDateBs, setExpDateBs] = useState('');
  const [expDateAd, setExpDateAd] = useState('');

  // 2. Output Product Details
  const [selectedItemId, setSelectedItemId] = useState('');
  const [productNameNe, setProductNameNe] = useState('');
  const [productNameEn, setProductNameEn] = useState('');
  const [outputQuantity, setOutputQuantity] = useState<number>(50);
  const [outputUnit, setOutputUnit] = useState('Kg');

  // 3. Raw Materials Input Rows (Multi-item)
  const [rmRows, setRmRows] = useState<RawMaterialRow[]>([]);
  const [manualInputQty, setManualInputQty] = useState<number | ''>('');
  const [inputUnit, setInputUnit] = useState('Kg');

  // 4. Overhead & Labor Costs
  const [laborCost, setLaborCost] = useState<number>(2500);
  const [electricityCost, setElectricityCost] = useState<number>(1200);
  const [otherOverheadCost, setOtherOverheadCost] = useState<number>(800);

  // 5. Packaging Details
  const [packetSize, setPacketSize] = useState('500g');
  const [packetsProduced, setPacketsProduced] = useState<number>(100);
  const [packagingType, setPackagingType] = useState('सिल्भर जिपर पाउच (Standup Pouch)');

  // 6. Quality & Machine
  const [qualityCheckStatus, setQualityCheckStatus] = useState<'PASS' | 'PENDING' | 'FAIL'>('PASS');
  const [qualityNotes, setQualityNotes] = useState('आर्द्रता, रङ्ग तथा शुद्धता मापदण्ड अनुसार ठीक छ');
  const [qualityCheckedBy, setQualityCheckedBy] = useState('');
  const [machineName, setMachineName] = useState('');
  const [operatorName, setOperatorName] = useState('');
  const [targetStage, setTargetStage] = useState<'FINISHED_GOODS' | 'IN_MACHINE_WIP'>('FINISHED_GOODS');
  const [notes, setNotes] = useState('');

  // 7. थप उत्पादन विवरण (BOM, शिफ्ट, स्क्र्याप, QC Checklist)
  const [bomId, setBomId] = useState('');
  const [shift, setShift] = useState<'MORNING' | 'DAY' | 'EVENING' | 'NIGHT'>('DAY');
  const [supervisorName, setSupervisorName] = useState('');
  const [machineHours, setMachineHours] = useState<number | ''>('');
  const [scrapQuantity, setScrapQuantity] = useState<number | ''>('');
  const [scrapReason, setScrapReason] = useState('');
  const [storageLocation, setStorageLocation] = useState('');
  const [qcChecks, setQcChecks] = useState<QcCheckResult[]>([]);

  // Initialize form when opening
  useEffect(() => {
    if (isOpen) {
      const todayBs = getTodayBsString();
      let todayAd = '';
      try {
        todayAd = bsToAd(todayBs).toISOString().slice(0, 10);
      } catch {
        todayAd = new Date().toISOString().slice(0, 10);
      }

      const generatedNo = `BATCH-${todayBs.slice(0, 4)}-${String(productionBatches.length + 1).padStart(3, '0')}`;
      setBatchNo(generatedNo);
      setIsManualBatchNo(false);
      setProductionDateBs(todayBs);
      setProductionDateAd(todayAd);
      setMfgDateBs(todayBs);
      setMfgDateAd(todayAd);

      // Expiry 1 year out
      try {
        const d = new Date();
        d.setFullYear(d.getFullYear() + 1);
        const expAdStr = d.toISOString().slice(0, 10);
        setExpDateAd(expAdStr);
        setExpDateBs(formatBsDate(adToBs(d)));
      } catch {
        const nextY = parseInt(todayBs.slice(0, 4)) + 1;
        setExpDateBs(`${nextY}${todayBs.slice(4)}`);
        setExpDateAd(todayAd);
      }

      setQualityCheckedBy(employees[0]?.name || 'सुरेश खनाल (गुणस्तर प्राविधिक)');
      setOperatorName(employees[0]?.name || 'रामचन्द्र सिलवाल');
      setMachineName(machines[0]?.nameNe || 'ग्राइन्डिङ मिल तथा मसला पल्भराइजर');

      // Populate default raw materials
      if (rawMaterials.length > 0) {
        const agroFirst = rawMaterials.filter((r) => r.category === 'AGRO_FOOD');
        const chosen = agroFirst.length > 0 ? agroFirst : rawMaterials.slice(0, 2);

        setRmRows(
          chosen.map((r, idx) => ({
            rowId: `row-${Date.now()}-${idx}`,
            materialId: r.id,
            materialName: r.nameNe,
            quantity: idx === 0 ? 35 : 10,
            unit: r.unit || 'Kg',
            rate: r.unitCostPrice || 100,
            availableStock: r.currentStock
          }))
        );
      } else {
        setRmRows([]);
      }

      setLaborCost(2500);
      setElectricityCost(1200);
      setOtherOverheadCost(800);
      setOutputQuantity(50);
      setOutputUnit('Kg');
      setPacketSize('500g');
      setPacketsProduced(100);
      setTargetStage('FINISHED_GOODS');
      setBomId('');
      setShift('DAY');
      setSupervisorName('');
      setMachineHours('');
      setScrapQuantity('');
      setScrapReason('');
      setStorageLocation('');
      setQcChecks([]);
    }
  }, [isOpen, productionBatches.length]);

  if (!isOpen) return null;

  // Handle Date Sync (BS -> AD)
  const handleBsDateChange = (newBs: string, type: 'prod' | 'mfg' | 'exp') => {
    if (type === 'prod') {
      setProductionDateBs(newBs);
      try {
        setProductionDateAd(bsToAd(newBs).toISOString().slice(0, 10));
      } catch {
        // fallback
      }
    } else if (type === 'mfg') {
      setMfgDateBs(newBs);
      try {
        setMfgDateAd(bsToAd(newBs).toISOString().slice(0, 10));
      } catch {
        // fallback
      }
    } else if (type === 'exp') {
      setExpDateBs(newBs);
      try {
        setExpDateAd(bsToAd(newBs).toISOString().slice(0, 10));
      } catch {
        // fallback
      }
    }
  };

  // Handle Date Sync (AD -> BS)
  const handleAdDateChange = (newAd: string, type: 'prod' | 'mfg' | 'exp') => {
    if (type === 'prod') {
      setProductionDateAd(newAd);
      try {
        setProductionDateBs(formatBsDate(adToBs(new Date(newAd))));
      } catch {
        // fallback
      }
    } else if (type === 'mfg') {
      setMfgDateAd(newAd);
      try {
        setMfgDateBs(formatBsDate(adToBs(new Date(newAd))));
      } catch {
        // fallback
      }
    } else if (type === 'exp') {
      setExpDateAd(newAd);
      try {
        setExpDateBs(formatBsDate(adToBs(new Date(newAd))));
      } catch {
        // fallback
      }
    }
  };

  // सूत्र (BOM) छानेपछि सबै विवरण स्वतः भर्ने — qty = बनाउने परिमाण
  const applyBom = (id: string, qty?: number) => {
    setBomId(id);
    const bom = boms.find((b) => b.id === id);
    if (!bom) {
      setQcChecks([]);
      return;
    }
    const outQty = qty && qty > 0 ? qty : bom.outputQty;
    const scale = bom.outputQty > 0 ? outQty / bom.outputQty : 1;
    if (bom.productItemId) setSelectedItemId(bom.productItemId);
    setProductNameNe(bom.productNameNe);
    setProductNameEn(bom.productNameEn || bom.productNameNe);
    setOutputQuantity(outQty);
    setOutputUnit(bom.outputUnit);
    const reqs = bomRequirements(bom, outQty, rawMaterials);
    setRmRows(
      reqs.map((r, idx) => ({
        rowId: `row-${Date.now()}-${idx}`,
        materialId: r.materialId,
        materialName: r.name,
        quantity: r.required,
        unit: r.unit,
        rate: r.unitCost,
        availableStock: r.stock
      }))
    );
    setLaborCost(Math.round((bom.laborCostPerBatch || 0) * scale));
    setElectricityCost(Math.round((bom.electricityCostPerBatch || 0) * scale));
    setOtherOverheadCost(Math.round((bom.otherCostPerBatch || 0) * scale));
    if (bom.packetSize) setPacketSize(bom.packetSize);
    if (bom.packagingType) setPackagingType(bom.packagingType);
    if (bom.machineName) setMachineName(bom.machineName);
    if (bom.standardHoursPerBatch) setMachineHours(Math.round(bom.standardHoursPerBatch * scale * 100) / 100);
    setQcChecks((bom.qcChecklist || []).map((name) => ({ name, result: 'NA' as const })));
    if (bom.shelfLifeDays && bom.shelfLifeDays > 0) {
      try {
        const d = new Date();
        d.setDate(d.getDate() + bom.shelfLifeDays);
        setExpDateAd(d.toISOString().slice(0, 10));
        setExpDateBs(formatBsDate(adToBs(d)));
      } catch {
        // ignore
      }
    }
  };

  const updateQc = (idx: number, patch: Partial<QcCheckResult>) =>
    setQcChecks((prev) => prev.map((c, i) => (i === idx ? { ...c, ...patch } : c)));

  // Output item picker
  const handleSelectItem = (itemId: string) => {
    setSelectedItemId(itemId);
    if (!itemId) return;
    const it = items.find((i) => i.id === itemId);
    if (it) {
      setProductNameNe(it.nameNe);
      setProductNameEn(it.nameEn);
      setOutputUnit(it.unit || 'Kg');
    }
  };

  // Add Raw Material Row
  const handleAddRmRow = () => {
    const unselected = rawMaterials.find((r) => !rmRows.some((row) => row.materialId === r.id)) || rawMaterials[0];
    if (!unselected) return;

    setRmRows((prev) => [
      ...prev,
      {
        rowId: `row-${Date.now()}-${Math.random()}`,
        materialId: unselected.id,
        materialName: unselected.nameNe,
        quantity: 10,
        unit: unselected.unit || 'Kg',
        rate: unselected.unitCostPrice || 100,
        availableStock: unselected.currentStock
      }
    ]);
  };

  // Update RM Row
  const handleUpdateRmRow = (rowId: string, updates: Partial<RawMaterialRow>) => {
    setRmRows((prev) =>
      prev.map((r) => {
        if (r.rowId !== rowId) return r;
        const updated = { ...r, ...updates };
        if (updates.materialId) {
          const mat = rawMaterials.find((m) => m.id === updates.materialId);
          if (mat) {
            updated.materialName = mat.nameNe;
            updated.unit = mat.unit || 'Kg';
            updated.rate = mat.unitCostPrice || 0;
            updated.availableStock = mat.currentStock;
          }
        }
        return updated;
      })
    );
  };

  // Remove RM Row
  const handleRemoveRmRow = (rowId: string) => {
    setRmRows((prev) => prev.filter((r) => r.rowId !== rowId));
  };

  // Calculations
  const autoInputWeight = rmRows.reduce((sum, r) => sum + (Number(r.quantity) || 0), 0);
  const totalInputQty = manualInputQty !== '' ? Number(manualInputQty) : autoInputWeight;
  const rawMaterialTotalCost = rmRows.reduce(
    (sum, r) => sum + (Number(r.quantity) || 0) * (Number(r.rate) || 0),
    0
  );

  const effectiveOutputQty = Number(outputQuantity) || 0;
  const yieldPercent = totalInputQty > 0
    ? Math.min(100, Math.round((effectiveOutputQty / totalInputQty) * 1000) / 10)
    : 100;
  const wastagePercent = totalInputQty > 0
    ? Math.max(0, Math.round((100 - yieldPercent) * 10) / 10)
    : 0;

  const totalOverheadCost = Number(laborCost || 0) + Number(electricityCost || 0) + Number(otherOverheadCost || 0);
  const totalBatchCost = rawMaterialTotalCost + totalOverheadCost;
  const costPerUnit = effectiveOutputQty > 0 ? Math.round((totalBatchCost / effectiveOutputQty) * 100) / 100 : 0;
  const effectivePackets = Number(packetsProduced) || (effectiveOutputQty > 0 ? effectiveOutputQty * 2 : 0);
  const costPerPacket = effectivePackets > 0 ? Math.round((totalBatchCost / effectivePackets) * 100) / 100 : 0;

  // Stock deficit check
  const stockDeficits = rmRows.filter((r) => r.quantity > r.availableStock);

  // Form Submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productNameNe.trim()) {
      alert(isNe ? 'कृपया उत्पादन हुने वस्तुको नाम लेख्नुहोस्।' : 'Please enter product name.');
      return;
    }
    if (rmRows.length === 0) {
      alert(isNe ? 'कम्तीमा एउटा कच्चा पदार्थ छान्नुहोस्।' : 'Please add at least one raw material.');
      return;
    }

    const usages: RawMaterialUsage[] = rmRows.map((r) => ({
      materialId: r.materialId,
      materialName: r.materialName,
      quantityUsed: Number(r.quantity) || 0,
      unit: r.unit,
      costPerUnit: Number(r.rate) || 0,
      totalCost: (Number(r.quantity) || 0) * (Number(r.rate) || 0)
    }));

    const newBatch: ProductionBatch = {
      id: `batch-${Date.now()}`,
      batchNumber: batchNo.trim(),
      productNameNe: productNameNe.trim(),
      productNameEn: productNameEn.trim() || productNameNe.trim(),
      stage: targetStage,
      targetQuantity: effectiveOutputQty,
      finishedItemId: selectedItemId || undefined,
      
      // Dates
      productionDateBs,
      productionDateAd,
      manufactureDateBs: mfgDateBs,
      manufactureDateAd: mfgDateAd,
      expiryDateBs: expDateBs,
      expiryDateAd: expDateAd,
      startedDateBs: productionDateBs,
      startedDateAd: productionDateAd,
      completionDateBs: targetStage === 'FINISHED_GOODS' ? productionDateBs : undefined,
      completionDateAd: targetStage === 'FINISHED_GOODS' ? productionDateAd : undefined,

      // Quantities
      inputQuantity: totalInputQty,
      inputUnit,
      outputQuantity: effectiveOutputQty,
      outputUnit,
      finishedGoodsQuantity: targetStage === 'FINISHED_GOODS' ? effectiveOutputQty : undefined,
      yieldPercent,
      wastagePercent,

      // Costs
      rawMaterialCost: rawMaterialTotalCost,
      laborCost: Number(laborCost) || 0,
      electricityCost: Number(electricityCost) || 0,
      otherOverheadCost: Number(otherOverheadCost) || 0,
      totalProductionCost: totalBatchCost,
      unitManufacturingCost: costPerUnit,
      costPerPacket,

      // Packaging
      packetSize,
      packetsProduced: effectivePackets,
      packagingType,

      // Quality & Machine
      qualityCheckStatus,
      qualityNotes,
      qualityCheckedBy,
      machineName,
      operatorName,

      rawMaterialsUsed: usages,
      notes,
      status: 'ACTIVE',

      // थप विवरण
      bomId: bomId || undefined,
      shift,
      supervisorName: supervisorName.trim() || undefined,
      machineHours: machineHours === '' ? undefined : Number(machineHours),
      scrapQuantity: scrapQuantity === '' ? undefined : Number(scrapQuantity),
      scrapReason: scrapReason.trim() || undefined,
      storageLocation: storageLocation.trim() || undefined,
      qcChecks: qcChecks.filter((c) => c.name.trim())
    };

    onSuccess(newBatch);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black flex items-center gap-2">
                <span>{isNe ? 'उत्पादन ब्याच प्रविष्टि (Production Batch Entry)' : 'New Production Batch Entry'}</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                {isNe
                  ? 'कच्चा पदार्थ अनुपात (BOM), स्वतः तौल ह्रास (Wastage / Yield), ज्याला, बिजुली र प्रति एकाइ लागत हिसाब'
                  : 'Multi-raw material BOM, auto yield/wastage calculation, overhead allocation & unit cost'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5 text-xs overflow-y-auto flex-1 bg-slate-50/50">
          
          {/* Top Row: Batch Number & Dual Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-bold text-slate-700">ब्याच नं. (Batch No):*</label>
                <button
                  type="button"
                  onClick={() => setIsManualBatchNo(!isManualBatchNo)}
                  className="text-[10px] text-purple-700 hover:underline font-bold"
                >
                  {isManualBatchNo ? 'स्वतः सिर्जना' : 'म्यानुअल परिवर्तन'}
                </button>
              </div>
              <input
                type="text"
                required
                value={batchNo}
                readOnly={!isManualBatchNo}
                onChange={(e) => setBatchNo(e.target.value)}
                className={`w-full px-3 py-2 border rounded-xl font-mono font-bold text-slate-900 ${
                  isManualBatchNo ? 'border-purple-400 bg-white' : 'border-slate-200 bg-slate-50'
                }`}
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                <span>उत्पादन मिति (नेपाली B.S.):*</span>
              </label>
              <input
                type="text"
                required
                value={productionDateBs}
                onChange={(e) => handleBsDateChange(e.target.value, 'prod')}
                placeholder="YYYY-MM-DD (2081-11-02)"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold bg-white"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
                <span>Production Date (English A.D.):*</span>
              </label>
              <input
                type="date"
                required
                value={productionDateAd}
                onChange={(e) => handleAdDateChange(e.target.value, 'prod')}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono bg-white"
              />
            </div>
          </div>

          {/* Section 1: Output Finished Product Selection */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Package className="w-4 h-4 text-purple-600" />
              <span>१. उत्पादन हुने वस्तु (Output Finished Product)</span>
            </h4>

            {boms.filter((b) => b.isActive).length > 0 && (
              <div className="p-3 bg-purple-50 border border-purple-200 rounded-xl flex flex-col sm:flex-row sm:items-end gap-2">
                <div className="flex-1">
                  <label className="block font-bold text-purple-900 mb-1">उत्पादन सूत्र (BOM / Recipe) छान्नुहोस् — कच्चा पदार्थ, लागत र QC स्वतः भरिन्छ:</label>
                  <select
                    value={bomId}
                    onChange={(e) => applyBom(e.target.value)}
                    className="w-full px-3 py-2 border border-purple-300 rounded-xl font-medium bg-white"
                  >
                    <option value="">-- सूत्र बिना म्यानुअल भर्ने --</option>
                    {boms.filter((b) => b.isActive).map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.code} · {b.productNameNe} ({b.outputQty} {b.outputUnit})
                      </option>
                    ))}
                  </select>
                </div>
                {bomId && (
                  <button
                    type="button"
                    onClick={() => applyBom(bomId, Number(outputQuantity) || undefined)}
                    className="px-3 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold text-xs cursor-pointer"
                  >
                    ↻ तलको उत्पादन परिमाण अनुसार पुनः गणना
                  </button>
                )}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-1">
                <label className="block font-bold text-slate-700 mb-1">तयारी सामान क्याटलगबाट छनोट:</label>
                <select
                  value={selectedItemId}
                  onChange={(e) => handleSelectItem(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-medium bg-white"
                >
                  <option value="">-- नयाँ वा अन्य सामान लेख्नुहोस् --</option>
                  {items.map((it) => (
                    <option key={it.id} value={it.id}>
                      {it.nameNe} ({it.unit}) · मौज्दात: {it.currentStock}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">उत्पादन नाम (नेपालीमा):*</label>
                <input
                  type="text"
                  required
                  value={productNameNe}
                  onChange={(e) => setProductNameNe(e.target.value)}
                  placeholder="उदा: सुकेको खुर्सानी धुलो (Chili Powder 500g)"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Product Name (English):</label>
                <input
                  type="text"
                  value={productNameEn}
                  onChange={(e) => setProductNameEn(e.target.value)}
                  placeholder="e.g. Pure Ground Chili Powder 500g Pack"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Multi Raw Material Input (BOM / Recipe) */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
              <div>
                <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <Boxes className="w-4 h-4 text-emerald-600" />
                  <span>२. कच्चा पदार्थ इनपुट (Raw Materials Input / BOM)</span>
                </h4>
                <p className="text-[11px] text-slate-500">
                  एउटै ब्याचमा प्रयोग हुने बहु-कच्चा पदार्थहरू (उदा: खुर्सानी + प्याज + अदुवा + पाउच) थप्नुहोस्
                </p>
              </div>
              <button
                type="button"
                onClick={handleAddRmRow}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer self-start sm:self-auto shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ कच्चा पदार्थ थप्नुहोस् (+ Add RM)</span>
              </button>
            </div>

            {stockDeficits.length > 0 && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 flex items-center gap-2 text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>
                  <b>सचेत:</b> {stockDeficits.map((d) => `${d.materialName} (माग: ${d.quantity}, मौज्दात: ${d.availableStock})`).join(', ')} मा मौज्दात अपुग छ!
                </span>
              </div>
            )}

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-2 px-3">कच्चा पदार्थको नाम</th>
                    <th className="py-2 px-3 text-right">मौज्दात स्टक</th>
                    <th className="py-2 px-3 text-right">प्रयोग हुने परिमाण</th>
                    <th className="py-2 px-3">इकाइ</th>
                    <th className="py-2 px-3 text-right">प्रति एकाइ दर (Rs)</th>
                    <th className="py-2 px-3 text-right">कुल लागत (Rs)</th>
                    <th className="py-2 px-2 text-center">हटाउने</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {rmRows.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-6 text-center text-slate-400">
                        कुनै कच्चा पदार्थ थपिएको छैन। माथिको बटन थिचेर थप्नुहोस्।
                      </td>
                    </tr>
                  ) : (
                    rmRows.map((row) => {
                      const lineTotal = (Number(row.quantity) || 0) * (Number(row.rate) || 0);
                      const isLow = row.quantity > row.availableStock;
                      return (
                        <tr key={row.rowId} className={isLow ? 'bg-red-50/50' : 'hover:bg-slate-50'}>
                          <td className="py-2 px-3 min-w-[200px]">
                            <select
                              value={row.materialId}
                              onChange={(e) => handleUpdateRmRow(row.rowId, { materialId: e.target.value })}
                              className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-bold bg-white"
                            >
                              {rawMaterials.map((rm) => (
                                <option key={rm.id} value={rm.id}>
                                  {rm.nameNe} · {rm.currentStock} {rm.unit} (रु. {rm.unitCostPrice})
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-slate-600">
                            {row.availableStock} {row.unit}
                          </td>
                          <td className="py-2 px-3 text-right w-28">
                            <input
                              type="number"
                              min={0.01}
                              step="any"
                              value={row.quantity}
                              onChange={(e) =>
                                handleUpdateRmRow(row.rowId, { quantity: parseFloat(e.target.value) || 0 })
                              }
                              className={`w-24 px-2 py-1.5 border rounded-lg font-mono font-bold text-right ${
                                isLow ? 'border-red-400 bg-red-50 text-red-900' : 'border-slate-300 bg-white'
                              }`}
                            />
                          </td>
                          <td className="py-2 px-3 font-mono font-bold text-slate-500">{row.unit}</td>
                          <td className="py-2 px-3 text-right w-28">
                            <input
                              type="number"
                              min={0}
                              step="any"
                              value={row.rate}
                              onChange={(e) =>
                                handleUpdateRmRow(row.rowId, { rate: parseFloat(e.target.value) || 0 })
                              }
                              className="w-24 px-2 py-1.5 border border-slate-300 rounded-lg font-mono text-right"
                            />
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-black text-emerald-800">
                            रु. {lineTotal.toLocaleString()}
                          </td>
                          <td className="py-2 px-2 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveRmRow(row.rowId)}
                              className="p-1 text-slate-400 hover:text-red-600 rounded transition cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
                <tfoot className="bg-slate-900 text-white font-bold">
                  <tr>
                    <td colSpan={2} className="py-2.5 px-3">
                      कुल कच्चा पदार्थ इनपुट (Total Raw Materials):
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-amber-300 font-black">
                      {autoInputWeight.toLocaleString()} {inputUnit}
                    </td>
                    <td colSpan={2} className="py-2.5 px-3 text-right">
                      कुल कच्चा पदार्थ खर्च:
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-emerald-300 font-black">
                      रु. {rawMaterialTotalCost.toLocaleString()}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Section 3: Output Quantity, Yield % and Wastage % */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Scale className="w-4 h-4 text-blue-600" />
              <span>३. उत्पादन परिमाण, तौल ह्रास (Wastage) तथा प्राप्ति (Yield %)</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">कुल इनपुट तौल (Input Weight):</label>
                <div className="flex gap-1.5">
                  <input
                    type="number"
                    step="any"
                    value={totalInputQty}
                    onChange={(e) => setManualInputQty(parseFloat(e.target.value) || 0)}
                    placeholder="Auto"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold"
                  />
                  <select
                    value={inputUnit}
                    onChange={(e) => setInputUnit(e.target.value)}
                    className="px-2 border border-slate-300 rounded-xl font-bold bg-white"
                  >
                    <option value="Kg">Kg</option>
                    <option value="Quintal">क्विन्टल</option>
                    <option value="Gm">Gm</option>
                    <option value="Pc">थान</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">तयारी उत्पादन परिमाण (Output):*</label>
                <div className="flex gap-1.5">
                  <input
                    type="number"
                    required
                    min={0.1}
                    step="any"
                    value={outputQuantity}
                    onChange={(e) => setOutputQuantity(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-blue-900 text-sm"
                  />
                  <select
                    value={outputUnit}
                    onChange={(e) => setOutputUnit(e.target.value)}
                    className="px-2 border border-slate-300 rounded-xl font-bold bg-white"
                  >
                    <option value="Kg">Kg</option>
                    <option value="Packet">प्याकेट</option>
                    <option value="Pc">थान</option>
                    <option value="Set">सेट</option>
                  </select>
                </div>
              </div>

              {/* Yield Badge */}
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex flex-col justify-center">
                <span className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider">
                  उत्पादन प्राप्ति (Yield %):
                </span>
                <span className="text-xl font-black font-mono text-emerald-900 mt-0.5">
                  {toNepaliDigits(yieldPercent)}%
                </span>
                <span className="text-[9px] text-emerald-600">
                  (तयारी वस्तु ÷ कुल कच्चा इनपुट)
                </span>
              </div>

              {/* Wastage / Moisture Loss Badge */}
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex flex-col justify-center">
                <span className="text-[10px] text-amber-800 font-bold uppercase tracking-wider">
                  तौल ह्रास / वेस्टेज (Wastage %):
                </span>
                <span className="text-xl font-black font-mono text-amber-900 mt-0.5">
                  {toNepaliDigits(wastagePercent)}%
                </span>
                <span className="text-[9px] text-amber-700">
                  सुकेको / धुलो / मोइस्चर लस (Weight Loss)
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Overhead Costs (Labor, Electricity, Packaging) */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-600" />
              <span>४. अप्रत्यक्ष खर्च (Labor & Overhead Costs)</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">ज्याला खर्च (Labor Cost - Rs):</label>
                <input
                  type="number"
                  min={0}
                  value={laborCost}
                  onChange={(e) => setLaborCost(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">विजुली / इन्धन खर्च (Electricity - Rs):</label>
                <input
                  type="number"
                  min={0}
                  value={electricityCost}
                  onChange={(e) => setElectricityCost(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">अन्य अप्रत्यक्ष खर्च (Other Overhead - Rs):</label>
                <input
                  type="number"
                  min={0}
                  value={otherOverheadCost}
                  onChange={(e) => setOtherOverheadCost(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold"
                />
              </div>
            </div>

            {/* Packaging Details */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-100">
              <div>
                <label className="block font-bold text-slate-700 mb-1">प्याकेट साइज (Packet Size):</label>
                <input
                  type="text"
                  value={packetSize}
                  onChange={(e) => setPacketSize(e.target.value)}
                  placeholder="उदा: 100g, 250g, 500g, 1kg"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">उत्पादित प्याकेट सङ्ख्या (Packets):</label>
                <input
                  type="number"
                  min={1}
                  value={packetsProduced}
                  onChange={(e) => setPacketsProduced(parseInt(e.target.value) || 1)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">प्याकेजिङ प्रकार (Packaging Type):</label>
                <input
                  type="text"
                  value={packagingType}
                  onChange={(e) => setPackagingType(e.target.value)}
                  placeholder="उदा: सिल्भर जिपर स्ट्यान्डअप पाउच"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>
          </div>

          {/* Section 5: Expiry & Quality Tracking (Food Safety) */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>५. खाद्य सुरक्षा, म्याद तथा गुणस्तर (Expiry & Quality Tracking)</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">उत्पादन मिति (Mfg Date BS):</label>
                <input
                  type="text"
                  value={mfgDateBs}
                  onChange={(e) => handleBsDateChange(e.target.value, 'mfg')}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">म्याद सकिने मिति (Exp Date BS):</label>
                <input
                  type="text"
                  value={expDateBs}
                  onChange={(e) => handleBsDateChange(e.target.value, 'exp')}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-amber-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">गुणस्तर जाँच स्थिति (QC Status):</label>
                <select
                  value={qualityCheckStatus}
                  onChange={(e) => setQualityCheckStatus(e.target.value as any)}
                  className={`w-full px-3 py-2 border rounded-xl font-bold ${
                    qualityCheckStatus === 'PASS'
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-900'
                      : qualityCheckStatus === 'PENDING'
                      ? 'border-amber-500 bg-amber-50 text-amber-900'
                      : 'border-red-500 bg-red-50 text-red-900'
                  }`}
                >
                  <option value="PASS">✓ पास (Passed - सुरक्षित)</option>
                  <option value="PENDING">⏳ परीक्षण बाँकी (Pending Lab)</option>
                  <option value="FAIL">✕ फेल (Failed - अस्वीकृत)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">गुणस्तर निरीक्षक (Inspector):</label>
                <input
                  type="text"
                  value={qualityCheckedBy}
                  onChange={(e) => setQualityCheckedBy(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">गुणस्तर परीक्षण टिप्पणी (QC Notes):</label>
              <input
                type="text"
                value={qualityNotes}
                onChange={(e) => setQualityNotes(e.target.value)}
                placeholder="उदा: मोइस्चर १०% भन्दा कम, रङ्ग र गन्ध राम्रो"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl"
              />
            </div>
          </div>

          {/* Section 6: Machine, Operator & Stage Action */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">प्रयोग भएको मेसिन:</label>
              <input
                type="text"
                value={machineName}
                onChange={(e) => setMachineName(e.target.value)}
                placeholder="उदा: पल्भराइजर / ग्राइन्डिङ मिल"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">अपरेटर / प्राविधिकको नाम:</label>
              <input
                type="text"
                value={operatorName}
                onChange={(e) => setOperatorName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">ब्याचको चरण (Stage Action):*</label>
              <select
                value={targetStage}
                onChange={(e) => setTargetStage(e.target.value as any)}
                className="w-full px-3 py-2 border border-purple-500 rounded-xl font-bold bg-purple-50 text-purple-900"
              >
                <option value="FINISHED_GOODS">
                  ✓ सिधै तयारी सामान (Finished Goods & Sync Stock)
                </option>
                <option value="IN_MACHINE_WIP">
                  ⚙️ मेसिनमा लोड (Save as Active WIP)
                </option>
              </select>
            </div>
          </div>

          {/* Section 7: थप उत्पादन विवरण */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>७. शिफ्ट, स्क्र्याप तथा गुणस्तर जाँच सूची (थप विवरण)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">शिफ्ट:</label>
                <select value={shift} onChange={(e) => setShift(e.target.value as any)} className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white">
                  <option value="MORNING">बिहानको</option>
                  <option value="DAY">दिउँसोको</option>
                  <option value="EVENING">साँझको</option>
                  <option value="NIGHT">रातको</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">सुपरभाइजर:</label>
                <input type="text" value={supervisorName} onChange={(e) => setSupervisorName(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-xl" />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">मेसिन चलेको घण्टा:</label>
                <input type="number" min={0} step="0.25" value={machineHours} onChange={(e) => setMachineHours(e.target.value === '' ? '' : Number(e.target.value))} className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono" />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">तयारी सामान राख्ने स्थान:</label>
                <input type="text" value={storageLocation} onChange={(e) => setStorageLocation(e.target.value)} placeholder="गोदाम / र्‍याक" className="w-full px-3 py-2 border border-slate-300 rounded-xl" />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">स्क्र्याप / खेर गएको परिमाण:</label>
                <input type="number" min={0} value={scrapQuantity} onChange={(e) => setScrapQuantity(e.target.value === '' ? '' : Number(e.target.value))} className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono" />
              </div>
              <div className="sm:col-span-3">
                <label className="block font-bold text-slate-700 mb-1">स्क्र्याप हुनुको कारण:</label>
                <input type="text" value={scrapReason} onChange={(e) => setScrapReason(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-xl" />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-bold text-slate-700">गुणस्तर जाँच सूची (QC Checklist):</label>
                <button
                  type="button"
                  onClick={() => setQcChecks((p) => [...p, { name: '', result: 'NA' }])}
                  className="text-[11px] text-indigo-700 font-bold hover:underline cursor-pointer"
                >
                  + बुँदा थप्नुहोस्
                </button>
              </div>
              {qcChecks.length === 0 && <p className="text-[11px] text-slate-500">सूत्र (BOM) मा QC बुँदा राखेमा यहाँ स्वतः आउँछ, वा आफैँ थप्नुहोस्।</p>}
              <div className="space-y-1.5">
                {qcChecks.map((c, i) => (
                  <div key={i} className="grid grid-cols-12 gap-1.5 items-center">
                    <input type="text" value={c.name} onChange={(e) => updateQc(i, { name: e.target.value })} placeholder="जाँच बुँदा" className="col-span-5 px-2 py-1.5 border border-slate-300 rounded-lg" />
                    <input type="text" value={c.value || ''} onChange={(e) => updateQc(i, { value: e.target.value })} placeholder="नापेको मान" className="col-span-3 px-2 py-1.5 border border-slate-300 rounded-lg" />
                    <select value={c.result} onChange={(e) => updateQc(i, { result: e.target.value as any })} className={`col-span-3 px-2 py-1.5 border rounded-lg font-bold ${c.result === 'PASS' ? 'bg-emerald-50 border-emerald-400 text-emerald-900' : c.result === 'FAIL' ? 'bg-red-50 border-red-400 text-red-900' : 'bg-white border-slate-300'}`}>
                      <option value="NA">लागू छैन</option>
                      <option value="PASS">✓ पास</option>
                      <option value="FAIL">✕ फेल</option>
                    </select>
                    <button type="button" onClick={() => setQcChecks((p) => p.filter((_, x) => x !== i))} className="col-span-1 text-rose-600 cursor-pointer">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Live Cost Summary Banner (Auto-calculate per unit cost) */}
          <div className="p-4 bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl shadow-md border border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs text-amber-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>प्रति एकाइ उत्पादन लागत (Auto Production Cost Analysis)</span>
                </span>
                <div className="text-xs text-slate-300 mt-1">
                  (कच्चा पदार्थ: रु. {rawMaterialTotalCost.toLocaleString()} + ज्याला: रु. {laborCost.toLocaleString()} + बिजुली/ओभरहेड: रु. {Number(electricityCost + otherOverheadCost).toLocaleString()}) ÷ {effectiveOutputQty} {outputUnit}
                </div>
              </div>

              <div className="flex items-center gap-4 text-right">
                <div className="border-r border-slate-700 pr-4">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">कुल ब्याच लागत</div>
                  <div className="text-lg font-black font-mono text-emerald-400">
                    रु. {totalBatchCost.toLocaleString()}
                  </div>
                </div>

                <div className="border-r border-slate-700 pr-4">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">प्रति {outputUnit} लागत</div>
                  <div className="text-xl font-black font-mono text-amber-300">
                    रु. {costPerUnit.toLocaleString()}
                  </div>
                </div>

                {effectivePackets > 0 && (
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-bold">प्रति प्याकेट ({packetSize})</div>
                    <div className="text-xl font-black font-mono text-purple-300">
                      रु. {costPerPacket.toLocaleString()}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Bottom Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-200">
            <div className="text-[11px] text-slate-500">
              * ब्याच सुरक्षित गर्दा प्रयोग भएको कच्चा पदार्थ गोदामबाट <b>स्वतः घट्नेछ</b>।
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-slate-600 hover:bg-slate-200 rounded-xl font-bold cursor-pointer transition"
              >
                रद्द (Cancel)
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md cursor-pointer transition flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {targetStage === 'FINISHED_GOODS'
                    ? 'तयारी सामान दाखिला तथा स्टक अपडेट (Save & Sync Stock)'
                    : 'मेसिनमा लोड गरी सुरु गर्नुहोस् (Start WIP)'}
                </span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
