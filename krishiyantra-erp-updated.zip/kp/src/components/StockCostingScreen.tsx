import React, { useEffect, useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { loadStoredData, saveStoredData } from '../utils/storage';
import { computeReorder, computeStockCosting, type CostMethod, type ReorderRow } from '../utils/stockCosting';
import { downloadCsv, fmtMoney, fyRange, normBs } from '../utils/accountingEngine';

const inputCls = 'border border-slate-300 rounded-lg px-2 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/40 w-full';
const btnGhost = 'px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold cursor-pointer';
const th = 'py-2 px-2.5 text-left font-bold text-slate-700';
const tdc = 'py-1.5 px-2.5';
const num = 'font-mono tabular-nums text-right';

interface Settings { method: CostMethod; lookbackDays: number; leadTimeDays: number; coverDays: number }
const DEFAULTS: Settings = { method: 'FIFO', lookbackDays: 30, leadTimeDays: 7, coverDays: 15 };

const methodNames: Record<CostMethod, { ne: string; en: string; hint: string }> = {
  FIFO: { ne: 'FIFO (पहिले आएको पहिले बिक्री)', en: 'FIFO (first in, first out)', hint: 'Oldest cost is sold first; closing stock holds the latest costs.' },
  LIFO: { ne: 'LIFO (पछि आएको पहिले बिक्री)', en: 'LIFO (last in, first out)', hint: 'Newest cost is sold first; closing stock holds the oldest costs.' },
  AVG: { ne: 'औसत लागत (Weighted Average)', en: 'Weighted Average', hint: 'Every purchase is blended into one moving average cost.' }
};

const statusStyle: Record<string, { ne: string; en: string; cls: string }> = {
  OUT: { ne: 'सकियो', en: 'Out of stock', cls: 'bg-rose-100 text-rose-800' },
  BELOW_MIN: { ne: 'न्यूनतम मुनि', en: 'Below minimum', cls: 'bg-orange-100 text-orange-800' },
  REORDER: { ne: 'अर्डर गर्ने समय', en: 'Reorder now', cls: 'bg-amber-100 text-amber-800' },
  OK: { ne: 'ठीक छ', en: 'OK', cls: 'bg-emerald-100 text-emerald-800' }
};

export const StockCostingScreen: React.FC = () => {
  const { language, company, items, allInvoices, allPurchases, rawMaterials, activeCompanyId } = useApp();
  const isNe = language === 'ne';
  const key = !activeCompanyId || activeCompanyId === 'comp-default' ? 'krishiyantra_stock_costing_v1' : `krishiyantra_stock_costing_v1__${activeCompanyId}`;

  const [st, setSt] = useState<{ key: string; s: Settings }>(() => ({ key, s: { ...DEFAULTS, ...(loadStoredData<Partial<Settings>>(key, {}) || {}) } }));
  let cur = st;
  if (st.key !== key) {
    cur = { key, s: { ...DEFAULTS, ...(loadStoredData<Partial<Settings>>(key, {}) || {}) } };
    setSt(cur);
  }
  const s = cur.s;
  useEffect(() => { saveStoredData(st.key, st.s); }, [st]);
  const setS = (patch: Partial<Settings>) => setSt((p) => ({ ...p, s: { ...p.s, ...patch } }));

  const [tab, setTab] = useState<'VALUATION' | 'REORDER'>('REORDER');
  const [fy, setFy] = useState(company.fiscalYear || '082/83');
  const [q, setQ] = useState('');
  const [open, setOpen] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);
  const [copied, setCopied] = useState('');

  const period = useMemo(() => fyRange(fy), [fy]);
  const fyOptions = useMemo(
    () => Array.from(new Set([company.fiscalYear, ...(company.fiscalYearsList || []), ...(company.closedFiscalYears || []), fy].filter(Boolean))).sort(),
    [company.fiscalYear, company.fiscalYearsList, company.closedFiscalYears, fy]
  );

  const fifo = useMemo(() => computeStockCosting(items, allPurchases, allInvoices, 'FIFO', period), [items, allPurchases, allInvoices, period]);
  const lifo = useMemo(() => computeStockCosting(items, allPurchases, allInvoices, 'LIFO', period), [items, allPurchases, allInvoices, period]);
  const avg = useMemo(() => computeStockCosting(items, allPurchases, allInvoices, 'AVG', period), [items, allPurchases, allInvoices, period]);
  const sel = s.method === 'FIFO' ? fifo : s.method === 'LIFO' ? lifo : avg;

  const reorder = useMemo(
    () => computeReorder(items, rawMaterials || [], allPurchases, allInvoices, s),
    [items, rawMaterials, allPurchases, allInvoices, s.lookbackDays, s.leadTimeDays, s.coverDays]
  );
  const needs = reorder.filter((r) => r.status !== 'OK');
  const shown = (showAll ? reorder : needs).filter((r) => !q || `${r.code} ${r.name}`.toLowerCase().includes(q.toLowerCase()));

  const bySupplier = useMemo(() => {
    const m = new Map<string, ReorderRow[]>();
    needs.filter((r) => r.suggestQty > 0).forEach((r) => {
      const k = r.supplier || (isNe ? 'आपूर्तिकर्ता तोकिएको छैन' : 'Supplier not set');
      m.set(k, [...(m.get(k) || []), r]);
    });
    return Array.from(m.entries());
  }, [needs, isNe]);

  const orderText = (sup: string, rows: ReorderRow[]) =>
    [`${isNe ? 'खरिद अर्डर' : 'Purchase order'} — ${company.nameNe || company.nameEn || ''}`, `${isNe ? 'आपूर्तिकर्ता' : 'Supplier'}: ${sup}`, '',
      ...rows.map((r, i) => `${i + 1}. ${r.name} (${r.code}) — ${r.suggestQty} ${r.unit}`), '',
      `${isNe ? 'अनुमानित रकम' : 'Estimated'}: Rs. ${fmtMoney(rows.reduce((t, r) => t + r.estCost, 0))}`].join('\n');

  const copy = async (sup: string, rows: ReorderRow[]) => {
    try { await navigator.clipboard.writeText(orderText(sup, rows)); setCopied(sup); setTimeout(() => setCopied(''), 2000); }
    catch { window.prompt(isNe ? 'कपी गर्नुहोस्' : 'Copy this', orderText(sup, rows)); }
  };

  const valRows = sel.rows
    .map((r, i) => ({ r, f: fifo.rows[i], l: lifo.rows[i], a: avg.rows[i] }))
    .filter(({ r }) => (r.onHand > 0 || r.qtySold > 0) && (!q || `${r.item.code} ${r.item.nameEn} ${r.item.nameNe}`.toLowerCase().includes(q.toLowerCase())));

  const exportVal = () => downloadCsv(`stock-valuation-${s.method}.csv`, [
    ['Code', 'Item', 'Unit', 'On hand', 'FIFO value', 'LIFO value', 'Average value', `${s.method} avg cost`, `COGS ${fy} (${s.method})`],
    ...valRows.map(({ r, f, l, a }) => [r.item.code, r.item.nameEn, r.item.primaryUnit || r.item.unit, r.onHand, f.value, l.value, a.value, r.avgCost, r.cogs])
  ]);
  const exportReorder = () => downloadCsv('reorder-suggestions.csv', [
    ['Type', 'Code', 'Item', 'Unit', 'Current', 'Minimum', 'Avg daily sales', 'Days of cover', 'Reorder point', 'Suggested qty', 'Supplier', 'Last rate', 'Est. cost', 'Status'],
    ...reorder.filter((r) => r.status !== 'OK').map((r) => [r.kind, r.code, r.name, r.unit, r.current, r.minLevel, r.avgDaily, r.daysCover ?? '', r.reorderPoint, r.suggestQty, r.supplier, r.lastRate, r.estCost, r.status])
  ]);

  const gp = (rev: number, cogs: number) => round(rev - cogs);
  const round = (n: number) => Math.round(n * 100) / 100;

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
        <div>
          <h2 className="text-base font-extrabold text-slate-900">{isNe ? '📊 स्टक मूल्याङ्कन तथा पुनःक्रम (Reorder)' : '📊 Stock Valuation & Reorder'}</h2>
          <p className="text-[11px] text-slate-500">
            {isNe ? 'खरिद र बिक्री बिलबाट FIFO / LIFO / औसत लागत स्वतः निकालिन्छ, र स्टक सकिन लागेकोमा कति अर्डर गर्ने सुझाव दिन्छ।'
                  : 'FIFO / LIFO / Average cost is worked out from your purchase and sales bills, and low stock gets an order suggestion.'}
          </p>
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {([['REORDER', isNe ? '🛒 खरिद सुझाव (Reorder)' : '🛒 Reorder Suggestions'], ['VALUATION', isNe ? '💰 स्टक मूल्याङ्कन' : '💰 Stock Valuation']] as const).map(([id, label]) => (
            <button key={id} type="button" onClick={() => setTab(id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${tab === id ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}>{label}</button>
          ))}
          {needs.length > 0 && <span className="ml-1 self-center text-[11px] font-bold text-rose-700">{needs.length} {isNe ? 'सामानमा ध्यान दिनुपर्ने' : 'items need attention'}</span>}
        </div>
      </div>

      {tab === 'REORDER' && (
        <>
          <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 items-end">
              <label><span className="block text-[10px] font-bold text-slate-600 mb-0.5">{isNe ? 'बिक्री इतिहास (दिन)' : 'Sales history (days)'}</span>
                <select className={inputCls} value={s.lookbackDays} onChange={(e) => setS({ lookbackDays: parseInt(e.target.value, 10) })}>{[15, 30, 60, 90, 180].map((d) => <option key={d} value={d}>{d}</option>)}</select></label>
              <label><span className="block text-[10px] font-bold text-slate-600 mb-0.5">{isNe ? 'सामान आइपुग्न लाग्ने दिन' : 'Supplier lead time (days)'}</span>
                <input className={inputCls} type="number" min={0} value={s.leadTimeDays} onChange={(e) => setS({ leadTimeDays: Math.max(0, parseInt(e.target.value, 10) || 0) })} /></label>
              <label><span className="block text-[10px] font-bold text-slate-600 mb-0.5">{isNe ? 'एक अर्डरले धान्ने दिन' : 'One order should cover (days)'}</span>
                <input className={inputCls} type="number" min={1} value={s.coverDays} onChange={(e) => setS({ coverDays: Math.max(1, parseInt(e.target.value, 10) || 1) })} /></label>
              <div className="flex gap-2">
                <input className={inputCls} placeholder={isNe ? 'खोज्नुहोस्…' : 'Search…'} value={q} onChange={(e) => setQ(e.target.value)} />
                <button type="button" className={btnGhost} onClick={exportReorder}>CSV</button>
              </div>
            </div>
            <p className="text-[10px] text-slate-500">
              {isNe ? 'सुझाव = (दैनिक औसत बिक्री × (आइपुग्ने दिन + धान्ने दिन)) + न्यूनतम स्टक − हालको स्टक। "न्यूनतम स्टक" सामानको Min Stock Alert बाट लिइन्छ।'
                    : 'Suggested qty = (avg daily sales × (lead time + cover days)) + minimum stock − current stock. Minimum stock comes from each item\'s Min Stock Alert.'}
            </p>
            <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer">
              <input type="checkbox" checked={showAll} onChange={(e) => setShowAll(e.target.checked)} /> {isNe ? 'ठीक भएका सामान पनि देखाउने' : 'Show healthy items too'}
            </label>
          </div>

          {bySupplier.length > 0 && (
            <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
              <h3 className="text-sm font-extrabold text-slate-900">{isNe ? 'आपूर्तिकर्ता अनुसार खरिद अर्डर मस्यौदा' : 'Draft purchase orders by supplier'}</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                {bySupplier.map(([sup, rows]) => (
                  <div key={sup} className="border border-slate-200 rounded-xl p-3 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-extrabold text-xs text-slate-900">{sup}</div>
                      <div className="flex gap-1.5">
                        <button type="button" className={btnGhost + ' !py-0.5 !px-2'} onClick={() => copy(sup, rows)}>{copied === sup ? (isNe ? '✔ कपी भयो' : '✔ Copied') : (isNe ? 'कपी (WhatsApp/SMS)' : 'Copy for WhatsApp/SMS')}</button>
                        <button type="button" className={btnGhost + ' !py-0.5 !px-2'} onClick={() => downloadCsv(`po-${sup}.csv`, [['Item', 'Code', 'Qty', 'Unit', 'Est. rate', 'Est. amount'], ...rows.map((r) => [r.name, r.code, r.suggestQty, r.unit, r.lastRate, r.estCost])])}>CSV</button>
                      </div>
                    </div>
                    <ul className="text-[11px] text-slate-700 space-y-0.5">
                      {rows.map((r) => <li key={r.id} className="flex justify-between gap-2"><span>{r.name}</span><span className="font-mono font-bold whitespace-nowrap">{r.suggestQty} {r.unit}</span></li>)}
                    </ul>
                    <div className="text-[11px] font-bold text-slate-800 border-t border-slate-100 pt-1">{isNe ? 'अनुमानित रकम' : 'Estimated'}: Rs. {fmtMoney(rows.reduce((t, r) => t + r.estCost, 0))}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="bg-white rounded-xl border border-slate-200 p-4 overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50"><tr>
                <th className={th}>{isNe ? 'सामान' : 'Item'}</th><th className={`${th} text-right`}>{isNe ? 'हाल' : 'Stock'}</th><th className={`${th} text-right`}>{isNe ? 'न्यूनतम' : 'Min'}</th>
                <th className={`${th} text-right`}>{isNe ? 'दैनिक बिक्री' : 'Sales/day'}</th><th className={`${th} text-right`}>{isNe ? 'कति दिन पुग्छ' : 'Days left'}</th>
                <th className={`${th} text-right`}>{isNe ? 'सुझाव (अर्डर)' : 'Suggested'}</th><th className={th}>{isNe ? 'पछिल्लो आपूर्तिकर्ता' : 'Last supplier'}</th><th className={th}>{isNe ? 'स्थिति' : 'Status'}</th>
              </tr></thead>
              <tbody className="divide-y divide-slate-100">
                {shown.length === 0 && <tr><td colSpan={8} className="py-8 text-center text-slate-400">{isNe ? '✔ अहिले कुनै सामान अर्डर गर्नुपर्ने छैन' : '✔ Nothing needs reordering right now'}</td></tr>}
                {shown.map((r) => (
                  <tr key={r.kind + r.id}>
                    <td className={tdc}>{r.name}<div className="text-[10px] text-slate-500 font-mono">{r.code}{r.kind === 'RAW' ? ' · ' + (isNe ? 'कच्चा पदार्थ' : 'raw material') : ''}</div></td>
                    <td className={`${tdc} ${num}`}>{r.current} {r.unit}</td><td className={`${tdc} ${num}`}>{r.minLevel}</td>
                    <td className={`${tdc} ${num}`}>{r.kind === 'RAW' ? '—' : r.avgDaily}</td>
                    <td className={`${tdc} ${num}`}>{r.daysCover === null ? '—' : r.daysCover}</td>
                    <td className={`${tdc} ${num} font-extrabold`}>{r.suggestQty > 0 ? `${r.suggestQty} ${r.unit}` : '—'}</td>
                    <td className={tdc}>{r.supplier || '—'}{r.lastRate > 0 && <div className="text-[10px] text-slate-500">Rs. {fmtMoney(r.lastRate)}</div>}</td>
                    <td className={tdc}><span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${statusStyle[r.status].cls}`}>{isNe ? statusStyle[r.status].ne : statusStyle[r.status].en}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === 'VALUATION' && (
        <>
          <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 items-end">
              <label className="col-span-2"><span className="block text-[10px] font-bold text-slate-600 mb-0.5">{isNe ? 'लागत विधि (विवरण/COGS का लागि)' : 'Costing method (detail & COGS)'}</span>
                <select className={inputCls} value={s.method} onChange={(e) => setS({ method: e.target.value as CostMethod })}>
                  {(Object.keys(methodNames) as CostMethod[]).map((m) => <option key={m} value={m}>{isNe ? methodNames[m].ne : methodNames[m].en}</option>)}
                </select></label>
              <label><span className="block text-[10px] font-bold text-slate-600 mb-0.5">{isNe ? 'आ.व. (COGS का लागि)' : 'F.Y. (for COGS)'}</span>
                <select className={inputCls} value={fy} onChange={(e) => setFy(e.target.value)}>{fyOptions.map((f) => <option key={f} value={f}>{f}</option>)}</select></label>
              <div className="flex gap-2"><input className={inputCls} placeholder={isNe ? 'खोज्नुहोस्…' : 'Search…'} value={q} onChange={(e) => setQ(e.target.value)} /><button type="button" className={btnGhost} onClick={exportVal}>CSV</button></div>
            </div>
            <p className="text-[10px] text-slate-500">{methodNames[s.method].hint}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {([['FIFO', fifo], ['LIFO', lifo], ['AVG', avg]] as const).map(([m, res]) => (
              <div key={m} className={`rounded-xl border p-3 ${s.method === m ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 bg-white'}`}>
                <div className="text-[11px] font-extrabold text-slate-700">{m === 'AVG' ? (isNe ? 'औसत लागत' : 'Average') : m}</div>
                <div className="text-[11px] text-slate-500">{isNe ? 'बाँकी स्टकको मूल्य' : 'Closing stock value'}</div>
                <div className="text-base font-extrabold font-mono text-slate-900">Rs. {fmtMoney(res.totals.value)}</div>
                <div className="mt-1 text-[11px] text-slate-500">{isNe ? `बिक्रीको लागत (${fy})` : `COGS (${fy})`}: <span className="font-mono font-bold text-slate-800">Rs. {fmtMoney(res.totals.cogs)}</span></div>
                <div className="text-[11px] text-slate-500">{isNe ? 'कुल नाफा' : 'Gross profit'}: <span className={`font-mono font-bold ${gp(res.totals.revenue, res.totals.cogs) >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>Rs. {fmtMoney(gp(res.totals.revenue, res.totals.cogs))}</span></div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-4 overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50"><tr>
                <th className={th}>{isNe ? 'सामान' : 'Item'}</th><th className={`${th} text-right`}>{isNe ? 'मौज्दात' : 'On hand'}</th>
                <th className={`${th} text-right`}>FIFO</th><th className={`${th} text-right`}>LIFO</th><th className={`${th} text-right`}>{isNe ? 'औसत' : 'Avg'}</th>
                <th className={`${th} text-right`}>{isNe ? 'प्रति एकाइ लागत' : 'Unit cost'} ({s.method})</th><th className={`${th} text-right`}>COGS {fy}</th><th></th>
              </tr></thead>
              <tbody className="divide-y divide-slate-100">
                {valRows.length === 0 && <tr><td colSpan={8} className="py-8 text-center text-slate-400">{isNe ? 'सामान भेटिएन' : 'No items'}</td></tr>}
                {valRows.map(({ r, f, l, a }) => (
                  <React.Fragment key={r.item.id}>
                    <tr>
                      <td className={tdc}>{r.item.nameNe || r.item.nameEn}<div className="text-[10px] text-slate-500 font-mono">{r.item.code}</div></td>
                      <td className={`${tdc} ${num}`}>{r.onHand} {r.item.primaryUnit || r.item.unit}</td>
                      <td className={`${tdc} ${num}`}>{fmtMoney(f.value)}</td><td className={`${tdc} ${num}`}>{fmtMoney(l.value)}</td><td className={`${tdc} ${num}`}>{fmtMoney(a.value)}</td>
                      <td className={`${tdc} ${num} font-bold`}>{fmtMoney(r.avgCost)}</td><td className={`${tdc} ${num}`}>{fmtMoney(r.cogs)}</td>
                      <td className={tdc}><button type="button" className="text-[11px] underline text-slate-600 cursor-pointer" onClick={() => setOpen(open === r.item.id ? null : r.item.id)}>{open === r.item.id ? '▲' : (isNe ? 'तह (layers)' : 'Layers')}</button></td>
                    </tr>
                    {open === r.item.id && (
                      <tr className="bg-slate-50"><td colSpan={8} className="px-4 py-2">
                        {r.layers.length === 0 ? <span className="text-slate-400">{isNe ? 'कुनै बाँकी तह छैन' : 'No remaining layers'}</span> : (
                          <table className="text-[11px] w-full max-w-xl">
                            <thead><tr className="text-slate-600"><th className="text-left py-0.5">{isNe ? 'स्रोत' : 'Source'}</th><th className="text-left">{isNe ? 'मिति' : 'Date'}</th><th className="text-right">{isNe ? 'परिमाण' : 'Qty'}</th><th className="text-right">{isNe ? 'दर' : 'Cost'}</th><th className="text-right">{isNe ? 'मूल्य' : 'Value'}</th></tr></thead>
                            <tbody>{r.layers.map((l, i) => (
                              <tr key={i}><td className="py-0.5">{l.source === 'OPENING' ? (isNe ? 'सुरुवाती स्टक' : 'Opening') : l.source === 'PURCHASE' ? `${isNe ? 'खरिद' : 'Purchase'} ${l.ref || ''}` : (isNe ? 'बिल बाहिरको स्टक (उत्पादन/समायोजन)' : 'Non-bill stock (production/adjustment)')}</td>
                                <td className="font-mono">{l.source === 'PURCHASE' || l.source === 'OPENING' ? (normBs(l.dateBs) || '—') : '—'}</td><td className={num}>{l.qty}</td><td className={num}>{fmtMoney(l.cost)}</td><td className={num}>{fmtMoney(l.qty * l.cost)}</td></tr>
                            ))}</tbody>
                          </table>
                        )}
                        {(r.adjustedQty !== 0 || r.shortfallQty > 0) && (
                          <p className="text-[10px] text-amber-800 mt-1">
                            {r.adjustedQty > 0 && (isNe ? `⚠ ${r.adjustedQty} एकाइ स्टक खरिद बिलमा छैन (उत्पादन/समायोजन/फिर्ता) — पछिल्लो लागतमा गणना गरिएको।` : `⚠ ${r.adjustedQty} units are in stock but not in purchase bills (production/adjustment/returns) — valued at last known cost.`)}
                            {r.adjustedQty < 0 && (isNe ? `⚠ ${-r.adjustedQty} एकाइ बिल बिना घटेको (नोक्सानी/समायोजन)।` : `⚠ ${-r.adjustedQty} units reduced without a bill (loss/adjustment).`)}
                            {r.shortfallQty > 0 && (isNe ? ` बिक्री ${r.shortfallQty} एकाइ खरिद तहभन्दा बढी भएको छ।` : ` Sales exceed purchase layers by ${r.shortfallQty} units.`)}
                          </p>
                        )}
                      </td></tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
              <tfoot className="bg-slate-100 font-extrabold"><tr>
                <td className={tdc} colSpan={2}>{isNe ? 'जम्मा' : 'Total'}</td>
                <td className={`${tdc} ${num}`}>{fmtMoney(fifo.totals.value)}</td><td className={`${tdc} ${num}`}>{fmtMoney(lifo.totals.value)}</td><td className={`${tdc} ${num}`}>{fmtMoney(avg.totals.value)}</td>
                <td></td><td className={`${tdc} ${num}`}>{fmtMoney(sel.totals.cogs)}</td><td></td>
              </tr></tfoot>
            </table>
            {sel.purchasesWithoutDetail > 0 && (
              <p className="text-[10px] text-amber-800 mt-2">
                {isNe ? `${sel.purchasesWithoutDetail} वटा खरिद बिलमा सामानको विवरण छैन, त्यसैले ती लागत गणनामा आएनन्।` : `${sel.purchasesWithoutDetail} purchase bills have no item details and are not included in costing.`}
              </p>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default StockCostingScreen;
