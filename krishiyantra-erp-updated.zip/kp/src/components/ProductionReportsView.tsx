import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { ProductionBatch } from '../types';
import {
  FileText,
  Calendar,
  Download,
  Printer,
  Search,
  Filter,
  TrendingDown,
  Layers,
  Scale,
  DollarSign,
  AlertTriangle,
  Boxes,
  CheckCircle2
} from 'lucide-react';
import {
  getTodayBsString,
  toNepaliDigits,
  formatCurrency
} from '../utils/nepaliCalendar';
import {
  exportReportToExcel,
  printOrDownloadReportPdf,
  PrintableReportConfig
} from '../utils/pdfReportExporter';

export const ProductionReportsView: React.FC = () => {
  const { productionBatches, rawMaterials, company, language } = useApp();
  const isNe = language === 'ne';

  const todayBs = getTodayBsString();
  const currentMonthBs = todayBs.slice(0, 7);

  // Report Sub-tabs
  const [reportType, setReportType] = useState<'BATCH_WISE' | 'DAILY_MONTHLY' | 'WASTAGE'>('BATCH_WISE');

  // Date Filter State
  const [filterMode, setFilterMode] = useState<'ALL' | 'TODAY' | 'MONTH' | 'CUSTOM'>('ALL');
  const [fromBs, setFromBs] = useState('');
  const [toBs, setToBs] = useState('');
  const [productFilter, setProductFilter] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Filtered Batches
  const filteredBatches = useMemo(() => {
    return productionBatches.filter((b) => {
      const bDate = b.productionDateBs || b.startedDateBs || '';

      // Date check
      if (filterMode === 'TODAY' && bDate !== todayBs) return false;
      if (filterMode === 'MONTH' && !bDate.startsWith(currentMonthBs)) return false;
      if (filterMode === 'CUSTOM') {
        if (fromBs && bDate < fromBs) return false;
        if (toBs && bDate > toBs) return false;
      }

      // Product check
      if (productFilter) {
        const prod = (b.productNameNe + ' ' + (b.productNameEn || '')).toLowerCase();
        if (!prod.includes(productFilter.toLowerCase())) return false;
      }

      // Search
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const str = `${b.batchNumber} ${b.productNameNe} ${b.productNameEn || ''} ${b.operatorName || ''}`.toLowerCase();
        if (!str.includes(q)) return false;
      }

      return true;
    });
  }, [productionBatches, filterMode, fromBs, toBs, productFilter, searchTerm, todayBs, currentMonthBs]);

  // Aggregate Metrics
  const totalInputQty = filteredBatches.reduce(
    (sum, b) => sum + (b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0)),
    0
  );
  const totalOutputQty = filteredBatches.reduce(
    (sum, b) => sum + (b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0),
    0
  );
  const totalProductionCost = filteredBatches.reduce((sum, b) => sum + (b.totalProductionCost || 0), 0);
  const totalWastageWeight = Math.max(0, totalInputQty - totalOutputQty);
  const avgYield = totalInputQty > 0 ? ((totalOutputQty / totalInputQty) * 100).toFixed(1) : '100';

  // Export to Excel handler
  const handleExportExcel = () => {
    let title = '';
    let headers: string[] = [];
    let rows: (string | number)[][] = [];

    if (reportType === 'BATCH_WISE') {
      title = 'ब्याच अनुसारको उत्पादन प्रतिवेदन (Batch-wise Production Report)';
      headers = [
        'ब्याच नं.',
        'उत्पादन मिति',
        'उत्पादित वस्तु',
        'कच्चा पदार्थ विवरण',
        'इनपुट तौल',
        'आउटपुट परिमाण',
        'प्राप्ति (Yield %)',
        'तौल ह्रास (Wastage %)',
        'कुल लागत (Rs)',
        'प्रति एकाइ लागत (Rs)',
        'गुणस्तर'
      ];
      rows = filteredBatches.map((b) => [
        b.batchNumber,
        b.productionDateBs || b.startedDateBs,
        b.productNameNe,
        b.rawMaterialsUsed.map((r) => `${r.materialName} (${r.quantityUsed} ${r.unit})`).join(', '),
        b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0),
        b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0,
        b.yieldPercent ? `${b.yieldPercent}%` : '-',
        b.wastagePercent ? `${b.wastagePercent}%` : '-',
        b.totalProductionCost || 0,
        b.unitManufacturingCost || 0,
        b.qualityCheckStatus || 'PASS'
      ]);
    } else if (reportType === 'DAILY_MONTHLY') {
      title = 'दैनिक तथा मासिक उत्पादन समीक्षा प्रतिवेदन (Production Summary Report)';
      headers = ['मिति / महिना', 'ब्याच सङ्ख्या', 'कच्चा पदार्थ इनपुट', 'तयारी आउटपुट', 'औसत प्राप्ति %', 'कुल लागत (Rs)'];

      // Group by date
      const groups: { [key: string]: { count: number; inQty: number; outQty: number; cost: number } } = {};
      filteredBatches.forEach((b) => {
        const d = b.productionDateBs || b.startedDateBs || 'अन्य';
        if (!groups[d]) groups[d] = { count: 0, inQty: 0, outQty: 0, cost: 0 };
        groups[d].count += 1;
        groups[d].inQty += b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0);
        groups[d].outQty += b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0;
        groups[d].cost += b.totalProductionCost || 0;
      });

      rows = Object.entries(groups).map(([date, data]) => [
        date,
        data.count,
        data.inQty,
        data.outQty,
        data.inQty > 0 ? `${((data.outQty / data.inQty) * 100).toFixed(1)}%` : '100%',
        data.cost
      ]);
    } else {
      title = 'उत्पादन तौल ह्रास तथा वेस्टेज प्रतिवेदन (Production Wastage & Loss Report)';
      headers = [
        'ब्याच नं.',
        'उत्पादित वस्तु',
        'इनपुट परिमाण',
        'आउटपुट परिमाण',
        'तौल ह्रास (Weight Loss)',
        'ह्रास प्रतिशत (Wastage %)',
        'कच्चा पदार्थ लागत',
        'वेस्टेजको आर्थिक नोक्सानी (Rs)'
      ];
      rows = filteredBatches.map((b) => {
        const inQ = b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0);
        const outQ = b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0;
        const lossWeight = Math.max(0, inQ - outQ);
        const rmCost = b.rawMaterialCost || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed * r.costPerUnit, 0);
        const estimatedLossRs = inQ > 0 ? Math.round((lossWeight / inQ) * rmCost) : 0;
        return [
          b.batchNumber,
          b.productNameNe,
          inQ,
          outQ,
          lossWeight,
          b.wastagePercent ? `${b.wastagePercent}%` : `${inQ > 0 ? ((lossWeight / inQ) * 100).toFixed(1) : 0}%`,
          rmCost,
          estimatedLossRs
        ];
      });
    }

    const config: PrintableReportConfig = {
      title,
      headers,
      rows,
      company,
      fileName: `Production_Report_${reportType}_${todayBs}`
    };

    exportReportToExcel(config);
  };

  // Export to PDF handler
  const handlePrintPdf = () => {
    let title = '';
    let headers: string[] = [];
    let rows: (string | number)[][] = [];

    if (reportType === 'BATCH_WISE') {
      title = 'ब्याच अनुसारको उत्पादन प्रतिवेदन (Batch-wise Report)';
      headers = ['ब्याच नं.', 'मिति', 'उत्पादित सामान', 'इनपुट', 'आउटपुट', 'Yield %', 'Wastage %', 'कुल लागत (Rs)', 'प्रति एकाइ'];
      rows = filteredBatches.map((b) => [
        b.batchNumber,
        b.productionDateBs || b.startedDateBs,
        b.productNameNe,
        `${b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0)} ${b.inputUnit || 'Kg'}`,
        `${b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0} ${b.outputUnit || 'Kg'}`,
        b.yieldPercent ? `${b.yieldPercent}%` : '-',
        b.wastagePercent ? `${b.wastagePercent}%` : '-',
        (b.totalProductionCost || 0).toLocaleString(),
        (b.unitManufacturingCost || 0).toLocaleString()
      ]);
    } else if (reportType === 'DAILY_MONTHLY') {
      title = 'उत्पादन समीक्षा प्रतिवेदन (Production Summary Report)';
      headers = ['मिति', 'ब्याच सङ्ख्या', 'कच्चा इनपुट', 'तयारी आउटपुट', 'औसत Yield %', 'कुल लागत (Rs)'];
      const groups: { [key: string]: { count: number; inQty: number; outQty: number; cost: number } } = {};
      filteredBatches.forEach((b) => {
        const d = b.productionDateBs || b.startedDateBs || 'अन्य';
        if (!groups[d]) groups[d] = { count: 0, inQty: 0, outQty: 0, cost: 0 };
        groups[d].count += 1;
        groups[d].inQty += b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0);
        groups[d].outQty += b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0;
        groups[d].cost += b.totalProductionCost || 0;
      });
      rows = Object.entries(groups).map(([date, data]) => [
        date,
        data.count,
        data.inQty,
        data.outQty,
        data.inQty > 0 ? `${((data.outQty / data.inQty) * 100).toFixed(1)}%` : '100%',
        data.cost.toLocaleString()
      ]);
    } else {
      title = 'उत्पादन तौल ह्रास तथा वेस्टेज प्रतिवेदन (Wastage Report)';
      headers = ['ब्याच नं.', 'उत्पादित वस्तु', 'इनपुट', 'आउटपुट', 'तौल ह्रास (Loss)', 'Wastage %', 'वेस्टेज नोक्सानी (Rs)'];
      rows = filteredBatches.map((b) => {
        const inQ = b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0);
        const outQ = b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0;
        const lossWeight = Math.max(0, inQ - outQ);
        const rmCost = b.rawMaterialCost || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed * r.costPerUnit, 0);
        const estimatedLossRs = inQ > 0 ? Math.round((lossWeight / inQ) * rmCost) : 0;
        return [
          b.batchNumber,
          b.productNameNe,
          inQ,
          outQ,
          lossWeight,
          b.wastagePercent ? `${b.wastagePercent}%` : `${inQ > 0 ? ((lossWeight / inQ) * 100).toFixed(1) : 0}%`,
          estimatedLossRs.toLocaleString()
        ];
      });
    }

    const config: PrintableReportConfig = {
      title,
      headers,
      rows,
      summaryCards: [
        { label: 'कुल ब्याच सङ्ख्या', value: `${filteredBatches.length}` },
        { label: 'कुल इनपुट परिमाण', value: `${totalInputQty.toLocaleString()} Kg` },
        { label: 'कुल आउटपुट परिमाण', value: `${totalOutputQty.toLocaleString()} Kg` },
        { label: 'औसत प्राप्ति (Yield %)', value: `${avgYield}%` },
        { label: 'कुल उत्पादन लागत', value: `रु. ${totalProductionCost.toLocaleString()}` }
      ],
      company,
      fileName: `Production_Report_${reportType}_${todayBs}`
    };

    printOrDownloadReportPdf(config, 'DOWNLOAD_PDF');
  };

  return (
    <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-5">
      
      {/* Top Banner & Export Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-purple-700" />
            <span>{isNe ? 'उत्पादन प्रतिवेदन तथा विश्लेषण (Production Reports & Analytics)' : 'Production Reports & Analytics'}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {isNe
              ? 'ब्याच अनुसारको हिसाब, दैनिक/मासिक समीक्षा, तौल ह्रास (Wastage) र Excel/PDF निर्यात'
              : 'Batch-wise costs, daily/monthly summaries, wastage analysis with Excel/PDF export'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportExcel}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Excel निर्यात</span>
          </button>
          <button
            onClick={handlePrintPdf}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs border border-slate-700"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>PDF डाउनलोड / प्रिन्ट</span>
          </button>
        </div>
      </div>

      {/* Report Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setReportType('BATCH_WISE')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
            reportType === 'BATCH_WISE'
              ? 'bg-purple-900 text-white shadow-xs'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>१. ब्याच अनुसारको विस्तृत विवरण (Batch-wise Report)</span>
        </button>

        <button
          onClick={() => setReportType('DAILY_MONTHLY')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
            reportType === 'DAILY_MONTHLY'
              ? 'bg-purple-900 text-white shadow-xs'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>२. दैनिक तथा मासिक उत्पादन समीक्षा (Daily/Monthly Summary)</span>
        </button>

        <button
          onClick={() => setReportType('WASTAGE')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
            reportType === 'WASTAGE'
              ? 'bg-purple-900 text-white shadow-xs'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <TrendingDown className="w-4 h-4 text-amber-300" />
          <span>३. तौल ह्रास तथा वेस्टेज रिपोर्ट (Wastage & Loss Report)</span>
        </button>
      </div>

      {/* Date & Filter Bar (Nepali Dates) */}
      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Quick Date Mode Buttons */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-bold text-slate-700 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-slate-500" />
              <span>मिति फिल्टर:</span>
            </span>
            <button
              onClick={() => setFilterMode('ALL')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterMode === 'ALL' ? 'bg-purple-700 text-white' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              सबै (All)
            </button>
            <button
              onClick={() => setFilterMode('TODAY')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterMode === 'TODAY' ? 'bg-purple-700 text-white' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              आज (Today - {todayBs})
            </button>
            <button
              onClick={() => setFilterMode('MONTH')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterMode === 'MONTH' ? 'bg-purple-700 text-white' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              यो महिना (This Month - {currentMonthBs})
            </button>
            <button
              onClick={() => setFilterMode('CUSTOM')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterMode === 'CUSTOM' ? 'bg-purple-700 text-white' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              कस्टम मिति (Custom Range)
            </button>
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="ब्याच नं., सामान, अपरेटर खोज्नुहोस्..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs"
            />
          </div>
        </div>

        {/* Custom Date Inputs if CUSTOM is active */}
        {filterMode === 'CUSTOM' && (
          <div className="flex items-center gap-3 pt-2 border-t border-slate-200 flex-wrap text-xs">
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-slate-600">मिति देखि (From BS):</span>
              <input
                type="text"
                placeholder="2081-10-01"
                value={fromBs}
                onChange={(e) => setFromBs(e.target.value)}
                className="px-2.5 py-1 border border-slate-300 rounded-lg font-mono bg-white w-32"
              />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-slate-600">मिति सम्म (To BS):</span>
              <input
                type="text"
                placeholder="2081-11-30"
                value={toBs}
                onChange={(e) => setToBs(e.target.value)}
                className="px-2.5 py-1 border border-slate-300 rounded-lg font-mono bg-white w-32"
              />
            </div>
          </div>
        )}
      </div>

      {/* Summary KPI Ribbon for Filtered Data */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-3 bg-purple-50 rounded-2xl border border-purple-200">
          <span className="text-[10px] text-purple-700 font-bold uppercase block">कुल ब्याच सङ्ख्या</span>
          <span className="text-xl font-black font-mono text-purple-900 mt-0.5">
            {toNepaliDigits(filteredBatches.length)}
          </span>
          <span className="text-[9px] text-purple-600 block">उत्पादित लटहरू</span>
        </div>

        <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
          <span className="text-[10px] text-slate-600 font-bold uppercase block">कच्चा इनपुट तौल</span>
          <span className="text-xl font-black font-mono text-slate-900 mt-0.5">
            {toNepaliDigits(totalInputQty)} Kg
          </span>
          <span className="text-[9px] text-slate-500 block">प्रयोग भएको कच्चा पदार्थ</span>
        </div>

        <div className="p-3 bg-blue-50 rounded-2xl border border-blue-200">
          <span className="text-[10px] text-blue-700 font-bold uppercase block">तयारी आउटपुट परिमाण</span>
          <span className="text-xl font-black font-mono text-blue-900 mt-0.5">
            {toNepaliDigits(totalOutputQty)} Kg
          </span>
          <span className="text-[9px] text-blue-600 block">उत्पादित सामान</span>
        </div>

        <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200">
          <span className="text-[10px] text-emerald-700 font-bold uppercase block">औसत प्राप्ति (Yield %)</span>
          <span className="text-xl font-black font-mono text-emerald-900 mt-0.5">
            {toNepaliDigits(avgYield)}%
          </span>
          <span className="text-[9px] text-emerald-600 block">स्वाभाविक कार्यक्षमता</span>
        </div>

        <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200">
          <span className="text-[10px] text-amber-800 font-bold uppercase block">कुल उत्पादन लागत</span>
          <span className="text-lg font-black font-mono text-amber-950 mt-0.5">
            रु. {totalProductionCost.toLocaleString()}
          </span>
          <span className="text-[9px] text-amber-700 block">सामग्री + ज्याला + उर्जा</span>
        </div>
      </div>

      {/* REPORT 1: BATCH-WISE TABLE */}
      {reportType === 'BATCH_WISE' && (
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-900 text-white font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-3">ब्याच नं.</th>
                <th className="py-3 px-3">उत्पादन मिति</th>
                <th className="py-3 px-3">उत्पादित सामान</th>
                <th className="py-3 px-3">कच्चा पदार्थ विवरण (BOM)</th>
                <th className="py-3 px-3 text-right">इनपुट तौल</th>
                <th className="py-3 px-3 text-right">आउटपुट</th>
                <th className="py-3 px-3 text-center">Yield %</th>
                <th className="py-3 px-3 text-center">Wastage %</th>
                <th className="py-3 px-3 text-right">कुल लागत (Rs)</th>
                <th className="py-3 px-3 text-right">प्रति एकाइ</th>
                <th className="py-3 px-3 text-center">गुणस्तर</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {filteredBatches.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center text-slate-400">
                    यस फिल्टर अनुसार कुनै ब्याच फेला परेन।
                  </td>
                </tr>
              ) : (
                filteredBatches.map((b) => {
                  const inQ = b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0);
                  const outQ = b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0;
                  const yPct = typeof b.yieldPercent === 'number' ? b.yieldPercent : inQ > 0 ? Math.round((outQ / inQ) * 1000) / 10 : 100;
                  const wPct = typeof b.wastagePercent === 'number' ? b.wastagePercent : Math.max(0, 100 - yPct);

                  return (
                    <tr key={b.id} className="hover:bg-slate-50 transition">
                      <td className="py-2.5 px-3 font-mono font-black text-purple-900">{b.batchNumber}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-700">
                        {b.productionDateBs || b.startedDateBs}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-900">{b.productNameNe}</div>
                        {b.productNameEn && <div className="text-[10px] text-slate-400 font-mono">{b.productNameEn}</div>}
                      </td>
                      <td className="py-2.5 px-3 max-w-[200px]">
                        <div className="text-[11px] text-slate-600 line-clamp-2">
                          {b.rawMaterialsUsed.map((r) => `${r.materialName} (${r.quantityUsed} ${r.unit})`).join(', ')}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-800">
                        {toNepaliDigits(inQ)} {b.inputUnit || 'Kg'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-blue-800">
                        {toNepaliDigits(outQ)} {b.outputUnit || 'Kg'}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono font-black text-emerald-700">
                        {toNepaliDigits(yPct)}%
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono font-bold text-amber-700">
                        {toNepaliDigits(wPct)}%
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                        रु. {(b.totalProductionCost || 0).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-purple-900">
                        रु. {(b.unitManufacturingCost || 0).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          b.qualityCheckStatus === 'PASS'
                            ? 'bg-emerald-100 text-emerald-800'
                            : b.qualityCheckStatus === 'PENDING'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {b.qualityCheckStatus === 'PASS' ? 'पास' : b.qualityCheckStatus === 'PENDING' ? 'परीक्षण' : 'फेल'}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* REPORT 2: DAILY / MONTHLY SUMMARY */}
      {reportType === 'DAILY_MONTHLY' && (
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-900 text-white font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">उत्पादन मिति (Date BS)</th>
                <th className="py-3 px-4 text-center">ब्याच सङ्ख्या</th>
                <th className="py-3 px-4 text-right">कुल कच्चा इनपुट (Kg)</th>
                <th className="py-3 px-4 text-right">कुल तयारी आउटपुट (Kg)</th>
                <th className="py-3 px-4 text-center">औसत प्राप्ति (Yield %)</th>
                <th className="py-3 px-4 text-right">कुल उत्पादन लागत (Rs)</th>
                <th className="py-3 px-4 text-right">प्रति एकाइ औसत लागत (Rs)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {Object.entries(
                filteredBatches.reduce((acc, b) => {
                  const d = b.productionDateBs || b.startedDateBs || 'अन्य';
                  if (!acc[d]) acc[d] = { count: 0, inQty: 0, outQty: 0, cost: 0 };
                  acc[d].count += 1;
                  acc[d].inQty += b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0);
                  acc[d].outQty += b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0;
                  acc[d].cost += b.totalProductionCost || 0;
                  return acc;
                }, {} as { [key: string]: { count: number; inQty: number; outQty: number; cost: number } })
              ).map(([date, rawData]) => {
                const data = rawData as { count: number; inQty: number; outQty: number; cost: number };
                const yieldP = data.inQty > 0 ? ((data.outQty / data.inQty) * 100).toFixed(1) : '100';
                const unitCost = data.outQty > 0 ? Math.round(data.cost / data.outQty) : 0;
                return (
                  <tr key={date} className="hover:bg-slate-50 transition">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">{date}</td>
                    <td className="py-3 px-4 text-center font-mono font-bold text-purple-900">
                      {toNepaliDigits(data.count)} ब्याच
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-800">
                      {toNepaliDigits(data.inQty)} Kg
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-blue-800">
                      {toNepaliDigits(data.outQty)} Kg
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-black text-emerald-700">
                      {toNepaliDigits(yieldP)}%
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      रु. {data.cost.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-purple-900">
                      रु. {unitCost.toLocaleString()}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* REPORT 3: WASTAGE & MOISTURE LOSS REPORT */}
      {reportType === 'WASTAGE' && (
        <div className="space-y-4">
          <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-900 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-700" />
            <span>
              कृषि उपज (खुर्सानी, प्याज, अदुवा आदि) सुकाउँदा, पिस्दा वा मेशिनिङ गर्दा हुने स्वाभाविक मोइस्चर लस (Moisture Loss) र तौल ह्रासको वित्तीय विश्लेषण।
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-900 text-white font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">ब्याच नं.</th>
                  <th className="py-3 px-4">उत्पादित वस्तु</th>
                  <th className="py-3 px-4 text-right">कच्चा इनपुट तौल</th>
                  <th className="py-3 px-4 text-right">तयारी आउटपुट तौल</th>
                  <th className="py-3 px-4 text-right">तौल ह्रास (Weight Loss)</th>
                  <th className="py-3 px-4 text-center">ह्रास प्रतिशत (Wastage %)</th>
                  <th className="py-3 px-4 text-right">कच्चा पदार्थ लागत</th>
                  <th className="py-3 px-4 text-right">ह्रासको अनुमानित लागत (Rs)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {filteredBatches.map((b) => {
                  const inQ = b.inputQuantity || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0);
                  const outQ = b.outputQuantity || b.finishedGoodsQuantity || b.targetQuantity || 0;
                  const lossWeight = Math.max(0, inQ - outQ);
                  const rmCost = b.rawMaterialCost || b.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed * r.costPerUnit, 0);
                  const estimatedLossRs = inQ > 0 ? Math.round((lossWeight / inQ) * rmCost) : 0;
                  const wPct = typeof b.wastagePercent === 'number' ? b.wastagePercent : inQ > 0 ? Math.round(((lossWeight / inQ) * 100) * 10) / 10 : 0;

                  return (
                    <tr key={b.id} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-4 font-mono font-bold text-purple-900">{b.batchNumber}</td>
                      <td className="py-3 px-4 font-bold text-slate-900">{b.productNameNe}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-700">
                        {toNepaliDigits(inQ)} {b.inputUnit || 'Kg'}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-blue-800">
                        {toNepaliDigits(outQ)} {b.outputUnit || 'Kg'}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-black text-amber-900">
                        {toNepaliDigits(lossWeight)} {b.inputUnit || 'Kg'}
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-amber-800">
                        {toNepaliDigits(wPct)}%
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700">
                        रु. {rmCost.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-black text-red-700">
                        रु. {estimatedLossRs.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
