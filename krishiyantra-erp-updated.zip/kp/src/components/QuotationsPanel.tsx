import React, { useMemo, useState } from 'react';
import { Plus, Printer, MessageCircle, Trash2, Edit2, CheckCircle2, XCircle, ArrowRightCircle, FileText, Save, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FieldOrder, FieldOrderItem, Party, Quotation, QuotationStatus } from '../types';
import { OrderLinesEditor } from './OrderLinesEditor';
import { QuotationPrintModal } from './QuotationPrintModal';
import {
  addDaysAd,
  adStringToBs,
  buildQuotationMessage,
  calcTotals
} from '../utils/orderUtils';
import { getTodayAdString, getTodayBsString } from '../utils/nepaliCalendar';
import { shareViaWhatsApp } from '../utils/shareUtils';
import { getServerUser } from '../utils/auth';

const STATUS: Record<QuotationStatus, { ne: string; cls: string }> = {
  DRAFT: { ne: 'ड्राफ्ट', cls: 'bg-slate-100 text-slate-700 border-slate-300' },
  SENT: { ne: 'ग्राहकलाई पठाइयो', cls: 'bg-blue-100 text-blue-800 border-blue-300' },
  ACCEPTED: { ne: 'ग्राहकले स्वीकार गरे', cls: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
  REJECTED: { ne: 'अस्वीकृत', cls: 'bg-rose-100 text-rose-800 border-rose-300' },
  CONVERTED: { ne: 'अर्डरमा परिणत', cls: 'bg-purple-100 text-purple-800 border-purple-300' }
};

interface Props {
  /** कोटेशनबाट अर्डर बनाउन अभिभावक स्क्रिनलाई जानकारी दिने */
  onConvertToOrder: (prefill: Partial<FieldOrder>, quotationId: string) => void;
  /** अर्डरबाट कोटेशन बनाउँदा भरिने */
  seed?: Partial<Quotation> | null;
  onSeedConsumed?: () => void;
}

export const QuotationsPanel: React.FC<Props> = ({ onConvertToOrder, seed, onSeedConsumed }) => {
  const { quotations, saveQuotation, deleteQuotation, getNextQuotationNo, parties, company, currentAccount, currentRole, language } = useApp();
  const isNe = language === 'ne';
  const privileged = ['OWNER', 'ACCOUNTANT', 'ADMINISTRATION', 'SUPERVISOR'].includes(currentRole as string);
  const me = currentAccount?.ownerName || getServerUser()?.name || (isNe ? 'कर्मचारी' : 'Staff');
  const myId = getServerUser()?.id || currentAccount?.mobileNumber;

  const [editing, setEditing] = useState<Quotation | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState<'ALL' | QuotationStatus>('ALL');
  const [printing, setPrinting] = useState<Quotation | null>(null);

  React.useEffect(() => {
    if (seed) {
      setEditing(null);
      setShowForm(true);
    }
  }, [seed]);

  const visible = useMemo(
    () =>
      quotations
        .filter((q) => privileged || !q.preparedById || q.preparedById === myId || q.preparedBy === me)
        .filter((q) => filter === 'ALL' || q.status === filter),
    [quotations, filter, privileged, myId, me]
  );

  if (showForm) {
    return (
      <QuotationForm
        key={editing?.id || 'new'}
        editing={editing}
        seed={seed || null}
        privileged={privileged}
        me={me}
        myId={myId}
        parties={parties}
        onCancel={() => {
          setShowForm(false);
          setEditing(null);
          onSeedConsumed?.();
        }}
        onSave={(q) => {
          saveQuotation(q);
          setShowForm(false);
          setEditing(null);
          onSeedConsumed?.();
        }}
        nextNo={getNextQuotationNo}
        company={company}
        isNe={isNe}
      />
    );
  }

  const setStatus = (q: Quotation, status: QuotationStatus) => saveQuotation({ ...q, status });

  return (
    <div className="space-y-3">
      {printing && (
        <QuotationPrintModal
          quotation={printing}
          onClose={() => setPrinting(null)}
          onPrinted={() => {
            if (printing.status === 'DRAFT') {
              const upd = { ...printing, status: 'SENT' as QuotationStatus };
              saveQuotation(upd);
              setPrinting(upd);
            }
          }}
        />
      )}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1.5">
          {(['ALL', 'DRAFT', 'SENT', 'ACCEPTED', 'REJECTED', 'CONVERTED'] as const).map((k) => (
            <button
              key={k}
              onClick={() => setFilter(k)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold border ${
                filter === k ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-600 border-slate-200'
              }`}
            >
              {k === 'ALL' ? (isNe ? 'सबै' : 'All') : STATUS[k as QuotationStatus].ne}
            </button>
          ))}
        </div>
        <button
          onClick={() => {
            setEditing(null);
            setShowForm(true);
          }}
          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-black rounded-xl flex items-center gap-1.5 shadow"
        >
          <Plus className="w-4 h-4" />
          {isNe ? 'नयाँ कोटेशन' : 'New quotation'}
        </button>
      </div>

      {visible.length === 0 ? (
        <div className="text-center text-sm text-slate-400 py-12 bg-white border border-dashed border-slate-300 rounded-2xl">
          <FileText className="w-8 h-8 mx-auto mb-2 text-slate-300" />
          {isNe ? 'कुनै कोटेशन छैन। "नयाँ कोटेशन" थिच्नुहोस्।' : 'No quotations yet.'}
        </div>
      ) : (
        visible.map((q) => (
          <div key={q.id} className="bg-white border border-slate-200 rounded-2xl p-3 shadow-xs">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-black text-slate-700">{q.quotationNo}</span>
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${STATUS[q.status].cls}`}>{STATUS[q.status].ne}</span>
                </div>
                <div className="font-bold text-slate-900 truncate">{q.customerName}</div>
                <div className="text-[11px] text-slate-500">
                  {q.dateBs} · {q.items.length} {isNe ? 'सामान' : 'items'}
                  {q.validUntilBs ? ` · ${isNe ? 'मान्य' : 'valid'}: ${q.validUntilBs}` : ''} · {q.preparedBy}
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-base font-black text-emerald-800">रू. {q.grandTotal.toLocaleString('en-IN')}</div>
                <div className="text-[10px] text-slate-400">{q.billType === 'VAT' ? (isNe ? 'भ्याट सहित' : 'incl. VAT') : isNe ? 'भ्याट बिना' : 'no VAT'}</div>
              </div>
            </div>

            <div className="mt-2 flex flex-wrap gap-1.5">
              <button
                onClick={() => setPrinting(q)}
                className="px-2.5 py-1.5 text-xs font-bold bg-slate-800 text-white rounded-lg flex items-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" />
                {isNe ? 'प्रिन्ट / PDF' : 'Print / PDF'}
              </button>
              <button
                onClick={() => {
                  shareViaWhatsApp(q.customerPhone, buildQuotationMessage(q, company));
                  if (q.status === 'DRAFT') setStatus(q, 'SENT');
                }}
                className="px-2.5 py-1.5 text-xs font-bold bg-green-600 text-white rounded-lg flex items-center gap-1"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                WhatsApp
              </button>
              {q.status !== 'CONVERTED' && (
                <button
                  onClick={() => {
                    setEditing(q);
                    setShowForm(true);
                  }}
                  className="px-2.5 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg flex items-center gap-1"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  {isNe ? 'सच्याउनुहोस्' : 'Edit'}
                </button>
              )}
              {(q.status === 'DRAFT' || q.status === 'SENT') && (
                <>
                  <button onClick={() => setStatus(q, 'ACCEPTED')} className="px-2.5 py-1.5 text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {isNe ? 'स्वीकार भयो' : 'Accepted'}
                  </button>
                  <button onClick={() => setStatus(q, 'REJECTED')} className="px-2.5 py-1.5 text-xs font-bold bg-rose-50 text-rose-800 border border-rose-300 rounded-lg flex items-center gap-1">
                    <XCircle className="w-3.5 h-3.5" />
                    {isNe ? 'अस्वीकार' : 'Rejected'}
                  </button>
                </>
              )}
              {(q.status === 'ACCEPTED' || q.status === 'SENT' || q.status === 'DRAFT') && (
                <button
                  onClick={() =>
                    onConvertToOrder(
                      {
                        partyId: q.partyId,
                        customerName: q.customerName,
                        customerPhone: q.customerPhone,
                        customerAddress: q.customerAddress,
                        customerPan: q.customerPan,
                        items: q.items,
                        discountPercent: q.discountPercent,
                        notes: `कोटेशन ${q.quotationNo} बाट`
                      },
                      q.id
                    )
                  }
                  className="px-2.5 py-1.5 text-xs font-bold bg-purple-600 text-white rounded-lg flex items-center gap-1"
                >
                  <ArrowRightCircle className="w-3.5 h-3.5" />
                  {isNe ? 'अर्डरमा बदल्नुहोस्' : 'Convert to order'}
                </button>
              )}
              {currentRole === 'OWNER' && (
                <button onClick={() => deleteQuotation(q.id)} className="px-2 py-1.5 text-xs text-rose-600 border border-rose-200 rounded-lg">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
};

interface FormProps {
  editing: Quotation | null;
  seed: Partial<Quotation> | null;
  privileged: boolean;
  me: string;
  myId?: string;
  parties: Party[];
  nextNo: () => string;
  company: any;
  isNe: boolean;
  onSave: (q: Quotation) => void;
  onCancel: () => void;
}

const QuotationForm: React.FC<FormProps> = ({ editing, seed, privileged, me, myId, parties, nextNo, isNe, onSave, onCancel }) => {
  const base: Partial<Quotation> = editing || seed || {};
  const [partyId, setPartyId] = useState(base.partyId || '');
  const [search, setSearch] = useState('');
  const [name, setName] = useState(base.customerName || '');
  const [phone, setPhone] = useState(base.customerPhone || '');
  const [address, setAddress] = useState(base.customerAddress || '');
  const [pan, setPan] = useState(base.customerPan || '');
  const [subject, setSubject] = useState(base.subject || '');
  const [lines, setLines] = useState<FieldOrderItem[]>(base.items || []);
  const [discount, setDiscount] = useState(base.discountPercent || 0);
  const [billType, setBillType] = useState<'VAT' | 'NON_VAT'>(base.billType || 'NON_VAT');
  const [freight, setFreight] = useState(base.freightCharge || 0);
  const [validAd, setValidAd] = useState(addDaysAd(15));
  const [validBs, setValidBs] = useState(base.validUntilBs || adStringToBs(addDaysAd(15)));
  const [deliveryTerms, setDeliveryTerms] = useState(base.deliveryTerms ?? 'अर्डर पाएको ७ दिनभित्र');
  const [paymentTerms, setPaymentTerms] = useState(base.paymentTerms ?? '५०% अग्रिम, बाँकी डेलिभरीमा');
  const [warranty, setWarranty] = useState(base.warrantyNote || '');
  const [notes, setNotes] = useState(base.notes || '');
  const [err, setErr] = useState('');

  const matches = useMemo(() => {
    const t = search.trim().toLowerCase();
    if (!t) return [];
    return parties.filter((p) => [p.name, p.phone || ''].some((f) => f.toLowerCase().includes(t))).slice(0, 6);
  }, [search, parties]);

  const totals = calcTotals(lines, discount, billType === 'VAT', freight);

  const save = (status: QuotationStatus) => {
    if (!name.trim()) return setErr(isNe ? 'ग्राहकको नाम चाहिन्छ।' : 'Customer name required.');
    const valid = lines.filter((l) => l.qty > 0);
    if (valid.length === 0) return setErr(isNe ? 'कम्तीमा एउटा सामान राख्नुहोस्।' : 'Add at least one item.');
    onSave({
      id: editing?.id || `qt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      quotationNo: editing?.quotationNo || nextNo(),
      dateBs: editing?.dateBs || getTodayBsString(),
      dateAd: editing?.dateAd || getTodayAdString(),
      validUntilBs: validBs || undefined,
      partyId: partyId || undefined,
      customerName: name.trim(),
      customerPhone: phone.trim() || undefined,
      customerAddress: address.trim() || undefined,
      customerPan: pan.trim() || undefined,
      subject: subject.trim() || undefined,
      items: valid,
      subtotal: totals.subtotal,
      discountPercent: discount,
      discountAmount: totals.discountAmount,
      billType,
      vatAmount: totals.vatAmount,
      freightCharge: freight,
      grandTotal: totals.grandTotal,
      deliveryTerms: deliveryTerms.trim() || undefined,
      paymentTerms: paymentTerms.trim() || undefined,
      warrantyNote: warranty.trim() || undefined,
      notes: notes.trim() || undefined,
      preparedBy: editing?.preparedBy || me,
      preparedById: editing?.preparedById || myId,
      status: editing && editing.status !== 'DRAFT' && status === 'DRAFT' ? editing.status : status,
      fieldOrderId: editing?.fieldOrderId || seed?.fieldOrderId
    });
  };

  const inp = 'w-full px-3 py-2.5 border border-slate-300 rounded-xl text-sm';

  return (
    <div className="space-y-4 pb-28">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-black text-slate-900">
          {editing ? (isNe ? `कोटेशन सच्याउने — ${editing.quotationNo}` : 'Edit quotation') : isNe ? 'नयाँ कोटेशन' : 'New quotation'}
        </h3>
        <button onClick={onCancel} className="p-2 rounded-lg hover:bg-slate-100">
          <X className="w-5 h-5" />
        </button>
      </div>

      <section className="bg-white border border-slate-200 rounded-2xl p-3 sm:p-4 space-y-2">
        <div className="relative">
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={isNe ? 'पुरानो ग्राहक खोज्नुहोस् (नाम / फोन)' : 'Search existing customer'} className={inp + ' border-emerald-300 border-2'} />
          {matches.length > 0 && (
            <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-300 rounded-xl shadow-xl">
              {matches.map((p) => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => {
                    setPartyId(p.id);
                    setName(p.name);
                    setPhone(p.phone || '');
                    setAddress(p.address || '');
                    setPan(p.panNo || '');
                    setSearch('');
                  }}
                  className="w-full text-left px-3 py-2 border-b border-slate-100 hover:bg-emerald-50 text-sm"
                >
                  <b>{p.name}</b> <span className="text-xs text-slate-500">{p.phone}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder={isNe ? 'ग्राहकको नाम *' : 'Customer *'} className={inp + ' font-bold'} />
          <input value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" placeholder={isNe ? 'फोन' : 'Phone'} className={inp} />
          <input value={address} onChange={(e) => setAddress(e.target.value)} placeholder={isNe ? 'ठेगाना' : 'Address'} className={inp} />
          <input value={pan} onChange={(e) => setPan(e.target.value)} placeholder="PAN" className={inp} />
        </div>
        <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder={isNe ? 'विषय (उदा: ट्याक्टर तथा स्प्रेयर सम्बन्धी मूल्य प्रस्ताव)' : 'Subject'} className={inp} />
      </section>

      <section className="bg-white border border-slate-200 rounded-2xl p-3 sm:p-4">
        <OrderLinesEditor lines={lines} onChange={setLines} privileged={privileged} showStock={false} />
      </section>

      <section className="bg-white border border-slate-200 rounded-2xl p-3 sm:p-4 space-y-2">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <label className="text-[11px] font-bold text-slate-600">
            {isNe ? 'बिल प्रकार' : 'Bill type'}
            <select value={billType} onChange={(e) => setBillType(e.target.value as 'VAT' | 'NON_VAT')} className={inp + ' mt-0.5 bg-white font-normal'}>
              <option value="NON_VAT">{isNe ? 'भ्याट बिना' : 'No VAT'}</option>
              <option value="VAT">{isNe ? 'भ्याट १३% सहित' : 'With 13% VAT'}</option>
            </select>
          </label>
          <label className="text-[11px] font-bold text-slate-600">
            {isNe ? 'कुल छुट %' : 'Discount %'}
            <input type="number" min={0} max={privileged ? 100 : 10} value={discount} onChange={(e) => setDiscount(privileged ? Number(e.target.value) : Math.min(10, Number(e.target.value)))} className={inp + ' mt-0.5 font-normal'} />
          </label>
          <label className="text-[11px] font-bold text-slate-600">
            {isNe ? 'ढुवानी (रू.)' : 'Freight'}
            <input type="number" min={0} value={freight} onChange={(e) => setFreight(Number(e.target.value))} className={inp + ' mt-0.5 font-normal'} />
          </label>
          <label className="text-[11px] font-bold text-slate-600">
            {isNe ? 'मान्य हुने मिति' : 'Valid until'}
            <input
              type="date"
              value={validAd}
              onChange={(e) => {
                setValidAd(e.target.value);
                setValidBs(adStringToBs(e.target.value));
              }}
              className={inp + ' mt-0.5 font-normal'}
            />
            <span className="font-mono text-emerald-800">{validBs}</span>
          </label>
        </div>
        <input value={paymentTerms} onChange={(e) => setPaymentTerms(e.target.value)} placeholder={isNe ? 'भुक्तानी सर्त' : 'Payment terms'} className={inp} />
        <input value={deliveryTerms} onChange={(e) => setDeliveryTerms(e.target.value)} placeholder={isNe ? 'डेलिभरी सर्त' : 'Delivery terms'} className={inp} />
        <input value={warranty} onChange={(e) => setWarranty(e.target.value)} placeholder={isNe ? 'ग्यारेन्टी / वारेन्टी (भए)' : 'Warranty'} className={inp} />
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder={isNe ? 'अन्य टिप्पणी' : 'Notes'} className={inp} />
      </section>

      {err && <div className="text-sm font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-2">{err}</div>}

      <div className="fixed left-0 right-0 bottom-[60px] lg:bottom-0 lg:left-72 z-40 bg-white border-t-2 border-emerald-600 shadow-2xl px-3 py-2">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 flex-wrap">
          <div>
            <div className="text-[11px] text-slate-500 font-bold">
              {isNe ? 'कुल जम्मा' : 'Total'}
              {billType === 'VAT' ? (isNe ? ' (भ्याट सहित)' : ' (incl. VAT)') : ''}
            </div>
            <div className="text-lg font-black text-emerald-800">रू. {totals.grandTotal.toLocaleString('en-IN')}</div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => save('DRAFT')} className="px-3 py-2.5 text-xs font-bold rounded-xl bg-slate-800 text-white flex items-center gap-1.5">
              <Save className="w-4 h-4" />
              {isNe ? 'ड्राफ्ट सेभ' : 'Save draft'}
            </button>
            <button onClick={() => save('SENT')} className="px-4 py-2.5 text-sm font-black rounded-xl bg-emerald-600 text-white">
              {isNe ? 'सेभ (पठाइयो)' : 'Save as sent'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
