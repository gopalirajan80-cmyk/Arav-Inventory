import { InvoicePrintOptions, InvoicePrintOpts, loadPrintOpts, printArgsFor } from './InvoicePrintOptions';
import { PrintLetterhead, PrintFooter } from './PrintLetterhead';
import { printPage } from '../utils/printHelper';
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Invoice } from '../types';
import { QRCodeSVG } from 'qrcode.react';
import {
  Printer,
  X,
  Share2,
  FileText,
  Receipt,
  QrCode,
  CheckCircle,
  Ban,
  Trash2,
  Smartphone,
  FileDown,
  Loader2,
  Truck
} from 'lucide-react';
import {
  formatCurrency,
  toNepaliDigits,
  formatBsDateNepaliText
} from '../utils/nepaliCalendar';
import { amountInNepaliWords, amountInEnglishWords } from '../utils/vatCalculator';
import {
  buildInvoiceShareMessage,
  shareViaWhatsApp,
  shareViaViber,
  shareViaSms,
  sharePdfFileViaWebShareOrWhatsApp
} from '../utils/shareUtils';
import { downloadElementAsPdf, generateElementPdfFile } from '../utils/pdfHelper';
import { PaperSizeToggle } from './PaperSizeToggle';
import { UniversalShareModal } from './UniversalShareModal';

interface InvoicePrintModalProps {
  invoice: Invoice;
  onClose: () => void;
  onEditInvoice?: (id: string) => void;
  onCancelInvoice?: (id: string) => void;
  onDeleteInvoice?: (id: string) => void;
}

type PrintFormat = 'A4' | 'THERMAL_80' | 'THERMAL_58';

export const InvoicePrintModal: React.FC<InvoicePrintModalProps> = ({
  invoice,
  onClose,
  onEditInvoice,
  onCancelInvoice,
  onDeleteInvoice
}) => {
  const { company, parties, language, t, triggerQuickDispatch } = useApp();

  const getInitialFormat = (): PrintFormat => {
    if (company.defaultPrintFormat === 'THERMAL_58MM') return 'THERMAL_58';
    if (company.defaultPrintFormat === 'THERMAL_80MM') return 'THERMAL_80';
    return 'A4';
  };

  const [printFormat, setPrintFormat] = useState<PrintFormat>(getInitialFormat());
  const [printOpts, setPrintOpts] = useState<InvoicePrintOpts>(loadPrintOpts());
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isSharingPdf, setIsSharingPdf] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const isNe = language === 'ne';

  // Resolve customer phone number from invoice or from the stored parties database
  const resolvedCustomerPhone = React.useMemo(() => {
    if (invoice.customerPhone && invoice.customerPhone.trim()) {
      return invoice.customerPhone.trim();
    }
    const matchedParty = parties.find(
      (p) =>
        (invoice.partyId && p.id === invoice.partyId) ||
        p.name.trim().toLowerCase() === (invoice.customerName || '').trim().toLowerCase()
    );
    return matchedParty?.phone?.trim() || '';
  }, [invoice, parties]);

  const handleGenerateInvoicePdfFile = async (): Promise<File | null> => {
    const pdfFormat = printFormat === 'A4' ? 'a4' : printFormat === 'THERMAL_80' ? 'pos80' : 'pos58';
    const cleanInvNo = (invoice.invoiceNo || 'INV').replace(/[^a-zA-Z0-9_-]/g, '_');
    return await generateElementPdfFile({
      elementId: 'printable-invoice',
      fileName: `${cleanInvNo}_Bill.pdf`,
      format: pdfFormat
    });
  };

  const handleDirectWhatsAppPdfShare = async () => {
    try {
      setIsSharingPdf(true);
      const pdfFile = await handleGenerateInvoicePdfFile();
      const message = buildInvoiceShareMessage(invoice, company);
      await sharePdfFileViaWebShareOrWhatsApp({
        title: `Invoice ${invoice.invoiceNo} - ${company.name}`,
        message,
        phone: resolvedCustomerPhone,
        pdfFile,
        preferDirectWhatsAppNumber: Boolean(resolvedCustomerPhone)
      });
    } catch (err) {
      console.error('WhatsApp PDF share error', err);
    } finally {
      setIsSharingPdf(false);
    }
  };

  const handleDownloadPdf = async () => {
    try {
      setIsGeneratingPdf(true);
      const pdfFormat = printFormat === 'A4' ? 'a4' : printFormat === 'THERMAL_80' ? 'pos80' : 'pos58';
      const cleanInvNo = (invoice.invoiceNo || 'INV').replace(/[^a-zA-Z0-9_-]/g, '_');
      await downloadElementAsPdf({
        elementId: 'printable-invoice',
        fileName: `${cleanInvNo}_Bill.pdf`,
        format: pdfFormat,
        onProgress: setIsGeneratingPdf
      });
    } catch (err) {
      console.error('PDF generation error', err);
      setIsGeneratingPdf(false);
    }
  };

  const handlePrint = () => {
    printPage(printArgsFor('invoice', { mode: printFormat as any, isA4: printFormat === 'A4' }));
  };

  const words = isNe
    ? amountInNepaliWords(invoice.grandTotal)
    : amountInEnglishWords(invoice.grandTotal);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static print:overflow-visible print:block">


      <div className="relative w-full max-w-4xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[95vh] flex flex-col">
        
        {/* Top Control Bar (Hidden when printing) */}
        <div className="no-print bg-slate-900 text-white px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold tracking-tight">
              {invoice.billType === 'VAT' ? 'कर बीजक (Tax Invoice)' : 'Non-VAT अनुमानित बिल'} : {invoice.invoiceNo}
            </h2>
            {invoice.status === 'CANCELLED' && (
              <span className="bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                रद्द गरिएको (CANCELLED)
              </span>
            )}
          </div>

          <div className="flex items-center flex-wrap gap-2">
            <PaperSizeToggle />
            {/* Format toggle: A4 vs 80mm POS vs 58mm POS */}
            <div className="flex items-center gap-2 px-3 py-1 bg-slate-800 rounded-lg border border-slate-700">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Format:</span>
              <div className="flex items-center gap-0.5 text-xs">
                <button
                  onClick={() => setPrintFormat('A4')}
                  className={`px-2 py-0.5 font-medium rounded transition cursor-pointer ${
                    printFormat === 'A4'
                      ? 'bg-emerald-600 text-white shadow-xs font-bold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  A4
                </button>
                <button
                  onClick={() => setPrintFormat('THERMAL_80')}
                  className={`px-2 py-0.5 font-medium rounded transition cursor-pointer ${
                    printFormat === 'THERMAL_80'
                      ? 'bg-emerald-600 text-white shadow-xs font-bold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  80mm
                </button>
                <button
                  onClick={() => setPrintFormat('THERMAL_58')}
                  className={`px-2 py-0.5 font-medium rounded transition cursor-pointer ${
                    printFormat === 'THERMAL_58'
                      ? 'bg-emerald-600 text-white shadow-xs font-bold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  58mm
                </button>
              </div>
            </div>

            <InvoicePrintOptions value={printOpts} onChange={setPrintOpts} isA4={printFormat === 'A4'} />

            <button
              onClick={() => {
                triggerQuickDispatch(invoice.id, 'SALES');
                onClose();
              }}
              className="ky-btn ky-btn-indigo"
            >
              <Truck className="w-4 h-4" />
              <span>{isNe ? 'ढुवानी चलानी बनाउने' : 'Create Challan'}</span>
            </button>

            {/* Direct PDF Download button (सिधै PDF डाउनलोड) */}
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="ky-btn ky-btn-blue"
              title="सिधै कम्प्युटर वा मोबाइलमा PDF फाइल डाउनलोड गर्नुहोस्"
            >
              {isGeneratingPdf ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>{isNe ? 'PDF बन्दैछ...' : 'Creating PDF...'}</span>
                </>
              ) : (
                <>
                  <FileDown className="w-4 h-4 text-white" />
                  <span>{isNe ? '📄 सिधै PDF डाउनलोड' : 'Direct PDF Download'}</span>
                </>
              )}
            </button>

            {/* Print button */}
            <button
              onClick={handlePrint}
              className="ky-btn ky-btn-green"
            >
              <Printer className="w-4 h-4" />
              <span>{t.printNow}</span>
            </button>

            {/* Direct 1-Click PDF + WhatsApp (wa.me / Web Share) */}
            <button
              type="button"
              onClick={handleDirectWhatsAppPdfShare}
              disabled={isSharingPdf}
              className="ky-btn ky-btn-teal"
              title="PDF बिल र विवरण सिधै ग्राहकको WhatsApp नम्बर (wa.me) वा Web Share मा पठाउनुहोस्"
            >
              {isSharingPdf ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Smartphone className="w-3.5 h-3.5" />
              )}
              <span>{isNe ? '📲 WhatsApp PDF' : 'WhatsApp PDF'}</span>
            </button>

            {/* Share Modal (Customer Database Phone Selector + WhatsApp / SMS) */}
            <button
              onClick={() => setIsShareModalOpen(true)}
              className="ky-btn ky-btn-green"
              title="ग्राहकको फोन नम्बर छानेर WhatsApp वा SMS मा बिल पठाउनुहोस्"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>WhatsApp / SMS</span>
            </button>

            {/* Edit Bill button (items सहित सच्याउने) */}
            {invoice.status === 'ACTIVE' && onEditInvoice && (
              <button
                onClick={() => onEditInvoice(invoice.id)}
                className="ky-btn ky-btn-green"
                title="बिल सच्याउनुहोस् — सामान, परिमाण, दर सहित (Owner Key अनिवार्य)"
              >
                <span>✏️</span>
                <span className="hidden sm:inline">सच्याउने</span>
              </button>
            )}

            {/* Cancel Bill button */}
            {invoice.status === 'ACTIVE' && onCancelInvoice && (
              <button
                onClick={() => {
                  onCancelInvoice(invoice.id);
                }}
                className="ky-btn ky-btn-rose"
                title="Cancel Bill & Return Stock"
              >
                <Ban className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t.cancelBill}</span>
              </button>
            )}

            {/* Delete Bill button */}
            {onDeleteInvoice && (
              <button
                onClick={() => {
                  onDeleteInvoice(invoice.id);
                }}
                className="ky-btn ky-btn-rose"
                title="बिल सदाको लागि मेटाउने (Owner Key अनिवार्य)"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">मेटाउने</span>
              </button>
            )}

            {/* Close */}
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-md transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Container */}
        <div
          id="printable-invoice"
          className="overflow-y-auto p-4 sm:p-8 flex justify-center bg-slate-100 flex-1 print:p-0 print:bg-white print:block"
        >
          <div
            className={`bg-white shadow-md border border-slate-300 text-slate-900 transition-all ${
              printFormat === 'A4'
                ? 'w-full max-w-[800px] p-6 sm:p-8 text-xs font-sans'
                : printFormat === 'THERMAL_80'
                ? 'w-[320px] p-3 text-[11px] font-mono leading-tight'
                : 'w-[230px] p-2 text-[10px] font-mono leading-tight'
            }`}
          >
            {printFormat === 'A4' ? (
              /* ================== A4 STANDARD TAX INVOICE ================== */
              <div className="space-y-4">
                
                <PrintLetterhead company={company as any} topNote={invoice.billType === 'VAT' ? 'Government of Nepal · IRD Approved Format' : 'Internal Estimate / Quotation'} docTitle={invoice.billType === 'VAT' ? 'कर चालान (TAX INVOICE)' : 'अनुमानित बिल (ESTIMATE BILL)'} />

                {/* Invoice Meta Grid */}
                <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-3 rounded-sm border border-slate-200">
                  <div className="space-y-1">
                    <div>
                      <span className="font-semibold text-slate-700">बीजक नं. (Invoice No): </span>
                      <span className="font-mono font-bold text-slate-900 text-sm">{invoice.invoiceNo}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">आर्थिक वर्ष (Fiscal Year): </span>
                      <span className="font-mono">{invoice.fiscalYear}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">मिति (Date B.S.): </span>
                      <span className="font-bold">{formatBsDateNepaliText(invoice.dateBs)}</span>
                      <span className="text-slate-500 font-mono text-[11px] ml-1">({invoice.dateBs})</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">Date (A.D.): </span>
                      <span className="font-mono">{invoice.dateAd} {invoice.time}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">बिल तयार गर्ने (Billed By): </span>
                      <span className="font-bold text-[#1e3f73]">{invoice.billedBy || 'राजन गोपाली'}</span>
                    </div>
                  </div>

                  <div className="space-y-1 border-l border-slate-200 pl-4">
                    <div>
                      <span className="font-semibold text-slate-700">खरिदकर्ताको नाम (Buyer): </span>
                      <span className="font-bold text-slate-900">{invoice.customerName}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">ग्राहकको प्यान नं. (Buyer PAN): </span>
                      <span className="font-mono font-bold">{invoice.customerPan || '-'}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">ठेगाना (Address): </span>
                      <span>{invoice.customerAddress || '-'}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">भुक्तानी माध्यम (Payment): </span>
                      <span className="font-semibold">{invoice.paymentMode}</span>
                    </div>
                    {invoice.paymentMode === 'BANK_FONEPAY' && (
                      <div className="mt-1 pt-1 border-t border-slate-200 text-[11px] text-blue-900 bg-blue-50/60 p-1 rounded font-mono">
                        <div><strong>बैंक:</strong> {invoice.bankName || '-'}</div>
                        <div><strong>खाता नं:</strong> {invoice.bankAccountNo || '-'}</div>
                        {invoice.transactionRef && <div><strong>Ref No:</strong> {invoice.transactionRef}</div>}
                      </div>
                    )}
                  </div>
                </div>

                {/* Items Table */}
                <div className="overflow-x-auto">
                  <table className="ky-items w-full border-collapse border border-slate-300 text-xs">
                    <thead>
                      <tr className="bg-[#2b5797] text-white font-bold text-center">
                        <th className="border border-slate-300 py-1.5 px-1.5 w-8">क्र.सं.</th>
                        <th className="border border-slate-300 py-1.5 px-2 w-16">कोड</th>
                        <th className="border border-slate-300 py-1.5 px-3 text-left">सामानको विवरण (Description)</th>
                        <th className="border border-slate-300 py-1.5 px-2 w-14">साइज</th>
                        <th className="border border-slate-300 py-1.5 px-2 w-12">परिमाण</th>
                        <th className="border border-slate-300 py-1.5 px-2 w-12">एकाइ</th>
                        <th className="border border-slate-300 py-1.5 px-2 text-right w-18">दर (रु)</th>
                        <th className="border border-slate-300 py-1.5 px-1.5 text-center w-12">छुट %</th>
                        <th className="border border-slate-300 py-1.5 px-2 text-right w-18">छुट रकम</th>
                        <th className="border border-slate-300 py-1.5 px-2 text-right w-22">जम्मा (रु)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {invoice.items.map((line, idx) => {
                        const lineGross = line.quantity * line.rate;
                        const lineDiscAmt = (lineGross * (line.discountPercent || 0)) / 100;
                        const lineNet = line.amount !== undefined ? line.amount : (lineGross - lineDiscAmt);
                        return (
                          <tr key={idx} className="text-slate-900 odd:bg-white even:bg-slate-100">
                            <td className="border border-slate-300 py-1 px-1.5 text-center font-mono font-medium">
                              {idx + 1}
                            </td>
                            <td className="border border-slate-300 py-1 px-2 text-center font-mono text-[11px] font-bold">
                              {line.code || '-'}
                            </td>
                            <td className="border border-slate-300 py-1 px-3">
                              <div className="flex flex-col">
                                {line.hsCode && (
                                  <span className="text-[9px] text-slate-500 font-bold uppercase tracking-tight">
                                    HS CODE: {line.hsCode}
                                  </span>
                                )}
                                <span className="font-semibold text-slate-900">{line.name}</span>
                                {line.isVatExempt && (
                                  <span className="text-[10px] text-[#1e3f73] font-bold">
                                    [कर छुट]
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="border border-slate-300 py-1 px-2 text-center font-medium">
                              {line.size || '-'}
                            </td>
                            <td className="border border-slate-300 py-1 px-2 text-center font-mono font-bold">
                              {line.quantity}
                            </td>
                            <td className="border border-slate-300 py-1 px-2 text-center text-[11px]">
                              {line.unit}
                            </td>
                            <td className="border border-slate-300 py-1 px-2 text-right font-mono tabular-nums">
                              {line.rate.toFixed(2)}
                            </td>
                            <td className="border border-slate-300 py-1 px-1.5 text-center font-mono">
                              {(line.discountPercent || 0) > 0 ? `${line.discountPercent}%` : '-'}
                            </td>
                            <td className="border border-slate-300 py-1 px-2 text-right font-mono tabular-nums text-rose-800">
                              {lineDiscAmt > 0 ? lineDiscAmt.toFixed(2) : '-'}
                            </td>
                            <td className="border border-slate-300 py-1 px-2 text-right font-mono tabular-nums font-bold">
                              {lineNet.toFixed(2)}
                            </td>
                          </tr>
                        );
                      })}
                      {Array.from({ length: Math.max(0, 3 - invoice.items.length) }).map((_, i) => (
                        <tr key={`empty-${i}`} className="border-b border-slate-300 h-6">
                          <td className="border border-slate-300"></td>
                          <td className="border border-slate-300"></td>
                          <td className="border border-slate-300"></td>
                          <td className="border border-slate-300"></td>
                          <td className="border border-slate-300"></td>
                          <td className="border border-slate-300"></td>
                          <td className="border border-slate-300"></td>
                          <td className="border border-slate-300"></td>
                          <td className="border border-slate-300"></td>
                          <td className="border border-slate-300"></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Calculation & Summary Footer Grid */}
                <div className="grid grid-cols-12 gap-4 text-xs pt-1">
                  <div className="col-span-7 flex flex-col justify-between">
                    <div className="bg-slate-50 p-2.5 rounded-sm border border-slate-200">
                      <span className="font-semibold text-slate-700">अक्षरूपी (In Words): </span>
                      <p className="font-medium text-slate-900 mt-0.5 leading-snug">
                        {words}
                      </p>
                    </div>

                    <div className="text-[10px] text-slate-500 mt-2">
                      <p>१. बिकेको सामान फिर्ता वा साटिने छैन।</p>
                      <p>२. सामान बुझ्नु अगाडि राम्रोसँग परीक्षण गर्नुहोला।</p>
                    </div>

                    {/* Embedded Scan-to-Verify QR Code */}
                    <div className="flex items-center gap-3 bg-slate-50 p-2 rounded-lg border border-slate-300 mt-2">
                      <div className="p-1 bg-white rounded border border-slate-300 shrink-0 shadow-2xs">
                        <QRCodeSVG
                          value={JSON.stringify({
                            invoiceNo: invoice.invoiceNo,
                            invoiceId: invoice.id,
                            grandTotal: invoice.grandTotal,
                            dateBs: invoice.dateBs,
                            dateAd: invoice.dateAd,
                            panVatNo: company.panVatNo,
                            companyName: company.name
                          })}
                          size={64}
                          level="M"
                        />
                      </div>
                      <div className="text-[10px] text-slate-700 space-y-0.5">
                        <div className="font-bold text-slate-900 flex items-center gap-1">
                          <QrCode className="w-3.5 h-3.5 text-[#2b5797]" />
                          <span>{isNe ? 'प्रमाणित QR कोड (Scan to Verify)' : 'Scan to Verify Invoice'}</span>
                        </div>
                        <p className="font-mono text-[9px] text-slate-600">ID: <span className="font-bold">{invoice.id.slice(0, 14)}</span></p>
                        <p className="font-mono text-[9px] text-slate-700">रकम: <span className="font-bold text-[#1e3f73]">Rs. {invoice.grandTotal.toFixed(2)}</span> | मिति: {invoice.dateBs}</p>
                        <p className="text-[8px] text-slate-500 font-sans">स्क्यान गरी बिलको सत्यता जाँच्न सकिन्छ।</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-10 mt-6 text-center text-xs text-slate-700">
                      <div className="border-t border-slate-400 pt-1">
                        खरिदकर्ताको हस्ताक्षर (Receiver)
                      </div>
                      <div className="border-t border-slate-400 pt-1 font-bold text-slate-900">
                        <div className="text-[#1e3f73] font-extrabold mb-0.5">तयार गर्ने: {invoice.billedBy || 'राजन गोपाली'}</div>
                        <div className="text-[10px] text-slate-500 font-normal">अधिकृत हस्ताक्षर (Authorized Signatory)</div>
                      </div>
                    </div>
                  </div>

                  <div className="col-span-5">
                    <table className="w-full border-collapse border border-slate-900 text-xs">
                      <tbody>
                        <tr className="border-b border-slate-300">
                          <td className="py-1 px-2 font-medium text-slate-700 border-r border-slate-900">उप-जम्मा (Sub Total)</td>
                          <td className="py-1 px-2 text-right font-mono tabular-nums font-semibold">{invoice.subtotal.toFixed(2)}</td>
                        </tr>
                        {invoice.discountAmount > 0 && (
                          <tr className="border-b border-slate-300">
                            <td className="py-1 px-2 font-medium text-slate-700 border-r border-slate-900">छुट ({invoice.discountPercent}%)</td>
                            <td className="py-1 px-2 text-right font-mono tabular-nums text-rose-700">-{invoice.discountAmount.toFixed(2)}</td>
                          </tr>
                        )}
                        {invoice.freightCharge > 0 && (
                          <tr className="border-b border-slate-300">
                            <td className="py-1 px-2 font-medium text-slate-700 border-r border-slate-900">ढुवानी शुल्क (Freight)</td>
                            <td className="py-1 px-2 text-right font-mono tabular-nums">+{invoice.freightCharge.toFixed(2)}</td>
                          </tr>
                        )}
                        {invoice.exemptAmount > 0 && (
                          <tr className="border-b border-slate-300">
                            <td className="py-1 px-2 font-medium text-slate-700 border-r border-slate-900">कर छुट रकम (Exempt)</td>
                            <td className="py-1 px-2 text-right font-mono tabular-nums">{invoice.exemptAmount.toFixed(2)}</td>
                          </tr>
                        )}
                        {invoice.billType === 'VAT' && (
                          <>
                            <tr className="border-b border-slate-300 bg-slate-50">
                              <td className="py-1 px-2 font-semibold text-slate-800 border-r border-slate-900">करयोग्य रकम (Taxable)</td>
                              <td className="py-1 px-2 text-right font-mono tabular-nums font-semibold">{invoice.taxableAmount.toFixed(2)}</td>
                            </tr>
                            <tr className="border-b border-slate-300">
                              <td className="py-1 px-2 font-semibold text-slate-800 border-r border-slate-900">१३% भ्याट (VAT 13%)</td>
                              <td className="py-1 px-2 text-right font-mono tabular-nums font-bold text-blue-900">{invoice.vatAmount.toFixed(2)}</td>
                            </tr>
                          </>
                        )}
                        <tr className="bg-slate-900 text-white font-bold text-sm">
                          <td className="py-1.5 px-2 border-r border-slate-700">हालको बिल (Bill Total)</td>
                          <td className="py-1.5 px-2 text-right font-mono tabular-nums text-[#8fbfe6]">
                            रू. {invoice.grandTotal.toFixed(2)}
                          </td>
                        </tr>
                        {invoice.previousDue !== undefined && invoice.previousDue > 0 && (
                          <tr className="border-b border-slate-300 bg-amber-50 text-amber-950 text-xs">
                            <td className="py-1 px-2 font-medium border-r border-slate-900">पुरानो लिन बाँकी (Previous Due)</td>
                            <td className="py-1 px-2 text-right font-mono tabular-nums font-semibold">
                              रू. {invoice.previousDue.toFixed(2)}
                            </td>
                          </tr>
                        )}
                        <tr className="border-b border-slate-300 bg-slate-100 font-bold text-xs">
                          <td className="py-1 px-2 border-r border-slate-900">कुल तिर्नुपर्ने (Total Payable)</td>
                          <td className="py-1 px-2 text-right font-mono tabular-nums">
                            रू. {((invoice.previousDue || 0) + invoice.grandTotal).toFixed(2)}
                          </td>
                        </tr>
                        <tr className="border-b border-slate-300 bg-[#e8f2f8] text-[#1e3f73] font-bold text-xs">
                          <td className="py-1 px-2 border-r border-slate-900">
                            आज बुझाएको रकम ({invoice.paymentMode === 'CASH' ? 'नगद' : invoice.paymentMode === 'BANK_FONEPAY' ? 'बैंक' : 'भुक्तानी'})
                          </td>
                          <td className="py-1 px-2 text-right font-mono tabular-nums text-[#1e3f73]">
                            रू. {(invoice.amountPaid !== undefined ? invoice.amountPaid : (invoice.paymentMode === 'CREDIT' ? 0 : invoice.grandTotal)).toFixed(2)}
                          </td>
                        </tr>
                        <tr className="bg-rose-50 border-t-2 border-slate-900 text-rose-950 font-black text-sm">
                          <td className="py-1.5 px-2 border-r border-slate-900">हालसम्म बाँकी रकम (Net Remaining Due)</td>
                          <td className="py-1.5 px-2 text-right font-mono tabular-nums text-rose-700">
                            रू. {(invoice.remainingDue !== undefined ? invoice.remainingDue : Math.max(0, ((invoice.previousDue || 0) + invoice.grandTotal) - (invoice.amountPaid ?? (invoice.paymentMode === 'CREDIT' ? 0 : invoice.grandTotal)))).toFixed(2)}
                          </td>
                        </tr>
                        {invoice.paymentDueDate && (
                          <tr className="bg-amber-100 text-amber-950 text-[11px] font-bold">
                            <td colSpan={2} className="py-1 px-2 text-center">
                              रकम बुझाउने अन्तिम म्याद (Payment Due Date): {invoice.paymentDueDate}
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {invoice.photoUrl && (
                  <div className="mt-3 p-2.5 border border-dashed border-slate-400 rounded-lg bg-slate-50 text-center">
                    <span className="text-[11px] font-bold text-slate-700 block mb-1">
                      संलग्न रसिद / सामान / चलानको फोटो (Attached Document / Goods Photo):
                    </span>
                    <img
                      src={invoice.photoUrl}
                      alt="Invoice Attachment"
                      className="max-h-40 mx-auto object-contain rounded border border-slate-300 shadow-2xs"
                    />
                  </div>
                )}

                <PrintFooter company={company as any} />
              </div>
            ) : printFormat === 'THERMAL_80' ? (
              /* ================== 80MM (3 INCH) THERMAL POS RECEIPT ================== */
              <div className="space-y-2.5">
                {/* Store Header */}
                <div className="text-center border-b border-dashed border-slate-500 pb-2 space-y-0.5">
                  <h1 className="text-sm font-black text-slate-900 uppercase tracking-tight">{company.name}</h1>
                  <p className="text-[10px] text-slate-700 font-medium">{company.address}</p>
                  <p className="text-[10px] text-slate-700">फोन: {company.phone}</p>
                  <div className="font-bold text-[10px] text-slate-900 mt-0.5">
                    PAN / VAT: {company.panVatNo}
                  </div>
                  <div className="font-black text-xs uppercase tracking-wider pt-1 border-t border-slate-300 mt-1">
                    {invoice.billType === 'VAT' ? 'कर बीजक (TAX INVOICE)' : 'अनुमानित बिल (ESTIMATE BILL)'}
                  </div>
                </div>

                {/* Bill Meta */}
                <div className="text-[10px] border-b border-dashed border-slate-500 pb-2 space-y-0.5">
                  <div className="flex justify-between">
                    <span>बिल नं. (Bill No):</span>
                    <span className="font-bold font-mono">{invoice.invoiceNo}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>मिति (Date BS):</span>
                    <span>{invoice.dateBs} ({invoice.dateAd})</span>
                  </div>
                  <div className="flex justify-between">
                    <span>समय (Time):</span>
                    <span>{invoice.time}</span>
                  </div>
                  <div className="flex justify-between font-semibold text-slate-900 pt-0.5 border-t border-slate-200">
                    <span>खरिदकर्ता (Buyer):</span>
                    <span>{invoice.customerName}</span>
                  </div>
                  {invoice.customerPan && (
                    <div className="flex justify-between">
                      <span>प्यान नं. (PAN):</span>
                      <span className="font-mono">{invoice.customerPan}</span>
                    </div>
                  )}
                  {invoice.customerPhone && (
                    <div className="flex justify-between">
                      <span>सम्पर्क (Mobile):</span>
                      <span className="font-mono">{invoice.customerPhone}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold">
                    <span>भुक्तानी (Payment):</span>
                    <span>{invoice.paymentMode}</span>
                  </div>
                  <div className="flex justify-between pt-0.5 border-t border-slate-200 text-slate-800">
                    <span>बिलिङ गर्ने (Billed By):</span>
                    <span className="font-bold">{invoice.billedBy || 'राजन गोपाली'}</span>
                  </div>
                </div>

                {/* Items Table */}
                <div className="border-b border-dashed border-slate-500 pb-2">
                  <div className="flex justify-between font-bold text-[10px] border-b border-slate-900 pb-1 mb-1">
                    <span className="w-1/2">सामान (Item)</span>
                    <span className="w-1/4 text-center">परिमाण</span>
                    <span className="w-1/4 text-right">रकम (Rs)</span>
                  </div>
                  {invoice.items.map((line, i) => (
                    <div key={i} className="py-1 border-b border-slate-100 space-y-0.5">
                      <div className="font-bold text-slate-900 flex justify-between">
                        <span>{i + 1}. {line.name}</span>
                        {line.isVatExempt && <span className="text-[9px] text-emerald-800">[करछुट]</span>}
                      </div>
                      <div className="flex justify-between text-[10px] font-mono text-slate-700 pl-3">
                        <span>{line.quantity} {line.unit} x @{line.rate}</span>
                        <span className="font-bold">{(line.quantity * line.rate).toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Totals & Tax Summary */}
                <div className="text-[10px] space-y-1 border-b border-dashed border-slate-500 pb-2">
                  <div className="flex justify-between text-slate-700">
                    <span>उप-जम्मा (Subtotal):</span>
                    <span className="font-mono">{invoice.subtotal.toFixed(2)}</span>
                  </div>
                  {invoice.discountAmount > 0 && (
                    <div className="flex justify-between text-rose-700">
                      <span>छुट (Discount {invoice.discountPercent}%):</span>
                      <span className="font-mono">-{invoice.discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  {invoice.freightCharge > 0 && (
                    <div className="flex justify-between">
                      <span>ढुवानी (Freight):</span>
                      <span className="font-mono">+{invoice.freightCharge.toFixed(2)}</span>
                    </div>
                  )}
                  {invoice.billType === 'VAT' && (
                    <>
                      <div className="flex justify-between text-slate-700">
                        <span>करयोग्य रकम (Taxable):</span>
                        <span className="font-mono">{invoice.taxableAmount.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-bold text-slate-900">
                        <span>१३% भ्याट (VAT 13%):</span>
                        <span className="font-mono">{invoice.vatAmount.toFixed(2)}</span>
                      </div>
                    </>
                  )}
                  <div className="flex justify-between font-black text-xs pt-1 border-t border-slate-900 text-slate-900">
                    <span>हालको बिल (Grand Total):</span>
                    <span className="font-mono">Rs. {invoice.grandTotal.toFixed(2)}</span>
                  </div>
                  {invoice.previousDue !== undefined && invoice.previousDue > 0 && (
                    <div className="flex justify-between text-slate-700">
                      <span>पुरानो बाँकी (Previous Due):</span>
                      <span className="font-mono">Rs. {invoice.previousDue.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-emerald-800">
                    <span>आज बुझाएको (Paid):</span>
                    <span className="font-mono">Rs. {(invoice.amountPaid !== undefined ? invoice.amountPaid : (invoice.paymentMode === 'CREDIT' ? 0 : invoice.grandTotal)).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-black text-xs text-rose-700 pt-0.5 border-t border-slate-300">
                    <span>बाँकी बक्यौता (Net Remaining Due):</span>
                    <span className="font-mono">Rs. {(invoice.remainingDue !== undefined ? invoice.remainingDue : Math.max(0, ((invoice.previousDue || 0) + invoice.grandTotal) - (invoice.amountPaid ?? (invoice.paymentMode === 'CREDIT' ? 0 : invoice.grandTotal)))).toFixed(2)}</span>
                  </div>
                </div>

                {/* Scan to Verify QR Code */}
                <div className="flex flex-col items-center justify-center pt-2 pb-1 border-t border-dashed border-slate-500 text-center">
                  <div className="p-1 bg-white rounded border border-slate-300 mb-1">
                    <QRCodeSVG
                      value={JSON.stringify({
                        invoiceNo: invoice.invoiceNo,
                        invoiceId: invoice.id,
                        grandTotal: invoice.grandTotal,
                        dateBs: invoice.dateBs,
                        panVatNo: company.panVatNo
                      })}
                      size={68}
                      level="M"
                    />
                  </div>
                  <span className="text-[9px] font-bold text-slate-800">Scan to Verify Invoice</span>
                  <span className="text-[8px] font-mono text-slate-600">{invoice.invoiceNo} • Rs. {invoice.grandTotal.toFixed(2)}</span>
                </div>

                {/* Footer Notice */}
                <div className="text-center text-[9px] pt-1 text-slate-700 space-y-0.5">
                  <p className="font-bold">नेपाल भ्याट तथा राजस्व मापदण्ड अनुकूल</p>
                  <p>सामान खरिद गर्नुभएकोमा धन्यवाद ! पुनः पाल्नुहोला ।</p>
                  <p className="font-mono text-[8px] text-slate-500 pt-0.5">KrishiYantra ERP 80mm POS</p>
                </div>
              </div>
            ) : (
              /* ================== 58MM (2 INCH MINI) THERMAL POS RECEIPT ================== */
              <div className="space-y-2 font-mono text-[10px]">
                {/* Store Header */}
                <div className="text-center border-b border-dashed border-slate-600 pb-1.5 space-y-0.5">
                  <h1 className="text-xs font-black uppercase text-slate-900 leading-tight">{company.name}</h1>
                  <p className="text-[9px] leading-tight text-slate-700">{company.address}</p>
                  <p className="text-[9px]">Ph: {company.phone}</p>
                  <p className="text-[9px] font-bold">PAN/VAT: {company.panVatNo}</p>
                  <div className="font-black text-[10px] uppercase border-t border-slate-300 pt-0.5 mt-0.5">
                    {invoice.billType === 'VAT' ? 'TAX INVOICE (कर बीजक)' : 'ESTIMATE BILL'}
                  </div>
                </div>

                {/* Bill Meta */}
                <div className="border-b border-dashed border-slate-600 pb-1.5 space-y-0.5 text-[9px]">
                  <div className="flex justify-between">
                    <span>No:</span>
                    <span className="font-bold">{invoice.invoiceNo}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>BS:</span>
                    <span>{invoice.dateBs}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Time:</span>
                    <span>{invoice.time}</span>
                  </div>
                  <div className="flex justify-between font-bold pt-0.5">
                    <span>Buyer:</span>
                    <span className="truncate max-w-[120px]">{invoice.customerName}</span>
                  </div>
                  {invoice.customerPan && (
                    <div className="flex justify-between">
                      <span>PAN:</span>
                      <span>{invoice.customerPan}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Mode:</span>
                    <span>{invoice.paymentMode}</span>
                  </div>
                  <div className="flex justify-between font-bold pt-0.5 border-t border-slate-200">
                    <span>Billed By:</span>
                    <span>{invoice.billedBy || 'राजन गोपाली'}</span>
                  </div>
                </div>

                {/* Items List (Narrow Format) */}
                <div className="border-b border-dashed border-slate-600 pb-1.5 space-y-1 text-[9px]">
                  <div className="font-bold border-b border-slate-900 pb-0.5 flex justify-between uppercase">
                    <span>ITEM</span>
                    <span>AMOUNT</span>
                  </div>
                  {invoice.items.map((line, i) => (
                    <div key={i} className="border-b border-slate-100 pb-0.5">
                      <div className="font-bold text-slate-900 truncate">
                        {i + 1}. {line.name}
                      </div>
                      <div className="flex justify-between text-slate-700 font-mono pl-2">
                        <span>{line.quantity}{line.unit} x @{line.rate}</span>
                        <span className="font-bold">{(line.quantity * line.rate).toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Summary Totals */}
                <div className="space-y-0.5 text-[9px] border-b border-dashed border-slate-600 pb-1.5">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>{invoice.subtotal.toFixed(2)}</span>
                  </div>
                  {invoice.discountAmount > 0 && (
                    <div className="flex justify-between text-rose-700">
                      <span>Discount ({invoice.discountPercent}%):</span>
                      <span>-{invoice.discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  {invoice.billType === 'VAT' && (
                    <>
                      <div className="flex justify-between">
                        <span>Taxable:</span>
                        <span>{invoice.taxableAmount.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-bold">
                        <span>VAT (13%):</span>
                        <span>{invoice.vatAmount.toFixed(2)}</span>
                      </div>
                    </>
                  )}
                  <div className="flex justify-between font-black text-[11px] pt-0.5 border-t border-slate-800 text-slate-900">
                    <span>TOTAL:</span>
                    <span>Rs. {invoice.grandTotal.toFixed(2)}</span>
                  </div>
                  {invoice.previousDue !== undefined && invoice.previousDue > 0 && (
                    <div className="flex justify-between">
                      <span>Old Due:</span>
                      <span>Rs. {invoice.previousDue.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-emerald-800">
                    <span>Paid:</span>
                    <span>Rs. {(invoice.amountPaid !== undefined ? invoice.amountPaid : (invoice.paymentMode === 'CREDIT' ? 0 : invoice.grandTotal)).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-black text-[10px] text-rose-700 pt-0.5 border-t border-slate-300">
                    <span>NET DUE:</span>
                    <span>Rs. {(invoice.remainingDue !== undefined ? invoice.remainingDue : Math.max(0, ((invoice.previousDue || 0) + invoice.grandTotal) - (invoice.amountPaid ?? (invoice.paymentMode === 'CREDIT' ? 0 : invoice.grandTotal)))).toFixed(2)}</span>
                  </div>
                </div>

                {/* Compact Scan to Verify QR Code */}
                <div className="flex flex-col items-center justify-center pt-1.5 pb-0.5 border-t border-dashed border-slate-500 text-center">
                  <div className="p-1 bg-white rounded border border-slate-300 mb-0.5">
                    <QRCodeSVG
                      value={JSON.stringify({
                        invoiceNo: invoice.invoiceNo,
                        invoiceId: invoice.id,
                        grandTotal: invoice.grandTotal,
                        dateBs: invoice.dateBs
                      })}
                      size={54}
                      level="M"
                    />
                  </div>
                  <span className="text-[8px] font-bold text-slate-800">Scan to Verify</span>
                </div>

                {/* Compact Footer */}
                <div className="text-center text-[8px] text-slate-700 space-y-0.5 pt-0.5">
                  <p>धन्यवाद ! पुनः पाल्नुहोला ।</p>
                  <p className="font-mono">KrishiYantra 58mm POS</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Universal WhatsApp / SMS Share Modal */}
      <UniversalShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        title={isNe ? `बीजक नं. ${invoice.invoiceNo} - WhatsApp / Message शेयर` : `Share Invoice ${invoice.invoiceNo} via WhatsApp / SMS`}
        recipientName={invoice.customerName}
        initialPhone={resolvedCustomerPhone}
        message={buildInvoiceShareMessage(invoice, company)}
        bankDetails={company.bankAccounts && company.bankAccounts[0]}
        onGeneratePdfFile={handleGenerateInvoicePdfFile}
        pdfLabel={isNe ? `बीजक नं. ${invoice.invoiceNo} (PDF)` : `Invoice ${invoice.invoiceNo} (PDF)`}
      />
    </div>
  );
};
