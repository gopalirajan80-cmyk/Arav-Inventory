import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Item, ItemCategory, Party, PurchaseRecord, Invoice, BillType, PaymentMode } from '../types';
import {
  FileSpreadsheet,
  Upload,
  Download,
  CheckCircle2,
  AlertCircle,
  FileText,
  ArrowRight,
  Database,
  RefreshCw,
  Users,
  ShoppingBag,
  Receipt,
  Boxes,
  SlidersHorizontal,
  Table,
  Eye,
  Check,
  PackageCheck
} from 'lucide-react';
import {
  downloadAgricultureTemplate,
  downloadCustomerImportTemplate,
  downloadPurchaseImportTemplate,
  downloadSalesImportTemplate,
  parseExcelFile,
  parseExcelNumericValue,
  validatePanVat,
  validateDate
} from '../utils/excelEngine';
import { toNepaliDigits, formatCurrency } from '../utils/nepaliCalendar';

type ImportMode = 'ITEMS' | 'CUSTOMERS' | 'PURCHASES' | 'SALES';

export const ExcelWizardScreen: React.FC = () => {
  const {
    items,
    invoices,
    purchases,
    parties,
    company,
    importItemsList,
    importPartiesList,
    importPurchasesList,
    importInvoicesList,
    setActiveTab,
    language,
    t
  } = useApp();

  const isNe = language === 'ne';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [activeMode, setActiveMode] = useState<ImportMode>('ITEMS');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [excelHeaders, setExcelHeaders] = useState<string[]>([]);
  const [excelRows, setExcelRows] = useState<any[][]>([]);
  const [importStatus, setImportStatus] = useState<'IDLE' | 'PARSED' | 'SUCCESS'>('IDLE');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  // Interactive Column Mapping state: maps field keys to excel column index (0-based, or -1 for unmapped)
  const [columnMap, setColumnMap] = useState<Record<string, number>>({
    code: -1,
    name: -1,
    purchasePrice: -1,
    sellingPrice: -1,
    stock: -1,
    category: -1,
    unit: -1,
    // Customers
    custDate: -1,
    custBill: -1,
    custName: -1,
    custAddress: -1,
    custPhone: -1,
    custPan: -1,
    custTotal: -1,
    custPay: -1,
    custDue: -1,
    // Purchases
    purDate: -1,
    purBill: -1,
    purSupp: -1,
    purPan: -1,
    purSummary: -1,
    purTaxable: -1,
    purExempt: -1,
    purVat: -1,
    purTotal: -1,
    purMode: -1,
    // Sales
    saleDate: -1,
    saleBill: -1,
    saleType: -1,
    saleCust: -1,
    salePan: -1,
    saleAddr: -1,
    saleTaxable: -1,
    saleExempt: -1,
    saleVat: -1,
    saleTotal: -1,
    saleMode: -1
  });

  // Default fallback values if Excel column is unmapped
  const [defaultCategory, setDefaultCategory] = useState<ItemCategory>('SPARE_PARTS');
  const [defaultUnit, setDefaultUnit] = useState<string>('Pcs');
  const [customerCalcMode, setCustomerCalcMode] = useState<'SUBTRACT_PAY' | 'DUE_IS_NET'>('SUBTRACT_PAY');

  // Parsed data previews
  const [mappedItems, setMappedItems] = useState<Item[]>([]);
  const [mappedParties, setMappedParties] = useState<Party[]>([]);
  const [mappedPurchases, setMappedPurchases] = useState<PurchaseRecord[]>([]);
  const [mappedSales, setMappedSales] = useState<Invoice[]>([]);

  const handleModeChange = (mode: ImportMode) => {
    setActiveMode(mode);
    setUploadedFileName('');
    setExcelHeaders([]);
    setExcelRows([]);
    setImportStatus('IDLE');
    setErrorMessage('');
    setValidationErrors([]);
    setMappedItems([]);
    setMappedParties([]);
    setMappedPurchases([]);
    setMappedSales([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDownloadTemplate = () => {
    switch (activeMode) {
      case 'ITEMS':
        downloadAgricultureTemplate();
        break;
      case 'CUSTOMERS':
        downloadCustomerImportTemplate();
        break;
      case 'PURCHASES':
        downloadPurchaseImportTemplate();
        break;
      case 'SALES':
        downloadSalesImportTemplate();
        break;
    }
  };

  const autoDetectColumnMappings = (headers: string[], mode: ImportMode) => {
    const newMap: Record<string, number> = { ...columnMap };

    headers.forEach((h, idx) => {
      const lower = h.toLowerCase();
      if (mode === 'ITEMS') {
        if (newMap.code === undefined || newMap.code === -1) {
          if (lower.includes('code') || lower.includes('कोड') || lower.includes('id') || lower.includes('sku')) newMap.code = idx;
        }
        if (newMap.name === undefined || newMap.name === -1) {
          if (lower.includes('name') || lower.includes('नाम') || lower.includes('item') || lower.includes('title') || lower.includes('description') || lower.includes('सामान')) newMap.name = idx;
        }
        if (newMap.purchasePrice === undefined || newMap.purchasePrice === -1) {
          if (lower.includes('purchase') || lower.includes('खरिद') || lower.includes('cost') || lower.includes('buy') || lower.includes('लागत')) newMap.purchasePrice = idx;
        }
        if (newMap.sellingPrice === undefined || newMap.sellingPrice === -1) {
          if (lower.includes('sell') || lower.includes('बिक्री') || lower.includes('rate') || lower.includes('price') || lower.includes('mrp') || lower.includes('दर')) newMap.sellingPrice = idx;
        }
        if (newMap.stock === undefined || newMap.stock === -1) {
          if (lower.includes('stock') || lower.includes('स्टक') || lower.includes('qty') || lower.includes('quantity') || lower.includes('मौज्दात')) newMap.stock = idx;
        }
        if (newMap.category === undefined || newMap.category === -1) {
          if (lower.includes('cat') || lower.includes('श्रेणी') || lower.includes('group') || lower.includes('वर्ग')) newMap.category = idx;
        }
        if (newMap.unit === undefined || newMap.unit === -1) {
          if (lower.includes('unit') || lower.includes('एकाइ')) newMap.unit = idx;
        }
      } else if (mode === 'CUSTOMERS') {
        if (lower.includes('date') || lower.includes('मिति')) newMap.custDate = idx;
        if (lower.includes('bill') || lower.includes('बीजक') || lower.includes('नं')) newMap.custBill = idx;
        if (lower.includes('name') || lower.includes('नाम') || lower.includes('ग्राहक') || lower.includes('पार्टी') || lower.includes('customer') || lower.includes('party')) newMap.custName = idx;
        if (lower.includes('address') || lower.includes('ठेगाना') || lower.includes('स्थान') || lower.includes('location') || lower.includes('ठाउँ')) newMap.custAddress = idx;
        if (lower.includes('phone') || lower.includes('फोन') || lower.includes('सम्पर्क') || lower.includes('मोबाइल') || lower.includes('mobile')) newMap.custPhone = idx;
        if (lower.includes('pan') || lower.includes('प्यान') || lower.includes('vat') || lower.includes('भ्याट')) newMap.custPan = idx;
        if (lower.includes('total') || lower.includes('कुल') || lower.includes('जम्मा') || lower.includes('amount')) newMap.custTotal = idx;
        if (lower.includes('pay') || lower.includes('paid') || lower.includes('received') || lower.includes('भुक्तानी') || lower.includes('बुझाएको') || lower.includes('तिरेको') || lower.includes('असुल')) newMap.custPay = idx;
        if (lower.includes('due') || lower.includes('बाँकी') || lower.includes('बक्यौता') || lower.includes('balance') || lower.includes('मौज्दात') || lower.includes('उधारो')) newMap.custDue = idx;
      } else if (mode === 'PURCHASES') {
        if (lower.includes('date') || lower.includes('मिति')) newMap.purDate = idx;
        if (lower.includes('bill') || lower.includes('बीजक')) newMap.purBill = idx;
        if (lower.includes('supp') || lower.includes('आपूर्तिकर्ता')) newMap.purSupp = idx;
        if (lower.includes('pan') || lower.includes('प्यान')) newMap.purPan = idx;
        if (lower.includes('summary') || lower.includes('विवरण')) newMap.purSummary = idx;
        if (lower.includes('taxable') || lower.includes('करयोग्य')) newMap.purTaxable = idx;
        if (lower.includes('exempt') || lower.includes('छुट')) newMap.purExempt = idx;
        if (lower.includes('vat') || lower.includes('भ्याट')) newMap.purVat = idx;
        if (lower.includes('total') || lower.includes('जम्मा') || lower.includes('कुल')) newMap.purTotal = idx;
        if (lower.includes('mode') || lower.includes('माध्यम')) newMap.purMode = idx;
      } else if (mode === 'SALES') {
        if (lower.includes('date') || lower.includes('मिति')) newMap.saleDate = idx;
        if (lower.includes('bill') || lower.includes('बीजक')) newMap.saleBill = idx;
        if (lower.includes('type') || lower.includes('प्रकार')) newMap.saleType = idx;
        if (lower.includes('cust') || lower.includes('ग्राहक')) newMap.saleCust = idx;
        if (lower.includes('pan') || lower.includes('प्यान')) newMap.salePan = idx;
        if (lower.includes('address') || lower.includes('ठेगाना')) newMap.saleAddr = idx;
        if (lower.includes('taxable') || lower.includes('करयोग्य')) newMap.saleTaxable = idx;
        if (lower.includes('exempt') || lower.includes('छुट')) newMap.saleExempt = idx;
        if (lower.includes('vat') || lower.includes('भ्याट')) newMap.saleVat = idx;
        if (lower.includes('total') || lower.includes('जम्मा')) newMap.saleTotal = idx;
        if (lower.includes('mode') || lower.includes('माध्यम')) newMap.saleMode = idx;
      }
    });

    setColumnMap(newMap);
    return newMap;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    setErrorMessage('');
    setImportStatus('IDLE');

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const buffer = event.target?.result as ArrayBuffer;
        const { headers, rows } = parseExcelFile(buffer);

        if (rows.length === 0) {
          setErrorMessage(isNe ? 'एक्सेल फाइलमा कुनै डाटा भेटिएन।' : 'No data rows found in the Excel file.');
          return;
        }

        setExcelHeaders(headers);
        setExcelRows(rows);

        // Auto-detect column mappings
        const initialMap = autoDetectColumnMappings(headers, activeMode);
        reparseDataWithMapping(headers, rows, initialMap, activeMode);

        setImportStatus('PARSED');
      } catch (err: any) {
        console.error(err);
        setErrorMessage(isNe ? 'फाइल पढ्न सकिएन: कृपया सही .xlsx वा .csv फाइल छान्नुहोस्।' : 'Failed to parse Excel file.');
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Dynamically reparse rows based on selected column mapping
  const reparseDataWithMapping = (
    headers: string[],
    rows: any[][],
    mapping: Record<string, number>,
    mode: ImportMode
  ) => {
    const errors: string[] = [];
    if (mode === 'ITEMS') {
      const parsed: Item[] = [];
      rows.forEach((row, i) => {
        const name = String(mapping.name >= 0 ? row[mapping.name] || '' : '').trim();
        if (!name) return;

        const code = String(mapping.code >= 0 ? row[mapping.code] || '' : `IMP-${i + 1}`).trim() || `IMP-${i + 1}`;
        const purVal = mapping.purchasePrice >= 0 ? String(row[mapping.purchasePrice] || '0').replace(/[^0-9.]/g, '') : '0';
        const sellVal = mapping.sellingPrice >= 0 ? String(row[mapping.sellingPrice] || '0').replace(/[^0-9.]/g, '') : '0';
        const stockVal = mapping.stock >= 0 ? String(row[mapping.stock] || '0').replace(/[^0-9]/g, '') : '0';
        const unitVal = mapping.unit >= 0 ? String(row[mapping.unit] || '').trim() : '';

        const purchasePrice = parseFloat(purVal) || 0;
        const sellingPrice = parseFloat(sellVal) || (purchasePrice ? purchasePrice * 1.15 : 0);
        const stock = parseInt(stockVal) || 0;
        const unit = unitVal || defaultUnit;

        let category: ItemCategory = defaultCategory;
        if (mapping.category >= 0) {
          const catStr = String(row[mapping.category] || '').toUpperCase();
          if (catStr.includes('TRACTOR') || catStr.includes('TILLER') || catStr.includes('टिलर')) category = 'TRACTOR_TILLER';
          else if (catStr.includes('PUMP') || catStr.includes('IRRIGATION') || catStr.includes('पम्प')) category = 'IRRIGATION_PUMP';
          else if (catStr.includes('SPRAY') || catStr.includes('TOOL') || catStr.includes('स्प्रेयर')) category = 'SPRAYER_TOOLS';
          else if (catStr.includes('SPARE') || catStr.includes('पार्ट्स')) category = 'SPARE_PARTS';
          else if (catStr.includes('SEED') || catStr.includes('AGRO') || catStr.includes('बिउ')) category = 'SEEDS_AGRO';
          else if (catStr.includes('FERTILIZER') || catStr.includes('मल')) category = 'FERTILIZER';
          else if (catStr.includes('PESTICIDE') || catStr.includes('औषधी')) category = 'PESTICIDES';
          else if (catStr.includes('FEED') || catStr.includes('दाना')) category = 'LIVESTOCK_FEED';
        }

        parsed.push({
          id: `imp-${Date.now()}-${i}`,
          code,
          nameEn: name,
          nameNe: name,
          category,
          unit,
          purchasePrice,
          sellingPrice,
          openingStock: stock,
          currentStock: stock,
          minStockAlert: 3,
          isVatExempt: category === 'SEEDS_AGRO' || category === 'FERTILIZER'
        });
      });
      setMappedItems(parsed);
    }
    
    if (mode === 'CUSTOMERS') {
      const parsed: Party[] = [];
      rows.forEach((row, i) => {
        const name = String(mapping.custName >= 0 ? row[mapping.custName] || '' : '').trim();
        if (!name || name.toLowerCase().includes('total') || name.includes('जम्मा')) return;

        const dateBs = String(mapping.custDate >= 0 ? row[mapping.custDate] || '2081-11-01' : '2081-11-01').trim();
        const billNo = String(mapping.custBill >= 0 ? row[mapping.custBill] || `INV-${i + 1}` : `INV-${i + 1}`).trim();
        const address = String(mapping.custAddress >= 0 ? row[mapping.custAddress] || 'ठेगाना नखुलेको' : 'ठेगाना नखुलेको').trim();
        const phone = String(mapping.custPhone >= 0 ? row[mapping.custPhone] || '' : '').trim();
        const panNo = String(mapping.custPan >= 0 ? row[mapping.custPan] || '' : '').trim();
        if (panNo) {
          const panRes = validatePanVat(panNo);
          if (!panRes.isValid) errors.push(`Row ${i + 1}: PAN/VAT Error - ${panRes.error}`);
        }
        const totalAmount = mapping.custTotal >= 0 ? parseExcelNumericValue(row[mapping.custTotal]) : 0;
        const rawPay = mapping.custPay >= 0 ? parseExcelNumericValue(row[mapping.custPay]) : 0;
        const rawDue = mapping.custDue >= 0 ? parseExcelNumericValue(row[mapping.custDue]) : Math.max(0, totalAmount - rawPay);

        const openingBalance = customerCalcMode === 'SUBTRACT_PAY' ? rawDue : rawDue + rawPay;
        const currentBalance = customerCalcMode === 'SUBTRACT_PAY' ? Math.max(0, rawDue - rawPay) : rawDue;

        parsed.push({
          id: `pty-imp-${Date.now()}-${i}`,
          name,
          address,
          phone,
          panNo,
          partyType: 'CUSTOMER',
          openingBalance,
          paidAmount: rawPay,
          currentBalance
        });
      });
      setMappedParties(parsed);
    } else if (mode === 'PURCHASES') {
      const parsed: PurchaseRecord[] = [];
      rows.forEach((row, i) => {
        const supplierName = String(mapping.purSupp >= 0 ? row[mapping.purSupp] || 'आपूर्तिकर्ता' : 'आपूर्तिकर्ता').trim();
        if (!supplierName) return;

        const billNo = String(mapping.purBill >= 0 ? row[mapping.purBill] || `PUR-${i + 1}` : `PUR-${i + 1}`).trim();
        const dateBs = String(mapping.purDate >= 0 ? row[mapping.purDate] || '2081-11-01' : '2081-11-01').trim();
        const dateRes = validateDate(dateBs);
        if (!dateRes.isValid) errors.push(`Row ${i + 1}: Date Error - ${dateRes.error}`);
        const summary = String(mapping.purSummary >= 0 ? row[mapping.purSummary] || 'कृषि औजार तथा सामग्री' : 'कृषि औजार तथा सामग्री').trim();

        const grandTotal = mapping.purTotal >= 0 ? parseFloat(String(row[mapping.purTotal] || '0').replace(/[^0-9.]/g, '')) || 0 : 0;
        const vatAmount = mapping.purVat >= 0 ? parseFloat(String(row[mapping.purVat] || '0').replace(/[^0-9.]/g, '')) || (grandTotal * 0.13 / 1.13) : 0;
        const taxableAmount = mapping.purTaxable >= 0 ? parseFloat(String(row[mapping.purTaxable] || '0').replace(/[^0-9.]/g, '')) || (grandTotal - vatAmount) : 0;
        const exemptAmount = mapping.purExempt >= 0 ? parseFloat(String(row[mapping.purExempt] || '0').replace(/[^0-9.]/g, '')) || 0 : 0;

        const modeStr = mapping.purMode >= 0 ? String(row[mapping.purMode] || 'BANK_FONEPAY').toUpperCase() : 'BANK_FONEPAY';
        const paymentMode: PaymentMode = modeStr.includes('CASH') ? 'CASH' : 'BANK_FONEPAY';

        parsed.push({
          id: `pur-imp-${Date.now()}-${i}`,
          purchaseBillNo: billNo,
          supplierName,
          supplierPan: String(mapping.purPan >= 0 ? row[mapping.purPan] || '' : '').trim(),
          dateBs,
          dateAd: '2025-02-13',
          itemsSummary: summary,
          taxableAmount,
          exemptAmount,
          vatAmount,
          grandTotal,
          paymentMode
        });
      });
      setMappedPurchases(parsed);
    } else if (mode === 'SALES') {
      const parsed: Invoice[] = [];
      rows.forEach((row, i) => {
        const customerName = String(mapping.saleCust >= 0 ? row[mapping.saleCust] || 'खुद्रा ग्राहक' : 'खुद्रा ग्राहक').trim();
        const invoiceNo = String(mapping.saleBill >= 0 ? row[mapping.saleBill] || `INV-${i + 1}` : `INV-${i + 1}`).trim();
        const typeStr = mapping.saleType >= 0 ? String(row[mapping.saleType] || 'VAT').toUpperCase() : 'VAT';
        const billType: BillType = typeStr.includes('NON') ? 'NON_VAT' : 'VAT';

        const grandTotal = mapping.saleTotal >= 0 ? parseFloat(String(row[mapping.saleTotal] || '0').replace(/[^0-9.]/g, '')) || 0 : 0;
        const vatAmount = mapping.saleVat >= 0 ? parseFloat(String(row[mapping.saleVat] || '0').replace(/[^0-9.]/g, '')) || (billType === 'VAT' ? grandTotal * 0.13 / 1.13 : 0) : 0;
        const taxableAmount = mapping.saleTaxable >= 0 ? parseFloat(String(row[mapping.saleTaxable] || '0').replace(/[^0-9.]/g, '')) || (grandTotal - vatAmount) : 0;
        const exemptAmount = mapping.saleExempt >= 0 ? parseFloat(String(row[mapping.saleExempt] || '0').replace(/[^0-9.]/g, '')) || 0 : 0;

        const modeStr = mapping.saleMode >= 0 ? String(row[mapping.saleMode] || 'CASH').toUpperCase() : 'CASH';
        let paymentMode: PaymentMode = 'CASH';
        if (modeStr.includes('BANK') || modeStr.includes('FONEPAY') || modeStr.includes('QR')) paymentMode = 'BANK_FONEPAY';
        else if (modeStr.includes('CREDIT') || modeStr.includes('उधारो')) paymentMode = 'CREDIT';

        const dateBs = String(mapping.saleDate >= 0 ? row[mapping.saleDate] || '2081-11-01' : '2081-11-01').trim();
        const dateRes = validateDate(dateBs);
        if (!dateRes.isValid) errors.push(`Row ${i + 1}: Date Error - ${dateRes.error}`);

        parsed.push({
          id: `inv-imp-${Date.now()}-${i}`,
          billType,
          invoiceNo,
          seriesNumber: i + 1,
          fiscalYear: company.fiscalYear || '081/82',
          dateBs,
          dateAd: '2025-02-13',
          time: '12:00 PM',
          customerName,
          customerPan: String(mapping.salePan >= 0 ? row[mapping.salePan] || '' : '').trim(),
          customerAddress: String(mapping.saleAddr >= 0 ? row[mapping.saleAddr] || '' : '').trim(),
          items: [],
          subtotal: grandTotal - vatAmount,
          discountPercent: 0,
          discountAmount: 0,
          freightCharge: 0,
          taxableAmount,
          exemptAmount,
          vatAmount,
          grandTotal,
          paymentMode,
          status: 'ACTIVE',
          createdRole: 'OWNER'
        });
      });
      setMappedSales(parsed);
    }
    setValidationErrors(errors);
  };

  const handleMapChange = (fieldKey: string, columnIndex: number) => {
    const updatedMap = { ...columnMap, [fieldKey]: columnIndex };
    setColumnMap(updatedMap);
    reparseDataWithMapping(excelHeaders, excelRows, updatedMap, activeMode);
  };

  // Commit Import
  const handleCommitImport = () => {
    if (activeMode === 'ITEMS') {
      if (mappedItems.length === 0) return;
      importItemsList(mappedItems);
    } else if (activeMode === 'CUSTOMERS') {
      if (mappedParties.length === 0) return;
      importPartiesList(mappedParties);
    } else if (activeMode === 'PURCHASES') {
      if (mappedPurchases.length === 0) return;
      importPurchasesList(mappedPurchases);
    } else if (activeMode === 'SALES') {
      if (mappedSales.length === 0) return;
      importInvoicesList(mappedSales);
    }

    setImportStatus('SUCCESS');
  };

  const getActiveCount = () => {
    switch (activeMode) {
      case 'ITEMS': return mappedItems.length;
      case 'CUSTOMERS': return mappedParties.length;
      case 'PURCHASES': return mappedPurchases.length;
      case 'SALES': return mappedSales.length;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-xl border border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-emerald-700" />
            <span>{isNe ? 'Excel म्यापिङ तथा इम्पोर्ट विजार्ड' : 'Universal Excel Column Mapping Import Wizard'}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {isNe
              ? 'एक्सेल फाइलका स्तम्भहरू (Columns) लाई प्रणालीको फिल्डहरूसँग जोडेर (Field Mapping) इन्भेन्टरी, ग्राहक वा खरिद/बिक्री डाटा सेकेन्डमै भित्र्याउनुहोस्'
              : 'Upload Excel files, map columns to inventory fields, preview data, and commit directly to ERP'}
          </p>
        </div>

        <button
          onClick={handleDownloadTemplate}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>{isNe ? 'नमुना Excel टेम्प्लेट डाउनलोड (.xlsx)' : 'Download Sample Template'}</span>
        </button>
      </div>

      {/* 4-Mode Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <button
          onClick={() => handleModeChange('ITEMS')}
          className={`p-3 rounded-xl border flex items-center gap-2.5 transition text-xs font-bold cursor-pointer ${
            activeMode === 'ITEMS'
              ? 'bg-emerald-50 border-emerald-600 text-emerald-950 shadow-xs'
              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Boxes className={`w-4 h-4 ${activeMode === 'ITEMS' ? 'text-emerald-700' : 'text-slate-400'}`} />
          <span>{isNe ? '१. सामान इन्भेन्टरी (Items)' : '1. Items Inventory'}</span>
        </button>

        <button
          onClick={() => handleModeChange('CUSTOMERS')}
          className={`p-3 rounded-xl border flex items-center gap-2.5 transition text-xs font-bold cursor-pointer ${
            activeMode === 'CUSTOMERS'
              ? 'bg-emerald-50 border-emerald-600 text-emerald-950 shadow-xs'
              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Users className={`w-4 h-4 ${activeMode === 'CUSTOMERS' ? 'text-emerald-700' : 'text-slate-400'}`} />
          <span>{isNe ? '२. ग्राहक विवरण (Customers)' : '2. Customer Profiles'}</span>
        </button>

        <button
          onClick={() => handleModeChange('PURCHASES')}
          className={`p-3 rounded-xl border flex items-center gap-2.5 transition text-xs font-bold cursor-pointer ${
            activeMode === 'PURCHASES'
              ? 'bg-emerald-50 border-emerald-600 text-emerald-950 shadow-xs'
              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          <ShoppingBag className={`w-4 h-4 ${activeMode === 'PURCHASES' ? 'text-emerald-700' : 'text-slate-400'}`} />
          <span>{isNe ? '३. खरिद विवरण (Purchases)' : '3. Purchase Records'}</span>
        </button>

        <button
          onClick={() => handleModeChange('SALES')}
          className={`p-3 rounded-xl border flex items-center gap-2.5 transition text-xs font-bold cursor-pointer ${
            activeMode === 'SALES'
              ? 'bg-emerald-50 border-emerald-600 text-emerald-950 shadow-xs'
              : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          <Receipt className={`w-4 h-4 ${activeMode === 'SALES' ? 'text-emerald-700' : 'text-slate-400'}`} />
          <span>{isNe ? '४. बिक्री विवरण (Sales)' : '4. Sales Invoices'}</span>
        </button>
      </div>

      {/* Upload Dropzone */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-dashed border-slate-300 text-center space-y-3">
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx, .xls, .csv"
          onChange={handleFileUpload}
          className="hidden"
          id="excel-file-upload"
        />

        <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-700">
          <Upload className="w-6 h-6" />
        </div>

        <div>
          <label
            htmlFor="excel-file-upload"
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>
              {isNe
                ? `${activeMode === 'ITEMS' ? 'सामानको' : activeMode === 'CUSTOMERS' ? 'ग्राहकको' : activeMode === 'PURCHASES' ? 'खरिदको' : 'बिक्रीको'} Excel फाइल छान्नुहोस् (.xlsx, .csv)`
                : 'Upload Excel File (.xlsx, .csv)'}
            </span>
          </label>
        </div>

        {uploadedFileName ? (
          <div className="text-xs text-slate-700 font-mono">
            {isNe ? 'छानिएको फाइल: ' : 'Selected File: '}<strong>{uploadedFileName}</strong> ({excelRows.length} {isNe ? 'पङ्क्तिहरू' : 'rows'})
          </div>
        ) : (
          <p className="text-xs text-slate-400">
            {isNe ? 'कम्प्युटर वा मोबाइलबाट .xlsx वा .csv फाइल अपलोड गरेपछि स्तम्भ म्यापिङ गर्न मिल्नेछ' : 'Upload Excel file to open the Column Mapping Wizard'}
          </p>
        )}

        {errorMessage && (
          <div className="p-3 bg-rose-50 text-rose-700 border border-rose-200 rounded-lg text-xs font-medium max-w-md mx-auto">
            {errorMessage}
          </div>
        )}

        {validationErrors.length > 0 && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 space-y-1 mt-4">
            <h4 className="font-bold">{isNe ? 'डाटा म्यापिङ त्रुटिहरू:' : 'Data Mapping Errors:'}</h4>
            <ul className="list-disc pl-4">
              {validationErrors.slice(0, 5).map((err, i) => <li key={i}>{err}</li>)}
              {validationErrors.length > 5 && <li>...</li>}
            </ul>
          </div>
        )}
      </div>

      {/* Success Confirmation Banner */}
      {importStatus === 'SUCCESS' && (
        <div className="bg-emerald-50 border border-emerald-200 p-5 rounded-xl flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
            <div className="text-xs">
              <h3 className="font-bold text-emerald-950 text-sm">
                {isNe ? 'डाटा सफलतापूर्वक इम्पोर्ट भयो !' : 'Data imported successfully!'}
              </h3>
              <p className="text-emerald-800 mt-0.5">
                {isNe
                  ? `तपाईंको एक्सेलबाट ${toNepaliDigits(getActiveCount())} वटा रेकर्डहरू डाटाबेसमा सुरक्षित गरियो।`
                  : `${getActiveCount()} records have been successfully added to your ERP database.`}
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveTab(activeMode === 'ITEMS' ? 'inventory' : activeMode === 'CUSTOMERS' ? 'ledger' : activeMode === 'PURCHASES' ? 'vouchers' : 'billing')}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs transition cursor-pointer shrink-0"
          >
            {isNe ? 'डाटा हेर्नुहोस् →' : 'View Imported Data →'}
          </button>
        </div>
      )}

      {/* Interactive Column Mapping Panel */}
      {importStatus === 'PARSED' && (
        <div className="space-y-5">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <SlidersHorizontal className="w-5 h-5 text-emerald-700" />
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {isNe ? 'एक्सेल कोलम म्यापिङ विजार्ड (Map Excel Columns)' : 'Interactive Column Mapping Wizard'}
                </h2>
                <p className="text-xs text-slate-500">
                  {isNe
                    ? 'तपाईंको एक्सेल फाइलका हेडरहरूलाई प्रणालीको इन्भेन्टरी फिल्डहरूसँग जोड्नुहोस्'
                    : 'Map detected Excel column headers to system database fields'}
                </p>
              </div>
            </div>

            {/* Mode-specific Column Mapping Fields */}
            {activeMode === 'ITEMS' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 text-xs">
                  
                  {/* Field: Code */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">
                      {isNe ? '१. सामान कोड (Item Code)' : '1. Item Code'}
                    </label>
                    <select
                      value={columnMap.code !== undefined ? columnMap.code : -1}
                      onChange={(e) => handleMapChange('code', Number(e.target.value))}
                      className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value={-1}>{isNe ? '-- नछान्नुहोस् (Auto ID) --' : '-- Auto Generate --'}</option>
                      {excelHeaders.map((h, i) => (
                        <option key={i} value={i}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>

                  {/* Field: Item Name */}
                  <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-300 space-y-1">
                    <label className="font-bold text-emerald-950 block">
                      {isNe ? '२. सामानको नाम (Item Name) *' : '2. Item Name *'}
                    </label>
                    <select
                      value={columnMap.name !== undefined ? columnMap.name : -1}
                      onChange={(e) => handleMapChange('name', Number(e.target.value))}
                      className="w-full px-2 py-1.5 border border-emerald-400 rounded-lg text-xs bg-white font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value={-1}>{isNe ? '-- म्याप गर्नुहोस् * --' : '-- Select Header * --'}</option>
                      {excelHeaders.map((h, i) => (
                        <option key={i} value={i}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>

                  {/* Field: Purchase Price */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">
                      {isNe ? '३. खरिद मूल्य (Cost Price)' : '3. Purchase Price'}
                    </label>
                    <select
                      value={columnMap.purchasePrice !== undefined ? columnMap.purchasePrice : -1}
                      onChange={(e) => handleMapChange('purchasePrice', Number(e.target.value))}
                      className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value={-1}>{isNe ? '-- नछान्नुहोस् (Rs. 0) --' : '-- Default 0 --'}</option>
                      {excelHeaders.map((h, i) => (
                        <option key={i} value={i}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>

                  {/* Field: Selling Price */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">
                      {isNe ? '४. बिक्री दर (Selling Price)' : '4. Selling Price'}
                    </label>
                    <select
                      value={columnMap.sellingPrice !== undefined ? columnMap.sellingPrice : -1}
                      onChange={(e) => handleMapChange('sellingPrice', Number(e.target.value))}
                      className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value={-1}>{isNe ? '-- नछान्नुहोस् (खरिद + १५%) --' : '-- Auto +15% --'}</option>
                      {excelHeaders.map((h, i) => (
                        <option key={i} value={i}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>

                  {/* Field: Stock */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">
                      {isNe ? '५. स्टक परिमाण (Stock Qty)' : '5. Opening Stock'}
                    </label>
                    <select
                      value={columnMap.stock !== undefined ? columnMap.stock : -1}
                      onChange={(e) => handleMapChange('stock', Number(e.target.value))}
                      className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value={-1}>{isNe ? '-- नछान्नुहोस् (0 Qty) --' : '-- Default 0 --'}</option>
                      {excelHeaders.map((h, i) => (
                        <option key={i} value={i}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>

                  {/* Field: Category */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">
                      {isNe ? '६. श्रेणी (Category Column)' : '6. Category Column'}
                    </label>
                    <select
                      value={columnMap.category !== undefined ? columnMap.category : -1}
                      onChange={(e) => handleMapChange('category', Number(e.target.value))}
                      className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value={-1}>{isNe ? '-- नछान्नुहोस् (डिफल्ट श्रेणी) --' : '-- Default Category --'}</option>
                      {excelHeaders.map((h, i) => (
                        <option key={i} value={i}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>

                  {/* Field: Unit */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">
                      {isNe ? '७. एकाइ (Unit Column)' : '7. Unit Column'}
                    </label>
                    <select
                      value={columnMap.unit !== undefined ? columnMap.unit : -1}
                      onChange={(e) => handleMapChange('unit', Number(e.target.value))}
                      className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    >
                      <option value={-1}>{isNe ? '-- नछान्नुहोस् (Pcs) --' : '-- Default Pcs --'}</option>
                      {excelHeaders.map((h, i) => (
                        <option key={i} value={i}>Col {i + 1}: {h}</option>
                      ))}
                    </select>
                  </div>

                </div>

                {/* Default Category and Unit fallback options */}
                <div className="p-3 bg-slate-100 rounded-xl flex flex-wrap items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-700">{isNe ? 'डिफल्ट श्रेणी (Fallback Category):' : 'Fallback Category:'}</span>
                    <select
                      value={defaultCategory}
                      onChange={(e) => {
                        const val = e.target.value as ItemCategory;
                        setDefaultCategory(val);
                        reparseDataWithMapping(excelHeaders, excelRows, columnMap, activeMode);
                      }}
                      className="px-2 py-1 border border-slate-300 rounded-lg bg-white font-semibold cursor-pointer"
                    >
                      <option value="SPARE_PARTS">स्पेयर पार्टस (Spare Parts)</option>
                      <option value="TRACTOR_TILLER">ट्याक्टर तथा टिलर (Tractor & Tiller)</option>
                      <option value="IRRIGATION_PUMP">सिंचाई पम्प (Irrigation Pump)</option>
                      <option value="SPRAYER_TOOLS">स्प्रेयर तथा औजार (Sprayer & Tools)</option>
                      <option value="SEEDS_AGRO">बिउबिजन (Seeds)</option>
                      <option value="FERTILIZER">रासायनिक मल (Fertilizer)</option>
                      <option value="PESTICIDES">विषादी तथा औषधी (Pesticides)</option>
                      <option value="LIVESTOCK_FEED">दाना (Livestock Feed)</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-700">{isNe ? 'डिफल्ट एकाइ (Fallback Unit):' : 'Fallback Unit:'}</span>
                    <select
                      value={defaultUnit}
                      onChange={(e) => {
                        setDefaultUnit(e.target.value);
                        reparseDataWithMapping(excelHeaders, excelRows, columnMap, activeMode);
                      }}
                      className="px-2 py-1 border border-slate-300 rounded-lg bg-white font-semibold cursor-pointer"
                    >
                      <option value="Pcs">Pcs (थान)</option>
                      <option value="Set">Set (सेट)</option>
                      <option value="Kg">Kg (के.जी.)</option>
                      <option value="Litre">Litre (लिटर)</option>
                      <option value="Bag">Bag (बोरा)</option>
                      <option value="Meter">Meter (मिटर)</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Customers Mapping */}
            {activeMode === 'CUSTOMERS' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">१. मिति (Date B.S.)</label>
                    <select
                      value={columnMap.custDate !== undefined ? columnMap.custDate : -1}
                      onChange={(e) => handleMapChange('custDate', Number(e.target.value))}
                      className="w-full px-2 py-1 border border-slate-300 rounded bg-white text-xs cursor-pointer"
                    >
                      <option value={-1}>-- नछान्नुहोस् (आजको मिति) --</option>
                      {excelHeaders.map((h, i) => <option key={i} value={i}>Col {i + 1}: {h}</option>)}
                    </select>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">२. बिल नं. (Bill No)</label>
                    <select
                      value={columnMap.custBill !== undefined ? columnMap.custBill : -1}
                      onChange={(e) => handleMapChange('custBill', Number(e.target.value))}
                      className="w-full px-2 py-1 border border-slate-300 rounded bg-white text-xs cursor-pointer"
                    >
                      <option value={-1}>-- नछान्नुहोस् (अटो बिल नं) --</option>
                      {excelHeaders.map((h, i) => <option key={i} value={i}>Col {i + 1}: {h}</option>)}
                    </select>
                  </div>

                  <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-300 space-y-1">
                    <label className="font-bold text-emerald-950 block">३. ग्राहकको नाम (Customer Name)*</label>
                    <select
                      value={columnMap.custName !== undefined ? columnMap.custName : -1}
                      onChange={(e) => handleMapChange('custName', Number(e.target.value))}
                      className="w-full px-2 py-1 border border-emerald-400 rounded bg-white text-xs font-bold cursor-pointer"
                    >
                      <option value={-1}>-- छान्नुहोस् * --</option>
                      {excelHeaders.map((h, i) => <option key={i} value={i}>Col {i + 1}: {h}</option>)}
                    </select>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">४. ठेगाना (Address)</label>
                    <select
                      value={columnMap.custAddress !== undefined ? columnMap.custAddress : -1}
                      onChange={(e) => handleMapChange('custAddress', Number(e.target.value))}
                      className="w-full px-2 py-1 border border-slate-300 rounded bg-white text-xs cursor-pointer"
                    >
                      <option value={-1}>-- नछान्नुहोस् --</option>
                      {excelHeaders.map((h, i) => <option key={i} value={i}>Col {i + 1}: {h}</option>)}
                    </select>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">५. फोन नम्बर (Phone Number)</label>
                    <select
                      value={columnMap.custPhone !== undefined ? columnMap.custPhone : -1}
                      onChange={(e) => handleMapChange('custPhone', Number(e.target.value))}
                      className="w-full px-2 py-1 border border-slate-300 rounded bg-white text-xs cursor-pointer"
                    >
                      <option value={-1}>-- नछान्नुहोस् --</option>
                      {excelHeaders.map((h, i) => <option key={i} value={i}>Col {i + 1}: {h}</option>)}
                    </select>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                    <label className="font-bold text-slate-800 block">६. प्यान/भ्याट नं. (PAN Number)</label>
                    <select
                      value={columnMap.custPan !== undefined ? columnMap.custPan : -1}
                      onChange={(e) => handleMapChange('custPan', Number(e.target.value))}
                      className="w-full px-2 py-1 border border-slate-300 rounded bg-white text-xs cursor-pointer"
                    >
                      <option value={-1}>-- नछान्नुहोस् --</option>
                      {excelHeaders.map((h, i) => <option key={i} value={i}>Col {i + 1}: {h}</option>)}
                    </select>
                  </div>

                  <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200 space-y-1">
                    <label className="font-bold text-amber-950 block">७. कुल रकम (Total Amount)</label>
                    <select
                      value={columnMap.custTotal !== undefined ? columnMap.custTotal : -1}
                      onChange={(e) => handleMapChange('custTotal', Number(e.target.value))}
                      className="w-full px-2 py-1 border border-amber-300 rounded bg-white text-xs font-bold cursor-pointer"
                    >
                      <option value={-1}>-- नछान्नुहोस् (Rs. 0) --</option>
                      {excelHeaders.map((h, i) => <option key={i} value={i}>Col {i + 1}: {h}</option>)}
                    </select>
                  </div>

                  <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200 space-y-1">
                    <label className="font-bold text-blue-950 block">८. बुझाएको रकम (Pay Amount)</label>
                    <select
                      value={columnMap.custPay !== undefined ? columnMap.custPay : -1}
                      onChange={(e) => handleMapChange('custPay', Number(e.target.value))}
                      className="w-full px-2 py-1 border border-blue-300 rounded bg-white text-xs font-bold cursor-pointer"
                    >
                      <option value={-1}>-- नछान्नुहोस् (Rs. 0) --</option>
                      {excelHeaders.map((h, i) => <option key={i} value={i}>Col {i + 1}: {h}</option>)}
                    </select>
                  </div>

                  <div className="p-3 bg-rose-50/60 rounded-xl border border-rose-200 space-y-1">
                    <label className="font-bold text-rose-950 block">९. बाँकी रकम (Due Amount)</label>
                    <select
                      value={columnMap.custDue !== undefined ? columnMap.custDue : -1}
                      onChange={(e) => handleMapChange('custDue', Number(e.target.value))}
                      className="w-full px-2 py-1 border border-rose-300 rounded bg-white text-xs font-bold cursor-pointer"
                    >
                      <option value={-1}>-- नछान्नुहोस् (Total - Pay) --</option>
                      {excelHeaders.map((h, i) => <option key={i} value={i}>Col {i + 1}: {h}</option>)}
                    </select>
                  </div>
                </div>

                {/* Calculation Rule Selector for Due Amount & Pay Amount */}
                <div className="p-3 bg-slate-100 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs">
                  <span className="font-bold text-slate-800">
                    {isNe ? 'Due Amount र Pay Amount को हिसाब कसरी राख्ने?' : 'How should Due Amount & Pay Amount be calculated?'}
                  </span>
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => {
                        setCustomerCalcMode('SUBTRACT_PAY');
                        setTimeout(() => reparseDataWithMapping(excelHeaders, excelRows, columnMap, 'CUSTOMERS'), 0);
                      }}
                      className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                        customerCalcMode === 'SUBTRACT_PAY'
                          ? 'bg-emerald-700 text-white shadow-xs'
                          : 'bg-white text-slate-700 border border-slate-300'
                      }`}
                    >
                      {isNe ? 'खुद बाँकी = Due Amount - Pay Amount (Due बाट Pay घटाउने)' : 'Net Due = Due Amount - Pay Amount'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCustomerCalcMode('DUE_IS_NET');
                        setTimeout(() => reparseDataWithMapping(excelHeaders, excelRows, columnMap, 'CUSTOMERS'), 0);
                      }}
                      className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                        customerCalcMode === 'DUE_IS_NET'
                          ? 'bg-emerald-700 text-white shadow-xs'
                          : 'bg-white text-slate-700 border border-slate-300'
                      }`}
                    >
                      {isNe ? 'Due Amount नै अन्तिम बाँकी हो (Net Due = Due Amount)' : 'Due Amount is Already Net Due'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Live Preview Table & Commit Action */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Eye className="w-5 h-5 text-emerald-700" />
                  <span>{isNe ? 'इम्पोर्ट हुने डाटाको पूर्वावलोकन (Preview Before Commit)' : 'Preview Parsed Records'}</span>
                </h2>
                <p className="text-xs text-slate-500">
                  {isNe
                    ? `कूल ${toNepaliDigits(getActiveCount())} वटा रेकर्डहरू डाटाबेसमा सुरक्षित हुन तयार छन्`
                    : `${getActiveCount()} rows ready to be merged into database`}
                </p>
              </div>

              <button
                onClick={handleCommitImport}
                disabled={getActiveCount() === 0}
                className="flex items-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-sm transition cursor-pointer self-start sm:self-auto"
              >
                <Database className="w-4 h-4" />
                <span>
                  {activeMode === 'ITEMS'
                    ? (isNe ? 'सिधै इन्भेन्टरीमा सुरक्षित गर्नुहोस् (Import Items)' : 'Confirm & Import Items')
                    : activeMode === 'CUSTOMERS'
                    ? (isNe ? 'सिधै ग्राहक खातामा सुरक्षित गर्नुहोस् (Import Customers & Dues)' : 'Confirm & Import Customers')
                    : activeMode === 'PURCHASES'
                    ? (isNe ? 'सिधै खरिद खातामा सुरक्षित गर्नुहोस् (Import Purchases)' : 'Confirm & Import Purchases')
                    : (isNe ? 'सिधै बिक्री खातामा सुरक्षित गर्नुहोस् (Import Sales)' : 'Confirm & Import Sales')}
                </span>
              </button>
            </div>

            {/* Mode-specific preview tables */}
            <div className="overflow-x-auto max-h-96 border border-slate-200 rounded-xl">
              
              {/* ITEMS PREVIEW */}
              {activeMode === 'ITEMS' && (
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-900 text-slate-100 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3">कोड (Code)</th>
                      <th className="py-2.5 px-3">सामानको नाम (Name)</th>
                      <th className="py-2.5 px-3">श्रेणी (Category)</th>
                      <th className="py-2.5 px-3 text-right">खरिद मूल्य (Cost)</th>
                      <th className="py-2.5 px-3 text-right">बिक्री मूल्य (Sell)</th>
                      <th className="py-2.5 px-3 text-center">स्टक (Stock)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {mappedItems.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center py-6 text-slate-400 italic">
                          {isNe ? 'कुनै सामान भेटिएन। कृपया ऊपरको "सामानको नाम *" मा एक्सेल कोलम म्याप गर्नुहोस्।' : 'No items mapped. Please select Item Name column.'}
                        </td>
                      </tr>
                    ) : (
                      mappedItems.slice(0, 20).map((it, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/80">
                          <td className="py-2 px-3 font-mono font-bold text-slate-600">{it.code}</td>
                          <td className="py-2 px-3 font-bold text-slate-900">{it.nameEn}</td>
                          <td className="py-2 px-3">
                            <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] font-semibold border border-slate-200">
                              {it.category}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600">
                            Rs. {it.purchasePrice.toFixed(2)}
                          </td>
                          <td className="py-2 px-3 text-right font-mono tabular-nums font-bold text-emerald-800">
                            Rs. {it.sellingPrice.toFixed(2)}
                          </td>
                          <td className="py-2 px-3 text-center font-mono font-bold">
                            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded border border-emerald-300">
                              {it.currentStock} {it.unit}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              )}

              {/* CUSTOMERS PREVIEW */}
              {activeMode === 'CUSTOMERS' && (
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-900 text-slate-100 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3">ग्राहकको नाम (Customer Name)</th>
                      <th className="py-2.5 px-3">ठेगाना (Address)</th>
                      <th className="py-2.5 px-3 text-right">कुल बक्यौता (Due Amount)</th>
                      <th className="py-2.5 px-3 text-right">बुझाएको रकम (Pay Amount)</th>
                      <th className="py-2.5 px-3 text-right">हालको खुद बाँकी (Net Due)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {mappedParties.slice(0, 50).map((p, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-bold text-slate-900">{p.name}</td>
                        <td className="py-2 px-3 text-slate-700">{p.address}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-slate-800">
                          {formatCurrency(p.openingBalance, isNe)}
                        </td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-blue-700">
                          {formatCurrency(p.paidAmount || 0, isNe)}
                        </td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-emerald-800">
                          {formatCurrency(p.currentBalance, isNe)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {/* PURCHASES PREVIEW */}
              {activeMode === 'PURCHASES' && (
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-900 text-slate-100 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3">मिति</th>
                      <th className="py-2.5 px-3">बीजक नं.</th>
                      <th className="py-2.5 px-3">आपूर्तिकर्ता</th>
                      <th className="py-2.5 px-3">सामान विवरण</th>
                      <th className="py-2.5 px-3 text-right">करयोग्य</th>
                      <th className="py-2.5 px-3 text-right">भ्याट</th>
                      <th className="py-2.5 px-3 text-right">कुल खरिद रकम</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {mappedPurchases.slice(0, 20).map((pur, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2 px-3 text-slate-500">{pur.dateBs}</td>
                        <td className="py-2 px-3 font-bold text-slate-900">{pur.purchaseBillNo}</td>
                        <td className="py-2 px-3 font-sans font-medium text-slate-900">{pur.supplierName}</td>
                        <td className="py-2 px-3 font-sans text-slate-600">{pur.itemsSummary}</td>
                        <td className="py-2 px-3 text-right">{pur.taxableAmount.toFixed(2)}</td>
                        <td className="py-2 px-3 text-right text-blue-800">{pur.vatAmount.toFixed(2)}</td>
                        <td className="py-2 px-3 text-right font-bold text-slate-900">{pur.grandTotal.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {/* SALES PREVIEW */}
              {activeMode === 'SALES' && (
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-900 text-slate-100 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3">मिति</th>
                      <th className="py-2.5 px-3">बीजक नं.</th>
                      <th className="py-2.5 px-3">प्रकार</th>
                      <th className="py-2.5 px-3">ग्राहकको नाम</th>
                      <th className="py-2.5 px-3">ठेगाना</th>
                      <th className="py-2.5 px-3 text-right">कुल बिक्री रकम</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {mappedSales.slice(0, 20).map((inv, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2 px-3 text-slate-500">{inv.dateBs}</td>
                        <td className="py-2 px-3 font-bold text-slate-900">{inv.invoiceNo}</td>
                        <td className="py-2 px-3 font-sans font-semibold">{inv.billType}</td>
                        <td className="py-2 px-3 font-sans font-bold text-slate-900">{inv.customerName}</td>
                        <td className="py-2 px-3 font-sans text-slate-600">{inv.customerAddress || '-'}</td>
                        <td className="py-2 px-3 text-right font-bold text-emerald-800">{inv.grandTotal.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

            </div>
          </div>
        </div>
      )}

    </div>
  );
};
