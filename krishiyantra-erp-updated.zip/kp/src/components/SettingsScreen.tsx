import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { CompanyProfile, UserRole, Party, BankAccount, CompanyAccount, WorkCategoryConfig, Employee, AccountStatus, BranchOffice } from '../types';
import { WORK_CATEGORIES, DEFAULT_SITE_PRESETS } from './AttendanceScreen';
import { getCurrentDeviceGps } from '../utils/gpsUtils';
import {
  Settings,
  Building,
  Database,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  Check,
  Shield,
  FileCheck,
  Users,
  Calendar,
  Lock,
  Unlock,
  Key,
  Boxes,
  Receipt,
  Landmark,
  Share2,
  Phone,
  MapPin,
  Edit2,
  Plus,
  X,
  AlertTriangle,
  QrCode,
  FileText,
  Printer,
  MessageCircle,
  Smartphone,
  Clock,
  Navigation,
  UserCheck,
  Cloud,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import {
  formatCurrency,
  getTodayBsString,
  formatBsDateNepaliText,
  getDateSyncMode,
  setManualOverrideDate
} from '../utils/nepaliCalendar';
import {
  shareViaWhatsApp,
  shareViaViber,
  shareViaSms,
  copyMessageToClipboard,
  buildCustomerStatementMessage
} from '../utils/shareUtils';
import { fileToDataUrl } from '../utils/imageUtils';
import { downloadServerBackup, isStaffLogin } from '../utils/auth';
import { StaffLoginsPanel } from './StaffLoginsPanel';
import { syncEngine } from '../utils/syncClient';
import { exportAllReportsWorkbookToExcel, printOrDownloadReportPdf } from '../utils/pdfReportExporter';
import { GoogleDriveBackupModal } from './GoogleDriveBackupModal';
import { DateManagementModal } from './DateManagementModal';
import { MobileAuthModal } from './MobileAuthModal';
import { DEFAULT_EXPENSE_CATEGORIES, DEFAULT_INCOME_CATEGORIES } from './VoucherScreen';

export const DEFAULT_PRIMARY_UNITS: { id: string; code: string; labelNe: string; labelEn: string }[] = [
  { id: 'PRI_100MTR', code: '100mtr', labelNe: '१०० मिटर रोल (100mtr)', labelEn: '100 Meter Roll (100mtr)' },
  { id: 'PRI_1CARTON', code: '1 Carton', labelNe: '१ कार्टुन (1 Carton)', labelEn: '1 Carton Box (1 Carton)' },
  { id: 'PRI_12PCS', code: '12pcs', labelNe: '१२ पिस दर्जन (12pcs)', labelEn: '12 Pieces Dozen (12pcs)' },
  { id: 'PRI_ROLL', code: 'Roll', labelNe: 'रोल (Roll)', labelEn: 'Roll' },
  { id: 'PRI_BOX', code: 'Box', labelNe: 'बाकस / कार्टुन (Box)', labelEn: 'Box / Carton' },
  { id: 'PRI_BAG', code: 'Bag', labelNe: 'बोरा (Bag)', labelEn: 'Bag / Sack' },
  { id: 'PRI_PCS', code: 'Pcs', labelNe: 'थान / पिस (Pcs)', labelEn: 'Pieces (Pcs)' },
  { id: 'PRI_SET', code: 'Set', labelNe: 'सेट (Set)', labelEn: 'Set' },
  { id: 'PRI_MTR', code: 'Meter', labelNe: 'मिटर (Meter)', labelEn: 'Meter (Mtr)' },
  { id: 'PRI_LTR', code: 'Litre', labelNe: 'लिटर (Litre)', labelEn: 'Litre (Ltr)' },
  { id: 'PRI_KG', code: 'Kg', labelNe: 'केजी (Kg)', labelEn: 'Kilogram (Kg)' },
  { id: 'PRI_DRUM', code: 'Drum', labelNe: 'ड्रम (Drum)', labelEn: 'Drum' },
  { id: 'PRI_PKT', code: 'Packet', labelNe: 'प्याकेट (Packet)', labelEn: 'Packet' },
  { id: 'PRI_DZN', code: 'Dzn', labelNe: 'दर्जन (Dzn)', labelEn: 'Dozen (Dzn)' },
  { id: 'PRI_TON', code: 'Ton', labelNe: 'टन (Ton)', labelEn: 'Metric Ton' }
];

export const DEFAULT_SECONDARY_UNITS: { id: string; code: string; labelNe: string; labelEn: string }[] = [
  { id: 'SEC_PCS', code: 'Pcs', labelNe: 'पिस / थान (Pcs)', labelEn: 'Pieces (Pcs)' },
  { id: 'SEC_MTR', code: 'Mtr', labelNe: 'मिटर (Mtr)', labelEn: 'Meter (Mtr)' },
  { id: 'SEC_LTR', code: 'Ltr', labelNe: 'लिटर (Ltr)', labelEn: 'Litre (Ltr)' },
  { id: 'SEC_KG', code: 'Kg', labelNe: 'केजी (Kg)', labelEn: 'Kilogram (Kg)' },
  { id: 'SEC_GM', code: 'Gm', labelNe: 'ग्राम (Gm)', labelEn: 'Gram (Gm)' },
  { id: 'SEC_ML', code: 'Ml', labelNe: 'मि.लि. (Ml)', labelEn: 'Millilitre (Ml)' },
  { id: 'SEC_PKT', code: 'Packet', labelNe: 'प्याकेट (Packet)', labelEn: 'Packet' },
  { id: 'SEC_SET', code: 'Set', labelNe: 'सेट (Set)', labelEn: 'Set' },
  { id: 'SEC_ROLL', code: 'Roll', labelNe: 'रोल (Roll)', labelEn: 'Roll' }
];

export const DEFAULT_UNIT_CONVERSIONS: {
  id: string;
  primaryUnit: string;
  secondaryUnit: string;
  ratio: number;
  labelNe: string;
}[] = [
  { id: 'CONV_1', primaryUnit: '100mtr', secondaryUnit: 'Mtr', ratio: 100, labelNe: '100mtr = 100 Mtr (१०० मिटर रोल)' },
  { id: 'CONV_2', primaryUnit: '1 Carton', secondaryUnit: 'Pcs', ratio: 12, labelNe: '1 Carton = 12 Pcs (१ कार्टुन = १२ पिस)' },
  { id: 'CONV_3', primaryUnit: '12pcs', secondaryUnit: 'Pcs', ratio: 12, labelNe: '12pcs = 12 Pcs (१ दर्जन = १२ पिस)' },
  { id: 'CONV_4', primaryUnit: 'Roll', secondaryUnit: 'Mtr', ratio: 100, labelNe: '1 Roll = 100 Mtr (१ रोल = १०० मिटर)' },
  { id: 'CONV_5', primaryUnit: 'Bag', secondaryUnit: 'Kg', ratio: 50, labelNe: '1 Bag = 50 Kg (१ बोरा = ५० केजी)' },
  { id: 'CONV_6', primaryUnit: 'Drum', secondaryUnit: 'Ltr', ratio: 200, labelNe: '1 Drum = 200 Ltr (१ ड्रम = २०० लिटर)' },
  { id: 'CONV_7', primaryUnit: 'Box', secondaryUnit: 'Pcs', ratio: 24, labelNe: '1 Box = 24 Pcs (१ बाकस = २४ पिस)' }
];

export const DEFAULT_PRODUCT_CATEGORIES: { id: string; labelNe: string; labelEn: string }[] = [
  { id: 'TRACTOR_TILLER', labelNe: 'टिलर, ट्रयाक्टर तथा जोत्ने उपकरण', labelEn: 'Tiller & Tractor Machinery' },
  { id: 'IRRIGATION_PUMP', labelNe: 'सिँचाइ, पम्प, पाइप तथा ड्रिप सामग्री', labelEn: 'Irrigation, Pump & Drip' },
  { id: 'SPRAYER_TOOLS', labelNe: 'स्प्रेयर, कटर तथा बाली संरक्षण औजार', labelEn: 'Sprayers & Crop Tools' },
  { id: 'SPARE_PARTS', labelNe: 'रोटाभेटर ब्लेड, बेल्ट तथा स्पेयर पार्ट्स', labelEn: 'Blades, Belts & Spare Parts' },
  { id: 'SEEDS_AGRO', labelNe: 'प्रमाणित उन्नत बिउबिजन (धान, मकै, तरकारी)', labelEn: 'Certified Seeds & Agro' },
  { id: 'FERTILIZER', labelNe: 'रासायनिक तथा जैविक मल (युरिया, डीएपी)', labelEn: 'Chemical & Organic Fertilizer' },
  { id: 'PESTICIDES', labelNe: 'किटनाशक, ढुसीनाशक तथा औषधी', labelEn: 'Pesticides & Crop Medicine' },
  { id: 'LIVESTOCK_FEED', labelNe: 'पशुपालन तथा दाना सामग्री', labelEn: 'Livestock & Feed Supplies' }
];

export const DEFAULT_STAFF_ROLES: {
  id: string;
  titleNe: string;
  titleEn: string;
  defaultWageType: 'MONTHLY' | 'DAILY';
  defaultRate: number;
}[] = [
  { id: 'ROLE_1', titleNe: 'मेसिनरी प्राविधिक / मिस्त्री', titleEn: 'Machinery Technician', defaultWageType: 'MONTHLY', defaultRate: 28000 },
  { id: 'ROLE_2', titleNe: 'काउन्टर सेल्स / क्यासियर', titleEn: 'Counter Sales / Cashier', defaultWageType: 'MONTHLY', defaultRate: 22000 },
  { id: 'ROLE_3', titleNe: 'फिल्ड सुपरभाइजर / प्रमुख', titleEn: 'Field Supervisor', defaultWageType: 'MONTHLY', defaultRate: 30000 },
  { id: 'ROLE_4', titleNe: 'टनेल निर्माण मिस्त्री', titleEn: 'Tunnel Construction Mistri', defaultWageType: 'DAILY', defaultRate: 1200 },
  { id: 'ROLE_5', titleNe: 'फिल्ड हेल्पर / ज्यालादारी कामदार', titleEn: 'Field Helper / Daily Worker', defaultWageType: 'DAILY', defaultRate: 850 },
  { id: 'ROLE_6', titleNe: 'गोदाम तथा स्टक इंचार्ज', titleEn: 'Warehouse & Stock Incharge', defaultWageType: 'MONTHLY', defaultRate: 24000 },
  { id: 'ROLE_7', titleNe: 'डेलिभरी चालक (Driver)', titleEn: 'Delivery Driver', defaultWageType: 'MONTHLY', defaultRate: 25000 }
];

export const ALL_DASHBOARD_TABS = [
  { id: 'dashboard', labelNe: 'ड्यासबोर्ड (Dashboard)', labelEn: 'Dashboard' },
  { id: 'billing', labelNe: 'बिलिङ (Billing)', labelEn: 'Billing' },
  { id: 'manufacturing', labelNe: 'उत्पादन (Manufacturing)', labelEn: 'Manufacturing' },
  { id: 'vouchers', labelNe: 'असुली (Vouchers)', labelEn: 'Vouchers' },
  { id: 'ledger', labelNe: 'खाता (Ledger)', labelEn: 'Ledger' },
  { id: 'inventory', labelNe: 'स्टक (Stock)', labelEn: 'Stock' },
  { id: 'reports', labelNe: 'रिपोर्ट (Reports)', labelEn: 'Reports' },
  { id: 'audit_report', labelNe: 'अडिट रिपोर्ट र ट्रेल (Audit Report & Trail)', labelEn: 'Audit Report & Trail' },
  { id: 'vat_books', labelNe: 'भ्याट खाता (VAT Books)', labelEn: 'VAT Books' },
  { id: 'stock_costing', labelNe: 'स्टक मूल्याङ्कन तथा पुनःक्रम', labelEn: 'Stock Valuation & Reorder' },
  { id: 'accounting', labelNe: 'लेखा तथा वित्त (Accounting)', labelEn: 'Accounting & Finance' },
  { id: 'logistics', labelNe: 'चलानी (Logistics)', labelEn: 'Logistics' },
  { id: 'attendance', labelNe: 'हाजिरी (Attendance)', labelEn: 'Attendance' },
  { id: 'excel_wizard', labelNe: 'एक्सेल (Excel Wizard)', labelEn: 'Excel Wizard' },
  { id: 'settings', labelNe: 'सेटिङ (Settings)', labelEn: 'Settings' }
];

export const DEFAULT_BRANCHES: BranchOffice[] = [
  {
    id: 'branch-head-01',
    code: 'BR-01',
    name: 'मुख्य शाखा - भरतपुर (Head Office)',
    address: 'भरतपुर-१०, चितवन',
    phone: '०५६-५२०१२३, ९८५५०१२३४५',
    email: 'info@krishiyantra.com.np',
    managerName: 'रामेश्वर अधिकारी (Owner)',
    managerMobile: '9855012345',
    managerPin: '1234',
    isMainBranch: true,
    status: 'ACTIVE',
    billPrefix: 'BHR',
    dailyExpenseLimit: 50000,
    maxDiscountPercent: 25,
    permissions: {
      allowSalesBilling: true,
      allowPurchaseEntry: true,
      allowCreditSales: true,
      allowDiscount: true,
      allowStockTransfer: true,
      allowExpenseVoucher: true,
      allowDeleteOrEdit: true,
      allowedTabs: ALL_DASHBOARD_TABS.map((t) => t.id)
    },
    createdAtBs: '२०८१-०१-०१'
  },
  {
    id: 'branch-ktm-02',
    code: 'BR-02',
    name: 'काठमाडौँ शाखा - तीनकुने (Kathmandu Branch)',
    address: 'तीनकुने, काठमाडौँ',
    phone: '०१-४११२२३३, ९८४१२२३३४४',
    email: 'ktm@krishiyantra.com.np',
    managerName: 'सुमन थापा (Branch Incharge)',
    managerMobile: '9841223344',
    managerPin: '1234',
    isMainBranch: false,
    status: 'ACTIVE',
    billPrefix: 'KTM',
    dailyExpenseLimit: 15000,
    maxDiscountPercent: 10,
    permissions: {
      allowSalesBilling: true,
      allowPurchaseEntry: true,
      allowCreditSales: true,
      allowDiscount: true,
      allowStockTransfer: true,
      allowExpenseVoucher: true,
      allowDeleteOrEdit: false,
      allowedTabs: ['dashboard', 'billing', 'vouchers', 'ledger', 'inventory', 'reports', 'logistics', 'attendance']
    },
    createdAtBs: '२०८१-०४-१५'
  }
];

type SettingsTab =
  | 'BRANCHES'
  | 'WORK_ATTENDANCE'
  | 'COMPANY'
  | 'CUSTOMERS'
  | 'FISCAL_YEAR'
  | 'ROLES'
  | 'STAFF_LOGINS'
  | 'CATEGORIES'
  | 'INVOICE'
  | 'BANKS'
  | 'BACKUP';

export const SettingsScreen: React.FC = () => {
  const {
    company,
    updateCompanyProfile,
    companiesList,
    activeCompanyId,
    switchCompany,
    createNewCompany,
    deleteCompanyById,
    deleteCompany,
    currentRole,
    setCurrentRole,
    currentAccount,
    parties,
    saveParty,
    deleteParty,
    bankAccounts,
    saveBankAccount,
    deleteBankAccount,
    closeFiscalYear,
    setFiscalReopenCode,
    isFiscalYearClosed,
    verifyOwnerPin,
    setOwnerPin,
    companyAccounts,
    saveCompanyAccount,
    deleteCompanyAccount,
    approveAccount,
    rejectAccount,
    resetAccountPin,
    items,
    invoices,
    purchases,
    partyTransactions,
    attendance,
    employeeLedger,
    rawMaterials,
    productionBatches,
    loadAgricultureStarterCatalog,
    clearAllData,
    exportFullBackup,
    restoreFullBackup,
    employees,
    saveEmployee,
    deleteEmployee,
    setActiveTab: setGlobalActiveTab,
    setBillingSubTab,
    setVoucherSubTab,
    fiscalYearsList,
    selectFiscalYear,
    addNewFiscalYear,
    language,
    t
  } = useApp();

  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isMasterHubOpen, setIsMasterHubOpen] = useState(true);
  const [copiedLinkId, setCopiedLinkId] = useState<string | null>(null);
  const [masterNewFyInput, setMasterNewFyInput] = useState('');
  const [newSettingFyInput, setNewSettingFyInput] = useState('');

  const [localBackupFolder, setLocalBackupFolder] = useState<string>(
    () => (typeof localStorage !== 'undefined' && localStorage.getItem('krishiyantra_local_backup_folder_path')) || ''
  );
  const [isLocalFolderEnabled, setIsLocalFolderEnabled] = useState<boolean>(
    () => typeof localStorage !== 'undefined' && localStorage.getItem('krishiyantra_local_backup_enabled') === 'true'
  );

  const handleSelectLocalFolder = async () => {
    if (typeof window !== 'undefined' && 'showDirectoryPicker' in window) {
      try {
        const handle = await (window as any).showDirectoryPicker();
        if (handle && handle.name) {
          setLocalBackupFolder(handle.name);
          setIsLocalFolderEnabled(true);
          localStorage.setItem('krishiyantra_local_backup_folder_path', handle.name);
          localStorage.setItem('krishiyantra_local_backup_enabled', 'true');
          showToast(isNe ? `✓ स्थानीय फोल्डर '${handle.name}' ब्याकअपका लागि छानियो!` : `✓ Local folder '${handle.name}' selected!`);
        }
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          showToast(isNe ? 'स्थानीय फोल्डर छान्न सकिएन।' : 'Could not select directory.');
        }
      }
    } else {
      setIsLocalFolderEnabled(true);
      const fallbackName = 'Downloads Folder (Local Storage)';
      setLocalBackupFolder(fallbackName);
      localStorage.setItem('krishiyantra_local_backup_folder_path', fallbackName);
      localStorage.setItem('krishiyantra_local_backup_enabled', 'true');
      showToast(isNe ? '✓ स्थानीय फाइल सेभ सक्रिय भयो! ब्याकअप स्वतः डाउनलोड हुनेछ।' : '✓ Local file backup enabled!');
    }
  };

  const publicAppUrl =
    typeof window !== 'undefined'
      ? window.location.origin
      : 'https://ais-pre-4wcnbnzz5cmaf6s6n5ud5c-301709447959.asia-southeast1.run.app';

  const copyMasterPortalUrl = (url: string, id: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedLinkId(id);
      showToast('✓ मास्टर लिंक सफलतापूर्वक कपी भयो!');
      setTimeout(() => setCopiedLinkId(null), 2500);
    }
  };

  const isNe = language === 'ne';
  const todayBs = getTodayBsString();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const bankQrInputRef = useRef<HTMLInputElement>(null);

  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [serverBackupBusy, setServerBackupBusy] = useState(false);
  const serverRestoreRef = useRef<HTMLInputElement>(null);
  const handleServerRestore = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const okToGo = window.confirm(
      isNe
        ? 'यो ब्याकअप फाइलको डाटाले अहिलेको डाटा बदल्नेछ र सबै डिभाइसमा सर्भरबाट लागू हुनेछ। जारी राख्ने?'
        : 'This will replace current data with the backup file on ALL devices. Continue?'
    );
    if (!okToGo) return;
    setServerBackupBusy(true);
    const text = await file.text();
    const r = await syncEngine.restoreFromBackup(text);
    setServerBackupBusy(false);
    if (r.ok) {
      showToast(isNe ? `✓ ${r.count} वटा डाटा फिर्ता भयो। पुनः लोड हुँदैछ...` : `✓ ${r.count} records restored. Reloading...`);
      setTimeout(() => window.location.reload(), 1200);
    } else if (r.count > 0) {
      showToast(isNe ? 'डाटा यो डिभाइसमा फिर्ता भयो तर सर्भरमा सेभ हुन सकेन। इन्टरनेट जाँचेर पुनः प्रयास गर्नुहोस्।' : 'Restored on this device but could not save to server yet.');
    } else {
      showToast(isNe ? 'यो सर्भर ब्याकअप फाइल मान्य छैन।' : 'Not a valid server backup file.');
    }
  };
  const handleServerBackup = async () => {
    setServerBackupBusy(true);
    const r = await downloadServerBackup();
    setServerBackupBusy(false);
    if (r.ok) showToast(isNe ? '✓ सर्भरको ब्याकअप डाउनलोड भयो!' : '✓ Server backup downloaded!');
    else if (r.message === 'empty') showToast(isNe ? 'सर्भरमा अहिलेसम्म कुनै डाटा सेभ भएको छैन।' : 'No data saved on the server yet.');
    else if (r.message === 'network') showToast(isNe ? 'सर्भरसँग जोडिन सकिएन। इन्टरनेट जाँच गर्नुहोस्।' : 'Could not reach the server.');
    else showToast(isNe ? 'ब्याकअप डाउनलोड असफल भयो।' : 'Backup download failed.');
  };
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const mapSubParamToTab = (subParam: string | null): SettingsTab => {
    switch ((subParam || '').toLowerCase()) {
      case 'branches':
        return 'BRANCHES';
      case 'work_attendance':
        return 'WORK_ATTENDANCE';
      case 'invoice':
        return 'INVOICE';
      case 'company':
        return 'COMPANY';
      case 'customers':
        return 'CUSTOMERS';
      case 'roles':
        return 'ROLES';
      case 'banks':
        return 'BANKS';
      case 'categories':
        return 'CATEGORIES';
      case 'fiscal_year':
        return 'FISCAL_YEAR';
      case 'backup':
        return 'BACKUP';
      default:
        return 'BRANCHES';
    }
  };

  const [activeTab, setActiveTab] = useState<SettingsTab>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return mapSubParamToTab(params.get('sub'));
    }
    return 'WORK_ATTENDANCE';
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('sub')) {
      setActiveTab(mapSubParamToTab(params.get('sub')));
    }

    const handleSubNav = (evt: Event) => {
      const customEvt = evt as CustomEvent<{
        target?: string;
        settingsTab?: SettingsTab;
        partyId?: string;
      }>;
      if (customEvt.detail?.target === 'settings' && customEvt.detail.settingsTab) {
        setActiveTab(customEvt.detail.settingsTab);
        if (customEvt.detail.partyId) {
          const targetParty = parties.find((p) => p.id === customEvt.detail.partyId);
          if (targetParty) {
            setEditingParty(targetParty);
            setPartyName(targetParty.name);
            setPartyAddress(targetParty.address || '');
            setPartyPhone(targetParty.phone || '');
            setPartyPan(targetParty.panNo || '');
            setPartyTypeInput(targetParty.partyType || 'CUSTOMER');
            setPartyOpeningDue(
              targetParty.currentBalance !== undefined
                ? targetParty.currentBalance
                : targetParty.openingBalance || 0
            );
            setIsAddPartyOpen(true);
          }
        }
      }
    };

    window.addEventListener('ims-sub-nav', handleSubNav);
    return () => window.removeEventListener('ims-sub-nav', handleSubNav);
  }, [parties]);

  // Master Work Categories, Site Notes, Shift Timing & GPS Geofence states
  const activeWorkCategories: WorkCategoryConfig[] =
    company.workCategories && company.workCategories.length > 0
      ? company.workCategories
      : WORK_CATEGORIES;

  const activeSitePresets: string[] =
    company.siteLocationPresets && company.siteLocationPresets.length > 0
      ? company.siteLocationPresets
      : DEFAULT_SITE_PRESETS;

  const [newWorkShortNe, setNewWorkShortNe] = useState('');
  const [newWorkLabelEn, setNewWorkLabelEn] = useState('');
  const [newWorkDefaultSite, setNewWorkDefaultSite] = useState('');
  const [newWorkIsField, setNewWorkIsField] = useState(true);

  const [newSitePresetInput, setNewSitePresetInput] = useState('');

  const [shiftStartInput, setShiftStartInput] = useState(company.shiftStartTime || '10:00 AM');
  const [shiftEndInput, setShiftEndInput] = useState(company.shiftEndTime || '05:00 PM');
  const [lateGraceInput, setLateGraceInput] = useState<number>(company.lateGraceMinutes || 15);
  const [autoShiftTimeInput, setAutoShiftTimeInput] = useState<boolean>(
    company.autoSetShiftTime !== undefined ? company.autoSetShiftTime : true
  );

  const [workplaceLabelInput, setWorkplaceLabelInput] = useState(
    company.workplaceLocationLabel || 'कृषियन्त्र मुख्य वर्कसप तथा काउन्टर'
  );
  const [workplaceLatInput, setWorkplaceLatInput] = useState<string>(
    company.workplaceLatitude ? String(company.workplaceLatitude) : ''
  );
  const [workplaceLngInput, setWorkplaceLngInput] = useState<string>(
    company.workplaceLongitude ? String(company.workplaceLongitude) : ''
  );
  const [workplaceRadiusInput, setWorkplaceRadiusInput] = useState<number>(
    company.workplaceRadiusMeters || 200
  );
  const [enforceGpsInput, setEnforceGpsInput] = useState<boolean>(
    company.enforceGpsLocation !== undefined ? company.enforceGpsLocation : true
  );
  const [isFetchingGpsMaster, setIsFetchingGpsMaster] = useState(false);

  // Staff Master Add/Edit inside Master Settings
  const [editingStaff, setEditingStaff] = useState<Employee | null>(null);
  const [staffCodeInput, setStaffCodeInput] = useState('');
  const [staffNameInput, setStaffNameInput] = useState('');
  const [staffRoleInput, setStaffRoleInput] = useState('');
  const [staffSystemRoleInput, setStaffSystemRoleInput] = useState<UserRole>('STAFF');
  const [staffPhoneInput, setStaffPhoneInput] = useState('');
  const [staffLoginMobileInput, setStaffLoginMobileInput] = useState('');
  const [staffLoginPinInput, setStaffLoginPinInput] = useState('1234');
  const [staffApprovalInput, setStaffApprovalInput] = useState<AccountStatus>('APPROVED');
  const [staffWageTypeInput, setStaffWageTypeInput] = useState<'DAILY' | 'MONTHLY'>('DAILY');
  const [staffDailyRateInput, setStaffDailyRateInput] = useState<number>(1000);
  const [staffMonthlySalInput, setStaffMonthlySalInput] = useState<number>(25000);
  const [staffOpeningDueInput, setStaffOpeningDueInput] = useState<number>(0);

  const handleAddWorkCategoryMaster = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWorkShortNe.trim()) return;
    const id = `WORK_${Date.now()}`;
    const shortNe = newWorkShortNe.trim();
    const labelEn = newWorkLabelEn.trim() || shortNe;
    const newCat: WorkCategoryConfig = {
      id,
      shortNe,
      labelNe: `${shortNe} (${labelEn})`,
      labelEn,
      badgeClass: newWorkIsField
        ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
        : 'bg-blue-100 text-blue-900 border-blue-300',
      isFieldWork: newWorkIsField,
      defaultSiteNote: newWorkDefaultSite.trim()
    };
    updateCompanyProfile({
      ...company,
      workCategories: [...activeWorkCategories, newCat]
    });
    setNewWorkShortNe('');
    setNewWorkLabelEn('');
    setNewWorkDefaultSite('');
  };

  const handleUpdateWorkCategoryItem = (id: string, patch: Partial<WorkCategoryConfig>) => {
    const updated = activeWorkCategories.map((c) => (c.id === id ? { ...c, ...patch } : c));
    updateCompanyProfile({
      ...company,
      workCategories: updated
    });
  };

  const handleDeleteWorkCategoryItem = (id: string) => {
    if (activeWorkCategories.length <= 1) return;
    updateCompanyProfile({
      ...company,
      workCategories: activeWorkCategories.filter((c) => c.id !== id)
    });
  };

  const handleResetDefaultWorkCategories = () => {
    updateCompanyProfile({
      ...company,
      workCategories: WORK_CATEGORIES,
      siteLocationPresets: DEFAULT_SITE_PRESETS
    });
  };

  const handleAddSitePreset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSitePresetInput.trim()) return;
    const updated = Array.from(new Set([...activeSitePresets, newSitePresetInput.trim()]));
    updateCompanyProfile({
      ...company,
      siteLocationPresets: updated
    });
    setNewSitePresetInput('');
  };

  const handleRemoveSitePreset = (presetToRemove: string) => {
    updateCompanyProfile({
      ...company,
      siteLocationPresets: activeSitePresets.filter((p) => p !== presetToRemove)
    });
  };

  const handleSaveShiftAndGpsMaster = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompanyProfile({
      ...company,
      shiftStartTime: shiftStartInput.trim() || '10:00 AM',
      shiftEndTime: shiftEndInput.trim() || '05:00 PM',
      lateGraceMinutes: Number(lateGraceInput) || 15,
      autoSetShiftTime: autoShiftTimeInput,
      workplaceLocationLabel: workplaceLabelInput.trim() || 'मुख्य कार्यस्थल',
      workplaceLatitude: workplaceLatInput ? parseFloat(workplaceLatInput) : undefined,
      workplaceLongitude: workplaceLngInput ? parseFloat(workplaceLngInput) : undefined,
      workplaceRadiusMeters: Number(workplaceRadiusInput) || 200,
      enforceGpsLocation: enforceGpsInput
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handlePinCurrentGpsInMaster = async () => {
    setIsFetchingGpsMaster(true);
    try {
      const gps = await getCurrentDeviceGps();
      setWorkplaceLatInput(String(gps.lat));
      setWorkplaceLngInput(String(gps.lng));
      updateCompanyProfile({
        ...company,
        workplaceLatitude: gps.lat,
        workplaceLongitude: gps.lng,
        workplaceRadiusMeters: Number(workplaceRadiusInput) || 200,
        workplaceLocationLabel: workplaceLabelInput.trim() || 'मुख्य कार्यस्थल',
        enforceGpsLocation: enforceGpsInput
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch {
      // ignore
    } finally {
      setIsFetchingGpsMaster(false);
    }
  };

  const handleSaveStaffInMaster = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffNameInput.trim()) return;
    const generatedCode =
      staffCodeInput.trim() ||
      editingStaff?.staffCode ||
      `STF-${String(employees.length + 1).padStart(3, '0')}`;
    const cleanPhone = (staffLoginMobileInput.trim() || staffPhoneInput.trim()).replace(/\D/g, '');
    const pinVal = staffLoginPinInput.trim() || '1234';

    saveEmployee({
      id: editingStaff ? editingStaff.id : `emp-${Date.now()}`,
      staffCode: generatedCode,
      name: staffNameInput.trim(),
      role: staffRoleInput.trim() || 'प्राविधिक / स्टाफ',
      systemRole: staffSystemRoleInput,
      phone: staffPhoneInput.trim() || cleanPhone,
      loginMobile: cleanPhone,
      loginPin: pinVal,
      approvalStatus: staffApprovalInput,
      wageType: staffWageTypeInput,
      dailyWageRate: Number(staffDailyRateInput) || 1000,
      salaryMonthly: Number(staffMonthlySalInput) || 25000,
      joinedDateBs: editingStaff ? editingStaff.joinedDateBs : todayBs,
      openingDue: Number(staffOpeningDueInput) || 0
    });

    if (cleanPhone.length === 10) {
      const existingAcc = companyAccounts.find(
        (a) => a.mobileNumber.replace(/\D/g, '') === cleanPhone
      );
      saveCompanyAccount({
        id: existingAcc?.id,
        companyId: activeCompanyId,
        mobileNumber: cleanPhone,
        companyName: company.name,
        ownerName: staffNameInput.trim(),
        assignedRole: staffSystemRoleInput,
        pin: pinVal,
        status: staffApprovalInput === 'APPROVED' ? 'APPROVED' : 'PENDING_APPROVAL'
      });
    }

    setEditingStaff(null);
    setStaffCodeInput('');
    setStaffNameInput('');
    setStaffRoleInput('');
    setStaffPhoneInput('');
    setStaffLoginMobileInput('');
    setStaffLoginPinInput('1234');
    setStaffOpeningDueInput(0);
    setSaveSuccess(true);
    showToast(isNe ? '✓ कर्मचारी विवरण र लग-इन ID सुरक्षित गरियो!' : '✓ Staff saved!');
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  // Company Profile form states
  const [name, setName] = useState(company.name);
  const [pan, setPan] = useState(company.panVatNo);
  const [address, setAddress] = useState(company.address);
  const [phone, setPhone] = useState(company.phone);
  const [email, setEmail] = useState(company.email || '');
  const [logoUrl, setLogoUrl] = useState(company.logoUrl || '');
  const [backupGmail, setBackupGmail] = useState(company.backupGmail || company.email || '');
  const [autoGmailBackup, setAutoGmailBackup] = useState<boolean>(company.autoGmailBackup || false);
  const [vatPrefix, setVatPrefix] = useState(company.vatBillPrefix || 'TI');
  const [nonVatPrefix, setNonVatPrefix] = useState(company.nonVatBillPrefix || 'NV');
  const [fiscalYear, setFiscalYear] = useState(company.fiscalYear || '081/82');

  // Logged-in user name state ("asma login garne ko name rakhne")
  const [loggedUserNameInput, setLoggedUserNameInput] = useState(
    currentAccount?.ownerName || 'सञ्चालक / मालिक'
  );

  // Sync local company form states whenever company or activeCompanyId changes
  useEffect(() => {
    setName(company.name || '');
    setPan(company.panVatNo || '');
    setAddress(company.address || '');
    setPhone(company.phone || '');
    setEmail(company.email || '');
    setLogoUrl(company.logoUrl || '');
    setBackupGmail(company.backupGmail || company.email || '');
    setAutoGmailBackup(!!company.autoGmailBackup);
    setVatPrefix(company.vatBillPrefix || 'TI');
    setNonVatPrefix(company.nonVatBillPrefix || 'NV');
    setFiscalYear(company.fiscalYear || '081/82');
  }, [company, activeCompanyId]);

  useEffect(() => {
    if (currentAccount?.ownerName) {
      setLoggedUserNameInput(currentAccount.ownerName);
    }
  }, [currentAccount?.ownerName]);

  // Multi-Company Creation states
  const [newCompName, setNewCompName] = useState('');
  const [newCompPan, setNewCompPan] = useState('');
  const [newCompPhone, setNewCompPhone] = useState('');
  const [newCompAddress, setNewCompAddress] = useState('');
  const [newCompStarter, setNewCompStarter] = useState(false);

  // Branch Management & Admin/Owner Control States (प्रत्येक कम्पनी भित्र छुट्टाछुट्टै शाखा खोल्ने र एडमिन कन्ट्रोल)
  const fallbackCompanyMainBranch: BranchOffice = {
    id: `branch-main-${activeCompanyId}`,
    code: 'BR-01',
    name: `मुख्य शाखा - ${company.address || 'हेड अफिस'} (Head Office)`,
    address: company.address || 'मुख्य कार्यालय',
    phone: company.phone || '',
    email: company.email || '',
    managerName: currentAccount?.ownerName || 'सञ्चालक / मुख्य व्यवस्थापक',
    managerMobile: currentAccount?.mobileNumber || company.phone || '',
    managerPin: '1234',
    isMainBranch: true,
    status: 'ACTIVE',
    billPrefix: 'HO',
    dailyExpenseLimit: 50000,
    maxDiscountPercent: 25,
    permissions: {
      allowSalesBilling: true,
      allowPurchaseEntry: true,
      allowCreditSales: true,
      allowDiscount: true,
      allowStockTransfer: true,
      allowExpenseVoucher: true,
      allowDeleteOrEdit: true,
      allowedTabs: ALL_DASHBOARD_TABS.map((t) => t.id)
    },
    createdAtBs: todayBs
  };

  const activeBranches: BranchOffice[] =
    company.branches && company.branches.length > 0
      ? company.branches
      : activeCompanyId === 'comp-default'
      ? DEFAULT_BRANCHES
      : [fallbackCompanyMainBranch];

  const currentActiveBranchId =
    company.activeBranchId || activeBranches[0]?.id || fallbackCompanyMainBranch.id;
  const currentActiveBranch =
    activeBranches.find((b) => b.id === currentActiveBranchId) || activeBranches[0];

  const [editingBranch, setEditingBranch] = useState<BranchOffice | null>(null);
  const [branchNameInput, setBranchNameInput] = useState('');
  const [branchCodeInput, setBranchCodeInput] = useState('');
  const [branchPrefixInput, setBranchPrefixInput] = useState('');
  const [branchAddressInput, setBranchAddressInput] = useState('');
  const [branchPhoneInput, setBranchPhoneInput] = useState('');
  const [branchEmailInput, setBranchEmailInput] = useState('');
  const [branchManagerNameInput, setBranchManagerNameInput] = useState('');
  const [branchManagerMobileInput, setBranchManagerMobileInput] = useState('');
  const [branchManagerPinInput, setBranchManagerPinInput] = useState('1234');
  const [branchMaxDiscountInput, setBranchMaxDiscountInput] = useState<number>(10);
  const [branchDailyExpenseInput, setBranchDailyExpenseInput] = useState<number>(20000);
  const [branchAllowSales, setBranchAllowSales] = useState(true);
  const [branchAllowPurchase, setBranchAllowPurchase] = useState(true);
  const [branchAllowCredit, setBranchAllowCredit] = useState(true);
  const [branchAllowDiscount, setBranchAllowDiscount] = useState(true);
  const [branchAllowStock, setBranchAllowStock] = useState(true);
  const [branchAllowExpense, setBranchAllowExpense] = useState(true);
  const [branchAllowEditDelete, setBranchAllowEditDelete] = useState(false);
  const [branchAllowedTabsInput, setBranchAllowedTabsInput] = useState<string[]>([
    'dashboard',
    'billing',
    'vouchers',
    'ledger',
    'inventory',
    'reports',
    'logistics',
    'attendance'
  ]);

  const resetBranchForm = () => {
    setEditingBranch(null);
    setBranchNameInput('');
    setBranchCodeInput(`BR-0${activeBranches.length + 1}`);
    setBranchPrefixInput('');
    setBranchAddressInput('');
    setBranchPhoneInput('');
    setBranchEmailInput('');
    setBranchManagerNameInput('');
    setBranchManagerMobileInput('');
    setBranchManagerPinInput('1234');
    setBranchMaxDiscountInput(10);
    setBranchDailyExpenseInput(20000);
    setBranchAllowSales(true);
    setBranchAllowPurchase(true);
    setBranchAllowCredit(true);
    setBranchAllowDiscount(true);
    setBranchAllowStock(true);
    setBranchAllowExpense(true);
    setBranchAllowEditDelete(false);
    setBranchAllowedTabsInput([
      'dashboard',
      'billing',
      'vouchers',
      'ledger',
      'inventory',
      'reports',
      'logistics',
      'attendance'
    ]);
  };

  const handleEditBranchSelect = (br: BranchOffice) => {
    setEditingBranch(br);
    setBranchNameInput(br.name);
    setBranchCodeInput(br.code);
    setBranchPrefixInput(br.billPrefix || '');
    setBranchAddressInput(br.address);
    setBranchPhoneInput(br.phone);
    setBranchEmailInput(br.email || '');
    setBranchManagerNameInput(br.managerName);
    setBranchManagerMobileInput(br.managerMobile);
    setBranchManagerPinInput(br.managerPin || '1234');
    setBranchMaxDiscountInput(br.maxDiscountPercent ?? 10);
    setBranchDailyExpenseInput(br.dailyExpenseLimit ?? 20000);
    setBranchAllowSales(br.permissions.allowSalesBilling);
    setBranchAllowPurchase(br.permissions.allowPurchaseEntry);
    setBranchAllowCredit(br.permissions.allowCreditSales);
    setBranchAllowDiscount(br.permissions.allowDiscount);
    setBranchAllowStock(br.permissions.allowStockTransfer);
    setBranchAllowExpense(br.permissions.allowExpenseVoucher);
    setBranchAllowEditDelete(br.permissions.allowDeleteOrEdit);
    setBranchAllowedTabsInput(br.permissions.allowedTabs || ALL_DASHBOARD_TABS.map((t) => t.id));
  };

  const handleSaveBranchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!branchNameInput.trim()) {
      showToast('कृपया शाखाको नाम लेख्नुहोस्।');
      return;
    }

    const code = branchCodeInput.trim() || `BR-0${activeBranches.length + 1}`;
    const prefix =
      branchPrefixInput.trim().toUpperCase() ||
      code.replace(/[^A-Z0-9]/gi, '').toUpperCase();
    const cleanManagerPhone = branchManagerMobileInput.replace(/\D/g, '');

    const newBranch: BranchOffice = {
      id: editingBranch ? editingBranch.id : `branch-${Date.now()}`,
      code,
      name: branchNameInput.trim(),
      address: branchAddressInput.trim() || company.address,
      phone: branchPhoneInput.trim() || company.phone,
      email: branchEmailInput.trim() || company.email,
      managerName: branchManagerNameInput.trim() || 'शाखा प्रमुख',
      managerMobile: cleanManagerPhone || branchPhoneInput.trim(),
      managerPin: branchManagerPinInput.trim() || '1234',
      isMainBranch: editingBranch ? editingBranch.isMainBranch : activeBranches.length === 0,
      status: editingBranch ? editingBranch.status : 'ACTIVE',
      billPrefix: prefix,
      dailyExpenseLimit: Number(branchDailyExpenseInput) || 20000,
      maxDiscountPercent: Number(branchMaxDiscountInput) || 10,
      permissions: {
        allowSalesBilling: branchAllowSales,
        allowPurchaseEntry: branchAllowPurchase,
        allowCreditSales: branchAllowCredit,
        allowDiscount: branchAllowDiscount,
        allowStockTransfer: branchAllowStock,
        allowExpenseVoucher: branchAllowExpense,
        allowDeleteOrEdit: branchAllowEditDelete,
        allowedTabs: branchAllowedTabsInput
      },
      createdAtBs: editingBranch ? editingBranch.createdAtBs : todayBs
    };

    const updatedBranches = editingBranch
      ? activeBranches.map((b) => (b.id === editingBranch.id ? newBranch : b))
      : [...activeBranches, newBranch];

    updateCompanyProfile(
      {
        ...company,
        branches: updatedBranches,
        activeBranchId: company.activeBranchId || newBranch.id
      },
      true
    );

    // Also sync Branch Manager login account in companyAccounts so they can login and be controlled by Admin
    if (cleanManagerPhone.length === 10) {
      const existingAcc = companyAccounts.find(
        (a) => a.mobileNumber.replace(/\D/g, '') === cleanManagerPhone
      );
      saveCompanyAccount({
        id: existingAcc?.id,
        companyId: activeCompanyId,
        mobileNumber: cleanManagerPhone,
        companyName: `${company.name} (${newBranch.name})`,
        ownerName: newBranch.managerName,
        address: newBranch.address,
        assignedRole: newBranch.isMainBranch ? 'OWNER' : 'ADMINISTRATION',
        pin: newBranch.managerPin,
        status: newBranch.status === 'ACTIVE' ? 'APPROVED' : 'REJECTED',
        allowedTabs: newBranch.permissions.allowedTabs
      });
    }

    resetBranchForm();
    showToast(
      editingBranch
        ? `✓ '${company.name}' भित्रको शाखा '${newBranch.name}' अपडेट भयो!`
        : `✓ '${company.name}' कम्पनी भित्र नयाँ शाखा '${newBranch.name}' सफलतापूर्वक बन्यो!`
    );
  };

  const handleSwitchActiveBranch = (br: BranchOffice) => {
    if (br.status === 'LOCKED') {
      showToast(`⚠️ '${br.name}' एडमिन/ओनरद्वारा लक गरिएको छ! पहिले अनलक गर्नुहोस्।`);
      return;
    }
    updateCompanyProfile(
      {
        ...company,
        branches: activeBranches,
        activeBranchId: br.id,
        address: br.address || company.address,
        phone: br.phone || company.phone,
        email: br.email || company.email
      },
      true
    );
    showToast(`✓ '${company.name}' को सक्रिय शाखा '${br.name}' छानियो!`);
  };

  const handleToggleBranchLockStatus = (br: BranchOffice) => {
    const nextStatus: BranchOffice['status'] = br.status === 'ACTIVE' ? 'LOCKED' : 'ACTIVE';
    const updated = activeBranches.map((b) =>
      b.id === br.id ? { ...b, status: nextStatus } : b
    );
    updateCompanyProfile(
      {
        ...company,
        branches: updated
      },
      true
    );

    // Sync manager account status as well
    const cleanPhone = (br.managerMobile || '').replace(/\D/g, '');
    if (cleanPhone.length === 10) {
      const acc = companyAccounts.find((a) => a.mobileNumber.replace(/\D/g, '') === cleanPhone);
      if (acc) {
        saveCompanyAccount({
          id: acc.id,
          companyId: activeCompanyId,
          mobileNumber: acc.mobileNumber,
          companyName: acc.companyName,
          ownerName: acc.ownerName,
          assignedRole: acc.assignedRole || 'ADMINISTRATION',
          pin: acc.pin,
          status: nextStatus === 'ACTIVE' ? 'APPROVED' : 'REJECTED',
          allowedTabs: br.permissions.allowedTabs
        });
      }
    }

    showToast(
      nextStatus === 'ACTIVE'
        ? `🟢 '${br.name}' शाखा सुचारु (Unlocked / Active) गरियो!`
        : `🔒 '${br.name}' शाखा एडमिनद्वारा लक (Locked) गरियो!`
    );
  };

  const handleToggleBranchPermission = (
    branchId: string,
    permKey: keyof BranchOffice['permissions'],
    value: boolean
  ) => {
    const updated = activeBranches.map((b) => {
      if (b.id !== branchId) return b;
      return {
        ...b,
        permissions: {
          ...b.permissions,
          [permKey]: value
        }
      };
    });
    updateCompanyProfile(
      {
        ...company,
        branches: updated
      },
      true
    );
    showToast('✓ शाखाको अधिकार (Branch Permission) अपडेट भयो!');
  };

  const handleUpdateBranchLimit = (
    branchId: string,
    field: 'maxDiscountPercent' | 'dailyExpenseLimit',
    val: number
  ) => {
    const updated = activeBranches.map((b) =>
      b.id === branchId ? { ...b, [field]: val } : b
    );
    updateCompanyProfile(
      {
        ...company,
        branches: updated
      },
      true
    );
  };

  const handleToggleBranchAllowedTab = (branchId: string, tabId: string) => {
    const updated = activeBranches.map((b) => {
      if (b.id !== branchId) return b;
      const currentTabs = b.permissions.allowedTabs || [];
      const exists = currentTabs.includes(tabId);
      const nextTabs = exists
        ? currentTabs.filter((t) => t !== tabId)
        : [...currentTabs, tabId];

      // Also sync manager account allowedTabs
      const cleanPhone = (b.managerMobile || '').replace(/\D/g, '');
      if (cleanPhone.length === 10) {
        const acc = companyAccounts.find((a) => a.mobileNumber.replace(/\D/g, '') === cleanPhone);
        if (acc) {
          saveCompanyAccount({
            id: acc.id,
            companyId: activeCompanyId,
            mobileNumber: acc.mobileNumber,
            companyName: acc.companyName,
            ownerName: acc.ownerName,
            assignedRole: acc.assignedRole || 'ADMINISTRATION',
            pin: acc.pin,
            status: acc.status,
            allowedTabs: nextTabs
          });
        }
      }

      return {
        ...b,
        permissions: {
          ...b.permissions,
          allowedTabs: nextTabs
        }
      };
    });
    updateCompanyProfile(
      {
        ...company,
        branches: updated
      },
      true
    );
  };

  const handleDeleteBranch = (br: BranchOffice) => {
    if (br.isMainBranch || activeBranches.length <= 1) {
      showToast('⚠️ मुख्य शाखा मेटाउन मिल्दैन!');
      return;
    }
    const updated = activeBranches.filter((b) => b.id !== br.id);
    updateCompanyProfile({
      ...company,
      branches: updated,
      activeBranchId:
        company.activeBranchId === br.id ? updated[0]?.id : company.activeBranchId
    });
    showToast(`✓ शाखा '${br.name}' हटाइयो।`);
  };

  // Custom Roles states
  const [newCustomRoleNameNe, setNewCustomRoleNameNe] = useState('');
  const [newCustomRoleBase, setNewCustomRoleBase] = useState<UserRole>('STAFF');
  const [newCustomRoleDesc, setNewCustomRoleDesc] = useState('');

  // Invoice Customization states
  const [invoiceFooter, setInvoiceFooter] = useState(
    company.invoiceFooterNote || 'बिक्री भएको सामान ७ दिनभित्र बिल सहित ल्याएमा फिर्ता वा साटफेर गरिनेछ।'
  );
  const [invoiceTerms, setInvoiceTerms] = useState(
    company.invoiceTerms || '१. सामान ढुवानी तथा लोड/अनलोड ग्राहकको जिम्मामा हुनेछ।\n२. उधारो खरिदको रकम तोकिएको म्यादभित्र अनिवार्य बुझाउनुपर्नेछ।'
  );
  const [defaultDueDays, setDefaultDueDays] = useState(company.defaultDueDays || 30);
  const [defaultPrintFormat, setDefaultPrintFormat] = useState<'A4' | 'THERMAL_80MM' | 'THERMAL_58MM'>(
    company.defaultPrintFormat || 'A4'
  );
  const [showQrOnInvoice, setShowQrOnInvoice] = useState(
    company.showQrOnInvoice !== undefined ? company.showQrOnInvoice : true
  );
  const [deductStockOnNonVat, setDeductStockOnNonVat] = useState(
    company.deductStockOnNonVat !== undefined ? company.deductStockOnNonVat : true
  );

  // Owner PIN & Role Security states
  const [isOwnerUnlocked, setIsOwnerUnlocked] = useState(currentRole === 'OWNER');
  const [enteredPin, setEnteredPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [newPinInput, setNewPinInput] = useState('');
  const [pinChangeSuccess, setPinChangeSuccess] = useState(false);

  // Customer / Party Edit modal state
  const [customerSearch, setCustomerSearch] = useState('');
  const [editingParty, setEditingParty] = useState<Party | null>(null);
  const [isAddPartyOpen, setIsAddPartyOpen] = useState(false);
  const [partyName, setPartyName] = useState('');
  const [partyAddress, setPartyAddress] = useState('');
  const [partyPhone, setPartyPhone] = useState('');
  const [partyPan, setPartyPan] = useState('');
  const [partyTypeInput, setPartyTypeInput] = useState<'CUSTOMER' | 'SUPPLIER' | 'BOTH'>('CUSTOMER');
  const [partyOpeningDue, setPartyOpeningDue] = useState<number>(0);

  // Fiscal Year Closing states
  const [nextFiscalYear, setNextFiscalYear] = useState('082/83');
  const [isFiscalCloseConfirmOpen, setIsFiscalCloseConfirmOpen] = useState(false);
  const [closeCodeInput, setCloseCodeInput] = useState('');
  const [reopenNewCode, setReopenNewCode] = useState('');
  const [reopenCurrentCode, setReopenCurrentCode] = useState('');
  const [fiscalCloseSuccess, setFiscalCloseSuccess] = useState(false);

  // Bank Edit state + QR Upload state
  const [editingBank, setEditingBank] = useState<BankAccount | null>(null);
  const [isAddBankOpen, setIsAddBankOpen] = useState(false);
  const [bankName, setBankName] = useState('');
  const [bankAccNo, setBankAccNo] = useState('');
  const [bankHolder, setBankHolder] = useState(company.name);
  const [bankBranch, setBankBranch] = useState('');
  const [bankOpeningBal, setBankOpeningBal] = useState<number>(0);
  const [bankQrCodeUrl, setBankQrCodeUrl] = useState<string>('');

  // Categories custom state
  const [newCategoryNe, setNewCategoryNe] = useState('');
  const [newCategoryEn, setNewCategoryEn] = useState('');

  const [saveSuccess, setSaveSuccess] = useState(false);

  // User & Role Accounts management state
  const [userSearchTerm, setUserSearchTerm] = useState('');
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<CompanyAccount | null>(null);
  const [userMobile, setUserMobile] = useState('');
  const [userName, setUserName] = useState('');
  const [userCompanyName, setUserCompanyName] = useState('');
  const [userAssignedRole, setUserAssignedRole] = useState<UserRole>('STAFF');
  const [userPin, setUserPin] = useState('1234');
  const [userStatus, setUserStatus] = useState<'APPROVED' | 'PENDING_APPROVAL' | 'REJECTED'>('APPROVED');
  const [userAllowedTabs, setUserAllowedTabs] = useState<string[]>([]);

  const handleOpenUserModal = (acc?: CompanyAccount) => {
    if (acc) {
      setEditingAccount(acc);
      setUserMobile(acc.mobileNumber);
      setUserName(acc.ownerName);
      setUserCompanyName(acc.companyName);
      setUserAssignedRole(acc.assignedRole || 'STAFF');
      setUserPin(acc.pin || '1234');
      setUserStatus(acc.status);
      setUserAllowedTabs(acc.allowedTabs || ALL_DASHBOARD_TABS.map(t => t.id));
    } else {
      setEditingAccount(null);
      setUserMobile('');
      setUserName('');
      setUserCompanyName(company.name);
      setUserAssignedRole('STAFF');
      setUserPin('1234');
      setUserStatus('APPROVED');
      setUserAllowedTabs(ALL_DASHBOARD_TABS.map(t => t.id));
    }
    setIsUserModalOpen(true);
  };

  const handleSaveUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = saveCompanyAccount({
      id: editingAccount?.id,
      mobileNumber: userMobile,
      ownerName: userName,
      companyName: userCompanyName || company.name,
      assignedRole: userAssignedRole,
      pin: userPin,
      status: userStatus,
      allowedTabs: userAllowedTabs
    });

    if (result.success) {
      showToast(result.message);
      setIsUserModalOpen(false);
      setEditingAccount(null);
    } else {
      showToast(result.message);
    }
  };

  // Verify PIN to unlock owner role management
  const handleUnlockOwner = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyOwnerPin(enteredPin)) {
      setIsOwnerUnlocked(true);
      setPinError('');
      setEnteredPin('');
    } else {
      setPinError(isNe ? 'गलत पिन कोड ! कृपया पुन: प्रयास गर्नुहोस्।' : 'Incorrect PIN! Try again.');
    }
  };

  const handleUpdateOwnerPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPinInput.trim() || newPinInput.trim().length < 4) {
      showToast(isNe ? 'पिन कम्तीमा ४ अंकको हुनुपर्छ।' : 'PIN must be at least 4 digits.');
      return;
    }
    setOwnerPin(newPinInput.trim());
    setNewPinInput('');
    setPinChangeSuccess(true);
    showToast(isNe ? '✓ मालिक पिन परिवर्तन भयो!' : '✓ Owner PIN updated!');
    setTimeout(() => setPinChangeSuccess(false), 2500);
  };

  // Handle Company Logo Upload
  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await fileToDataUrl(file, 360, 0.85);
      setLogoUrl(dataUrl);
      updateCompanyProfile({
        ...company,
        logoUrl: dataUrl
      });
      showToast(isNe ? '✓ कम्पनीको लोगो सफलतापूर्वक राखियो!' : '✓ Company logo uploaded!');
    } catch {
      showToast(isNe ? 'लोगो अपलोड गर्न सकिएन।' : 'Failed to upload logo.');
    }
  };

  // Handle Bank QR Upload inside Add/Edit Bank Modal
  const handleBankQrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await fileToDataUrl(file, 520, 0.88);
      setBankQrCodeUrl(dataUrl);
      if (editingBank) {
        saveBankAccount({
          ...editingBank,
          qrCodeUrl: dataUrl
        });
      }
      showToast(isNe ? '✓ बैंकको QR कोड फोटो लोड र सेभ भयो!' : '✓ Bank QR image uploaded!');
    } catch {
      showToast(isNe ? 'QR फोटो लोड गर्न सकिएन।' : 'Failed to load QR image.');
    }
  };

  // Handle Direct Bank QR Upload right on a Bank Card in BANKS tab
  const handleDirectBankCardQrUpload = async (bank: BankAccount, file?: File) => {
    if (!file) return;
    try {
      const dataUrl = await fileToDataUrl(file, 520, 0.88);
      saveBankAccount({
        ...bank,
        qrCodeUrl: dataUrl
      });
      showToast(
        isNe
          ? `✓ '${bank.bankName}' को QR कोड सफलतापूर्वक अपलोड र सेभ भयो!`
          : `✓ QR uploaded for ${bank.bankName}!`
      );
    } catch {
      showToast(isNe ? 'QR फोटो अपलोड गर्न सकिएन।' : 'Failed to upload QR image.');
    }
  };

  // Save Logged-in User Name ("asma login garne ko name rakhne")
  const handleSaveLoggedInUserName = () => {
    const cleanUser = loggedUserNameInput.trim();
    if (!cleanUser) {
      showToast(isNe ? 'कृपया लग-इन गर्नेको नाम लेख्नुहोस्।' : 'Please enter user name.');
      return;
    }
    if (currentAccount) {
      saveCompanyAccount({
        id: currentAccount.id,
        companyId: activeCompanyId,
        mobileNumber: currentAccount.mobileNumber,
        companyName: company.name,
        ownerName: cleanUser,
        assignedRole: currentAccount.assignedRole || currentRole,
        pin: currentAccount.pin || '1234',
        status: currentAccount.status || 'APPROVED'
      });
    } else {
      saveCompanyAccount({
        companyId: activeCompanyId,
        mobileNumber: '9855012345',
        companyName: company.name,
        ownerName: cleanUser,
        assignedRole: currentRole,
        pin: '1234',
        status: 'APPROVED'
      });
    }
    showToast(
      isNe
        ? `✓ लग-इन गर्नेको नाम '${cleanUser}' सफलतापूर्वक राखियो!`
        : `✓ Logged-in user name updated to '${cleanUser}'!`
    );
  };

  // Save General Company & Invoice Settings
  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim() || company.name;
    const updated: CompanyProfile = {
      ...company,
      name: cleanName,
      panVatNo: pan.trim(),
      address: address.trim(),
      phone: phone.trim(),
      email: email.trim(),
      logoUrl: logoUrl || undefined,
      backupGmail: backupGmail.trim() || email.trim(),
      autoGmailBackup,
      vatBillPrefix: vatPrefix.trim() || 'TI',
      nonVatBillPrefix: nonVatPrefix.trim() || 'NV',
      fiscalYear: fiscalYear.trim() || '081/82',
      invoiceFooterNote: invoiceFooter,
      invoiceTerms: invoiceTerms,
      defaultDueDays: Number(defaultDueDays) || 30,
      defaultPrintFormat: defaultPrintFormat,
      showQrOnInvoice: showQrOnInvoice,
      deductStockOnNonVat: deductStockOnNonVat
    };
    updateCompanyProfile(updated);
    setSaveSuccess(true);
    showToast(isNe ? `✓ कम्पनीको नाम र विवरण '${cleanName}' मा अपडेट भयो!` : '✓ Company profile saved!');
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  // Save Customer / Supplier Party (Name, Address, Phone, PAN, Due)
  const handleSavePartySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partyName.trim()) return;

    const newParty: Party = {
      id: editingParty ? editingParty.id : `party-${Date.now()}`,
      name: partyName.trim(),
      address: partyAddress.trim(),
      phone: partyPhone.trim(),
      panNo: partyPan.trim(),
      partyType: partyTypeInput,
      openingBalance: partyOpeningDue,
      currentBalance: partyOpeningDue
    };

    saveParty(newParty);
    setEditingParty(null);
    setIsAddPartyOpen(false);
    setPartyName('');
    setPartyAddress('');
    setPartyPhone('');
    setPartyPan('');
    setPartyOpeningDue(0);
    showToast(isNe ? '✓ ग्राहक/पार्टी विवरण सुरक्षित गरियो !' : '✓ Party saved successfully!');
  };

  // Save Bank Account (including QR Code Image)
  const handleSaveBankSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bankName.trim() || !bankAccNo.trim()) return;

    const account: BankAccount = {
      id: editingBank ? editingBank.id : `bank-${Date.now()}`,
      bankName: bankName.trim(),
      accountNumber: bankAccNo.trim(),
      accountHolder: bankHolder.trim() || company.name,
      branch: bankBranch.trim(),
      openingBalance: bankOpeningBal,
      currentBalance: editingBank ? editingBank.currentBalance : bankOpeningBal,
      qrCodeUrl: bankQrCodeUrl || undefined
    };

    saveBankAccount(account);
    setEditingBank(null);
    setIsAddBankOpen(false);
    setBankName('');
    setBankAccNo('');
    setBankBranch('');
    setBankOpeningBal(0);
    setBankQrCodeUrl('');
    showToast(isNe ? '✓ बैंक खाता र QR विवरण सुरक्षित गरियो !' : '✓ Bank account saved!');
  };

  // Fiscal Year Closing Handler
  const handleExecuteFiscalClose = () => {
    if (!nextFiscalYear.trim()) return;
    if (!company.fiscalReopenCode && closeCodeInput.trim().length < 4) {
      showToast('⚠️ बन्द गर्नुअघि कम्तिमा ४ अक्षरको Reopen Code सेट गर्नुहोस्');
      return;
    }
    closeFiscalYear(nextFiscalYear.trim(), closeCodeInput.trim());
    setCloseCodeInput('');
    setFiscalYear(nextFiscalYear.trim());
    setIsFiscalCloseConfirmOpen(false);
    setFiscalCloseSuccess(true);
    showToast(isNe ? '✓ आर्थिक वर्ष क्लोजिङ सम्पन्न भयो!' : '✓ Fiscal year closed!');
    setTimeout(() => setFiscalCloseSuccess(false), 3000);
  };

  // Master Units, Categories, Staff Roles & Expense/Income Categories state
  const activePrimaryUnits = company.inventoryPrimaryUnits && company.inventoryPrimaryUnits.length > 0
    ? company.inventoryPrimaryUnits
    : DEFAULT_PRIMARY_UNITS;
  const activeSecondaryUnits = company.inventorySecondaryUnits && company.inventorySecondaryUnits.length > 0
    ? company.inventorySecondaryUnits
    : DEFAULT_SECONDARY_UNITS;
  const activeUnitConversions = company.unitConversionPresets && company.unitConversionPresets.length > 0
    ? company.unitConversionPresets
    : DEFAULT_UNIT_CONVERSIONS;
  const activeProductCategories = company.productCategories && company.productCategories.length > 0
    ? company.productCategories
    : [
        ...DEFAULT_PRODUCT_CATEGORIES,
        ...(company.customCategories || [])
      ];
  const activeStaffRoles = company.staffRoles && company.staffRoles.length > 0
    ? company.staffRoles
    : DEFAULT_STAFF_ROLES;
  const activeExpenseCategoriesMaster = company.expenseCategories && company.expenseCategories.length > 0
    ? company.expenseCategories
    : DEFAULT_EXPENSE_CATEGORIES;
  const activeIncomeCategoriesMaster = company.incomeCategories && company.incomeCategories.length > 0
    ? company.incomeCategories
    : DEFAULT_INCOME_CATEGORIES;

  const [newPrimaryCode, setNewPrimaryCode] = useState('');
  const [newPrimaryLabelNe, setNewPrimaryLabelNe] = useState('');
  const [newSecondaryCode, setNewSecondaryCode] = useState('');
  const [newSecondaryLabelNe, setNewSecondaryLabelNe] = useState('');
  const [newConvPrimary, setNewConvPrimary] = useState('100mtr');
  const [newConvSecondary, setNewConvSecondary] = useState('Mtr');
  const [newConvRatio, setNewConvRatio] = useState<number>(100);
  const [newStaffRoleNe, setNewStaffRoleNe] = useState('');
  const [newStaffRoleEn, setNewStaffRoleEn] = useState('');
  const [newStaffRoleWageType, setNewStaffRoleWageType] = useState<'MONTHLY' | 'DAILY'>('MONTHLY');
  const [newStaffRoleRate, setNewStaffRoleRate] = useState<number>(25000);
  const [newExpCatNe, setNewExpCatNe] = useState('');
  const [newIncCatNe, setNewIncCatNe] = useState('');
  const [newIncCatType, setNewIncCatType] = useState<'OTHER_INCOME' | 'LOAN_RECEIVED'>('OTHER_INCOME');

  // Add / Edit Product Category
  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryNe.trim()) return;
    const catId = newCategoryEn.trim()
      ? newCategoryEn.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_')
      : `CAT_${Date.now()}`;
    const newEntry = {
      id: catId,
      labelNe: newCategoryNe.trim(),
      labelEn: newCategoryEn.trim() || newCategoryNe.trim()
    };
    const updatedCats = [...activeProductCategories, newEntry];
    updateCompanyProfile({
      ...company,
      productCategories: updatedCats,
      customCategories: [...(company.customCategories || []), newEntry]
    });
    setNewCategoryNe('');
    setNewCategoryEn('');
    showToast(isNe ? '✓ नयाँ सामान क्याटगोरी थपियो !' : '✓ Product category added!');
  };

  // Database Restore
  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const success = restoreFullBackup(text);
      if (success) {
        showToast(isNe ? '✓ डाटाबेस सफलतापूर्वक रिस्टोर गरियो!' : '✓ Database restored!');
      } else {
        showToast(isNe ? 'ब्याकअप फाइल पढ्न सकिएन।' : 'Failed to parse backup JSON.');
      }
    };
    reader.readAsText(file);
  };

  // Filtered customer list for customer master
  const filteredParties = parties.filter(
    (p) =>
      p.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
      p.address?.toLowerCase().includes(customerSearch.toLowerCase()) ||
      p.phone?.includes(customerSearch) ||
      p.panNo?.includes(customerSearch)
  );

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {toastMsg && (
        <div className="fixed top-4 right-4 z-50 px-4 py-3 bg-emerald-900 text-white text-xs font-bold rounded-xl shadow-2xl border border-emerald-500 flex items-center gap-2">
          <span>{toastMsg}</span>
          <button onClick={() => setToastMsg(null)} className="text-emerald-200 hover:text-white cursor-pointer">
            ✕
          </button>
        </div>
      )}

      {/* Top Banner Header with Instant Company Name & Logged-in User Name Editor */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            {company.logoUrl ? (
              <img
                src={company.logoUrl}
                alt="Logo"
                className="w-12 h-12 rounded-xl object-contain border border-slate-200 bg-slate-50 p-1"
              />
            ) : (
              <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700">
                <Settings className="w-6 h-6" />
              </div>
            )}
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <span>{isNe ? 'प्रणाली तथा मास्टर सेटिङ (Master Settings)' : 'System & Master Settings'}</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {isNe
                  ? 'कम्पनीको नाम, लग-इन नाम, बैंक खाता/QR, कर्मचारी र पार्टी सच्याउने र मेटाउने मुख्य ठाउँ'
                  : 'Exclusive master hub for company name, login user name, bank QR, staff and party management'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-mono font-medium px-2.5 py-1 bg-slate-100 text-slate-800 rounded-lg border border-slate-200">
              {isNe ? `आ.व.: ${company.fiscalYear}` : `FY: ${company.fiscalYear}`}
            </span>
            <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-950 border border-emerald-300">
              👤 {currentAccount?.ownerName || loggedUserNameInput} ({currentRole})
            </span>
          </div>
        </div>

        {/* Instant Quick Save Bar for Company Name & Logged-in User Name */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs">
          <div className="flex flex-col sm:flex-row sm:items-end gap-2">
            <div className="flex-1">
              <label className="block text-[11px] font-extrabold text-emerald-950 mb-1">
                🏢 सक्रिय कम्पनीको नाम फेर्नुहोस् (Change Company Name):
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="कम्पनी वा फर्मको नाम लेख्नुहोस्..."
                className="w-full px-3 py-2 bg-white border border-emerald-400 rounded-lg font-bold text-slate-900 text-xs"
              />
            </div>
            <button
              type="button"
              onClick={() => {
                const clean = name.trim();
                if (!clean) {
                  showToast('कृपया कम्पनीको नाम लेख्नुहोस्।');
                  return;
                }
                updateCompanyProfile({
                  ...company,
                  name: clean
                });
                showToast(`✓ कम्पनीको नाम '${clean}' मा तुरुन्तै परिवर्तन भयो!`);
              }}
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg cursor-pointer shadow-xs whitespace-nowrap"
            >
              ✓ कम्पनी नाम सेभ
            </button>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-end gap-2">
            <div className="flex-1">
              <label className="block text-[11px] font-extrabold text-blue-950 mb-1">
                👤 लग-इन गर्नेको नाम राख्नुहोस् (Logged-in User Name):
              </label>
              <input
                type="text"
                value={loggedUserNameInput}
                onChange={(e) => setLoggedUserNameInput(e.target.value)}
                placeholder="उदा: राम बहादुर थापा"
                className="w-full px-3 py-2 bg-white border border-blue-300 rounded-lg font-bold text-slate-900 text-xs"
              />
            </div>
            <button
              type="button"
              onClick={handleSaveLoggedInUserName}
              className="px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-lg cursor-pointer shadow-xs whitespace-nowrap"
            >
              ✓ लग-इन नाम सेभ
            </button>
          </div>
        </div>

        {/* Mandatory Owner Key Security Bar (कुनै पनि डाटा डिलिट वा सच्याउँदा अनिवार्य मालिक साँचो) */}
        <div className="p-3.5 bg-amber-50/90 border border-amber-300 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-2.5">
            <div className="p-2 bg-amber-600 text-white rounded-lg shrink-0 mt-0.5">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <div className="font-extrabold text-amber-950 flex items-center gap-2 flex-wrap">
                <span>🔐 अनिवार्य मालिक साँचो (Owner Key) सुरक्षा सक्रिय छ!</span>
                <span className="px-2 py-0.5 bg-emerald-700 text-white rounded text-[10px] font-bold">
                  ACTIVE ON ALL EDIT & DELETE
                </span>
              </div>
              <p className="text-[11px] text-amber-900 mt-0.5">
                प्रणालीमा कुनै पनि डाटा <strong>मेटाउँदा (Delete)</strong> वा <strong>सच्याउँदा (Edit)</strong> अनिवार्य रूपमा मालिकको साँचो (Owner Key) राख्नुपर्छ।
                {(!company.ownerPin || company.ownerPin === '1234') && (
                  <span className="ml-1 font-mono font-bold text-rose-800">
                    (हालको डिफल्ट Key: 1234)
                  </span>
                )}
              </p>
            </div>
          </div>

          <form
            onSubmit={handleUpdateOwnerPin}
            className="flex items-center gap-2 shrink-0"
          >
            <input
              type="text"
              value={newPinInput}
              onChange={(e) => setNewPinInput(e.target.value)}
              placeholder="नयाँ Owner Key (उदा: 5566)"
              className="w-44 px-3 py-2 bg-white border border-amber-400 rounded-lg font-mono font-bold text-slate-900 text-xs"
            />
            <button
              type="submit"
              className="px-3.5 py-2 bg-amber-800 hover:bg-amber-900 text-white font-bold rounded-lg cursor-pointer shadow-xs whitespace-nowrap"
            >
              🔑 Key फेर्नुहोस्
            </button>
          </form>
        </div>

        {/* Multi-Company Switcher & Quick Add Separate Company Bar */}
        <div className="p-3.5 bg-slate-900 text-white rounded-xl space-y-3 text-xs border border-slate-700">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="font-extrabold text-emerald-400 text-xs block">
                🏭 छुट्टाछुट्टै कम्पनी छान्नुहोस् वा नयाँ कम्पनी थप्नुहोस् (Multi-Company Selector):
              </span>
              <span className="text-[11px] text-slate-300">
                जुन कम्पनी छान्नुहुन्छ, सोही कम्पनीको छुट्टै स्टाफ, स्टक, बिलिङ, बैंक र हिसाब खुल्छ
              </span>
            </div>
            <span className="px-2.5 py-1 bg-slate-800 text-emerald-300 rounded-lg font-mono text-[11px] font-bold border border-slate-700 self-start sm:self-auto">
              कुल कम्पनी: {companiesList.length}
            </span>
          </div>

          {/* Clickable Company Chips */}
          <div className="flex flex-wrap items-center gap-2">
            {companiesList.map((comp, idx) => {
              const isSelected = comp.id === activeCompanyId;
              return (
                <div
                  key={comp.id}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition border ${
                    isSelected
                      ? 'bg-emerald-600 text-white border-emerald-400 shadow-sm'
                      : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      switchCompany(comp.id);
                      showToast(`✓ अब '${comp.name}' कम्पनी छानियो!`);
                    }}
                    className="cursor-pointer flex items-center gap-1.5"
                  >
                    <span>
                      {idx + 1}. {isSelected ? company.name : comp.name}
                    </span>
                    {isSelected && (
                      <span className="px-1.5 py-0.5 bg-white text-emerald-950 rounded text-[9px] font-extrabold">
                        सक्रिय
                      </span>
                    )}
                  </button>
                  {companiesList.length > 1 && (
                    <button
                      type="button"
                      onClick={() => {
                        deleteCompanyById(comp.id);
                      }}
                      className="ml-1 text-rose-300 hover:text-rose-100 cursor-pointer p-0.5"
                      title="यो कम्पनी हटाउनुहोस् (Owner Key अनिवार्य)"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* Quick 1-Line Add Separate Company Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newCompName.trim()) {
                showToast('कृपया नयाँ कम्पनीको नाम लेख्नुहोस्।');
                return;
              }
              const created = createNewCompany({
                name: newCompName.trim(),
                panVatNo: newCompPan.trim(),
                phone: newCompPhone.trim(),
                address: newCompAddress.trim(),
                includeStarterCatalog: newCompStarter
              });
              setNewCompName('');
              setNewCompPan('');
              setNewCompPhone('');
              setNewCompAddress('');
              showToast(`✓ नयाँ कम्पनी '${created.name}' थपियो र सक्रिय भयो!`);
            }}
            className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-2 border-t border-slate-800 items-center"
          >
            <div className="sm:col-span-5">
              <input
                type="text"
                value={newCompName}
                onChange={(e) => setNewCompName(e.target.value)}
                placeholder="+ नयाँ छुट्टै कम्पनीको नाम लेख्नुहोस् (उदा: हिमालय एग्रो प्रा.लि.)..."
                className="w-full px-3 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white font-bold text-xs placeholder:text-slate-400"
              />
            </div>
            <div className="sm:col-span-2">
              <input
                type="text"
                maxLength={9}
                value={newCompPan}
                onChange={(e) => setNewCompPan(e.target.value)}
                placeholder="PAN नं (ऐच्छिक)"
                className="w-full px-2.5 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white font-mono text-xs placeholder:text-slate-400"
              />
            </div>
            <div className="sm:col-span-2">
              <input
                type="text"
                value={newCompAddress}
                onChange={(e) => setNewCompAddress(e.target.value)}
                placeholder="ठेगाना (ऐच्छिक)"
                className="w-full px-2.5 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white text-xs placeholder:text-slate-400"
              />
            </div>
            <div className="sm:col-span-3">
              <button
                type="submit"
                className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-lg cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>+ नयाँ कम्पनी थप्नुहोस्</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* 👑 MASTER CONFIGURATION & MASTER LINKS HUB (मास्टर सेटिङ तथा मुख्य लिंक) */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950 text-white p-5 rounded-2xl border-2 border-amber-400/50 shadow-xl space-y-4">
        <div
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3 cursor-pointer select-none"
          onClick={() => setIsMasterHubOpen(!isMasterHubOpen)}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/20 text-amber-400 border border-amber-400/40 rounded-xl">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-amber-300 flex items-center gap-2">
                <span>👑 मुख्य मास्टर सेटिङ (Master Configuration & Links)</span>
                {isMasterHubOpen ? <ChevronDown className="w-4 h-4 text-amber-400" /> : <ChevronRight className="w-4 h-4 text-amber-400" />}
              </h2>
              <p className="text-[11px] text-slate-300">
                आर्थिक वर्ष, कम्प्युटर/मोबाइल मिति, लग-इन युजर र सबै फिचर चल्ने मास्टर लिंक
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="px-3 py-1 bg-amber-500 text-slate-950 font-black rounded-lg text-xs shadow-sm">
              MASTER CONTROL
            </span>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsMasterHubOpen(!isMasterHubOpen);
              }}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg cursor-pointer transition flex items-center gap-1 text-xs font-bold"
            >
              <span>{isMasterHubOpen ? 'बन्द (Hide)' : 'खोल्नुहोस् (Show)'}</span>
              {isMasterHubOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {isMasterHubOpen && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* 3 Main Master Cards: 1. Fiscal Year, 2. Live/Manual Date, 3. Logged-in User */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Card 1: Fiscal Year Master */}
              <div className="bg-slate-800/90 border border-slate-700 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-amber-400" />
                    <span>१. आर्थिक वर्ष (Fiscal Year)</span>
                  </span>
                  <span className="px-2 py-0.5 bg-amber-400/20 text-amber-200 border border-amber-400/30 rounded font-mono font-bold text-[10px]">
                    {company.fiscalYear}
                  </span>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">
                    सक्रिय आर्थिक वर्ष छान्नुहोस्:
                  </label>
                  <select
                    value={company.fiscalYear || '081/82'}
                    onChange={(e) => {
                      {
                      const r = selectFiscalYear(e.target.value);
                      if (r.success) showToast(`✓ सक्रिय आर्थिक वर्ष '${e.target.value}' छानियो!`);
                      else if (!r.needsCode) showToast(r.message);
                    }
                    }}
                    className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-600 rounded-lg text-amber-200 font-bold font-mono text-xs focus:outline-none"
                  >
                    {fiscalYearsList.map((fy) => (
                      <option key={fy} value={fy}>
                        📅 आर्थिक वर्ष {fy}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Quick Add New FY form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const res = addNewFiscalYear(masterNewFyInput);
                    showToast(res.message);
                    if (res.success) setMasterNewFyInput('');
                  }}
                  className="flex items-center gap-1 pt-1 border-t border-slate-700/60"
                >
                  <input
                    type="text"
                    value={masterNewFyInput}
                    onChange={(e) => setMasterNewFyInput(e.target.value)}
                    placeholder="नयाँ आ.व. (उदा: 083/84)"
                    className="flex-1 px-2 py-1 bg-slate-900 border border-slate-600 rounded text-xs text-white font-mono placeholder:text-slate-500"
                  />
                  <button
                    type="submit"
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-xs cursor-pointer shadow-xs whitespace-nowrap"
                  >
                    + थप्नुहोस्
                  </button>
                </form>
              </div>

              {/* Card 2: Date Management Master */}
              <div className="bg-slate-800/90 border border-slate-700 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-emerald-400" />
                    <span>२. नेपाली मिति (B.S. Date)</span>
                  </span>
                  <span
                    className={`text-[9px] px-2 py-0.5 rounded font-mono font-bold ${
                      getDateSyncMode() === 'MANUAL'
                        ? 'bg-amber-900 text-amber-200 border border-amber-600'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-600/40'
                    }`}
                  >
                    {getDateSyncMode() === 'MANUAL' ? '✏️ म्यानुअल' : '💻📱 अटो'}
                  </span>
                </div>

                <div className="p-2 bg-slate-900/90 border border-slate-700 rounded-lg text-center">
                  <div className="text-xs text-slate-400">हाल प्रणालीमा सक्रिय मिति:</div>
                  <div className="text-sm font-black text-white mt-0.5">
                    {formatBsDateNepaliText(todayBs)}
                  </div>
                  <div className="text-[10px] font-mono text-emerald-400">{todayBs} (वि.सं.)</div>
                </div>

                <div className="flex items-center gap-1.5 pt-1 border-t border-slate-700/60">
                  <button
                    type="button"
                    onClick={() => setIsDateModalOpen(true)}
                    className="flex-1 py-1.5 px-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded text-xs text-center cursor-pointer shadow-xs"
                  >
                    ✏️ मिति सच्याउने / हेर्ने
                  </button>
                  {getDateSyncMode() === 'MANUAL' && (
                    <button
                      type="button"
                      onClick={() => {
                        setManualOverrideDate(null);
                        showToast('✓ कम्प्युटर/मोबाइल घडी अनुसार अटो-सिंक भयो!');
                      }}
                      className="py-1.5 px-2 bg-slate-700 hover:bg-slate-600 text-amber-300 font-bold rounded text-xs cursor-pointer shadow-xs"
                      title="अटो-सिंकमा फर्काउनुहोस्"
                    >
                      🔄 अटो
                    </button>
                  )}
                </div>
              </div>

              {/* Card 3: Active User & Security Role */}
              <div className="bg-slate-800/90 border border-slate-700 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-sky-300 flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 text-sky-400" />
                    <span>३. सक्रिय युजर प्रोफाइल</span>
                  </span>
                  <span className="px-2 py-0.5 bg-sky-950 text-sky-300 border border-sky-600/40 rounded font-mono font-bold text-[10px]">
                    {currentAccount?.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : currentRole}
                  </span>
                </div>

                <div className="p-2 bg-slate-900/90 border border-slate-700 rounded-lg space-y-1">
                  <div className="text-xs font-bold text-white truncate">
                    👤 {currentAccount?.ownerName || loggedUserNameInput}
                  </div>
                  <div className="text-[11px] font-mono text-sky-300 flex items-center justify-between">
                    <span>📱 {currentAccount?.mobileNumber || '9855012345'}</span>
                    <span className="text-[9px] text-emerald-400 font-bold">🟢 लग-इन सक्रिय</span>
                  </div>
                </div>

                <div className="pt-1 border-t border-slate-700/60 flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setIsAuthModalOpen(true)}
                    className="w-full py-1.5 px-2 bg-sky-700 hover:bg-sky-600 text-white font-bold rounded text-xs text-center cursor-pointer shadow-xs"
                  >
                    🔄 युजर बदल्ने / लग-इन
                  </button>
                </div>
              </div>
            </div>

            {/* Primary All-in-One Master Link Box */}
            <div className="p-4 rounded-xl bg-slate-950 border border-amber-400/40 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="font-extrabold text-amber-300 text-sm flex items-center gap-2">
                    <span>👑 मुख्य मास्टर लिंक (Unified Master Link)</span>
                  </span>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    यो एउटै मास्टर लिंकबाट कुनै पनि मोबाइल वा कम्प्युटरमा सिधै सम्पूर्ण सफ्टवेयर चलाउन सकिन्छ
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => copyMasterPortalUrl(publicAppUrl, 'master_main')}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold rounded-xl cursor-pointer flex items-center gap-1.5 shadow-md self-start sm:self-auto shrink-0"
                >
                  {copiedLinkId === 'master_main' ? <Check className="w-4 h-4" /> : null}
                  <span>{copiedLinkId === 'master_main' ? '✓ मास्टर लिंक कपी भयो!' : '📋 मास्टर लिंक कपी गर्नुहोस्'}</span>
                </button>
              </div>

              <input
                type="text"
                readOnly
                value={publicAppUrl}
                onClick={(e) => (e.target as HTMLInputElement).select()}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg font-mono text-xs text-emerald-300 select-all"
              />

              {/* Direct Module Links Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 pt-2 border-t border-slate-800">
                {[
                  {
                    id: 'link_master_dash',
                    label: '१. मुख्य ड्यासबोर्ड (Full App)',
                    url: `${publicAppUrl}/?portal=owner`,
                    action: () => setGlobalActiveTab('dashboard')
                  },
                  {
                    id: 'link_master_sales',
                    label: '२. बिक्री तथा काउन्टर (POS)',
                    url: `${publicAppUrl}/?tab=billing&sub=SALES`,
                    action: () => {
                      setGlobalActiveTab('billing');
                      setBillingSubTab('SALES');
                    }
                  },
                  {
                    id: 'link_master_purchase',
                    label: '३. खरिद बिल तथा स्टक (Purchase)',
                    url: `${publicAppUrl}/?tab=billing&sub=PURCHASE`,
                    action: () => {
                      setGlobalActiveTab('billing');
                      setBillingSubTab('PURCHASE');
                    }
                  },
                  {
                    id: 'link_master_mfg',
                    label: '४. म्यानुफ्याक्चरिङ (Production)',
                    url: `${publicAppUrl}/?tab=manufacturing`,
                    action: () => setGlobalActiveTab('manufacturing')
                  },
                  {
                    id: 'link_master_ledger',
                    label: '५. पार्टी लेजर खाता (Ledger)',
                    url: `${publicAppUrl}/?tab=ledger`,
                    action: () => setGlobalActiveTab('ledger')
                  },
                  {
                    id: 'link_master_att',
                    label: '६. कर्मचारी तथा काम हाजिरी',
                    url: `${publicAppUrl}/?tab=attendance`,
                    action: () => setGlobalActiveTab('attendance')
                  }
                ].map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between gap-1.5 bg-slate-900/90 border border-slate-800 rounded-lg px-2.5 py-1.5"
                  >
                    <div className="min-w-0">
                      <div className="text-[11px] font-bold text-white truncate">{item.label}</div>
                      <div className="text-[9px] font-mono text-emerald-400 truncate">{item.url}</div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={item.action}
                        className="px-2 py-1 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded text-[10px] cursor-pointer"
                      >
                        खोल्नुहोस्
                      </button>
                      <button
                        type="button"
                        onClick={() => copyMasterPortalUrl(item.url, item.id)}
                        className="px-2 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-[10px] cursor-pointer"
                      >
                        {copiedLinkId === item.id ? '✓' : 'कपी'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Horizontal Settings Tabs Bar */}
      <div className="bg-white p-1.5 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-1 overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setActiveTab('BRANCHES')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'BRANCHES'
              ? 'bg-emerald-700 text-white shadow-xs font-bold'
              : 'bg-indigo-50 text-indigo-950 border border-indigo-200 hover:bg-indigo-100 font-bold'
          }`}
        >
          <Building className="w-3.5 h-3.5" />
          <span>{isNe ? '🏬 शाखा खोल्ने र एडमिन कन्ट्रोल (Branches & Control)' : '🏬 Branches & Admin Control'}</span>
        </button>

        <button
          onClick={() => setActiveTab('WORK_ATTENDANCE')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'WORK_ATTENDANCE'
              ? 'bg-emerald-700 text-white shadow-xs font-bold'
              : 'bg-amber-50 text-amber-950 border border-amber-200 hover:bg-amber-100 font-bold'
          }`}
        >
          <UserCheck className="w-3.5 h-3.5" />
          <span>{isNe ? '👷 काम, हाजिरी र साइट सेटिङ (Master)' : '👷 Work, Site & Attendance'}</span>
        </button>

        <button
          onClick={() => setActiveTab('COMPANY')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'COMPANY'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Building className="w-3.5 h-3.5" />
          <span>{isNe ? '१. फर्म विवरण' : '1. Company Profile'}</span>
        </button>

        <button
          onClick={() => setActiveTab('CUSTOMERS')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'CUSTOMERS'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>{isNe ? '२. ग्राहक/ठेगाना सच्याउने' : '2. Customer Master'}</span>
        </button>

        <button
          onClick={() => setActiveTab('ROLES')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'ROLES'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Shield className="w-3.5 h-3.5" />
          <span>{isNe ? '३. मालिकबाट मात्र रोल' : '3. Role Security'}</span>
        </button>

        {!isStaffLogin() && (
        <button
          onClick={() => setActiveTab('STAFF_LOGINS')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'STAFF_LOGINS'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Shield className="w-3.5 h-3.5" />
          <span>{isNe ? 'कर्मचारी लगइन (ID/Password)' : 'Staff Logins'}</span>
        </button>
        )}

        <button
          onClick={() => setActiveTab('FISCAL_YEAR')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'FISCAL_YEAR'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>{isNe ? '४. आर्थिक वर्ष बन्द' : '4. Fiscal Year Close'}</span>
        </button>

        <button
          onClick={() => setActiveTab('INVOICE')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'INVOICE'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Receipt className="w-3.5 h-3.5" />
          <span>{isNe ? '५. खरिद/बिक्री र बिलिङ मिलाउने' : '5. Purchase/Sales & Invoice'}</span>
        </button>

        <button
          onClick={() => setActiveTab('BANKS')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'BANKS'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Landmark className="w-3.5 h-3.5" />
          <span>{isNe ? '६. बैंक खाता मिलाउने' : '6. Bank Accounts'}</span>
        </button>

        <button
          onClick={() => setActiveTab('CATEGORIES')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'CATEGORIES'
              ? 'bg-emerald-700 text-white shadow-xs font-bold'
              : 'bg-emerald-50 text-emerald-950 border border-emerald-200 hover:bg-emerald-100 font-bold'
          }`}
        >
          <Boxes className="w-3.5 h-3.5" />
          <span>{isNe ? '७. एकाइ, क्याटगोरी, स्टाफ पद र खर्च/आम्दानी (Master)' : '7. Units, Categories, Roles & Heads'}</span>
        </button>

        <button
          onClick={() => setActiveTab('BACKUP')}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition whitespace-nowrap cursor-pointer ${
            activeTab === 'BACKUP'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>{isNe ? '८. ब्याकअप / रिस्टोर' : '8. Backup'}</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB: SEPARATE COMPANIES & BRANCHES INSIDE EACH COMPANY                    */}
      {/* ========================================================================= */}
      {activeTab === 'BRANCHES' && (
        <div className="space-y-6">
          {/* ===================================================================== */}
          {/* PART A: SEPARATE COMPANY MANAGEMENT (कम्पनी अलग्गै थप्ने र छान्ने)     */}
          {/* ===================================================================== */}
          <div className="bg-white p-5 sm:p-6 rounded-2xl border-2 border-emerald-600/40 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-800 shrink-0">
                  <Building className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-base sm:text-lg font-black text-slate-900">
                      🏭 १. अलग्गै कम्पनी व्यवस्थापन (Add & Switch Separate Companies)
                    </h2>
                    <span className="px-2.5 py-0.5 bg-emerald-700 text-white font-black rounded-full text-[11px]">
                      कुल छुट्टाछुट्टै कम्पनी: {companiesList.length} वटा
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    यहाँबाट <strong>छुट्टै नयाँ कम्पनी (Separate Company)</strong> थप्न मिल्छ। जुन कम्पनी छान्नुहुन्छ, तल सोही कम्पनी भित्रका शाखाहरू खुल्छन् र नयाँ शाखा सोही कम्पनी भित्र बन्छ।
                  </p>
                </div>
              </div>
            </div>

            {/* Selectable Separate Companies Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              {companiesList.map((comp, idx) => {
                const isSelected = comp.id === activeCompanyId;
                return (
                  <div
                    key={comp.id}
                    onClick={() => {
                      if (!isSelected) {
                        switchCompany(comp.id);
                        resetBranchForm();
                        showToast(`✓ '${comp.name}' कम्पनी छानियो! अब तल यस कम्पनी भित्रका शाखाहरू हेर्नुहोस् वा थप्नुहोस्।`);
                      }
                    }}
                    className={`p-4 rounded-xl border-2 transition cursor-pointer flex flex-col justify-between gap-3 ${
                      isSelected
                        ? 'bg-emerald-50/90 border-emerald-600 shadow-sm'
                        : 'bg-slate-50 border-slate-200 hover:border-emerald-400 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="px-2 py-0.5 bg-slate-900 text-emerald-300 font-mono font-bold rounded text-[10px]">
                            कम्पनी #{idx + 1}
                          </span>
                          <h3 className="font-black text-sm text-slate-900">
                            {isSelected ? company.name : comp.name}
                          </h3>
                          {isSelected && (
                            <span className="px-2 py-0.5 bg-emerald-700 text-white rounded-full text-[10px] font-extrabold">
                              ✓ छानिएको कम्पनी (Selected)
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-600 mt-1">
                          PAN/VAT: <strong className="font-mono">{(isSelected ? company.panVatNo : comp.panVatNo) || '-'}</strong> · ठेगाना:{' '}
                          <strong>{(isSelected ? company.address : comp.address) || '-'}</strong> · फोन:{' '}
                          <strong className="font-mono">{(isSelected ? company.phone : comp.phone) || '-'}</strong>
                        </p>
                      </div>

                      {companiesList.length > 1 && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteCompanyById(comp.id);
                          }}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg cursor-pointer shrink-0"
                          title="यो कम्पनी हटाउनुहोस्"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-200/80">
                      <span className="text-[11px] font-bold text-indigo-900 flex items-center gap-1">
                        <span>🏬</span>
                        <span>
                          {isSelected
                            ? `यस कम्पनी भित्रका शाखाहरू: ${activeBranches.length} वटा`
                            : 'यो कम्पनी भित्रका शाखा हेर्न/थप्न यहाँ क्लिक गर्नुहोस्'}
                        </span>
                      </span>
                      <span
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                          isSelected
                            ? 'bg-indigo-700 text-white'
                            : 'bg-white text-emerald-800 border border-emerald-300'
                        }`}
                      >
                        {isSelected ? '👇 तल शाखा व्यवस्थापन खुल्ला छ' : 'छान्नुहोस् (Select Company) →'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Add Separate New Company Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newCompName.trim()) {
                  showToast('कृपया नयाँ छुट्टै कम्पनीको नाम लेख्नुहोस्।');
                  return;
                }
                const created = createNewCompany({
                  name: newCompName.trim(),
                  panVatNo: newCompPan.trim(),
                  phone: newCompPhone.trim(),
                  address: newCompAddress.trim(),
                  includeStarterCatalog: newCompStarter
                });
                setNewCompName('');
                setNewCompPan('');
                setNewCompPhone('');
                setNewCompAddress('');
                resetBranchForm();
                showToast(`✓ अलग्गै नयाँ कम्पनी '${created.name}' दर्ता भयो! अब तल यस कम्पनी भित्र शाखाहरू थप्न सक्नुहुन्छ।`);
              }}
              className="p-4 bg-emerald-50/70 border border-emerald-300 rounded-xl space-y-3 text-xs"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-black text-emerald-950 text-xs sm:text-sm flex items-center gap-1.5">
                  <Plus className="w-4 h-4 text-emerald-700" />
                  <span>+ अलग्गै नयाँ कम्पनी थप्नुहोस् (Add Separate New Company):</span>
                </span>
                <span className="text-[11px] text-emerald-800 font-semibold">
                  (नयाँ कम्पनीको आफ्नै छुट्टै हिसाब, बिलिङ, स्टक र आफ्नै छुट्टै शाखाहरू हुन्छन्)
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
                <div className="sm:col-span-4">
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    अलग्गै नयाँ कम्पनीको नाम (Company Name): <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newCompName}
                    onChange={(e) => setNewCompName(e.target.value)}
                    placeholder="उदा: हिमालय एग्रो एण्ड मेसिनरी प्रा.लि."
                    className="w-full px-3 py-2 bg-white border border-emerald-400 rounded-lg font-bold text-slate-900"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    PAN / VAT नं.:
                  </label>
                  <input
                    type="text"
                    maxLength={9}
                    value={newCompPan}
                    onChange={(e) => setNewCompPan(e.target.value)}
                    placeholder="9-digit PAN"
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-lg font-mono text-slate-900"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    मुख्य ठेगाना (Main Address):
                  </label>
                  <input
                    type="text"
                    value={newCompAddress}
                    onChange={(e) => setNewCompAddress(e.target.value)}
                    placeholder="उदा: बुटवल / पोखरा / चितवन"
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-lg text-slate-900"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    सम्पर्क फोन नम्बर:
                  </label>
                  <input
                    type="text"
                    value={newCompPhone}
                    onChange={(e) => setNewCompPhone(e.target.value)}
                    placeholder="98XXXXXXXX"
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-lg font-mono text-slate-900"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={newCompStarter}
                    onChange={(e) => setNewCompStarter(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600"
                  />
                  <span className="font-bold text-slate-700 text-[11px]">
                    नमुना सामानहरू (Starter Items) सहित सुरु गर्ने (नछान्दा ० बाट खाली सुरु हुन्छ)
                  </span>
                </label>

                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-black rounded-xl cursor-pointer flex items-center gap-1.5 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ अलग्गै नयाँ कम्पनी थप्नुहोस्</span>
                </button>
              </div>
            </form>
          </div>

          {/* ===================================================================== */}
          {/* PART B: BRANCHES INSIDE THE SELECTED COMPANY (कम्पनी भित्र शाखा बनाउने) */}
          {/* ===================================================================== */}
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-emerald-950 text-white p-5 rounded-2xl border-2 border-indigo-500/60 shadow-lg space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-white/10 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center shrink-0">
                  <Building className="w-6 h-6 text-amber-300" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2.5 py-0.5 bg-amber-400 text-slate-950 font-black rounded-md text-[11px]">
                      🏢 छानिएको कम्पनी: {company.name}
                    </span>
                    <span className="text-amber-300 font-black">➔</span>
                    <span className="px-2.5 py-0.5 bg-emerald-500 text-slate-950 font-black rounded-full text-[11px]">
                      🏬 यस कम्पनी भित्रका शाखाहरू: {activeBranches.length} वटा
                    </span>
                  </div>
                  <h2 className="text-base sm:text-lg font-black text-white mt-1">
                    २. &lsquo;{company.name}&rsquo; कम्पनी भित्र शाखा बनाउने र एडमिन कन्ट्रोल गर्ने
                  </h2>
                  <p className="text-xs text-slate-300 mt-0.5">
                    यो खण्डमा बनाइएका सबै शाखाहरू <strong>{company.name}</strong> कम्पनी भित्र रहन्छन् र एडमिन/ओनरले प्रत्येक शाखालाई यहीँबाट कन्ट्रोल गर्न सक्नुहुन्छ
                  </p>
                </div>
              </div>

              {/* Company Switcher Dropdown right inside the Branch Banner */}
              <div className="flex flex-col gap-1 shrink-0 bg-slate-900/90 p-2.5 rounded-xl border border-indigo-400/40">
                <label className="text-[10px] font-bold text-amber-300">
                  🔄 कुन कम्पनी भित्र शाखा बनाउने / हेर्ने?
                </label>
                <select
                  value={activeCompanyId}
                  onChange={(e) => {
                    switchCompany(e.target.value);
                    resetBranchForm();
                  }}
                  className="px-2.5 py-1.5 bg-slate-800 border border-slate-600 rounded-lg text-white font-bold text-xs focus:outline-none"
                >
                  {companiesList.map((c, i) => (
                    <option key={c.id} value={c.id}>
                      {i + 1}. {c.id === activeCompanyId ? company.name : c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Quick Active Branch Switcher Bar inside Selected Company */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-white/5 p-3.5 rounded-xl border border-white/10">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-emerald-300 block">
                  🟢 हाल &lsquo;{company.name}&rsquo; भित्र चालु (Active) शाखा:
                </span>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm sm:text-base font-black text-white">
                    {currentActiveBranch?.name} ({currentActiveBranch?.code})
                  </span>
                  <span className="text-xs text-slate-300">
                    📍 {currentActiveBranch?.address} · 📞 {currentActiveBranch?.phone}
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {activeBranches.map((b) => {
                  const isCurrent = b.id === currentActiveBranch?.id;
                  return (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => handleSwitchActiveBranch(b)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border flex items-center gap-1.5 ${
                        isCurrent
                          ? 'bg-emerald-500 text-slate-950 border-emerald-300 font-black shadow-sm'
                          : b.status === 'LOCKED'
                          ? 'bg-rose-950/60 text-rose-300 border-rose-700/50 hover:bg-rose-900/60'
                          : 'bg-slate-800 text-slate-200 border-slate-600 hover:bg-slate-700'
                      }`}
                    >
                      <span>{b.status === 'LOCKED' ? '🔒' : isCurrent ? '✓' : '🏬'}</span>
                      <span>{b.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* SECTION 1 INSIDE COMPANY: OPEN / REGISTER NEW BRANCH INSIDE SELECTED COMPANY */}
          <div className="bg-white p-5 sm:p-6 rounded-2xl border-2 border-indigo-500/30 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-indigo-50 border border-indigo-200 text-indigo-900 text-[11px] font-extrabold mb-1">
                  <span>🏢 कम्पनी: {company.name}</span>
                  <span>➔</span>
                  <span>🏬 शाखा दर्ता</span>
                </div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Plus className="w-5 h-5 text-indigo-700" />
                  <span>
                    {editingBranch
                      ? `✏️ '${company.name}' भित्रको शाखा सच्याउँदै: ${editingBranch.name}`
                      : `‘${company.name}’ कम्पनी भित्र नयाँ शाखा बनाउनुहोस् (Create Branch Inside Company)`}
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  यो शाखा सिधै <strong>{company.name}</strong> कम्पनी अन्तर्गत थपिनेछ। शाखा म्यानेजरको लग-इन मोबाइल/पिन र अधिकार यहीँबाट तोक्नुहोस्।
                </p>
              </div>
              {editingBranch && (
                <button
                  type="button"
                  onClick={resetBranchForm}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold cursor-pointer self-start sm:self-auto"
                >
                  ✕ सम्पादन रद्द गर्नुहोस्
                </button>
              )}
            </div>

            <form onSubmit={handleSaveBranchSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                <div className="sm:col-span-5">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    कम्पनी भित्रको शाखाको नाम (Branch Name): <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={branchNameInput}
                    onChange={(e) => setBranchNameInput(e.target.value)}
                    placeholder="उदा: पोखरा शाखा - पृथ्वीचोक / शाखा नं २"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    शाखा कोड (Code):
                  </label>
                  <input
                    type="text"
                    value={branchCodeInput}
                    onChange={(e) => setBranchCodeInput(e.target.value)}
                    placeholder={`BR-0${activeBranches.length + 1}`}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    बिल सिरिज (Prefix):
                  </label>
                  <input
                    type="text"
                    maxLength={5}
                    value={branchPrefixInput}
                    onChange={(e) => setBranchPrefixInput(e.target.value.toUpperCase())}
                    placeholder="उदा: PKR / BR2"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    शाखाको ठेगाना (Branch Address): <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={branchAddressInput}
                    onChange={(e) => setBranchAddressInput(e.target.value)}
                    placeholder="उदा: पृथ्वीचोक, पोखरा"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                <div className="sm:col-span-3">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    शाखा फोन नं (Branch Phone):
                  </label>
                  <input
                    type="text"
                    value={branchPhoneInput}
                    onChange={(e) => setBranchPhoneInput(e.target.value)}
                    placeholder="०६१-५२XXXX / ९८XXXXXXXX"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    शाखा जिमेल / इमेल (Email):
                  </label>
                  <input
                    type="email"
                    value={branchEmailInput}
                    onChange={(e) => setBranchEmailInput(e.target.value)}
                    placeholder="branch@company.com.np"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono text-slate-900"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    शाखा प्रमुख (Manager Name):
                  </label>
                  <input
                    type="text"
                    value={branchManagerNameInput}
                    onChange={(e) => setBranchManagerNameInput(e.target.value)}
                    placeholder="उदा: हरि प्रसाद शर्मा"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    म्यानेजर लग-इन मोबाइल:
                  </label>
                  <input
                    type="text"
                    maxLength={10}
                    value={branchManagerMobileInput}
                    onChange={(e) => setBranchManagerMobileInput(e.target.value.replace(/\D/g, ''))}
                    placeholder="98XXXXXXXX"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold text-indigo-900"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    शाखा लग-इन पिन (PIN):
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={branchManagerPinInput}
                    onChange={(e) => setBranchManagerPinInput(e.target.value)}
                    placeholder="1234"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>
              </div>

              {/* Admin Control Limits & Initial Permissions */}
              <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-extrabold text-indigo-950 text-xs flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-indigo-700" />
                    <span>एडमिन / ओनरले तोक्ने शाखा अधिकार र सीमा (Admin Branch Permissions & Limits):</span>
                  </span>

                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex items-center gap-1.5">
                      <label className="text-[11px] font-bold text-slate-700">अधिकतम छुट सीमा (%):</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={branchMaxDiscountInput}
                        onChange={(e) => setBranchMaxDiscountInput(Number(e.target.value) || 0)}
                        className="w-16 px-2 py-1 bg-white border border-indigo-300 rounded-lg font-mono font-bold text-center"
                      />
                    </div>
                    <div className="flex items-center gap-1.5">
                      <label className="text-[11px] font-bold text-slate-700">दैनिक खर्च सीमा (रु.):</label>
                      <input
                        type="number"
                        min={0}
                        value={branchDailyExpenseInput}
                        onChange={(e) => setBranchDailyExpenseInput(Number(e.target.value) || 0)}
                        className="w-24 px-2 py-1 bg-white border border-indigo-300 rounded-lg font-mono font-bold text-right"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                  {[
                    { label: '🧾 बिक्री बिल', checked: branchAllowSales, set: setBranchAllowSales },
                    { label: '📦 खरिद दर्ता', checked: branchAllowPurchase, set: setBranchAllowPurchase },
                    { label: '💳 उधारो बिक्री', checked: branchAllowCredit, set: setBranchAllowCredit },
                    { label: '🏷️ छुट दिने', checked: branchAllowDiscount, set: setBranchAllowDiscount },
                    { label: '🔄 स्टक थपघट', checked: branchAllowStock, set: setBranchAllowStock },
                    { label: '💸 खर्च भौचर', checked: branchAllowExpense, set: setBranchAllowExpense },
                    { label: '✏️ सच्याउने/मेटाउने', checked: branchAllowEditDelete, set: setBranchAllowEditDelete }
                  ].map((perm, idx) => (
                    <label
                      key={idx}
                      className={`flex items-center gap-1.5 p-2 rounded-lg border cursor-pointer select-none transition ${
                        perm.checked
                          ? 'bg-white border-emerald-400 text-emerald-950 font-bold'
                          : 'bg-slate-100 border-slate-200 text-slate-500'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={perm.checked}
                        onChange={(e) => perm.set(e.target.checked)}
                        className="w-3.5 h-3.5 rounded text-emerald-600"
                      />
                      <span className="text-[11px]">{perm.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-700 hover:bg-indigo-800 text-white font-black rounded-xl cursor-pointer flex items-center gap-1.5 shadow-md"
                >
                  <Check className="w-4 h-4" />
                  <span>
                    {editingBranch
                      ? `✓ '${company.name}' भित्र शाखा अपडेट गर्नुहोस्`
                      : `+ '${company.name}' भित्र नयाँ शाखा बनाउनुहोस्`}
                  </span>
                </button>
              </div>
            </form>
          </div>

          {/* SECTION 2 INSIDE COMPANY: ADMIN / OWNER LIVE CONTROL PANEL FOR BRANCHES OF SELECTED COMPANY */}
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-emerald-700" />
                  <span>
                    ‘{company.name}’ भित्रका शाखाहरूको एडमिन/ओनर कन्ट्रोल प्यानल ({activeBranches.length} शाखा)
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  यस कम्पनी भित्रका प्रत्येक शाखालाई यहीँबाट चालु/लक (Active/Lock) गर्ने, अधिकार (Permissions) अन/अफ गर्ने र चलाउन पाउने मोड्युल तोक्ने
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {activeBranches.map((br, idx) => {
                const isCurrent = br.id === currentActiveBranch?.id;
                const isLocked = br.status === 'LOCKED';

                return (
                  <div
                    key={br.id}
                    className={`p-4 sm:p-5 rounded-2xl border-2 transition space-y-4 ${
                      isLocked
                        ? 'bg-rose-50/40 border-rose-300'
                        : isCurrent
                        ? 'bg-emerald-50/40 border-emerald-500 shadow-xs'
                        : 'bg-slate-50/70 border-slate-200'
                    }`}
                  >
                    {/* Branch Top Row: Info + Switch / Lock / Edit / Delete buttons */}
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-200/80">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="px-2 py-0.5 bg-slate-900 text-amber-300 font-mono font-black text-xs rounded-md">
                            {br.code}
                          </span>
                          <h4 className="text-sm sm:text-base font-black text-slate-900">
                            {idx + 1}. {br.name}
                          </h4>
                          {br.isMainBranch && (
                            <span className="px-2 py-0.5 bg-indigo-100 text-indigo-900 border border-indigo-300 rounded text-[10px] font-extrabold">
                              🏛️ मुख्य शाखा (Head Office)
                            </span>
                          )}
                          {isCurrent && !isLocked && (
                            <span className="px-2 py-0.5 bg-emerald-600 text-white rounded text-[10px] font-extrabold">
                              ✓ हाल चालु शाखा
                            </span>
                          )}
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-black border ${
                              isLocked
                                ? 'bg-rose-600 text-white border-rose-700'
                                : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            }`}
                          >
                            {isLocked ? '🔒 एडमिनद्वारा लक (LOCKED)' : '🟢 सुचारु (ACTIVE)'}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
                          <span>📍 <strong>{br.address}</strong></span>
                          <span>📞 <strong className="font-mono">{br.phone}</strong></span>
                          {br.email && <span>✉️ <strong className="font-mono">{br.email}</strong></span>}
                          <span>
                            👤 शाखा प्रमुख: <strong>{br.managerName}</strong> (लग-इन ID:{' '}
                            <strong className="font-mono text-indigo-800">{br.managerMobile}</strong> | PIN:{' '}
                            <strong className="font-mono">{br.managerPin}</strong>)
                          </span>
                          {br.billPrefix && (
                            <span>
                              🧾 बिल सिरिज: <strong className="font-mono">{br.billPrefix}</strong>
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Admin Quick Control Buttons */}
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        {!isCurrent && !isLocked && (
                          <button
                            type="button"
                            onClick={() => handleSwitchActiveBranch(br)}
                            className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold cursor-pointer shadow-2xs"
                          >
                            ✓ यो शाखा चलाउनुहोस्
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => handleToggleBranchLockStatus(br)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1 border ${
                            isLocked
                              ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700'
                              : 'bg-amber-100 hover:bg-amber-200 text-amber-950 border-amber-300'
                          }`}
                        >
                          {isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                          <span>{isLocked ? 'शाखा अनलक (Unlock)' : 'शाखा लक (Lock)'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleEditBranchSelect(br)}
                          className="px-3 py-1.5 bg-white hover:bg-indigo-50 text-indigo-900 border border-indigo-200 rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>सच्याउने</span>
                        </button>

                        {!br.isMainBranch && activeBranches.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleDeleteBranch(br)}
                            className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl cursor-pointer"
                            title="यो शाखा हटाउनुहोस्"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Live Granular Branch Permissions Checkboxes */}
                    <div className="space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-[11px] font-extrabold text-slate-800">
                          🛡️ एडमिन कन्ट्रोल १: शाखाले गर्न पाउने कामको अधिकार (Live Branch Action Permissions):
                        </span>
                        <div className="flex flex-wrap items-center gap-3 text-xs">
                          <div className="flex items-center gap-1">
                            <span className="text-[11px] font-bold text-slate-600">छुट सीमा %:</span>
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={br.maxDiscountPercent ?? 10}
                              onChange={(e) =>
                                handleUpdateBranchLimit(
                                  br.id,
                                  'maxDiscountPercent',
                                  Number(e.target.value) || 0
                                )
                              }
                              className="w-14 px-2 py-0.5 bg-white border border-slate-300 rounded font-mono font-bold text-center text-xs"
                            />
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="text-[11px] font-bold text-slate-600">दैनिक खर्च सीमा रु.:</span>
                            <input
                              type="number"
                              min={0}
                              value={br.dailyExpenseLimit ?? 20000}
                              onChange={(e) =>
                                handleUpdateBranchLimit(
                                  br.id,
                                  'dailyExpenseLimit',
                                  Number(e.target.value) || 0
                                )
                              }
                              className="w-24 px-2 py-0.5 bg-white border border-slate-300 rounded font-mono font-bold text-right text-xs"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                        {(
                          [
                            { key: 'allowSalesBilling', label: '🧾 बिक्री बिल' },
                            { key: 'allowPurchaseEntry', label: '📦 खरिद दर्ता' },
                            { key: 'allowCreditSales', label: '💳 उधारो बिक्री' },
                            { key: 'allowDiscount', label: '🏷️ छुट दिने' },
                            { key: 'allowStockTransfer', label: '🔄 स्टक थपघट' },
                            { key: 'allowExpenseVoucher', label: '💸 खर्च भौचर' },
                            { key: 'allowDeleteOrEdit', label: '✏️ सच्याउने/मेटाउने' }
                          ] as { key: keyof BranchOffice['permissions']; label: string }[]
                        ).map((pItem) => {
                          const isAllowed = Boolean(br.permissions[pItem.key]);
                          return (
                            <label
                              key={pItem.key}
                              className={`flex items-center gap-1.5 p-2 rounded-xl border text-xs cursor-pointer select-none transition ${
                                isAllowed
                                  ? 'bg-white border-emerald-400 text-emerald-950 font-bold shadow-2xs'
                                  : 'bg-slate-100 border-slate-200 text-slate-400'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={isAllowed}
                                onChange={(e) =>
                                  handleToggleBranchPermission(br.id, pItem.key, e.target.checked)
                                }
                                className="w-3.5 h-3.5 rounded text-emerald-600"
                              />
                              <span className="text-[11px] truncate">{pItem.label}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Allowed Modules / Tabs for this Branch */}
                    <div className="space-y-1.5 pt-2 border-t border-slate-200/70">
                      <span className="text-[11px] font-extrabold text-slate-800 block">
                        👑 एडमिन कन्ट्रोल २: यस शाखाले खोल्न र चलाउन पाउने मेनु/मोड्युलहरू (Allowed Branch Modules):
                      </span>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {ALL_DASHBOARD_TABS.filter((t) => t.id !== 'settings').map((tabItem) => {
                          const isTabAllowed = (br.permissions.allowedTabs || []).includes(tabItem.id);
                          return (
                            <button
                              key={tabItem.id}
                              type="button"
                              onClick={() => handleToggleBranchAllowedTab(br.id, tabItem.id)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border transition cursor-pointer ${
                                isTabAllowed
                                  ? 'bg-indigo-600 text-white border-indigo-700'
                                  : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              {isTabAllowed ? '✓ ' : '+ '}
                              {tabItem.labelNe}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 0: WORK CATEGORIES, SITE NOTES, SHIFT TIME, GPS & STAFF MASTER        */}
      {/* ========================================================================= */}
      {activeTab === 'WORK_ATTENDANCE' && (
        <div className="space-y-6">
          {saveSuccess && (
            <div className="p-3 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center justify-between shadow-sm">
              <span>✓ मास्टर सेटिङ सफलतापूर्वक सुरक्षित गरियो! (हाजिरी पेजमा स्वतः लागु भयो)</span>
              <button
                type="button"
                onClick={() => setGlobalActiveTab('attendance')}
                className="px-3 py-1 bg-white text-emerald-900 rounded-lg font-extrabold cursor-pointer"
              >
                👷 हाजिरी पेज खोल्नुहोस् →
              </button>
            </div>
          )}

          {/* SECTION 1: WORK CATEGORIES MASTER (टनेल बनाउने, प्लास्टिक राख्ने, ट्याक्टर बनाउने, फिटिङ गर्ने, अरुकोमा जाने) */}
          <div className="bg-white p-5 sm:p-6 rounded-2xl border-2 border-emerald-600/30 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-emerald-700" />
                  <span>
                    {isNe
                      ? '१. काम अनुसार स्टाफ हाजिरी क्याटगोरी सेटिङ (टनेल, प्लास्टिक, ट्याक्टर, फिटिङ, फिल्ड काम)'
                      : '1. Staff Work Categories Master Configuration'}
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isNe
                    ? 'स्टाफ हाजिरी र मासिक प्रिन्ट सिटमा देखिने कामका प्रकारहरू र डिफल्ट साइट टिपोट यहीँबाट थप्नुहोस् वा सच्याउनुहोस्'
                    : 'Configure work categories and default site notes used in daily staff attendance and monthly sheets'}
                </p>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={handleResetDefaultWorkCategories}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold cursor-pointer"
                >
                  ↺ डिफल्ट रिसेट
                </button>
                <button
                  type="button"
                  onClick={() => setGlobalActiveTab('attendance')}
                  className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold cursor-pointer shadow-xs"
                >
                  👷 हाजिरी पेजमा जानुहोस् →
                </button>
              </div>
            </div>

            {/* Existing Work Categories Table / List */}
            <div className="space-y-2.5 text-xs">
              {activeWorkCategories.map((cat, idx) => (
                <div
                  key={cat.id}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center"
                >
                  <div className="sm:col-span-4">
                    <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                      {idx + 1}. कामको नाम (नेपालीमा):
                    </label>
                    <input
                      type="text"
                      value={cat.shortNe}
                      onChange={(e) =>
                        handleUpdateWorkCategoryItem(cat.id, {
                          shortNe: e.target.value,
                          labelNe: `${e.target.value} (${cat.labelEn})`
                        })
                      }
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                    />
                  </div>

                  <div className="sm:col-span-4">
                    <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                      डिफल्ट साइट टिपोट (Default Site Note):
                    </label>
                    <input
                      type="text"
                      value={cat.defaultSiteNote || ''}
                      onChange={(e) =>
                        handleUpdateWorkCategoryItem(cat.id, {
                          defaultSiteNote: e.target.value
                        })
                      }
                      placeholder="उदा: टनेल निर्माण साइट / ग्राहकको फार्म..."
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-800"
                    />
                  </div>

                  <div className="sm:col-span-3 flex items-center pt-3 sm:pt-4">
                    <label className="flex items-center gap-1.5 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={!!cat.isFieldWork}
                        onChange={(e) =>
                          handleUpdateWorkCategoryItem(cat.id, {
                            isFieldWork: e.target.checked
                          })
                        }
                        className="w-4 h-4 rounded text-emerald-600"
                      />
                      <span className="text-[11px] font-bold text-slate-700">
                        {cat.isFieldWork ? '🚗 फिल्ड/बाहिरी काम (GPS खुल्ला)' : '🏭 वर्कसप भित्रको काम'}
                      </span>
                    </label>
                  </div>

                  <div className="sm:col-span-1 flex justify-end pt-2 sm:pt-4">
                    <button
                      type="button"
                      onClick={() => handleDeleteWorkCategoryItem(cat.id)}
                      className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                      title="हटाउनुहोस्"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add New Work Category Form */}
            <form
              onSubmit={handleAddWorkCategoryMaster}
              className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-3 text-xs"
            >
              <span className="font-bold text-emerald-950 block">
                + नयाँ कामको प्रकार थप्नुहोस् (Add New Work Category):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 items-end">
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    कामको नाम (जस्तै: 🔩 वेल्डिङ गर्ने):*
                  </label>
                  <input
                    type="text"
                    required
                    value={newWorkShortNe}
                    onChange={(e) => setNewWorkShortNe(e.target.value)}
                    placeholder="उदा: 🔩 वेल्डिङ गर्ने"
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-lg font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    डिफल्ट साइट टिपोट (ऐच्छिक):
                  </label>
                  <input
                    type="text"
                    value={newWorkDefaultSite}
                    onChange={(e) => setNewWorkDefaultSite(e.target.value)}
                    placeholder="उदा: फिल्ड वेल्डिङ साइट"
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-lg text-slate-900"
                  />
                </div>

                <div>
                  <label className="flex items-center gap-2 py-2 px-2.5 bg-white border border-emerald-200 rounded-lg cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={newWorkIsField}
                      onChange={(e) => setNewWorkIsField(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-600"
                    />
                    <span className="font-bold text-[11px] text-slate-800">
                      फिल्ड / बाहिरी काम हो
                    </span>
                  </label>
                </div>

                <button
                  type="submit"
                  className="py-2 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>काम थप्नुहोस्</span>
                </button>
              </div>
            </form>
          </div>

          {/* SECTION 2: SITE NOTES & CLIENT FIELD LOCATION PRESETS (साइट टिपोट सेटिङ) */}
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <MapPin className="w-5 h-5 text-amber-600" />
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {isNe
                    ? '२. साइट टिपोट तथा फिल्ड ठाउँहरूको सूची (Site Notes & Field Location Presets)'
                    : '2. Site Notes & Field Location Presets'}
                </h2>
                <p className="text-xs text-slate-500">
                  {isNe
                    ? 'यहाँ राखिएका ठाउँ र साइट टिपोटहरू हाजिरी गर्दा १-क्लिकमै छान्न मिल्ने गरी देखिन्छन्'
                    : 'Pre-configured site notes appear as 1-click chips on the attendance screen'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {activeSitePresets.map((preset, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-xl text-xs font-bold text-amber-950"
                >
                  <span>📍 {preset}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveSitePreset(preset)}
                    className="text-rose-600 hover:text-rose-800 p-0.5 cursor-pointer"
                    title="हटाउनुहोस्"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <form onSubmit={handleAddSitePreset} className="flex flex-col sm:flex-row gap-2 text-xs">
              <input
                type="text"
                value={newSitePresetInput}
                onChange={(e) => setNewSitePresetInput(e.target.value)}
                placeholder="नयाँ साइट वा ग्राहकको ठाउँ लेख्नुहोस् (उदा: राम थापाको टनेल साइट - भरतपुर)..."
                className="flex-1 px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-medium"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>साइट टिपोट थप्नुहोस्</span>
              </button>
            </form>
          </div>

          {/* SECTION 3: SHIFT TIMING & WORKPLACE GPS GEOFENCE MASTER SETTINGS */}
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Clock className="w-5 h-5 text-blue-700" />
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {isNe
                    ? '३. हाजिरी सिफ्ट समय र कार्यस्थल GPS परिधि सेटिङ (Shift Hours & GPS Geofence)'
                    : '3. Shift Hours & Workplace GPS Geofence Master Settings'}
                </h2>
                <p className="text-xs text-slate-500">
                  {isNe
                    ? 'हाजिरी हुने समय (In/Out) र कार्यस्थलको GPS लोकेसन तथा परिधि (Radius) यहीँबाट नियन्त्रण गर्नुहोस्'
                    : 'Control official clock-in/out shift hours and workplace GPS radius'}
                </p>
              </div>
            </div>

            <form onSubmit={handleSaveShiftAndGpsMaster} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    बिहानी हाजिरी समय (Shift Start / Log In):
                  </label>
                  <input
                    type="text"
                    value={shiftStartInput}
                    onChange={(e) => setShiftStartInput(e.target.value)}
                    placeholder="10:00 AM"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    साँझ बिदा समय (Shift End / Log Out):
                  </label>
                  <input
                    type="text"
                    value={shiftEndInput}
                    onChange={(e) => setShiftEndInput(e.target.value)}
                    placeholder="05:00 PM"
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    ढिलो आउन पाउने छुट (Grace Minutes):
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={lateGraceInput}
                    onChange={(e) => setLateGraceInput(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-100">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    मुख्य कार्यस्थलको नाम (Workplace Label):
                  </label>
                  <input
                    type="text"
                    value={workplaceLabelInput}
                    onChange={(e) => setWorkplaceLabelInput(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    अनुमति प्राप्त GPS परिधि (Allowed Radius):
                  </label>
                  <select
                    value={workplaceRadiusInput}
                    onChange={(e) => setWorkplaceRadiusInput(parseInt(e.target.value) || 200)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold text-slate-900 bg-white"
                  >
                    <option value={50}>५० मिटर (कडा स्टोर मात्र / 50m)</option>
                    <option value={100}>१०० मिटर (स्टोर तथा वर्कसप / 100m)</option>
                    <option value={200}>२०० मिटर (कार्यालय हाता / 200m)</option>
                    <option value={500}>५०० मिटर (वरपर क्षेत्र / 500m)</option>
                    <option value={2000}>२००० मिटर (२ कि.मि. क्षेत्र)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    कार्यस्थल GPS लोकेसन सेट गर्नुहोस्:
                  </label>
                  <button
                    type="button"
                    onClick={handlePinCurrentGpsInMaster}
                    disabled={isFetchingGpsMaster}
                    className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Navigation className="w-3.5 h-3.5 text-emerald-400" />
                    <span>
                      {isFetchingGpsMaster
                        ? 'GPS लोकेसन लिँदै...'
                        : workplaceLatInput
                        ? `✓ GPS सेट छ (${workplaceLatInput}, ${workplaceLngInput})`
                        : 'हालको स्थानलाई कार्यस्थल GPS तोक्नुहोस्'}
                    </span>
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <div className="flex flex-wrap items-center gap-4">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={autoShiftTimeInput}
                      onChange={(e) => setAutoShiftTimeInput(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-600"
                    />
                    <span className="font-bold text-slate-800">
                      हाजिर गर्दा सिफ्ट समय स्वतः सेट हुने
                    </span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={enforceGpsInput}
                      onChange={(e) => setEnforceGpsInput(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-600"
                    />
                    <span className="font-bold text-slate-800">
                      वर्कसप काममा GPS परिधि बाहिर हाजिरी रोक्ने (फिल्ड काममा खुल्ला)
                    </span>
                  </label>
                </div>

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>समय र GPS सेटिङ सुरक्षित गर्नुहोस्</span>
                </button>
              </div>
            </form>
          </div>

          {/* SECTION 4: STAFF & DAILY WAGE / MONTHLY SALARY MASTER SETTINGS */}
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-700" />
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    {isNe
                      ? '४. कर्मचारी तथा दैनिक ज्याला / मासिक तलब दर सेटिङ (Staff & Wage Master)'
                      : '4. Staff Roster & Daily/Monthly Wage Master'}
                  </h2>
                  <p className="text-xs text-slate-500">
                    {isNe
                      ? 'कर्मचारी थप्ने वा निजको पद, फोन र दैनिक ज्याला / मासिक तलब दर यहीँबाट मिलाउनुहोस्'
                      : 'Add or edit employees and their daily wage or monthly salary rates'}
                  </p>
                </div>
              </div>
            </div>

            {/* Staff Form */}
            <form
              onSubmit={handleSaveStaffInMaster}
              className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs"
            >
              <span className="font-bold text-slate-800 block">
                {editingStaff
                  ? `✏️ कर्मचारी सच्याउँदै (Rename / Edit Staff): ${editingStaff.name}`
                  : '+ नयाँ कर्मचारी वा मिस्त्री थप्नुहोस् (Add Staff with Login ID):'}
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 items-end">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1">
                    स्टाफ आईडी (Staff ID):
                  </label>
                  <input
                    type="text"
                    value={staffCodeInput}
                    onChange={(e) => setStaffCodeInput(e.target.value)}
                    placeholder={`STF-${String(employees.length + 1).padStart(3, '0')}`}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1">
                    कर्मचारीको नाम (Name):*
                  </label>
                  <input
                    type="text"
                    required
                    value={staffNameInput}
                    onChange={(e) => setStaffNameInput(e.target.value)}
                    placeholder="उदा: राम बहादुर थापा"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1">
                    पद / काम (Designation):
                  </label>
                  <input
                    type="text"
                    value={staffRoleInput}
                    onChange={(e) => setStaffRoleInput(e.target.value)}
                    placeholder="टनेल/ट्याक्टर मिस्त्री"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1">
                    प्रणाली अधिकार (System Role):
                  </label>
                  <select
                    value={staffSystemRoleInput}
                    onChange={(e) => setStaffSystemRoleInput(e.target.value as UserRole)}
                    className="w-full px-2.5 py-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                  >
                    <option value="STAFF">👤 STAFF (हाजिर मात्र)</option>
                    <option value="SUPERVISOR">👷 SUPERVISOR (सुपरभाइजर)</option>
                    <option value="SALESMAN">🏷️ SALESMAN (सेल्सम्यान)</option>
                    <option value="COUNTER_SALES">🛒 COUNTER SALES (काउन्टर बिलिङ)</option>
                    <option value="ACCOUNTANT">📊 ACCOUNTANT (लेखापाल)</option>
                    <option value="ADMINISTRATION">🛡️ ADMINISTRATION (प्रशासक)</option>
                    <option value="OWNER">👑 OWNER (मालिक)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1">
                    लग-इन मोबाइल नं (10-digit Login ID):
                  </label>
                  <input
                    type="text"
                    maxLength={10}
                    value={staffLoginMobileInput}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '');
                      setStaffLoginMobileInput(val);
                      if (!staffPhoneInput) setStaffPhoneInput(val);
                    }}
                    placeholder="9841XXXXXX"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1">
                    लग-इन पिन (Login PIN):
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={staffLoginPinInput}
                    onChange={(e) => setStaffLoginPinInput(e.target.value)}
                    placeholder="1234"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-1">
                    ज्याला प्रकार र दर (Wage):
                  </label>
                  <div className="flex gap-1">
                    <select
                      value={staffWageTypeInput}
                      onChange={(e) => setStaffWageTypeInput(e.target.value as 'DAILY' | 'MONTHLY')}
                      className="px-2 py-2 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                    >
                      <option value="DAILY">दैनिक</option>
                      <option value="MONTHLY">मासिक</option>
                    </select>
                    {staffWageTypeInput === 'DAILY' ? (
                      <input
                        type="number"
                        value={staffDailyRateInput}
                        onChange={(e) => setStaffDailyRateInput(parseFloat(e.target.value) || 0)}
                        className="w-full px-2.5 py-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                      />
                    ) : (
                      <input
                        type="number"
                        value={staffMonthlySalInput}
                        onChange={(e) => setStaffMonthlySalInput(parseFloat(e.target.value) || 0)}
                        className="w-full px-2.5 py-2 bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                      />
                    )}
                  </div>
                </div>

                <div className="flex gap-1.5">
                  <button
                    type="submit"
                    className="flex-1 py-2 px-3 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-lg cursor-pointer"
                  >
                    {editingStaff ? '✓ अपडेट गर्नुहोस्' : '+ कर्मचारी थप्नुहोस्'}
                  </button>
                  {editingStaff && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingStaff(null);
                        setStaffCodeInput('');
                        setStaffNameInput('');
                        setStaffRoleInput('');
                        setStaffPhoneInput('');
                        setStaffLoginMobileInput('');
                      }}
                      className="py-2 px-2.5 bg-slate-200 text-slate-700 font-bold rounded-lg cursor-pointer"
                    >
                      रद्द
                    </button>
                  )}
                </div>
              </div>
            </form>

            {/* Existing Employees List with Rename, Approve, ID Print & Delete */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {employees.map((emp) => (
                <div
                  key={emp.id}
                  className="p-3.5 rounded-xl border border-slate-200 bg-white flex flex-col justify-between gap-2.5 shadow-2xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="px-1.5 py-0.5 bg-purple-100 text-purple-900 font-mono font-extrabold text-[10px] rounded">
                          {emp.staffCode || emp.id.slice(0, 6).toUpperCase()}
                        </span>
                        <p className="font-bold text-slate-900 text-sm">{emp.name}</p>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                            emp.approvalStatus === 'PENDING_APPROVAL'
                              ? 'bg-amber-100 text-amber-900'
                              : 'bg-emerald-100 text-emerald-900'
                          }`}
                        >
                          {emp.approvalStatus === 'PENDING_APPROVAL' ? '⏳ स्वीकृति बाँकी' : '✓ स्वीकृत'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        {emp.role} ·{' '}
                        <span className="font-mono font-bold text-emerald-800">
                          {emp.wageType === 'DAILY'
                            ? `दैनिक रु. ${emp.dailyWageRate || 1000}`
                            : `मासिक रु. ${emp.salaryMonthly}`}
                        </span>
                      </p>
                      <p className="text-[10px] font-mono text-slate-500 mt-0.5">
                        📱 लग-इन ID: <strong>{emp.loginMobile || emp.phone || '-'}</strong> | PIN:{' '}
                        <strong>{emp.loginPin || '1234'}</strong> | Role:{' '}
                        <strong>{emp.systemRole || 'STAFF'}</strong>
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-end gap-1.5 pt-2 border-t border-slate-100">
                    {emp.approvalStatus === 'PENDING_APPROVAL' && (
                      <button
                        type="button"
                        onClick={() => {
                          saveEmployee({ ...emp, approvalStatus: 'APPROVED' });
                          showToast(`✓ ${emp.name} को स्टाफ खाता स्वीकृत गरियो!`);
                        }}
                        className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[10px] cursor-pointer"
                      >
                        ✓ स्वीकृत
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        printOrDownloadReportPdf({
                          company,
                          titleNe: `कर्मचारी परिचयपत्र तथा विवरण (${emp.name})`,
                          titleEn: `Staff ID & Details - ${emp.name}`,
                          headers: ['विवरण (Field)', 'जानकारी (Information)'],
                          rows: [
                            ['स्टाफ आईडी (Staff ID)', emp.staffCode || emp.id],
                            ['कर्मचारीको नाम (Name)', emp.name],
                            ['पद / जिम्मेवारी (Role)', emp.role],
                            ['प्रणाली अधिकार (System Role)', emp.systemRole || 'STAFF'],
                            ['सम्पर्क / लग-इन मोबाइल', emp.loginMobile || emp.phone || '-'],
                            [
                              'ज्याला / तलब दर',
                              emp.wageType === 'DAILY'
                                ? `दैनिक रु. ${emp.dailyWageRate || 1000}`
                                : `मासिक रु. ${emp.salaryMonthly}`
                            ],
                            ['आबद्ध मिति (Joined BS)', emp.joinedDateBs]
                          ],
                          mode: 'PRINT'
                        });
                      }}
                      className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg font-bold text-[10px] cursor-pointer flex items-center gap-1"
                    >
                      <Printer className="w-3 h-3" />
                      <span>ID प्रिन्ट</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setEditingStaff(emp);
                        setStaffCodeInput(emp.staffCode || '');
                        setStaffNameInput(emp.name);
                        setStaffRoleInput(emp.role);
                        setStaffSystemRoleInput(emp.systemRole || 'STAFF');
                        setStaffPhoneInput(emp.phone || '');
                        setStaffLoginMobileInput(emp.loginMobile || emp.phone || '');
                        setStaffLoginPinInput(emp.loginPin || '1234');
                        setStaffApprovalInput(emp.approvalStatus || 'APPROVED');
                        setStaffWageTypeInput(emp.wageType || 'DAILY');
                        setStaffDailyRateInput(emp.dailyWageRate || 1000);
                        setStaffMonthlySalInput(emp.salaryMonthly || 25000);
                        setStaffOpeningDueInput(emp.openingDue || 0);
                      }}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 rounded-lg font-bold text-[10px] cursor-pointer flex items-center gap-1"
                    >
                      <Edit2 className="w-3 h-3" />
                      <span>सच्याउने / नाम फेर्ने</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        deleteEmployee(emp.id);
                        showToast(`✓ कर्मचारी '${emp.name}' हटाइयो।`);
                      }}
                      className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[10px] cursor-pointer flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>हटाउने</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1: COMPANY PROFILE, LOGO & MULTI-COMPANY HUB (फर्मको विवरण)          */}
      {/* ========================================================================= */}
      {activeTab === 'COMPANY' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Building className="w-5 h-5 text-emerald-700" />
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {isNe ? 'आधिकारिक फर्म तथा व्यापारिक विवरण (Company Profile & Logo)' : 'Company Credentials & Logo'}
                </h2>
                <p className="text-xs text-slate-500">
                  {isNe
                    ? 'कम्पनीको नाम, लोगो, स्थायी लेखा नम्बर (PAN/VAT) र सम्पर्क यहीँबाट तुरुन्तै सच्याउनुहोस्'
                    : 'Update company name, logo, PAN/VAT number and contact details'}
                </p>
              </div>
            </div>

            {/* Company Logo Upload Box */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-3.5">
                {logoUrl ? (
                  <img
                    src={logoUrl}
                    alt="Company Logo"
                    className="w-16 h-16 rounded-xl object-contain bg-white border border-slate-300 p-1 shadow-2xs"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs border border-emerald-300">
                    LOGO
                  </div>
                )}
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    {isNe ? 'कम्पनीको आधिकारिक लोगो (Company Logo)' : 'Official Company Logo'}
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {isNe
                      ? 'यो लोगो भ्याट बिल, नन-भ्याट रसिद, बैंक स्टेटमेन्ट र सबै PDF रिपोर्टमा छापिन्छ।'
                      : 'Printed on VAT invoices, receipts, and all PDF reports.'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={logoInputRef}
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => logoInputRef.current?.click()}
                  className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{logoUrl ? 'लोगो परिवर्तन गर्नुहोस्' : '+ लोगो अपलोड गर्नुहोस्'}</span>
                </button>
                {logoUrl && (
                  <button
                    type="button"
                    onClick={() => {
                      setLogoUrl('');
                      updateCompanyProfile({ ...company, logoUrl: undefined });
                      showToast('लोगो हटाइयो।');
                    }}
                    className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl cursor-pointer"
                  >
                    हटाउने
                  </button>
                )}
              </div>
            </div>

            <form onSubmit={handleSaveCompany} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'फर्म / कम्पनीको नाम (Company Name / Rename)*' : 'Company Name*'}
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm font-bold text-slate-900 focus:ring-1 focus:ring-emerald-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg cursor-pointer whitespace-nowrap shadow-xs"
                  >
                    ✓ नाम र विवरण सेभ गर्नुहोस्
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'PAN / VAT नं. (९ अंकको स्थायी लेखा नम्बर)*' : 'PAN/VAT Number (9 digits)*'}
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={9}
                    value={pan}
                    onChange={(e) => setPan(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-sm focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'फोन नम्बर (Mobile / Landline)*' : 'Phone Number*'}
                  </label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-sm focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'ठेगाना (Address)*' : 'Address*'}
                  </label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'इमेल / जिमेल ठेगाना (Company Gmail)' : 'Email / Gmail'}
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (!backupGmail) setBackupGmail(e.target.value);
                    }}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                {saveSuccess ? (
                  <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                    <Check className="w-4 h-4" />
                    <span>{isNe ? 'सफलतापूर्वक सुरक्षित गरियो!' : 'Saved successfully!'}</span>
                  </span>
                ) : (
                  <div />
                )}

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-xl shadow-xs transition cursor-pointer"
                >
                  {isNe ? 'विवरण सुरक्षित गर्नुहोस् (Save Profile)' : 'Save Profile'}
                </button>
              </div>
            </form>
          </div>

          {/* MULTI-COMPANY MANAGEMENT HUB (फरक-फरक कम्पनी थप्ने र छान्ने) */}
          <div className="bg-white p-6 rounded-2xl border-2 border-emerald-600/30 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Building className="w-5 h-5 text-emerald-700" />
                  <span>
                    {isNe
                      ? 'बहु-कम्पनी व्यवस्थापन (फरक-फरक कम्पनी थप्ने, छान्ने र चलाउने)'
                      : 'Multi-Company Workspace Management'}
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isNe
                    ? 'प्रत्येक कम्पनीको आफ्नै छुट्टै कर्मचारी, हाजिरी, स्टक, बिलिङ, बैंक र पार्टी हिसाब हुन्छ तर प्रणाली सुविधा एउटै रहन्छ'
                    : 'Each company has its own isolated staff, inventory, billing, bank and ledger with identical ERP features'}
                </p>
              </div>
              <span className="px-3 py-1 bg-emerald-100 text-emerald-900 rounded-lg text-xs font-bold">
                कुल कम्पनी: {companiesList.length}
              </span>
            </div>

            {/* Existing Companies List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              {companiesList.map((comp, idx) => {
                const isActive = comp.id === activeCompanyId;
                return (
                  <div
                    key={comp.id}
                    className={`p-4 rounded-xl border-2 flex flex-col justify-between gap-3 transition ${
                      isActive
                        ? 'bg-emerald-50/80 border-emerald-600 shadow-xs'
                        : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-sm text-slate-900">
                            {idx + 1}. {isActive ? company.name : comp.name}
                          </span>
                          {isActive && (
                            <span className="px-2 py-0.5 bg-emerald-700 text-white rounded text-[10px] font-bold">
                              ✓ सक्रिय (Active)
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-600 mt-0.5">
                          PAN: <strong className="font-mono">{comp.panVatNo || '-'}</strong> | ठेगाना:{' '}
                          <strong>{comp.address || '-'}</strong>
                        </p>
                      </div>

                      {companiesList.length > 1 && (
                        <button
                          type="button"
                          onClick={() => {
                            const res = deleteCompanyById(comp.id);
                            showToast(res.message);
                          }}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg cursor-pointer"
                          title="कम्पनी मेटाउनुहोस्"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200/80">
                      <button
                        type="button"
                        onClick={() => {
                          if (!isActive) switchCompany(comp.id);
                          setActiveTab('BRANCHES');
                          showToast(`✓ '${comp.name}' भित्रका शाखाहरू खुल्यो!`);
                        }}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg cursor-pointer flex items-center gap-1"
                      >
                        <span>🏬 यस कम्पनी भित्र शाखा बनाउने / हेर्ने</span>
                      </button>

                      {!isActive && (
                        <button
                          type="button"
                          onClick={() => {
                            switchCompany(comp.id);
                            showToast(`✓ अब '${comp.name}' कम्पनी छानियो!`);
                          }}
                          className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg cursor-pointer"
                        >
                          छान्नुहोस् (Switch)
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Add New Separate Company Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newCompName.trim()) return;
                const created = createNewCompany({
                  name: newCompName.trim(),
                  panVatNo: newCompPan.trim(),
                  phone: newCompPhone.trim(),
                  address: newCompAddress.trim(),
                  includeStarterCatalog: newCompStarter
                });
                setNewCompName('');
                setNewCompPan('');
                setNewCompPhone('');
                setNewCompAddress('');
                showToast(`✓ अलग्गै नयाँ कम्पनी '${created.name}' थपियो र सक्रिय भयो!`);
              }}
              className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-xl space-y-3 text-xs"
            >
              <span className="font-bold text-emerald-950 block">
                + अलग्गै नयाँ कम्पनी थप्नुहोस् (Add New Separate Company):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    नयाँ कम्पनीको नाम:*
                  </label>
                  <input
                    type="text"
                    required
                    value={newCompName}
                    onChange={(e) => setNewCompName(e.target.value)}
                    placeholder="उदा: हिमालय एग्रो प्रा.लि."
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-lg font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    PAN / VAT नं.:
                  </label>
                  <input
                    type="text"
                    maxLength={9}
                    value={newCompPan}
                    onChange={(e) => setNewCompPan(e.target.value)}
                    placeholder="9-digit PAN"
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-lg font-mono text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    फोन नम्बर:
                  </label>
                  <input
                    type="text"
                    value={newCompPhone}
                    onChange={(e) => setNewCompPhone(e.target.value)}
                    placeholder="98XXXXXXXX"
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-lg font-mono text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    ठेगाना:
                  </label>
                  <input
                    type="text"
                    value={newCompAddress}
                    onChange={(e) => setNewCompAddress(e.target.value)}
                    placeholder="काठमाडौँ / चितवन"
                    className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-lg text-slate-900"
                  />
                </div>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={newCompStarter}
                    onChange={(e) => setNewCompStarter(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600"
                  />
                  <span className="font-bold text-slate-700 text-[11px]">
                    नमुना सामानहरू (Starter Items) सहित सुरु गर्ने (खाली राख्दा ० बाट सुरु हुन्छ)
                  </span>
                </label>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ नयाँ कम्पनी दर्ता र सुरु गर्नुहोस्</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: CUSTOMER / PARTY MASTER (ग्राहक/पार्टी सच्याउने र मेटाउने)           */}
      {/* ========================================================================= */}
      {activeTab === 'CUSTOMERS' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-700" />
                <span>
                  {isNe
                    ? 'ग्राहक तथा सप्लायर पार्टी विवरण सम्पादन र मेटाउने (Customer / Party Master)'
                    : 'Customer & Supplier Party Master'}
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                {isNe
                  ? 'ग्राहक वा पार्टीको नाम फेर्ने (Rename), ठेगाना, फोन, प्यान, बाँकी रकम सच्याउने र हटाउने (Delete) एकमात्र मुख्य ठाउँ'
                  : 'Rename, edit or delete customer and supplier party records exclusively from Master Settings'}
              </p>
            </div>

            <button
              onClick={() => {
                setEditingParty(null);
                setPartyName('');
                setPartyAddress('');
                setPartyPhone('');
                setPartyPan('');
                setPartyTypeInput('CUSTOMER');
                setPartyOpeningDue(0);
                setIsAddPartyOpen(true);
              }}
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5 self-start sm:self-auto shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{isNe ? '+ नयाँ ग्राहक / पार्टी थप्नुहोस्' : '+ Add Customer / Party'}</span>
            </button>
          </div>

          {/* Search bar */}
          <div className="relative">
            <input
              type="text"
              placeholder={isNe ? 'ग्राहक/पार्टीको नाम, ठेगाना, प्यान वा फोन नम्बरले खोज्नुहोस्...' : 'Search by name, address, phone...'}
              value={customerSearch}
              onChange={(e) => setCustomerSearch(e.target.value)}
              className="w-full pl-3 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Customers Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">नाम (Name)</th>
                  <th className="py-2.5 px-3">प्रकार</th>
                  <th className="py-2.5 px-3">ठेगाना (Address)</th>
                  <th className="py-2.5 px-3">सम्पर्क (Phone)</th>
                  <th className="py-2.5 px-3">प्यान (PAN)</th>
                  <th className="py-2.5 px-3 text-right">हाल बाँकी रकम</th>
                  <th className="py-2.5 px-3 text-center">म्यासेजिङ</th>
                  <th className="py-2.5 px-3 text-center">सच्याउने / हटाउने (Master Actions)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredParties.map((p) => {
                  const currentDue = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
                  const statementText = buildCustomerStatementMessage(p, company);

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 px-3 font-bold text-slate-900">{p.name}</td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            p.partyType === 'SUPPLIER'
                              ? 'bg-purple-100 text-purple-900'
                              : 'bg-emerald-100 text-emerald-900'
                          }`}
                        >
                          {p.partyType === 'SUPPLIER' ? 'सप्लायर' : 'ग्राहक'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px]">
                          <MapPin className="w-3 h-3 text-emerald-600" />
                          <span>{p.address || '-'}</span>
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-700">{p.phone || '-'}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-500">{p.panNo || '-'}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700">
                        {formatCurrency(currentDue, isNe)}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => shareViaWhatsApp(p.phone, statementText)}
                            title="WhatsApp मा पठाउनुहोस्"
                            className="p-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded cursor-pointer"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => shareViaSms(p.phone, statementText)}
                            title="SMS मा पठाउनुहोस्"
                            className="p-1 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded cursor-pointer"
                          >
                            <Smartphone className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={async () => {
                              await copyMessageToClipboard(statementText);
                              showToast(isNe ? '✓ विवरण कपी भयो !' : '✓ Copied!');
                            }}
                            title="विवरण कपी गर्नुहोस्"
                            className="p-1 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded cursor-pointer"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => {
                              setEditingParty(p);
                              setPartyName(p.name);
                              setPartyAddress(p.address || '');
                              setPartyPhone(p.phone || '');
                              setPartyPan(p.panNo || '');
                              setPartyTypeInput(p.partyType || 'CUSTOMER');
                              setPartyOpeningDue(currentDue || 0);
                              setIsAddPartyOpen(true);
                            }}
                            className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded text-[11px] font-semibold transition cursor-pointer flex items-center gap-1"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>{isNe ? 'सच्याउने / नाम फेर्ने' : 'Rename / Edit'}</span>
                          </button>
                          <button
                            onClick={() => {
                              deleteParty(p.id);
                              showToast(`✓ '${p.name}' पार्टी हटाइयो!`);
                            }}
                            className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded text-[11px] font-bold transition cursor-pointer flex items-center gap-1"
                            title="हटाउनुहोस्"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>हटाउने</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: ROLE MANAGEMENT & OWNER SECURITY (मालिकबाट मात्र रोल मिलाउने)      */}
      {/* ========================================================================= */}
      {activeTab === 'STAFF_LOGINS' && !isStaffLogin() && <StaffLoginsPanel />}

      {activeTab === 'ROLES' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-700" />
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {isNe ? 'मालिक सुरक्षा तथा भूमिका नियन्त्रण (Owner Role Security)' : 'Owner Security & Roles'}
                </h2>
                <p className="text-xs text-slate-500">
                  {isNe
                    ? 'कर्मचारी वा अपरेटरले आफै रोल परिवर्तन गर्न नसक्ने गरी मालिक पिन (Owner PIN) द्वारा सुरक्षित'
                    : 'Restricted role management guarded by Owner Master PIN'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200 text-amber-900 rounded-lg text-xs font-semibold">
              <Key className="w-3.5 h-3.5" />
              <span>{isOwnerUnlocked ? (isNe ? 'प्रमाणित (Unlocked)' : 'Unlocked') : (isNe ? 'लक गरिएको (Locked)' : 'Locked')}</span>
            </div>
          </div>

          {!isOwnerUnlocked ? (
            <div className="p-6 bg-slate-50 rounded-xl border border-slate-200 max-w-md mx-auto text-center space-y-4">
              <div className="w-12 h-12 bg-amber-100 text-amber-800 rounded-full flex items-center justify-center mx-auto">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  {isNe ? 'मालिकको सुरक्षा पिन आवश्यक' : 'Owner Master PIN Required'}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {isNe
                    ? 'भूमिका परिवर्तन तथा गोप्य वित्तीय अधिकार व्यवस्थापन गर्न मालिकको पिन प्रविष्ट गर्नुहोस्। (डिफल्ट पिन: १२३४)'
                    : 'Enter Owner PIN to adjust operator roles. (Default PIN: 1234)'}
                </p>
              </div>

              <form onSubmit={handleUnlockOwner} className="space-y-3">
                <input
                  type="password"
                  required
                  placeholder="Master PIN (उदा: 1234)"
                  value={enteredPin}
                  onChange={(e) => setEnteredPin(e.target.value)}
                  className="w-full text-center px-4 py-2.5 border border-slate-300 rounded-xl font-mono text-base font-bold tracking-widest focus:ring-2 focus:ring-emerald-500"
                />
                {pinError && <p className="text-xs font-semibold text-rose-600">{pinError}</p>}
                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-xl text-xs transition cursor-pointer shadow-xs"
                >
                  {isNe ? 'अनलक गर्नुहोस् (Unlock Owner Settings)' : 'Unlock Owner Settings'}
                </button>
              </form>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-emerald-900 font-semibold">
                  <Unlock className="w-4 h-4 text-emerald-700" />
                  <span>{isNe ? 'मालिक प्रमाणीकरण सम्पन्न भएको छ। तपाईंले रोलहरू परिवर्तन गर्न सक्नुहुन्छ।' : 'Owner verified! You can modify roles.'}</span>
                </div>
                <button
                  onClick={() => setIsOwnerUnlocked(false)}
                  className="text-emerald-800 font-bold hover:underline cursor-pointer"
                >
                  {isNe ? 'पुन: लक गर्नुहोस्' : 'Lock Again'}
                </button>
              </div>

              {/* User Accounts & Roles Table (युजर र भूमिका थपघट तथा व्यवस्थापन) */}
              <div className="space-y-3 pt-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-emerald-700" />
                      <span>{isNe ? 'प्रणालीका सबै युजर र पद अधिकारहरू (User & Role Accounts)' : 'All User Accounts & Roles'}</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      {isNe ? 'मालिकबाट नयाँ युजर थप्न, पद परिवर्तन गर्न वा हटाउन मिल्छ' : 'Add, edit assigned roles, approve or delete company accounts'}
                    </p>
                  </div>

                  <button
                    onClick={() => handleOpenUserModal()}
                    className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs self-start sm:self-auto"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{isNe ? '+ नयाँ युजर र भूमिका थप्नुहोस्' : '+ Add New User & Role'}</span>
                  </button>
                </div>

                {/* Filter / Search input */}
                <div className="relative">
                  <input
                    type="text"
                    placeholder={isNe ? 'नाम, मोबाइल वा पदबाट खोज्नुहोस्...' : 'Search by name, mobile, role...'}
                    value={userSearchTerm}
                    onChange={(e) => setUserSearchTerm(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Users Table */}
                <div className="overflow-x-auto border border-slate-200 rounded-xl">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900 text-slate-100 font-bold uppercase tracking-wider text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">युजर / सञ्चालक</th>
                        <th className="py-2.5 px-3">मोबाइल नं.</th>
                        <th className="py-2.5 px-3">तोकिएको पद (Role)</th>
                        <th className="py-2.5 px-3">PIN कोड</th>
                        <th className="py-2.5 px-3">स्थिति</th>
                        <th className="py-2.5 px-3 text-center">कार्यहरू (Actions)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {companyAccounts
                        .filter(
                          (a) =>
                            !userSearchTerm ||
                            a.ownerName.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
                            a.mobileNumber.includes(userSearchTerm) ||
                            (a.assignedRole && a.assignedRole.toLowerCase().includes(userSearchTerm.toLowerCase()))
                        )
                        .map((acc) => {
                          const assignedRole = acc.assignedRole || 'OWNER';
                          return (
                            <tr key={acc.id} className="hover:bg-slate-50/70">
                              <td className="py-2.5 px-3">
                                <div className="font-bold text-slate-900">{acc.ownerName}</div>
                                <div className="text-[10px] text-slate-500">{acc.companyName}</div>
                              </td>
                              <td className="py-2.5 px-3 font-mono font-bold text-emerald-800">
                                {acc.mobileNumber}
                              </td>
                              <td className="py-2.5 px-3">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                  assignedRole === 'OWNER'
                                    ? 'bg-amber-100 text-amber-900 border-amber-300'
                                    : assignedRole === 'ADMINISTRATION'
                                    ? 'bg-purple-100 text-purple-900 border-purple-300'
                                    : assignedRole === 'ACCOUNTANT'
                                    ? 'bg-blue-100 text-blue-900 border-blue-300'
                                    : assignedRole === 'COUNTER_SALES'
                                    ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                    : assignedRole === 'SALESMAN'
                                    ? 'bg-teal-100 text-teal-900 border-teal-300'
                                    : assignedRole === 'SUPERVISOR'
                                    ? 'bg-indigo-100 text-indigo-900 border-indigo-300'
                                    : 'bg-slate-100 text-slate-800 border-slate-300'
                                }`}>
                                  {assignedRole === 'OWNER' && '👑 OWNER (मालिक)'}
                                  {assignedRole === 'ADMINISTRATION' && '🛡️ ADMIN (प्रशासक)'}
                                  {assignedRole === 'ACCOUNTANT' && '📊 ACCOUNTANT (लेखापाल)'}
                                  {assignedRole === 'COUNTER_SALES' && '🛒 COUNTER SALES (काउन्टर)'}
                                  {assignedRole === 'SALESMAN' && '🏷️ SALESMAN (सेल्सम्यान)'}
                                  {assignedRole === 'SUPERVISOR' && '👷 SUPERVISOR (सुपरभाइजर)'}
                                  {assignedRole === 'STAFF' && '👤 STAFF (कर्मचारी)'}
                                </span>
                              </td>
                              <td className="py-2.5 px-3 font-mono font-bold text-slate-700">
                                {acc.pin || '1234'}
                              </td>
                              <td className="py-2.5 px-3">
                                {acc.status === 'APPROVED' ? (
                                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded font-bold text-[10px] border border-emerald-300">
                                    ✓ स्वीकृत (APPROVED)
                                  </span>
                                ) : acc.status === 'PENDING_APPROVAL' ? (
                                  <span className="px-2 py-0.5 bg-amber-100 text-amber-900 rounded font-bold text-[10px] border border-amber-300 animate-pulse">
                                    ⏳ पर्खाइमा (PENDING)
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 bg-rose-100 text-rose-900 rounded font-bold text-[10px] border border-rose-300">
                                    ❌ अस्वीकृत (REJECTED)
                                  </span>
                                )}
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                <div className="flex items-center justify-center gap-1.5">
                                  <button
                                    onClick={() => handleOpenUserModal(acc)}
                                    className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded text-[11px] font-semibold transition cursor-pointer flex items-center gap-1"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                    <span>{isNe ? 'सच्याउने' : 'Edit'}</span>
                                  </button>

                                  {acc.status === 'PENDING_APPROVAL' && (
                                    <button
                                      onClick={() => approveAccount(acc.id, acc.assignedRole || 'STAFF')}
                                      className="px-2 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-[11px] font-bold transition cursor-pointer"
                                    >
                                      {isNe ? 'स्वीकृत' : 'Approve'}
                                    </button>
                                  )}

                                  {acc.mobileNumber !== '9855012345' && (
                                    <button
                                      onClick={() => {
                                        const res = deleteCompanyAccount(acc.id);
                                        showToast(res.message);
                                      }}
                                      className="p-1 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded transition cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Role Definition Cards Overview */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  {isNe ? 'प्रणाली भूमिका विवरण (Role Definitions):' : 'Role Definitions Overview:'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(['OWNER', 'ADMINISTRATION', 'ACCOUNTANT', 'COUNTER_SALES', 'SALESMAN', 'SUPERVISOR', 'STAFF'] as UserRole[]).map((r) => (
                    <div
                      key={r}
                      onClick={() => {
                        setCurrentRole(r);
                        showToast(isNe ? `✓ भूमिका दृश्य परिवर्तन भयो: ${r}` : `Role view switched to ${r}`);
                      }}
                      className={`p-3 rounded-xl border cursor-pointer transition ${
                        currentRole === r
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold shadow-xs'
                          : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs">
                          {r === 'OWNER' && (isNe ? '👑 मालिक (Owner)' : 'Owner')}
                          {r === 'ADMINISTRATION' && (isNe ? '🛡️ प्रशासक (Admin)' : 'Admin')}
                          {r === 'ACCOUNTANT' && (isNe ? '📊 लेखापाल (Accountant)' : 'Accountant')}
                          {r === 'COUNTER_SALES' && (isNe ? '🛒 काउन्टर बिलिङ (Counter Sales)' : 'Counter Sales')}
                          {r === 'SALESMAN' && (isNe ? '🏷️ सेल्सम्यान (Salesman)' : 'Salesman')}
                          {r === 'SUPERVISOR' && (isNe ? '👷 सुपरभाइजर (Supervisor)' : 'Supervisor')}
                          {r === 'STAFF' && (isNe ? '👤 कर्मचारी (Staff)' : 'Staff')}
                        </span>
                        {currentRole === r && <Check className="w-4 h-4 text-emerald-600" />}
                      </div>
                      <p className="text-[10px] text-slate-500 mt-1 font-normal leading-relaxed">
                        {r === 'OWNER' && (isNe ? 'सम्पूर्ण नाफा-नोक्सान, भ्याट खाता, सेटिङ र युजर/रोल थपघट अधिकार' : 'Full system owner access')}
                        {r === 'ADMINISTRATION' && (isNe ? 'लेखा, भ्याट, स्टक, हाजिरी र रिपोर्ट सञ्चालन अधिकार' : 'Full administration access')}
                        {r === 'ACCOUNTANT' && (isNe ? 'आम्दानी, खर्च, ज्याला र हिसाब किताब अधिकार' : 'Income, expenses, wages & accounts')}
                        {r === 'COUNTER_SALES' && (isNe ? 'पर्चेज, सेल्स र बिलिङ अधिकार' : 'Purchase, sales & billing')}
                        {r === 'SALESMAN' && (isNe ? 'अर्डर टिपोट र द्रुत बिलिङ अधिकार' : 'Order entries & quick billing')}
                        {r === 'SUPERVISOR' && (isNe ? 'हाजिरी मिलाउने, सामान/स्टक विवरण, गल्ती नाेट' : 'Attendance & stock inspection')}
                        {r === 'STAFF' && (isNe ? 'हाजिर मात्र गर्ने अधिकार' : 'Staff attendance only')}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Change Owner PIN Form */}
              <div className="pt-4 border-t border-slate-100 space-y-3">
                <h3 className="text-xs font-bold text-slate-800">
                  {isNe ? 'मालिकको नयाँ गोप्य पिन (Change Master Owner PIN):' : 'Update Owner Master PIN:'}
                </h3>
                <form onSubmit={handleUpdateOwnerPin} className="flex gap-2 max-w-md">
                  <input
                    type="password"
                    placeholder="नयाँ पिन (e.g. 9841)"
                    value={newPinInput}
                    onChange={(e) => setNewPinInput(e.target.value)}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-xs"
                  >
                    {isNe ? 'पिन फेर्नुहोस्' : 'Save PIN'}
                  </button>
                </form>
                {pinChangeSuccess && (
                  <p className="text-xs font-semibold text-emerald-700">
                    ✓ {isNe ? 'मालिक पिन सफलतापूर्वक परिवर्तन भयो !' : 'Owner PIN changed!'}
                  </p>
                )}
              </div>

              {/* Attendance Location Policy Toggle */}
              <div className="pt-4 border-t border-slate-100 space-y-3">
                <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-700" />
                  <span>{isNe ? 'कर्मचारी हाजिरी लोकेसन नीति (GPS Location Policy):' : 'Attendance Location Policy:'}</span>
                </h3>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <label className="flex items-start gap-3 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={company.enforceGpsLocation !== false}
                      onChange={(e) => {
                        updateCompanyProfile({ ...company, enforceGpsLocation: e.target.checked });
                        alert(
                          isNe
                            ? e.target.checked
                              ? 'GPS लोकेसन परिधि (Geofence) कडा रूपमा लागु भयो।'
                              : 'विना लोकेसन (फ्री लोकेसन) सबै कर्मचारीको हाजिरी खुला भयो !'
                            : 'Attendance location policy updated!'
                        );
                      }}
                      className="w-4 h-4 mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-900 block">
                        {isNe
                          ? 'GPS लोकेसन परिधि बाहिर हाजिरी रोक्ने (Block Clock-In Outside Geofence)'
                          : 'Block Clock-In Outside Geofence'}
                      </span>
                      <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                        {isNe
                          ? 'यो बन्द गरेमा सबै कर्मचारीले लोकेसन बिना (विना GPS) आफ्नो मोबाइलबाट हाजिर गर्न पाउँछन्। यदि यो चालू छ भने पनि, मालिकको Master PIN बाट विना लोकेसन हाजिर गर्न पाइन्छ।'
                          : 'When disabled, staff can clock-in without GPS. When enabled, staff can still clock-in without GPS if approved via Owner PIN.'}
                      </p>
                    </div>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: FISCAL YEAR CLOSING (आर्थिक वर्ष बन्द तथा नयाँ वर्ष सुरु)          */}
      {/* ========================================================================= */}
      {activeTab === 'FISCAL_YEAR' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Calendar className="w-5 h-5 text-emerald-700" />
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {isNe ? 'आर्थिक वर्ष बन्द तथा मौज्दात सार्ने कार्य (Year-End Rollover)' : 'Fiscal Year Closing'}
              </h2>
              <p className="text-xs text-slate-500">
                {isNe
                  ? 'चालु आर्थिक वर्ष बन्द गरी अन्तिम स्टक तथा बाँकी रकम नयाँ वर्षमा स्वतः सार्ने'
                  : 'Close current fiscal year, carry forward balances & reset bill series'}
              </p>
            </div>
          </div>

          {/* Fiscal Year Dropdown Selection & Quick Add Section */}
          <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-sm text-indigo-950">
                  {isNe ? 'आर्थिक वर्ष छान्नुहोस् वा नयाँ थप्नुहोस् (Fiscal Year Dropdown)' : 'Select or Add Fiscal Year'}
                </h3>
                <p className="text-xs text-indigo-700">
                  {isNe
                    ? 'यस ड्रपडाउनबाट चालु आर्थिक वर्ष परिवर्तन गर्न वा नयाँ आर्थिक वर्ष थप्न सकिन्छ'
                    : 'Switch active fiscal year or register a new fiscal period'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isNe ? 'सक्रिय आर्थिक वर्ष (Select Active Year):' : 'Select Active Fiscal Year:'}
                </label>
                <select
                  value={company.fiscalYear || '081/82'}
                  onChange={(e) => {
                    {
                      const r = selectFiscalYear(e.target.value);
                      if (r.success) showToast(`✓ आर्थिक वर्ष ${e.target.value} सक्रिय गरियो`);
                      else if (!r.needsCode) showToast(r.message);
                    }
                  }}
                  className="w-full px-3 py-2 bg-white border border-indigo-300 rounded-xl font-mono font-black text-sm text-indigo-950 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer shadow-2xs"
                >
                  {fiscalYearsList.map((fy) => (
                    <option key={fy} value={fy}>
                      📅 आ.व. {isFiscalYearClosed(fy) ? '🔒 ' : ''}{fy} {fy === company.fiscalYear ? '(हाल सक्रिय)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isNe ? '➕ नयाँ आर्थिक वर्ष थप्नुहोस्:' : '➕ Add New Fiscal Year:'}
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={newSettingFyInput}
                    onChange={(e) => setNewSettingFyInput(e.target.value)}
                    placeholder="उदा: 082/83"
                    className="flex-1 px-3 py-2 bg-white border border-indigo-300 rounded-xl font-mono font-bold text-xs text-indigo-950 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-2xs"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!newSettingFyInput.trim()) {
                        showToast('कृपया आर्थिक वर्ष लेख्नुहोस् (जस्तै: 082/83)');
                        return;
                      }
                      const res = addNewFiscalYear(newSettingFyInput.trim());
                      showToast(res.message);
                      setNewSettingFyInput('');
                    }}
                    className="px-3.5 py-2 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer shrink-0"
                  >
                    + थप्ने
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <span className="text-xs text-slate-500 font-medium block">
                {isNe ? 'हाल सक्रिय आर्थिक वर्ष:' : 'Current Active Fiscal Year:'}
              </span>
              <div className="text-2xl font-black font-mono text-slate-900">
                {company.fiscalYear || '081/82'}
              </div>
              <p className="text-[11px] text-slate-500">
                {isNe ? 'नेपालको विक्रम संवत् अनुसारको वर्तमान लेखा वर्ष' : 'Nepal standard B.S. fiscal period'}
              </p>
            </div>

            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 space-y-2">
              <span className="text-xs text-emerald-800 font-medium block">
                {isNe ? 'नयाँ सुरु हुने आर्थिक वर्ष (Rollover Target):' : 'Next Fiscal Year to Start:'}
              </span>
              <input
                type="text"
                value={nextFiscalYear}
                onChange={(e) => setNextFiscalYear(e.target.value)}
                placeholder="082/83"
                className="w-full px-3 py-1.5 border border-emerald-300 rounded-lg font-mono font-bold text-lg text-emerald-950 bg-white"
              />
              <p className="text-[11px] text-emerald-700">
                {isNe ? 'जस्तै: ०८२/८३ वा ०८३/८४' : 'e.g. 082/83'}
              </p>
            </div>
          </div>

          <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 space-y-2 text-xs text-amber-950">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertTriangle className="w-4 h-4 text-amber-700" />
              <span>{isNe ? 'आर्थिक वर्ष बन्द गर्दा के-के हुन्छ?' : 'What happens during year closing?'}</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-700 text-[11px]">
              <li>
                <strong>सामानको स्टक (Stock):</strong> हालको अन्तिम मौज्दात (Closing Stock) नयाँ वर्षको सुरुवाती मौज्दात (Opening Stock) बन्नेछ।
              </li>
              <li>
                <strong>ग्राहक तथा पार्टी खाता (Dues):</strong> हाल उठाउन बाँकी रकम नयाँ वर्षको सुरुवाती बाँकी रकम (Opening Balance) मा सर्नेछ।
              </li>
              <li>
                <strong>बैंक तथा काउन्टर नगद (Cash & Bank):</strong> हालको मौज्दात नयाँ वर्षको सुरुवाती बैंक तथा नगद मौज्दात बन्नेछ।
              </li>
              <li>
                <strong>नयाँ बीजक सिरिज (Invoice Series):</strong> नयाँ वर्षको पहिलो बिल नं. <strong>TI-{nextFiscalYear}-0001</strong> बाट सुरु हुनेछ।
              </li>
            </ul>
          </div>

<div className="p-4 bg-rose-50 border border-rose-200 rounded-xl space-y-2">
            <h3 className="text-sm font-bold text-rose-900">🔑 बन्द आर्थिक वर्ष खोल्ने Code (Fiscal Year Reopen Code)</h3>
            <p className="text-[11px] text-rose-800">
              {(company.closedFiscalYears || []).length > 0
                ? `बन्द वर्ष: ${(company.closedFiscalYears || []).join(', ')}`
                : 'अहिलेसम्म कुनै वर्ष बन्द भएको छैन।'}
            </p>
            <div className="flex flex-wrap gap-2">
              {company.fiscalReopenCode && (
                <input type="password" value={reopenCurrentCode} onChange={(e) => setReopenCurrentCode(e.target.value)}
                  placeholder="हालको Code" className="px-3 py-2 border border-rose-300 rounded-lg text-xs font-mono" />
              )}
              <input type="password" value={reopenNewCode} onChange={(e) => setReopenNewCode(e.target.value)}
                placeholder={company.fiscalReopenCode ? 'नयाँ Code' : 'Code सेट गर्नुहोस् (min 4)'} className="px-3 py-2 border border-rose-300 rounded-lg text-xs font-mono" />
              <button type="button"
                onClick={() => {
                  const r = setFiscalReopenCode(reopenNewCode, reopenCurrentCode);
                  showToast(r.message);
                  if (r.success) { setReopenNewCode(''); setReopenCurrentCode(''); }
                }}
                className="px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-lg text-xs font-bold">
                {company.fiscalReopenCode ? 'Code बदल्नुहोस्' : 'Code सेट गर्नुहोस्'}
              </button>
            </div>
          </div>

                    {fiscalCloseSuccess && (
            <div className="p-3 bg-emerald-100 text-emerald-900 rounded-lg text-xs font-bold text-center">
              ✓ {isNe ? 'आर्थिक वर्ष सफलतापुर्वक बन्द भई नयाँ वर्ष सुरु गरियो !' : 'Fiscal year closed and new year rolled over!'}
            </div>
          )}

          <div className="flex justify-end pt-3 border-t border-slate-100">
            <button
              onClick={() => setIsFiscalCloseConfirmOpen(true)}
              className="px-5 py-2.5 bg-rose-700 hover:bg-rose-800 text-white font-semibold rounded-xl text-xs shadow-xs transition cursor-pointer flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              <span>{isNe ? `आर्थिक वर्ष ${company.fiscalYear} बन्द गर्नुहोस्` : `Close FY ${company.fiscalYear}`}</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: INVOICE & BILLING CUSTOMIZATION (Invoice मिलाउने)                  */}
      {/* ========================================================================= */}
      {activeTab === 'INVOICE' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Receipt className="w-5 h-5 text-emerald-700" />
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {isNe
                    ? 'खरिद, बिक्री र बिलिङ मास्टर सेटिङ (Purchase, Sales & Invoice Master)'
                    : 'Purchase, Sales & Invoice Customization'}
                </h2>
                <p className="text-xs text-slate-500">
                  {isNe
                    ? 'खरिद/बिक्रीका सबै ६ वटा अप्सनहरू, बिल प्रिफिक्स, Non-VAT स्टक कट्टा, र प्रिन्ट ढाँचा यहीँबाट मिलाउनुहोस्'
                    : 'Control all 6 Purchase/Sales options, bill prefixes, stock deduction, QR and print formats'}
                </p>
              </div>
            </div>
          </div>

          {/* 6-Option Purchase & Sale Quick Master Bar */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
            <span className="text-xs font-extrabold text-slate-800 block">
              {isNe
                ? '⚡ खरिद तथा बिक्रीका सबै ६ वटा अप्सनहरू (Purchase & Sales All Options):'
                : '⚡ All 6 Purchase & Sales Options:'}
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
              <button
                type="button"
                onClick={() => {
                  setBillingSubTab('SALES');
                  setGlobalActiveTab('billing');
                }}
                className="px-3 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs cursor-pointer text-left"
              >
                १. बिक्री बिल (Sales) →
              </button>
              <button
                type="button"
                onClick={() => {
                  setBillingSubTab('PURCHASE');
                  setGlobalActiveTab('billing');
                }}
                className="px-3 py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl shadow-xs cursor-pointer text-left"
              >
                २. खरिद बिल (Purchase) →
              </button>
              <button
                type="button"
                onClick={() => {
                  setBillingSubTab('PAYMENT_IN');
                  setVoucherSubTab('COLLECTION');
                  setGlobalActiveTab('billing');
                }}
                className="px-3 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl shadow-xs cursor-pointer text-left"
              >
                ३. भुक्तानी प्राप्त (In) →
              </button>
              <button
                type="button"
                onClick={() => {
                  setBillingSubTab('PAYMENT_OUT');
                  setVoucherSubTab('PAYMENT');
                  setGlobalActiveTab('billing');
                }}
                className="px-3 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shadow-xs cursor-pointer text-left"
              >
                ४. भुक्तानी (Out) →
              </button>
              <button
                type="button"
                onClick={() => {
                  setBillingSubTab('SALES_RETURN');
                  setGlobalActiveTab('billing');
                }}
                className="px-3 py-2.5 bg-rose-700 hover:bg-rose-800 text-white font-bold rounded-xl shadow-xs cursor-pointer text-left"
              >
                ५. बिक्री फिर्ता (Return) →
              </button>
              <button
                type="button"
                onClick={() => {
                  setBillingSubTab('PURCHASE_RETURN');
                  setGlobalActiveTab('billing');
                }}
                className="px-3 py-2.5 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl shadow-xs cursor-pointer text-left"
              >
                ६. खरिद फिर्ता (Return) →
              </button>
            </div>
          </div>

          <form onSubmit={handleSaveCompany} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'भ्याट कर बीजक प्रिफिक्स (VAT Bill Prefix)' : 'VAT Prefix'}
                </label>
                <input
                  type="text"
                  value={vatPrefix}
                  onChange={(e) => setVatPrefix(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-sm"
                />
                <span className="text-[10px] text-slate-400">जस्तै: TI-{company.fiscalYear}-0001</span>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'Non-VAT बिक्री बिल प्रिफिक्स (Non-VAT Prefix)' : 'Non-VAT Prefix'}
                </label>
                <input
                  type="text"
                  value={nonVatPrefix}
                  onChange={(e) => setNonVatPrefix(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-sm"
                />
                <span className="text-[10px] text-slate-400">जस्तै: NV-{company.fiscalYear}-0001</span>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                {isNe ? 'बिलको मुनि देखिने मुख्य सन्देश (Invoice Footer Note)' : 'Invoice Footer Note'}
              </label>
              <input
                type="text"
                value={invoiceFooter}
                onChange={(e) => setInvoiceFooter(e.target.value)}
                placeholder="e.g. बिक्री भएको सामान ७ दिनभित्र साटफेर गरिनेछ। धन्यवाद !"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                {isNe ? 'सर्त तथा नियमहरू (Invoice Terms & Conditions)' : 'Invoice Terms & Conditions'}
              </label>
              <textarea
                rows={3}
                value={invoiceTerms}
                onChange={(e) => setInvoiceTerms(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'रकम बुझाउने सामान्य म्याद (दिन)' : 'Default Payment Due Days'}
                </label>
                <input
                  type="number"
                  min={1}
                  max={365}
                  value={defaultDueDays}
                  onChange={(e) => setDefaultDueDays(parseInt(e.target.value) || 30)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'प्रिन्ट ढाँचा (Print Paper Format)' : 'Default Print Format'}
                </label>
                <select
                  value={defaultPrintFormat}
                  onChange={(e) => setDefaultPrintFormat(e.target.value as 'A4' | 'THERMAL_80MM' | 'THERMAL_58MM')}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                >
                  <option value="A4">A4 Full Page (प्रमाणित कर बीजक)</option>
                  <option value="THERMAL_80MM">80mm Thermal Receipt (काउन्टर ३-इन्च रोल)</option>
                  <option value="THERMAL_58MM">58mm Mini Thermal (ब्लुटुथ/मिनी २-इन्च रोल)</option>
                </select>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-6 pt-2">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={showQrOnInvoice}
                  onChange={(e) => setShowQrOnInvoice(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-xs font-semibold text-slate-800">
                  {isNe ? 'बिलमा बैंक QR कोड देखाउने' : 'Show Bank QR on Invoices'}
                </span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={deductStockOnNonVat}
                  onChange={(e) => setDeductStockOnNonVat(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-xs font-semibold text-slate-800">
                  {isNe ? 'Non-VAT बिक्री बिल काँट्दा पनि गोदाम स्टक घटाउने' : 'Deduct Inventory Stock on Non-VAT Sales'}
                </span>
              </label>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-xl text-xs shadow-xs transition cursor-pointer"
              >
                {isNe ? 'खरिद/बिक्री र बिलिङ सेटिङ सुरक्षित गर्नुहोस्' : 'Save Purchase/Sales & Invoice Settings'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 6: BANK ACCOUNTS & QR UPLOAD (बैंक खाता, मेटाउने र QR अपलोड मिलाउने)   */}
      {/* ========================================================================= */}
      {activeTab === 'BANKS' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Landmark className="w-5 h-5 text-emerald-700" />
                <span>
                  {isNe
                    ? 'बैंक खाता तथा QR कोड व्यवस्थापन (Bank Accounts & QR Upload)'
                    : 'Bank Accounts & QR Code Setup'}
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                {isNe
                  ? 'बैंक खाता थप्ने, सच्याउने, मेटाउने र बिक्री गर्दा सिधै देखिने बैंक QR फोटो अपलोड गर्ने ठाउँ'
                  : 'Add, edit, delete bank accounts and upload custom Bank QR codes for Sales POS'}
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                setEditingBank(null);
                setBankName('');
                setBankAccNo('');
                setBankHolder(company.name);
                setBankBranch('');
                setBankOpeningBal(0);
                setBankQrCodeUrl('');
                setIsAddBankOpen(true);
              }}
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5 shadow-xs self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>{isNe ? '+ नयाँ बैंक र QR थप्नुहोस्' : '+ Add Bank & QR'}</span>
            </button>
          </div>

          {bankAccounts.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300 space-y-2">
              <p className="text-xs font-bold text-slate-700">
                हाल कुनै बैंक खाता दर्ता गरिएको छैन।
              </p>
              <button
                type="button"
                onClick={() => {
                  setEditingBank(null);
                  setBankName('');
                  setBankAccNo('');
                  setBankHolder(company.name);
                  setBankBranch('');
                  setBankOpeningBal(0);
                  setBankQrCodeUrl('');
                  setIsAddBankOpen(true);
                }}
                className="px-4 py-2 bg-emerald-700 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                + पहिलो बैंक खाता थप्नुहोस्
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {bankAccounts.map((b) => (
                <div
                  key={b.id}
                  className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex justify-between items-start gap-2">
                      <div>
                        <h3 className="font-bold text-slate-900 text-sm">{b.bankName}</h3>
                        <span className="text-[11px] text-slate-500 block">
                          {b.branch || 'मुख्य शाखा'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingBank(b);
                            setBankName(b.bankName);
                            setBankAccNo(b.accountNumber);
                            setBankHolder(b.accountHolder);
                            setBankBranch(b.branch);
                            setBankOpeningBal(b.openingBalance);
                            setBankQrCodeUrl(b.qrCodeUrl || '');
                            setIsAddBankOpen(true);
                          }}
                          className="px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 rounded-lg text-[11px] font-bold cursor-pointer flex items-center gap-1"
                        >
                          <Edit2 className="w-3 h-3" />
                          <span>{isNe ? 'सच्याउने' : 'Edit'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            deleteBankAccount(b.id);
                            showToast(
                              isNe
                                ? `✓ बैंक खाता '${b.bankName}' सफलतापूर्वक मेटाइयो!`
                                : `✓ Deleted bank account ${b.bankName}!`
                            );
                          }}
                          className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[11px] font-bold cursor-pointer flex items-center gap-1 shadow-2xs"
                          title="बैंक खाता मेटाउनुहोस्"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{isNe ? 'मेटाउने (Delete)' : 'Delete'}</span>
                        </button>
                      </div>
                    </div>

                    <div className="p-2.5 bg-white rounded-lg border border-slate-200 flex items-center justify-between gap-3">
                      <div className="text-xs font-mono space-y-0.5">
                        <div className="text-slate-600">
                          खाता नं: <strong className="text-slate-900">{b.accountNumber}</strong>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          खातावाला: {b.accountHolder}
                        </div>
                      </div>
                      {b.qrCodeUrl ? (
                        <div className="flex flex-col items-center">
                          <img
                            src={b.qrCodeUrl}
                            alt="Bank QR"
                            className="w-16 h-16 object-contain rounded border border-emerald-400 bg-white p-0.5 shadow-2xs"
                          />
                          <span className="text-[9px] font-bold text-emerald-700 mt-0.5">
                            ✓ QR अपलोड छ
                          </span>
                        </div>
                      ) : (
                        <div className="px-2 py-1 bg-amber-50 border border-amber-200 rounded text-[10px] font-bold text-amber-900">
                          QR फोटो छैन
                        </div>
                      )}
                    </div>

                    {/* Direct Inline QR Upload Bar on every Bank Card */}
                    <div className="p-2.5 bg-emerald-50/70 border border-emerald-200 rounded-xl flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-1.5 text-emerald-950 font-bold text-[11px]">
                        <QrCode className="w-4 h-4 text-emerald-700" />
                        <span>बिक्रीमा सिधै देखिने बैंक QR:</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <label className="px-2.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg text-[11px] cursor-pointer flex items-center gap-1 shadow-2xs">
                          <Upload className="w-3 h-3" />
                          <span>{b.qrCodeUrl ? 'QR फोटो फेर्नुहोस्' : '+ QR फोटो अपलोड'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) =>
                              handleDirectBankCardQrUpload(b, e.target.files?.[0])
                            }
                            className="hidden"
                          />
                        </label>
                        {b.qrCodeUrl && (
                          <button
                            type="button"
                            onClick={() => {
                              saveBankAccount({ ...b, qrCodeUrl: undefined });
                              showToast(`'${b.bankName}' को QR फोटो हटाइयो।`);
                            }}
                            className="px-2 py-1.5 bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold rounded-lg text-[10px] cursor-pointer"
                          >
                            QR हटाउने
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                    <span className="text-xs text-slate-500">
                      {isNe ? 'हालको मौज्दात:' : 'Live Balance:'}
                    </span>
                    <span className="font-mono font-bold text-base text-blue-900">
                      {formatCurrency(b.currentBalance, isNe)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 7: MASTER UNITS (PRIMARY/SECONDARY), PRODUCT CATEGORIES, STAFF ROLES, */}
      {/*        DAILY EXPENSE CATEGORIES & OTHER INCOME / LOAN CATEGORIES          */}
      {/* ========================================================================= */}
      {activeTab === 'CATEGORIES' && (
        <div className="space-y-6">
          {/* Top Overview Banner */}
          <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-5 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base sm:text-lg font-black text-amber-300 flex items-center gap-2">
                <Boxes className="w-5 h-5 text-amber-300" />
                <span>
                  {isNe
                    ? 'मास्टर सेटिङ: मुख्य/द्वितीय एकाइ, सामान क्याटगोरी, कर्मचारी पद र खर्च/आम्दानी शीर्षक'
                    : 'Master Hub: Primary/Secondary Units, Product Categories, Staff Roles & Account Heads'}
                </span>
              </h2>
              <p className="text-xs text-emerald-100 mt-0.5">
                {isNe
                  ? 'यहाँ मिलाइएका मुख्य एकाइ (100mtr, 1 Carton, 12pcs), द्वितीय एकाइ (Pcs, Mtr, Ltr), क्याटगोरी र पदहरू इन्भेन्टरी, खरिद, बिक्री र हाजिरीमा स्वतः लागू हुन्छन्।'
                  : 'Units, conversion ratios, product categories, staff designations, and expense/income heads configured here sync across Inventory, POS, Purchase, and Attendance.'}
              </p>
            </div>
          </div>

          {/* 1. INVENTORY PRIMARY UNITS & SECONDARY UNITS + CONVERSION PRESETS */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-black text-slate-900">
                  {isNe
                    ? '१. इन्भेन्टरी मुख्य एकाइ (Primary Unit) र द्वितीय एकाइ (Secondary Unit) मिलाउने'
                    : '1. Inventory Primary Units, Secondary Units & Conversion Ratios'}
                </h3>
                <p className="text-xs text-slate-500">
                  {isNe
                    ? 'मुख्य एकाइमा 100mtr, 1 Carton, 12pcs, Roll, Bag र द्वितीय एकाइमा Pcs, Mtr, Ltr, Kg थप्नुहोस् वा सच्याउनुहोस्'
                    : 'Configure primary bulk units (100mtr, 1 Carton, 12pcs) and secondary retail units (Pcs, Mtr, Ltr)'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  updateCompanyProfile({
                    ...company,
                    inventoryPrimaryUnits: DEFAULT_PRIMARY_UNITS,
                    inventorySecondaryUnits: DEFAULT_SECONDARY_UNITS,
                    unitConversionPresets: DEFAULT_UNIT_CONVERSIONS
                  });
                  showToast('✓ मुख्य र द्वितीय एकाइहरू डिफल्ट अवस्थामा रिसेट गरियो!');
                }}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold cursor-pointer self-start"
              >
                ↺ डिफल्ट एकाइ रिसेट
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {/* Primary Units Box */}
              <div className="p-4 bg-emerald-50/50 rounded-xl border border-emerald-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-emerald-950">
                    📦 मुख्य एकाइ सूची (Primary Units — जस्तै: 100mtr, 1 Carton, 12pcs, Roll)
                  </span>
                  <span className="text-[11px] font-mono font-bold bg-emerald-200/80 text-emerald-950 px-2 py-0.5 rounded">
                    {activePrimaryUnits.length} एकाइ
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto pr-1">
                  {activePrimaryUnits.map((u) => (
                    <div
                      key={u.id}
                      className="p-2 bg-white rounded-lg border border-emerald-200 flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0 flex-1">
                        <input
                          type="text"
                          value={u.labelNe}
                          onChange={(e) => {
                            const updated = activePrimaryUnits.map((item) =>
                              item.id === u.id ? { ...item, labelNe: e.target.value } : item
                            );
                            updateCompanyProfile({ ...company, inventoryPrimaryUnits: updated });
                          }}
                          className="w-full font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-emerald-500 focus:outline-none text-xs"
                        />
                        <span className="text-[10px] font-mono text-emerald-700 font-bold">कोड: {u.code}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const updated = activePrimaryUnits.filter((item) => item.id !== u.id);
                          updateCompanyProfile({ ...company, inventoryPrimaryUnits: updated });
                          showToast(`मुख्य एकाइ '${u.code}' हटाइयो।`);
                        }}
                        className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                        title="हटाउनुहोस्"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Add Primary Unit */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!newPrimaryCode.trim()) return;
                    const code = newPrimaryCode.trim();
                    const labelNe = newPrimaryLabelNe.trim() || code;
                    const updated = [
                      ...activePrimaryUnits,
                      { id: `PRI_${Date.now()}`, code, labelNe, labelEn: labelNe }
                    ];
                    updateCompanyProfile({ ...company, inventoryPrimaryUnits: updated });
                    setNewPrimaryCode('');
                    setNewPrimaryLabelNe('');
                    showToast(`✓ मुख्य एकाइ '${code}' थपियो!`);
                  }}
                  className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-2 border-t border-emerald-200/70"
                >
                  <input
                    type="text"
                    required
                    value={newPrimaryCode}
                    onChange={(e) => setNewPrimaryCode(e.target.value)}
                    placeholder="एकाइ कोड (उदा: 100mtr, 1 Carton, 12pcs)"
                    className="sm:col-span-5 px-2.5 py-1.5 bg-white border border-emerald-300 rounded-lg text-xs font-mono font-bold"
                  />
                  <input
                    type="text"
                    value={newPrimaryLabelNe}
                    onChange={(e) => setNewPrimaryLabelNe(e.target.value)}
                    placeholder="नेपाली नाम (उदा: १०० मिटर रोल)"
                    className="sm:col-span-4 px-2.5 py-1.5 bg-white border border-emerald-300 rounded-lg text-xs"
                  />
                  <button
                    type="submit"
                    className="sm:col-span-3 py-1.5 px-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold cursor-pointer"
                  >
                    + मुख्य एकाइ
                  </button>
                </form>
              </div>

              {/* Secondary Units Box */}
              <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-blue-950">
                    📏 द्वितीय एकाइ सूची (Secondary Units — जस्तै: Pcs, Mtr, Ltr, Kg)
                  </span>
                  <span className="text-[11px] font-mono font-bold bg-blue-200/80 text-blue-950 px-2 py-0.5 rounded">
                    {activeSecondaryUnits.length} एकाइ
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto pr-1">
                  {activeSecondaryUnits.map((u) => (
                    <div
                      key={u.id}
                      className="p-2 bg-white rounded-lg border border-blue-200 flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="min-w-0 flex-1">
                        <input
                          type="text"
                          value={u.labelNe}
                          onChange={(e) => {
                            const updated = activeSecondaryUnits.map((item) =>
                              item.id === u.id ? { ...item, labelNe: e.target.value } : item
                            );
                            updateCompanyProfile({ ...company, inventorySecondaryUnits: updated });
                          }}
                          className="w-full font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-blue-500 focus:outline-none text-xs"
                        />
                        <span className="text-[10px] font-mono text-blue-700 font-bold">कोड: {u.code}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const updated = activeSecondaryUnits.filter((item) => item.id !== u.id);
                          updateCompanyProfile({ ...company, inventorySecondaryUnits: updated });
                          showToast(`द्वितीय एकाइ '${u.code}' हटाइयो।`);
                        }}
                        className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                        title="हटाउनुहोस्"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Add Secondary Unit */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!newSecondaryCode.trim()) return;
                    const code = newSecondaryCode.trim();
                    const labelNe = newSecondaryLabelNe.trim() || code;
                    const updated = [
                      ...activeSecondaryUnits,
                      { id: `SEC_${Date.now()}`, code, labelNe, labelEn: labelNe }
                    ];
                    updateCompanyProfile({ ...company, inventorySecondaryUnits: updated });
                    setNewSecondaryCode('');
                    setNewSecondaryLabelNe('');
                    showToast(`✓ द्वितीय एकाइ '${code}' थपियो!`);
                  }}
                  className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-2 border-t border-blue-200/70"
                >
                  <input
                    type="text"
                    required
                    value={newSecondaryCode}
                    onChange={(e) => setNewSecondaryCode(e.target.value)}
                    placeholder="द्वितीय कोड (उदा: Pcs, Mtr, Ltr, Kg)"
                    className="sm:col-span-5 px-2.5 py-1.5 bg-white border border-blue-300 rounded-lg text-xs font-mono font-bold"
                  />
                  <input
                    type="text"
                    value={newSecondaryLabelNe}
                    onChange={(e) => setNewSecondaryLabelNe(e.target.value)}
                    placeholder="नेपाली नाम (उदा: मिटर / पिस / लिटर)"
                    className="sm:col-span-4 px-2.5 py-1.5 bg-white border border-blue-300 rounded-lg text-xs"
                  />
                  <button
                    type="submit"
                    className="sm:col-span-3 py-1.5 px-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-xs font-bold cursor-pointer"
                  >
                    + द्वितीय एकाइ
                  </button>
                </form>
              </div>
            </div>

            {/* Unit Conversion Presets (मुख्य एकाइ = कति द्वितीय एकाइ?) */}
            <div className="p-4 bg-amber-50/60 rounded-xl border border-amber-200 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span className="text-xs font-black text-amber-950">
                  🔄 मुख्य एकाइ = द्वितीय एकाइ रूपान्तरण सूत्रहरू (Unit Conversion Presets — जस्तै: 100mtr = 100 Mtr, 1 Carton = 12 Pcs, 12pcs = 12 Pcs)
                </span>
                <span className="text-[11px] text-amber-800">
                  नयाँ सामान दर्ता गर्दा १-क्लिकमा छान्न सकिने सूत्रहरू
                </span>
              </div>

              <div className="flex flex-wrap gap-2">
                {activeUnitConversions.map((conv) => (
                  <div
                    key={conv.id}
                    className="px-3 py-1.5 bg-white border border-amber-300 rounded-lg text-xs flex items-center gap-2 shadow-2xs"
                  >
                    <span className="font-mono font-black text-emerald-900">{conv.primaryUnit}</span>
                    <span className="text-slate-400 font-bold">=</span>
                    <span className="font-mono font-black text-blue-900">
                      {conv.ratio} {conv.secondaryUnit}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const updated = activeUnitConversions.filter((c) => c.id !== conv.id);
                        updateCompanyProfile({ ...company, unitConversionPresets: updated });
                      }}
                      className="text-slate-400 hover:text-rose-600 cursor-pointer ml-1"
                      title="सूत्र हटाउनुहोस्"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newConvPrimary.trim() || !newConvSecondary.trim() || newConvRatio <= 0) return;
                  const p = newConvPrimary.trim();
                  const s = newConvSecondary.trim();
                  const r = Number(newConvRatio) || 1;
                  const updated = [
                    ...activeUnitConversions,
                    {
                      id: `CONV_${Date.now()}`,
                      primaryUnit: p,
                      secondaryUnit: s,
                      ratio: r,
                      labelNe: `${p} = ${r} ${s}`
                    }
                  ];
                  updateCompanyProfile({ ...company, unitConversionPresets: updated });
                  showToast(`✓ रूपान्तरण सूत्र '${p} = ${r} ${s}' थपियो!`);
                }}
                className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center pt-2 border-t border-amber-200/80 text-xs"
              >
                <div className="sm:col-span-4">
                  <input
                    type="text"
                    value={newConvPrimary}
                    onChange={(e) => setNewConvPrimary(e.target.value)}
                    placeholder="मुख्य एकाइ (उदा: 100mtr, 1 Carton)"
                    className="w-full px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg font-mono font-bold"
                  />
                </div>
                <div className="sm:col-span-1 text-center font-black text-amber-900">=</div>
                <div className="sm:col-span-2">
                  <input
                    type="number"
                    min={1}
                    step="any"
                    value={newConvRatio}
                    onChange={(e) => setNewConvRatio(parseFloat(e.target.value) || 1)}
                    placeholder="संख्या (उदा: 100, 12)"
                    className="w-full px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg font-mono font-bold text-center"
                  />
                </div>
                <div className="sm:col-span-3">
                  <input
                    type="text"
                    value={newConvSecondary}
                    onChange={(e) => setNewConvSecondary(e.target.value)}
                    placeholder="द्वितीय एकाइ (उदा: Mtr, Pcs, Ltr)"
                    className="w-full px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg font-mono font-bold"
                  />
                </div>
                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    className="w-full py-1.5 px-3 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg cursor-pointer"
                  >
                    + सूत्र थप्ने
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* 2. PRODUCT CATEGORIES (सामान क्याटगोरी मिलाउने) */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Boxes className="w-5 h-5 text-emerald-700" />
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    {isNe ? '२. सामान तथा कृषि औजार क्याटगोरी (Product Categories)' : '2. Product Categories Master'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isNe
                      ? 'इन्भेन्टरीमा सामान वर्गीकरण गर्न प्रयोग हुने क्याटगोरीहरू थप्ने, सच्याउने वा हटाउने'
                      : 'Add, rename, or remove product categories used in Inventory'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  updateCompanyProfile({
                    ...company,
                    productCategories: DEFAULT_PRODUCT_CATEGORIES
                  });
                  showToast('✓ सामान क्याटगोरीहरू डिफल्टमा रिसेट गरियो!');
                }}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold cursor-pointer"
              >
                ↺ रिसेट
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {activeProductCategories.map((cat) => (
                <div
                  key={cat.id}
                  className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-2"
                >
                  <div className="flex-1 min-w-0">
                    <input
                      type="text"
                      value={cat.labelNe}
                      onChange={(e) => {
                        const updated = activeProductCategories.map((c) =>
                          c.id === cat.id ? { ...c, labelNe: e.target.value } : c
                        );
                        updateCompanyProfile({ ...company, productCategories: updated });
                      }}
                      className="w-full font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-emerald-600 focus:outline-none text-xs"
                    />
                    <span className="text-[10px] font-mono text-slate-400 block">{cat.id}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (activeProductCategories.length <= 1) return;
                      const updated = activeProductCategories.filter((c) => c.id !== cat.id);
                      const updatedCustom = (company.customCategories || []).filter((c) => c.id !== cat.id);
                      updateCompanyProfile({
                        ...company,
                        productCategories: updated,
                        customCategories: updatedCustom
                      });
                      showToast(`क्याटगोरी '${cat.labelNe}' हटाइयो।`);
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 cursor-pointer"
                    title="हटाउनुहोस्"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Custom Product Category Form */}
            <form onSubmit={handleAddCategory} className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-3 border-t border-slate-100">
              <input
                type="text"
                required
                placeholder={isNe ? 'नयाँ क्याटगोरीको नाम (उदा: सौर्य सिँचाइ उपकरण, हार्डवेयर सामान)' : 'Category Name (Nepali)'}
                value={newCategoryNe}
                onChange={(e) => setNewCategoryNe(e.target.value)}
                className="sm:col-span-5 px-3 py-2 border border-slate-300 rounded-lg text-xs font-bold"
              />
              <input
                type="text"
                placeholder={isNe ? 'English Name / Code (ऐच्छिक, उदा: SOLAR_EQUIP)' : 'English Name (Optional)'}
                value={newCategoryEn}
                onChange={(e) => setNewCategoryEn(e.target.value)}
                className="sm:col-span-4 px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
              />
              <button
                type="submit"
                className="sm:col-span-3 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
              >
                + {isNe ? 'क्याटगोरी थप्नुहोस्' : 'Add Category'}
              </button>
            </form>
          </div>

          {/* 3. STAFF ROLES / DESIGNATIONS (कर्मचारी पद तथा भूमिका मिलाउने) */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-700" />
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    {isNe ? '३. कर्मचारी पद तथा भूमिका (Staff Roles & Designations)' : '3. Staff Roles & Designations Master'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isNe
                      ? 'कर्मचारी दर्ता र हाजिरीमा प्रयोग हुने पदहरू र डिफल्ट तलब/ज्याला दर मिलाउनुहोस्'
                      : 'Configure employee designations and default monthly/daily rates for Attendance & Payroll'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  updateCompanyProfile({ ...company, staffRoles: DEFAULT_STAFF_ROLES });
                  showToast('✓ कर्मचारी पदहरू डिफल्टमा रिसेट गरियो!');
                }}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold cursor-pointer"
              >
                ↺ रिसेट
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {activeStaffRoles.map((role) => (
                <div
                  key={role.id}
                  className="p-3 bg-purple-50/40 rounded-xl border border-purple-200 flex items-center justify-between gap-2"
                >
                  <div className="flex-1 min-w-0 space-y-1">
                    <input
                      type="text"
                      value={role.titleNe}
                      onChange={(e) => {
                        const updated = activeStaffRoles.map((r) =>
                          r.id === role.id ? { ...r, titleNe: e.target.value } : r
                        );
                        updateCompanyProfile({ ...company, staffRoles: updated });
                      }}
                      className="w-full font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-purple-600 focus:outline-none text-xs"
                    />
                    <div className="flex items-center gap-2 text-[10px] text-purple-800 font-mono">
                      <span>{role.defaultWageType === 'DAILY' ? 'दैनिक ज्याला:' : 'मासिक तलब:'}</span>
                      <input
                        type="number"
                        value={role.defaultRate || 0}
                        onChange={(e) => {
                          const updated = activeStaffRoles.map((r) =>
                            r.id === role.id ? { ...r, defaultRate: Number(e.target.value) || 0 } : r
                          );
                          updateCompanyProfile({ ...company, staffRoles: updated });
                        }}
                        className="w-20 px-1.5 py-0.5 bg-white border border-purple-200 rounded font-bold"
                      />
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const updated = activeStaffRoles.filter((r) => r.id !== role.id);
                      updateCompanyProfile({ ...company, staffRoles: updated });
                      showToast(`पद '${role.titleNe}' हटाइयो।`);
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 cursor-pointer"
                    title="हटाउनुहोस्"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add New Staff Role */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newStaffRoleNe.trim()) return;
                const newRole = {
                  id: `ROLE_${Date.now()}`,
                  titleNe: newStaffRoleNe.trim(),
                  titleEn: newStaffRoleEn.trim() || newStaffRoleNe.trim(),
                  defaultWageType: newStaffRoleWageType,
                  defaultRate: Number(newStaffRoleRate) || 0
                };
                updateCompanyProfile({
                  ...company,
                  staffRoles: [...activeStaffRoles, newRole]
                });
                setNewStaffRoleNe('');
                setNewStaffRoleEn('');
                showToast(`✓ नयाँ कर्मचारी पद '${newRole.titleNe}' थपियो!`);
              }}
              className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-3 border-t border-slate-100 text-xs"
            >
              <input
                type="text"
                required
                value={newStaffRoleNe}
                onChange={(e) => setNewStaffRoleNe(e.target.value)}
                placeholder="नयाँ कर्मचारी पद (उदा: वेल्डिङ मिस्त्री, लेखापाल, मार्केटिङ अधिकृत)"
                className="sm:col-span-5 px-3 py-2 border border-slate-300 rounded-lg font-bold"
              />
              <select
                value={newStaffRoleWageType}
                onChange={(e) => setNewStaffRoleWageType(e.target.value as 'MONTHLY' | 'DAILY')}
                className="sm:col-span-2 px-2 py-2 border border-slate-300 rounded-lg bg-white font-semibold"
              >
                <option value="MONTHLY">मासिक तलब</option>
                <option value="DAILY">दैनिक ज्याला</option>
              </select>
              <input
                type="number"
                value={newStaffRoleRate}
                onChange={(e) => setNewStaffRoleRate(Number(e.target.value) || 0)}
                placeholder="डिफल्ट दर (रु.)"
                className="sm:col-span-2 px-2.5 py-2 border border-slate-300 rounded-lg font-mono font-bold"
              />
              <button
                type="submit"
                className="sm:col-span-3 px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-lg font-bold cursor-pointer"
              >
                + पद थप्नुहोस्
              </button>
            </form>
          </div>

          {/* 4. DAILY EXPENSE CATEGORIES & OTHER INCOME / LOAN CATEGORIES */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Daily Expense Categories */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-sm font-black text-amber-950">
                    💸 ४. दैनिक खर्च शीर्षकहरू (Expense Categories)
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    दैनिक खर्च भौचरमा देखिने रेडिमेड खर्च शीर्षकहरू
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    updateCompanyProfile({ ...company, expenseCategories: DEFAULT_EXPENSE_CATEGORIES });
                    showToast('✓ दैनिक खर्च शीर्षकहरू डिफल्टमा रिसेट गरियो!');
                  }}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-bold cursor-pointer"
                >
                  ↺ रिसेट
                </button>
              </div>

              <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1 text-xs">
                {activeExpenseCategoriesMaster.map((expCat) => (
                  <div
                    key={expCat.id}
                    className="p-2 bg-amber-50/40 border border-amber-200 rounded-lg flex items-center justify-between gap-2"
                  >
                    <input
                      type="text"
                      value={expCat.ne}
                      onChange={(e) => {
                        const updated = activeExpenseCategoriesMaster.map((c) =>
                          c.id === expCat.id ? { ...c, ne: e.target.value, en: e.target.value } : c
                        );
                        updateCompanyProfile({ ...company, expenseCategories: updated });
                      }}
                      className="flex-1 font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-amber-600 focus:outline-none text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const updated = activeExpenseCategoriesMaster.filter((c) => c.id !== expCat.id);
                        updateCompanyProfile({ ...company, expenseCategories: updated });
                      }}
                      className="text-slate-400 hover:text-rose-600 cursor-pointer p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newExpCatNe.trim()) return;
                  const clean = newExpCatNe.trim();
                  const updated = [
                    ...activeExpenseCategoriesMaster,
                    { id: `EXP_CAT_${Date.now()}`, ne: clean, en: clean }
                  ];
                  updateCompanyProfile({ ...company, expenseCategories: updated });
                  setNewExpCatNe('');
                  showToast(`✓ खर्च शीर्षक '${clean}' थपियो!`);
                }}
                className="flex gap-2 pt-2 border-t border-slate-100 text-xs"
              >
                <input
                  type="text"
                  required
                  value={newExpCatNe}
                  onChange={(e) => setNewExpCatNe(e.target.value)}
                  placeholder="नयाँ खर्च शीर्षक (उदा: गोदाम भाडा, इन्टरनेट...)"
                  className="flex-1 px-3 py-1.5 border border-slate-300 rounded-lg font-bold"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold cursor-pointer"
                >
                  + थप्ने
                </button>
              </form>
            </div>

            {/* Other Income & Loan Categories */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-sm font-black text-emerald-950">
                    💰 ५. अन्य आम्दानी तथा ऋण/सापटी शीर्षकहरू (Other Income & Loans)
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    आम्दानी भौचरमा अन्य आम्दानी र बैंक/व्यक्तिगत ऋण राख्न प्रयोग हुने शीर्षकहरू
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    updateCompanyProfile({ ...company, incomeCategories: DEFAULT_INCOME_CATEGORIES });
                    showToast('✓ आम्दानी तथा ऋण शीर्षकहरू डिफल्टमा रिसेट गरियो!');
                  }}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-bold cursor-pointer"
                >
                  ↺ रिसेट
                </button>
              </div>

              <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1 text-xs">
                {activeIncomeCategoriesMaster.map((incCat) => (
                  <div
                    key={incCat.id}
                    className="p-2 bg-emerald-50/40 border border-emerald-200 rounded-lg flex items-center justify-between gap-2"
                  >
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                        incCat.incomeType === 'LOAN_RECEIVED'
                          ? 'bg-indigo-100 text-indigo-900'
                          : 'bg-teal-100 text-teal-900'
                      }`}
                    >
                      {incCat.incomeType === 'LOAN_RECEIVED' ? '🏦 ऋण' : '💰 आम्दानी'}
                    </span>
                    <input
                      type="text"
                      value={incCat.ne}
                      onChange={(e) => {
                        const updated = activeIncomeCategoriesMaster.map((c) =>
                          c.id === incCat.id ? { ...c, ne: e.target.value, en: e.target.value } : c
                        );
                        updateCompanyProfile({ ...company, incomeCategories: updated });
                      }}
                      className="flex-1 font-bold text-slate-900 bg-transparent border-b border-transparent focus:border-emerald-600 focus:outline-none text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const updated = activeIncomeCategoriesMaster.filter((c) => c.id !== incCat.id);
                        updateCompanyProfile({ ...company, incomeCategories: updated });
                      }}
                      className="text-slate-400 hover:text-rose-600 cursor-pointer p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newIncCatNe.trim()) return;
                  const clean = newIncCatNe.trim();
                  const updated = [
                    ...activeIncomeCategoriesMaster,
                    { id: `INC_CAT_${Date.now()}`, ne: clean, en: clean, incomeType: newIncCatType }
                  ];
                  updateCompanyProfile({ ...company, incomeCategories: updated });
                  setNewIncCatNe('');
                  showToast(`✓ '${clean}' आम्दानी/ऋण शीर्षक थपियो!`);
                }}
                className="flex flex-wrap sm:flex-nowrap gap-2 pt-2 border-t border-slate-100 text-xs"
              >
                <select
                  value={newIncCatType}
                  onChange={(e) => setNewIncCatType(e.target.value as 'OTHER_INCOME' | 'LOAN_RECEIVED')}
                  className="px-2 py-1.5 border border-slate-300 rounded-lg bg-white font-bold text-xs"
                >
                  <option value="OTHER_INCOME">💰 अन्य आम्दानी</option>
                  <option value="LOAN_RECEIVED">🏦 ऋण / सापटी</option>
                </select>
                <input
                  type="text"
                  required
                  value={newIncCatNe}
                  onChange={(e) => setNewIncCatNe(e.target.value)}
                  placeholder="नयाँ आम्दानी वा ऋण शीर्षक..."
                  className="flex-1 px-3 py-1.5 border border-slate-300 rounded-lg font-bold"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold cursor-pointer"
                >
                  + थप्ने
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 8: DATABASE BACKUP, GMAIL BACKUP & MASTER EXCEL/PDF                   */}
      {/* ========================================================================= */}
      {activeTab === 'BACKUP' && (
        <div className="space-y-5">
          {/* Company Gmail Auto-Backup Configuration */}
          <div className="bg-white p-6 rounded-2xl border-2 border-emerald-600/30 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  📧 कम्पनीको Gmail मा डाटा ब्याकअप र सबै रिपोर्ट Excel/PDF डाउनलोड
                </h2>
                <p className="text-xs text-slate-500">
                  आफ्नो कम्पनीको Gmail ठेगाना राख्नुहोस् र १-क्लिकमा सम्पूर्ण हिसाबकिताब Gmail, Excel वा PDF मा सुरक्षित राख्नुहोस्
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end text-xs">
              <div className="sm:col-span-2">
                <label className="block font-bold text-slate-700 mb-1">
                  कम्पनीको आधिकारिक ब्याकअप Gmail ठेगाना (Backup Gmail Address):
                </label>
                <input
                  type="email"
                  value={backupGmail}
                  onChange={(e) => setBackupGmail(e.target.value)}
                  placeholder="yourcompany@gmail.com"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-slate-900"
                />
              </div>
              <button
                type="button"
                onClick={() => {
                  updateCompanyProfile({
                    ...company,
                    backupGmail: backupGmail.trim(),
                    email: company.email || backupGmail.trim(),
                    autoGmailBackup
                  });
                  showToast('✓ कम्पनीको ब्याकअप Gmail सुरक्षित गरियो!');
                }}
                className="py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer"
              >
                ✓ Gmail ठेगाना सेभ गर्नुहोस्
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
              <button
                type="button"
                onClick={() => setIsDriveModalOpen(true)}
                className="py-3 px-4 bg-sky-700 hover:bg-sky-800 text-white font-bold rounded-xl cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <Cloud className="w-4 h-4" />
                <span>☁️ Google Drive मा ब्याकअप र सिंक</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  exportFullBackup();
                  const targetEmail = backupGmail.trim() || company.email || '';
                  const subject = encodeURIComponent(
                    `${company.name} - ERP Full Data Backup (${todayBs})`
                  );
                  const body = encodeURIComponent(
                    `नमस्ते,\n\n${company.name} (PAN: ${company.panVatNo}) को मिति ${todayBs} सम्मको सम्पूर्ण ERP ब्याकअप फाइल डाउनलोड भइसकेको छ।\n\nसारांश:\n- कुल बिक्री बिल: ${invoices.length}\n- कुल खरिद: ${purchases.length}\n- कुल सामान स्टक: ${items.length}\n- कुल पार्टी: ${parties.length}\n- कुल कर्मचारी: ${employees.length}\n\nकृपया भर्खरै डाउनलोड भएको JSON वा Excel फाइल यस इमेलमा Attach गरी सुरक्षित राख्नुहोला।`
                  );
                  const mailtoLink = document.createElement('a');
                  mailtoLink.href = `mailto:${targetEmail}?subject=${subject}&body=${body}`;
                  mailtoLink.click();
                  showToast('✓ ब्याकअप फाइल डाउनलोड भयो र Gmail ड्राफ्ट खुल्यो!');
                }}
                className="py-3 px-4 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <Share2 className="w-4 h-4" />
                <span>📧 Gmail मा ब्याकअप पठाउनुहोस्</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  exportAllReportsWorkbookToExcel({
                    company,
                    invoices,
                    purchases,
                    items,
                    parties,
                    partyTransactions,
                    bankAccounts,
                    employees,
                    attendance,
                    employeeLedger,
                    rawMaterials,
                    productionBatches
                  });
                  showToast('✓ सबै रिपोर्टहरूको Master Excel Workbook डाउनलोड भयो!');
                }}
                className="py-3 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <Download className="w-4 h-4" />
                <span>📊 सबै रिपोर्ट Excel मा डाउनलोड</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  printOrDownloadReportPdf({
                    company,
                    titleNe: 'कम्पनी मास्टर सारांश प्रतिवेदन (Master Summary PDF)',
                    titleEn: 'Company Master ERP Summary Report',
                    headers: ['विवरण (Metric)', 'संख्या / रकम (Value)'],
                    rows: [
                      ['कम्पनीको नाम', company.name],
                      ['PAN / VAT नं.', company.panVatNo],
                      ['कुल बिक्री बिल संख्या', invoices.length],
                      ['कुल खरिद बिल संख्या', purchases.length],
                      ['कुल इन्भेन्टरी सामानहरू', items.length],
                      ['कुल ग्राहक तथा सप्लायर पार्टी', parties.length],
                      ['कुल बैंक खाता संख्या', bankAccounts.length],
                      ['कुल कर्मचारी संख्या', employees.length]
                    ],
                    mode: 'DOWNLOAD'
                  });
                }}
                className="py-3 px-4 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl cursor-pointer flex items-center justify-center gap-2 shadow-xs"
              >
                <Printer className="w-4 h-4" />
                <span>📄 मास्टर सारांश PDF सेभ/प्रिन्ट</span>
              </button>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Database className="w-5 h-5 text-emerald-700" />
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  {isNe ? 'डाटा तथा स्थानीय फोल्डर ब्याकअप (Local File Storage & Backup)' : 'Data & Local Folder Backup'}
                </h2>
                <p className="text-xs text-slate-500">
                  {isNe ? 'मोबाइल वा कम्प्युटरको स्थानीय फोल्डर (Local Folder) मा डाटाबेस ब्याकअप राख्नुहोस्' : 'Select local device directory for database backups'}
                </p>
              </div>
            </div>

            {/* Dedicated Local File Storage Toggle & Folder Selector Box */}
            <div className="p-4 bg-emerald-50/80 border-2 border-emerald-300 rounded-2xl space-y-3.5 text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <div className="p-2 bg-emerald-700 text-white rounded-xl shrink-0 mt-0.5">
                    <Database className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-extrabold text-emerald-950 text-sm flex items-center gap-2">
                      <span>📁 स्थानीय फोल्डर ब्याकअप (Local Device Folder Storage)</span>
                      {isLocalFolderEnabled ? (
                        <span className="px-2 py-0.5 bg-emerald-700 text-white rounded text-[10px] font-bold">
                          ACTIVE / सक्रिय
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-slate-200 text-slate-700 rounded text-[10px] font-bold">
                          DISABLED
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-emerald-900 mt-0.5">
                      {isNe
                        ? 'एप चलाउँदा डाटाबेस ब्याकअप मोबाइल वा पीसी (PC) को रोजिएको फोल्डरमा सुरक्षित रहन्छ।'
                        : 'Database backups are mirrored to your chosen local directory on PC or Mobile.'}
                    </p>
                  </div>
                </div>

                {/* Local Storage Toggle Button */}
                <button
                  type="button"
                  onClick={() => {
                    const nextState = !isLocalFolderEnabled;
                    setIsLocalFolderEnabled(nextState);
                    localStorage.setItem('krishiyantra_local_backup_enabled', String(nextState));
                    showToast(
                      nextState
                        ? (isNe ? '✓ स्थानीय फोल्डर ब्याकअप सक्रिय भयो!' : '✓ Local folder backup enabled!')
                        : (isNe ? 'स्थानीय फोल्डर ब्याकअप निष्कृय गरियो।' : 'Local folder backup disabled.')
                    );
                  }}
                  className={`px-3.5 py-2 rounded-xl font-bold cursor-pointer transition text-xs whitespace-nowrap border shadow-2xs ${
                    isLocalFolderEnabled
                      ? 'bg-emerald-700 text-white border-emerald-800'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {isLocalFolderEnabled ? '✓ स्थानीय ब्याकअप (ON)' : 'स्थानीय ब्याकअप (OFF)'}
                </button>
              </div>

              {/* Directory Picker Button & Active Folder Badge */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pt-2 border-t border-emerald-200">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-emerald-950">
                    {isNe ? 'छानिएको फोल्डर (Local Directory):' : 'Current Directory:'}
                  </span>
                  <span className="px-2.5 py-1 bg-white border border-emerald-400 rounded-lg font-mono font-bold text-slate-900 text-xs shadow-2xs">
                    {localBackupFolder || (isNe ? 'फोल्डर छानिएको छैन' : 'No directory chosen')}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleSelectLocalFolder}
                  className="px-3.5 py-2 bg-gradient-to-r from-emerald-800 to-teal-800 hover:from-emerald-900 hover:to-teal-900 text-white font-extrabold rounded-xl text-xs cursor-pointer shadow-xs flex items-center justify-center gap-1.5 shrink-0"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-200" />
                  <span>{isNe ? '📁 ब्याकअप फोल्डर छान्नुहोस् / फेर्नुहोस्' : 'Select / Switch Backup Folder'}</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={exportFullBackup}
                className="flex items-center justify-center gap-2 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition shadow-xs cursor-pointer"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>{t.backupDatabase} (JSON Snapshot)</span>
              </button>

              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".json"
                  onChange={handleRestoreFile}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 border border-slate-300 hover:bg-slate-50 text-slate-800 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-blue-600" />
                  <span>{t.restoreDatabase} (JSON Restore)</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={handleServerBackup}
                disabled={serverBackupBusy}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white text-xs font-bold rounded-xl transition shadow-xs cursor-pointer"
              >
                <Database className="w-4 h-4" />
                <span>
                  {serverBackupBusy
                    ? (isNe ? 'कृपया पर्खनुहोस्...' : 'Please wait...')
                    : (isNe ? 'Backup डाउनलोड (सर्भरको सबै डाटा)' : 'Download Backup (all server data)')}
                </span>
              </button>
              <div>
                <input type="file" ref={serverRestoreRef} accept=".json" onChange={handleServerRestore} className="hidden" />
                <button
                  onClick={() => serverRestoreRef.current?.click()}
                  disabled={serverBackupBusy}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 border border-emerald-700 text-emerald-800 hover:bg-emerald-50 disabled:opacity-60 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>{isNe ? 'सर्भर Backup फिर्ता (Restore)' : 'Restore Server Backup'}</span>
                </button>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <button
                onClick={() => {
                  loadAgricultureStarterCatalog();
                  showToast(isNe ? '✓ नमुना सामानहरू इन्भेन्टरीमा लोड भए!' : '✓ Sample catalog loaded!');
                }}
                className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800 hover:text-emerald-950 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{t.loadAgricultureSample}</span>
              </button>

              <button
                onClick={() => {
                  clearAllData();
                  showToast(isNe ? 'डाटाबेस खाली गरियो।' : 'Database cleared.');
                }}
                className="flex items-center gap-1.5 text-xs font-semibold text-rose-700 hover:text-rose-900 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t.clearDataWarning}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: EDIT / RENAME / DELETE CUSTOMER OR SUPPLIER PARTY                */}
      {/* ========================================================================= */}
      {isAddPartyOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
              <h3 className="text-sm font-bold text-slate-900">
                {editingParty
                  ? (isNe ? 'ग्राहक / पार्टी नाम फेर्ने र सच्याउने' : 'Rename / Edit Party')
                  : (isNe ? 'नयाँ ग्राहक / पार्टी दर्ता गर्नुहोस्' : 'Add New Party')}
              </h3>
              <button
                onClick={() => setIsAddPartyOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePartySubmit} className="p-5 space-y-3.5 text-xs overflow-y-auto flex-1 min-h-0">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'पार्टीको प्रकार (Party Type)*' : 'Party Type*'}
                </label>
                <select
                  value={partyTypeInput}
                  onChange={(e) => setPartyTypeInput(e.target.value as 'CUSTOMER' | 'SUPPLIER')}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 bg-slate-50"
                >
                  <option value="CUSTOMER">ग्राहक (Customer - लिनुपर्ने)</option>
                  <option value="SUPPLIER">सप्लायर / पार्टी (Supplier - तिनुपर्ने)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'ग्राहक / पार्टीको नाम (Rename / Name)*' : 'Party Name*'}
                </label>
                <input
                  type="text"
                  required
                  value={partyName}
                  onChange={(e) => setPartyName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'ठेगाना / स्थान (Address)*' : 'Address*'}
                </label>
                <input
                  type="text"
                  required
                  value={partyAddress}
                  onChange={(e) => setPartyAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'फोन नम्बर (Phone)' : 'Phone'}
                  </label>
                  <input
                    type="text"
                    value={partyPhone}
                    onChange={(e) => setPartyPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'प्यान नं. (PAN)' : 'PAN'}
                  </label>
                  <input
                    type="text"
                    maxLength={9}
                    value={partyPan}
                    onChange={(e) => setPartyPan(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'हालको बाँकी रकम (Current Balance Rs.)' : 'Current Due Balance (Rs.)'}
                </label>
                <input
                  type="number"
                  min={0}
                  value={partyOpeningDue}
                  onChange={(e) => setPartyOpeningDue(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                />
              </div>

              <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100">
                {editingParty ? (
                  <button
                    type="button"
                    onClick={() => {
                      deleteParty(editingParty.id);
                      setIsAddPartyOpen(false);
                      setEditingParty(null);
                      showToast(`✓ '${editingParty.name}' पार्टी हटाइयो!`);
                    }}
                    className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-lg transition cursor-pointer flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>हटाउनुहोस्</span>
                  </button>
                ) : (
                  <div />
                )}

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAddPartyOpen(false)}
                    className="px-3 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                  >
                    {isNe ? 'रद्द' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-lg shadow-xs transition cursor-pointer"
                  >
                    {isNe ? 'सुरक्षित गर्नुहोस्' : 'Save'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: EDIT / ADD BANK ACCOUNT + QR CODE UPLOAD                         */}
      {/* ========================================================================= */}
      {isAddBankOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
              <h3 className="text-sm font-bold text-slate-900">
                {editingBank
                  ? (isNe ? 'बैंक खाता तथा QR सच्याउनुहोस्' : 'Edit Bank Account & QR')
                  : (isNe ? 'नयाँ बैंक खाता तथा QR थप्नुहोस्' : 'Add Bank Account & QR')}
              </h3>
              <button
                onClick={() => setIsAddBankOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveBankSubmit} className="p-5 space-y-3.5 text-xs overflow-y-auto flex-1 min-h-0">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'बैंकको नाम (Bank Name)*' : 'Bank Name*'}
                </label>
                <input
                  type="text"
                  required
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'खाता नम्बर (Account Number)*' : 'Account Number*'}
                </label>
                <input
                  type="text"
                  required
                  value={bankAccNo}
                  onChange={(e) => setBankAccNo(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'खातावालाको नाम (Account Holder)' : 'Account Holder'}
                </label>
                <input
                  type="text"
                  value={bankHolder}
                  onChange={(e) => setBankHolder(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'शाखा (Branch)' : 'Branch'}
                  </label>
                  <input
                    type="text"
                    value={bankBranch}
                    onChange={(e) => setBankBranch(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'सुरुवाती मौज्दात' : 'Opening Bal'}
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={bankOpeningBal}
                    onChange={(e) => setBankOpeningBal(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold"
                  />
                </div>
              </div>

              {/* Bank QR Code Image Upload for Direct Display in Sales POS */}
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                <label className="block text-[11px] font-bold text-emerald-950">
                  📱 बिक्रीमा सिधै देखिने बैंक QR कोड फोटो (FonePay / Bank QR Image Upload):
                </label>
                <div className="flex items-center gap-3">
                  {bankQrCodeUrl ? (
                    <img
                      src={bankQrCodeUrl}
                      alt="Bank QR Preview"
                      className="w-16 h-16 object-contain bg-white border border-emerald-300 rounded-lg p-1"
                    />
                  ) : (
                    <div className="w-16 h-16 bg-white border border-dashed border-emerald-300 rounded-lg flex items-center justify-center text-[10px] text-slate-400 text-center p-1">
                      QR फोटो
                    </div>
                  )}
                  <div className="flex-1 space-y-1.5">
                    <input
                      type="file"
                      ref={bankQrInputRef}
                      accept="image/*"
                      onChange={handleBankQrUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => bankQrInputRef.current?.click()}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg text-[11px] cursor-pointer flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{bankQrCodeUrl ? 'QR फोटो फेर्नुहोस्' : '+ QR फोटो अपलोड गर्नुहोस्'}</span>
                    </button>
                    {bankQrCodeUrl && (
                      <button
                        type="button"
                        onClick={() => setBankQrCodeUrl('')}
                        className="text-[10px] text-rose-600 font-bold hover:underline block cursor-pointer"
                      >
                        QR फोटो हटाउने
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100">
                {editingBank ? (
                  <button
                    type="button"
                    onClick={() => {
                      deleteBankAccount(editingBank.id);
                      setIsAddBankOpen(false);
                      setEditingBank(null);
                      showToast(`✓ बैंक खाता '${editingBank.bankName}' मेटाइयो!`);
                    }}
                    className="px-3 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg transition cursor-pointer flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>खाता मेटाउने</span>
                  </button>
                ) : (
                  <div />
                )}
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsAddBankOpen(false)}
                    className="px-3 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                  >
                    {isNe ? 'रद्द' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-lg shadow-xs transition cursor-pointer"
                  >
                    {isNe ? 'बैंक र QR सुरक्षित गर्नुहोस्' : 'Save Bank & QR'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2.5: ADD / EDIT USER & ROLE ACCOUNT                                 */}
      {/* ========================================================================= */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-700" />
                <span>
                  {editingAccount
                    ? (isNe ? 'युजर तथा पद सच्याउनुहोस्' : 'Edit User & Role')
                    : (isNe ? 'नयाँ युजर तथा पद अधिकार थप्नुहोस्' : 'Add New User & Role')}
                </span>
              </h3>
              <button
                onClick={() => setIsUserModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveUserSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'युजर / कर्मचारीको नाम *' : 'User / Staff Name *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder="उदा: रामप्रसाद शर्मा"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? '१० अंकको मोबाइल नम्बर *' : '10-digit Mobile Number *'}
                </label>
                <input
                  type="text"
                  required
                  maxLength={10}
                  placeholder="उदा: 9845012399"
                  value={userMobile}
                  onChange={(e) => setUserMobile(e.target.value.replace(/\D/g, ''))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-xs font-bold focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'तोकिएको पद / भूमिका (Assigned Role) *' : 'Assigned Role *'}
                </label>
                <select
                  value={userAssignedRole}
                  onChange={(e) => setUserAssignedRole(e.target.value as UserRole)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold bg-slate-50 focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                >
                  <option value="OWNER">👑 OWNER - मालिक / सञ्चालक (सम्पुर्ण अधिकार)</option>
                  <option value="ADMINISTRATION">🛡️ ADMINISTRATION - प्रशासक / एडमिन (प्रशासकीय अधिकार)</option>
                  <option value="ACCOUNTANT">📊 ACCOUNTANT - लेखापाल (आम्दानी, खर्च, ज्याला, भ्याट, हिसाब किताब)</option>
                  <option value="COUNTER_SALES">🛒 COUNTER SALES - काउन्टर बिलिङ (पर्चेज, सेल्स, बिलिङ अधिकार)</option>
                  <option value="SALESMAN">🏷️ SALESMAN - सेल्सम्यान (अर्डर टिपोट र द्रुत बिलिङ)</option>
                  <option value="SUPERVISOR">👷 SUPERVISOR - सुपरभाइजर (हाजिरी, सामान/स्टक विवरण, गल्ती नाेट)</option>
                  <option value="STAFF">👤 STAFF - कर्मचारी (हाजिर मात्र गर्ने)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isNe ? 'गोप्य PIN कोड' : 'PIN Code'}
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    placeholder="1234"
                    value={userPin}
                    onChange={(e) => setUserPin(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-xs font-bold focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isNe ? 'खाता स्थिति' : 'Account Status'}
                  </label>
                  <select
                    value={userStatus}
                    onChange={(e) => setUserStatus(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold bg-slate-50 focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                  >
                    <option value="APPROVED">✓ APPROVED (स्वीकृत)</option>
                    <option value="PENDING_APPROVAL">⏳ PENDING (पर्खाइमा)</option>
                    <option value="REJECTED">❌ REJECTED (अस्वीकृत)</option>
                  </select>
                </div>
              </div>

              {/* Module Permissions */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  {isNe ? 'चलाउन पाउने मोड्युलहरू (Permissions)' : 'Allowed Modules (Permissions)'}
                </label>
                <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                  {ALL_DASHBOARD_TABS.map((tab) => (
                    <label key={tab.id} className="flex items-center gap-2 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={userAllowedTabs.includes(tab.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setUserAllowedTabs([...userAllowedTabs, tab.id]);
                          } else {
                            setUserAllowedTabs(userAllowedTabs.filter(id => id !== tab.id));
                          }
                        }}
                        className="w-4 h-4 rounded-sm text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                      <span className="text-[10px] font-medium text-slate-600 group-hover:text-slate-900 transition">
                        {isNe ? tab.labelNe : tab.labelEn}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsUserModalOpen(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  {isNe ? 'रद्द गर्नुहोस्' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs shadow-xs cursor-pointer"
                >
                  {isNe ? 'सुरक्षित गर्नुहोस्' : 'Save User & Role'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: CONFIRM FISCAL YEAR CLOSING                                      */}
      {/* ========================================================================= */}
      {isFiscalCloseConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-rose-50 text-rose-950">
              <div className="flex items-center gap-2 font-bold text-sm">
                <AlertTriangle className="w-5 h-5 text-rose-700" />
                <span>{isNe ? 'आर्थिक वर्ष बन्दको पुष्टि' : 'Confirm Fiscal Year Closing'}</span>
              </div>
              <button
                onClick={() => setIsFiscalCloseConfirmOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <p className="text-slate-700 leading-relaxed">
                के तपाईं निश्चित हुनुहुन्छ कि आर्थिक वर्ष <strong>{company.fiscalYear}</strong> बन्द गरी नयाँ आर्थिक वर्ष <strong>{nextFiscalYear}</strong> सुरु गर्न चाहनुहुन्छ?
              </p>
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-amber-900 text-[11px] space-y-1">
                <p className="font-bold">✓ सिफारिस: कार्य सुरु गर्नु अघि ब्याकअप फाइल डाउनलोड गर्नुहोस्।</p>
                <p>✓ मौज्दात स्टक, ग्राहकको लिन बाँकी, र बैंक मौज्दात नयाँ वर्षमा सुरक्षित रहनेछन्।</p>
              </div>

              {!company.fiscalReopenCode ? (
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-rose-800">🔑 Reopen Code सेट गर्नुहोस् (अनिवार्य, कम्तिमा ४ अक्षर)</label>
                  <input
                    type="password"
                    value={closeCodeInput}
                    onChange={(e) => setCloseCodeInput(e.target.value)}
                    placeholder="Reopen Code"
                    className="w-full px-3 py-2 border border-rose-300 rounded-lg font-mono tracking-widest text-sm"
                  />
                  <p className="text-[11px] text-slate-500">बन्द वर्ष फेरि खोल्दा यही Code चाहिन्छ। सुरक्षित राख्नुहोस्।</p>
                </div>
              ) : (
                <p className="text-[11px] font-semibold text-emerald-800">🔒 बन्द भएको वर्ष खोल्न तपाईंले सेट गरेको Reopen Code चाहिनेछ।</p>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFiscalCloseConfirmOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition font-medium"
                >
                  {isNe ? 'फिर्ता' : 'Cancel'}
                </button>
                <button
                  type="button"
                  onClick={handleExecuteFiscalClose}
                  className="px-5 py-2 bg-rose-700 hover:bg-rose-800 text-white font-bold rounded-lg shadow-xs transition"
                >
                  {isNe ? 'हो, बन्द गर्नुहोस्' : 'Yes, Close FY'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Google Drive Backup Modal */}
      <GoogleDriveBackupModal
        isOpen={isDriveModalOpen}
        onClose={() => setIsDriveModalOpen(false)}
      />

      {/* Nepali Date Management Modal */}
      <DateManagementModal
        isOpen={isDateModalOpen}
        onClose={() => setIsDateModalOpen(false)}
      />

      {/* Mobile Authentication & User Switcher Modal */}
      <MobileAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialTab="LOGIN"
      />
    </div>
  );
};
