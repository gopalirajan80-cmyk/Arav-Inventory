import React, { useState } from 'react';
import { SlidersHorizontal } from 'lucide-react';
import type { PrintOptions, PrintMode } from '../utils/printHelper';

export interface InvoicePrintOpts {
  copies: string[];
  twoUp: boolean;
  bw: boolean;
  hideDiscount: boolean;
  watermark: '' | 'COPY' | 'PAID' | 'UNPAID';
}

export const COPY_LABELS = [
  { v: 'ORIGINAL', t: 'मूल प्रति (Original)' },
  { v: 'DUPLICATE', t: 'दोस्रो प्रति (Duplicate)' },
  { v: 'TRIPLICATE', t: 'तेस्रो प्रति (Triplicate)' },
  { v: 'COPY OF ORIGINAL', t: 'पुनः प्रिन्ट (Copy of Original)' }
];

/** Which options each document type shows. */
export interface PrintFeatures { copies?: boolean; twoUp?: boolean; compact?: boolean }

const storageKeyFor = (key: string) => (key === 'invoice' ? 'ky-invoice-print-opts' : `ky-print-opts:${key}`);
const defaultsFor = (key: string, features: PrintFeatures = { copies: true }): InvoicePrintOpts => ({
  copies: features.copies === false ? [] : ['ORIGINAL'],
  twoUp: false,
  bw: false,
  hideDiscount: false,
  watermark: ''
});

export function loadPrintOpts(key = 'invoice', features?: PrintFeatures): InvoicePrintOpts {
  const base = defaultsFor(key, features);
  try {
    const raw = localStorage.getItem(storageKeyFor(key));
    return raw ? { ...base, ...JSON.parse(raw) } : base;
  } catch {
    return base;
  }
}
export function savePrintOpts(o: InvoicePrintOpts, key = 'invoice') {
  try { localStorage.setItem(storageKeyFor(key), JSON.stringify(o)); } catch { /* ignore */ }
}

/** Build the printPage() arguments from the saved options of a document type. */
export function printArgsFor(key: string, base: { mode?: PrintMode; isA4?: boolean; features?: PrintFeatures } = {}): PrintOptions {
  const o = loadPrintOpts(key, base.features);
  const a4 = base.isA4 !== false;
  const twoUp = o.twoUp && a4;
  const copies = o.copies.length === 1 && twoUp ? [o.copies[0], 'DUPLICATE'] : o.copies;
  return {
    mode: base.mode,
    copies: copies.length ? copies : undefined,
    twoUp,
    bw: o.bw,
    watermark: o.watermark || undefined,
    hideDiscount: o.hideDiscount
  };
}

/** "Print Options" popover: copies, 2-up, B/W, watermark, compact columns. */
export const InvoicePrintOptions: React.FC<{
  value?: InvoicePrintOpts;
  onChange?: (o: InvoicePrintOpts) => void;
  isA4?: boolean;
  storageKey?: string;
  features?: PrintFeatures;
}> = ({ value, onChange, isA4 = true, storageKey = 'invoice', features = { copies: true, twoUp: true, compact: true } }) => {
  const [open, setOpen] = useState(false);
  const [inner, setInner] = useState<InvoicePrintOpts>(() => loadPrintOpts(storageKey, features));
  const cur = value || inner;
  const set = (patch: Partial<InvoicePrintOpts>) => {
    const next = { ...cur, ...patch };
    savePrintOpts(next, storageKey);
    setInner(next);
    onChange?.(next);
  };
  const toggleCopy = (v: string) => {
    const has = cur.copies.includes(v);
    const copies = has ? cur.copies.filter((c) => c !== v) : COPY_LABELS.map((l) => l.v).filter((x) => x === v || cur.copies.includes(x));
    set({ copies: copies.length ? copies : [v] });
  };
  const row = 'flex items-center gap-2 text-xs text-slate-800 py-1 cursor-pointer';
  return (
    <div className="relative no-print">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="ky-btn ky-btn-dark"
      >
        <SlidersHorizontal className="w-3.5 h-3.5" />
        <span>Print Options{cur.copies.length > 1 ? ` (${cur.copies.length})` : ''}</span>
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-2 z-[60] w-72 bg-white text-slate-900 rounded-xl shadow-xl border border-slate-200 p-3 space-y-2">
          {features.copies && (
            <div>
              <p className="text-[11px] font-bold text-slate-500 uppercase mb-1">प्रति (Copies), हरेक प्रति अलग पानामा</p>
              {COPY_LABELS.map((l) => (
                <label key={l.v} className={row}>
                  <input type="checkbox" checked={cur.copies.includes(l.v)} onChange={() => toggleCopy(l.v)} />
                  {l.t}
                </label>
              ))}
            </div>
          )}
          <div className={features.copies ? 'border-t border-slate-100 pt-2' : ''}>
            <p className="text-[11px] font-bold text-slate-500 uppercase mb-1">लेआउट (Layout)</p>
            {features.twoUp && (
              <label className={row + (isA4 ? '' : ' opacity-50')}>
                <input type="checkbox" disabled={!isA4} checked={cur.twoUp && isA4} onChange={(e) => set({ twoUp: e.target.checked })} />
                एउटै A4 मा २ प्रति (2-up, मूल + नक्कल)
              </label>
            )}
            {features.compact && (
              <label className={row}>
                <input type="checkbox" checked={cur.hideDiscount} onChange={(e) => set({ hideDiscount: e.target.checked })} />
                छुट कोलम नदेखाउने (Compact)
              </label>
            )}
            <label className={row}>
              <input type="checkbox" checked={cur.bw} onChange={(e) => set({ bw: e.target.checked })} />
              कालो-सेतो (Black &amp; White)
            </label>
          </div>
          <div className="border-t border-slate-100 pt-2">
            <p className="text-[11px] font-bold text-slate-500 uppercase mb-1">वाटरमार्क (Watermark)</p>
            <div className="flex gap-1.5 flex-wrap">
              {(['', 'COPY', 'PAID', 'UNPAID'] as const).map((w) => (
                <button
                  key={w || 'none'}
                  type="button"
                  onClick={() => set({ watermark: w })}
                  className={`px-3 py-1 rounded-full text-xs font-bold border cursor-pointer transition ${cur.watermark === w ? 'bg-emerald-700 text-white border-emerald-700 shadow-md' : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-500 hover:text-emerald-700'}`}
                >
                  {w || 'None'}
                </button>
              ))}
            </div>
          </div>
          <p className="text-[10px] text-slate-400">नोट: यी विकल्प प्रिन्टमा लाग्छन्, PDF डाउनलोडमा होइन।</p>
        </div>
      )}
    </div>
  );
};
