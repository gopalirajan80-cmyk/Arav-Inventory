import React from 'react';
import { Phone, Mail, MapPin, Hash } from 'lucide-react';
import { useLetterheadMode } from '../utils/paperSize';

interface Company {
  name?: string;
  address?: string;
  phone?: string;
  email?: string;
  panVatNo?: string;
  tagline?: string;
  logoUrl?: string;
  invoiceFooterNote?: string;
}

interface Props {
  company: Company;
  docTitle?: string;
  topNote?: string;
}

// Brand blues – matched to the pre-printed Agro Cross bill (printed with exact colour; see print-color-adjust in index.css)
const G1 = '#6fa8d6';
const G2 = '#2b5797';
const G3 = '#1e3f73';

/** Small round green icon used in front of each contact line */
const ContactLine: React.FC<{ icon: React.ReactNode; children: React.ReactNode; strong?: boolean }> = ({ icon, children, strong }) => (
  <div className="flex items-center justify-end gap-2 leading-tight">
    <span className={`text-right ${strong ? 'font-bold text-slate-900' : 'text-slate-700'}`}>{children}</span>
    <span
      className="shrink-0 inline-flex items-center justify-center rounded-full text-white"
      style={{ width: 18, height: 18, background: G2 }}
    >
      {icon}
    </span>
  </div>
);

/**
 * Designed letterhead (green curved header, round logo, contact icons, big document title).
 * It bleeds to the edges of the invoice card (negative margins) so the curves reach the paper edge.
 * In "PREPRINTED" mode it only leaves blank space for ready-made letterhead paper.
 */
export const PrintLetterhead: React.FC<Props> = ({ company, docTitle, topNote }) => {
  const mode = useLetterheadMode();
  if (mode === 'PREPRINTED') {
    return (
      <div>
        <div style={{ height: '38mm' }} />
        {docTitle && <div className="text-center text-base font-bold tracking-widest uppercase mb-2">{docTitle}</div>}
      </div>
    );
  }

  const name = (company.name || '').trim();

  return (
    <header className="-mx-6 -mt-6 sm:-mx-8 sm:-mt-8 mb-4 overflow-hidden" style={{ breakInside: 'avoid' }}>
      <div className="relative" style={{ height: 168 }}>
        {/* Curved background shapes */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 800 168"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="lhG" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor={G1} />
              <stop offset="1" stopColor={G2} />
            </linearGradient>
          </defs>
          {/* big top-left swoosh */}
          <path d="M0 0 H330 C312 62 262 104 190 132 C130 155 60 164 0 160 Z" fill="url(#lhG)" />
          {/* darker inner swoosh for depth */}
          <path d="M0 0 H262 C244 50 200 84 140 106 C98 120 46 124 0 120 Z" fill={G3} opacity="0.55" />
          {/* top-right corner swoosh */}
          <path d="M590 0 H800 V58 C740 62 650 44 590 0 Z" fill="url(#lhG)" />
          <path d="M690 0 H800 V30 C760 32 720 22 690 0 Z" fill={G3} opacity="0.6" />
        </svg>

        {/* Round logo / name badge */}
        <div
          className="absolute flex items-center justify-center text-center bg-white rounded-full overflow-hidden"
          style={{ left: 38, top: 32, width: 112, height: 112, border: `5px solid ${G1}`, boxShadow: '0 0 0 4px #fff' }}
        >
          {company.logoUrl ? (
            <img src={company.logoUrl} alt="" className="w-full h-full object-contain p-1.5" />
          ) : (
            <div className="px-2 leading-tight">
              <div className="font-extrabold uppercase tracking-tight" style={{ color: G3, fontSize: name.length > 14 ? 11 : 14 }}>
                {name || 'COMPANY'}
              </div>
              {company.tagline && <div className="text-[8px] uppercase tracking-widest text-slate-500 mt-0.5">{company.tagline}</div>}
            </div>
          )}
        </div>

        {/* Company name (middle) */}
        <div className="absolute" style={{ left: 336, top: 56, right: 290 }}>
          <h1 className="font-extrabold tracking-tight leading-tight" style={{ color: G3, fontSize: name.length > 22 ? 16 : 19 }}>{name}</h1>
          {company.tagline && <p className="text-[11px] italic text-slate-600 mt-0.5">{company.tagline}</p>}
        </div>

        {/* Contact lines (right) */}
        <div className="absolute text-[11px] space-y-1" style={{ right: 28, top: 62, maxWidth: 270 }}>
          {company.phone && <ContactLine icon={<Phone size={10} />}><span className="font-mono">{company.phone}</span></ContactLine>}
          {company.email && <ContactLine icon={<Mail size={10} />}>{company.email}</ContactLine>}
          {company.address && <ContactLine icon={<MapPin size={10} />}>{company.address}</ContactLine>}
          {company.panVatNo && (
            <ContactLine icon={<Hash size={10} />} strong>
              PAN/VAT: <span className="font-mono">{company.panVatNo}</span>
            </ContactLine>
          )}
        </div>
      </div>

      {/* Document title row */}
      <div className="px-6 sm:px-8 mt-1 flex items-end justify-between gap-4">
        <div className="text-[10px] tracking-[0.16em] uppercase text-slate-500 pb-1">{topNote}</div>
        {docTitle && (
          <div className="text-right">
            <div className="font-extrabold tracking-wide uppercase" style={{ color: G2, fontSize: 24, lineHeight: 1.1 }}>
              {docTitle}
            </div>
            <div className="mt-1 ml-auto h-[3px] w-full" style={{ background: `linear-gradient(90deg, transparent, ${G2})` }} />
          </div>
        )}
      </div>
    </header>
  );
};

/** Matching curved footer with thank-you note. Hidden (blank) on pre-printed letterhead paper. */
export const PrintFooter: React.FC<{ company: Company; note?: string }> = ({ company, note }) => {
  const mode = useLetterheadMode();
  if (mode === 'PREPRINTED') return <div style={{ height: '18mm' }} />;
  const text = note || company.invoiceFooterNote || 'धन्यवाद! फेरि पनि आउनुहोला। (Thank you for your business!)';
  return (
    <footer className="-mx-6 -mb-6 sm:-mx-8 sm:-mb-8 mt-6 overflow-hidden" style={{ breakInside: 'avoid' }}>
      <div className="px-6 sm:px-8 pb-2 text-[11px] font-bold italic" style={{ color: G3 }}>{text}</div>
      <svg className="block w-full" viewBox="0 0 800 70" preserveAspectRatio="none" style={{ height: 56 }} aria-hidden="true">
        <defs>
          <linearGradient id="lhF" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor={G2} />
            <stop offset="1" stopColor={G1} />
          </linearGradient>
        </defs>
        <path d="M0 70 V30 C80 6 190 4 300 34 C400 60 480 66 560 70 Z" fill="url(#lhF)" />
        <path d="M0 70 V50 C110 30 210 36 330 56 C380 64 430 68 470 70 Z" fill={G3} opacity="0.55" />
        <path d="M470 70 C560 62 640 40 720 24 C752 18 780 16 800 16 V70 Z" fill="#1e3f73" />
      </svg>
    </footer>
  );
};
