import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  BookOpen,
  Calendar,
  ArrowDownLeft,
  ArrowUpRight,
  Search,
  Printer,
  Download,
  Wallet,
  Landmark,
  CreditCard,
  Banknote,
  Filter,
  Receipt,
  FileSpreadsheet,
  CheckCircle2,
  TrendingUp,
  TrendingDown,
  Layers
} from 'lucide-react';
import * as XLSX from 'xlsx';
import {
  formatCurrency,
  toNepaliDigits,
  getTodayBsString,
  NEPALI_MONTHS_NE
} from '../utils/nepaliCalendar';
import { printOrDownloadReportPdf } from '../utils/pdfReportExporter';
import { PaperSizeToggle } from './PaperSizeToggle';

export interface DailyTransactionItem {
  id: string;
  time?: string;
  sourceType:
    | 'SALES_INVOICE'
    | 'CUSTOMER_COLLECTION'
    | 'SUPPLIER_PAYMENT'
    | 'PURCHASE_BILL'
    | 'DAILY_EXPENSE'
    | 'MANUAL_BANK_ENTRY'
    | 'STAFF_PAYROLL';
  sourceTitleNe: string;
  sourceTitleEn: string;
  partyOrBeneficiary: string;
  particulars: string;
  referenceNo?: string;
  paymentMode: 'CASH' | 'BANK';
  bankName?: string;
  bankAccountNo?: string;
  inflow: number; // आम्दानी / जम्मा (+)
  outflow: number; // खर्च / भुक्तानी (-)
}

export const DailyCashBook: React.FC<{
  onRecordExpenseClick?: () => void;
  onRecordCollectionClick?: () => void;
  onRecordPaymentClick?: () => void;
}> = ({ onRecordExpenseClick, onRecordCollectionClick, onRecordPaymentClick }) => {
  const {
    invoices,
    purchases,
    partyTransactions,
    expenses,
    employeeLedger,
    bankAccounts,
    company,
    language
  } = useApp();

  const isNe = language === 'ne';
  const todayBs = getTodayBsString();

  const [selectedDateBs, setSelectedDateBs] = useState<string>(todayBs);
  const [periodMode, setPeriodMode] = useState<'TODAY' | 'ALL' | 'MONTH' | 'YEAR' | 'SPECIFIC_DATE'>('TODAY');
  const [selectedMonthCode, setSelectedMonthCode] = useState<string>(todayBs.substring(5, 7));
  const [selectedYearBs, setSelectedYearBs] = useState<string>(todayBs.substring(0, 4));
  const [filterMode, setFilterMode] = useState<'ALL' | 'CASH_ONLY' | 'BANK_ONLY'>('ALL');
  const [flowFilter, setFlowFilter] = useState<'ALL' | 'INFLOW_ONLY' | 'OUTFLOW_ONLY'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const matchDateFilter = (dateBsStr: string) => {
    if (!dateBsStr) return false;
    const clean = dateBsStr.trim().replace(/\//g, '-');
    const parts = clean.split('-');
    const yr = parts[0] || '';
    const mo = parts[1] ? parts[1].padStart(2, '0') : '';

    if (periodMode === 'ALL') return true;
    if (periodMode === 'TODAY') return clean === todayBs.replace(/\//g, '-');
    if (periodMode === 'SPECIFIC_DATE') return clean === selectedDateBs.trim().replace(/\//g, '-');
    if (periodMode === 'YEAR') return selectedYearBs === 'ALL' || yr === selectedYearBs;
    if (periodMode === 'MONTH') {
      const yrMatch = selectedYearBs === 'ALL' || yr === selectedYearBs;
      const moMatch = selectedMonthCode === 'ALL' || mo === selectedMonthCode;
      return yrMatch && moMatch;
    }
    return true;
  };

  // Extract all daily cash and bank transactions for the selected BS date / period
  const dailyTransactions = useMemo<DailyTransactionItem[]>(() => {
    const list: DailyTransactionItem[] = [];

    // 1. Sales Invoices (Active)
    invoices
      .filter((inv) => inv.status === 'ACTIVE' && matchDateFilter(inv.dateBs))
      .forEach((inv) => {
        const isCash = inv.paymentMode === 'CASH';
        const isBank = inv.paymentMode === 'BANK_FONEPAY';
        if (!isCash && !isBank) return;

        const paid = inv.amountPaid !== undefined && inv.amountPaid > 0 ? inv.amountPaid : inv.grandTotal;
        if (paid <= 0) return;

        list.push({
          id: `inv-${inv.id}`,
          time: inv.time || '10:00 AM',
          sourceType: 'SALES_INVOICE',
          sourceTitleNe: inv.billType === 'VAT' ? 'कर बिक्री (VAT Sales)' : 'बिक्री बीजक (Sales)',
          sourceTitleEn: inv.billType === 'VAT' ? 'VAT Sales' : 'Sales Bill',
          partyOrBeneficiary: inv.customerName || (isNe ? 'काउन्टर ग्राहक' : 'Walk-in Customer'),
          particulars: `${inv.items?.length || 0} वटा सामान बिक्री (${inv.invoiceNo})`,
          referenceNo: inv.transactionRef || inv.invoiceNo,
          paymentMode: isCash ? 'CASH' : 'BANK',
          bankName: isBank ? inv.bankName || 'FonePay / Bank' : undefined,
          bankAccountNo: inv.bankAccountNo,
          inflow: paid,
          outflow: 0
        });
      });

    // 2. Customer Collections, Other Income, Loans & Supplier Payments (Party Transactions)
    partyTransactions
      .filter((tx) => matchDateFilter(tx.dateBs))
      .forEach((tx) => {
        const isBank = tx.paymentMode === 'BANK';
        const isCollection = tx.type === 'COLLECTION_FROM_CUSTOMER';

        if (isCollection) {
          const isLoan = tx.incomeType === 'LOAN_RECEIVED';
          const isOtherInc = tx.incomeType === 'OTHER_INCOME';
          const titleNe = isLoan
            ? `ऋण / सापटी प्राप्त (${tx.incomeCategory || 'Loan'})`
            : isOtherInc
            ? `अन्य आम्दानी (${tx.incomeCategory || 'Other Income'})`
            : 'ग्राहक असुली (Collection)';
          const titleEn = isLoan
            ? `Loan Received (${tx.incomeCategory || 'Loan'})`
            : isOtherInc
            ? `Other Income (${tx.incomeCategory || 'Income'})`
            : 'Customer Collection';

          list.push({
            id: `ptx-col-${tx.id}`,
            sourceType: 'CUSTOMER_COLLECTION',
            sourceTitleNe: titleNe,
            sourceTitleEn: titleEn,
            partyOrBeneficiary: tx.partyName,
            particulars:
              tx.notes ||
              (isLoan
                ? 'ऋण तथा सापटी रकम प्राप्त'
                : isOtherInc
                ? 'अन्य आम्दानी प्राप्त'
                : isNe
                ? 'ग्राहकबाट बाँकी बक्यौता असुली'
                : 'Customer Due Receipt'),
            referenceNo: tx.referenceNo || `RCP-${tx.id.slice(-4)}`,
            paymentMode: isBank ? 'BANK' : 'CASH',
            bankName: isBank ? tx.bankName || 'Bank' : undefined,
            bankAccountNo: tx.bankAccountNo,
            inflow: tx.amount,
            outflow: 0
          });
        } else {
          list.push({
            id: `ptx-pay-${tx.id}`,
            sourceType: 'SUPPLIER_PAYMENT',
            sourceTitleNe: 'पार्टी भुक्तानी (Payment)',
            sourceTitleEn: 'Supplier Payment',
            partyOrBeneficiary: tx.partyName,
            particulars: tx.notes || (isNe ? 'आपूर्तिकर्तालाई बाँकी भुक्तानी' : 'Payment to Supplier'),
            referenceNo: tx.referenceNo || `PMT-${tx.id.slice(-4)}`,
            paymentMode: isBank ? 'BANK' : 'CASH',
            bankName: isBank ? tx.bankName || 'Bank' : undefined,
            bankAccountNo: tx.bankAccountNo,
            inflow: 0,
            outflow: tx.amount
          });
        }
      });

    // 3. Purchases (Cash / Bank)
    purchases
      .filter((p) => matchDateFilter(p.dateBs))
      .forEach((p) => {
        const isCash = p.paymentMode === 'CASH';
        const isBank = p.paymentMode === 'BANK_FONEPAY';
        if (!isCash && !isBank) return;

        // Skip if already in partyTransactions with same reference to avoid double entry
        const existsInPartyTx = partyTransactions.some(
          (pt) => pt.referenceNo === p.purchaseBillNo && pt.dateBs === selectedDateBs
        );
        if (existsInPartyTx) return;

        list.push({
          id: `pur-${p.id}`,
          sourceType: 'PURCHASE_BILL',
          sourceTitleNe: 'सामान खरिद (Purchase)',
          sourceTitleEn: 'Purchase Bill',
          partyOrBeneficiary: p.supplierName,
          particulars: `${p.itemsSummary || 'सामान खरिद'} (${p.purchaseBillNo})`,
          referenceNo: p.purchaseBillNo,
          paymentMode: isCash ? 'CASH' : 'BANK',
          bankName: isBank ? p.bankName || 'Bank' : undefined,
          bankAccountNo: p.bankAccountNo,
          inflow: 0,
          outflow: p.grandTotal
        });
      });

    // 4. Daily Expenses (खर्चा)
    expenses
      .filter((e) => matchDateFilter(e.dateBs))
      .forEach((e) => {
        const bankAcc = e.bankAccountId ? bankAccounts.find((b) => b.id === e.bankAccountId) : undefined;
        list.push({
          id: `exp-${e.id}`,
          sourceType: 'DAILY_EXPENSE',
          sourceTitleNe: `दैनिक खर्च (${e.category})`,
          sourceTitleEn: `Expense (${e.category})`,
          partyOrBeneficiary: e.description || e.category,
          particulars: e.notes ? `${e.category} - ${e.notes}` : `${e.category} भुक्तानी`,
          referenceNo: `EXP-${e.id.slice(-4)}`,
          paymentMode: e.paymentMode === 'BANK' ? 'BANK' : 'CASH',
          bankName: bankAcc?.bankName,
          bankAccountNo: bankAcc?.accountNumber,
          inflow: 0,
          outflow: e.amount
        });
      });

    // 5. Manual Bank Entries
    (company.manualBankEntries || [])
      .filter((m) => matchDateFilter(m.dateBs))
      .forEach((m) => {
        const isInflow = m.type === 'DEPOSIT' || m.type === 'INTEREST';
        const typeLabels: Record<string, { ne: string; en: string }> = {
          DEPOSIT: { ne: 'बैंक दाखिला (Deposit)', en: 'Bank Deposit' },
          WITHDRAWAL: { ne: 'बैंकबाट झिकेको (Withdrawal)', en: 'Bank Withdrawal' },
          INTEREST: { ne: 'बैंक ब्याज (Interest)', en: 'Bank Interest' },
          BANK_CHARGE: { ne: 'बैंक शुल्क (Bank Charge)', en: 'Bank Fee' }
        };

        list.push({
          id: `mb-${m.id}`,
          sourceType: 'MANUAL_BANK_ENTRY',
          sourceTitleNe: typeLabels[m.type]?.ne || 'बैंक कारोबार',
          sourceTitleEn: typeLabels[m.type]?.en || 'Bank Entry',
          partyOrBeneficiary: m.bankName,
          particulars: m.particulars || 'बैंक कारोबार प्रविष्टि',
          referenceNo: m.referenceNo || `BNK-${m.id.slice(-4)}`,
          paymentMode: 'BANK',
          bankName: m.bankName,
          inflow: isInflow ? m.amount : 0,
          outflow: isInflow ? 0 : m.amount
        });
      });

    // 6. Employee Payroll / Advance Payments
    (employeeLedger || [])
      .filter(
        (el) =>
          matchDateFilter(el.dateBs) &&
          (el.type === 'SALARY_PAYMENT' || el.type === 'CASH_ADVANCE')
      )
      .forEach((el) => {
        const isSalary = el.type === 'SALARY_PAYMENT';
        list.push({
          id: `emp-${el.id}`,
          sourceType: 'STAFF_PAYROLL',
          sourceTitleNe: isSalary ? 'कर्मचारी तलब (Salary)' : 'कर्मचारी पेस्की (Advance)',
          sourceTitleEn: isSalary ? 'Staff Salary' : 'Salary Advance',
          partyOrBeneficiary: el.notes || (isNe ? 'कर्मचारी खाता' : 'Staff Account'),
          particulars: isSalary ? `तलब भुक्तानी (${el.notes})` : `पेस्की भुक्तानी (${el.notes})`,
          referenceNo: el.referenceBillNo || `EMP-${el.id.slice(-4)}`,
          paymentMode: el.paymentMode === 'BANK' ? 'BANK' : 'CASH',
          bankName: el.bankName,
          inflow: 0,
          outflow: el.amount
        });
      });

    return list;
  }, [
    invoices,
    purchases,
    partyTransactions,
    expenses,
    company.manualBankEntries,
    employeeLedger,
    bankAccounts,
    selectedDateBs,
    periodMode,
    selectedMonthCode,
    selectedYearBs,
    todayBs,
    isNe
  ]);

  // Filtered transactions based on UI selections & search
  const filteredTransactions = useMemo(() => {
    return dailyTransactions.filter((tx) => {
      // Payment Mode filter
      if (filterMode === 'CASH_ONLY' && tx.paymentMode !== 'CASH') return false;
      if (filterMode === 'BANK_ONLY' && tx.paymentMode !== 'BANK') return false;

      // Flow filter
      if (flowFilter === 'INFLOW_ONLY' && tx.inflow <= 0) return false;
      if (flowFilter === 'OUTFLOW_ONLY' && tx.outflow <= 0) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matches =
          tx.partyOrBeneficiary.toLowerCase().includes(q) ||
          tx.particulars.toLowerCase().includes(q) ||
          tx.sourceTitleNe.toLowerCase().includes(q) ||
          tx.sourceTitleEn.toLowerCase().includes(q) ||
          (tx.referenceNo || '').toLowerCase().includes(q) ||
          (tx.bankName || '').toLowerCase().includes(q);
        if (!matches) return false;
      }

      return true;
    });
  }, [dailyTransactions, filterMode, flowFilter, searchQuery]);

  // Aggregate Metrics & Total Balance Summary
  const summary = useMemo(() => {
    let totalCashIn = 0;
    let totalCashOut = 0;
    let totalBankIn = 0;
    let totalBankOut = 0;

    dailyTransactions.forEach((tx) => {
      if (tx.paymentMode === 'CASH') {
        totalCashIn += tx.inflow;
        totalCashOut += tx.outflow;
      } else {
        totalBankIn += tx.inflow;
        totalBankOut += tx.outflow;
      }
    });

    const netCash = totalCashIn - totalCashOut;
    const netBank = totalBankIn - totalBankOut;
    const combinedInflow = totalCashIn + totalBankIn;
    const combinedOutflow = totalCashOut + totalBankOut;
    const combinedNet = combinedInflow - combinedOutflow;

    const totalCashTxCount = dailyTransactions.filter((tx) => tx.paymentMode === 'CASH').length;
    const totalBankTxCount = dailyTransactions.filter((tx) => tx.paymentMode === 'BANK').length;

    return {
      totalCashIn,
      totalCashOut,
      netCash,
      totalBankIn,
      totalBankOut,
      netBank,
      combinedInflow,
      combinedOutflow,
      combinedNet,
      totalCashTxCount,
      totalBankTxCount,
      totalCount: dailyTransactions.length
    };
  }, [dailyTransactions]);

  // Print Daily Cash Book View via In-Page Print Modal
  const handlePrint = () => {
    printOrDownloadReportPdf({
      company,
      titleNe: 'दैनिक क्यासबुक (Daily Cash Book)',
      titleEn: 'Daily Cash Book Register',
      subtitleNe: `अवधि/मिति: ${periodMode === 'TODAY' ? todayBs : periodMode === 'SPECIFIC_DATE' ? selectedDateBs : periodMode}`,
      headers: ['क्र.सं.', 'कारोबार शीर्षक', 'पार्टी / विवरण', 'माध्यम', 'आम्दानी / असुली (+)', 'खर्च / भुक्तानी (-)', 'भौचर/बिल नं'],
      rows: filteredTransactions.map((tx, idx) => [
        idx + 1,
        tx.sourceTitleNe,
        `${tx.partyOrBeneficiary} (${tx.particulars})`,
        tx.paymentMode === 'CASH' ? 'नगद (CASH)' : `बैंक (${tx.bankName || 'BANK'})`,
        tx.inflow > 0 ? tx.inflow : 0,
        tx.outflow > 0 ? tx.outflow : 0,
        tx.referenceNo || '-'
      ]),
      summaryCards: [
        { label: 'कुल नगद आम्दानी', value: formatCurrency(summary.totalCashIn, true) },
        { label: 'कुल नगद खर्च', value: formatCurrency(summary.totalCashOut, true) },
        { label: 'खुद नगद मौज्दात', value: formatCurrency(summary.netCash, true) },
        { label: 'कुल खुद प्रवाह', value: formatCurrency(summary.combinedNet, true) }
      ],
      fileName: `DailyCashBook_${selectedDateBs}`,
      mode: 'PRINT'
    });
  };

  // Export Daily Cash Book to Excel
  const handleExportExcel = () => {
    const rows = filteredTransactions.map((tx, idx) => ({
      'क्र.सं.': idx + 1,
      'मिति (B.S.)': selectedDateBs,
      'समय': tx.time || '-',
      'कारोबारको प्रकार': tx.sourceTitleNe,
      'पार्टी / ग्राहक / शीर्षक': tx.partyOrBeneficiary,
      'विस्तृत विवरण': tx.particulars,
      'भुक्तानी माध्यम': tx.paymentMode === 'CASH' ? 'नगद (CASH)' : 'बैंक (BANK)',
      'बैंकको नाम': tx.bankName || '-',
      'आम्दानी / दाखिला (Inflow Rs.)': tx.inflow,
      'खर्च / भुक्तानी (Outflow Rs.)': tx.outflow,
      'भौचर/बिल नं': tx.referenceNo || '-'
    }));

    // Summary row
    rows.push({
      'क्र.सं.': '' as any,
      'मिति (B.S.)': 'कुल जम्मा',
      'समय': '',
      'कारोबारको प्रकार': '',
      'पार्टी / ग्राहक / शीर्षक': '',
      'विस्तृत विवरण': '',
      'भुक्तानी माध्यम': '',
      'बैंकको नाम': '',
      'आम्दानी / दाखिला (Inflow Rs.)': summary.combinedInflow,
      'खर्च / भुक्तानी (Outflow Rs.)': summary.combinedOutflow,
      'भौचर/बिल नं': `खुद: ${summary.combinedNet}`
    });

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `DailyCash_${selectedDateBs.replace(/\//g, '-')}`);
    XLSX.writeFile(wb, `DailyCashBook_${selectedDateBs.replace(/\//g, '-')}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Date Navigation */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-800">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-900">
                {isNe ? 'दैनिक क्यासबुक (Daily Cash Book)' : 'Daily Cash Book'}
              </h2>
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                {isNe ? 'दैनिक हिसाब' : 'Daily Journal'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {isNe
                ? 'आजको सम्पूर्ण नगद तथा बैंक दाखिला, बिक्री, असुली, खरिद र दैनिक खर्चको एकीकृत हिसाब'
                : 'Real-time record of all cash & bank collections, sales receipts, payments, and expenses'}
            </p>
          </div>
        </div>

        {/* Period, Month & Year Dropdown Selectors */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={periodMode}
            onChange={(e) => setPeriodMode(e.target.value as any)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-600"
          >
            <option value="TODAY">{isNe ? `आज (Today - ${todayBs})` : `Today (${todayBs})`}</option>
            <option value="ALL">{isNe ? 'सबै कारोबार (All)' : 'All Transactions'}</option>
            <option value="MONTH">{isNe ? 'महिना अनुसार (Months)' : 'By Month'}</option>
            <option value="YEAR">{isNe ? 'वर्ष अनुसार (Year)' : 'By Year'}</option>
            <option value="SPECIFIC_DATE">{isNe ? 'तोकिएको मिति (Select Date)' : 'Specific Date'}</option>
          </select>

          {periodMode === 'MONTH' && (
            <select
              value={selectedMonthCode}
              onChange={(e) => setSelectedMonthCode(e.target.value)}
              className="px-2.5 py-1.5 bg-emerald-50 border border-emerald-300 rounded-lg text-xs font-bold text-emerald-950 cursor-pointer"
            >
              <option value="ALL">{isNe ? 'सबै १२ महिना' : 'All Months'}</option>
              {NEPALI_MONTHS_NE.map((mNe, idx) => {
                const code = String(idx + 1).padStart(2, '0');
                return (
                  <option key={code} value={code}>
                    {code} - {mNe}
                  </option>
                );
              })}
            </select>
          )}

          {(periodMode === 'MONTH' || periodMode === 'YEAR') && (
            <select
              value={selectedYearBs}
              onChange={(e) => setSelectedYearBs(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 cursor-pointer"
            >
              <option value="ALL">{isNe ? 'सबै वर्ष' : 'All Years'}</option>
              {['2083', '2082', '2081', '2080'].map((yr) => (
                <option key={yr} value={yr}>
                  वि.सं. {yr}
                </option>
              ))}
            </select>
          )}

          {periodMode === 'SPECIFIC_DATE' && (
            <div className="flex items-center gap-1 px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                value={selectedDateBs}
                onChange={(e) => setSelectedDateBs(e.target.value)}
                placeholder="2081-11-15"
                className="w-24 text-xs font-mono font-bold bg-transparent text-slate-800 outline-none"
              />
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center gap-1.5">
            <PaperSizeToggle />
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-white border border-slate-300 hover:border-slate-400 rounded-lg text-xs font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer shadow-xs transition"
              title="Print Cash Book"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">{isNe ? 'प्रिन्ट' : 'Print'}</span>
            </button>
            <button
              onClick={handleExportExcel}
              className="px-3 py-1.5 bg-white border border-slate-300 hover:border-slate-400 rounded-lg text-xs font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer shadow-xs transition"
              title="Export to Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">{isNe ? 'एक्सेल' : 'Excel'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Highlight Summary Cards (Day Overview) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        {/* Cash Inflow */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
              <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600" />
              {isNe ? 'कुल नगद आम्दानी' : 'Total Cash In'}
            </span>
            <span className="p-1 rounded-md bg-emerald-50 text-emerald-700">
              <Banknote className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-xl font-bold font-mono text-emerald-700">
            {formatCurrency(summary.totalCashIn)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400 flex items-center justify-between">
            <span>{isNe ? 'बिक्री + असुली' : 'Sales & Receipts'}</span>
            <span className="font-semibold text-emerald-800">
              {toNepaliDigits(summary.totalCashTxCount)} {isNe ? 'कारोबार' : 'entries'}
            </span>
          </div>
        </div>

        {/* Cash Outflow */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
              <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
              {isNe ? 'कुल नगद खर्च' : 'Total Cash Out'}
            </span>
            <span className="p-1 rounded-md bg-rose-50 text-rose-700">
              <Wallet className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-xl font-bold font-mono text-rose-700">
            {formatCurrency(summary.totalCashOut)}
          </div>
          <div className="mt-1 text-[11px] text-slate-400 flex items-center justify-between">
            <span>{isNe ? 'दैनिक खर्च + भुक्तानी' : 'Expenses & Pay'}</span>
            <span className="font-semibold text-rose-800">
              {formatCurrency(summary.totalCashOut)}
            </span>
          </div>
        </div>

        {/* Net Cash Balance of the Day */}
        <div
          className={`p-4 rounded-xl border shadow-xs relative overflow-hidden ${
            summary.netCash >= 0
              ? 'bg-emerald-950 text-white border-emerald-900'
              : 'bg-rose-950 text-white border-rose-900'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-200">
              {isNe ? 'दिनको खुद नगद बचत' : 'Net Cashflow'}
            </span>
            <span
              className={`p-1 rounded-md ${
                summary.netCash >= 0 ? 'bg-emerald-800 text-emerald-200' : 'bg-rose-800 text-rose-200'
              }`}
            >
              {summary.netCash >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            </span>
          </div>
          <div className="mt-2 text-xl font-bold font-mono text-white">
            {formatCurrency(summary.netCash)}
          </div>
          <div className="mt-1 text-[11px] text-emerald-300">
            {isNe ? 'काउन्टरमा हुनुपर्ने खुद नगद' : 'Cash in hand change'}
          </div>
        </div>

        {/* Combined Net Bank Flow */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
              <Landmark className="w-3.5 h-3.5 text-blue-600" />
              {isNe ? 'बैंक खुद कारोबार' : 'Net Bank Flow'}
            </span>
            <span className="p-1 rounded-md bg-blue-50 text-blue-700">
              <CreditCard className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-xl font-bold font-mono text-blue-700">
            {formatCurrency(summary.netBank)}
          </div>
          <div className="mt-1 text-[11px] text-slate-500 flex items-center justify-between">
            <span className="text-emerald-600">+{formatCurrency(summary.totalBankIn)}</span>
            <span className="text-rose-600">-{formatCurrency(summary.totalBankOut)}</span>
          </div>
        </div>
      </div>

      {/* Filters and Search Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isNe
                ? 'ग्राहक, आपूर्तिकर्ता, विवरण वा बिल नं खोजी गर्नुहोस्...'
                : 'Search party, description, or bill ref...'
            }
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-700"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Payment Mode Selector */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => setFilterMode('ALL')}
              className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                filterMode === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              {isNe ? 'सबै (All)' : 'All'}
            </button>
            <button
              onClick={() => setFilterMode('CASH_ONLY')}
              className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                filterMode === 'CASH_ONLY' ? 'bg-emerald-700 text-white shadow-xs' : 'text-slate-600'
              }`}
            >
              {isNe ? '💵 नगद मात्र' : 'Cash Only'}
            </button>
            <button
              onClick={() => setFilterMode('BANK_ONLY')}
              className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                filterMode === 'BANK_ONLY' ? 'bg-blue-700 text-white shadow-xs' : 'text-slate-600'
              }`}
            >
              {isNe ? '🏦 बैंक / QR' : 'Bank Only'}
            </button>
          </div>

          {/* Flow Selector */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => setFlowFilter('ALL')}
              className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                flowFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              {isNe ? 'सबै बहाव' : 'All Flows'}
            </button>
            <button
              onClick={() => setFlowFilter('INFLOW_ONLY')}
              className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                flowFilter === 'INFLOW_ONLY' ? 'bg-emerald-700 text-white shadow-xs' : 'text-slate-600'
              }`}
            >
              {isNe ? '📥 आम्दानी (+)' : 'Inflow (+)'}
            </button>
            <button
              onClick={() => setFlowFilter('OUTFLOW_ONLY')}
              className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                flowFilter === 'OUTFLOW_ONLY' ? 'bg-rose-700 text-white shadow-xs' : 'text-slate-600'
              }`}
            >
              {isNe ? '📤 खर्च (-)' : 'Outflow (-)'}
            </button>
          </div>
        </div>
      </div>

      {/* Transactions Ledger Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-emerald-700" />
            <h3 className="text-sm font-bold text-slate-900">
              {isNe ? `मिति ${selectedDateBs} को कारोबार विवरण` : `Transactions for ${selectedDateBs}`}
            </h3>
            <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-mono font-semibold">
              {filteredTransactions.length}
            </span>
          </div>
          <div className="text-xs text-slate-500">
            {isNe ? 'असुली, बिक्री, भुक्तानी र खर्चको पूर्ण लेजर' : 'Full Cash & Bank Day Book'}
          </div>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400 mb-3">
              <BookOpen className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">
              {isNe ? 'यस मितिमा कुनै कारोबार भेटिएन' : 'No transactions recorded on this date'}
            </h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              {isNe
                ? 'माथिको मिति परिवर्तन गर्नुहोस् वा नयाँ बिक्री, असुली, भुक्तानी वा दैनिक खर्च प्रविष्टि गर्नुहोस्।'
                : 'Select another date or record new sales, collections, payments, or daily expenses.'}
            </p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              {onRecordExpenseClick && (
                <button
                  onClick={onRecordExpenseClick}
                  className="px-3 py-1.5 bg-amber-700 text-white rounded-lg text-xs font-bold hover:bg-amber-800 cursor-pointer transition"
                >
                  {isNe ? '+ दैनिक खर्च राख्नुहोस्' : '+ Record Expense'}
                </button>
              )}
              {onRecordCollectionClick && (
                <button
                  onClick={onRecordCollectionClick}
                  className="px-3 py-1.5 bg-emerald-700 text-white rounded-lg text-xs font-bold hover:bg-emerald-800 cursor-pointer transition"
                >
                  {isNe ? '+ ग्राहक असुली' : '+ Customer Collection'}
                </button>
              )}
              {onRecordPaymentClick && (
                <button
                  onClick={onRecordPaymentClick}
                  className="px-3 py-1.5 bg-blue-700 text-white rounded-lg text-xs font-bold hover:bg-blue-800 cursor-pointer transition"
                >
                  {isNe ? '+ पार्टी भुक्तानी' : '+ Supplier Payment'}
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100/75 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  <th className="py-2.5 px-3 w-12 text-center">#</th>
                  <th className="py-2.5 px-3">{isNe ? 'प्रकार (Type)' : 'Type'}</th>
                  <th className="py-2.5 px-3">{isNe ? 'पार्टी / ग्राहक / शीर्षक' : 'Party / Beneficiary'}</th>
                  <th className="py-2.5 px-3">{isNe ? 'विवरण' : 'Particulars'}</th>
                  <th className="py-2.5 px-3">{isNe ? 'माध्यम' : 'Mode'}</th>
                  <th className="py-2.5 px-3 text-right text-emerald-700">{isNe ? 'आम्दानी / दाखिला (+)' : 'Inflow (+)'}</th>
                  <th className="py-2.5 px-3 text-right text-rose-700">{isNe ? 'खर्च / भुक्तानी (-)' : 'Outflow (-)'}</th>
                  <th className="py-2.5 px-3 text-center">{isNe ? 'भौचर/बिल नं' : 'Ref / Bill'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredTransactions.map((tx, idx) => {
                  const isInflow = tx.inflow > 0;
                  const isCash = tx.paymentMode === 'CASH';

                  return (
                    <tr key={tx.id} className="hover:bg-slate-50 transition">
                      <td className="py-2.5 px-3 text-center font-mono text-slate-400">
                        {idx + 1}
                      </td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-bold text-[11px] ${
                            tx.sourceType === 'SALES_INVOICE'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : tx.sourceType === 'CUSTOMER_COLLECTION'
                              ? 'bg-teal-50 text-teal-800 border border-teal-200'
                              : tx.sourceType === 'DAILY_EXPENSE'
                              ? 'bg-amber-50 text-amber-900 border border-amber-200'
                              : tx.sourceType === 'SUPPLIER_PAYMENT'
                              ? 'bg-blue-50 text-blue-800 border border-blue-200'
                              : tx.sourceType === 'PURCHASE_BILL'
                              ? 'bg-indigo-50 text-indigo-800 border border-indigo-200'
                              : 'bg-slate-100 text-slate-800 border border-slate-200'
                          }`}
                        >
                          {isInflow ? (
                            <ArrowDownLeft className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <ArrowUpRight className="w-3 h-3 text-rose-600" />
                          )}
                          <span>{isNe ? tx.sourceTitleNe : tx.sourceTitleEn}</span>
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900">
                        {tx.partyOrBeneficiary}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 max-w-xs truncate" title={tx.particulars}>
                        {tx.particulars}
                      </td>
                      <td className="py-2.5 px-3">
                        {isCash ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900">
                            💵 {isNe ? 'नगद' : 'Cash'}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-900">
                            🏦 {tx.bankName || (isNe ? 'बैंक/FonePay' : 'Bank')}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                        {tx.inflow > 0 ? `+${formatCurrency(tx.inflow)}` : '-'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700">
                        {tx.outflow > 0 ? `-${formatCurrency(tx.outflow)}` : '-'}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono text-[11px] text-slate-500">
                        {tx.referenceNo || '-'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Grand Total Balance Summary Dock at the Bottom */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 border-t border-slate-800">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-emerald-400" />
                <h4 className="text-sm font-bold tracking-tight text-white">
                  {isNe ? `मिति ${selectedDateBs} को कुल मौज्दात सारांश` : `Daily Balance Summary for ${selectedDateBs}`}
                </h4>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {isNe
                  ? `जम्मा कारोबार: ${summary.totalCount} (नगद: ${summary.totalCashTxCount}, बैंक: ${summary.totalBankTxCount})`
                  : `Total ${summary.totalCount} transactions (${summary.totalCashTxCount} cash, ${summary.totalBankTxCount} bank)`}
              </p>
            </div>

            {/* Balances Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {/* Cash Net */}
              <div className="bg-slate-800/80 p-2.5 rounded-lg border border-slate-700">
                <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                  {isNe ? 'दिनको खुद नगद (Cash)' : 'Net Daily Cash'}
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-emerald-400">
                  {formatCurrency(summary.netCash)}
                </div>
                <div className="text-[10px] text-slate-500">
                  In: {formatCurrency(summary.totalCashIn)} | Out: {formatCurrency(summary.totalCashOut)}
                </div>
              </div>

              {/* Bank Net */}
              <div className="bg-slate-800/80 p-2.5 rounded-lg border border-slate-700">
                <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                  {isNe ? 'दिनको खुद बैंक (Bank)' : 'Net Daily Bank'}
                </div>
                <div className="mt-1 font-mono text-sm font-bold text-blue-400">
                  {formatCurrency(summary.netBank)}
                </div>
                <div className="text-[10px] text-slate-500">
                  In: {formatCurrency(summary.totalBankIn)} | Out: {formatCurrency(summary.totalBankOut)}
                </div>
              </div>

              {/* Combined Grand Net Daily Cashflow */}
              <div className="bg-emerald-950/70 p-2.5 rounded-lg border border-emerald-800 col-span-2 sm:col-span-1">
                <div className="text-[10px] text-emerald-300 uppercase font-bold tracking-wider">
                  {isNe ? 'दिनको कुल खुद बचत (Net Total)' : 'Combined Day Net'}
                </div>
                <div className="mt-1 font-mono text-base font-extrabold text-white">
                  {formatCurrency(summary.combinedNet)}
                </div>
                <div className="text-[10px] text-emerald-200">
                  {summary.combinedNet >= 0
                    ? isNe ? 'मुनाफा / बचत मौज्दात' : 'Positive Net Cashflow'
                    : isNe ? 'घाटा / अतिरिक्त भुक्तानी' : 'Negative Net Cashflow'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
