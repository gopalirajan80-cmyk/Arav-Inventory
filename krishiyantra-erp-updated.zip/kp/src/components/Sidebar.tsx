import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import {
  LayoutDashboard,
  Receipt,
  Boxes,
  BookOpenCheck,
  CalendarCheck2,
  FileSpreadsheet,
  Settings,
  Languages,
  Wifi,
  WifiOff,
  Wallet,
  TrendingUp,
  X,
  Users,
  Factory,
  ChevronDown,
  ChevronRight,
  ShieldAlert,
  Calendar,
  Truck,
  ClipboardList,
  ChevronsLeft,
  ChevronsRight,
  Calculator
} from 'lucide-react';
import { formatCurrency, getTodayBsString, formatBsDateNepaliText, getDateSyncMode } from '../utils/nepaliCalendar';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  /** Desktop only: icon-only narrow sidebar */
  collapsed?: boolean;
  onToggleCollapse?: () => void;
}

interface SubMenuItem {
  id: string;
  labelNe: string;
  labelEn: string;
  onSelect: () => void;
  isActive: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, collapsed = false, onToggleCollapse }) => {
  const {
    language,
    setLanguage,
    currentRole,
    setCurrentRole,
    activeTab,
    setActiveTab,
    isOnline,
    company,
    dailyCash,
    bankAccounts,
    parties,
    invoices,
    currentAccount,
    billingSubTab,
    setBillingSubTab,
    manufacturingSubTab,
    setManufacturingSubTab,
    voucherSubTab,
    setVoucherSubTab,
    ledgerSubTab,
    setLedgerSubTab,
    inventorySubTab,
    setInventorySubTab,
    reportSubTab,
    setReportSubTab,
    attendanceSubTab,
    setAttendanceSubTab,
    logisticsSubTab,
    setLogisticsSubTab,
    companiesList,
    activeCompanyId,
    switchCompany,
    fiscalYearsList,
    selectFiscalYear,
    addNewFiscalYear
  } = useApp();

  const isNe = language === 'ne';
  const todayBs = getTodayBsString();

  // Track which parent menus are expanded in the sidebar
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({
    billing: true,
    attendance: true,
    settings: true
  });

  const toggleExpandMenu = (menuId: string) => {
    setExpandedMenus((prev) => ({
      ...prev,
      [menuId]: !prev[menuId]
    }));
  };

  // Quick metrics for sidebar dashboard widget
  const todaySales = invoices
    .filter((i) => i.dateBs === todayBs && i.status === 'ACTIVE')
    .reduce((s, i) => s + i.grandTotal, 0);

  const totalBankBal = bankAccounts.reduce((s, b) => s + b.currentBalance, 0);

  const totalDues = parties.reduce(
    (s, p) => s + (p.currentBalance !== undefined ? p.currentBalance : p.openingBalance),
    0
  );

  const getSubMenuItems = (parentId: string): SubMenuItem[] => {
    if (parentId === 'billing') {
      return [
        {
          id: 'SALES',
          labelNe: 'बिक्री बिल (Sales / POS)',
          labelEn: 'Sales (POS Bill)',
          isActive: activeTab === 'billing' && billingSubTab === 'SALES',
          onSelect: () => {
            setActiveTab('billing');
            setBillingSubTab('SALES');
            onClose();
          }
        },
        {
          id: 'PURCHASE',
          labelNe: 'खरिद बिल (Purchase)',
          labelEn: 'Purchase Entry',
          isActive: activeTab === 'billing' && billingSubTab === 'PURCHASE',
          onSelect: () => {
            setActiveTab('billing');
            setBillingSubTab('PURCHASE');
            onClose();
          }
        },
        {
          id: 'PAYMENT_IN',
          labelNe: 'भुक्तानी प्राप्त (Payment In)',
          labelEn: 'Payment In (Receipt)',
          isActive: activeTab === 'billing' && billingSubTab === 'PAYMENT_IN',
          onSelect: () => {
            setActiveTab('billing');
            setBillingSubTab('PAYMENT_IN');
            onClose();
          }
        },
        {
          id: 'PAYMENT_OUT',
          labelNe: 'भुक्तानी (Payment Out)',
          labelEn: 'Payment Out (Voucher)',
          isActive: activeTab === 'billing' && billingSubTab === 'PAYMENT_OUT',
          onSelect: () => {
            setActiveTab('billing');
            setBillingSubTab('PAYMENT_OUT');
            onClose();
          }
        },
        {
          id: 'SALES_RETURN',
          labelNe: 'बिक्री फिर्ता (Sales Return)',
          labelEn: 'Sales Return (Credit Note)',
          isActive: activeTab === 'billing' && billingSubTab === 'SALES_RETURN',
          onSelect: () => {
            setActiveTab('billing');
            setBillingSubTab('SALES_RETURN');
            onClose();
          }
        },
        {
          id: 'PURCHASE_RETURN',
          labelNe: 'खरिद फिर्ता (Purchase Return)',
          labelEn: 'Purchase Return (Debit Note)',
          isActive: activeTab === 'billing' && billingSubTab === 'PURCHASE_RETURN',
          onSelect: () => {
            setActiveTab('billing');
            setBillingSubTab('PURCHASE_RETURN');
            onClose();
          }
        }
      ];
    }

    if (parentId === 'manufacturing') {
      return [
        {
          id: 'OVERVIEW',
          labelNe: 'उत्पादन सारांश (Overview)',
          labelEn: 'Production Overview',
          isActive: activeTab === 'manufacturing' && manufacturingSubTab === 'OVERVIEW',
          onSelect: () => {
            setActiveTab('manufacturing');
            setManufacturingSubTab('OVERVIEW');
            onClose();
          }
        },
        {
          id: 'PLANNING',
          labelNe: 'उत्पादन योजना तथा आदेश (Planning)',
          labelEn: 'Production Planning',
          isActive: activeTab === 'manufacturing' && manufacturingSubTab === 'PLANNING',
          onSelect: () => {
            setActiveTab('manufacturing');
            setManufacturingSubTab('PLANNING');
            onClose();
          }
        },
        {
          id: 'BOM',
          labelNe: 'उत्पादन सूत्र (BOM / Recipe)',
          labelEn: 'Bill of Materials',
          isActive: activeTab === 'manufacturing' && manufacturingSubTab === 'BOM',
          onSelect: () => {
            setActiveTab('manufacturing');
            setManufacturingSubTab('BOM');
            onClose();
          }
        },
        {
          id: 'RAW_MATERIALS',
          labelNe: 'कच्चा पदार्थ स्टक (Raw Materials)',
          labelEn: 'Raw Materials Stock',
          isActive: activeTab === 'manufacturing' && manufacturingSubTab === 'RAW_MATERIALS',
          onSelect: () => {
            setActiveTab('manufacturing');
            setManufacturingSubTab('RAW_MATERIALS');
            onClose();
          }
        },
        {
          id: 'WIP_MACHINE',
          labelNe: 'मेसिन उत्पादन (WIP Machine)',
          labelEn: 'Machine WIP Batches',
          isActive: activeTab === 'manufacturing' && manufacturingSubTab === 'WIP_MACHINE',
          onSelect: () => {
            setActiveTab('manufacturing');
            setManufacturingSubTab('WIP_MACHINE');
            onClose();
          }
        },
        {
          id: 'FINISHED_GOODS',
          labelNe: 'तयारी वस्तु (Finished Goods)',
          labelEn: 'Finished Goods (FG)',
          isActive: activeTab === 'manufacturing' && manufacturingSubTab === 'FINISHED_GOODS',
          onSelect: () => {
            setActiveTab('manufacturing');
            setManufacturingSubTab('FINISHED_GOODS');
            onClose();
          }
        },
        {
          id: 'PACKAGING',
          labelNe: 'प्याकिङ व्यवस्थापन (Packaging)',
          labelEn: 'Packaging Stage',
          isActive: activeTab === 'manufacturing' && manufacturingSubTab === 'PACKAGING',
          onSelect: () => {
            setActiveTab('manufacturing');
            setManufacturingSubTab('PACKAGING');
            onClose();
          }
        },
        {
          id: 'DISPATCHED',
          labelNe: 'बजार चलानी (Dispatched)',
          labelEn: 'Market Dispatch',
          isActive: activeTab === 'manufacturing' && manufacturingSubTab === 'DISPATCHED',
          onSelect: () => {
            setActiveTab('manufacturing');
            setManufacturingSubTab('DISPATCHED');
            onClose();
          }
        }
      ];
    }

    if (parentId === 'vouchers') {
      return [
        {
          id: 'COLLECTION',
          labelNe: 'भुक्तानी प्राप्त (Payment In)',
          labelEn: 'Customer Payment In',
          isActive: activeTab === 'vouchers' && voucherSubTab === 'COLLECTION',
          onSelect: () => {
            setActiveTab('vouchers');
            setVoucherSubTab('COLLECTION');
            onClose();
          }
        },
        {
          id: 'PAYMENT',
          labelNe: 'आपूर्तिकर्ता भुक्तानी (Payment Out)',
          labelEn: 'Supplier Payment Out',
          isActive: activeTab === 'vouchers' && voucherSubTab === 'PAYMENT',
          onSelect: () => {
            setActiveTab('vouchers');
            setVoucherSubTab('PAYMENT');
            onClose();
          }
        },
        {
          id: 'CUSTOMERS',
          labelNe: 'पार्टी दर्ता (Party Master)',
          labelEn: 'Customer & Supplier Master',
          isActive: activeTab === 'vouchers' && voucherSubTab === 'CUSTOMERS',
          onSelect: () => {
            setActiveTab('vouchers');
            setVoucherSubTab('CUSTOMERS');
            onClose();
          }
        }
      ];
    }

    if (parentId === 'ledger') {
      return [
        {
          id: 'ALL',
          labelNe: 'सबै पार्टी खाता (All Parties)',
          labelEn: 'All Parties Statement',
          isActive: activeTab === 'ledger' && ledgerSubTab === 'ALL',
          onSelect: () => {
            setActiveTab('ledger');
            setLedgerSubTab('ALL');
            onClose();
          }
        },
        {
          id: 'CUSTOMER',
          labelNe: 'ग्राहक उधारो खाता (Customers)',
          labelEn: 'Customer Receivables',
          isActive: activeTab === 'ledger' && ledgerSubTab === 'CUSTOMER',
          onSelect: () => {
            setActiveTab('ledger');
            setLedgerSubTab('CUSTOMER');
            onClose();
          }
        },
        {
          id: 'SUPPLIER',
          labelNe: 'आपूर्तिकर्ता खाता (Suppliers)',
          labelEn: 'Supplier Payables',
          isActive: activeTab === 'ledger' && ledgerSubTab === 'SUPPLIER',
          onSelect: () => {
            setActiveTab('ledger');
            setLedgerSubTab('SUPPLIER');
            onClose();
          }
        },
        {
          id: 'DUE_ONLY',
          labelNe: 'बक्यौता र ताकेता (Dues & Reminders)',
          labelEn: 'Pending Dues & Reminders',
          isActive: activeTab === 'ledger' && ledgerSubTab === 'DUE_ONLY',
          onSelect: () => {
            setActiveTab('ledger');
            setLedgerSubTab('DUE_ONLY');
            onClose();
          }
        },
        {
          id: 'ADD_PARTY',
          labelNe: '+ नयाँ पार्टी थप्नुहोस् (Add Party)',
          labelEn: '+ Add New Party',
          isActive: activeTab === 'ledger' && ledgerSubTab === 'ADD_PARTY',
          onSelect: () => {
            setActiveTab('ledger');
            setLedgerSubTab('ADD_PARTY');
            onClose();
          }
        }
      ];
    }

    if (parentId === 'inventory') {
      return [
        {
          id: 'ALL',
          labelNe: 'सबै सामान सूची (All Stock Items)',
          labelEn: 'All Inventory Items',
          isActive: activeTab === 'inventory' && inventorySubTab === 'ALL',
          onSelect: () => {
            setActiveTab('inventory');
            setInventorySubTab('ALL');
            onClose();
          }
        },
        {
          id: 'ADD_ITEM',
          labelNe: '+ नयाँ सामान थप्नुहोस् (Add Item)',
          labelEn: '+ Add New Stock Item',
          isActive: activeTab === 'inventory' && inventorySubTab === 'ADD_ITEM',
          onSelect: () => {
            setActiveTab('inventory');
            setInventorySubTab('ADD_ITEM');
            onClose();
          }
        },
        {
          id: 'RECONCILE',
          labelNe: 'भौतिक स्टक मिलान (Reconcile)',
          labelEn: 'Physical Stock Reconcile',
          isActive: activeTab === 'inventory' && inventorySubTab === 'RECONCILE',
          onSelect: () => {
            setActiveTab('inventory');
            setInventorySubTab('RECONCILE');
            onClose();
          }
        },
        {
          id: 'LOW_STOCK',
          labelNe: 'कम स्टक चेतावनी (Low Stock)',
          labelEn: 'Low Stock Alerts',
          isActive: activeTab === 'inventory' && inventorySubTab === 'LOW_STOCK',
          onSelect: () => {
            setActiveTab('inventory');
            setInventorySubTab('LOW_STOCK');
            onClose();
          }
        },
        {
          id: 'RAW_MATERIALS',
          labelNe: 'कच्चा पदार्थ (Raw Materials)',
          labelEn: 'Raw Materials Filter',
          isActive: activeTab === 'inventory' && inventorySubTab === 'RAW_MATERIALS',
          onSelect: () => {
            setActiveTab('inventory');
            setInventorySubTab('RAW_MATERIALS');
            onClose();
          }
        },
        {
          id: 'FINISHED_GOODS',
          labelNe: 'तयारी सामान (Finished Goods)',
          labelEn: 'Finished Goods Filter',
          isActive: activeTab === 'inventory' && inventorySubTab === 'FINISHED_GOODS',
          onSelect: () => {
            setActiveTab('inventory');
            setInventorySubTab('FINISHED_GOODS');
            onClose();
          }
        }
      ];
    }

    if (parentId === 'reports') {
      return [
        {
          id: 'ALL_HUB',
          labelNe: 'सबै १४ रिपोर्ट हब (All Reports)',
          labelEn: 'All 14 Reports Hub',
          isActive: activeTab === 'reports' && reportSubTab === '',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('');
            onClose();
          }
        },
        {
          id: 'SALES_REPORT',
          labelNe: 'बिक्री रिपोर्ट (Sales Report)',
          labelEn: 'Sales Report',
          isActive: activeTab === 'reports' && reportSubTab === 'SALES_REPORT',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('SALES_REPORT');
            onClose();
          }
        },
        {
          id: 'DAY_BOOK',
          labelNe: 'डे-बुक / दैनिक खाता (Day Book)',
          labelEn: 'Day Book Register',
          isActive: activeTab === 'reports' && reportSubTab === 'DAY_BOOK',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('DAY_BOOK');
            onClose();
          }
        },
        {
          id: 'ALL_TRANSACTIONS',
          labelNe: 'सबै कारोबार (All Transactions)',
          labelEn: 'All Transactions',
          isActive: activeTab === 'reports' && reportSubTab === 'ALL_TRANSACTIONS',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('ALL_TRANSACTIONS');
            onClose();
          }
        },
        {
          id: 'PROFIT_LOSS',
          labelNe: 'नाफा-नोक्सान (Profit & Loss)',
          labelEn: 'Profit & Loss (P&L)',
          isActive: activeTab === 'reports' && reportSubTab === 'PROFIT_LOSS',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('PROFIT_LOSS');
            onClose();
          }
        },
        {
          id: 'PARTY_STATEMENT',
          labelNe: 'पार्टी स्टेटमेन्ट (Party Statement)',
          labelEn: 'Party Statement',
          isActive: activeTab === 'reports' && reportSubTab === 'PARTY_STATEMENT',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('PARTY_STATEMENT');
            onClose();
          }
        },
        {
          id: 'CASH_IN_HAND',
          labelNe: 'काउन्टर नगद (Cash in Hand)',
          labelEn: 'Cash in Hand',
          isActive: activeTab === 'reports' && reportSubTab === 'CASH_IN_HAND',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('CASH_IN_HAND');
            onClose();
          }
        },
        {
          id: 'BANK_STATEMENT',
          labelNe: 'बैंक स्टेटमेन्ट (Bank Statement)',
          labelEn: 'Bank Statement',
          isActive: activeTab === 'reports' && reportSubTab === 'BANK_STATEMENT',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('BANK_STATEMENT');
            onClose();
          }
        },
        {
          id: 'STAFF_REPORT',
          labelNe: 'कर्मचारी तलब रिपोर्ट (Staff)',
          labelEn: 'Staff & Payroll Report',
          isActive: activeTab === 'reports' && reportSubTab === 'STAFF_REPORT',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('STAFF_REPORT');
            onClose();
          }
        },
        {
          id: 'BUSINESS_STATUS',
          labelNe: 'व्यापार अवस्था (Business Status)',
          labelEn: 'Business Status Summary',
          isActive: activeTab === 'reports' && reportSubTab === 'BUSINESS_STATUS',
          onSelect: () => {
            setActiveTab('reports');
            setReportSubTab('BUSINESS_STATUS');
            onClose();
          }
        }
      ];
    }

    if (parentId === 'logistics') {
      return [
        {
          id: 'DASHBOARD',
          labelNe: 'चलानी ड्यासबोर्ड (Overview)',
          labelEn: 'Logistics Dashboard',
          isActive: activeTab === 'logistics' && logisticsSubTab === 'DASHBOARD',
          onSelect: () => {
            setActiveTab('logistics');
            setLogisticsSubTab('DASHBOARD');
            onClose();
          }
        },
        {
          id: 'DISPATCH_LOG',
          labelNe: 'चलानी लग (Dispatch Log)',
          labelEn: 'Full Dispatch Log',
          isActive: activeTab === 'logistics' && logisticsSubTab === 'DISPATCH_LOG',
          onSelect: () => {
            setActiveTab('logistics');
            setLogisticsSubTab('DISPATCH_LOG');
            onClose();
          }
        },
        {
          id: 'PENDING_APPROVAL',
          labelNe: 'स्वीकृत हुन बाँकी (Approvals)',
          labelEn: 'Pending Approvals',
          isActive: activeTab === 'logistics' && logisticsSubTab === 'PENDING_APPROVAL',
          onSelect: () => {
            setActiveTab('logistics');
            setLogisticsSubTab('PENDING_APPROVAL');
            onClose();
          }
        }
      ];
    }

    if (parentId === 'attendance') {
      return [
        {
          id: 'DASHBOARD',
          labelNe: 'हाजिरी ड्यासबोर्ड (Overview)',
          labelEn: 'Attendance Dashboard',
          isActive: activeTab === 'attendance' && (!attendanceSubTab || attendanceSubTab === 'DASHBOARD'),
          onSelect: () => {
            setActiveTab('attendance');
            onClose();
          }
        },
        {
          id: 'ATT_MONTHLY_PRINT',
          labelNe: '१. 🖨️ महिनाभरिको हाजिरी सिट प्रिन्ट (Monthly Print)',
          labelEn: '1. Monthly Attendance Print Sheet',
          isActive: activeTab === 'attendance' && attendanceSubTab === 'PRINT',
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=attendance&sheet=1');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'attendance', openMonthlySheet: true }
              })
            );
            setActiveTab('attendance');
            onClose();
          }
        },
        {
          id: 'ATT_PAYROLL',
          labelNe: '२. 💰 दैनिक ज्याला र तलब खाता (Payroll & Advance)',
          labelEn: '2. Daily Wage & Payroll Ledger',
          isActive: activeTab === 'attendance' && attendanceSubTab === 'PAYROLL_LEDGER',
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=attendance&subTab=PAYROLL_LEDGER');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'attendance', subTab: 'PAYROLL_LEDGER' }
              })
            );
            setActiveTab('attendance');
            onClose();
          }
        },
        {
          id: 'ATT_REPORTS',
          labelNe: '३. 📊 हाजिरी र तलब रिपोर्टहरू (Reports)',
          labelEn: '3. Attendance & Payroll Reports',
          isActive: activeTab === 'attendance' && attendanceSubTab === 'REPORTS',
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=attendance&subTab=REPORTS');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'attendance', subTab: 'REPORTS' }
              })
            );
            setActiveTab('attendance');
            onClose();
          }
        },
        {
          id: 'ATT_MASTER_SETTINGS',
          labelNe: '४. ⚙️ काम, साइट र हाजिरी मास्टर सेटिङ',
          labelEn: '4. Work, Site & GPS Master Settings',
          isActive: false,
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=work_attendance');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'WORK_ATTENDANCE' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        }
      ];
    }

    if (parentId === 'settings') {
      return [
        {
          id: 'SET_WORK_ATTENDANCE',
          labelNe: '१. 👷 काम, हाजिरी र साइट सेटिङ (Work & Attendance)',
          labelEn: '1. Work, Site & Attendance Master',
          isActive: activeTab === 'settings',
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=work_attendance');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'WORK_ATTENDANCE' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        },
        {
          id: 'SET_INVOICE_PURCHASE_SALE',
          labelNe: '२. 🧾 खरिद, बिक्री र बिलिङ सेटिङ (Purchase/Sale)',
          labelEn: '2. Purchase, Sales & Invoice Setup',
          isActive: false,
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=invoice');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'INVOICE' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        },
        {
          id: 'SET_COMPANY',
          labelNe: '३. 🏢 फर्म तथा कम्पनी विवरण (Company Profile)',
          labelEn: '3. Company Profile',
          isActive: false,
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=company');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'COMPANY' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        },
        {
          id: 'SET_CUSTOMERS',
          labelNe: '४. 👥 ग्राहक र पार्टी ठेगाना सच्याउने (Customer Master)',
          labelEn: '4. Customer & Party Master',
          isActive: false,
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=customers');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'CUSTOMERS' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        },
        {
          id: 'SET_ROLES',
          labelNe: '५. 🛡️ मालिक र स्टाफ रोल अनुमति (Roles & Security)',
          labelEn: '5. Roles & Security',
          isActive: false,
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=roles');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'ROLES' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        },
        {
          id: 'SET_BANKS',
          labelNe: '६. 🏦 बैंक खाता र QR सेटिङ (Bank Accounts)',
          labelEn: '6. Bank Accounts & QR',
          isActive: false,
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=banks');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'BANKS' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        },
        {
          id: 'SET_CATEGORIES',
          labelNe: '७. 📦 सामान क्याटगोरी सेटिङ (Item Categories)',
          labelEn: '7. Item Categories',
          isActive: false,
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=categories');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'CATEGORIES' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        },
        {
          id: 'SET_FISCAL_YEAR',
          labelNe: '८. 📅 आर्थिक वर्ष बन्द (Fiscal Year Close)',
          labelEn: '8. Fiscal Year Close',
          isActive: false,
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=fiscal_year');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'FISCAL_YEAR' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        },
        {
          id: 'SET_BACKUP',
          labelNe: '९. 💾 डाटा ब्याकअप र रिस्टोर (Backup & Restore)',
          labelEn: '9. Backup & Restore',
          isActive: false,
          onSelect: () => {
            window.history.replaceState(null, '', '/?tab=settings&sub=backup');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'settings', settingsTab: 'BACKUP' }
              })
            );
            setActiveTab('settings');
            onClose();
          }
        }
      ];
    }

    if (parentId === 'audit_report') {
      return [
        {
          id: 'AUDIT_BOTH',
          labelNe: '१. एकीकृत दृश्य (NFRS + Audit Trail)',
          labelEn: '1. Combined NFRS & Audit Trail',
          isActive: activeTab === 'audit_report',
          onSelect: () => {
            setActiveTab('audit_report');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'audit_report', auditSubTab: 'BOTH' }
              })
            );
            onClose();
          }
        },
        {
          id: 'AUDIT_NFRS',
          labelNe: '२. एनएफआरएस वित्तीय विवरण (NFRS Statements)',
          labelEn: '2. NFRS Financial Statements',
          isActive: false,
          onSelect: () => {
            setActiveTab('audit_report');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'audit_report', auditSubTab: 'NFRS_REPORT' }
              })
            );
            onClose();
          }
        },
        {
          id: 'AUDIT_TRAIL_SUB',
          labelNe: '३. अडिट ट्रेल लग (Audit Trail Logs)',
          labelEn: '3. Audit Trail Security Logs',
          isActive: activeTab === 'audit_trail',
          onSelect: () => {
            setActiveTab('audit_report');
            window.dispatchEvent(
              new CustomEvent('ims-sub-nav', {
                detail: { target: 'audit_report', auditSubTab: 'AUDIT_TRAIL' }
              })
            );
            onClose();
          }
        }
      ];
    }

    return [];
  };

  const navLinks = [
    {
      id: 'dashboard',
      labelNe: 'ड्यासबोर्ड',
      labelEn: 'Dashboard',
      icon: LayoutDashboard
    },
    {
      id: 'billing',
      labelNe: 'खरिद / बिक्री तथा बिलिङ (POS)',
      labelEn: 'Purchase, Sales & POS',
      icon: Receipt,
      badge: '6'
    },
    {
      id: 'field_orders',
      labelNe: 'फिल्ड अर्डर तथा कोटेशन',
      labelEn: 'Field Orders & Quotations',
      icon: ClipboardList,
      badge: 'NEW'
    },
    {
      id: 'manufacturing',
      labelNe: 'उत्पादन तथा म्यानुफ्याक्चरिङ',
      labelEn: 'Manufacturing System',
      icon: Factory,
      badge: isNe ? 'मेसिन' : 'WIP'
    },
    {
      id: 'vouchers',
      labelNe: 'रकम असुली तथा भुक्तानी',
      labelEn: 'Dues & Vouchers',
      icon: Wallet
    },
    {
      id: 'ledger',
      labelNe: 'पार्टी लेजर खाता (Ledger)',
      labelEn: 'Party Ledger',
      icon: Users,
      badge: isNe ? 'खाता' : 'Ledger'
    },
    {
      id: 'inventory',
      labelNe: 'इन्भेन्टरी तथा स्टक',
      labelEn: 'Inventory & Stock',
      icon: Boxes
    },
    {
      id: 'reports',
      labelNe: 'विभिन्न रिपोर्टहरू (Reports)',
      labelEn: 'Reports Hub',
      icon: FileSpreadsheet,
      badge: '14'
    },
    {
      id: 'audit_report',
      labelNe: 'अडिट रिपोर्ट र ट्रेल (NFRS & Audit Trail)',
      labelEn: 'Audit Report & Trail',
      icon: ShieldAlert,
      badge: 'NFRS'
    },
    {
      id: 'vat_books',
      labelNe: 'भ्याट खाता (अनुसूची ५ र ८)',
      labelEn: 'VAT Registers',
      icon: BookOpenCheck
    },
    {
      id: 'stock_costing',
      labelNe: 'स्टक मूल्याङ्कन तथा पुनःक्रम',
      labelEn: 'Stock Valuation & Reorder',
      icon: Boxes,
      badge: 'NEW'
    },
    {
      id: 'accounting',
      labelNe: 'लेखा तथा वित्त (Accounting)',
      labelEn: 'Accounting & Finance',
      icon: Calculator,
      badge: 'NEW'
    },
    {
      id: 'logistics',
      labelNe: 'ढुवानी तथा चलानी (Logistics)',
      labelEn: 'Driver & Dispatch',
      icon: Truck,
      badge: 'NEW'
    },
    {
      id: 'attendance',
      labelNe: 'कर्मचारी तथा काम हाजिरी',
      labelEn: 'Staff & Work Attendance',
      icon: CalendarCheck2,
      badge: '9'
    },
    {
      id: 'excel_wizard',
      labelNe: 'Excel आयात तथा ब्याकअप',
      labelEn: 'Excel Wizard',
      icon: FileSpreadsheet
    },
    {
      id: 'settings',
      labelNe: 'मास्टर सेटिङ (Master Settings)',
      labelEn: 'Master Settings',
      icon: Settings,
      badge: '9'
    }
  ];

  const filteredNavLinks = navLinks.filter((link) => {
    return useApp().checkPermission(link.id);
  });

  // Logical menu groups (order = order shown in the sidebar)
  const NAV_GROUPS: { key: string; ne: string; en: string; ids: string[] }[] = [
    { key: 'main', ne: 'मुख्य', en: 'Main', ids: ['dashboard'] },
    { key: 'inventory', ne: '📦 स्टक', en: '📦 Inventory', ids: ['inventory', 'stock_costing'] },
    { key: 'transactions', ne: '🛒 कारोबार', en: '🛒 Transactions', ids: ['billing', 'field_orders', 'vouchers', 'ledger'] },
    { key: 'accounts', ne: '📒 लेखा', en: '📒 Accounting', ids: ['accounting'] },
    { key: 'manufacturing', ne: '🏭 उत्पादन', en: '🏭 Manufacturing', ids: ['manufacturing', 'logistics'] },
    { key: 'hr', ne: '👥 कर्मचारी', en: '👥 HR & Payroll', ids: ['attendance'] },
    { key: 'reports', ne: '📈 रिपोर्ट', en: '📈 Reports', ids: ['reports', 'audit_report', 'vat_books', 'excel_wizard'] },
    { key: 'settings', ne: '⚙️ सेटिङ', en: '⚙️ Settings', ids: ['settings'] }
  ];
  const groupedNav = NAV_GROUPS.map((g) => ({
    ...g,
    links: g.ids.map((id) => filteredNavLinks.find((l) => l.id === id)).filter(Boolean) as typeof filteredNavLinks
  }));
  // any link not mapped above still shows up (safety net)
  const mappedIds = new Set(NAV_GROUPS.flatMap((g) => g.ids));
  const orphanLinks = filteredNavLinks.filter((l) => !mappedIds.has(l.id));
  if (orphanLinks.length) groupedNav.push({ key: 'other', ne: 'अन्य', en: 'Other', ids: [], links: orphanLinks });

  const handleParentNavClick = (tabId: string, hasSubItems: boolean) => {
    if (hasSubItems) {
      setExpandedMenus((prev) => ({
        ...prev,
        [tabId]: !prev[tabId]
      }));
    } else {
      setActiveTab(tabId);
      onClose();
    }
  };

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden transition-opacity"
        />
      )}

      {/* Main Sidebar Container (Left Side) */}
      <aside
        data-collapsed={collapsed ? 'true' : 'false'}
        className={`group/side no-print fixed top-0 bottom-0 left-0 z-50 w-72 ${
          collapsed ? 'lg:w-20' : ''
        } ky-side text-slate-100 flex flex-col border-r transition-all duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header & Multi-Company Switcher */}
        <div className="p-4 border-b border-slate-800/80 space-y-2.5 shrink-0">
          <div className="flex items-center justify-between gap-2">
            <div
              onClick={() => handleParentNavClick('dashboard', false)}
              className="flex items-center gap-2.5 cursor-pointer select-none group min-w-0"
            >
              {company.logoUrl ? (
                <img
                  src={company.logoUrl}
                  alt={company.name}
                  className="w-10 h-10 rounded-xl object-contain bg-white p-0.5 shadow-md shrink-0"
                />
              ) : (
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center text-white font-black text-lg shadow-md group-hover:scale-105 transition-transform shrink-0">
                  {(company.name || 'कृ').charAt(0)}
                </div>
              )}
              <div className="min-w-0 lg:group-data-[collapsed=true]/side:hidden">
                <div className="font-bold text-sm tracking-tight text-white truncate" title={company.name}>
                  {company.name || (isNe ? 'कृषियन्त्र ERP' : 'KrishiYantra ERP')}
                </div>
                <div className="text-[10px] font-medium text-emerald-400 tracking-wide truncate">
                  {company.panVatNo ? `PAN/VAT: ${company.panVatNo}` : (isNe ? 'नेपाल भ्याट तथा इन्भेन्टरी प्रणाली' : 'Nepal VAT & Inventory ERP')}
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Multi-Company Switcher & Quick Rename/Add Bar */}
          <div className="flex items-center gap-1.5 lg:group-data-[collapsed=true]/side:hidden">
            <select
              value={activeCompanyId}
              onChange={(e) => {
                if (e.target.value === '__ADD_NEW_COMPANY__') {
                  setActiveTab('settings');
                  setTimeout(() => {
                    window.dispatchEvent(
                      new CustomEvent('ims-sub-nav', {
                        detail: { target: 'settings', settingsTab: 'COMPANY' }
                      })
                    );
                  }, 40);
                  onClose();
                  return;
                }
                switchCompany(e.target.value);
              }}
              className="flex-1 min-w-0 bg-slate-800/90 hover:bg-slate-800 border border-slate-700 text-slate-100 rounded-lg px-2 py-1.5 text-[11px] font-bold truncate cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-500"
              title={isNe ? 'कम्पनी छान्नुहोस् वा नयाँ कम्पनी थप्नुहोस्' : 'Switch or Add Company'}
            >
              {companiesList.map((c, idx) => (
                <option key={c.id} value={c.id}>
                  🏢 {idx + 1}. {c.id === activeCompanyId ? company.name : c.name}
                </option>
              ))}
              <option value="__ADD_NEW_COMPANY__">
                ➕ नयाँ छुट्टै कम्पनी थप्नुहोस् (Add New Company)...
              </option>
            </select>
            <button
              type="button"
              onClick={() => {
                setActiveTab('settings');
                setTimeout(() => {
                  window.dispatchEvent(
                    new CustomEvent('ims-sub-nav', {
                      detail: { target: 'settings', settingsTab: 'COMPANY' }
                    })
                  );
                }, 40);
                onClose();
              }}
              className="px-2 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-[10px] font-bold shrink-0 cursor-pointer transition"
              title={isNe ? 'कम्पनी नाम फेर्ने वा नयाँ कम्पनी थप्ने' : 'Rename or Add Company'}
            >
              + कम्पनी थप्ने
            </button>
          </div>
        </div>

        {/* Scrollable Navigation & Left Dashboard Mini-Cards */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-4 text-xs">
          
          {/* Quick Left-Side Dashboard Summary Widget (dashboard ma aafai cards chhan, tesaile lukaeko) */}
          <div className={`bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/60 space-y-2.5 lg:group-data-[collapsed=true]/side:hidden ${activeTab === 'dashboard' ? 'hidden' : ''}`}>
            <div className="flex items-center justify-between text-slate-400 text-[11px] font-semibold uppercase tracking-wider">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>{isNe ? 'ड्यासबोर्ड स्थिति' : 'Dashboard Status'}</span>
              </span>
              <span className="font-mono text-[10px] text-slate-400">{todayBs}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="bg-slate-900/70 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-400 text-[10px] block truncate">{isNe ? 'आजको बिक्री' : "Today's Sales"}</span>
                <span className="font-mono font-bold text-emerald-400 truncate block">
                  {formatCurrency(todaySales, isNe)}
                </span>
              </div>

              <div className="bg-slate-900/70 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-400 text-[10px] block truncate">{isNe ? 'काउन्टर नगद' : 'Cash in Hand'}</span>
                <span className="font-mono font-bold text-slate-200 truncate block">
                  {formatCurrency(dailyCash.closingCashInHand, isNe)}
                </span>
              </div>

              <div className="bg-slate-900/70 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-400 text-[10px] block truncate">{isNe ? 'बैंक मौज्दात' : 'Bank Balance'}</span>
                <span className="font-mono font-bold text-blue-400 truncate block">
                  {formatCurrency(totalBankBal, isNe)}
                </span>
              </div>

              <div className="bg-slate-900/70 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-400 text-[10px] block truncate">{isNe ? 'लिन बाँकी' : 'Customer Dues'}</span>
                <span className="font-mono font-bold text-rose-400 truncate block">
                  {formatCurrency(totalDues, isNe)}
                </span>
              </div>
            </div>

            <div className="pt-1 flex gap-2">
              <button
                onClick={() => {
                  setActiveTab('billing');
                  setBillingSubTab('SALES');
                  onClose();
                }}
                className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-[11px] transition text-center shadow-xs cursor-pointer"
              >
                + {isNe ? 'नयाँ बिल' : 'New Bill'}
              </button>
              <button
                onClick={() => {
                  setActiveTab('billing');
                  setBillingSubTab('PAYMENT_IN');
                  onClose();
                }}
                className="flex-1 py-1.5 px-2 bg-slate-700 hover:bg-slate-600 text-slate-200 font-semibold rounded-lg text-[11px] transition text-center cursor-pointer"
              >
                {isNe ? 'रकम असुली' : 'Collect'}
              </button>
            </div>
          </div>

          {/* Desktop-only collapse / expand toggle */}
          {onToggleCollapse && (
            <button
              type="button"
              onClick={onToggleCollapse}
              title={collapsed ? (isNe ? 'मेनु फराकिलो बनाउनुहोस्' : 'Expand sidebar') : (isNe ? 'मेनु सानो बनाउनुहोस्' : 'Collapse sidebar')}
              className="hidden lg:flex w-full items-center justify-center gap-2 py-1.5 rounded-lg text-[11px] font-semibold text-slate-400 hover:text-white hover:bg-slate-800/80 transition cursor-pointer"
            >
              {collapsed ? <ChevronsRight className="w-4 h-4" /> : <><ChevronsLeft className="w-4 h-4" /><span>{isNe ? 'मेनु सानो गर्नुहोस्' : 'Collapse menu'}</span></>}
            </button>
          )}

          {/* Grouped navigation with expandable sub-menus */}
          <div className="space-y-3">
            {groupedNav.filter((g) => g.links.length > 0).map((group) => (
              <div key={group.key} className="space-y-1">
                {group.key !== 'main' && (
                  <span className="lg:group-data-[collapsed=true]/side:hidden px-2 pt-1 text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                    {isNe ? group.ne : group.en}
                  </span>
                )}
                {group.key !== 'main' && (
                  <div className="hidden lg:group-data-[collapsed=true]/side:block mx-3 border-t border-slate-800" />
                )}

                {group.links.map((link) => {
                  const Icon = link.icon;
                  const isActive = activeTab === link.id;
                  const subItems = getSubMenuItems(link.id);
                  const hasSubItems = subItems.length > 0;
                  const isExpanded = !!expandedMenus[link.id];

                  return (
                    <div key={link.id} className="space-y-1">
                      <button
                        onClick={() => handleParentNavClick(link.id, hasSubItems)}
                        title={isNe ? link.labelNe : link.labelEn}
                        className={`w-full flex items-center justify-between lg:group-data-[collapsed=true]/side:justify-center px-3 py-2.5 rounded-xl font-medium transition cursor-pointer text-left ${
                          isActive
                            ? 'bg-emerald-600 text-white font-bold shadow-xs'
                            : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                          <span className="lg:group-data-[collapsed=true]/side:hidden truncate">{isNe ? link.labelNe : link.labelEn}</span>
                        </div>

                        <div className="lg:group-data-[collapsed=true]/side:hidden flex items-center gap-1.5 shrink-0 ml-1.5">
                          {link.badge && (
                            <span
                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${
                                isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400 border border-slate-700'
                              }`}
                            >
                              {link.badge}
                            </span>
                          )}
                          {hasSubItems && (
                            <span
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleExpandMenu(link.id);
                              }}
                              className="p-0.5 rounded hover:bg-white/10"
                            >
                              {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                            </span>
                          )}
                        </div>
                      </button>

                      {/* Sub-menu items (hidden while the sidebar is collapsed) */}
                      {hasSubItems && isExpanded && (
                        <div className="lg:group-data-[collapsed=true]/side:hidden ml-4 pl-3 border-l-2 border-emerald-500/40 space-y-1 py-1 animate-fadeIn">
                          {subItems.map((sub) => (
                            <button
                              key={sub.id}
                              type="button"
                              onClick={sub.onSelect}
                              className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-[11px] transition cursor-pointer text-left ${
                                sub.isActive
                                  ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40'
                                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
                              }`}
                            >
                              <span className="truncate">• {isNe ? sub.labelNe : sub.labelEn}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

        </div>

        {/* Sidebar Footer: Role, Language & Version */}
        <div className="p-3.5 border-t border-slate-800/80 bg-slate-950/60 space-y-2.5 shrink-0 text-xs lg:group-data-[collapsed=true]/side:hidden">
          <div className="flex items-center justify-between gap-2">
            {/* Logged-in User Profile & Single Active Post Badge */}
            <div className="flex-1 min-w-0 bg-slate-900/90 border border-slate-800 rounded-lg px-2.5 py-1.5 flex items-center justify-between gap-1.5">
              <div className="min-w-0 flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-[10px] shrink-0">
                  {(currentAccount?.ownerName || 'R').charAt(0).toUpperCase()}
                </div>
                <div className="min-w-0 leading-tight">
                  <div className="text-[11px] font-bold text-slate-100 truncate">
                    {currentAccount?.ownerName || (isNe ? 'राजन गोपाली' : 'Rajan Gopali')}
                  </div>
                  <div className="text-[10px] text-emerald-400 font-medium truncate">
                    {currentRole === 'OWNER'
                      ? isNe ? 'मालिक / प्रशासक' : 'Owner'
                      : currentRole === 'ACCOUNTANT'
                      ? isNe ? 'लेखापाल (Accountant)' : 'Accountant'
                      : currentRole === 'COUNTER_SALES'
                      ? isNe ? 'काउन्टर / बिलिङ' : 'Counter Sales'
                      : currentRole === 'SALESMAN'
                      ? isNe ? 'सेल्सम्यान' : 'Salesman'
                      : currentRole === 'SUPERVISOR'
                      ? isNe ? 'सुपरभाइजर' : 'Supervisor'
                      : isNe ? 'कर्मचारी (Staff)' : 'Staff'}
                  </div>
                </div>
              </div>
            </div>

            {/* Language Toggle */}
            <button
              onClick={() => setLanguage(language === 'ne' ? 'en' : 'ne')}
              className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-[11px] font-medium transition cursor-pointer shrink-0"
              title="नेपाली / English"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isNe ? 'English' : 'नेपाली'}</span>
            </button>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-800/60">
            <div className="flex items-center gap-1.5">
              {isOnline ? (
                <span className="flex items-center gap-1 text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Online</span>
                </span>
              ) : (
                <span className="flex items-center gap-1 text-amber-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  <span>Offline</span>
                </span>
              )}
            </div>
            <span className="font-mono text-[10px] text-slate-500">v1.2 (आ.व. {company.fiscalYear || '081/82'})</span>
          </div>
        </div>

      </aside>
    </>
  );
};
