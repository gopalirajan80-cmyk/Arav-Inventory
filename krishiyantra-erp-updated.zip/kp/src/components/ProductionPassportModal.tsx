import { printPage } from '../utils/printHelper';
import React, { useRef } from 'react';
import { ProductionBatch } from '../types';
import { useApp } from '../context/AppContext';
import {
  X,
  Printer,
  ShieldCheck,
  Package,
  Calendar,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Scale,
  DollarSign,
  Cpu,
  Boxes,
  FileText
} from 'lucide-react';
import {
  formatCurrency,
  toNepaliDigits
} from '../utils/nepaliCalendar';

interface ProductionPassportModalProps {
  batch: ProductionBatch | null;
  onClose: () => void;
}

export const ProductionPassportModal: React.FC<ProductionPassportModalProps> = ({
  batch,
  onClose
}) => {
  const { company, language } = useApp();
  const isNe = language === 'ne';
  const printRef = useRef<HTMLDivElement>(null);

  if (!batch) return null;

  const handlePrint = () => {
    printPage();
  };

  const getStageBadge = (stage: string) => {
    switch (stage) {
      case 'IN_MACHINE_WIP':
        return { label: '⚙️ मेसिनमा रहेको (WIP)', color: 'bg-purple-100 text-purple-900 border-purple-300' };
      case 'FINISHED_GOODS':
        return { label: '✓ तयारी सामान (Finished Goods)', color: 'bg-blue-100 text-blue-900 border-blue-300' };
      case 'PACKAGING':
        return { label: '📦 प्याकिङ शाखा (Packaging)', color: 'bg-amber-100 text-amber-900 border-amber-300' };
      case 'DISPATCHED_MARKET':
        return { label: '🚚 बजारमा पठाइएको (Dispatched)', color: 'bg-indigo-100 text-indigo-900 border-indigo-300' };
      default:
        return { label: stage, color: 'bg-slate-100 text-slate-800 border-slate-300' };
    }
  };

  const stageInfo = getStageBadge(batch.stage);
  const totalInputQty = batch.inputQuantity || batch.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed, 0);
  const totalOutputQty = batch.outputQuantity || batch.finishedGoodsQuantity || batch.targetQuantity || 0;
  const yieldPct = typeof batch.yieldPercent === 'number'
    ? batch.yieldPercent
    : totalInputQty > 0
    ? Math.round((totalOutputQty / totalInputQty) * 1000) / 10
    : 100;
  const wastagePct = typeof batch.wastagePercent === 'number'
    ? batch.wastagePercent
    : Math.max(0, 100 - yieldPct);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto print:p-0 print:bg-white">
      <div data-print-target className="w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col print:max-w-none print:shadow-none print:border-none print:rounded-none">
        
        {/* Top Action Bar (hidden when printing) */}
        <div className="px-5 py-4 border-b border-slate-800 bg-slate-900 text-white flex items-center justify-between shrink-0 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-purple-500/20 text-purple-400 rounded-xl border border-purple-500/30">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold flex items-center gap-2">
                <span>उत्पादन ब्याच पासपोर्ट तथा गुणस्तर प्रमाणपत्र</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-purple-400/20 text-purple-300 font-black">
                  {batch.batchNumber}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                खाद्य सुरक्षा, कच्चा पदार्थ ट्र्याकिङ, ह्रास प्रतिशत र प्रति एकाइ उत्पादन लागत
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>प्रिन्ट / लेबल प्रिन्ट</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Certificate & Batch Details */}
        <div ref={printRef} className="p-6 space-y-6 overflow-y-auto text-xs bg-white font-sans">
          
          {/* Header */}
          <div className="text-center border-b pb-4 border-slate-200">
            <h1 className="text-xl font-black text-slate-900">
              {company.name || 'कृषियन्त्र एग्रो तथा मेशिनरी उद्योग प्रा.लि.'}
            </h1>
            <p className="text-xs text-slate-600 mt-0.5">
              {company.address || 'भरतपुर-१०, चितवन, नेपाल'} | फोन: {company.phone || '०५६-५२१४८०'} | प्यान/भ्याट नं: {company.panVatNo || '६०१२३४५६७'}
            </p>
            <div className="inline-block mt-2 px-3 py-1 bg-slate-900 text-white rounded-full font-mono text-[11px] font-bold tracking-wider uppercase">
              उत्पादन ब्याच पासपोर्ट (Batch Production & Quality Passport)
            </div>
          </div>

          {/* Identity Card */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <div>
              <span className="text-[10px] text-slate-500 font-bold block uppercase">ब्याच नम्बर (Batch No)</span>
              <span className="font-mono text-sm font-black text-purple-900">{batch.batchNumber}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 font-bold block uppercase">उत्पादन मिति (Date BS)</span>
              <span className="font-mono text-xs font-bold text-slate-800">
                {batch.productionDateBs || batch.startedDateBs}
                {batch.productionDateAd ? ` (${batch.productionDateAd})` : ''}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 font-bold block uppercase">हालको चरण (Stage)</span>
              <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold border mt-0.5 ${stageInfo.color}`}>
                {stageInfo.label}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 font-bold block uppercase">गुणस्तर स्थिति (QC)</span>
              <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold mt-0.5 ${
                batch.qualityCheckStatus === 'PASS'
                  ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                  : batch.qualityCheckStatus === 'PENDING'
                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                  : 'bg-red-100 text-red-900 border border-red-300'
              }`}>
                {batch.qualityCheckStatus === 'PASS' ? '✓ गुणस्तर पास (PASS)' : batch.qualityCheckStatus === 'PENDING' ? '⏳ परीक्षणमा (PENDING)' : '✕ अस्वीकृत (FAIL)'}
              </span>
            </div>
          </div>

          {/* Product and Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-purple-50/60 border border-purple-200 rounded-2xl">
              <span className="text-[10px] text-purple-700 font-bold uppercase">उत्पादित सामान (Product)</span>
              <h2 className="text-base font-black text-slate-900 mt-1">{batch.productNameNe}</h2>
              {batch.productNameEn && <p className="text-xs text-slate-500 italic font-mono">{batch.productNameEn}</p>}
              <div className="mt-2 text-xs flex gap-3 text-slate-700">
                <span>प्याकेट साइज: <b>{batch.packetSize || '-'}</b></span>
                <span>प्याकेट सङ्ख्या: <b>{batch.packetsProduced || '-'}</b></span>
              </div>
            </div>

            <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-2xl space-y-2">
              <span className="text-[10px] text-emerald-800 font-bold uppercase">खाद्य सुरक्षा मिति विवरण (Food Safety)</span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 block">उत्पादन मिति (Mfg Date):</span>
                  <span className="font-mono font-bold text-slate-900">{batch.manufactureDateBs || batch.productionDateBs || batch.startedDateBs}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">म्याद सकिने मिति (Exp Date):</span>
                  <span className="font-mono font-bold text-amber-900">{batch.expiryDateBs || '२०८२-११-०१'}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">निरीक्षक (Inspector):</span>
                  <span className="font-medium text-slate-900">{batch.qualityCheckedBy || 'सुरेश खनाल'}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">मेसिन / अपरेटर:</span>
                  <span className="font-medium text-slate-900">{batch.operatorName || '-'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Raw Materials Consumed (BOM Breakdown) */}
          <div>
            <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-1.5 text-xs">
              <Boxes className="w-4 h-4 text-emerald-700" />
              <span>प्रयोग भएको कच्चा पदार्थ अनुपात (Raw Materials Recipe / BOM Used)</span>
            </h4>
            <table className="w-full text-xs text-left border border-slate-200 rounded-xl overflow-hidden">
              <thead className="bg-slate-100 font-bold uppercase text-[10px] text-slate-700">
                <tr>
                  <th className="py-2 px-3">क्र.सं.</th>
                  <th className="py-2 px-3">कच्चा पदार्थको नाम</th>
                  <th className="py-2 px-3 text-right">प्रयोग परिमाण</th>
                  <th className="py-2 px-3">इकाइ</th>
                  <th className="py-2 px-3 text-right">प्रति एकाइ लागत (Rs)</th>
                  <th className="py-2 px-3 text-right">जम्मा रकम (Rs)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {batch.rawMaterialsUsed.map((rm, idx) => {
                  const lineTotal = rm.quantityUsed * rm.costPerUnit;
                  return (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-mono">{idx + 1}</td>
                      <td className="py-2 px-3 font-bold text-slate-900">{rm.materialName}</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-800">
                        {toNepaliDigits(rm.quantityUsed)}
                      </td>
                      <td className="py-2 px-3 text-slate-500">{rm.unit}</td>
                      <td className="py-2 px-3 text-right font-mono">रु. {rm.costPerUnit.toLocaleString()}</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-emerald-800">
                        रु. {lineTotal.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-slate-900 text-white font-bold">
                <tr>
                  <td colSpan={2} className="py-2 px-3">कुल इनपुट तौल (Input Weight):</td>
                  <td className="py-2 px-3 text-right font-mono text-amber-300 font-black">
                    {toNepaliDigits(totalInputQty)} {batch.inputUnit || 'Kg'}
                  </td>
                  <td colSpan={2} className="py-2 px-3 text-right">कुल कच्चा पदार्थ लागत:</td>
                  <td className="py-2 px-3 text-right font-mono text-emerald-300 font-black">
                    रु. {(batch.rawMaterialCost || batch.rawMaterialsUsed.reduce((s, r) => s + r.quantityUsed * r.costPerUnit, 0)).toLocaleString()}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Yield & Wastage / Moisture Loss Breakdown */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] text-slate-500 block font-bold">कुल इनपुट (Input Qty)</span>
              <span className="text-base font-black font-mono text-slate-900">
                {toNepaliDigits(totalInputQty)} {batch.inputUnit || 'Kg'}
              </span>
            </div>

            <div className="p-3 bg-blue-50 rounded-xl border border-blue-200">
              <span className="text-[10px] text-blue-700 block font-bold">तयारी आउटपुट (Output Qty)</span>
              <span className="text-base font-black font-mono text-blue-900">
                {toNepaliDigits(totalOutputQty)} {batch.outputUnit || 'Kg'}
              </span>
            </div>

            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
              <span className="text-[10px] text-emerald-700 block font-bold">प्राप्ति प्रतिशत (Yield %)</span>
              <span className="text-base font-black font-mono text-emerald-900">
                {toNepaliDigits(yieldPct)}%
              </span>
            </div>

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
              <span className="text-[10px] text-amber-700 block font-bold">तौल ह्रास / वेस्टेज (Loss %)</span>
              <span className="text-base font-black font-mono text-amber-900">
                {toNepaliDigits(wastagePct)}%
              </span>
            </div>
          </div>

          {/* Financial Breakdown Table */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-1.5 text-xs">
              <DollarSign className="w-4 h-4 text-emerald-700" />
              <span>उत्पादन लागत विश्लेषण (Cost Calculation & Allocation)</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 block">कच्चा पदार्थ लागत:</span>
                <span className="font-mono font-bold text-slate-900">
                  रु. {(batch.rawMaterialCost || 0).toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">ज्याला तथा पारिश्रमिक:</span>
                <span className="font-mono font-bold text-slate-900">
                  रु. {(batch.laborCost || 0).toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">विजुली तथा ओभरहेड:</span>
                <span className="font-mono font-bold text-slate-900">
                  रु. {((batch.electricityCost || 0) + (batch.otherOverheadCost || 0)).toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-emerald-700 block font-bold">कुल ब्याच लागत:</span>
                <span className="font-mono font-black text-emerald-900 text-sm">
                  रु. {(batch.totalProductionCost || 0).toLocaleString()}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3 pt-3 border-t border-slate-200">
              <div className="p-2.5 bg-white rounded-xl border border-slate-200 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">प्रति एकाइ उत्पादन लागत (Per Unit Cost):</span>
                <span className="font-mono font-black text-purple-900 text-sm">
                  रु. {(batch.unitManufacturingCost || 0).toLocaleString()} / {batch.outputUnit || 'Kg'}
                </span>
              </div>

              {batch.costPerPacket ? (
                <div className="p-2.5 bg-white rounded-xl border border-slate-200 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">प्रति प्याकेट लागत ({batch.packetSize}):</span>
                  <span className="font-mono font-black text-emerald-900 text-sm">
                    रु. {batch.costPerPacket.toLocaleString()} / पाउच
                  </span>
                </div>
              ) : null}
            </div>
          </div>

          {/* QC Inspection Notes */}
          {batch.qualityNotes && (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700">
              <b>गुणस्तर टिप्पणी:</b> {batch.qualityNotes}
            </div>
          )}

          {/* Signatures */}
          <div className="grid grid-cols-3 gap-6 pt-8 mt-6 border-t border-slate-200 text-center text-[11px] text-slate-600">
            <div>
              <div className="border-b border-dashed border-slate-400 pb-1 mb-1 font-bold text-slate-800">
                {batch.operatorName || 'अपरेटर'}
              </div>
              <span>उत्पादन अपरेटर</span>
            </div>
            <div>
              <div className="border-b border-dashed border-slate-400 pb-1 mb-1 font-bold text-slate-800">
                {batch.qualityCheckedBy || 'गुणस्तर नियन्त्रक'}
              </div>
              <span>गुणस्तर निरीक्षक (QC Incharge)</span>
            </div>
            <div>
              <div className="border-b border-dashed border-slate-400 pb-1 mb-1 font-bold text-slate-800">
                व्यवस्थापक / म्यानेजर
              </div>
              <span>अधिकृत हस्ताक्षर (Authorized Signatory)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
