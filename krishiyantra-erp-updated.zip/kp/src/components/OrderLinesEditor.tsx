import React, { useMemo, useState } from 'react';
import { Search, Plus, Minus, Trash2, AlertTriangle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FieldOrderItem } from '../types';
import { calcLineAmount, MAX_FIELD_STAFF_DISCOUNT } from '../utils/orderUtils';

interface Props {
  lines: FieldOrderItem[];
  onChange: (lines: FieldOrderItem[]) => void;
  /** true भए दर सच्याउन र छुट सीमाबिना दिन पाइन्छ (अफिस / मालिक) */
  privileged: boolean;
  showStock?: boolean;
}

/** सामान खोजेर अर्डर/कोटेशनमा थप्ने साझा सम्पादक — मोबाइलमा सजिलो हुने गरी ठूला बटन */
export const OrderLinesEditor: React.FC<Props> = ({ lines, onChange, privileged, showStock = true }) => {
  const { items, language } = useApp();
  const isNe = language === 'ne';
  const [q, setQ] = useState('');

  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return [];
    return items
      .filter((it) =>
        [it.nameNe, it.nameEn, it.code, it.size || ''].some((f) => (f || '').toLowerCase().includes(term))
      )
      .slice(0, 8);
  }, [q, items]);

  const addItem = (itemId: string) => {
    const it = items.find((i) => i.id === itemId);
    if (!it) return;
    const existing = lines.findIndex((l) => l.itemId === itemId);
    if (existing !== -1) {
      const next = [...lines];
      const l = next[existing];
      const qty = l.qty + 1;
      next[existing] = { ...l, qty, amount: calcLineAmount(qty, l.rate, l.discountPercent) };
      onChange(next);
    } else {
      onChange([
        ...lines,
        {
          itemId: it.id,
          code: it.code,
          name: it.nameNe || it.nameEn,
          size: it.size,
          unit: it.unit,
          qty: 1,
          rate: it.sellingPrice,
          discountPercent: 0,
          amount: calcLineAmount(1, it.sellingPrice, 0),
          isVatExempt: it.isVatExempt
        }
      ]);
    }
    setQ('');
  };

  const update = (idx: number, patch: Partial<FieldOrderItem>) => {
    const next = [...lines];
    const merged = { ...next[idx], ...patch };
    if (!privileged && (merged.discountPercent || 0) > MAX_FIELD_STAFF_DISCOUNT) {
      merged.discountPercent = MAX_FIELD_STAFF_DISCOUNT;
    }
    merged.amount = calcLineAmount(merged.qty, merged.rate, merged.discountPercent);
    next[idx] = merged;
    onChange(next);
  };

  const remove = (idx: number) => onChange(lines.filter((_, i) => i !== idx));

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={isNe ? 'सामानको नाम / कोड खोज्नुहोस्...' : 'Search item name / code...'}
          className="w-full pl-9 pr-3 py-3 border-2 border-emerald-300 rounded-xl text-sm font-medium focus:outline-none focus:border-emerald-600"
        />
        {results.length > 0 && (
          <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-300 rounded-xl shadow-xl max-h-72 overflow-y-auto">
            {results.map((it) => (
              <button
                type="button"
                key={it.id}
                onClick={() => addItem(it.id)}
                className="w-full text-left px-3 py-2.5 border-b border-slate-100 hover:bg-emerald-50 flex items-center justify-between gap-2"
              >
                <span className="min-w-0">
                  <span className="block text-sm font-bold text-slate-900 truncate">{it.nameNe || it.nameEn}</span>
                  <span className="block text-[11px] text-slate-500 truncate">
                    {it.code}
                    {it.size ? ` · ${it.size}` : ''} · {it.unit}
                  </span>
                </span>
                <span className="text-right shrink-0">
                  <span className="block text-sm font-black text-emerald-800">रू. {it.sellingPrice}</span>
                  {showStock && (
                    <span className={`block text-[11px] font-bold ${it.currentStock > 0 ? 'text-slate-500' : 'text-rose-600'}`}>
                      {isNe ? 'स्टक' : 'Stock'}: {it.currentStock}
                    </span>
                  )}
                </span>
              </button>
            ))}
          </div>
        )}
        {q.trim() && results.length === 0 && (
          <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-300 rounded-xl p-3 text-xs text-slate-500">
            {isNe ? 'कुनै सामान फेला परेन। इन्भेन्टरीमा सामान थप्नुहोस्।' : 'No item found. Add the item in Inventory first.'}
          </div>
        )}
      </div>

      {lines.length === 0 ? (
        <div className="text-center text-xs text-slate-400 py-6 border-2 border-dashed border-slate-200 rounded-xl">
          {isNe ? 'माथि खोजेर सामान थप्नुहोस्' : 'Search above to add items'}
        </div>
      ) : (
        <div className="space-y-2">
          {lines.map((l, idx) => {
            const stock = items.find((i) => i.id === l.itemId)?.currentStock ?? 0;
            const short = showStock && l.qty > stock;
            return (
              <div key={l.itemId} className="border border-slate-200 rounded-xl p-2.5 bg-white">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-slate-900 truncate">{l.name}</div>
                    <div className="text-[11px] text-slate-500">
                      {l.code}
                      {l.size ? ` · ${l.size}` : ''} · {l.unit}
                    </div>
                  </div>
                  <button type="button" onClick={() => remove(idx)} className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="mt-2 grid grid-cols-12 gap-2 items-end">
                  <div className="col-span-6 sm:col-span-4">
                    <div className="text-[10px] font-bold text-slate-500 mb-0.5">{isNe ? 'परिमाण' : 'Qty'}</div>
                    <div className="flex items-center">
                      <button type="button" onClick={() => update(idx, { qty: Math.max(0, l.qty - 1) })} className="w-9 h-10 bg-slate-100 rounded-l-lg flex items-center justify-center">
                        <Minus className="w-4 h-4" />
                      </button>
                      <input
                        type="number"
                        inputMode="decimal"
                        min={0}
                        value={l.qty}
                        onChange={(e) => update(idx, { qty: Number(e.target.value) })}
                        className="w-full h-10 text-center border-y border-slate-200 font-black text-base min-w-0"
                      />
                      <button type="button" onClick={() => update(idx, { qty: l.qty + 1 })} className="w-9 h-10 bg-slate-100 rounded-r-lg flex items-center justify-center">
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="col-span-6 sm:col-span-3">
                    <div className="text-[10px] font-bold text-slate-500 mb-0.5">{isNe ? 'दर (रू.)' : 'Rate'}</div>
                    <input
                      type="number"
                      inputMode="decimal"
                      value={l.rate}
                      disabled={!privileged}
                      onChange={(e) => update(idx, { rate: Number(e.target.value) })}
                      className="w-full h-10 px-2 border border-slate-200 rounded-lg font-bold disabled:bg-slate-50 disabled:text-slate-600"
                    />
                  </div>
                  <div className="col-span-5 sm:col-span-2">
                    <div className="text-[10px] font-bold text-slate-500 mb-0.5">{isNe ? 'छुट %' : 'Disc %'}</div>
                    <input
                      type="number"
                      inputMode="decimal"
                      min={0}
                      max={privileged ? 100 : MAX_FIELD_STAFF_DISCOUNT}
                      value={l.discountPercent || 0}
                      onChange={(e) => update(idx, { discountPercent: Number(e.target.value) })}
                      className="w-full h-10 px-2 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div className="col-span-7 sm:col-span-3 text-right">
                    <div className="text-[10px] font-bold text-slate-500 mb-0.5">{isNe ? 'रकम' : 'Amount'}</div>
                    <div className="h-10 flex items-center justify-end font-black text-emerald-800 text-base">
                      {l.amount.toLocaleString('en-IN')}
                    </div>
                  </div>
                </div>

                {short && (
                  <div className="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-2 py-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {isNe
                      ? `मौज्दात ${stock} मात्र छ — बाँकी उत्पादन गर्नुपर्नेछ`
                      : `Only ${stock} in stock — remaining must be produced`}
                  </div>
                )}

                <input
                  value={l.note || ''}
                  onChange={(e) => update(idx, { note: e.target.value })}
                  placeholder={isNe ? 'यो सामानको विशेष टिप्पणी (रङ, साइज आदि)' : 'Line note (colour, size...)'}
                  className="mt-2 w-full px-2 py-1.5 text-xs border border-slate-200 rounded-lg"
                />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
