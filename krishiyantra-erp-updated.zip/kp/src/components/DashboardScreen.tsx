import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { getTodayBsString, formatBsDateNepaliText } from '../utils/nepaliCalendar';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, CartesianGrid, AreaChart, Area
} from 'recharts';
import {
  Receipt, Wallet, Landmark, AlertTriangle, Plus, ArrowUpRight, ArrowDownRight, Boxes, FileText,
  BookOpen, Factory, BarChart3, Users, Building2, ChevronRight, Package, TrendingUp, CalendarCheck,
  ShoppingCart, Coins, Percent, CreditCard, ChevronLeft, ArrowUpDown, Search, HandCoins, Banknote, PackagePlus
} from 'lucide-react';
import { getServerUser } from '../utils/auth';

/* ---------- dark-teal palette (one place to change colors) ---------- */
const C = {
  bg1: '#06191d',
  bg2: '#0a2a2f',
  card: 'rgba(255,255,255,0.045)',
  line: 'rgba(255,255,255,0.09)',
  text: '#e7f3f1',
  muted: '#8fb0ad',
  gold: '#e8b13c',
  teal: '#2dd4bf',
  green: '#34d399',
  blue: '#60a5fa',
  red: '#f87171',
  violet: '#a78bfa'
};

const rs = (n: number) => '₹ ' + Math.round(n || 0).toLocaleString('en-IN');
const compact = (n: number) =>
  n >= 10000000 ? (n / 10000000).toFixed(1) + ' Cr' : n >= 100000 ? (n / 100000).toFixed(1) + ' L' : n >= 1000 ? (n / 1000).toFixed(0) + 'k' : String(Math.round(n));

const PAY_LABEL: Record<string, { ne: string; en: string; color: string }> = {
  CASH: { ne: 'नगद', en: 'Cash', color: C.green },
  BANK_FONEPAY: { ne: 'बैंक / फोनपे', en: 'Bank / FonePay', color: C.blue },
  CREDIT: { ne: 'उधारो', en: 'Credit', color: C.gold },
  STAFF_SALARY_DEDUCT: { ne: 'तलब कटौती', en: 'Salary deduct', color: C.violet }
};

const cardStyle: React.CSSProperties = {
  background: C.card,
  border: `1px solid ${C.line}`,
  boxShadow: '0 10px 30px -14px rgba(0,0,0,.6), inset 0 1px 0 rgba(255,255,255,.05)',
  backdropFilter: 'blur(6px)'
};

const Panel: React.FC<{ className?: string; children: React.ReactNode }> = ({ className = '', children }) => (
  <section className={`rounded-2xl ${className}`} style={cardStyle}>{children}</section>
);

const PanelTitle: React.FC<{ children: React.ReactNode; right?: React.ReactNode }> = ({ children, right }) => (
  <div className="flex items-center justify-between gap-2 mb-4">
    <h3 className="text-[15px] font-extrabold tracking-tight" style={{ color: C.text }}>{children}</h3>
    {right}
  </div>
);

/** Coloured KPI tile (top row) */
const Kpi: React.FC<{ label: string; value: string; sub?: string; icon: React.ReactNode; from: string; to: string }> = ({ label, value, sub, icon, from, to }) => (
  <div
    className="rounded-2xl p-4 text-white relative overflow-hidden"
    style={{ background: `linear-gradient(135deg, ${from}, ${to})`, border: `1px solid ${C.line}`, boxShadow: '0 12px 28px -14px rgba(0,0,0,.7)' }}
  >
    <div className="flex items-start justify-between gap-2">
      <p className="text-sm font-semibold text-white/85">{label}</p>
      <span className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">{icon}</span>
    </div>
    <p className="mt-2 text-[22px] sm:text-2xl font-extrabold tabular-nums leading-tight">{value}</p>
    {sub && <p className="text-xs text-white/70 mt-0.5">{sub}</p>}
  </div>
);

/** One tile of the "main sales insights" block */
const Insight: React.FC<{ icon: React.ReactNode; color: string; label: string; value: string; sub?: string }> = ({ icon, color, label, value, sub }) => (
  <div className="flex items-center gap-3">
    <span className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${color}22`, color }}>{icon}</span>
    <div className="min-w-0">
      <p className="text-xs" style={{ color: C.muted }}>{label}</p>
      <p className="text-lg font-extrabold tabular-nums truncate" style={{ color: C.text }}>{value}</p>
      {sub && <p className="text-[11px] truncate" style={{ color: C.muted }}>{sub}</p>}
    </div>
  </div>
);

export const DashboardScreen: React.FC<{ onViewInvoice?: (invoiceId: string) => void }> = ({ onViewInvoice }) => {
  const {
    items, invoices, purchases, parties, company, dailyCash, bankAccounts, language, setActiveTab, setBillingSubTab,
    companiesList, activeCompanyId, switchCompany, createNewCompany, currentAccount
  } = useApp();
  const [leftTab, setLeftTab] = useState<'products' | 'pay' | 'recent'>('products');
  const [trendMode, setTrendMode] = useState<'daily' | 'monthly'>('daily');
  const [dueSort, setDueSort] = useState<'desc' | 'asc'>('desc');
  const [dueFilter, setDueFilter] = useState('');
  const [showDueFilter, setShowDueFilter] = useState(false);
  const [duePage, setDuePage] = useState(0);
  const DUE_PAGE = 7;
  const userName = (currentAccount as any)?.ownerName || getServerUser()?.name || '';
  const isNe = language === 'ne';
  const todayBs = getTodayBsString();
  const t = (ne: string, en: string) => (isNe ? ne : en);

  const d = useMemo(() => {
    const active = invoices.filter((i) => i.status === 'ACTIVE');
    const today = active.filter((i) => i.dateBs === todayBs);
    const todayTotal = today.reduce((s, i) => s + i.grandTotal, 0);
    const totalSales = active.reduce((s, i) => s + i.grandTotal, 0);
    const totalPurchase = purchases.reduce((s, p) => s + p.grandTotal, 0);

    const byDay: Record<string, number> = {};
    active.forEach((i) => { byDay[i.dateBs] = (byDay[i.dateBs] || 0) + i.grandTotal; });
    const prevKey = Object.keys(byDay).filter((k) => k < todayBs && byDay[k] > 0).sort().pop();
    const prevTotal = prevKey ? byDay[prevKey] : 0;
    const bestDayEntry = Object.entries(byDay).sort((a, b) => b[1] - a[1])[0];
    byDay[todayBs] = byDay[todayBs] || 0;
    const trend = Object.keys(byDay).sort().slice(-14).map((k) => ({ key: k, label: k.slice(5), sales: byDay[k], isToday: k === todayBs }));
    const half = Math.floor(trend.length / 2);
    const recentSum = trend.slice(half).reduce((s, p) => s + p.sales, 0);
    const olderSum = trend.slice(0, half).reduce((s, p) => s + p.sales, 0);
    const growth = olderSum > 0 ? ((recentSum - olderSum) / olderSum) * 100 : null;

    const pay: Record<string, number> = {};
    active.forEach((i) => { pay[i.paymentMode] = (pay[i.paymentMode] || 0) + i.grandTotal; });
    const payList = Object.entries(pay).map(([k, v]) => ({ key: k, value: v })).sort((a, b) => b.value - a.value);
    const payTotal = payList.reduce((s, p) => s + p.value, 0) || 1;

    const prod: Record<string, number> = {};
    active.forEach((i) => i.items.forEach((it) => { prod[it.name] = (prod[it.name] || 0) + it.amount; }));
    const top = Object.entries(prod).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([name, amt]) => {
      const it = items.find((x) => x.nameEn === name || x.nameNe === name);
      return { name, amt, img: it?.imageUrl };
    });

    // Due dates aren't stored on a party, only on invoices — collect the earliest
    // unpaid due date per customer (by partyId, falling back to name) so it can be
    // shown next to the live balance below.
    const dueDateByParty: Record<string, string> = {};
    const dueDateByName: Record<string, string> = {};
    active.forEach((i: any) => {
      if (!i.paymentDueDate) return;
      if (i.partyId && (!dueDateByParty[i.partyId] || i.paymentDueDate < dueDateByParty[i.partyId])) {
        dueDateByParty[i.partyId] = i.paymentDueDate;
      }
      const k = i.customerName || '—';
      if (!dueDateByName[k] || i.paymentDueDate < dueDateByName[k]) dueDateByName[k] = i.paymentDueDate;
    });

    // Customer dues: read the party's live balance, not just invoices — this also
    // picks up dues entered directly on the Ledger screen (opening balance, Excel
    // upload, manual balance edit) that never went through billing.
    const dues = (parties || [])
      .filter((p: any) => ((p.partyType || p.type) === 'CUSTOMER' || !(p.partyType || p.type)) && (p.currentBalance ?? p.openingBalance) > 0)
      .map((p: any) => ({
        name: p.name,
        due: p.currentBalance ?? p.openingBalance,
        date: dueDateByParty[p.id] || dueDateByName[p.name]
      }))
      .sort((a, b) => b.due - a.due);
    const receivable = dues.reduce((s, e) => s + e.due, 0);
    const overdue = dues.reduce((sum, e) => sum + (e.date && e.date < todayBs ? e.due : 0), 0);

    // Payables: what we still owe suppliers (same rule the Ledger screen uses)
    const payable = (parties || [])
      .filter((p: any) => (p.partyType || p.type) === 'SUPPLIER')
      .reduce((sum: number, p: any) => sum + Math.max(0, p.currentBalance ?? p.openingBalance ?? 0), 0);
    const payableCount = (parties || []).filter(
      (p: any) => (p.partyType || p.type) === 'SUPPLIER' && (p.currentBalance ?? p.openingBalance ?? 0) > 0
    ).length;

    // Monthly sales (BS month = first 7 chars of YYYY-MM-DD), last 6 months that have sales
    const byMonth: Record<string, number> = {};
    active.forEach((i) => { const m = (i.dateBs || '').slice(0, 7); if (m) byMonth[m] = (byMonth[m] || 0) + i.grandTotal; });
    const monthly = Object.keys(byMonth).sort().slice(-6).map((k) => ({ key: k, label: k.slice(2), sales: byMonth[k], isToday: k === todayBs.slice(0, 7) }));

    const lowAll = items.filter((i) => i.currentStock <= i.minStockAlert);
    const recent = [...active].sort((a, b) => (b.dateBs + (b.time || '')).localeCompare(a.dateBs + (a.time || ''))).slice(0, 5);
    const dc: any = Array.isArray(dailyCash) ? (dailyCash as any[]).find((r) => r.dateBs === todayBs) : null;
    const cash = dc?.closingCashInHand ?? 0;
    const bank = bankAccounts.reduce((s, b) => s + b.currentBalance, 0);
    const delta = prevTotal > 0 && todayTotal > 0 ? ((todayTotal - prevTotal) / prevTotal) * 100 : null;
    return {
      todayCount: today.length, overdue, payable, payableCount, monthly, todayTotal, totalSales, totalPurchase, receivable, trend, payList, payTotal, top, dues,
      low: lowAll.slice(0, 4), lowCount: lowAll.length, recent, cash, bank, delta, growth,
      avgOrder: active.length ? totalSales / active.length : 0, billCount: active.length,
      bestDay: bestDayEntry ? { key: bestDayEntry[0], amt: bestDayEntry[1] } : null
    };
  }, [invoices, purchases, items, parties, dailyCash, bankAccounts, todayBs]);

  const actions = [
    { id: 'billing', icon: Receipt, ne: 'नयाँ बिल', en: 'New Bill' },
    { id: 'inventory', icon: Boxes, ne: 'स्टक', en: 'Inventory' },
    { id: 'ledger', icon: BookOpen, ne: 'लेजर', en: 'Ledger' },
    { id: 'manufacturing', icon: Factory, ne: 'उत्पादन', en: 'Production' },
    { id: 'reports', icon: BarChart3, ne: 'रिपोर्ट', en: 'Reports' },
    { id: 'vat_books', icon: Landmark, ne: 'VAT किताब', en: 'VAT Books' },
    { id: 'vouchers', icon: FileText, ne: 'भौचर', en: 'Vouchers' },
    { id: 'attendance', icon: Users, ne: 'हाजिरी', en: 'Attendance' }
  ];

  const pct = (v: number | null) => (v === null ? '—' : `${v >= 0 ? '+' : ''}${v.toFixed(1)}%`);

  const dueRows = useMemo(() => {
    const f = dueFilter.trim().toLowerCase();
    const list = d.dues.filter((r) => !f || r.name.toLowerCase().includes(f));
    return [...list].sort((a, b) => (dueSort === 'desc' ? b.due - a.due : a.due - b.due));
  }, [d.dues, dueFilter, dueSort]);
  const duePages = Math.max(1, Math.ceil(dueRows.length / DUE_PAGE));
  const safePage = Math.min(duePage, duePages - 1);
  const pagedDues = dueRows.slice(safePage * DUE_PAGE, safePage * DUE_PAGE + DUE_PAGE);

  return (
    <div
      className="relative overflow-hidden rounded-3xl p-4 sm:p-5"
      style={{ background: `radial-gradient(1200px 500px at 85% -10%, #12474b 0%, transparent 60%), linear-gradient(160deg, ${C.bg2}, ${C.bg1})`, color: C.text }}
    >
      {/* decorative mountains (top right) */}
      <svg className="absolute right-0 top-0 w-[560px] max-w-full h-44 opacity-40 pointer-events-none" viewBox="0 0 560 170" aria-hidden="true">
        <defs>
          <linearGradient id="kyMt" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={C.gold} />
            <stop offset="1" stopColor={C.gold} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d="M120 170 L210 60 L250 95 L340 12 L430 110 L480 70 L560 170 Z" fill="url(#kyMt)" />
        <path d="M340 12 L318 42 L340 36 L356 48 Z" fill="#fff" opacity="0.55" />
      </svg>

      <div className="relative grid grid-cols-1 xl:grid-cols-12 gap-4 items-start">
        {/* ================= LEFT COLUMN (full height) ================= */}
        <div className="xl:col-span-3 space-y-4 xl:pt-[84px]">
          <Panel className="p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">{t('आजको बिक्री', "Today's Sales")}</p>
              <span className="text-xs" style={{ color: C.muted }}>{todayBs}</span>
            </div>
            <p className="mt-1 text-3xl font-extrabold tabular-nums">{rs(d.todayTotal)}</p>
            <div className="mt-1 text-xs flex items-center gap-1" style={{ color: d.delta !== null && d.delta < 0 ? C.red : C.green }}>
              {d.delta !== null && (d.delta >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />)}
              {d.delta !== null ? `${Math.abs(d.delta).toFixed(0)}% ${t('अघिल्लो बिक्री दिनभन्दा', 'vs last sales day')}` : d.todayCount === 0 ? t('आज अहिलेसम्म बिल छैन', 'No bills yet today') : ''}
            </div>
            <div className="h-24 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={d.trend} margin={{ left: 0, right: 0, top: 4, bottom: 0 }}>
                  <defs>
                    <linearGradient id="kySpark" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={C.green} stopOpacity={0.55} />
                      <stop offset="100%" stopColor={C.green} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Tooltip formatter={(v: any) => rs(Number(v))} contentStyle={{ background: '#0b2327', border: `1px solid ${C.line}`, borderRadius: 10, fontSize: 12, color: C.text }} />
                  <Area type="monotone" dataKey="sales" stroke={C.green} strokeWidth={2.5} fill="url(#kySpark)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Panel>

          <Panel className="p-4 flex items-center justify-between gap-3">
            <div>
              <p className="text-sm font-semibold" style={{ color: C.muted }}>{t('बैंक मौज्दात', 'Bank Balance')}</p>
              <p className="text-2xl font-extrabold tabular-nums mt-1">{rs(d.bank)}</p>
            </div>
            <span className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${C.gold}22`, color: C.gold }}><Landmark className="w-6 h-6" /></span>
          </Panel>

          <Panel className="p-4 flex items-center justify-between gap-3">
            <div>
              <p className="text-sm font-semibold" style={{ color: C.muted }}>{t('ग्राहक बाँकी', 'Customer Dues')}</p>
              <p className="text-2xl font-extrabold tabular-nums mt-1">{rs(d.receivable)}</p>
            </div>
            <span className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${C.violet}22`, color: C.violet }}><CreditCard className="w-6 h-6" /></span>
          </Panel>

          <Panel className="p-0 overflow-hidden">
            <div className="grid grid-cols-3" style={{ borderBottom: `1px solid ${C.line}` }}>
              {([['products', Package], ['pay', Wallet], ['recent', FileText]] as const).map(([k, Icon]) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setLeftTab(k)}
                  className="py-2.5 flex items-center justify-center cursor-pointer transition"
                  style={{ background: leftTab === k ? 'rgba(45,212,191,.16)' : 'transparent', color: leftTab === k ? C.teal : C.muted, borderBottom: leftTab === k ? `2px solid ${C.teal}` : '2px solid transparent' }}
                  title={k === 'products' ? t('सामान', 'Products') : k === 'pay' ? t('भुक्तानी', 'Payments') : t('बिल', 'Invoices')}
                >
                  <Icon className="w-5 h-5" />
                </button>
              ))}
            </div>
            <div className="p-3">
              {leftTab === 'products' && (
                <ul className="space-y-2">
                  {d.top.length === 0 && <li className="text-sm" style={{ color: C.muted }}>{t('डाटा छैन', 'No data yet')}</li>}
                  {d.top.map((p, i) => (
                    <li key={p.name} className="flex items-center gap-3 rounded-lg p-2" style={{ background: i === 0 ? 'rgba(232,177,60,.14)' : 'transparent', border: i === 0 ? '1px solid rgba(232,177,60,.35)' : '1px solid transparent' }}>
                      <span className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center overflow-hidden shrink-0">
                        {p.img ? <img src={p.img} alt="" className="w-full h-full object-cover" /> : <Package className="w-5 h-5" style={{ color: C.muted }} />}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-semibold truncate">{p.name}</span>
                        <span className="block text-xs tabular-nums" style={{ color: C.gold }}>{rs(p.amt)}</span>
                      </span>
                      <span className="text-[11px] font-bold tabular-nums shrink-0" style={{ color: C.green }}>
                        ▲ {d.totalSales > 0 ? ((p.amt / d.totalSales) * 100).toFixed(0) : 0}%
                      </span>
                    </li>
                  ))}
                </ul>
              )}
              {leftTab === 'pay' && (
                d.payList.length === 0 ? (
                  <p className="text-sm" style={{ color: C.muted }}>{t('डाटा छैन', 'No data yet')}</p>
                ) : (
                  <>
                    <div className="h-3 rounded-full overflow-hidden flex gap-0.5">
                      {d.payList.map((p) => (
                        <div key={p.key} title={rs(p.value)} style={{ width: `${(p.value / d.payTotal) * 100}%`, background: PAY_LABEL[p.key]?.color || '#98a2b3' }} />
                      ))}
                    </div>
                    <ul className="mt-3 space-y-2.5">
                      {d.payList.map((p) => (
                        <li key={p.key} className="flex items-center justify-between gap-2 text-sm">
                          <span className="flex items-center gap-2" style={{ color: C.muted }}>
                            <i className="w-2.5 h-2.5 rounded-full" style={{ background: PAY_LABEL[p.key]?.color || '#98a2b3' }} />
                            {PAY_LABEL[p.key] ? (isNe ? PAY_LABEL[p.key].ne : PAY_LABEL[p.key].en) : p.key}
                          </span>
                          <span><b className="tabular-nums">{rs(p.value)}</b> <span className="text-xs tabular-nums" style={{ color: C.muted }}>{((p.value / d.payTotal) * 100).toFixed(0)}%</span></span>
                        </li>
                      ))}
                    </ul>
                  </>
                )
              )}
              {leftTab === 'recent' && (
                <ul className="text-sm">
                  {d.recent.length === 0 && <li style={{ color: C.muted }}>{t('बिल छैन', 'No invoices yet')}</li>}
                  {d.recent.map((inv) => (
                    <li key={inv.id}>
                      <button type="button" onClick={() => onViewInvoice?.(inv.id)} className="w-full py-2 flex items-center justify-between gap-2 text-left hover:bg-white/5 rounded-lg px-1 cursor-pointer">
                        <span className="min-w-0"><span className="block font-semibold truncate">{inv.customerName || '—'}</span><span className="block text-xs" style={{ color: C.muted }}>{inv.invoiceNo}</span></span>
                        <b className="tabular-nums shrink-0">{rs(inv.grandTotal)}</b>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </Panel>
        </div>

        {/* ================= RIGHT AREA (greeting, KPIs, insights, dues, quick access) ================= */}
        <div className="xl:col-span-9 space-y-4 min-w-0">
          {/* Header: greeting + company switcher + New Bill */}
          <div className="relative flex flex-wrap items-center justify-between gap-3 min-h-[68px]">
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                {t(`नमस्ते${userName ? ' ' + userName : ''}! कृषियन्त्र ERP मा स्वागत छ`, `Welcome${userName ? ', ' + userName : ''} — KrishiYantra ERP`)}
              </h2>
              <p className="text-sm mt-0.5" style={{ color: C.muted }}>{company.name} · {formatBsDateNepaliText(todayBs)}</p>
            </div>
            <div className="flex items-center gap-2">
              {companiesList && companiesList.length > 0 && (
                <label className="flex items-center gap-2 rounded-xl pl-3 pr-2 py-2 text-sm" style={{ background: C.card, border: `1px solid ${C.line}` }}>
                  <Building2 className="w-4 h-4" style={{ color: C.gold }} />
                  <select
                    value={activeCompanyId}
                    onChange={(e) => switchCompany(e.target.value)}
                    className="bg-transparent outline-none font-semibold max-w-[190px] cursor-pointer"
                    style={{ color: C.text }}
                  >
                    {companiesList.map((c) => <option key={c.id} value={c.id} className="text-slate-900">{c.name}</option>)}
                  </select>
                  <button
                    type="button"
                    title={t('नयाँ कम्पनी थप्नुहोस्', 'Add company')}
                    className="w-6 h-6 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center cursor-pointer"
                    onClick={() => {
                      const name = window.prompt(t('नयाँ कम्पनीको नाम', 'New company name'));
                      if (name && name.trim())
                        createNewCompany({ name: name.trim(), panVatNo: '', address: '', phone: '', includeStarterCatalog: true });
                    }}
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </label>
              )}
              <button type="button" onClick={() => { setBillingSubTab('SALES'); setActiveTab('billing'); }} className="ky-btn ky-btn-green">
                <Plus className="w-4 h-4" /> {t('नयाँ बिल', 'New Bill')}
              </button>
            </div>
          </div>

          {/* Quick actions: the three things done most often */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { key: 'sale', icon: Receipt, ne: 'नयाँ बिक्री', en: 'New Sale', sub: t('बिल काट्नुहोस्', 'Create a bill'), tab: 'SALES', bg: 'linear-gradient(135deg,#0f766e,#14b8a6)' },
              { key: 'purchase', icon: PackagePlus, ne: 'खरिद थप्नुहोस्', en: 'Add Purchase', sub: t('सप्लायरबाट खरिद', 'Record supplier purchase'), tab: 'PURCHASE', bg: 'linear-gradient(135deg,#1d4ed8,#3b82f6)' },
              { key: 'payment', icon: HandCoins, ne: 'भुक्तानी रेकर्ड', en: 'Record Payment', sub: t('रकम प्राप्त / भुक्तानी', 'Payment in / out'), tab: 'PAYMENT_IN', bg: 'linear-gradient(135deg,#b45309,#e8b13c)' }
            ].map((a) => (
              <button
                key={a.key}
                type="button"
                onClick={() => { setBillingSubTab(a.tab as any); setActiveTab('billing'); }}
                className="group flex items-center gap-4 rounded-2xl px-5 py-4 text-left text-white cursor-pointer transition hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
                style={{ background: a.bg, boxShadow: '0 14px 28px -16px rgba(0,0,0,.8)' }}
              >
                <span className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center shrink-0 transition group-hover:scale-110">
                  <a.icon className="w-6 h-6" />
                </span>
                <span className="min-w-0">
                  <span className="block text-lg font-extrabold leading-tight">{isNe ? a.ne : a.en}</span>
                  <span className="block text-xs text-white/80 truncate">{a.sub}</span>
                </span>
              </button>
            ))}
          </div>

          {/* KPI row: Today's Sales · Receivables · Payables · Low Stock */}
          <div className="relative grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Kpi label={t('आजको कुल बिक्री', "Today's Sales")} value={rs(d.todayTotal)} sub={`${d.todayCount} ${t('बिल', 'bills')} · ${t('नगद', 'Cash')} ${rs(d.cash)}`} icon={<Receipt className="w-5 h-5" />} from="#0f766e" to="#064e4b" />
            <Kpi label={t('लिन बाँकी रकम', 'Total Receivables')} value={rs(d.receivable)} sub={d.overdue > 0 ? `${t('म्याद नाघेको', 'Overdue')} ${rs(d.overdue)}` : t('म्याद नाघेको छैन', 'Nothing overdue')} icon={<Wallet className="w-5 h-5" />} from="#1e4f9c" to="#102a55" />
            <Kpi label={t('तिर्न बाँकी रकम', 'Total Payables')} value={rs(d.payable)} sub={`${d.payableCount} ${t('सप्लायर', 'suppliers')}`} icon={<CreditCard className="w-5 h-5" />} from="#8b2b3a" to="#4a1520" />
            <button type="button" onClick={() => setActiveTab('inventory')} className="text-left cursor-pointer transition hover:-translate-y-0.5 rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70">
              <Kpi label={t('कम स्टक भएका सामान', 'Low Stock Alerts')} value={String(d.lowCount)} sub={d.lowCount > 0 ? t('स्टक हेर्न थिच्नुहोस्', 'Tap to review stock') : t('सबै स्टक पर्याप्त', 'All stock is fine')} icon={<AlertTriangle className="w-5 h-5" />} from={d.lowCount > 0 ? '#a8501f' : '#2f6b4f'} to={d.lowCount > 0 ? '#5c2a0f' : '#17382a'} />
            </button>
          </div>

          {/* Sales trend chart (daily / monthly) */}
          <Panel className="p-4">
            <PanelTitle
              right={
                <div className="inline-flex rounded-lg p-0.5" style={{ background: 'rgba(255,255,255,.07)', border: `1px solid ${C.line}` }}>
                  {(['daily', 'monthly'] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setTrendMode(m)}
                      className="px-3 py-1 text-xs font-bold rounded-md cursor-pointer transition"
                      style={{ background: trendMode === m ? 'rgba(45,212,191,.22)' : 'transparent', color: trendMode === m ? C.teal : C.muted }}
                    >
                      {m === 'daily' ? t('दैनिक', 'Daily') : t('मासिक', 'Monthly')}
                    </button>
                  ))}
                </div>
              }
            >
              {t('बिक्री ट्रेन्ड', 'Sales Trend')}
              <span className="ml-2 text-[11px] font-normal" style={{ color: C.muted }}>
                {trendMode === 'daily' ? t('पछिल्ला १४ बिक्री दिन', 'last 14 sales days') : t('पछिल्ला ६ महिना', 'last 6 months')}
              </span>
            </PanelTitle>
            <div className="h-56">
              {(trendMode === 'daily' ? d.trend : d.monthly).length === 0 ? (
                <p className="text-sm" style={{ color: C.muted }}>{t('डाटा छैन', 'No data yet')}</p>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={trendMode === 'daily' ? d.trend : d.monthly} margin={{ left: 0, right: 8, top: 8, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={C.line} />
                    <XAxis dataKey="label" tick={{ fill: C.muted, fontSize: 11 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: C.muted, fontSize: 11 }} axisLine={false} tickLine={false} width={44} tickFormatter={(v: number) => compact(v)} />
                    <Tooltip cursor={{ fill: 'rgba(255,255,255,.05)' }} formatter={(v: any) => rs(Number(v))} contentStyle={{ background: '#0b2327', border: `1px solid ${C.line}`, borderRadius: 10, fontSize: 12, color: C.text }} />
                    <Bar dataKey="sales" radius={[6, 6, 0, 0]}>
                      {(trendMode === 'daily' ? d.trend : d.monthly).map((p: any) => (
                        <Cell key={p.key} fill={p.isToday ? C.gold : C.teal} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </Panel>

          {/* Insights (middle) + Top customer dues (right) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
            <div className="lg:col-span-6 space-y-4 min-w-0">
              <Panel className="p-5">
                <PanelTitle>{t('मुख्य बिक्री अन्तर्दृष्टि', 'Key Sales Insights')}</PanelTitle>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-6">
                  <Insight icon={<ShoppingCart className="w-5 h-5" />} color={C.green} label={t('औसत बिल मूल्य', 'Average Order Value')} value={rs(d.avgOrder)} />
                  <Insight icon={<CalendarCheck className="w-5 h-5" />} color={C.gold} label={t('उत्कृष्ट बिक्री दिन', 'Best Selling Day')} value={d.bestDay ? d.bestDay.key.slice(5) : '—'} sub={d.bestDay ? rs(d.bestDay.amt) : undefined} />
                  <Insight icon={<TrendingUp className="w-5 h-5" />} color={C.teal} label={t('बिक्री वृद्धि दर', 'Sales Growth Rate')} value={pct(d.growth)} />
                  <Insight icon={<Receipt className="w-5 h-5" />} color={C.blue} label={t('कुल बिल', 'Total Bills')} value={String(d.billCount)} />
                  <Insight icon={<Percent className="w-5 h-5" />} color={C.violet} label={t('खरिद / बिक्री', 'Purchase / Sales')} value={d.totalSales > 0 ? `${Math.min(999, (d.totalPurchase / d.totalSales) * 100).toFixed(0)}%` : '—'} />
                  <Insight icon={<Wallet className="w-5 h-5" />} color={C.red} label={t('असुल्नुपर्ने', 'Outstanding')} value={rs(d.receivable)} />
                </div>
              </Panel>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Panel className="p-4">
                  <PanelTitle right={<span className="text-[10px] font-bold rounded-full px-2 py-0.5" style={{ background: 'rgba(45,212,191,.16)', color: C.teal }}>{t('लाइभ', 'Live')}</span>}>
                    {t('धेरै बिक्री भएका सामान', 'Top Products')}
                  </PanelTitle>
                  {d.top.length === 0 ? (
                    <p className="text-sm" style={{ color: C.muted }}>{t('डाटा छैन', 'No data yet')}</p>
                  ) : (
                    <div className="flex gap-3 flex-wrap">
                      {d.top.slice(0, 4).map((p) => (
                        <div key={p.name} className="w-[58px] text-center" title={`${p.name} — ${rs(p.amt)}`}>
                          <span className="w-[58px] h-[58px] rounded-xl bg-white/10 flex items-center justify-center overflow-hidden">
                            {p.img ? <img src={p.img} alt="" className="w-full h-full object-cover" /> : <Package className="w-6 h-6" style={{ color: C.muted }} />}
                          </span>
                          <span className="block text-[10px] mt-1 truncate" style={{ color: C.muted }}>{p.name}</span>
                          <span className="block text-[10px] font-bold tabular-nums" style={{ color: C.gold }}>{compact(p.amt)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </Panel>

                <Panel className="p-4">
                  <PanelTitle
                    right={d.lowCount > 0 ? <span className="text-xs font-bold rounded-full px-2.5 py-0.5" style={{ background: 'rgba(248,113,113,.18)', color: C.red }}>{d.lowCount}</span> : undefined}
                  >
                    <span className="flex items-center gap-2"><AlertTriangle className="w-4 h-4" style={{ color: C.gold }} /> {t('स्टक सकिँदै', 'Low Stock')}</span>
                  </PanelTitle>
                  <ul className="space-y-3 text-sm">
                    {d.low.length === 0 && <li style={{ color: C.green }} className="font-semibold">✓ {t('सबै स्टक पर्याप्त छ', 'All stock levels are fine')}</li>}
                    {d.low.slice(0, 3).map((i) => {
                      const pc = i.minStockAlert > 0 ? Math.max(0, Math.min(100, (i.currentStock / i.minStockAlert) * 100)) : 0;
                      return (
                        <li key={i.id}>
                          <div className="flex justify-between gap-2">
                            <span className="truncate font-semibold">{isNe ? i.nameNe || i.nameEn : i.nameEn}</span>
                            <b className="tabular-nums shrink-0" style={{ color: C.red }}>{i.currentStock} {i.unit}</b>
                          </div>
                          <div className="h-1.5 rounded-full mt-1.5 overflow-hidden bg-white/10">
                            <div className="h-full rounded-full" style={{ width: `${pc}%`, background: C.red }} />
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                  {d.lowCount > 0 && (
                    <button type="button" onClick={() => setActiveTab('inventory')} className="mt-3 text-sm font-bold flex items-center gap-1 cursor-pointer" style={{ color: C.teal }}>
                      {t('स्टक हेर्नुहोस्', 'Open inventory')} <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </Panel>
              </div>
            </div>

            {/* Top customer dues table */}
            <Panel className="lg:col-span-6 p-5 flex flex-col min-w-0">
              <PanelTitle>{t('शीर्ष ग्राहक बक्यौता', 'Top Customer Dues')}</PanelTitle>
              <div className="overflow-x-auto flex-1">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-xs text-left" style={{ color: C.text, borderBottom: `1px solid ${C.line}` }}>
                      <th className="py-2 pr-2 font-bold">
                        <span className="inline-flex items-center gap-1.5">
                          {t('ग्राहकको नाम', 'Customer Name')}
                          <button type="button" onClick={() => setShowDueFilter((v) => !v)} title={t('खोज्नुहोस्', 'Filter')} className="cursor-pointer" style={{ color: showDueFilter ? C.teal : C.muted }}>
                            <Search className="w-3.5 h-3.5" />
                          </button>
                        </span>
                      </th>
                      <th className="py-2 pr-2 font-bold text-right">
                        <button type="button" onClick={() => setDueSort((v) => (v === 'desc' ? 'asc' : 'desc'))} className="inline-flex items-center gap-1 cursor-pointer font-bold">
                          {t('बाँकी रकम', 'Amount Due')} <ArrowUpDown className="w-3.5 h-3.5" style={{ color: C.muted }} />
                        </button>
                      </th>
                      <th className="py-2 pr-2 font-bold">{t('म्याद', 'Due Date')}</th>
                      <th className="py-2 font-bold">{t('स्थिति', 'Status')}</th>
                    </tr>
                    {showDueFilter && (
                      <tr>
                        <th colSpan={4} className="pb-2">
                          <input
                            autoFocus
                            value={dueFilter}
                            onChange={(e) => { setDueFilter(e.target.value); setDuePage(0); }}
                            placeholder={t('ग्राहकको नाम खोज्नुहोस्…', 'Search customer…')}
                            className="w-full rounded-lg px-3 py-1.5 text-sm font-normal outline-none"
                            style={{ background: 'rgba(255,255,255,.07)', border: `1px solid ${C.line}`, color: C.text }}
                          />
                        </th>
                      </tr>
                    )}
                  </thead>
                  <tbody>
                    {pagedDues.length === 0 && (
                      <tr><td colSpan={4} className="py-4" style={{ color: C.muted }}>{t('कुनै बक्यौता छैन', 'No dues')}</td></tr>
                    )}
                    {pagedDues.map((r) => {
                      const overdue = !!r.date && r.date < todayBs;
                      return (
                        <tr key={r.name} style={{ borderBottom: `1px solid ${C.line}` }}>
                          <td className="py-3 pr-2 font-semibold truncate max-w-[150px]">{r.name}</td>
                          <td className="py-3 pr-2 text-right tabular-nums">{rs(r.due)}</td>
                          <td className="py-3 pr-2 tabular-nums text-xs" style={{ color: C.muted }}>{r.date || '—'}</td>
                          <td className="py-3">
                            <span
                              className="text-[11px] font-bold rounded px-2.5 py-1"
                              style={overdue ? { background: 'rgba(248,113,113,.2)', color: C.red } : { background: 'rgba(52,211,153,.2)', color: C.green }}
                            >
                              {overdue ? t('म्याद नाघ्यो', 'Overdue') : t('बाँकी', 'Pending')}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <div className="flex items-center justify-between pt-3 text-xs" style={{ color: C.muted }}>
                <span>{t('क्रम', 'Sort')}: {dueSort === 'desc' ? t('धेरैदेखि कम', 'High → Low') : t('कमदेखि धेरै', 'Low → High')} · {dueRows.length}</span>
                <span className="flex items-center gap-1">
                  <button type="button" disabled={safePage === 0} onClick={() => setDuePage(safePage - 1)} className="p-1 rounded hover:bg-white/10 disabled:opacity-30 cursor-pointer"><ChevronLeft className="w-4 h-4" /></button>
                  <span className="tabular-nums">{safePage + 1}/{duePages}</span>
                  <button type="button" disabled={safePage >= duePages - 1} onClick={() => setDuePage(safePage + 1)} className="p-1 rounded hover:bg-white/10 disabled:opacity-30 cursor-pointer"><ChevronRight className="w-4 h-4" /></button>
                </span>
              </div>
            </Panel>
          </div>

          {/* Quick access + quick payment */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            <Panel className="lg:col-span-9 p-4">
              <PanelTitle>{t('छिटो पहुँच', 'Quick Access')}</PanelTitle>
              <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 gap-3">
                {actions.map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => setActiveTab(a.id as any)}
                    className="group flex flex-col items-center gap-2 rounded-xl py-3 px-2 text-xs font-bold cursor-pointer transition hover:-translate-y-0.5"
                    style={{ background: 'linear-gradient(160deg, rgba(45,212,191,.22), rgba(15,118,110,.25))', border: `1px solid rgba(45,212,191,.28)`, color: C.text }}
                  >
                    <a.icon className="w-6 h-6 transition group-hover:scale-110" style={{ color: C.teal }} />
                    {isNe ? a.ne : a.en}
                  </button>
                ))}
              </div>
            </Panel>
            <Panel className="lg:col-span-3 p-4">
              <PanelTitle>{t('छिटो भुक्तानी', 'Quick Payment')}</PanelTitle>
              <div className="grid grid-cols-2 gap-3">
                <button type="button" onClick={() => setActiveTab('vouchers' as any)} className="flex flex-col items-center gap-2 rounded-xl py-3 px-2 text-xs font-bold cursor-pointer transition hover:-translate-y-0.5" style={{ background: 'linear-gradient(160deg, rgba(45,212,191,.22), rgba(15,118,110,.25))', border: '1px solid rgba(45,212,191,.28)' }}>
                  <HandCoins className="w-6 h-6" style={{ color: C.teal }} />
                  {t('रिसिप्ट', 'Receipt')}
                </button>
                <button type="button" onClick={() => setActiveTab('vouchers' as any)} className="flex flex-col items-center gap-2 rounded-xl py-3 px-2 text-xs font-bold cursor-pointer transition hover:-translate-y-0.5" style={{ background: 'linear-gradient(160deg, rgba(232,177,60,.22), rgba(122,90,20,.25))', border: '1px solid rgba(232,177,60,.3)' }}>
                  <Banknote className="w-6 h-6" style={{ color: C.gold }} />
                  {t('भुक्तानी', 'Paid')}
                </button>
              </div>
            </Panel>
          </div>
        </div>
      </div>
    </div>
  );
};
