import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldAlert,
  Search,
  Download,
  FileText,
  Package,
  AlertTriangle,
  CheckCircle2,
  UserCheck,
  Filter,
  ShoppingCart,
  RefreshCw,
  LogIn,
  Trash2,
  Clock
} from 'lucide-react';
import { AuditActionType, AuditLogEntry } from '../types';
import { formatCurrency } from '../utils/nepaliCalendar';

export const AuditTrailScreen: React.FC = () => {
  const { auditLogs, language, currentAccount, currentRole } = useApp();
  const isNe = language === 'ne';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedModule, setSelectedModule] = useState<string>('ALL');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('ALL');
  const [selectedAction, setSelectedAction] = useState<string>('ALL');

  const isSuperAdminOrOwner =
    currentAccount?.mobileNumber === '9855012345' ||
    currentAccount?.role === 'SUPER_ADMIN' ||
    currentRole === 'OWNER' ||
    currentRole === 'ADMINISTRATION';

  const stats = useMemo(() => {
    const total = auditLogs.length;
    const invoicesCreated = auditLogs.filter((l) => l.actionType === 'INVOICE_CREATED').length;
    const criticalAlerts = auditLogs.filter(
      (l) => l.severity === 'CRITICAL' || l.actionType === 'INVOICE_CANCELLED' || l.actionType === 'INVOICE_DELETED' || l.actionType === 'INVENTORY_DELETED'
    ).length;
    const inventoryChanges = auditLogs.filter((l) => l.module === 'INVENTORY').length;
    return { total, invoicesCreated, criticalAlerts, inventoryChanges };
  }, [auditLogs]);

  const filteredLogs = useMemo(() => {
    return auditLogs.filter((log) => {
      if (selectedModule !== 'ALL' && log.module !== selectedModule) return false;
      if (selectedSeverity !== 'ALL' && log.severity !== selectedSeverity) return false;
      if (selectedAction !== 'ALL' && log.actionType !== selectedAction) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchSummary =
          log.summaryEn.toLowerCase().includes(q) || log.summaryNe.toLowerCase().includes(q);
        const matchTarget =
          (log.targetId || '').toLowerCase().includes(q);
        const matchActor =
          log.actorName.toLowerCase().includes(q) || log.actorMobile.toLowerCase().includes(q);
        const matchDetails = (log.details || '').toLowerCase().includes(q);
        return matchSummary || matchTarget || matchActor || matchDetails;
      }
      return true;
    });
  }, [auditLogs, selectedModule, selectedSeverity, selectedAction, searchQuery]);

  const handleExportCSV = () => {
    const headers = [
      'Timestamp',
      'Date (BS)',
      'Action',
      'Module',
      'Severity',
      'Actor Name',
      'Actor Mobile',
      'Actor Role',
      'Target ID',
      'Summary',
      'Details'
    ];
    const rows = filteredLogs.map((l) => [
      new Date(l.timestamp).toLocaleString(),
      l.dateBs,
      l.actionType,
      l.module,
      l.severity,
      `"${l.actorName.replace(/"/g, '""')}"`,
      l.actorMobile,
      l.actorRole,
      l.targetId || '',
      `"${(isNe ? l.summaryNe : l.summaryEn).replace(/"/g, '""')}"`,
      `"${(l.details || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Audit_Trail_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getActionBadge = (action: AuditActionType) => {
    switch (action) {
      case 'INVOICE_CREATED':
        return {
          label: isNe ? 'बिल जारी' : 'Invoice Created',
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          icon: <FileText className="w-3.5 h-3.5 text-emerald-600" />
        };
      case 'INVOICE_CANCELLED':
        return {
          label: isNe ? 'बिल रद्द' : 'Invoice Cancelled',
          bg: 'bg-red-50 text-red-700 border-red-200',
          icon: <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
        };
      case 'INVOICE_DELETED':
        return {
          label: isNe ? 'बिल मेटियो' : 'Invoice Deleted',
          bg: 'bg-red-50 text-red-700 border-red-200',
          icon: <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
        };
      case 'INVENTORY_ADDED':
        return {
          label: isNe ? 'सामान थप' : 'Item Added',
          bg: 'bg-blue-50 text-blue-700 border-blue-200',
          icon: <Package className="w-3.5 h-3.5 text-blue-600" />
        };
      case 'INVENTORY_UPDATED':
        return {
          label: isNe ? 'सामान संशोधन' : 'Item Updated',
          bg: 'bg-indigo-50 text-indigo-700 border-indigo-200',
          icon: <Package className="w-3.5 h-3.5 text-indigo-600" />
        };
      case 'INVENTORY_DELETED':
        return {
          label: isNe ? 'सामान हटाइयो' : 'Item Deleted',
          bg: 'bg-rose-50 text-rose-700 border-rose-200',
          icon: <Trash2 className="w-3.5 h-3.5 text-rose-600" />
        };
      case 'STOCK_ADJUSTED':
        return {
          label: isNe ? 'स्टक समायोजन' : 'Stock Adjusted',
          bg: 'bg-amber-50 text-amber-800 border-amber-200',
          icon: <RefreshCw className="w-3.5 h-3.5 text-amber-600" />
        };
      case 'STOCK_RECONCILED':
        return {
          label: isNe ? 'भौतिक स्टक मिलान' : 'Stock Reconciled',
          bg: 'bg-purple-50 text-purple-700 border-purple-200',
          icon: <CheckCircle2 className="w-3.5 h-3.5 text-purple-600" />
        };
      case 'PURCHASE_RECORDED':
        return {
          label: isNe ? 'खरिद दर्ता' : 'Purchase Recorded',
          bg: 'bg-teal-50 text-teal-700 border-teal-200',
          icon: <ShoppingCart className="w-3.5 h-3.5 text-teal-600" />
        };
      case 'PURCHASE_DELETED':
        return {
          label: isNe ? 'खरिद मेटियो' : 'Purchase Deleted',
          bg: 'bg-red-50 text-red-700 border-red-200',
          icon: <ShoppingCart className="w-3.5 h-3.5 text-red-600" />
        };
      case 'USER_LOGIN':
        return {
          label: isNe ? 'प्रणाली लगइन' : 'User Login',
          bg: 'bg-slate-100 text-slate-700 border-slate-200',
          icon: <LogIn className="w-3.5 h-3.5 text-slate-600" />
        };
      default:
        return {
          label: action,
          bg: 'bg-slate-100 text-slate-700 border-slate-200',
          icon: <UserCheck className="w-3.5 h-3.5 text-slate-600" />
        };
    }
  };

  const getSeverityStyle = (severity: AuditLogEntry['severity']) => {
    if (severity === 'CRITICAL') {
      return 'bg-red-600 text-white';
    }
    if (severity === 'WARNING') {
      return 'bg-amber-500 text-white';
    }
    return 'bg-emerald-600 text-white';
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-2xl p-5 sm:p-6 text-white shadow-lg border border-emerald-800/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight">
                  {isNe ? 'सुपर एडमिन अडिट ट्रेल (Audit Trail)' : 'Super Admin Security & Audit Trail'}
                </h1>
                <span className="px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/30 rounded-full">
                  {isSuperAdminOrOwner ? 'SUPER ADMIN REVIEW' : 'READ ONLY'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-emerald-200/80 mt-1">
                {isNe
                  ? 'प्रणालीमा गरिएका प्रत्येक बिल जारी, बिल रद्द/डिलिट, मौज्दात (Inventory) घटबढ र खरिद कार्यहरूको अपरिवर्तनीय अभिलेख'
                  : 'Immutable real-time log of all invoice creations, cancellations/deletions, and inventory stock adjustments for Super Admin review'}
              </p>
            </div>
          </div>

          <button
            onClick={handleExportCSV}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-md transition-colors cursor-pointer shrink-0"
          >
            <Download className="w-4 h-4" />
            {isNe ? 'अडिट रिपोर्ट डाउनलोड (CSV)' : 'Export Audit CSV'}
          </button>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">
              {isNe ? 'कुल अडिट गतिविधि' : 'Total Tracked Events'}
            </span>
            <Clock className="w-4 h-4 text-slate-500" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-1.5">{stats.total}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">
            {isNe ? 'सक्रिय सुरक्षा निगरानी' : 'Active security monitoring'}
          </p>
        </div>

        <div className="bg-white rounded-xl p-4 border border-emerald-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-700 uppercase">
              {isNe ? 'जारी गरिएका बिलहरू' : 'Invoices Created'}
            </span>
            <FileText className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-emerald-700 mt-1.5">{stats.invoicesCreated}</p>
          <p className="text-[11px] text-emerald-600/80 mt-0.5">
            {isNe ? 'बिक्री तथा कर बीजक' : 'Verified sales & tax invoices'}
          </p>
        </div>

        <div className="bg-white rounded-xl p-4 border border-red-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-red-700 uppercase">
              {isNe ? 'बिल रद्द / संवेदनशील' : 'Deletions & Cancellations'}
            </span>
            <AlertTriangle className="w-4 h-4 text-red-600" />
          </div>
          <p className="text-2xl font-black text-red-600 mt-1.5">{stats.criticalAlerts}</p>
          <p className="text-[11px] text-red-600/80 mt-0.5">
            {isNe ? 'सुपर एडमिन विशेष ध्यान' : 'High-priority review items'}
          </p>
        </div>

        <div className="bg-white rounded-xl p-4 border border-amber-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-800 uppercase">
              {isNe ? 'मौज्दात (Inventory) समायोजन' : 'Inventory Adjustments'}
            </span>
            <Package className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-black text-amber-700 mt-1.5">{stats.inventoryChanges}</p>
          <p className="text-[11px] text-amber-700/80 mt-0.5">
            {isNe ? 'स्टक थप, घटबढ र मिलान' : 'Stock edits & reconciliations'}
          </p>
        </div>
      </div>

      {/* Filters & Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isNe
                  ? 'बिल नं (TI-...), सामानको कोड, प्रयोगकर्ता वा मोबाइल नम्बर खोज्नुहोस्...'
                  : 'Search by Invoice # (TI-...), Item SKU, Actor Name, Mobile, or Reason...'
              }
              className="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border border-slate-200 focus:border-emerald-600 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-3 gap-2 sm:flex sm:items-center">
            <div className="flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-slate-400 hidden sm:inline" />
              <select
                value={selectedModule}
                onChange={(e) => setSelectedModule(e.target.value)}
                className="w-full px-3 py-2.5 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 text-slate-700 focus:outline-none focus:border-emerald-600"
              >
                <option value="ALL">{isNe ? 'सबै मोड्युल (All)' : 'All Modules'}</option>
                <option value="BILLING">{isNe ? 'बिक्री बिल (Billing)' : 'Billing / Invoices'}</option>
                <option value="INVENTORY">{isNe ? 'मौज्दात (Inventory)' : 'Inventory / Stock'}</option>
                <option value="PURCHASE">{isNe ? 'खरिद (Purchase)' : 'Purchases'}</option>
                <option value="AUTH">{isNe ? 'लगइन / सुरक्षा (Auth)' : 'Auth & Accounts'}</option>
              </select>
            </div>

            <select
              value={selectedAction}
              onChange={(e) => setSelectedAction(e.target.value)}
              className="w-full px-3 py-2.5 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 text-slate-700 focus:outline-none focus:border-emerald-600"
            >
              <option value="ALL">{isNe ? 'सबै कार्य (All Actions)' : 'All Actions'}</option>
              <option value="INVOICE_CREATED">{isNe ? 'बिल जारी' : 'Invoice Created'}</option>
              <option value="INVOICE_CANCELLED">{isNe ? 'बिल रद्द/डिलिट' : 'Invoice Cancelled'}</option>
              <option value="INVOICE_DELETED">{isNe ? 'बिल सदाको लागि मेटियो' : 'Invoice Deleted'}</option>
              <option value="STOCK_ADJUSTED">{isNe ? 'स्टक समायोजन' : 'Stock Adjusted'}</option>
              <option value="STOCK_RECONCILED">{isNe ? 'भौतिक स्टक मिलान' : 'Stock Reconciled'}</option>
              <option value="ITEM_CREATED">{isNe ? 'नयाँ सामान थप' : 'Item Added'}</option>
              <option value="ITEM_UPDATED">{isNe ? 'सामान संशोधन' : 'Item Updated'}</option>
              <option value="ITEM_DELETED">{isNe ? 'सामान हटाइयो' : 'Item Deleted'}</option>
              <option value="PURCHASE_RECORDED">{isNe ? 'खरिद दर्ता' : 'Purchase Recorded'}</option>
              <option value="PURCHASE_DELETED">{isNe ? 'खरिद मेटियो' : 'Purchase Deleted'}</option>
            </select>

            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="w-full px-3 py-2.5 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 text-slate-700 focus:outline-none focus:border-emerald-600"
            >
              <option value="ALL">{isNe ? 'सबै स्तर (Severity)' : 'All Severities'}</option>
              <option value="CRITICAL">{isNe ? 'संवेदनशील (Critical)' : 'Critical Only'}</option>
              <option value="WARNING">{isNe ? 'चेतावनी (Warning)' : 'Warning'}</option>
              <option value="INFO">{isNe ? 'सामान्य (Info)' : 'Info'}</option>
            </select>
          </div>
        </div>
      </div>

      {/* Audit Log Timeline / Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <h2 className="text-sm font-black text-slate-800">
            {isNe
              ? `अडिट लग विवरण (${filteredLogs.length} रेकर्डहरू)`
              : `Audit Event Stream (${filteredLogs.length} records)`}
          </h2>
          <span className="text-[11px] font-semibold text-slate-500">
            {isNe ? 'सुपर एडमिन: ९८५५०१२३४५' : 'Reviewed by Super Admin (9855012345)'}
          </span>
        </div>

        {filteredLogs.length === 0 ? (
          <div className="p-12 text-center">
            <ShieldAlert className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-600">
              {isNe ? 'कुनै अडिट रेकर्ड फेला परेन' : 'No matching audit trail records found'}
            </p>
            <p className="text-xs text-slate-400 mt-1">
              {isNe
                ? 'खोज शब्द वा फिल्टर परिवर्तन गर्नुहोस्'
                : 'Try clearing your search or changing the module filter'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredLogs.map((log) => {
              const badge = getActionBadge(log.actionType);
              const formattedTime = new Date(log.timestamp).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit'
              });

              return (
                <div
                  key={log.id}
                  className={`p-4 sm:px-5 hover:bg-slate-50/80 transition-colors ${
                    log.severity === 'CRITICAL' ? 'bg-red-50/20' : ''
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                    <div className="flex items-start gap-3">
                      <div
                        className={`mt-0.5 px-2.5 py-1 rounded-lg border text-xs font-bold inline-flex items-center gap-1.5 shrink-0 ${badge.bg}`}
                      >
                        {badge.icon}
                        <span>{badge.label}</span>
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span
                            className={`px-1.5 py-0.5 text-[10px] font-black rounded uppercase ${getSeverityStyle(
                              log.severity
                            )}`}
                          >
                            {log.severity}
                          </span>
                          {log.targetId && (
                            <span className="px-2 py-0.5 text-xs font-mono font-bold bg-slate-100 text-slate-800 rounded border border-slate-200">
                              #{log.targetId}
                            </span>
                          )}
                          <h3 className="text-sm font-bold text-slate-900">
                            {isNe ? log.summaryNe : log.summaryEn}
                          </h3>
                        </div>

                        {log.details && (
                          <p className="text-xs font-medium text-slate-600 mt-1 bg-slate-100/80 px-2.5 py-1.5 rounded-lg border border-slate-200/70 inline-block">
                            {log.details}
                          </p>
                        )}

                        <div className="flex items-center gap-3 flex-wrap mt-2 text-[11px] text-slate-500">
                          <span className="font-semibold text-slate-700">
                            👤 {log.actorName} ({log.actorMobile})
                          </span>
                          <span className="px-1.5 py-0.2 bg-slate-100 rounded text-slate-600 font-bold">
                            {log.actorRole}
                          </span>
                          <span>
                            📅 {log.dateBs} BS ({formattedTime})
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
