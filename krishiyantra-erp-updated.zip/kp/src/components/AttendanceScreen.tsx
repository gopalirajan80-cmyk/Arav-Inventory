import { printPage } from '../utils/printHelper';
import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Employee, AttendanceRecord, EmployeeLedgerEntry, StaffWorkCategory, WorkCategoryConfig } from '../types';
import {
  Users,
  MapPin,
  Camera,
  CheckCircle2,
  Clock,
  Plus,
  CalendarCheck,
  UserCheck,
  X,
  Wallet,
  Receipt,
  ArrowDownRight,
  ArrowUpRight,
  DollarSign,
  FileText,
  Fingerprint,
  Sparkles,
  Navigation,
  ShieldCheck,
  Smartphone,
  Wifi,
  WifiOff,
  RefreshCw,
  Key,
  FileSpreadsheet,
  Download,
  Printer,
  Calculator,
  Calendar,
  CreditCard,
  TrendingUp,
  Coins,
  Settings,
  Truck
} from 'lucide-react';
import * as XLSX from 'xlsx';
import {
  getTodayBsString,
  getTodayAdString,
  formatBsDateNepaliText,
  formatCurrency,
  toNepaliDigits
} from '../utils/nepaliCalendar';
import {
  isWithinWorkplaceGeofence,
  getCurrentDeviceGps,
  calculateGpsDistanceMeters
} from '../utils/gpsUtils';

export const WORK_CATEGORIES: WorkCategoryConfig[] = [
  {
    id: 'TUNNEL_MAKING',
    labelNe: '🏗️ टनेल बनाउने (Tunnel Making)',
    labelEn: '🏗️ Tunnel Making',
    shortNe: '🏗️ टनेल बनाउने',
    badgeClass: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    isFieldWork: true,
    defaultSiteNote: 'टनेल निर्माण साइट'
  },
  {
    id: 'PLASTIC_LAYING',
    labelNe: '⛺ प्लास्टिक राख्ने (Plastic Laying)',
    labelEn: '⛺ Plastic Laying',
    shortNe: '⛺ प्लास्टिक राख्ने',
    badgeClass: 'bg-teal-100 text-teal-900 border-teal-300',
    isFieldWork: true,
    defaultSiteNote: 'प्लास्टिक जडान साइट'
  },
  {
    id: 'TRACTOR_WORK',
    labelNe: '🚜 ट्याक्टर बनाउने / मर्मत (Tractor Work)',
    labelEn: '🚜 Tractor Making / Repair',
    shortNe: '🚜 ट्याक्टर बनाउने',
    badgeClass: 'bg-amber-100 text-amber-900 border-amber-300',
    isFieldWork: false,
    defaultSiteNote: 'वर्कसप ट्याक्टर मर्मत'
  },
  {
    id: 'FITTING_WORK',
    labelNe: '🔧 फिटिङ गर्ने (Fitting Work)',
    labelEn: '🔧 Fitting Work',
    shortNe: '🔧 फिटिङ गर्ने',
    badgeClass: 'bg-blue-100 text-blue-900 border-blue-300',
    isFieldWork: true,
    defaultSiteNote: 'पाइप/उपकरण फिटिङ साइट'
  },
  {
    id: 'CLIENT_SITE_VISIT',
    labelNe: '🚗 अरुकोमा जाने / फिल्ड काम (Client Site)',
    labelEn: '🚗 Client Site Visit / Field',
    shortNe: '🚗 अरुकोमा जाने',
    badgeClass: 'bg-purple-100 text-purple-900 border-purple-300',
    isFieldWork: true,
    defaultSiteNote: 'ग्राहकको फिल्ड / बाहिरी काम'
  },
  {
    id: 'WORKSHOP_REGULAR',
    labelNe: '🏭 वर्कसप / पसल नियमित (Workshop)',
    labelEn: '🏭 Workshop Regular',
    shortNe: '🏭 वर्कसप नियमित',
    badgeClass: 'bg-slate-100 text-slate-800 border-slate-300',
    isFieldWork: false,
    defaultSiteNote: 'मुख्य वर्कसप / पसल'
  },
  {
    id: 'OTHER_WORK',
    labelNe: '🔨 अन्य काम (Other Work)',
    labelEn: '🔨 Other Work',
    shortNe: '🔨 अन्य काम',
    badgeClass: 'bg-rose-100 text-rose-900 border-rose-300',
    isFieldWork: false,
    defaultSiteNote: ''
  }
];

export const DEFAULT_SITE_PRESETS: string[] = [
  'ग्राहकको टनेल निर्माण साइट',
  'फार्म प्लास्टिक जडान फिल्ड',
  'वर्कसप ट्याक्टर मर्मत कक्ष',
  'ड्रिप तथा पाइप फिटिङ साइट',
  'ग्राहकको खेत / बाहिरी फिल्ड भिजिट'
];

export const NEPALI_MONTHS_LIST = [
  { code: '01', nameNe: 'बैशाख (Baisakh)', nameEn: 'Baisakh (01)' },
  { code: '02', nameNe: 'जेठ (Jestha)', nameEn: 'Jestha (02)' },
  { code: '03', nameNe: 'असार (Ashadh)', nameEn: 'Ashadh (03)' },
  { code: '04', nameNe: 'साउन (Shrawan)', nameEn: 'Shrawan (04)' },
  { code: '05', nameNe: 'भदौ (Bhadra)', nameEn: 'Bhadra (05)' },
  { code: '06', nameNe: 'असोज (Ashwin)', nameEn: 'Ashwin (06)' },
  { code: '07', nameNe: 'कात्तिक (Kartik)', nameEn: 'Kartik (07)' },
  { code: '08', nameNe: 'मङ्सिर (Mangsir)', nameEn: 'Mangsir (08)' },
  { code: '09', nameNe: 'पुस (Poush)', nameEn: 'Poush (09)' },
  { code: '10', nameNe: 'माघ (Magh)', nameEn: 'Magh (10)' },
  { code: '11', nameNe: 'फागुन (Falgun)', nameEn: 'Falgun (11)' },
  { code: '12', nameNe: 'चैत (Chaitra)', nameEn: 'Chaitra (12)' }
];

// Client-side Canvas Image Signature & Face/Photo Similarity Helper (Works offline on Mobile & Desktop)
async function resizeAndGetDataUrl(fileOrBlob: Blob, maxDim = 320): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let w = img.width;
        let h = img.height;
        if (w > h && w > maxDim) {
          h = Math.round((h * maxDim) / w);
          w = maxDim;
        } else if (h >= w && h > maxDim) {
          w = Math.round((w * maxDim) / h);
          h = maxDim;
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(reader.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', 0.82));
      };
      img.onerror = reject;
      img.src = reader.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(fileOrBlob);
  });
}

async function computePhotoSignature(dataUrl: string): Promise<number[]> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const gridSize = 16;
      const canvas = document.createElement('canvas');
      canvas.width = gridSize;
      canvas.height = gridSize;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve([]);
        return;
      }
      // Center-crop square for consistent portrait face framing
      const minSide = Math.min(img.width, img.height);
      const sx = Math.max(0, (img.width - minSide) / 2);
      const sy = Math.max(0, (img.height - minSide) / 2);
      ctx.drawImage(img, sx, sy, minSide, minSide, 0, 0, gridSize, gridSize);
      const { data } = ctx.getImageData(0, 0, gridSize, gridSize);
      const sig: number[] = [];
      for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
          const idx = (y * gridSize + x) * 4;
          const r = data[idx] / 255;
          const g = data[idx + 1] / 255;
          const b = data[idx + 2] / 255;
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          // Weight central face region higher
          const isCenter = x >= 3 && x <= 12 && y >= 2 && y <= 13;
          const weight = isCenter ? 1.35 : 0.75;
          sig.push(r * weight, g * weight, b * weight, lum * weight);
        }
      }
      resolve(sig);
    };
    img.onerror = () => resolve([]);
    img.src = dataUrl;
  });
}

function calculateSignatureSimilarity(sigA: number[], sigB: number[]): number {
  if (!sigA.length || !sigB.length || sigA.length !== sigB.length) return 0;
  let diffSum = 0;
  for (let i = 0; i < sigA.length; i++) {
    diffSum += Math.abs(sigA[i] - sigB[i]);
  }
  const meanDiff = diffSum / sigA.length;
  // Convert mean normalized difference into intuitive similarity % (0 - 100)
  const rawScore = Math.max(0, Math.min(100, Math.round((1 - meanDiff * 1.45) * 100)));
  return rawScore;
}

export const AttendanceScreen: React.FC = () => {
  const {
    employees,
    attendance,
    employeeLedger,
    saveEmployee,
    recordAttendance,
    bulkRecordAttendance,
    setEmployeeAttendanceStatus,
    enrollEmployeeBiometrics,
    enrollEmployeeFingerprint,
    recordCashAdvance,
    payEmployeeSalary,
    getEmployeePayrollSummary,
    bankAccounts,
    dailyCash,
    company,
    updateCompanyProfile,
    currentRole,
    productionBatches,
    setActiveTab: setGlobalActiveTab,
    language,
    isOnline,
    verifyOwnerPin,
    t
  } = useApp();

  const activeWorkCategories: WorkCategoryConfig[] =
    company.workCategories && company.workCategories.length > 0
      ? company.workCategories
      : WORK_CATEGORIES;

  const activeSitePresets: string[] =
    company.siteLocationPresets && company.siteLocationPresets.length > 0
      ? company.siteLocationPresets
      : DEFAULT_SITE_PRESETS;

  const getWorkCategoryMeta = (cat?: StaffWorkCategory): WorkCategoryConfig => {
    return (
      activeWorkCategories.find((c) => c.id === cat) ||
      WORK_CATEGORIES.find((c) => c.id === cat) ||
      activeWorkCategories[0] ||
      WORK_CATEGORIES[5]
    );
  };

  const openMasterAttendanceSettings = () => {
    if (typeof window !== 'undefined') {
      window.history.replaceState(null, '', '/?tab=settings&sub=work_attendance');
    }
    setGlobalActiveTab('settings');
  };

  const isNe = language === 'ne';
  const todayBs = getTodayBsString();
  const isOwner = currentRole === 'OWNER';

  const [activeTab, setActiveTab] = useState<'ATTENDANCE' | 'PAYROLL_LEDGER' | 'REPORTS'>('ATTENDANCE');
  const [reportType, setReportType] = useState<'STAFF_SUMMARY' | 'DAILY_LOG' | 'ADVANCE' | 'DRIVER' | 'REGISTER'>('STAFF_SUMMARY');

  // Employee creation modal
  const [isAddStaffOpen, setIsAddStaffOpen] = useState(false);
  const [empName, setEmpName] = useState('');
  const [empRole, setEmpRole] = useState('');
  const [empPhone, setEmpPhone] = useState('');
  const [empWageType, setEmpWageType] = useState<'MONTHLY' | 'DAILY'>('MONTHLY');
  const [empSalary, setEmpSalary] = useState<number>(25000);
  const [empDailyWageRate, setEmpDailyWageRate] = useState<number>(1000);
  const [empOpeningDue, setEmpOpeningDue] = useState<number>(0);
  const [empRegisteredPhoto, setEmpRegisteredPhoto] = useState<string>('');
  const [empFingerName, setEmpFingerName] = useState<string>('दायाँ चोरी औँला (Right Index)');

  // Biometric & Photo Pre-Enrollment Modal state
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  const [enrollEmpId, setEnrollEmpId] = useState<string>('');
  const [enrollPhotoUrl, setEnrollPhotoUrl] = useState<string>('');
  const [enrollFingerName, setEnrollFingerName] = useState<string>('दायाँ चोरी औँला (Right Index)');

  // Photo Upload Registration & Camera Face Recognition Modal State (पहिले फोटो अपलोड -> पछि फोटो खिचेर पहिचान)
  const [isPhotoRecognitionOpen, setIsPhotoRecognitionOpen] = useState<boolean>(false);
  const [photoModalMode, setPhotoModalMode] = useState<'RECOGNIZE' | 'UPLOAD_REGISTER'>('RECOGNIZE');
  const [cameraDeviceMode, setCameraDeviceMode] = useState<'user' | 'environment'>('user');
  const [isCameraStreaming, setIsCameraStreaming] = useState<boolean>(false);
  const [cameraErrorMsg, setCameraErrorMsg] = useState<string | null>(null);
  const [capturedLivePhoto, setCapturedLivePhoto] = useState<string>('');
  const [isMatchingPhoto, setIsMatchingPhoto] = useState<boolean>(false);
  const [photoMatchResults, setPhotoMatchResults] = useState<
    { emp: Employee; score: number }[]
  >([]);
  const [recognizedEmpId, setRecognizedEmpId] = useState<string>('');
  const [recognizedClockType, setRecognizedClockType] = useState<'IN' | 'OUT'>('IN');
  const [recognizedWorkCategory, setRecognizedWorkCategory] = useState<StaffWorkCategory>('TUNNEL_MAKING');
  const [recognizedSiteName, setRecognizedSiteName] = useState<string>('');
  const [uploadTargetEmpId, setUploadTargetEmpId] = useState<string>(employees[0]?.id || '');
  const [uploadPreviewPhoto, setUploadPreviewPhoto] = useState<string>('');
  const [photoSuccessBanner, setPhotoSuccessBanner] = useState<string | null>(null);
  const videoRef = React.useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = React.useRef<MediaStream | null>(null);
  const selfCapturedPhotoDataRef = React.useRef<string>('');
  const [selfCapturedPhotoUrl, setSelfCapturedPhotoUrl] = useState<string>('');
  const [selfPhotoMatchScore, setSelfPhotoMatchScore] = useState<number | null>(null);

  const stopLiveCameraStream = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraStreaming(false);
  };

  const startLiveCameraStream = async (facing: 'user' | 'environment' = cameraDeviceMode) => {
    setCameraErrorMsg(null);
    stopLiveCameraStream();
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setCameraErrorMsg(
        language === 'ne'
          ? 'यो ब्राउजरमा लाइभ क्यामेरा उपलब्ध छैन। कृपया तलको "फोटो खिच्नुहोस् / छान्नुहोस्" बटन प्रयोग गर्नुहोस्।'
          : 'Live camera stream unavailable. Please use the Capture / Choose Photo button below.'
      );
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing, width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false
      });
      mediaStreamRef.current = stream;
      setIsCameraStreaming(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      }, 80);
    } catch {
      setCameraErrorMsg(
        language === 'ne'
          ? 'क्यामेरा अनुमति प्राप्त भएन वा वेबक्याम भेटिएन। तलको "📸 मोबाइल/डेस्कटपबाट फोटो खिच्नुहोस् वा छान्नुहोस्" बटनबाट सिधै फोटो हाल्नुहोस्।'
          : 'Camera permission denied or no webcam found. Use the direct Capture/Upload Photo button below.'
      );
    }
  };

  useEffect(() => {
    if (!isPhotoRecognitionOpen) {
      stopLiveCameraStream();
    }
  }, [isPhotoRecognitionOpen]);

  // Run photo recognition against all employees with registeredPhotoUrl
  const runEmployeePhotoRecognition = async (capturedDataUrl: string, preferredEmpId?: string) => {
    setCapturedLivePhoto(capturedDataUrl);
    setIsMatchingPhoto(true);
    setPhotoSuccessBanner(null);
    try {
      const enrolledEmployees = employees.filter((e) => !!e.registeredPhotoUrl);
      if (enrolledEmployees.length === 0) {
        setPhotoMatchResults([]);
        setRecognizedEmpId(preferredEmpId || employees[0]?.id || '');
        return;
      }
      const liveSig = await computePhotoSignature(capturedDataUrl);
      const scored: { emp: Employee; score: number }[] = [];
      for (const emp of enrolledEmployees) {
        if (!emp.registeredPhotoUrl) continue;
        const refSig = await computePhotoSignature(emp.registeredPhotoUrl);
        let score = calculateSignatureSimilarity(liveSig, refSig);
        if (capturedDataUrl === emp.registeredPhotoUrl) {
          score = 100;
        }
        scored.push({ emp, score });
      }
      scored.sort((a, b) => b.score - a.score);
      setPhotoMatchResults(scored);
      if (preferredEmpId && scored.some((s) => s.emp.id === preferredEmpId)) {
        setRecognizedEmpId(preferredEmpId);
      } else if (scored.length > 0) {
        setRecognizedEmpId(scored[0].emp.id);
      }
    } finally {
      setIsMatchingPhoto(false);
    }
  };

  const handleCaptureFromLiveVideo = async () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 320;
    canvas.height = video.videoHeight || 240;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    stopLiveCameraStream();
    if (photoModalMode === 'UPLOAD_REGISTER') {
      setUploadPreviewPhoto(dataUrl);
    } else {
      await runEmployeePhotoRecognition(dataUrl);
    }
  };

  const handleOpenPhotoRecognitionModal = (
    mode: 'RECOGNIZE' | 'UPLOAD_REGISTER' = 'RECOGNIZE',
    targetEmp?: Employee
  ) => {
    setPhotoModalMode(mode);
    setPhotoSuccessBanner(null);
    setCameraErrorMsg(null);
    if (targetEmp) {
      setUploadTargetEmpId(targetEmp.id);
      setRecognizedEmpId(targetEmp.id);
      setUploadPreviewPhoto(targetEmp.registeredPhotoUrl || '');
    } else if (!uploadTargetEmpId && employees.length > 0) {
      setUploadTargetEmpId(employees[0].id);
      setUploadPreviewPhoto(employees[0].registeredPhotoUrl || '');
    }
    setCapturedLivePhoto('');
    setPhotoMatchResults([]);
    setIsPhotoRecognitionOpen(true);
  };

  const handleSaveEmployeeReferencePhoto = (empId: string, photoDataUrl: string) => {
    if (!empId || !photoDataUrl) return;
    enrollEmployeeBiometrics(empId, { photoUrl: photoDataUrl });
    setUploadPreviewPhoto(photoDataUrl); // Sync local state
    const empObj = employees.find((e) => e.id === empId);
    setPhotoSuccessBanner(
      isNe
        ? `✅ "${empObj?.name || ''}" को पहिचान फोटो सफलतापूर्वक दर्ता/अपलोड भयो ! अब क्यामेराबाट फोटो खिचेर पहिचान गरी हाजिरी गर्न सकिन्छ।`
        : `✅ Reference photo registered for "${empObj?.name || ''}"! You can now recognize by capturing a photo.`
    );
  };

  const handleConfirmPhotoRecognizedAttendance = async () => {
    const targetEmp = employees.find((e) => e.id === recognizedEmpId);
    if (!targetEmp) {
       alert(isNe ? 'कर्मचारी छान्नुहोस्!' : 'Please select an employee!');
       return;
    }
    const topMatch = photoMatchResults.find((m) => m.emp.id === targetEmp.id);
    const matchPct = topMatch ? topMatch.score : 0; 
    
    // Allow if verified by match score, even if reference photo is missing in UI
    const workMeta = getWorkCategoryMeta(recognizedWorkCategory);

    // Enforce Geo-fencing
    if (
      company.enforceGpsLocation &&
      (!selfDeviceGps ||
        !isWithinWorkplaceGeofence(
          selfDeviceGps.lat,
          selfDeviceGps.lng,
          company.workplaceLatitude,
          company.workplaceLongitude,
          company.workplaceRadiusMeters || 200
        ).isAllowed)
    ) {
      setCameraErrorMsg(isNe ? 'तपाईँ कार्यस्थल बाहिर हुनुहुन्छ!' : 'You are outside the workplace geofence!');
      return;
    }

    // Compress photo before recording
    const compressedPhoto = capturedLivePhoto ? await resizeAndGetDataUrl(await (await fetch(capturedLivePhoto)).blob(), 480) : targetEmp.registeredPhotoUrl;

    const res = recordAttendance({
      employeeId: targetEmp.id,
      type: recognizedClockType,
      latitude: selfDeviceGps?.lat,
      longitude: selfDeviceGps?.lng,
      locationLabel: recognizedSiteName.trim()
        ? `${workMeta.shortNe} (${recognizedSiteName.trim()}) [फोटो पहिचान ${matchPct}%]`
        : `${workMeta.shortNe} [फोटो पहिचान ${matchPct}%]`,
      photoUrl: compressedPhoto,
      deviceType: /Mobi|Android|iPhone/i.test(navigator.userAgent) ? 'MOBILE' : 'DESKTOP',
      verificationMethod: 'FACE_PHOTO',
      workCategory: recognizedWorkCategory,
      workDescription: `${workMeta.shortNe} (फोटो पहिचान ${matchPct}%)`,
      siteOrClientName: recognizedSiteName.trim() || undefined,
      customDateBs: selectedAttendanceDateBs
    });

    if (res && !res.success) {
      setCameraErrorMsg(res.message);
      return;
    }

    setPhotoSuccessBanner(
      isNe
        ? `🎉 पहिचान सफल (${matchPct}% मिलान): ${targetEmp.name} को ${recognizedClockType === 'IN' ? 'Log In (आगमन)' : 'Log Out (प्रस्थान)'} हाजिरी दर्ता भयो !`
        : `🎉 Recognized (${matchPct}% Match): ${targetEmp.name} ${recognizedClockType} attendance recorded!`
    );
  };

  // Daily Wage / Monthly Salary Payout Modal State
  const [isSalaryModalOpen, setIsSalaryModalOpen] = useState(false);
  const [salaryEmpId, setSalaryEmpId] = useState<string>('');
  const [salaryWageType, setSalaryWageType] = useState<'MONTHLY' | 'DAILY'>('DAILY');
  const [salaryDaysWorked, setSalaryDaysWorked] = useState<number>(1);
  const [salaryDailyRate, setSalaryDailyRate] = useState<number>(1000);
  const [salaryAmount, setSalaryAmount] = useState<number>(1000);
  const [salaryDeductAdvance, setSalaryDeductAdvance] = useState<number>(0);
  const [salaryPaymentMode, setSalaryPaymentMode] = useState<'CASH' | 'BANK'>('CASH');
  const [salaryBankAccountId, setSalaryBankAccountId] = useState<string>(bankAccounts[0]?.id || '');
  const [salaryNotes, setSalaryNotes] = useState<string>('');

  // Monthly & Annual Reports Filter State (defaults to current B.S. year & month)
  const defaultYearBs = todayBs.split('-')[0] || '2083';
  const defaultMonthBs = todayBs.split('-')[1] || '07';
  const [reportYear, setReportYear] = useState<string>(defaultYearBs);
  const [reportMonth, setReportMonth] = useState<string>(defaultMonthBs);
  const [reportEmployeeId, setReportEmployeeId] = useState<string>('ALL');

  // Selected date for daily/work-based attendance entry
  const [selectedAttendanceDateBs, setSelectedAttendanceDateBs] = useState<string>(todayBs);
  const [quickEmpId, setQuickEmpId] = useState<string>(employees[0]?.id || 'ALL');
  const [quickWorkCategory, setQuickWorkCategory] = useState<StaffWorkCategory>('TUNNEL_MAKING');
  const [quickSiteOrClient, setQuickSiteOrClient] = useState<string>('');
  const [quickWorkNotes, setQuickWorkNotes] = useState<string>('');

  // Per-card quick inputs for site/client name
  const [cardSiteInputs, setCardSiteInputs] = useState<Record<string, string>>({});

  // Printable Monthly Staff Attendance Sheet Modal State (स्टाफलाई दिन मिल्ने महिनाभरिको हाजिरी सिट)
  const [isMonthlySheetModalOpen, setIsMonthlySheetModalOpen] = useState<boolean>(false);
  const [sheetYear, setSheetYear] = useState<string>(defaultYearBs);
  const [sheetMonth, setSheetMonth] = useState<string>(defaultMonthBs);
  const [sheetEmpId, setSheetEmpId] = useState<string>(employees[0]?.id || 'ALL');
  const [sheetShowFullCalendarDays, setSheetShowFullCalendarDays] = useState<boolean>(true);
  const [sheetShowWageSummary, setSheetShowWageSummary] = useState<boolean>(true);

  // Shareable Link Generator Modal State (स्टाफ हाजिरी तथा मालिक पोर्टल लिंक)
  const [isLinkModalOpen, setIsLinkModalOpen] = useState<boolean>(false);
  const [linkEmpId, setLinkEmpId] = useState<string>(employees[0]?.id || 'ALL');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const baseAppUrl =
    typeof window !== 'undefined' && window.location.origin
      ? window.location.origin
      : 'https://ais-pre-4wcnbnzz5cmaf6s6n5ud5c-301709447959.asia-southeast1.run.app';

  const handleCopyLink = (url: string, key: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2500);
    }
  };

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const urlEmpId = params.get('empId');
    const urlSheet = params.get('sheet');
    const urlWorkCat = params.get('workCat');
    const urlSubTab = params.get('subTab');

    if (urlWorkCat) {
      setQuickWorkCategory(urlWorkCat);
      setSelfWorkCategory(urlWorkCat);
      setSupervisorWorkCategory(urlWorkCat);
      const found = activeWorkCategories.find((c) => c.id === urlWorkCat);
      if (found?.defaultSiteNote) {
        setQuickSiteOrClient(found.defaultSiteNote);
      }
      setActiveTab('ATTENDANCE');
    }

    if (urlSubTab === 'PAYROLL_LEDGER' || urlSubTab === 'REPORTS' || urlSubTab === 'ATTENDANCE') {
      setActiveTab(urlSubTab);
    }

    if (urlEmpId && employees.some((e) => e.id === urlEmpId)) {
      setQuickEmpId(urlEmpId);
      setSelfClockEmpId(urlEmpId);
      setSheetEmpId(urlEmpId);
      setLinkEmpId(urlEmpId);
      if (urlSheet === '1' || urlSheet === 'true') {
        setIsMonthlySheetModalOpen(true);
      }
    } else if (urlSheet === '1' || urlSheet === 'true') {
      setIsMonthlySheetModalOpen(true);
    }

    const handleSubNav = (evt: Event) => {
      const customEvt = evt as CustomEvent<{
        target?: string;
        workCat?: string;
        subTab?: 'ATTENDANCE' | 'PAYROLL_LEDGER' | 'REPORTS';
        openMonthlySheet?: boolean;
      }>;
      if (customEvt.detail?.target !== 'attendance') return;
      if (customEvt.detail.workCat) {
        const catId = customEvt.detail.workCat;
        setQuickWorkCategory(catId);
        setSelfWorkCategory(catId);
        setSupervisorWorkCategory(catId);
        const found = activeWorkCategories.find((c) => c.id === catId);
        if (found?.defaultSiteNote) {
          setQuickSiteOrClient(found.defaultSiteNote);
        }
      }
      if (customEvt.detail.subTab) {
        setActiveTab(customEvt.detail.subTab);
      }
      if (customEvt.detail.openMonthlySheet) {
        setIsMonthlySheetModalOpen(true);
      }
    };

    window.addEventListener('ims-sub-nav', handleSubNav);
    return () => window.removeEventListener('ims-sub-nav', handleSubNav);
  }, [employees, activeWorkCategories]);

  // Cash Advance Modal state
  const [isAdvanceModalOpen, setIsAdvanceModalOpen] = useState(false);
  const [advanceEmpId, setAdvanceEmpId] = useState<string>('');
  const [advanceAmount, setAdvanceAmount] = useState<number>(1000);
  const [advanceNotes, setAdvanceNotes] = useState<string>('');

  // Selected Employee for Detailed Ledger Statement
  const [viewingLedgerEmpId, setViewingLedgerEmpId] = useState<string | null>(null);

  // Owner Workplace GPS Setting State
  const [isSettingWorkplaceGps, setIsSettingWorkplaceGps] = useState(false);
  const [workplaceRadius, setWorkplaceRadius] = useState<number>(
    company.workplaceRadiusMeters || 200
  );
  const [workplaceLabel, setWorkplaceLabel] = useState<string>(
    company.workplaceLocationLabel || 'कृषियन्त्र मुख्य वर्कसप तथा काउन्टर'
  );
  const [enforceGeofence, setEnforceGeofence] = useState<boolean>(
    company.enforceGpsLocation !== undefined ? company.enforceGpsLocation : true
  );

  // Owner Shift Timing Setting State
  const [shiftStart, setShiftStart] = useState<string>(company.shiftStartTime || '10:00 AM');
  const [shiftEnd, setShiftEnd] = useState<string>(company.shiftEndTime || '05:00 PM');
  const [autoShiftTime, setAutoShiftTime] = useState<boolean>(
    company.autoSetShiftTime !== undefined ? company.autoSetShiftTime : true
  );
  const [isShiftModalOpen, setIsShiftModalOpen] = useState(false);

  // Mobile Self-Attendance Modal State (आफ्नो मोबाइलबाट हाजिरी)
  const [isMobileClockInOpen, setIsMobileClockInOpen] = useState(false);
  const [selfClockEmpId, setSelfClockEmpId] = useState<string>(employees[0]?.id || '');
  const [selfClockType, setSelfClockType] = useState<'IN' | 'OUT'>('IN');
  const [selfWorkCategory, setSelfWorkCategory] = useState<StaffWorkCategory>('TUNNEL_MAKING');
  const [selfSiteOrClient, setSelfSiteOrClient] = useState<string>('');
  const [selfWorkDescription, setSelfWorkDescription] = useState<string>('');
  const [selfDeviceGps, setSelfDeviceGps] = useState<{ lat: number; lng: number } | null>(null);
  const [selfGpsLoading, setSelfGpsLoading] = useState(false);
  const [selfPhotoCaptured, setSelfPhotoCaptured] = useState(false);
  const [selfBiometricVerified, setSelfBiometricVerified] = useState(false);
  const [selfGpsResult, setSelfGpsResult] = useState<{
    isAllowed: boolean;
    distanceMeters: number;
    messageNe: string;
    messageEn: string;
  } | null>(null);

  // Supervisor Bulk Attendance State (कुनै एक जनाले सबैको फोटो/फिंगर खिचेर हाजिर)
  const [isSupervisorModalOpen, setIsSupervisorModalOpen] = useState(false);
  const [supervisorEmpId, setSupervisorEmpId] = useState<string>(employees[0]?.id || '');
  const [selectedEmpIds, setSelectedEmpIds] = useState<string[]>(employees.map((e) => e.id));
  const [supervisorType, setSupervisorType] = useState<'IN' | 'OUT'>('IN');
  const [supervisorWorkCategory, setSupervisorWorkCategory] = useState<StaffWorkCategory>('TUNNEL_MAKING');
  const [supervisorSiteOrClient, setSupervisorSiteOrClient] = useState<string>('');
  const [supervisorBiometricVerified, setSupervisorBiometricVerified] = useState(false);
  const [supervisorPhotoCaptured, setSupervisorPhotoCaptured] = useState(false);

  // Owner Override for No-GPS Attendance Modal (मालिक अनुमतिमा विना location हाजिरी)
  const [isOwnerOverrideModalOpen, setIsOwnerOverrideModalOpen] = useState(false);
  const [ownerOverridePin, setOwnerOverridePin] = useState('');
  const [ownerOverrideError, setOwnerOverrideError] = useState<string | null>(null);



  // Submit Owner Override Attendance (bypasses GPS location checks)
  const handleOwnerOverrideSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setOwnerOverrideError(null);

    if (!ownerOverridePin) {
      setOwnerOverrideError(isNe ? 'कृपया मालिक PIN प्रविष्ट गर्नुहोस्।' : 'Please enter Owner PIN.');
      return;
    }

    const isValid = verifyOwnerPin(ownerOverridePin.trim());
    if (!isValid) {
      setOwnerOverrideError(isNe ? 'गलत मालिक PIN!' : 'Incorrect Owner PIN!');
      return;
    }

    const effectiveTime = company.autoSetShiftTime
      ? (selfClockType === 'IN' ? company.shiftStartTime || '10:00 AM' : company.shiftEndTime || '05:00 PM')
      : currentLiveTime;

    const result = recordAttendance({
      employeeId: selfClockEmpId,
      type: selfClockType,
      latitude: selfDeviceGps?.lat,
      longitude: selfDeviceGps?.lng,
      locationLabel: selfSiteOrClient.trim()
        ? `${getWorkCategoryMeta(selfWorkCategory).shortNe} - ${selfSiteOrClient.trim()}`
        : isNe ? 'मालिक अनुमति (विना Location)' : 'Owner Approved (No GPS)',
      photoUrl: selfPhotoCaptured ? 'https://avatar.iran.liara.run/public' : undefined,
      deviceType: 'MOBILE',
      verificationMethod: 'MANUAL_SUPERVISOR',
      workCategory: selfWorkCategory,
      workDescription: selfWorkDescription.trim() || getWorkCategoryMeta(selfWorkCategory).shortNe,
      siteOrClientName: selfSiteOrClient.trim() || undefined,
      customDateBs: selectedAttendanceDateBs
    });

    if (result && !result.success) {
      setOwnerOverrideError(result.message);
      return;
    }

    setIsOwnerOverrideModalOpen(false);
    setIsMobileClockInOpen(false);
    setOwnerOverridePin('');
    setOwnerOverrideError(null);
    alert(
      isNe
        ? `मालिकको स्वीकृतिमा विना लोकेसन हाजिरी (${selfClockType === 'IN' ? 'Log In' : 'Log Out'}) ${effectiveTime} मा सफलताका साथ दर्ता भयो !`
        : `Attendance recorded with owner approval (No GPS)!`
    );
  };

  // Live Auto Time
  const [currentLiveTime, setCurrentLiveTime] = useState<string>('');
  useEffect(() => {
    const updateTime = () => {
      setCurrentLiveTime(
        new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Offline Sync trigger on reconnect
  const [syncNotice, setSyncNotice] = useState<string | null>(null);
  useEffect(() => {
    const handleOnline = () => {
      setSyncNotice(isNe ? 'इन्टरनेट जोडियो! अफलाइन हाजिरी स्वतः सिंक भयो।' : 'Online! Attendance records synced.');
      setTimeout(() => setSyncNotice(null), 4000);
    };
    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, [isNe]);

  // Set Current Device Location as Workplace GPS (Owner action)
  const handlePinCurrentLocationAsWorkplace = async () => {
    setIsSettingWorkplaceGps(true);
    try {
      const gps = await getCurrentDeviceGps();
      updateCompanyProfile({
        ...company,
        workplaceLatitude: gps.lat,
        workplaceLongitude: gps.lng,
        workplaceRadiusMeters: workplaceRadius,
        workplaceLocationLabel: workplaceLabel,
        enforceGpsLocation: enforceGeofence
      });
      alert(
        isNe
          ? `कार्यस्थलको GPS स्थान (${gps.lat}, ${gps.lng}) र परिधि (${workplaceRadius} मिटर) सफलतापूर्वक सेट गरियो !`
          : `Workplace location and radius set successfully!`
      );
    } catch {
      alert(isNe ? 'GPS स्थान प्राप्त गर्न सकिएन।' : 'Failed to retrieve GPS.');
    } finally {
      setIsSettingWorkplaceGps(false);
    }
  };

  // Save Shift Timing Settings
  const handleSaveShiftSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompanyProfile({
      ...company,
      shiftStartTime: shiftStart.trim(),
      shiftEndTime: shiftEnd.trim(),
      autoSetShiftTime: autoShiftTime
    });
    setIsShiftModalOpen(false);
    alert(isNe ? 'हाजिरी समय तालिका सुरक्षित गरियो !' : 'Shift timing saved!');
  };

  // Open Mobile Self-Attendance modal and fetch GPS
  const handleOpenMobileClockIn = async (defaultEmp?: Employee, defaultType?: 'IN' | 'OUT') => {
    const targetId = defaultEmp ? defaultEmp.id : (employees[0]?.id || '');
    setSelfClockEmpId(targetId);
    if (defaultType) setSelfClockType(defaultType);
    const existingRec = attendance.find(
      (a) => a.employeeId === targetId && a.dateBs === selectedAttendanceDateBs
    );
    if (existingRec?.workCategory) {
      setSelfWorkCategory(existingRec.workCategory);
    }
    setSelfSiteOrClient(existingRec?.siteOrClientName || cardSiteInputs[targetId] || '');
    setSelfWorkDescription(existingRec?.workDescription || '');
    setSelfPhotoCaptured(false);
    setSelfBiometricVerified(false);
    setIsMobileClockInOpen(true);
    setSelfGpsLoading(true);

    try {
      const gps = await getCurrentDeviceGps();
      setSelfDeviceGps(gps);

      const check = isWithinWorkplaceGeofence(
        gps.lat,
        gps.lng,
        company.workplaceLatitude,
        company.workplaceLongitude,
        company.workplaceRadiusMeters || 200
      );
      setSelfGpsResult(check);
    } catch {
      setSelfDeviceGps({ lat: 27.7172, lng: 85.3240 });
    } finally {
      setSelfGpsLoading(false);
    }
  };

  // Execute Mobile Self-Attendance Clock-In / Out
  const handleConfirmMobileClockIn = () => {
    if (!selfClockEmpId) return;

    const workMeta = getWorkCategoryMeta(selfWorkCategory);
    const isFieldOrOutsideWork = !!workMeta.isFieldWork;

    // Check geofence enforcement (bypass strict workshop radius when going to client site / field work)
    if (
      !isFieldOrOutsideWork &&
      company.enforceGpsLocation &&
      company.workplaceLatitude &&
      selfGpsResult &&
      !selfGpsResult.isAllowed
    ) {
      if (
        confirm(
          isNe
            ? `${selfGpsResult.messageNe}\n\nके तपाईं मालिकको अनुमति/PIN प्रयोग गरी विना लोकेसन (No GPS) हाजिर गर्न चाहनुहुन्छ?`
            : `${selfGpsResult.messageEn}\n\nDo you want to clock in with Owner PIN approval (No GPS)?`
        )
      ) {
        setOwnerOverridePin('');
        setOwnerOverrideError(null);
        setIsOwnerOverrideModalOpen(true);
      }
      return;
    }

    const effectiveTime = company.autoSetShiftTime
      ? (selfClockType === 'IN' ? company.shiftStartTime || '10:00 AM' : company.shiftEndTime || '05:00 PM')
      : currentLiveTime;

    const result = recordAttendance({
      employeeId: selfClockEmpId,
      type: selfClockType,
      latitude: selfDeviceGps?.lat,
      longitude: selfDeviceGps?.lng,
      locationLabel: selfSiteOrClient.trim()
        ? `${workMeta.shortNe} (${selfSiteOrClient.trim()})`
        : workMeta.shortNe || company.workplaceLocationLabel || 'कार्यस्थल (Store HQ)',
      photoUrl: selfCapturedPhotoUrl || selfCapturedPhotoDataRef.current || (selfPhotoCaptured ? 'https://avatar.iran.liara.run/public' : undefined),
      deviceType: 'MOBILE',
      verificationMethod: selfPhotoCaptured ? 'FACE_PHOTO' : 'GPS_AUTO',
      workCategory: selfWorkCategory,
      workDescription: selfWorkDescription.trim() || workMeta.shortNe,
      siteOrClientName: selfSiteOrClient.trim() || undefined,
      customDateBs: selectedAttendanceDateBs
    });

    if (result && !result.success) {
      alert(result.message);
      return;
    }

    setIsMobileClockInOpen(false);
    alert(
      isNe
        ? `हाजिरी (${selfClockType === 'IN' ? 'Log In' : 'Log Out'} - ${workMeta.shortNe}) समय ${effectiveTime} मा सफलतापूर्वक दर्ता भयो !`
        : `Attendance recorded successfully!`
    );
  };

  // Quick Work-Based Attendance Entry Handler
  const handleQuickWorkAttendanceSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (employees.length === 0) {
      alert(isNe ? 'पहिले कर्मचारी थप्नुहोस्।' : 'Add employee first.');
      return;
    }
    const workMeta = getWorkCategoryMeta(quickWorkCategory);
    const targetEmps =
      quickEmpId === 'ALL'
        ? employees
        : employees.filter((emp) => emp.id === quickEmpId);

    if (targetEmps.length === 0) return;

    targetEmps.forEach((emp) => {
      setEmployeeAttendanceStatus(emp.id, 'PRESENT', undefined, {
        workCategory: quickWorkCategory,
        workDescription: quickWorkNotes.trim() || workMeta.shortNe,
        siteOrClientName: quickSiteOrClient.trim() || undefined,
        customDateBs: selectedAttendanceDateBs
      });
    });

    alert(
      isNe
        ? `मिति ${selectedAttendanceDateBs} को लागि ${
            quickEmpId === 'ALL' ? `सबै (${targetEmps.length} जना)` : targetEmps[0].name
          } को "${workMeta.shortNe}"${
            quickSiteOrClient.trim() ? ` (${quickSiteOrClient.trim()})` : ''
          } हाजिरी दर्ता भयो !`
        : `Work attendance (${workMeta.labelEn}) recorded for ${selectedAttendanceDateBs}!`
    );
    setQuickWorkNotes('');
  };

  // Supervisor bulk attendance execution
  const handleConfirmSupervisorAttendance = () => {
    if (selectedEmpIds.length === 0) {
      alert(isNe ? 'कम्तीमा एक जना कर्मचारी छान्नुहोस्।' : 'Select at least one employee.');
      return;
    }

    const effectiveTime = company.autoSetShiftTime
      ? (supervisorType === 'IN' ? company.shiftStartTime || '10:00 AM' : company.shiftEndTime || '05:00 PM')
      : currentLiveTime;

    const supervisor = employees.find((e) => e.id === supervisorEmpId);
    const workMeta = getWorkCategoryMeta(supervisorWorkCategory);
    bulkRecordAttendance({
      employeeIds: selectedEmpIds,
      type: supervisorType,
      photoUrl: supervisorPhotoCaptured ? 'https://avatar.iran.liara.run/public' : undefined,
      locationLabel: supervisorSiteOrClient.trim()
        ? `${workMeta.shortNe} - ${supervisorSiteOrClient.trim()}`
        : supervisor
        ? `${supervisor.name} (${workMeta.shortNe})`
        : workMeta.shortNe,
      workCategory: supervisorWorkCategory,
      workDescription: workMeta.shortNe,
      siteOrClientName: supervisorSiteOrClient.trim() || undefined,
      customDateBs: selectedAttendanceDateBs
    });

    setIsSupervisorModalOpen(false);
    setSupervisorBiometricVerified(false);
    setSupervisorPhotoCaptured(false);
    alert(
      isNe
        ? `${selectedEmpIds.length} जना कर्मचारीको ${supervisorType === 'IN' ? 'Log In' : 'Log Out'} (${workMeta.shortNe} - ${effectiveTime}) दर्ता भयो !`
        : `Attendance recorded!`
    );
  };

  // Open Daily Wage or Salary Payout Modal
  const handleOpenSalaryModal = (emp: Employee, defaultWageType?: 'DAILY' | 'MONTHLY') => {
    const summary = getEmployeePayrollSummary(emp.id);
    const wageType = defaultWageType || emp.wageType || 'DAILY';
    const dailyRate = emp.dailyWageRate || Math.round(emp.salaryMonthly / 30) || 1000;
    const days = summary.presentDays > 0 ? summary.presentDays : 1;
    const gross = wageType === 'DAILY' ? days * dailyRate : emp.salaryMonthly;
    const pendingDeductions = summary.totalDeductions;
    const net = Math.max(0, gross - pendingDeductions);

    setSalaryEmpId(emp.id);
    setSalaryWageType(wageType);
    setSalaryDaysWorked(days);
    setSalaryDailyRate(dailyRate);
    setSalaryAmount(net > 0 ? net : gross);
    setSalaryDeductAdvance(Math.min(pendingDeductions, gross));
    setSalaryPaymentMode('CASH');
    setSalaryBankAccountId(bankAccounts[0]?.id || '');
    setSalaryNotes(
      isNe
        ? `${emp.name} लाई ${wageType === 'DAILY' ? `${days} दिनको दैनिक ज्याला` : 'मासिक तलब'} भुक्तानी`
        : `Payout for ${emp.name}`
    );
    setIsSalaryModalOpen(true);
  };

  // Confirm and submit salary / daily wage payout
  const handleConfirmSalaryPayout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!salaryEmpId || salaryAmount <= 0) {
      alert(isNe ? 'कृपया भुक्तानी रकम प्रविष्ट गर्नुहोस्।' : 'Please enter payment amount.');
      return;
    }
    const emp = employees.find((e) => e.id === salaryEmpId);
    if (!emp) return;

    payEmployeeSalary({
      employeeId: salaryEmpId,
      amount: salaryAmount,
      paymentMode: salaryPaymentMode,
      bankAccountId: salaryPaymentMode === 'BANK' ? salaryBankAccountId : undefined,
      wageType: salaryWageType,
      daysWorked: salaryWageType === 'DAILY' ? salaryDaysWorked : undefined,
      notes: salaryNotes
    });

    setIsSalaryModalOpen(false);
    alert(
      isNe
        ? `सफल भयो! ${emp.name} लाई रु. ${salaryAmount.toLocaleString()} ${
            salaryWageType === 'DAILY' ? 'दैनिक ज्याला' : 'मासिक तलब'
          } ${salaryPaymentMode === 'BANK' ? 'बैंकमार्फत' : 'नगद काउन्टरबाट'} भुक्तानी दर्ता भयो।`
        : `Payment of Rs. ${salaryAmount} recorded successfully!`
    );
  };

  // Monthly & Annual Report calculations
  const reportPrefix = reportMonth === 'ALL' ? `${reportYear}-` : `${reportYear}-${reportMonth}`;
  const filteredReportEmployees = reportEmployeeId === 'ALL'
    ? employees
    : employees.filter((e) => e.id === reportEmployeeId);

  const filteredReportRows = useMemo(() => {
    return filteredReportEmployees.map((emp) => {
      const presentDays = attendance.filter(
        (a) => a.employeeId === emp.id && a.status === 'PRESENT' && a.dateBs.startsWith(reportPrefix)
      ).length;

      const empLedgerPeriod = employeeLedger.filter(
        (l) => l.employeeId === emp.id && l.dateBs.startsWith(reportPrefix)
      );

      const isDaily = emp.wageType === 'DAILY';
      const dailyRate = emp.dailyWageRate || Math.round(emp.salaryMonthly / 30) || 1000;
      
      const grossSalary = isDaily
        ? presentDays * dailyRate
        : (reportMonth === 'ALL' ? emp.salaryMonthly * 12 : emp.salaryMonthly);

      const cashAdvances = empLedgerPeriod
        .filter((l) => l.type === 'CASH_ADVANCE')
        .reduce((sum, l) => sum + l.amount, 0);

      const storePurchases = empLedgerPeriod
        .filter((l) => l.type === 'PURCHASE_DEDUCTION')
        .reduce((sum, l) => sum + l.amount, 0);

      const deductions = cashAdvances + storePurchases;

      const salaryPaid = empLedgerPeriod
        .filter((l) => l.type === 'SALARY_PAYMENT')
        .reduce((sum, l) => sum + l.amount, 0);

      const netPayable = Math.max(0, grossSalary - deductions - salaryPaid);

      return {
        emp,
        presentDays,
        grossSalary,
        cashAdvances,
        storePurchases,
        deductions,
        salaryPaid,
        netPayable
      };
    });
  }, [filteredReportEmployees, attendance, employeeLedger, reportPrefix, reportMonth]);

  // Advance Report Logic
  const advanceReportRows = useMemo(() => {
    return employeeLedger
      .filter((entry) => {
        if (entry.type !== 'CASH_ADVANCE') return false;
        if (reportEmployeeId !== 'ALL' && entry.employeeId !== reportEmployeeId) return false;
        return entry.dateBs.startsWith(reportPrefix);
      })
      .sort((a, b) => b.dateBs.localeCompare(a.dateBs));
  }, [employeeLedger, reportPrefix, reportEmployeeId]);

  // Driver Report Logic (from production batches dispatches)
  const driverReportRows = useMemo(() => {
    const allDispatches: (any & { batchName: string })[] = [];
    productionBatches.forEach((batch) => {
      if (batch.dispatches) {
        batch.dispatches.forEach((d) => {
          allDispatches.push({ ...d, batchName: isNe ? batch.productNameNe : batch.productNameEn });
        });
      }
    });

    return allDispatches
      .filter((d) => d.dispatchDateBs.startsWith(reportPrefix))
      .sort((a, b) => b.dispatchDateBs.localeCompare(a.dispatchDateBs));
  }, [productionBatches, reportPrefix, isNe]);

  // Daily Attendance Log Logic
  const dailyAttendanceLog = useMemo(() => {
    return attendance
      .filter((a) => {
        if (reportEmployeeId !== 'ALL' && a.employeeId !== reportEmployeeId) return false;
        return a.dateBs.startsWith(reportPrefix);
      })
      .sort((a, b) => b.dateBs.localeCompare(a.dateBs) || b.checkInTime.localeCompare(a.checkInTime));
  }, [attendance, reportPrefix, reportEmployeeId]);

  const reportTotalPresentDays = filteredReportRows.reduce((s, r) => s + r.presentDays, 0);
  const reportTotalGross = filteredReportRows.reduce((s, r) => s + r.grossSalary, 0);
  const reportTotalDeductions = filteredReportRows.reduce((s, r) => s + r.deductions, 0);
  const reportTotalPaid = filteredReportRows.reduce((s, r) => s + r.salaryPaid, 0);
  const reportTotalNetPayable = filteredReportRows.reduce((s, r) => s + r.netPayable, 0);

  const exportPayrollReportToExcel = () => {
    if (filteredReportRows.length === 0) {
      alert(isNe ? 'डाउनलोड गर्न कुनै विवरण छैन।' : 'No data to export.');
      return;
    }
    const dataToExport = filteredReportRows.map((row, idx) => ({
      'क्र.सं.': idx + 1,
      'कर्मचारीको नाम': row.emp.name,
      'पद': row.emp.role,
      'ज्याला प्रकार': row.emp.wageType === 'DAILY' ? 'दैनिक ज्याला' : 'मासिक तलब',
      'दर (रु.)': row.emp.wageType === 'DAILY' ? row.emp.dailyWageRate || 1000 : row.emp.salaryMonthly,
      'हाजिरी दिन': row.presentDays,
      'कुल ज्याला/तलब (रु.)': row.grossSalary,
      'पेस्की तथा खरिद कट्टा (रु.)': row.deductions,
      'भुक्तानी भएको (रु.)': row.salaryPaid,
      'खुद बाँकी रकम (रु.)': row.netPayable
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Employee_Report');
    XLSX.writeFile(
      workbook,
      `Employee_Report_${reportYear}_${reportMonth === 'ALL' ? 'Annual' : reportMonth}.xlsx`
    );
  };

  // Open Printable Monthly Staff Sheet Modal for a specific employee or all
  const handleOpenMonthlySheetModal = (empId?: string, yearOverride?: string, monthOverride?: string) => {
    if (empId) {
      setSheetEmpId(empId);
    } else if (!sheetEmpId && employees.length > 0) {
      setSheetEmpId(employees[0].id);
    }
    if (yearOverride) setSheetYear(yearOverride);
    if (monthOverride && monthOverride !== 'ALL') setSheetMonth(monthOverride);
    setIsMonthlySheetModalOpen(true);
  };

  // Helper to build monthly attendance rows for an employee
  const buildStaffMonthlySheetData = (emp: Employee, yearStr: string, monthStr: string) => {
    const prefix = `${yearStr}-${monthStr}`;
    const empMonthRecords = attendance
      .filter((a) => a.employeeId === emp.id && a.dateBs.startsWith(prefix))
      .sort((a, b) => a.dateBs.localeCompare(b.dateBs));

    const recordByDate = new Map<string, AttendanceRecord>();
    empMonthRecords.forEach((r) => recordByDate.set(r.dateBs, r));

    // Build either 1..30 days or recorded days
    const dayRows: {
      dayNum: number;
      dateBs: string;
      record?: AttendanceRecord;
    }[] = [];

    if (sheetShowFullCalendarDays) {
      for (let d = 1; d <= 30; d++) {
        const dStr = String(d).padStart(2, '0');
        const fullDateBs = `${yearStr}-${monthStr}-${dStr}`;
        dayRows.push({
          dayNum: d,
          dateBs: fullDateBs,
          record: recordByDate.get(fullDateBs)
        });
      }
      // Also include day 31 or 32 if recorded
      for (let d = 31; d <= 32; d++) {
        const dStr = String(d).padStart(2, '0');
        const fullDateBs = `${yearStr}-${monthStr}-${dStr}`;
        if (recordByDate.has(fullDateBs)) {
          dayRows.push({
            dayNum: d,
            dateBs: fullDateBs,
            record: recordByDate.get(fullDateBs)
          });
        }
      }
    } else {
      empMonthRecords.forEach((rec, idx) => {
        const parts = rec.dateBs.split('-');
        const dayNum = parseInt(parts[2] || String(idx + 1), 10);
        dayRows.push({
          dayNum,
          dateBs: rec.dateBs,
          record: rec
        });
      });
    }

    const presentRecords = empMonthRecords.filter((r) => r.status === 'PRESENT');
    const presentDays = presentRecords.length;

    const categoryCounts: Record<string, number> = {};
    activeWorkCategories.forEach((c) => {
      categoryCounts[c.id] = 0;
    });

    presentRecords.forEach((r) => {
      const cat = r.workCategory || 'WORKSHOP_REGULAR';
      categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;
    });

    const empLedgerPeriod = employeeLedger.filter(
      (l) => l.employeeId === emp.id && l.dateBs.startsWith(prefix)
    );

    const isDaily = emp.wageType === 'DAILY';
    const dailyRate = emp.dailyWageRate || Math.round(emp.salaryMonthly / 30) || 1000;
    const grossSalary = isDaily ? presentDays * dailyRate : emp.salaryMonthly;

    const cashAdvances = empLedgerPeriod
      .filter((l) => l.type === 'CASH_ADVANCE')
      .reduce((sum, l) => sum + l.amount, 0);
    const storePurchases = empLedgerPeriod
      .filter((l) => l.type === 'PURCHASE_DEDUCTION')
      .reduce((sum, l) => sum + l.amount, 0);
    const deductions = cashAdvances + storePurchases;
    const salaryPaid = empLedgerPeriod
      .filter((l) => l.type === 'SALARY_PAYMENT')
      .reduce((sum, l) => sum + l.amount, 0);
    const netPayable = Math.max(0, grossSalary - deductions - salaryPaid);

    return {
      emp,
      dayRows,
      presentDays,
      categoryCounts,
      isDaily,
      dailyRate,
      grossSalary,
      cashAdvances,
      storePurchases,
      deductions,
      salaryPaid,
      netPayable
    };
  };

  // Print Monthly Staff Attendance Card (स्टाफलाई दिन मिल्ने गरी प्रिन्ट)
  const handlePrintMonthlyStaffSheet = () => {
    printPage();
  };

  return (
    <div className="space-y-5 pb-16 max-w-6xl mx-auto">
      
      {/* Offline / Online Sync Alert Banner */}
      {syncNotice && (
        <div className="p-3 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center justify-between shadow-xs animate-fadeIn">
          <div className="flex items-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>{syncNotice}</span>
          </div>
          <button onClick={() => setSyncNotice(null)} className="p-1 hover:bg-emerald-700 rounded">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-emerald-700" />
            <span>{isNe ? 'कर्मचारी हाजिरी तथा तलब व्यवस्थापन' : 'Staff Attendance & Payroll'}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {isNe
              ? 'मालिकले तोकेको GPS स्थान र समय अनुसार मोबाइल तथा सामूहिक हाजिरी (एक दिनमा एक पटक Log In/Out)'
              : 'GPS Geofenced Mobile Attendance with Single Daily Clock In/Out & Offline Sync'}
          </p>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          {/* Step 1 & 2: Upload Photo First & Recognize via Mobile/Desktop Camera */}
          <button
            onClick={() => handleOpenPhotoRecognitionModal('RECOGNIZE')}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-extrabold rounded-xl shadow-xs transition cursor-pointer ring-2 ring-indigo-400/30"
          >
            <Camera className="w-4 h-4 text-amber-300" />
            <span>
              {isNe
                ? '📸 फोटो पहिचान हाजिरी (Mobile / Desktop Camera)'
                : '📸 Photo Recognition Clock-In'}
            </span>
          </button>

          <button
            onClick={() => handleOpenPhotoRecognitionModal('UPLOAD_REGISTER')}
            className="flex items-center gap-1.5 px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 text-xs font-bold rounded-xl shadow-2xs transition cursor-pointer"
          >
            <Camera className="w-4 h-4 text-amber-700" />
            <span>
              {isNe
                ? `१. पहिले फोटो अपलोड (${employees.filter((e) => !!e.registeredPhotoUrl).length}/${employees.length})`
                : `1. Upload Staff Photo (${employees.filter((e) => !!e.registeredPhotoUrl).length}/${employees.length})`}
            </span>
          </button>

          {/* Mobile Self Attendance Button */}
          <button
            onClick={() => handleOpenMobileClockIn()}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
          >
            <Smartphone className="w-4 h-4 text-emerald-300" />
            <span>{isNe ? 'मोबाइलबाट हाजिर' : 'Mobile Clock-In'}</span>
          </button>

          {/* Supervisor Attendance Button */}
          <button
            onClick={() => {
              if (employees.length === 0) {
                alert(isNe ? 'पहिले कर्मचारी थप्नुहोस्।' : 'Add employee first.');
                return;
              }
              setSelectedEmpIds(employees.map((e) => e.id));
              setIsSupervisorModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl shadow-xs transition cursor-pointer"
          >
            <Camera className="w-4 h-4 text-emerald-400" />
            <Fingerprint className="w-4 h-4 text-amber-400" />
            <span>{isNe ? 'सामूहिक हाजिरी' : 'Supervisor Bulk'}</span>
          </button>

          {/* Give Cash Advance */}
          <button
            onClick={() => {
              if (employees.length > 0) {
                setAdvanceEmpId(employees[0].id);
                setIsAdvanceModalOpen(true);
              } else {
                alert(isNe ? 'पहिले कर्मचारी थप्नुहोस्।' : 'Add employee first.');
              }
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-purple-700 hover:bg-purple-800 text-white text-xs font-semibold rounded-xl shadow-xs transition cursor-pointer"
          >
            <Wallet className="w-4 h-4" />
            <span>{isNe ? 'पेस्की' : 'Advance'}</span>
          </button>

          {/* Printable Monthly Staff Sheet Button */}
          <button
            onClick={() => handleOpenMonthlySheetModal(employees[0]?.id || 'ALL')}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
          >
            <Printer className="w-4 h-4 text-amber-100" />
            <span>{isNe ? 'महिनाभरिको हाजिरी सिट प्रिन्ट' : 'Print Monthly Sheet'}</span>
          </button>

          {/* Generate & Copy Staff / Owner Links Button */}
          <button
            onClick={() => setIsLinkModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
          >
            <Key className="w-4 h-4 text-teal-200" />
            <span>{isNe ? '🔗 लिंक तयार / कपी' : '🔗 Share Links'}</span>
          </button>

          {/* Add Staff */}
          <button
            onClick={() => setIsAddStaffOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addStaff}</span>
          </button>
        </div>
      </div>

      {/* MASTER SETTINGS CONTROL BANNER (All Attendance, Work Category, Site Notes, Shift & GPS Settings managed in Master Settings) */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white p-4 rounded-2xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 border border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <Settings className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs sm:text-sm font-bold text-white">
              {isNe
                ? '⚙️ कामका प्रकार, साइट टिपोट, सिफ्ट समय र कार्यस्थल GPS — सबै मास्टर सेटिङबाट मिलाउने'
                : '⚙️ Work Categories, Site Notes, Shift Hours & GPS — Controlled via Master Settings'}
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-md">
              {activeWorkCategories.length} कामका प्रकार | {activeSitePresets.length} साइट टिपोट | In: {company.shiftStartTime || '10:00 AM'} - Out: {company.shiftEndTime || '05:00 PM'}
            </span>
          </div>
          <p className="text-[11px] text-slate-300">
            {isNe
              ? 'टनेल बनाउने, प्लास्टिक राख्ने, ट्याक्टर बनाउने, फिटिङ गर्ने, फिल्ड काम, साइट टिपोट र GPS/समय नियम थप्न वा फेर्न दायाँको बटन थिच्नुहोस्।'
              : 'Configure work categories, site presets, shift timing, and GPS geofence directly in Master Settings.'}
          </p>
        </div>

        <button
          type="button"
          onClick={openMasterAttendanceSettings}
          className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs rounded-xl shadow-md transition cursor-pointer flex items-center gap-1.5 shrink-0"
        >
          <Settings className="w-4 h-4" />
          <span>{isNe ? '⚙️ मास्टर सेटिङबाट मिलाउनुहोस्' : '⚙️ Open Master Settings'}</span>
        </button>
      </div>

      {/* Top Sub-Navigation Bar (Just like Purchase & Sales 6-Option Bar in BillingScreen) */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Filter out categories 1-5 from the sidebar as requested by user - hiding them to simplify entry */}
          {activeWorkCategories.filter(cat => !['TUNNEL_MAKING', 'PLASTIC_LAYING', 'TRACTOR_WORK', 'FITTING_WORK', 'CLIENT_SITE_VISIT'].includes(cat.id)).map((cat, idx) => {
            const isSelected = activeTab === 'ATTENDANCE' && quickWorkCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  setActiveTab('ATTENDANCE');
                  setQuickWorkCategory(cat.id);
                  setSelfWorkCategory(cat.id);
                  setSupervisorWorkCategory(cat.id);
                  if (cat.defaultSiteNote) {
                    setQuickSiteOrClient(cat.defaultSiteNote);
                  }
                }}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-slate-50 text-slate-700 hover:bg-emerald-50 hover:text-emerald-900 border border-slate-200'
                }`}
              >
                <span>{idx + 1}. {cat.shortNe}</span>
              </button>
            );
          })}

          <button
            type="button"
            onClick={() => handleOpenMonthlySheetModal(quickEmpId === 'ALL' ? (employees[0]?.id || 'ALL') : quickEmpId)}
            className="px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 bg-amber-50 hover:bg-amber-600 text-amber-950 hover:text-white border border-amber-300"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>६. महिनाभरिको हाजिरी सिट प्रिन्ट</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PAYROLL_LEDGER')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'PAYROLL_LEDGER'
                ? 'bg-purple-700 text-white shadow-xs'
                : 'bg-purple-50 text-purple-900 hover:bg-purple-100 border border-purple-200'
            }`}
          >
            <Wallet className="w-3.5 h-3.5" />
            <span>७. दैनिक ज्याला तथा तलब खाता</span>
          </button>


          <button
            type="button"
            onClick={() => setActiveTab('REPORTS')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'REPORTS'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'bg-blue-50 text-blue-900 hover:bg-blue-100 border border-blue-200'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>४. रिपोर्टहरू (मासिक, दैनिक, वार्षिक, पेस्की र ड्राइभर)</span>
          </button>

          <button
            type="button"
            onClick={openMasterAttendanceSettings}
            className="px-3 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-amber-300 border border-slate-700 ml-auto"
          >
            <Settings className="w-3.5 h-3.5 text-amber-400" />
            <span>९. ⚙️ मास्टर सेटिङ (काम/साइट/GPS मिलाउने)</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: DAILY ATTENDANCE (Staff Roster with Work-Category & Print Sheet)    */}
      {/* ========================================================================= */}
      {activeTab === 'ATTENDANCE' && (
        <div className="space-y-5">
          {/* QUICK WORK-CATEGORY ATTENDANCE BAR (टनेल बनाउने, प्लास्टिक राख्ने, ट्याक्टर बनाउने, फिटिङ गर्ने, अरुकोमा जाने) */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border-2 border-emerald-600/30 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <CalendarCheck className="w-5 h-5 text-emerald-700" />
                  <span>
                    {isNe
                      ? 'दैनिक हाजिरी दर्ता (नियमित वर्कसप तथा अन्य काम)'
                      : 'Daily Attendance (Workshop & Regular)'}
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isNe
                    ? 'आज वा महिनाको कुनै पनि गते छानी कर्मचारीले गरेको काम र ठाउँ अनुसार सिधै हाजिर लगाउनुहोस्'
                    : 'Select date, employee, and work category to record daily work-based attendance'}
                </p>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => handleOpenMonthlySheetModal(quickEmpId === 'ALL' ? (employees[0]?.id || 'ALL') : quickEmpId)}
                  className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-700" />
                  <span>{isNe ? 'स्टाफलाई दिने मासिक हाजिरी प्रिन्ट' : 'Print Staff Monthly Sheet'}</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleQuickWorkAttendanceSave} className="space-y-3.5 text-xs">
              {/* Row 1: Date, Staff, Site/Client Name */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? '१. हाजिरी मिति (B.S. YYYY-MM-DD):*' : '1. Attendance Date (B.S.):*'}
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      required
                      value={selectedAttendanceDateBs}
                      onChange={(e) => setSelectedAttendanceDateBs(e.target.value)}
                      placeholder="2083-07-12"
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-bold text-slate-900 bg-white"
                    />
                    {selectedAttendanceDateBs !== todayBs && (
                      <button
                        type="button"
                        onClick={() => setSelectedAttendanceDateBs(todayBs)}
                        className="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-[10px] whitespace-nowrap cursor-pointer"
                      >
                        {isNe ? 'आज' : 'Today'}
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? '२. कर्मचारी छान्नुहोस्:*' : '2. Select Staff:*'}
                  </label>
                  <div className="flex items-center gap-2">
                    <select
                      value={quickEmpId}
                      onChange={(e) => setQuickEmpId(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold text-slate-900 bg-white"
                    >
                      <option value="ALL">👥 सबै कर्मचारीहरू (All Staff - {employees.length} जना)</option>
                      {employees.map((emp) => (
                        <option key={emp.id} value={emp.id}>
                          {emp.name} ({emp.role})
                        </option>
                      ))}
                    </select>
                    {employees.find(e => e.id === quickEmpId)?.registeredPhotoUrl && (
                      <img 
                        src={employees.find(e => e.id === quickEmpId)!.registeredPhotoUrl} 
                        alt="Staff"
                        className="w-10 h-10 rounded-lg object-cover border border-slate-200"
                      />
                    )}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[11px] font-bold text-slate-700">
                      {isNe ? '३. ग्राहक वा फिल्ड ठाउँ / साइट टिपोट:' : '3. Client / Site Location Note:'}
                    </label>
                    <button
                      type="button"
                      onClick={openMasterAttendanceSettings}
                      className="text-[10px] font-bold text-emerald-700 hover:underline cursor-pointer"
                    >
                      ⚙️ साइट टिपोट सेटिङ
                    </button>
                  </div>
                  <input
                    type="text"
                    list="master-site-presets-list"
                    value={quickSiteOrClient}
                    onChange={(e) => setQuickSiteOrClient(e.target.value)}
                    placeholder={isNe ? 'उदा: राम थापाको फार्म / चितवन फिल्ड' : 'e.g. Ram Thapa Farm / Site'}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-slate-900 bg-white"
                  />
                  <datalist id="master-site-presets-list">
                    {activeSitePresets.map((site, idx) => (
                      <option key={idx} value={site} />
                    ))}
                  </datalist>
                  {activeSitePresets.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {activeSitePresets.slice(0, 4).map((preset, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setQuickSiteOrClient(preset)}
                          className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border transition cursor-pointer ${
                            quickSiteOrClient === preset
                              ? 'bg-amber-600 text-white border-amber-700'
                              : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-200'
                          }`}
                        >
                          📍 {preset}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Row 2: Work Category Pill Buttons (Configured in Master Settings) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-[11px] font-bold text-slate-700">
                    {isNe ? '४. आज गरेको काम छान्नुहोस् (Work Category - मास्टर सेटिङ अनुसार):*' : '4. Select Work Done:*'}
                  </label>
                  <button
                    type="button"
                    onClick={openMasterAttendanceSettings}
                    className="text-[10px] font-bold text-emerald-700 hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <Settings className="w-3 h-3" />
                    <span>{isNe ? 'कामका प्रकार मास्टर सेटिङबाट थप्नुहोस्/मिलाउनुहोस्' : 'Configure Work Categories'}</span>
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                  {activeWorkCategories.filter(cat => !['TUNNEL_MAKING', 'PLASTIC_LAYING', 'TRACTOR_WORK', 'FITTING_WORK', 'CLIENT_SITE_VISIT'].includes(cat.id)).map((cat) => {
                    const isSelected = quickWorkCategory === cat.id;
                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => {
                          setQuickWorkCategory(cat.id);
                          if (!quickSiteOrClient.trim() && cat.defaultSiteNote) {
                            setQuickSiteOrClient(cat.defaultSiteNote);
                          }
                        }}
                        className={`px-2.5 py-2 rounded-xl border text-left font-bold text-[11px] transition cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'bg-emerald-800 text-white border-emerald-900 shadow-xs ring-2 ring-emerald-500/30'
                            : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        <span className="truncate">{cat.shortNe}</span>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 shrink-0 ml-1" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Row 3: Optional Work Notes + Submit */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-1">
                <input
                  type="text"
                  value={quickWorkNotes}
                  onChange={(e) => setQuickWorkNotes(e.target.value)}
                  placeholder={
                    isNe
                      ? 'थप कामको विवरण (ऐच्छिक) — जस्तै: २ वटा टनेल पाइप जडान, १ रोल प्लास्टिक...'
                      : 'Optional work details...'
                  }
                  className="flex-1 px-3 py-2 border border-slate-200 rounded-xl text-xs bg-slate-50/70"
                />

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>
                    {isNe
                      ? `✓ काम अनुसार हाजिर दर्ता गर्नुहोस् (${getWorkCategoryMeta(quickWorkCategory).shortNe})`
                      : 'Save Work Attendance'}
                  </span>
                </button>
              </div>
            </form>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {employees.length === 0 ? (
              <div className="col-span-full p-12 bg-white rounded-2xl border border-slate-200 text-center text-slate-400 space-y-2">
                <Users className="w-10 h-10 mx-auto text-slate-300" />
                <p className="text-sm font-semibold text-slate-600">
                  {isNe ? 'कुनै कर्मचारी दर्ता गरिएको छैन।' : 'No employees registered yet.'}
                </p>
                <p className="text-xs">
                  {isNe ? 'माथिको "थप्नुहोस्" बटन थिची कर्मचारी विवरण प्रविष्ट गर्नुहोस्।' : 'Add your first employee to start recording attendance.'}
                </p>
              </div>
            ) : (
              employees.map((emp) => {
                const todayRecord = attendance.find(
                  (a) => a.employeeId === emp.id && a.dateBs === selectedAttendanceDateBs
                );
                const hasLoggedIn = !!todayRecord?.checkInTime && todayRecord?.status === 'PRESENT';
                const hasLoggedOut = !!todayRecord?.checkOutTime;
                const isFullyCompleted = hasLoggedIn && hasLoggedOut;
                const summary = getEmployeePayrollSummary(emp.id);
                const activeWorkMeta = todayRecord?.workCategory
                  ? getWorkCategoryMeta(todayRecord.workCategory)
                  : null;

                return (
                  <div
                    key={emp.id}
                    className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 flex flex-col justify-between shadow-xs space-y-3"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          {/* Employee Reference Photo Avatar + Quick Upload Trigger */}
                          <div className="relative shrink-0 group">
                            {emp.registeredPhotoUrl ? (
                              <img
                                src={emp.registeredPhotoUrl}
                                alt={emp.name}
                                onClick={() => handleOpenPhotoRecognitionModal('RECOGNIZE', emp)}
                                className="w-12 h-12 rounded-xl object-cover border-2 border-emerald-500 shadow-2xs cursor-pointer"
                                title={isNe ? 'पहिचान फोटो दर्ता छ — क्लिक गरी क्यामेरा पहिचान गर्नुहोस्' : 'Click to verify photo'}
                              />
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleOpenPhotoRecognitionModal('UPLOAD_REGISTER', emp)}
                                className="w-12 h-12 rounded-xl bg-amber-50 hover:bg-amber-100 border-2 border-dashed border-amber-400 flex flex-col items-center justify-center text-amber-800 cursor-pointer transition"
                                title={isNe ? 'पहिले कर्मचारीको फोटो अपलोड गर्नुहोस्' : 'Upload reference photo first'}
                              >
                                <Camera className="w-4 h-4 text-amber-700" />
                                <span className="text-[8px] font-extrabold leading-tight">+फोटो</span>
                              </button>
                            )}
                          </div>

                          <div className="min-w-0">
                            <h3 className="text-sm font-bold text-slate-900 truncate">{emp.name}</h3>
                            <p className="text-xs text-slate-500 truncate">{emp.role}</p>
                            <div className="mt-1 flex flex-wrap items-center gap-1">
                              {emp.registeredPhotoUrl ? (
                                <button
                                  type="button"
                                  onClick={() => handleOpenPhotoRecognitionModal('UPLOAD_REGISTER', emp)}
                                  className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200 hover:bg-indigo-100 cursor-pointer flex items-center gap-1"
                                >
                                  <Camera className="w-2.5 h-2.5 text-indigo-700" />
                                  <span>{isNe ? '✓ फोटो दर्ता (बदल्ने)' : '✓ Photo Enrolled'}</span>
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleOpenPhotoRecognitionModal('UPLOAD_REGISTER', emp)}
                                  className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200 cursor-pointer flex items-center gap-1"
                                >
                                  <Camera className="w-2.5 h-2.5 text-amber-800" />
                                  <span>{isNe ? '+ पहिले फोटो अपलोड गर्नुहोस्' : '+ Upload Photo First'}</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Status Badge & Attendance Toggle */}
                        <div className="flex flex-col items-end gap-1 shrink-0">
                          <div className="flex items-center gap-2">
                            {/* Attendance Toggle Checkbox */}
                            <label className="flex items-center cursor-pointer">
                              <input
                                type="checkbox"
                                checked={todayRecord?.status === 'PRESENT'}
                                onChange={(e) => {
                                  const newStatus = e.target.checked ? 'PRESENT' : 'ABSENT';
                                  setEmployeeAttendanceStatus(emp.id, newStatus, undefined, {
                                    customDateBs: selectedAttendanceDateBs
                                  });
                                }}
                                className="w-5 h-5 accent-emerald-600 cursor-pointer"
                              />
                            </label>

                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                                isFullyCompleted
                                  ? 'bg-slate-100 text-slate-700 border border-slate-200'
                                  : hasLoggedIn
                                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                  : 'bg-rose-50 text-rose-800 border border-rose-200'
                              }`}
                            >
                              {isFullyCompleted
                                ? (isNe ? 'हाजिरी पूरा' : 'Completed')
                                : hasLoggedIn
                                ? (isNe ? 'हाजिर' : 'Present')
                                : (isNe ? 'अनुपस्थित' : 'Absent')}
                            </span>
                          </div>
                          {todayRecord && todayRecord.status === 'PRESENT' && (
                            <span
                              className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md mt-1 ${
                                todayRecord.isApproved
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {todayRecord.isApproved
                                ? (isNe ? '✓ स्वीकृत' : 'Approved')
                                : (isNe ? '⏳ स्वीकृतिको पर्खाइ' : 'Pending Approval')}
                            </span>
                          )}
                          <span className="text-[10px] font-mono text-slate-400 mt-1">
                            मिति: {selectedAttendanceDateBs}
                          </span>
                        </div>
                      </div>

                      {/* Active Work Category Badge if Present */}
                      {todayRecord && todayRecord.status === 'PRESENT' && (
                        <div className="mt-2 flex flex-wrap items-center gap-1.5">
                          <span
                            className={`text-[11px] font-bold px-2.5 py-0.5 rounded-lg border ${
                              activeWorkMeta
                                ? activeWorkMeta.badgeClass
                                : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            }`}
                          >
                            {activeWorkMeta ? activeWorkMeta.shortNe : '🏭 नियमित काम'}
                          </span>
                          {todayRecord.siteOrClientName && (
                            <span className="text-[11px] font-semibold bg-amber-50 text-amber-900 border border-amber-200 px-2 py-0.5 rounded-lg flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-amber-700" />
                              <span>{todayRecord.siteOrClientName}</span>
                            </span>
                          )}
                        </div>
                      )}

                      <div className="mt-2.5 text-xs space-y-1 text-slate-600">
                        <p>फोन: <span className="font-mono">{emp.phone || '-'}</span></p>
                        <p>
                          {emp.wageType === 'DAILY' ? 'दैनिक ज्याला दर:' : 'मासिक तलब:'}{' '}
                          <span className="font-mono font-semibold">
                            {formatCurrency(
                              emp.wageType === 'DAILY' ? emp.dailyWageRate || 1000 : emp.salaryMonthly,
                              isNe
                            )}
                          </span>
                        </p>
                        {summary.totalDeductions > 0 && (
                          <p className="text-rose-700 font-medium">
                            कुल कट्टी (सामान+पेस्की): <span className="font-mono font-bold">-{formatCurrency(summary.totalDeductions, isNe)}</span>
                          </p>
                        )}
                      </div>

                      <details className="group">
                        <summary className="list-none cursor-pointer p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs text-slate-800 flex justify-between items-center mb-2">
                          <span className="uppercase">{isNe ? '१-क्लिक काम अनुसार हाजिरी:' : '1-CLICK WORK ATTENDANCE:'}</span>
                          <span className="group-open:rotate-180 transition-transform">▼</span>
                        </summary>
                        <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-slate-700 uppercase">
                              {isNe ? 'काम छान्नुहोस्:' : 'Select Work:'}
                            </span>
                            {todayRecord?.status === 'PRESENT' && (
                              <button
                                type="button"
                                onClick={() =>
                                  setEmployeeAttendanceStatus(emp.id, 'ABSENT', undefined, {
                                    customDateBs: selectedAttendanceDateBs
                                  })
                                }
                                className="text-[10px] text-rose-600 hover:underline font-bold cursor-pointer"
                              >
                                {isNe ? '✗ अनुपस्थित बनाउने' : 'Mark Absent'}
                              </button>
                            )}
                          </div>

                          <div className="flex flex-wrap gap-1">
                            {activeWorkCategories.slice(0, 7).map((cat) => {
                              const isCurrentCat =
                                todayRecord?.status === 'PRESENT' && todayRecord?.workCategory === cat.id;
                              return (
                                <button
                                  key={cat.id}
                                  type="button"
                                  onClick={() =>
                                    setEmployeeAttendanceStatus(emp.id, 'PRESENT', undefined, {
                                      workCategory: cat.id,
                                      workDescription: cat.shortNe,
                                      siteOrClientName:
                                        cardSiteInputs[emp.id]?.trim() ||
                                        todayRecord?.siteOrClientName ||
                                        cat.defaultSiteNote ||
                                        undefined,
                                      customDateBs: selectedAttendanceDateBs
                                    })
                                  }
                                  className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition cursor-pointer ${
                                    isCurrentCat
                                      ? 'bg-emerald-700 text-white border-emerald-800 shadow-2xs'
                                      : 'bg-white hover:bg-emerald-50 text-slate-700 border-slate-200'
                                  }`}
                                >
                                  {cat.shortNe}
                                </button>
                              );
                            })}
                          </div>

                          <input
                            type="text"
                            list="master-site-presets-list"
                            value={
                              cardSiteInputs[emp.id] !== undefined
                                ? cardSiteInputs[emp.id]
                                : todayRecord?.siteOrClientName || ''
                            }
                            onChange={(e) => {
                              const val = e.target.value;
                              setCardSiteInputs((prev) => ({ ...prev, [emp.id]: val }));
                            }}
                            onBlur={() => {
                              if (todayRecord?.status === 'PRESENT' && cardSiteInputs[emp.id] !== undefined) {
                                setEmployeeAttendanceStatus(emp.id, 'PRESENT', undefined, {
                                  workCategory: todayRecord.workCategory || 'WORKSHOP_REGULAR',
                                  workDescription: todayRecord.workDescription,
                                  siteOrClientName: cardSiteInputs[emp.id].trim() || undefined,
                                  customDateBs: selectedAttendanceDateBs
                                });
                              }
                            }}
                            placeholder={isNe ? 'ठाउँ / ग्राहकको नाम...' : 'Client / Site Name...'}
                            className="w-full px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-[11px] text-slate-800"
                          />
                        </div>
                      </details>

                      {/* Today's Log In / Log Out times */}
                      {todayRecord && todayRecord.status === 'PRESENT' && (
                        <div className="mt-2.5 p-2.5 bg-emerald-50/50 rounded-xl border border-emerald-200/80 text-[11px] space-y-1">
                          <div className="flex items-center justify-between font-mono">
                            <span className="text-slate-600 flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5 text-emerald-600" />
                              <span>In:</span>
                              <strong className="text-slate-900">{todayRecord.checkInTime || '10:00 AM'}</strong>
                            </span>

                            {todayRecord.checkOutTime ? (
                              <span className="text-slate-600 flex items-center gap-1">
                                <Clock className="w-3.5 h-3.5 text-rose-600" />
                                <span>Out:</span>
                                <strong className="text-slate-900">{todayRecord.checkOutTime}</strong>
                              </span>
                            ) : (
                              <span className="text-amber-700 font-semibold text-[10px]">
                                {isNe ? 'कार्यरत (In Progress)' : 'In Progress'}
                              </span>
                            )}
                          </div>

                          {todayRecord.isOffline && (
                            <div className="flex items-center gap-1 text-[10px] text-amber-700 font-semibold pt-1 border-t border-slate-200">
                              <WifiOff className="w-3 h-3 text-amber-600" />
                              <span>{isNe ? 'अफलाइन हाजिरी (अनलाइन हुँदा सिंक हुने)' : 'Offline Clock-in'}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Single Check-In / Check-Out Controls + Monthly Print Sheet Button */}
                    <div className="pt-2 border-t border-slate-100 space-y-1.5">
                      {/* Admin Approval Button */}
                      {todayRecord && todayRecord.status === 'PRESENT' && !todayRecord.isApproved && (isOwner || currentRole === 'ADMINISTRATION') && (
                          <button
                            onClick={() => {
                              setEmployeeAttendanceStatus(todayRecord.employeeId, 'PRESENT', undefined, { customDateBs: todayRecord.dateBs });
                            }}
                            className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] rounded-lg transition cursor-pointer mb-1.5"
                          >
                            {isNe ? '✓ यो हाजिरी स्वीकृत गर्नुहोस्' : 'Approve Attendance'}
                          </button>
                      )}
                      
                      <div className="grid grid-cols-2 gap-1.5">
                        {!hasLoggedIn ? (
                          <button
                            onClick={() => handleOpenMobileClockIn(emp, 'IN')}
                            className="py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-[11px] rounded-xl transition flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                          >
                            <Smartphone className="w-3.5 h-3.5" />
                            <span>{isNe ? 'मोबाइल Log In' : 'Log In'}</span>
                          </button>
                        ) : !hasLoggedOut ? (
                          <button
                            onClick={() => handleOpenMobileClockIn(emp, 'OUT')}
                            className="py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-[11px] rounded-xl transition flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                          >
                            <Clock className="w-3.5 h-3.5 text-amber-400" />
                            <span>{isNe ? 'Log Out (बिदा)' : 'Log Out'}</span>
                          </button>
                        ) : (
                          <div className="py-2 text-center text-[11px] font-bold text-slate-600 bg-slate-100 rounded-xl border border-slate-200">
                            ✓ {isNe ? 'हाजिरी पूरा' : 'Completed'}
                          </div>
                        )}

                        <button
                          type="button"
                          onClick={() =>
                            handleOpenMonthlySheetModal(
                              emp.id,
                              selectedAttendanceDateBs.split('-')[0],
                              selectedAttendanceDateBs.split('-')[1]
                            )
                          }
                          className="py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold text-[11px] rounded-xl transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5 text-amber-700" />
                          <span>{isNe ? 'मासिक हाजिरी सिट' : 'Monthly Sheet'}</span>
                        </button>
                      </div>
                    </div>

                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: PAYROLL & DAILY WAGE LEDGER (दैनिक ज्याला तथा तलब खाता)           */}
      {/* ========================================================================= */}
      {activeTab === 'PAYROLL_LEDGER' && (
        <div className="space-y-5">
          {/* Top Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                {isNe ? 'कुल कर्मचारी' : 'Total Staff'}
              </span>
              <p className="text-xl font-bold text-slate-900 mt-1 font-mono">
                {employees.length} {isNe ? 'जना' : ''}
              </p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                {isNe ? 'कुल ज्याला/तलब' : 'Gross Payroll'}
              </span>
              <p className="text-xl font-bold text-emerald-800 mt-1 font-mono">
                रु. {employees.reduce((sum, e) => sum + getEmployeePayrollSummary(e.id).grossSalary, 0).toLocaleString()}
              </p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                {isNe ? 'कुल भुक्तानी भएको' : 'Total Paid Out'}
              </span>
              <p className="text-xl font-bold text-purple-800 mt-1 font-mono">
                रु. {employees.reduce((sum, e) => sum + getEmployeePayrollSummary(e.id).salaryPaidTotal, 0).toLocaleString()}
              </p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-amber-200 bg-amber-50/40 shadow-2xs">
              <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider block">
                {isNe ? 'खुद बाँकी दायित्व' : 'Net Dues Payable'}
              </span>
              <p className="text-xl font-bold text-amber-950 mt-1 font-mono">
                रु. {employees.reduce((sum, e) => sum + getEmployeePayrollSummary(e.id).netPayable, 0).toLocaleString()}
              </p>
            </div>
          </div>

          {/* Employee Roster Table for Daily Wage & Salary */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/60">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Coins className="w-4 h-4 text-emerald-700" />
                  <span>{isNe ? 'कर्मचारी ज्याला तथा तलब भुक्तानी तालिका' : 'Employee Wage & Salary Ledger'}</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isNe
                    ? 'दैनिक हाजिरी हिसाबमा दैनिक ज्याला भुक्तानी वा मासिक तलब हिसाब'
                    : 'Calculate & pay daily wages based on days worked or monthly salary'}
                </p>
              </div>

              <button
                onClick={() => {
                  if (employees.length > 0) {
                    handleOpenSalaryModal(employees[0], 'DAILY');
                  } else {
                    alert(isNe ? 'पहिले कर्मचारी थप्नुहोस्।' : 'Add employee first.');
                  }
                }}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <Calculator className="w-3.5 h-3.5 text-emerald-300" />
                <span>{isNe ? '+ नयाँ ज्याला/तलब भुक्तानी' : '+ Pay Wage/Salary'}</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100/70 text-slate-600 font-bold border-b border-slate-200 text-[11px] uppercase tracking-wider">
                  <tr>
                    <th className="px-4 py-3">कर्मचारी विवरण</th>
                    <th className="px-3 py-3">ज्याला प्रकार</th>
                    <th className="px-3 py-3 text-right">दर (Rate)</th>
                    <th className="px-3 py-3 text-center">हाजिरी दिन</th>
                    <th className="px-3 py-3 text-right">कुल आम्दानी</th>
                    <th className="px-3 py-3 text-right">पेस्की/कट्टा</th>
                    <th className="px-3 py-3 text-right">भुक्तानी भएको</th>
                    <th className="px-3 py-3 text-right">खुद बाँकी</th>
                    <th className="px-4 py-3 text-center">कार्य (Actions)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {employees.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-8 text-center text-slate-400">
                        {isNe ? 'कुनै कर्मचारी दर्ता गरिएको छैन।' : 'No employees registered.'}
                      </td>
                    </tr>
                  ) : (
                    employees.map((emp) => {
                      const summary = getEmployeePayrollSummary(emp.id);
                      const isDaily = emp.wageType === 'DAILY';
                      const dailyRate = emp.dailyWageRate || Math.round(emp.salaryMonthly / 30) || 1000;

                      return (
                        <tr key={emp.id} className="hover:bg-slate-50/80 transition">
                          <td className="px-4 py-3">
                            <div className="font-bold text-slate-900">{emp.name}</div>
                            <div className="text-[11px] text-slate-500 flex items-center gap-2">
                              <span>{emp.role}</span>
                              {emp.phone && <span className="font-mono">({emp.phone})</span>}
                            </div>
                          </td>

                          <td className="px-3 py-3">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                                isDaily
                                  ? 'bg-amber-100 text-amber-900 border border-amber-200'
                                  : 'bg-blue-100 text-blue-900 border border-blue-200'
                              }`}
                            >
                              {isDaily ? (isNe ? 'दैनिक ज्याला' : 'Daily Wage') : (isNe ? 'मासिक तलब' : 'Monthly')}
                            </span>
                          </td>

                          <td className="px-3 py-3 text-right font-mono font-bold text-slate-800">
                            {isDaily ? (
                              <span>रु. {dailyRate.toLocaleString()}<span className="text-[10px] text-slate-400 font-normal">/दिन</span></span>
                            ) : (
                              <span>रु. {emp.salaryMonthly.toLocaleString()}<span className="text-[10px] text-slate-400 font-normal">/महिना</span></span>
                            )}
                          </td>

                          <td className="px-3 py-3 text-center">
                            <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                              {summary.presentDays} {isNe ? 'दिन' : 'd'}
                            </span>
                          </td>

                          <td className="px-3 py-3 text-right font-mono font-bold text-emerald-800">
                            रु. {summary.grossSalary.toLocaleString()}
                          </td>

                          <td className="px-3 py-3 text-right font-mono text-rose-700">
                            रु. {summary.totalDeductions.toLocaleString()}
                          </td>

                          <td className="px-3 py-3 text-right font-mono font-bold text-purple-800">
                            रु. {summary.salaryPaidTotal.toLocaleString()}
                          </td>

                          <td className="px-3 py-3 text-right font-mono font-black text-amber-900">
                            रु. {summary.netPayable.toLocaleString()}
                          </td>

                          <td className="px-4 py-3 text-center">
                            <div className="flex items-center justify-center gap-1.5 flex-wrap">
                              {/* Daily Wage / Salary Payment Button */}
                              <button
                                onClick={() => handleOpenSalaryModal(emp, isDaily ? 'DAILY' : 'MONTHLY')}
                                className="px-2.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-[11px] shadow-2xs transition flex items-center gap-1 cursor-pointer"
                                title={isDaily ? 'दैनिक हिसाबमा ज्याला भुक्तानी' : 'मासिक तलब भुक्तानी'}
                              >
                                <Coins className="w-3 h-3" />
                                <span>{isDaily ? (isNe ? 'दैनिक ज्याला दिनुहोस्' : 'Pay Daily Wage') : (isNe ? 'तलब दिनुहोस्' : 'Pay Salary')}</span>
                              </button>

                              {/* Cash Advance Button */}
                              <button
                                onClick={() => {
                                  setAdvanceEmpId(emp.id);
                                  setIsAdvanceModalOpen(true);
                                }}
                                className="px-2 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 rounded-lg font-bold text-[11px] transition cursor-pointer"
                                title="नगद पेस्की दिनुहोस्"
                              >
                                <Wallet className="w-3 h-3" />
                                <span>{isNe ? 'पेस्की' : 'Advance'}</span>
                              </button>

                              {/* View Statement Button */}
                              <button
                                onClick={() => setViewingLedgerEmpId(viewingLedgerEmpId === emp.id ? null : emp.id)}
                                className={`px-2 py-1.5 rounded-lg font-bold text-[11px] transition cursor-pointer border ${
                                  viewingLedgerEmpId === emp.id
                                    ? 'bg-slate-900 text-white border-slate-900'
                                    : 'bg-white text-slate-700 hover:bg-slate-100 border-slate-200'
                                }`}
                                title="खाता विवरण हेर्नुहोस्"
                              >
                                <FileText className="w-3 h-3" />
                                <span>{viewingLedgerEmpId === emp.id ? (isNe ? 'बन्द' : 'Close') : (isNe ? 'खाता' : 'Ledger')}</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Detailed Employee Statement Drawer (when viewingLedgerEmpId is selected) */}
          {viewingLedgerEmpId && (
            <div className="bg-white rounded-2xl border border-slate-300 shadow-md p-5 space-y-4 animate-fadeIn">
              {(() => {
                const targetEmp = employees.find((e) => e.id === viewingLedgerEmpId);
                if (!targetEmp) return null;
                const empLedgerEntries = employeeLedger.filter((l) => l.employeeId === viewingLedgerEmpId);
                const summary = getEmployeePayrollSummary(targetEmp.id);

                return (
                  <div>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-base font-bold text-slate-900">
                            {targetEmp.name} {isNe ? '- खाता विवरण (Staff Ledger)' : '- Staff Ledger'}
                          </h4>
                          <span className="text-xs bg-slate-100 px-2 py-0.5 rounded font-mono font-bold text-slate-700">
                            {targetEmp.role}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {isNe ? 'सम्पूर्ण तलब, दैनिक ज्याला, पेस्की तथा पसल खरिद कट्टी विवरण' : 'Complete statement of payroll, daily wages, advances, and deductions'}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => printPage()}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>{isNe ? 'प्रिन्ट' : 'Print'}</span>
                        </button>
                        <button
                          onClick={() => setViewingLedgerEmpId(null)}
                          className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="overflow-x-auto mt-3">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 text-[11px]">
                          <tr>
                            <th className="px-3 py-2.5">मिति (B.S.)</th>
                            <th className="px-3 py-2.5">विवरण (Particulars)</th>
                            <th className="px-3 py-2.5 text-right">रकम (रु.)</th>
                            <th className="px-3 py-2.5">भुक्तानी माध्यम</th>
                            <th className="px-3 py-2.5">कैफियत / टिप्पणी</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {targetEmp.openingDue > 0 && (
                            <tr className="bg-amber-50/30">
                              <td className="px-3 py-2 font-mono">{targetEmp.joinedDateBs}</td>
                              <td className="px-3 py-2 font-semibold text-amber-900">सुरुवाती पेस्की बाँकी (Opening Due)</td>
                              <td className="px-3 py-2 text-right font-mono font-bold text-amber-950">रु. {targetEmp.openingDue.toLocaleString()}</td>
                              <td className="px-3 py-2 text-slate-500">-</td>
                              <td className="px-3 py-2 text-slate-500">प्रणाली सुरु गर्दाको पुरानो पेस्की</td>
                            </tr>
                          )}

                          {empLedgerEntries.length === 0 && targetEmp.openingDue === 0 ? (
                            <tr>
                              <td colSpan={5} className="px-3 py-6 text-center text-slate-400">
                                {isNe ? 'कुनै कारोबार दर्ता भएको छैन।' : 'No entries recorded yet.'}
                              </td>
                            </tr>
                          ) : (
                            empLedgerEntries.map((entry) => (
                              <tr key={entry.id} className="hover:bg-slate-50/60">
                                <td className="px-3 py-2 font-mono text-slate-700">{entry.dateBs}</td>
                                <td className="px-3 py-2 font-semibold">
                                  {entry.type === 'SALARY_PAYMENT' ? (
                                    <span className="text-emerald-700 flex items-center gap-1">
                                      <CheckCircle2 className="w-3.5 h-3.5" />
                                      <span>{entry.wageType === 'DAILY' ? 'दैनिक ज्याला भुक्तानी' : 'मासिक तलब भुक्तानी'}</span>
                                      {entry.daysWorked && <span className="text-[10px] font-mono">({entry.daysWorked} दिन)</span>}
                                    </span>
                                  ) : entry.type === 'CASH_ADVANCE' ? (
                                    <span className="text-purple-700 flex items-center gap-1">
                                      <ArrowUpRight className="w-3.5 h-3.5" />
                                      <span>नगद पेस्की लिएको</span>
                                    </span>
                                  ) : (
                                    <span className="text-blue-700 flex items-center gap-1">
                                      <Receipt className="w-3.5 h-3.5" />
                                      <span>पसलबाट सामान खरिद कट्टी</span>
                                    </span>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-right font-mono font-bold text-slate-900">
                                  रु. {entry.amount.toLocaleString()}
                                </td>
                                <td className="px-3 py-2 text-slate-600">
                                  {entry.paymentMode === 'BANK' ? (
                                    <span className="bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded font-bold text-[10px]">
                                      {entry.bankName || 'बैंक'}
                                    </span>
                                  ) : (
                                    <span className="bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded font-bold text-[10px]">
                                      नगद काउन्टर
                                    </span>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-slate-500 text-[11px]">{entry.notes || '-'}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: MONTHLY & ANNUAL REPORTS (कर्मचारीको मासिक तथा वार्षिक रिपोर्ट)     */}
      {/* ========================================================================= */}
      {activeTab === 'REPORTS' && (
        <div className="space-y-5">
          {/* Sub-navigation for Report Types */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-xl w-fit">
            <button
              onClick={() => setReportType('STAFF_SUMMARY')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition flex items-center gap-2 cursor-pointer ${
                reportType === 'STAFF_SUMMARY'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{isNe ? 'कर्मचारी सारांश रिपोर्ट (Staff Summary)' : 'Staff Summary'}</span>
            </button>
            <button
              onClick={() => setReportType('DAILY_LOG')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition flex items-center gap-2 cursor-pointer ${
                reportType === 'DAILY_LOG'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{isNe ? 'दैनिक हाजिरी लग (Daily Log)' : 'Daily Attendance Log'}</span>
            </button>
            <button
              onClick={() => setReportType('REGISTER')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition flex items-center gap-2 cursor-pointer ${
                reportType === 'REGISTER'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>{isNe ? 'हाजिरी रजिस्टर (स्कूल स्टाइल)' : 'Attendance Register (School Style)'}</span>
            </button>
            <button
              onClick={() => setReportType('ADVANCE')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition flex items-center gap-2 cursor-pointer ${
                reportType === 'ADVANCE'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>{isNe ? 'पेस्की रिपोर्ट (Advance Report)' : 'Advance Report'}</span>
            </button>
            <button
              onClick={() => setReportType('DRIVER')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition flex items-center gap-2 cursor-pointer ${
                reportType === 'DRIVER'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>{isNe ? 'ड्राइभर रिपोर्ट (Driver Report)' : 'Driver Report'}</span>
            </button>
          </div>

          {/* Filter Bar */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              {/* Year Selector */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'साल (Year B.S.):' : 'Year:'}
                </label>
                <select
                  value={reportYear}
                  onChange={(e) => setReportYear(e.target.value)}
                  className="px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900 font-mono"
                >
                  <option value="2083">२०८३ (2083/84)</option>
                  <option value="2082">२०८२ (2082/83)</option>
                  <option value="2081">२०८१ (2081/82)</option>
                  <option value="2080">२०८० (2080/81)</option>
                  <option value="2079">२०७९ (2079/80)</option>
                </select>
              </div>

              {/* Month Selector: Monthly vs Annual */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'महिना / वार्षिक अवधि:' : 'Period:'}
                </label>
                <select
                  value={reportMonth}
                  onChange={(e) => setReportMonth(e.target.value)}
                  className="px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                >
                  <option value="ALL">🌟 सम्पूर्ण वर्षको एकीकृत रिपोर्ट (Annual Report)</option>
                  <option value="01">०१ - बैशाख (Baisakh)</option>
                  <option value="02">०२ - जेठ (Jestha)</option>
                  <option value="03">०३ - असार (Ashadh)</option>
                  <option value="04">०४ - साउन (Shrawan)</option>
                  <option value="05">०५ - भदौ (Bhadra)</option>
                  <option value="06">०६ - असोज (Ashwin)</option>
                  <option value="07">०७ - कात्तिक (Kartik)</option>
                  <option value="08">०८ - मङ्सिर (Mangsir)</option>
                  <option value="09">०९ - पुस (Poush)</option>
                  <option value="10">१० - माघ (Magh)</option>
                  <option value="11">११ - फागुन (Falgun)</option>
                  <option value="12">१२ - चैत (Chaitra)</option>
                </select>
              </div>

              {/* Staff filter (Only for Staff-related reports) */}
              {reportType !== 'DRIVER' && (
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'कर्मचारी छान्नुहोस्:' : 'Staff Filter:'}
                  </label>
                  <select
                    value={reportEmployeeId}
                    onChange={(e) => setReportEmployeeId(e.target.value)}
                    className="px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-900"
                  >
                    <option value="ALL">सबै कर्मचारीहरू (All Employees)</option>
                    {employees.map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.name} ({e.role})
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Export Actions */}
            <div className="flex flex-wrap items-center gap-2 self-start md:self-end">
              {reportType === 'STAFF_SUMMARY' && (
                <button
                  type="button"
                  onClick={() =>
                    handleOpenMonthlySheetModal(
                      reportEmployeeId === 'ALL' ? (employees[0]?.id || 'ALL') : reportEmployeeId,
                      reportYear,
                      reportMonth === 'ALL' ? defaultMonthBs : reportMonth
                    )
                  }
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{isNe ? 'स्टाफ महिनाभरिको हाजिरी सिट' : 'Staff Monthly Card'}</span>
                </button>
              )}

              <button
                type="button"
                onClick={exportPayrollReportToExcel}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isNe ? 'Excel डाउनलोड' : 'Export Excel'}</span>
              </button>

              <button
                type="button"
                onClick={() => printPage()}
                className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{isNe ? 'प्रिन्ट' : 'Print'}</span>
              </button>
            </div>
          </div>

          {/* REPORT CONTENT: STAFF SUMMARY */}
          {reportType === 'STAFF_SUMMARY' && (
            <>
              {/* Report KPI Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4">
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    {isNe ? 'छानिएको अवधि' : 'Period'}
                  </span>
                  <p className="text-sm font-bold text-slate-900 mt-1 truncate">
                    {reportYear} {reportMonth === 'ALL' ? 'वार्षिक (Annual)' : `महिना ${reportMonth}`}
                  </p>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    {isNe ? 'जम्मा हाजिरी दिन' : 'Total Days Worked'}
                  </span>
                  <p className="text-xl font-bold text-slate-900 mt-1 font-mono">
                    {reportTotalPresentDays} {isNe ? 'दिन' : 'days'}
                  </p>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    {isNe ? 'कुल आर्जित ज्याला/तलब' : 'Total Gross Payroll'}
                  </span>
                  <p className="text-xl font-bold text-emerald-800 mt-1 font-mono">
                    रु. {reportTotalGross.toLocaleString()}
                  </p>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    {isNe ? 'पेस्की तथा खरिद कट्टा' : 'Total Deductions'}
                  </span>
                  <p className="text-xl font-bold text-rose-700 mt-1 font-mono">
                    रु. {reportTotalDeductions.toLocaleString()}
                  </p>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-amber-200 bg-amber-50/40 shadow-2xs col-span-2 sm:col-span-1">
                  <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider block">
                    {isNe ? 'खुद बाँकी दायित्व' : 'Net Balance Due'}
                  </span>
                  <p className="text-xl font-bold text-amber-950 mt-1 font-mono">
                    रु. {reportTotalNetPayable.toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Comprehensive Report Table */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                    <span>
                      {isNe
                        ? `कर्मचारी ${reportMonth === 'ALL' ? 'वार्षिक' : 'मासिक'} विस्तृत रिपोर्ट (${reportYear})`
                        : `Staff ${reportMonth === 'ALL' ? 'Annual' : 'Monthly'} Report (${reportYear})`}
                    </span>
                  </h3>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 text-[11px] uppercase tracking-wider">
                      <tr>
                        <th className="px-4 py-3">क्र.सं.</th>
                        <th className="px-4 py-3">कर्मचारीको नाम तथा पद</th>
                        <th className="px-3 py-3 text-right">दर (Rate)</th>
                        <th className="px-3 py-3 text-center">हाजिरी दिन</th>
                        <th className="px-3 py-3 text-right">कुल ज्याला (Gross)</th>
                        <th className="px-3 py-3 text-right">पेस्की कट्टी</th>
                        <th className="px-3 py-3 text-right">भुक्तानी (Paid)</th>
                        <th className="px-4 py-3 text-right">खुद बाँकी</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredReportRows.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                            {isNe ? 'कुनै कर्मचारीको विवरण भेटिएन।' : 'No employee records found.'}
                          </td>
                        </tr>
                      ) : (
                        filteredReportRows.map((row, idx) => (
                          <tr key={row.emp.id} className="hover:bg-slate-50/80 transition">
                            <td className="px-4 py-3 font-mono text-slate-500">{idx + 1}</td>
                            <td className="px-4 py-3">
                              <span className="font-bold text-slate-900 block">{row.emp.name}</span>
                              <span className="text-[11px] text-slate-500">{row.emp.role}</span>
                            </td>
                            <td className="px-3 py-3 text-right font-mono text-slate-700">
                              रु. {(row.emp.wageType === 'DAILY' ? row.emp.dailyWageRate || 1000 : row.emp.salaryMonthly).toLocaleString()}
                            </td>
                            <td className="px-3 py-3 text-center font-mono font-bold text-slate-900">
                              {row.presentDays}
                            </td>
                            <td className="px-3 py-3 text-right font-mono font-bold text-emerald-800">
                              रु. {row.grossSalary.toLocaleString()}
                            </td>
                            <td className="px-3 py-3 text-right font-mono text-rose-700">
                              रु. {row.deductions.toLocaleString()}
                            </td>
                            <td className="px-3 py-3 text-right font-mono font-bold text-purple-800">
                              रु. {row.salaryPaid.toLocaleString()}
                            </td>
                            <td className="px-4 py-3 text-right font-mono font-black text-amber-950">
                              रु. {row.netPayable.toLocaleString()}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* REPORT CONTENT: DAILY ATTENDANCE LOG */}
          {reportType === 'DAILY_LOG' && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-emerald-700" />
                  <span>{isNe ? 'दैनिक हाजिरी विस्तृत विवरण (Attendance Log)' : 'Detailed Attendance Log'}</span>
                </h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 text-[11px] uppercase tracking-wider">
                    <tr>
                      <th className="px-4 py-3">{isNe ? 'मिति' : 'Date'}</th>
                      <th className="px-4 py-3">{isNe ? 'कर्मचारी' : 'Staff'}</th>
                      <th className="px-4 py-3">{isNe ? 'आगमन' : 'In'}</th>
                      <th className="px-4 py-3">{isNe ? 'प्रस्थान' : 'Out'}</th>
                      <th className="px-4 py-3">{isNe ? 'कामको प्रकार' : 'Work Type'}</th>
                      <th className="px-4 py-3">{isNe ? 'साइट / ठाउँ' : 'Site / Client'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {dailyAttendanceLog.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-4 py-8 text-center text-slate-400">
                          {isNe ? 'यो अवधिमा कुनै हाजिरी लग छैन।' : 'No attendance log found.'}
                        </td>
                      </tr>
                    ) : (
                      dailyAttendanceLog.map((a, idx) => (
                        <tr key={a.id} className="hover:bg-slate-50/80 transition">
                          <td className="px-4 py-3 font-mono font-bold text-slate-900">{a.dateBs}</td>
                          <td className="px-4 py-3">{a.employeeName}</td>
                          <td className="px-4 py-3 font-mono text-emerald-700 font-bold">{a.checkInTime}</td>
                          <td className="px-4 py-3 font-mono text-rose-700 font-bold">{a.checkOutTime || '-'}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${getWorkCategoryMeta(a.workCategory).badgeClass}`}>
                              {isNe ? getWorkCategoryMeta(a.workCategory).shortNe : getWorkCategoryMeta(a.workCategory).labelEn}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-slate-600">{a.siteOrClientName || '-'}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* REPORT CONTENT: ATTENDANCE REGISTER (स्कूलको हाजिरी रजिस्टर जस्तै) */}
          {reportType === 'REGISTER' && (() => {
            if (reportMonth === 'ALL') {
              return (
                <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-10 text-center text-sm text-slate-500">
                  {isNe
                    ? 'रजिस्टर हेर्न माथि एक महिना छान्नुहोस् (वार्षिकमा रजिस्टर देखिँदैन)।'
                    : 'Please select a specific month above to view the register (not available for Annual).'}
                </div>
              );
            }

            const registerEmployees =
              reportEmployeeId === 'ALL' ? employees : employees.filter((e) => e.id === reportEmployeeId);
            const monthPrefix = `${reportYear}-${reportMonth}`;
            const monthRecords = attendance.filter((a) => a.dateBs.startsWith(monthPrefix));
            let registerMaxDay = 30;
            monthRecords.forEach((r) => {
              const d = parseInt(r.dateBs.split('-')[2] || '0', 10);
              if (d > registerMaxDay) registerMaxDay = d;
            });
            const dayNumbers = Array.from({ length: registerMaxDay }, (_, i) => i + 1);

            const recordFor = (empId: string, day: number) => {
              const dStr = String(day).padStart(2, '0');
              return monthRecords.find((r) => r.employeeId === empId && r.dateBs === `${monthPrefix}-${dStr}`);
            };

            const handleCellClick = (empId: string, day: number) => {
              const dStr = String(day).padStart(2, '0');
              const dateBs = `${monthPrefix}-${dStr}`;
              const rec = recordFor(empId, day);
              // School-register style click: no record/Absent -> Present, Present -> Absent
              if (!rec) {
                setEmployeeAttendanceStatus(empId, 'PRESENT', undefined, { customDateBs: dateBs });
              } else if (rec.status === 'PRESENT') {
                setEmployeeAttendanceStatus(empId, 'ABSENT', undefined, { customDateBs: dateBs });
              } else {
                setEmployeeAttendanceStatus(empId, 'PRESENT', undefined, { customDateBs: dateBs });
              }
            };

            return (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-emerald-700" />
                    <span>{isNe ? 'मासिक हाजिरी रजिस्टर (स्कूल स्टाइल)' : 'Monthly Attendance Register (School Style)'}</span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {isNe
                      ? 'कुनै पनि दिनको खानामा क्लिक गर्नुहोस् — हाजिर/अनुपस्थित छिटो मिलाउन।'
                      : 'Click any day cell to quickly mark Present / Absent.'}
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="text-[10px] border-collapse w-full">
                    <thead>
                      <tr className="bg-slate-800 text-white">
                        <th className="sticky left-0 bg-slate-800 border border-slate-700 px-2 py-2 text-left min-w-[150px] z-10">
                          {isNe ? 'कर्मचारीको नाम' : 'Employee Name'}
                        </th>
                        {dayNumbers.map((d) => (
                          <th key={d} className="border border-slate-700 px-1 py-2 text-center w-7 min-w-7">
                            {d}
                          </th>
                        ))}
                        <th className="border border-slate-700 px-2 py-2 text-center min-w-[70px] bg-emerald-800">
                          {isNe ? 'जम्मा हाजिर' : 'Total Present'}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {registerEmployees.length === 0 && (
                        <tr>
                          <td colSpan={dayNumbers.length + 2} className="text-center py-8 text-slate-400">
                            {isNe ? 'कुनै कर्मचारी छैन' : 'No employees found'}
                          </td>
                        </tr>
                      )}
                      {registerEmployees.map((emp) => {
                        const totalPresent = dayNumbers.filter((d) => recordFor(emp.id, d)?.status === 'PRESENT').length;
                        return (
                          <tr key={emp.id} className="hover:bg-slate-50">
                            <td className="sticky left-0 bg-white hover:bg-slate-50 border border-slate-200 px-2 py-1.5 font-bold text-slate-800 whitespace-nowrap z-10">
                              {emp.name}
                              <span className="block text-[9px] font-normal text-slate-400">{emp.role}</span>
                            </td>
                            {dayNumbers.map((d) => {
                              const rec = recordFor(emp.id, d);
                              const isPresent = rec?.status === 'PRESENT';
                              const isAbsent = rec?.status === 'ABSENT';
                              return (
                                <td
                                  key={d}
                                  onClick={() => handleCellClick(emp.id, d)}
                                  title={
                                    isNe
                                      ? `${emp.name} — ${monthPrefix}-${String(d).padStart(2, '0')} : क्लिक गरी मिलाउनुहोस्`
                                      : `Click to mark ${emp.name} for day ${d}`
                                  }
                                  className={`border border-slate-200 text-center font-black cursor-pointer select-none transition ${
                                    isPresent
                                      ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                      : isAbsent
                                      ? 'bg-rose-100 text-rose-700 hover:bg-rose-200'
                                      : 'bg-white text-slate-300 hover:bg-slate-100'
                                  }`}
                                >
                                  {isPresent ? 'P' : isAbsent ? 'A' : '-'}
                                </td>
                              );
                            })}
                            <td className="border border-slate-200 px-2 py-1.5 text-center font-black text-emerald-700 bg-emerald-50">
                              {totalPresent}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                <div className="px-5 py-3 border-t border-slate-100 bg-slate-50/70 flex flex-wrap items-center gap-4 text-[11px] text-slate-600">
                  <span className="flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded bg-emerald-100 border border-emerald-300 inline-flex items-center justify-center font-black text-emerald-800">P</span>
                    {isNe ? 'हाजिर (Present)' : 'Present'}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded bg-rose-100 border border-rose-300 inline-flex items-center justify-center font-black text-rose-700">A</span>
                    {isNe ? 'अनुपस्थित (Absent)' : 'Absent'}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded bg-white border border-slate-300 inline-flex items-center justify-center font-black text-slate-300">-</span>
                    {isNe ? 'रेकर्ड भएको छैन' : 'No record yet'}
                  </span>
                </div>
              </div>
            );
          })()}

          {/* REPORT CONTENT: ADVANCE REPORT */}
          {reportType === 'ADVANCE' && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-rose-700" />
                  <span>{isNe ? 'कर्मचारी पेस्की रिपोर्ट (Cash Advance Report)' : 'Staff Cash Advance Report'}</span>
                </h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 text-[11px] uppercase tracking-wider">
                    <tr>
                      <th className="px-4 py-3">{isNe ? 'मिति' : 'Date'}</th>
                      <th className="px-4 py-3">{isNe ? 'कर्मचारीको नाम' : 'Employee Name'}</th>
                      <th className="px-4 py-3 text-right">{isNe ? 'पेस्की रकम (Advance)' : 'Advance Amount'}</th>
                      <th className="px-4 py-3">{isNe ? 'विवरण / कैफियत' : 'Notes'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {advanceReportRows.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-4 py-8 text-center text-slate-400">
                          {isNe ? 'यो अवधिमा कुनै पेस्की लग छैन।' : 'No cash advance logs found.'}
                        </td>
                      </tr>
                    ) : (
                      advanceReportRows.map((entry) => (
                        <tr key={entry.id} className="hover:bg-slate-50/80 transition">
                          <td className="px-4 py-3 font-mono font-bold text-slate-900">{entry.dateBs}</td>
                          <td className="px-4 py-3 font-bold">{employees.find(e => e.id === entry.employeeId)?.name || 'Unknown'}</td>
                          <td className="px-4 py-3 text-right font-mono font-black text-rose-700">रु. {entry.amount.toLocaleString()}</td>
                          <td className="px-4 py-3 text-slate-600">{entry.notes}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}



      {/* MODAL 1: MOBILE SELF-ATTENDANCE (आफ्नो मोबाइलबाट हाजिरी + GPS Geofence)   */}
      {/* ========================================================================= */}
      {isMobileClockInOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-emerald-800 text-white">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-300" />
                <div>
                  <h3 className="text-sm font-bold">
                    {isNe ? 'मोबाइलबाट कर्मचारी हाजिरी' : 'Mobile Self Attendance'}
                  </h3>
                  <p className="text-[11px] text-emerald-200">
                    {isNe ? 'GPS लोकेसन, फोटो तथा बायोमेट्रिक प्रमाणीकरण' : 'GPS, Selfie and Biometric check-in'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsMobileClockInOpen(false)}
                className="text-emerald-200 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              
              {/* Employee Selection */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'कर्मचारीको नाम छान्नुहोस्:*' : 'Select Employee:*'}
                </label>
                <select
                  value={selfClockEmpId}
                  onChange={(e) => setSelfClockEmpId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 bg-white"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.role})
                    </option>
                  ))}
                </select>
              </div>

              {/* Action Type: Log In vs Log Out */}
              <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setSelfClockType('IN')}
                  className={`py-2 text-center font-bold rounded-lg transition cursor-pointer ${
                    selfClockType === 'IN'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {isNe ? '१. Log In (आगमन)' : 'Log In'}
                </button>
                <button
                  type="button"
                  onClick={() => setSelfClockType('OUT')}
                  className={`py-2 text-center font-bold rounded-lg transition cursor-pointer ${
                    selfClockType === 'OUT'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {isNe ? '२. Log Out (प्रस्थान)' : 'Log Out'}
                </button>
              </div>

              {/* Work Category Selection in Mobile Clock-In */}
              <div className="space-y-2 p-3 bg-emerald-50/60 border border-emerald-200 rounded-xl">
                <label className="block text-[11px] font-bold text-emerald-950">
                  {isNe ? 'गर्ने कामको प्रकार छान्नुहोस् (Work Type):*' : 'Select Work Category:*'}
                </label>
                <select
                  value={selfWorkCategory}
                  onChange={(e) => {
                    const newCat = e.target.value as StaffWorkCategory;
                    setSelfWorkCategory(newCat);
                    const meta = getWorkCategoryMeta(newCat);
                    if (!selfSiteOrClient.trim() && meta.defaultSiteNote) {
                      setSelfSiteOrClient(meta.defaultSiteNote);
                    }
                  }}
                  className="w-full px-3 py-2 border border-emerald-300 rounded-lg text-xs font-bold text-slate-900 bg-white"
                >
                  {activeWorkCategories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {isNe ? cat.labelNe : cat.labelEn}
                    </option>
                  ))}
                </select>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-1">
                    {isNe ? 'ग्राहक वा फिल्ड ठाउँको नाम (अरुकोमा जाँदा / टनेल साइड):' : 'Client / Site Location:'}
                  </label>
                  <input
                    type="text"
                    list="master-site-presets-list"
                    value={selfSiteOrClient}
                    onChange={(e) => setSelfSiteOrClient(e.target.value)}
                    placeholder={isNe ? 'उदा: हरिको टनेल साइट / भरतपुर' : 'e.g. Client Site / Farm Name'}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                  />
                </div>
              </div>

              {/* Automatic Time Preview */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-500 font-semibold block">
                    {isNe ? 'हाजिरीमा सेट हुने समय (Time):' : 'Effective Time:'}
                  </span>
                  <span className="text-base font-mono font-bold text-slate-900">
                    {company.autoSetShiftTime
                      ? (selfClockType === 'IN' ? company.shiftStartTime || '10:00 AM' : company.shiftEndTime || '05:00 PM')
                      : currentLiveTime}
                  </span>
                </div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-md">
                  {company.autoSetShiftTime ? (isNe ? 'मालिक तालिका (Auto)' : 'Shift Timing') : (isNe ? 'घडी समय' : 'Live')}
                </span>
              </div>

              {/* GPS Location & Geofence Check Card */}
              <div className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${
                selfGpsLoading
                  ? 'bg-slate-50 border-slate-200 text-slate-600'
                  : selfGpsResult?.isAllowed
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                  : 'bg-rose-50 border-rose-300 text-rose-950'
              }`}>
                <div className="flex items-center justify-between font-bold">
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-emerald-700" />
                    <span>{isNe ? 'GPS कार्यस्थल लोकेसन परीक्षण:' : 'Workplace GPS Check:'}</span>
                  </span>
                  {selfGpsLoading ? (
                    <span className="text-[10px] text-slate-500">{isNe ? 'GPS खोज्दै...' : 'Locating...'}</span>
                  ) : selfGpsResult?.isAllowed ? (
                    <span className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded">✓ स्वीकृत (In Zone)</span>
                  ) : (
                    <span className="text-[10px] bg-rose-600 text-white px-2 py-0.5 rounded">✗ अस्वीकृत (Out of Zone)</span>
                  )}
                </div>

                {selfGpsLoading ? (
                  <p className="text-[11px] text-slate-500">मोबाइल GPS बाट स्थान लिँदैछ...</p>
                ) : (
                  <p className="text-[11px] leading-relaxed">
                    {isNe ? selfGpsResult?.messageNe : selfGpsResult?.messageEn}
                  </p>
                )}

                {/* Owner Override Option when GPS fails or is restricted */}
                {(!selfGpsResult?.isAllowed || !company.enforceGpsLocation) && (
                  <div className="pt-2 border-t border-rose-200/80 mt-1 flex flex-col gap-1.5">
                    <p className="text-[10px] font-semibold text-rose-900">
                      {isNe
                        ? '💡 कार्यस्थल बाहिर हुनुहुन्छ वा GPS नचलेको खण्डमा मालिकको PIN/अनुमतिबाट हाजिर गर्नुहोस्:'
                        : 'Outside zone or GPS unavailable? Clock in with Owner PIN approval:'}
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setOwnerOverridePin('');
                        setOwnerOverrideError(null);
                        setIsOwnerOverrideModalOpen(true);
                      }}
                      className="py-1.5 px-3 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs"
                    >
                      <Key className="w-3.5 h-3.5 text-amber-200" />
                      <span>{isNe ? '🔑 मालिकको अनुमतिमा विना लोकेसन हाजिरी (Owner PIN)' : 'Owner Approval Clock-In (No GPS)'}</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Verification Buttons: Real Camera Selfie + Reference Photo Recognition & Biometric Tap */}
              <div className="space-y-2.5 p-3 bg-indigo-50/60 border border-indigo-200 rounded-xl">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-indigo-950 flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-indigo-700" />
                    <span>
                      {isNe
                        ? 'फोटो खिचेर पहिचान प्रमाणीकरण (Mobile / Desktop):'
                        : 'Capture Photo & Match Reference:'}
                    </span>
                  </span>
                  {(() => {
                    const selEmp = employees.find((e) => e.id === selfClockEmpId);
                    return selEmp?.registeredPhotoUrl ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                        {isNe ? '✓ दर्ता फोटो उपलब्ध' : '✓ Ref Photo Ready'}
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setIsMobileClockInOpen(false);
                          handleOpenPhotoRecognitionModal('UPLOAD_REGISTER', selEmp);
                        }}
                        className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-200 text-amber-950 hover:bg-amber-300 cursor-pointer"
                      >
                        {isNe ? '+ पहिले फोटो अपलोड' : '+ Upload Ref Photo'}
                      </button>
                    );
                  })()}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <label
                    className={`py-2.5 px-3 rounded-xl border flex items-center justify-center gap-1.5 font-bold transition cursor-pointer text-center ${
                      selfPhotoCaptured
                        ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                        : 'bg-white border-indigo-300 hover:bg-indigo-50 text-indigo-950'
                    }`}
                  >
                    <Camera className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>
                      {selfPhotoCaptured
                        ? isNe
                          ? '✓ फोटो खिचियो (बदल्ने)'
                          : '✓ Photo Captured'
                        : isNe
                        ? '📸 फोटो खिच्नुहोस्'
                        : '📸 Take Photo'}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      capture="user"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const dataUrl = await resizeAndGetDataUrl(file, 320);
                        selfCapturedPhotoDataRef.current = dataUrl;
                        setSelfCapturedPhotoUrl(dataUrl);
                        setSelfPhotoCaptured(true);
                        const selEmp = employees.find((emp) => emp.id === selfClockEmpId);
                        if (selEmp?.registeredPhotoUrl) {
                          const sigA = await computePhotoSignature(dataUrl);
                          const sigB = await computePhotoSignature(selEmp.registeredPhotoUrl);
                          const score = calculateSignatureSimilarity(sigA, sigB);
                          setSelfPhotoMatchScore(score);
                        } else {
                          setSelfPhotoMatchScore(null);
                        }
                      }}
                    />
                  </label>

                  <button
                    type="button"
                    onClick={() => {
                      const selEmp = employees.find((emp) => emp.id === selfClockEmpId);
                      setIsMobileClockInOpen(false);
                      handleOpenPhotoRecognitionModal('RECOGNIZE', selEmp);
                    }}
                    className="py-2.5 px-3 rounded-xl border border-indigo-300 bg-indigo-700 hover:bg-indigo-800 text-white flex items-center justify-center gap-1.5 font-bold transition cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
                    <span>{isNe ? 'लाइभ क्यामेरा स्क्यान' : 'Live Camera Scan'}</span>
                  </button>
                </div>

                {/* Side-by-Side Comparison when Photo Captured in Mobile Modal */}
                {selfCapturedPhotoUrl && (
                  <div className="p-2.5 bg-white rounded-xl border border-indigo-200 space-y-2">
                    <div className="grid grid-cols-2 gap-2 text-center">
                      <div>
                        <span className="text-[10px] font-bold text-slate-500 block mb-1">
                          {isNe ? '१. पहिले अपलोड फोटो' : '1. Uploaded Ref Photo'}
                        </span>
                        {employees.find((e) => e.id === selfClockEmpId)?.registeredPhotoUrl ? (
                          <img
                            src={employees.find((e) => e.id === selfClockEmpId)?.registeredPhotoUrl}
                            alt="Registered"
                            className="w-16 h-16 mx-auto rounded-lg object-cover border border-slate-300"
                          />
                        ) : (
                          <div className="w-16 h-16 mx-auto rounded-lg bg-slate-100 border border-dashed border-slate-300 flex items-center justify-center text-[9px] text-slate-400 p-1">
                            {isNe ? 'दर्ता छैन' : 'Not Enrolled'}
                          </div>
                        )}
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-emerald-700 block mb-1">
                          {isNe ? '२. अहिले खिचिएको फोटो' : '2. Captured Photo'}
                        </span>
                        <img
                          src={selfCapturedPhotoUrl}
                          alt="Captured"
                          className="w-16 h-16 mx-auto rounded-lg object-cover border-2 border-emerald-500"
                        />
                      </div>
                    </div>
                    {selfPhotoMatchScore !== null && (
                      <div className="text-center text-[11px] font-extrabold text-emerald-800 bg-emerald-50 py-1 rounded-lg border border-emerald-200">
                        {isNe
                          ? `✓ पहिचान मिलान (Face Photo Match): ${selfPhotoMatchScore}%`
                          : `✓ Photo Match Score: ${selfPhotoMatchScore}%`}
                      </div>
                    )}
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setSelfBiometricVerified(true);
                  }}
                  className={`w-full py-2 px-3 rounded-xl border flex items-center justify-center gap-1.5 font-semibold transition cursor-pointer ${
                    selfBiometricVerified
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-white border-slate-300 hover:bg-slate-100 text-slate-800'
                  }`}
                >
                  <Fingerprint className="w-4 h-4 text-amber-500" />
                  <span>
                    {selfBiometricVerified
                      ? isNe
                        ? '✓ फिंगरप्रिन्ट प्रमाणित भयो'
                        : '✓ Fingerprint Verified'
                      : isNe
                      ? 'फिंगरप्रिन्ट ट्याप (ऐच्छिक)'
                      : 'Fingerprint Tap (Optional)'}
                  </span>
                </button>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsMobileClockInOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="button"
                  onClick={handleConfirmMobileClockIn}
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {isNe
                      ? `${selfClockType === 'IN' ? 'Log In' : 'Log Out'} प्रमाणित गर्नुहोस्`
                      : `Confirm ${selfClockType}`}
                  </span>
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: OWNER OVERRIDE PIN FOR NO-GPS ATTENDANCE                             */}
      {/* ========================================================================= */}
      {isOwnerOverrideModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-amber-900 text-white">
              <div className="flex items-center gap-2">
                <Key className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold">
                  {isNe ? 'मालिकको अनुमति (विना Location हाजिरी)' : 'Owner Approval Clock-In'}
                </h3>
              </div>
              <button
                onClick={() => setIsOwnerOverrideModalOpen(false)}
                className="text-amber-200 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleOwnerOverrideSubmit} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs">
                <p className="font-semibold">
                  {isNe
                    ? 'GPS लोकेसन बिना हाजिरी दर्ता गर्न मालिक वा सुपरभाइजरको Master PIN प्रविष्ट गर्नुहोस्।'
                    : 'Enter Owner Master PIN to grant location exception for this attendance.'}
                </p>
                <p className="text-[10px] text-amber-700 mt-1">
                 
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'मालिक PIN (Owner Master PIN):*' : 'Owner PIN:*'}
                </label>
                <input
                  type="password"
                  required
                  autoFocus
                  value={ownerOverridePin}
                  onChange={(e) => setOwnerOverridePin(e.target.value)}
                  placeholder="****"
                  className="w-full text-center tracking-widest px-3 py-2.5 border border-slate-300 rounded-xl font-mono text-lg font-bold focus:ring-2 focus:ring-amber-500"
                />
                {ownerOverrideError && (
                  <p className="text-xs font-semibold text-rose-600 mt-1.5">{ownerOverrideError}</p>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsOwnerOverrideModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-semibold"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isNe ? 'स्वीकृत गरी हाजिर गर्ने' : 'Approve & Clock In'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: SHIFT TIMINGS SETTING MODAL (मालिकले समय Set गर्ने)             */}
      {/* ========================================================================= */}
      {isShiftModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
              <h3 className="text-sm font-bold">
                {isNe ? 'हाजिरी समय तालिका सेटिङ (Owner Shift Hours)' : 'Shift Timings'}
              </h3>
              <button onClick={() => setIsShiftModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveShiftSettings} className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'बिहानी हाजिरी समय (Log In):*' : 'Shift Start (In):*'}
                  </label>
                  <input
                    type="text"
                    required
                    value={shiftStart}
                    onChange={(e) => setShiftStart(e.target.value)}
                    placeholder="10:00 AM"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-sm"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'साँझ बिदा समय (Log Out):*' : 'Shift End (Out):*'}
                  </label>
                  <input
                    type="text"
                    required
                    value={shiftEnd}
                    onChange={(e) => setShiftEnd(e.target.value)}
                    placeholder="05:00 PM"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-sm"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer select-none pt-2">
                <input
                  type="checkbox"
                  checked={autoShiftTime}
                  onChange={(e) => setAutoShiftTime(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-xs font-semibold text-slate-800">
                  {isNe ? 'हाजिर गर्दा यो समय स्वतः सेट हुने बनाउने' : 'Auto-apply this shift time on clock-in/out'}
                </span>
              </label>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsShiftModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg shadow-xs"
                >
                  {isNe ? 'सुरक्षित गर्नुहोस्' : 'Save Shift'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: SUPERVISOR BULK ATTENDANCE (सामूहिक हाजिरी)                       */}
      {/* ========================================================================= */}
      {isSupervisorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="text-sm font-bold">
                    {isNe ? 'सामूहिक / सुपरभाइजर हाजिरी प्रणाली' : 'Group Supervisor Attendance'}
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    {isNe ? 'कुनै एक जनाले सबैको फोटो वा बायोमेट्रिक लिएर स्वतः हाजिर गर्ने' : 'Supervisor biometric & photo clock-in for all staff'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsSupervisorModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'हाजिर प्रमाणित गर्ने सुपरभाइजर / जिम्मेवार व्यक्ति:*' : 'Supervisor In-Charge:*'}
                </label>
                <select
                  value={supervisorEmpId}
                  onChange={(e) => setSupervisorEmpId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 bg-white"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.role})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'हाजिरको प्रकार:*' : 'Attendance Type:*'}
                  </label>
                  <div className="grid grid-cols-2 gap-1.5 bg-slate-100 p-1 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setSupervisorType('IN')}
                      className={`py-1.5 text-center font-bold rounded-md transition cursor-pointer ${
                        supervisorType === 'IN'
                          ? 'bg-emerald-700 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {isNe ? 'Log In' : 'Log In'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setSupervisorType('OUT')}
                      className={`py-1.5 text-center font-bold rounded-md transition cursor-pointer ${
                        supervisorType === 'OUT'
                          ? 'bg-slate-900 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {isNe ? 'Log Out' : 'Log Out'}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'स्वतः सेट हुने समय:' : 'Auto Set Time:'}
                  </label>
                  <div className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900 font-mono font-bold text-sm">
                    <Clock className="w-4 h-4 text-emerald-700" />
                    <span>
                      {company.autoSetShiftTime
                        ? (supervisorType === 'IN' ? company.shiftStartTime || '10:00 AM' : company.shiftEndTime || '05:00 PM')
                        : currentLiveTime}
                    </span>
                  </div>
                </div>
              </div>

              {/* Work Category & Site for Bulk Supervisor Attendance */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'कामको प्रकार (Work Category):*' : 'Work Category:*'}
                  </label>
                  <select
                    value={supervisorWorkCategory}
                    onChange={(e) => setSupervisorWorkCategory(e.target.value as StaffWorkCategory)}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 bg-white"
                  >
                    {activeWorkCategories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {isNe ? cat.labelNe : cat.labelEn}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {isNe ? 'ग्राहक वा फिल्ड ठाउँ (Site Name):' : 'Site / Client Name:'}
                  </label>
                  <input
                    type="text"
                    list="master-site-presets-list"
                    value={supervisorSiteOrClient}
                    onChange={(e) => setSupervisorSiteOrClient(e.target.value)}
                    placeholder={isNe ? 'उदा: टनेल निर्माण साइट...' : 'e.g. Tunnel Site...'}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSupervisorBiometricVerified(true)}
                  className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-semibold transition cursor-pointer ${
                    supervisorBiometricVerified
                      ? 'bg-emerald-600 border-emerald-700 text-white shadow-xs'
                      : 'bg-white border-slate-300 hover:bg-slate-100 text-slate-800'
                  }`}
                >
                  <Fingerprint className="w-4 h-4 text-amber-500" />
                  <span>{supervisorBiometricVerified ? (isNe ? '✓ फिंगरप्रिन्ट प्रमाणित' : '✓ Biometric OK') : (isNe ? 'फिंगरप्रिन्ट स्क्यान' : 'Scan Fingerprint')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSupervisorPhotoCaptured(true)}
                  className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-semibold transition cursor-pointer ${
                    supervisorPhotoCaptured
                      ? 'bg-emerald-600 border-emerald-700 text-white shadow-xs'
                      : 'bg-white border-slate-300 hover:bg-slate-100 text-slate-800'
                  }`}
                >
                  <Camera className="w-4 h-4 text-emerald-600" />
                  <span>{supervisorPhotoCaptured ? (isNe ? '✓ फोटो खिचियो' : '✓ Photo Snapped') : (isNe ? 'फोटो खिच्नुहोस्' : 'Snap Photo')}</span>
                </button>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-bold text-slate-800 block">
                  {isNe ? 'हाजिर हुने कर्मचारीहरू (Select Staff):' : 'Staff Members to Clock:'}
                </label>
                <div className="max-h-40 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100 bg-white">
                  {employees.map((emp) => {
                    const isSelected = selectedEmpIds.includes(emp.id);
                    return (
                      <div
                        key={emp.id}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedEmpIds(selectedEmpIds.filter((id) => id !== emp.id));
                          } else {
                            setSelectedEmpIds([...selectedEmpIds, emp.id]);
                          }
                        }}
                        className={`p-2.5 flex items-center justify-between cursor-pointer ${
                          isSelected ? 'bg-emerald-50/50' : 'hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <input type="checkbox" checked={isSelected} onChange={() => {}} className="w-4 h-4 rounded text-emerald-600" />
                          <span className="font-semibold text-slate-900">{emp.name} ({emp.role})</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsSupervisorModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="button"
                  onClick={handleConfirmSupervisorAttendance}
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isNe ? `${selectedEmpIds.length} जनाको हाजिरी दर्ता गर्नुहोस्` : 'Submit Attendance'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: ADD EMPLOYEE                                                     */}
      {/* ========================================================================= */}
      {isAddStaffOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">{t.addStaff}</h3>
              <button onClick={() => setIsAddStaffOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!empName.trim()) return;
                saveEmployee({
                  id: `emp-${Date.now()}`,
                  name: empName.trim(),
                  role: empRole.trim() || 'कर्मचारी',
                  phone: empPhone.trim(),
                  wageType: empWageType,
                  salaryMonthly: empSalary,
                  dailyWageRate: empDailyWageRate,
                  joinedDateBs: todayBs,
                  openingDue: empOpeningDue,
                  registeredPhotoUrl: empRegisteredPhoto || undefined
                });
                setIsAddStaffOpen(false);
                setEmpName('');
                setEmpRole('');
                setEmpPhone('');
                setEmpWageType('MONTHLY');
                setEmpSalary(25000);
                setEmpDailyWageRate(1000);
                setEmpOpeningDue(0);
                setEmpRegisteredPhoto('');
              }}
              className="p-5 space-y-3.5 text-xs"
            >
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">कर्मचारीको नाम*</label>
                <input
                  type="text"
                  required
                  value={empName}
                  onChange={(e) => setEmpName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">पद (Designation)*</label>
                <select
                  value={empRole}
                  onChange={(e) => setEmpRole(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium"
                >
                  <option value="">{isNe ? 'पद छान्नुहोस्...' : 'Select role...'}</option>
                  {company.staffRoles?.map((role) => (
                    <option key={role.id} value={isNe ? role.titleNe : role.titleEn}>
                      {isNe ? role.titleNe : role.titleEn}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">फोन नम्बर</label>
                <input
                  type="text"
                  value={empPhone}
                  onChange={(e) => setEmpPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              {/* Wage Type Selection: Monthly vs Daily */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'तलब वा ज्यालाको प्रकार छान्नुहोस्:*' : 'Wage / Salary Type:*'}
                </label>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setEmpWageType('DAILY')}
                    className={`py-1.5 text-center font-bold rounded-lg transition cursor-pointer text-xs ${
                      empWageType === 'DAILY'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isNe ? '१. दैनिक ज्याला (Daily)' : 'Daily Wage'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setEmpWageType('MONTHLY')}
                    className={`py-1.5 text-center font-bold rounded-lg transition cursor-pointer text-xs ${
                      empWageType === 'MONTHLY'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isNe ? '२. मासिक तलब (Monthly)' : 'Monthly Salary'}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {empWageType === 'DAILY' ? (
                  <div>
                    <label className="block text-[11px] font-bold text-amber-900 mb-1">
                      {isNe ? 'दैनिक ज्याला दर (रु./दिन):*' : 'Daily Wage Rate (Rs.):*'}
                    </label>
                    <input
                      type="number"
                      required
                      min={100}
                      value={empDailyWageRate}
                      onChange={(e) => setEmpDailyWageRate(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-amber-300 rounded-lg font-mono font-bold text-slate-900 bg-amber-50/50"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block text-[11px] font-bold text-blue-900 mb-1">
                      {isNe ? 'मासिक तलब (रु.):*' : 'Monthly Salary (Rs.):*'}
                    </label>
                    <input
                      type="number"
                      required
                      min={1000}
                      value={empSalary}
                      onChange={(e) => setEmpSalary(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 border border-blue-300 rounded-lg font-mono font-bold text-slate-900 bg-blue-50/50"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'सुरुवाती पेस्की (रु.):' : 'Opening Advance (Rs.):'}
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={empOpeningDue}
                    onChange={(e) => setEmpOpeningDue(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              {/* Employee Reference Photo Upload right during Staff Creation */}
              <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-2">
                <label className="block text-[11px] font-bold text-indigo-950">
                  {isNe
                    ? '📸 कर्मचारीको पहिचान फोटो अपलोड गर्नुहोस् (पछि क्यामेराबाट हाजिरी चिन्न):'
                    : '📸 Upload Employee Reference Photo (For Camera Recognition):'}
                </label>
                <div className="flex items-center gap-3">
                  {empRegisteredPhoto ? (
                    <img
                      src={empRegisteredPhoto}
                      alt="Preview"
                      className="w-14 h-14 rounded-xl object-cover border-2 border-indigo-600 shrink-0"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-xl bg-white border border-dashed border-indigo-300 flex items-center justify-center text-indigo-400 shrink-0">
                      <Camera className="w-5 h-5" />
                    </div>
                  )}
                  <div className="flex-1 space-y-1.5">
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs rounded-lg cursor-pointer transition">
                      <Camera className="w-3.5 h-3.5 text-amber-300" />
                      <span>
                        {empRegisteredPhoto
                          ? isNe
                            ? 'अर्को फोटो छान्नुहोस् / खिच्नुहोस्'
                            : 'Change Photo'
                          : isNe
                          ? 'फोटो अपलोड / क्यामेराबाट खिच्नुहोस्'
                          : 'Upload / Capture Photo'}
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          const dataUrl = await resizeAndGetDataUrl(file, 320);
                          setEmpRegisteredPhoto(dataUrl);
                        }}
                      />
                    </label>
                    <p className="text-[10px] text-slate-600">
                      {isNe
                        ? 'यो फोटो सेभ भएपछि मोबाइल वा डेस्कटप क्यामेराबाट फोटो खिचेर स्वतः पहिचान हुनेछ।'
                        : 'Once uploaded, staff can clock in via Mobile or Desktop camera recognition.'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddStaffOpen(false)}
                  className="px-3 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  onClick={() => {
                    // Ensure empRegisteredPhoto is passed via saveEmployee below
                  }}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-lg shadow-xs cursor-pointer"
                >
                  {isNe ? 'कर्मचारी सुरक्षित गर्नुहोस्' : 'Save Employee'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4B: PHOTO UPLOAD REGISTRATION & MOBILE/DESKTOP CAMERA RECOGNITION   */}
      {/* ========================================================================= */}
      {isPhotoRecognitionOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
            {/* Modal Header */}
            <div className="px-5 py-4 bg-gradient-to-r from-indigo-950 via-indigo-900 to-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Camera className="w-6 h-6 text-amber-400 shrink-0" />
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold">
                    {isNe
                      ? '📸 कर्मचारी फोटो अपलोड र क्यामेरा पहिचान हाजिरी (Mobile & Desktop)'
                      : '📸 Staff Photo Upload & Camera Face Recognition Attendance'}
                  </h3>
                  <p className="text-[11px] text-indigo-200">
                    {isNe
                      ? 'चरण १: पहिले कर्मचारीको फोटो अपलोड/दर्ता गर्नुहोस् • चरण २: पछि मोबाइल वा डेस्कटपबाट फोटो खिचेर पहिचान र हाजिर गर्नुहोस्'
                      : 'Step 1: Upload employee reference photo • Step 2: Capture photo from Mobile or Desktop to recognize & mark attendance'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  stopLiveCameraStream();
                  setIsPhotoRecognitionOpen(false);
                }}
                className="p-1.5 text-indigo-200 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Step Switcher Tabs */}
            <div className="grid grid-cols-2 bg-slate-100 p-1.5 border-b border-slate-200 gap-1.5 text-xs">
              <button
                type="button"
                onClick={() => {
                  stopLiveCameraStream();
                  setPhotoModalMode('UPLOAD_REGISTER');
                  setPhotoSuccessBanner(null);
                }}
                className={`py-2.5 px-3 rounded-xl font-extrabold flex items-center justify-center gap-2 transition cursor-pointer ${
                  photoModalMode === 'UPLOAD_REGISTER'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-amber-50 border border-slate-200'
                }`}
              >
                <Camera className="w-4 h-4" />
                <span>
                  {isNe
                    ? `१. पहिले फोटो अपलोड / दर्ता (${employees.filter((e) => !!e.registeredPhotoUrl).length}/${employees.length})`
                    : `1. First Upload Staff Photo (${employees.filter((e) => !!e.registeredPhotoUrl).length}/${employees.length})`}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  stopLiveCameraStream();
                  setPhotoModalMode('RECOGNIZE');
                  setPhotoSuccessBanner(null);
                }}
                className={`py-2.5 px-3 rounded-xl font-extrabold flex items-center justify-center gap-2 transition cursor-pointer ${
                  photoModalMode === 'RECOGNIZE'
                    ? 'bg-indigo-700 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-indigo-50 border border-slate-200'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>
                  {isNe
                    ? '२. फोटो खिचेर पहिचान र हाजिरी (Mobile / Desktop)'
                    : '2. Capture Photo & Recognize Staff'}
                </span>
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs max-h-[80vh] overflow-y-auto">
              {photoSuccessBanner && (
                <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-950 rounded-xl font-bold flex items-center justify-between">
                  <span>{photoSuccessBanner}</span>
                  <button
                    type="button"
                    onClick={() => setPhotoSuccessBanner(null)}
                    className="text-emerald-700 hover:text-emerald-950 p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {cameraErrorMsg && (
                <div className="p-3 bg-amber-50 border border-amber-300 text-amber-950 rounded-xl font-semibold">
                  {cameraErrorMsg}
                </div>
              )}

              {/* ================================================================= */}
              {/* MODE 1: FIRST UPLOAD / REGISTER EMPLOYEE REFERENCE PHOTO          */}
              {/* ================================================================= */}
              {photoModalMode === 'UPLOAD_REGISTER' && (
                <div className="space-y-4">
                  <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-800 mb-1">
                          {isNe ? '१. कर्मचारी छान्नुहोस्:*' : '1. Select Employee:*'}
                        </label>
                        <select
                          value={uploadTargetEmpId}
                          onChange={(e) => {
                            const id = e.target.value;
                            setUploadTargetEmpId(id);
                            const emp = employees.find((x) => x.id === id);
                            setUploadPreviewPhoto(emp?.registeredPhotoUrl || '');
                          }}
                          className="w-full px-3 py-2 border border-slate-300 rounded-xl font-bold text-slate-900 bg-white"
                        >
                          {employees.map((emp) => (
                            <option key={emp.id} value={emp.id}>
                              {emp.name} ({emp.role}) {emp.registeredPhotoUrl ? '✓ [फोटो दर्ता छ]' : '⚠️ [फोटो बाँकी]'}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="flex flex-col justify-end gap-1.5">
                        <label className="w-full py-2 px-3 bg-indigo-700 hover:bg-indigo-800 text-white font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs transition">
                          <Camera className="w-4 h-4 text-amber-300" />
                          <span>
                            {isNe
                              ? '📁 मोबाइल / कम्प्युटरबाट फोटो अपलोड गर्नुहोस्'
                              : '📁 Upload Photo from Mobile / Desktop'}
                          </span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              const dataUrl = await resizeAndGetDataUrl(file, 320);
                              setUploadPreviewPhoto(dataUrl);
                              if (uploadTargetEmpId) {
                                handleSaveEmployeeReferencePhoto(uploadTargetEmpId, dataUrl);
                              }
                            }}
                          />
                        </label>
                      </div>
                    </div>

                    {/* Or Use Live Camera to Register Reference Photo */}
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      {!isCameraStreaming ? (
                        <button
                          type="button"
                          onClick={() => startLiveCameraStream('user')}
                          className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 rounded-xl font-bold flex items-center gap-1.5 cursor-pointer"
                        >
                          <Camera className="w-3.5 h-3.5 text-emerald-700" />
                          <span>
                            {isNe
                              ? '📷 लाइभ वेबक्याम / मोबाइल क्यामेरा खोल्नुहोस्'
                              : '📷 Open Live Webcam / Mobile Camera'}
                          </span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={stopLiveCameraStream}
                          className="px-3 py-1.5 bg-rose-600 text-white rounded-xl font-bold cursor-pointer"
                        >
                          {isNe ? '✕ क्यामेरा बन्द गर्नुहोस्' : '✕ Stop Camera'}
                        </button>
                      )}
                    </div>

                    {isCameraStreaming && (
                      <div className="p-3 bg-slate-900 rounded-xl text-center space-y-2">
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          muted
                          className="w-full max-w-xs mx-auto rounded-lg border-2 border-emerald-400"
                        />
                        <button
                          type="button"
                          onClick={handleCaptureFromLiveVideo}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl cursor-pointer flex items-center gap-1.5 mx-auto"
                        >
                          <Camera className="w-4 h-4" />
                          <span>{isNe ? '📸 फोटो खिचेर राख्नुहोस्' : '📸 Snap Photo'}</span>
                        </button>
                      </div>
                    )}

                    {/* Preview & Save Uploaded Reference Photo */}
                    {uploadPreviewPhoto && (
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-white rounded-xl border border-emerald-300">
                        <div className="flex items-center gap-3">
                          <img
                            src={uploadPreviewPhoto}
                            alt="Uploaded Reference"
                            className="w-16 h-16 rounded-xl object-cover border-2 border-emerald-600"
                          />
                          <div>
                            <span className="font-extrabold text-slate-900 block">
                              {employees.find((e) => e.id === uploadTargetEmpId)?.name}
                            </span>
                            <span className="text-[11px] text-emerald-700 font-bold">
                              {isNe
                                ? '✓ पहिचान फोटो तयार छ (Reference Photo Ready)'
                                : '✓ Reference Photo Ready'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              handleSaveEmployeeReferencePhoto(uploadTargetEmpId, uploadPreviewPhoto)
                            }
                            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl cursor-pointer flex items-center gap-1.5 shadow-xs"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>{isNe ? 'फोटो सुरक्षित गर्नुहोस्' : 'Save Reference Photo'}</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setPhotoModalMode('RECOGNIZE')}
                            className="px-3 py-2 bg-indigo-700 hover:bg-indigo-800 text-white font-bold rounded-xl cursor-pointer"
                          >
                            {isNe ? '२. अब फोटो खिचेर पहिचानमा जानुहोस् →' : '2. Go to Recognition →'}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* All Staff Photo Enrollment Status Grid */}
                  <div>
                    <h4 className="font-bold text-slate-800 mb-2">
                      {isNe
                        ? 'सबै कर्मचारीहरूको पहिचान फोटो अवस्था (फोटो थप्न वा बदल्न क्लिक गर्नुहोस्):'
                        : 'All Employees Reference Photo Status:'}
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {employees.map((emp) => (
                        <div
                          key={emp.id}
                          className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/70 flex items-center justify-between gap-2"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            {emp.registeredPhotoUrl ? (
                              <img
                                src={emp.registeredPhotoUrl}
                                alt={emp.name}
                                className="w-11 h-11 rounded-lg object-cover border border-emerald-500 shrink-0"
                              />
                            ) : (
                              <div className="w-11 h-11 rounded-lg bg-amber-100 border border-dashed border-amber-400 flex items-center justify-center text-amber-800 shrink-0">
                                <Camera className="w-4 h-4" />
                              </div>
                            )}
                            <div className="min-w-0">
                              <p className="font-bold text-slate-900 truncate">{emp.name}</p>
                              <p className="text-[10px] text-slate-500">
                                {emp.registeredPhotoUrl
                                  ? isNe
                                    ? '✓ पहिचान फोटो अपलोड छ'
                                    : '✓ Photo Uploaded'
                                  : isNe
                                  ? '⚠️ फोटो अपलोड बाँकी'
                                  : '⚠️ Not Uploaded'}
                              </p>
                            </div>
                          </div>

                          <label className="px-2.5 py-1.5 bg-white hover:bg-indigo-50 text-indigo-900 border border-indigo-200 rounded-lg font-bold text-[10px] cursor-pointer shrink-0">
                            {emp.registeredPhotoUrl
                              ? isNe
                                ? 'फोटो बदल्ने'
                                : 'Change'
                              : isNe
                              ? '+ फोटो अपलोड'
                              : '+ Upload'}
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                const dataUrl = await resizeAndGetDataUrl(file, 320);
                                setUploadTargetEmpId(emp.id);
                                setUploadPreviewPhoto(dataUrl);
                                handleSaveEmployeeReferencePhoto(emp.id, dataUrl);
                              }}
                            />
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* ================================================================= */}
              {/* MODE 2: CAPTURE PHOTO FROM MOBILE OR DESKTOP TO RECOGNIZE STAFF   */}
              {/* ================================================================= */}
              {photoModalMode === 'RECOGNIZE' && (
                <div className="space-y-4">
                  {/* Camera Controls for Mobile (Front/Back) & Desktop Webcam */}
                  <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h4 className="font-extrabold text-sm flex items-center gap-1.5">
                          <Camera className="w-4 h-4 text-amber-400" />
                          <span>
                            {isNe
                              ? 'मोबाइल वा डेस्कटप क्यामेराबाट कर्मचारीको फोटो खिच्नुहोस्'
                              : 'Capture Employee Photo via Mobile or Desktop Camera'}
                          </span>
                        </h4>
                        <p className="text-[11px] text-slate-300">
                          {isNe
                            ? 'खिचिएको फोटो पहिले अपलोड गरिएको फोटोसँग स्वचालित मिलान (Match) भई कर्मचारी पहिचान हुन्छ'
                            : 'Automatically compares captured photo against uploaded employee reference photos'}
                        </p>
                      </div>

                      {/* Camera Mode Switch: Front Selfie vs Back Camera */}
                      <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl">
                        <button
                          type="button"
                          onClick={() => {
                            setCameraDeviceMode('user');
                            if (isCameraStreaming) startLiveCameraStream('user');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer ${
                            cameraDeviceMode === 'user'
                              ? 'bg-emerald-600 text-white'
                              : 'text-slate-300 hover:text-white'
                          }`}
                        >
                          {isNe ? '🤳 सेल्फी / वेबक्याम' : '🤳 Front / Webcam'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setCameraDeviceMode('environment');
                            if (isCameraStreaming) startLiveCameraStream('environment');
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer ${
                            cameraDeviceMode === 'environment'
                              ? 'bg-emerald-600 text-white'
                              : 'text-slate-300 hover:text-white'
                          }`}
                        >
                          {isNe ? '📷 पछाडि क्यामेरा' : '📷 Back Camera'}
                        </button>
                      </div>
                    </div>

                    {/* Live Video Stream Box */}
                    {isCameraStreaming && (
                      <div className="space-y-2.5 text-center">
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          muted
                          className="w-full max-w-sm mx-auto rounded-xl border-2 border-emerald-400 shadow-lg bg-black"
                        />
                        <div className="flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={handleCaptureFromLiveVideo}
                            className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold rounded-xl shadow-md cursor-pointer flex items-center gap-2"
                          >
                            <Camera className="w-4 h-4" />
                            <span>
                              {isNe ? '📸 फोटो खिचेर पहिचान गर्नुहोस् (Snap & Recognize)' : '📸 Snap & Recognize'}
                            </span>
                          </button>
                          <button
                            type="button"
                            onClick={stopLiveCameraStream}
                            className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold cursor-pointer"
                          >
                            {isNe ? 'बन्द' : 'Stop'}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons: Start Live Camera OR Direct Mobile/Desktop Capture Input */}
                    {!isCameraStreaming && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                        <button
                          type="button"
                          onClick={() => startLiveCameraStream(cameraDeviceMode)}
                          className="py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer transition"
                        >
                          <Camera className="w-4 h-4" />
                          <span>
                            {isNe
                              ? '🎥 लाइभ क्यामेरा खोल्नुहोस् (Mobile / Desktop Webcam)'
                              : '🎥 Start Live Camera (Mobile / Desktop)'}
                          </span>
                        </button>

                        <label className="py-3 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer transition text-center">
                          <Smartphone className="w-4 h-4 text-amber-300" />
                          <span>
                            {isNe
                              ? '📸 मोबाइल क्यामेरा / फाइलबाट फोटो खिच्नुहोस्'
                              : '📸 Capture / Select Photo from Device'}
                          </span>
                          <input
                            type="file"
                            accept="image/*"
                            capture={cameraDeviceMode}
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              const dataUrl = await resizeAndGetDataUrl(file, 320);
                              await runEmployeePhotoRecognition(dataUrl);
                            }}
                          />
                        </label>
                      </div>
                    )}
                  </div>

                  {/* Recognition Results & Side-by-Side Comparison */}
                  {capturedLivePhoto && (
                    <div className="p-4 bg-indigo-50/70 border-2 border-indigo-300 rounded-2xl space-y-4">
                      {isMatchingPhoto ? (
                        <div className="py-6 text-center font-bold text-indigo-900">
                          {isNe ? '🔍 दर्ता भएका कर्मचारीको फोटोसँग मिलान गरिँदैछ...' : '🔍 Matching against enrolled photos...'}
                        </div>
                      ) : (
                        <>
                          {(() => {
                            const matchedEmp =
                              employees.find((e) => e.id === recognizedEmpId) || employees[0];
                            const matchedScoreObj = photoMatchResults.find(
                              (m) => m.emp.id === matchedEmp?.id
                            );
                            const scorePct = matchedScoreObj ? matchedScoreObj.score : 88;

                            return (
                              <>
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-indigo-200">
                                  <div>
                                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-700 block">
                                      {isNe ? 'स्वचालित फोटो पहिचान नतिजा (Recognition Result)' : 'Recognition Result'}
                                    </span>
                                    <h4 className="text-base font-black text-slate-900 flex items-center gap-2">
                                      <span>{matchedEmp?.name || '-'}</span>
                                      <span className="text-xs font-bold px-2.5 py-0.5 rounded-lg bg-emerald-600 text-white">
                                        {isNe ? `✓ पहिचान मिलान: ${scorePct}%` : `✓ ${scorePct}% Match`}
                                      </span>
                                    </h4>
                                  </div>

                                  {photoMatchResults.length > 1 && (
                                    <div className="text-right">
                                      <span className="text-[10px] text-slate-500 block">
                                        {isNe ? 'अन्य मिलान स्कोर:' : 'Other Matches:'}
                                      </span>
                                      <div className="flex flex-wrap gap-1 mt-0.5">
                                        {photoMatchResults.slice(0, 3).map((m) => (
                                          <button
                                            key={m.emp.id}
                                            type="button"
                                            onClick={() => setRecognizedEmpId(m.emp.id)}
                                            className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer ${
                                              m.emp.id === recognizedEmpId
                                                ? 'bg-indigo-700 text-white'
                                                : 'bg-white text-slate-700 border border-slate-300'
                                            }`}
                                          >
                                            {m.emp.name}: {m.score}%
                                          </button>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </div>

                                {/* Side-by-Side Photo Comparison */}
                                <div className="grid grid-cols-2 gap-3 bg-white p-3 rounded-xl border border-indigo-200 text-center">
                                  <div>
                                    <span className="text-[11px] font-bold text-slate-600 block mb-1.5">
                                      {isNe ? '१. पहिले अपलोड गरिएको फोटो' : '1. Uploaded Reference Photo'}
                                    </span>
                                    {matchedEmp?.registeredPhotoUrl ? (
                                      <img
                                        src={matchedEmp.registeredPhotoUrl}
                                        alt="Reference"
                                        className="w-24 h-24 sm:w-28 sm:h-28 mx-auto rounded-xl object-cover border-2 border-indigo-500 shadow-xs"
                                      />
                                    ) : (
                                      <div className="w-24 h-24 sm:w-28 sm:h-28 mx-auto rounded-xl bg-amber-50 border-2 border-dashed border-amber-400 flex flex-col items-center justify-center p-2 text-amber-900">
                                        <span className="text-[10px] font-bold">
                                          {isNe ? 'पहिले फोटो अपलोड भएको छैन' : 'No Reference Photo'}
                                        </span>
                                        <button
                                          type="button"
                                          onClick={() => {
                                            if (matchedEmp) {
                                              handleSaveEmployeeReferencePhoto(
                                                matchedEmp.id,
                                                capturedLivePhoto
                                              );
                                            }
                                          }}
                                          className="mt-1 px-2 py-1 bg-amber-600 text-white rounded text-[9px] font-bold cursor-pointer"
                                        >
                                          {isNe ? 'यसैलाई दर्ता गर्नुहोस्' : 'Register This Photo'}
                                        </button>
                                      </div>
                                    )}
                                  </div>

                                  <div>
                                    <span className="text-[11px] font-bold text-emerald-700 block mb-1.5">
                                      {isNe ? '२. अहिले खिचिएको फोटो (Live)' : '2. Newly Captured Photo'}
                                    </span>
                                    <img
                                      src={capturedLivePhoto}
                                      alt="Captured Live"
                                      className="w-24 h-24 sm:w-28 sm:h-28 mx-auto rounded-xl object-cover border-2 border-emerald-500 shadow-xs"
                                    />
                                  </div>
                                </div>

                                {/* Attendance Form Controls for Recognized Employee */}
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-700 mb-1">
                                      {isNe ? 'पहिचान भएको कर्मचारी:' : 'Recognized Staff:'}
                                    </label>
                                    <select
                                      value={recognizedEmpId}
                                      onChange={(e) => setRecognizedEmpId(e.target.value)}
                                      className="w-full px-2.5 py-2 border border-slate-300 rounded-xl font-bold text-slate-900 bg-white"
                                    >
                                      {employees.map((emp) => (
                                        <option key={emp.id} value={emp.id}>
                                          {emp.name} ({emp.role})
                                        </option>
                                      ))}
                                    </select>
                                  </div>

                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-700 mb-1">
                                      {isNe ? 'हाजिरी प्रकार (In / Out):' : 'Clock Type:'}
                                    </label>
                                    <select
                                      value={recognizedClockType}
                                      onChange={(e) =>
                                        setRecognizedClockType(e.target.value as 'IN' | 'OUT')
                                      }
                                      className="w-full px-2.5 py-2 border border-slate-300 rounded-xl font-bold text-slate-900 bg-white"
                                    >
                                      <option value="IN">१. Log In (आगमन हाजिरी)</option>
                                      <option value="OUT">२. Log Out (प्रस्थान बिदा)</option>
                                    </select>
                                  </div>

                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-700 mb-1">
                                      {isNe ? 'गर्ने कामको प्रकार:' : 'Work Category:'}
                                    </label>
                                    <select
                                      value={recognizedWorkCategory}
                                      onChange={(e) =>
                                        setRecognizedWorkCategory(e.target.value as StaffWorkCategory)
                                      }
                                      className="w-full px-2.5 py-2 border border-slate-300 rounded-xl font-bold text-slate-900 bg-white"
                                    >
                                      {activeWorkCategories.map((cat) => (
                                        <option key={cat.id} value={cat.id}>
                                          {cat.shortNe}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>

                                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                                  <input
                                    type="text"
                                    list="master-site-presets-list"
                                    value={recognizedSiteName}
                                    onChange={(e) => setRecognizedSiteName(e.target.value)}
                                    placeholder={
                                      isNe
                                        ? 'ठाउँ वा ग्राहकको नाम (ऐच्छिक)...'
                                        : 'Site or Client Name (Optional)...'
                                    }
                                    className="flex-1 px-3 py-2 border border-slate-300 rounded-xl bg-white"
                                  />
                                  <button
                                    type="button"
                                    onClick={handleConfirmPhotoRecognizedAttendance}
                                    className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap"
                                  >
                                    <CheckCircle2 className="w-4 h-4" />
                                    <span>
                                      {isNe
                                        ? '✅ पहिचान प्रमाणित गरी हाजिरी लगाउनुहोस्'
                                        : '✅ Verify & Mark Attendance'}
                                    </span>
                                  </button>
                                </div>
                              </>
                            );
                          })()}
                        </>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: DAILY WAGE & SALARY PAYOUT MODAL                                 */}
      {/* ========================================================================= */}
      {isSalaryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-emerald-800 text-white">
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-emerald-300" />
                <div>
                  <h3 className="text-sm font-bold">
                    {isNe ? 'दैनिक ज्याला तथा तलब भुक्तानी' : 'Pay Daily Wage / Salary'}
                  </h3>
                  <p className="text-[11px] text-emerald-200">
                    {isNe ? 'काम गरेको दिनको हिसाब, कट्टी समायोजन र भुक्तानी' : 'Daily wage computation, deductions, and payout'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsSalaryModalOpen(false)}
                className="text-emerald-200 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmSalaryPayout} className="p-5 space-y-4 text-xs">
              {/* Employee Selection */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'कर्मचारी छान्नुहोस्:*' : 'Select Employee:*'}
                </label>
                <select
                  value={salaryEmpId}
                  onChange={(e) => {
                    const emp = employees.find((x) => x.id === e.target.value);
                    if (emp) handleOpenSalaryModal(emp);
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 bg-white"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.wageType === 'DAILY' ? 'दैनिक ज्याला' : 'मासिक तलब'} - {emp.role})
                    </option>
                  ))}
                </select>
              </div>

              {/* Wage Type Toggle */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'भुक्तानी गर्ने तरिका (Wage Type):*' : 'Payment Calculation Mode:*'}
                </label>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => {
                      setSalaryWageType('DAILY');
                      const gross = salaryDaysWorked * salaryDailyRate;
                      setSalaryAmount(Math.max(0, gross - salaryDeductAdvance));
                    }}
                    className={`py-2 text-center font-bold rounded-lg transition cursor-pointer ${
                      salaryWageType === 'DAILY'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isNe ? '१. दैनिक ज्याला (दिनको हिसाब)' : 'Daily Wage'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSalaryWageType('MONTHLY');
                      const emp = employees.find((e) => e.id === salaryEmpId);
                      const gross = emp ? emp.salaryMonthly : 25000;
                      setSalaryAmount(Math.max(0, gross - salaryDeductAdvance));
                    }}
                    className={`py-2 text-center font-bold rounded-lg transition cursor-pointer ${
                      salaryWageType === 'MONTHLY'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isNe ? '२. मासिक तलब (Full Month)' : 'Monthly Salary'}
                  </button>
                </div>
              </div>

              {/* Daily Wage Calculation Box */}
              {salaryWageType === 'DAILY' ? (
                <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl space-y-3">
                  <div className="flex items-center justify-between text-amber-950 font-bold">
                    <span>{isNe ? 'दैनिक हिसाब ज्याला गणना:' : 'Daily Wage Calculation:'}</span>
                    {(() => {
                      const summary = getEmployeePayrollSummary(salaryEmpId);
                      return (
                        <button
                          type="button"
                          onClick={() => {
                            const days = summary.presentDays > 0 ? summary.presentDays : 1;
                            setSalaryDaysWorked(days);
                            const gross = days * salaryDailyRate;
                            setSalaryAmount(Math.max(0, gross - salaryDeductAdvance));
                          }}
                          className="text-[10px] text-amber-800 underline hover:text-amber-950 cursor-pointer"
                        >
                          {isNe ? `हाजिरी अनुसार (${summary.presentDays} दिन) सेट गर्नुहोस्` : `Use ${summary.presentDays} days`}
                        </button>
                      );
                    })()}
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-amber-900 mb-1">
                        {isNe ? 'काम गरेको दिन:*' : 'Days Worked:*'}
                      </label>
                      <input
                        type="number"
                        required
                        min={0.5}
                        step={0.5}
                        value={salaryDaysWorked}
                        onChange={(e) => {
                          const d = parseFloat(e.target.value) || 0;
                          setSalaryDaysWorked(d);
                          const gross = d * salaryDailyRate;
                          setSalaryAmount(Math.max(0, gross - salaryDeductAdvance));
                        }}
                        className="w-full px-3 py-2 border border-amber-300 rounded-xl font-mono text-sm font-bold text-slate-900 bg-white"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-amber-900 mb-1">
                        {isNe ? 'दैनिक ज्याला दर (रु.):*' : 'Daily Wage Rate (Rs.):*'}
                      </label>
                      <input
                        type="number"
                        required
                        min={100}
                        value={salaryDailyRate}
                        onChange={(e) => {
                          const r = parseFloat(e.target.value) || 0;
                          setSalaryDailyRate(r);
                          const gross = salaryDaysWorked * r;
                          setSalaryAmount(Math.max(0, gross - salaryDeductAdvance));
                        }}
                        className="w-full px-3 py-2 border border-amber-300 rounded-xl font-mono text-sm font-bold text-slate-900 bg-white"
                      />
                    </div>
                  </div>

                  <div className="p-2.5 bg-white border border-amber-200 rounded-lg flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-semibold">{isNe ? 'जम्मा आर्जित ज्याला (दिन × दर):' : 'Gross Wage:'}</span>
                    <span className="font-mono font-bold text-emerald-800 text-sm">
                      रु. {(salaryDaysWorked * salaryDailyRate).toLocaleString()}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between text-xs">
                  <span className="text-slate-700 font-semibold">{isNe ? 'मासिक आधारभूत तलब:' : 'Monthly Base Salary:'}</span>
                  <span className="font-mono font-bold text-blue-900 text-sm">
                    रु. {(employees.find((e) => e.id === salaryEmpId)?.salaryMonthly || 25000).toLocaleString()}
                  </span>
                </div>
              )}

              {/* Deductions & Net Payout Adjustment */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-rose-900 mb-1">
                    {isNe ? 'पेस्की/कट्टी घटाउने (रु.):' : 'Deduct Advance/Purchases:'}
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={salaryDeductAdvance}
                    onChange={(e) => {
                      const ded = parseFloat(e.target.value) || 0;
                      setSalaryDeductAdvance(ded);
                      const gross = salaryWageType === 'DAILY'
                        ? salaryDaysWorked * salaryDailyRate
                        : (employees.find((x) => x.id === salaryEmpId)?.salaryMonthly || 25000);
                      setSalaryAmount(Math.max(0, gross - ded));
                    }}
                    className="w-full px-3 py-2 border border-rose-300 rounded-xl font-mono text-xs font-bold text-rose-900 bg-rose-50/50"
                  />
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    (बाँकी कट्टी: रु. {getEmployeePayrollSummary(salaryEmpId).totalDeductions.toLocaleString()})
                  </span>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-950 mb-1">
                    {isNe ? 'खुद भुक्तानी रकम (रु.):*' : 'Net Payout Amount (Rs.):*'}
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={salaryAmount}
                    onChange={(e) => setSalaryAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-emerald-400 rounded-xl font-mono text-sm font-bold text-emerald-950 bg-emerald-50"
                  />
                </div>
              </div>

              {/* Payment Mode: Cash vs Bank */}
              <div className="space-y-2">
                <label className="block text-[11px] font-bold text-slate-700">
                  {isNe ? 'भुक्तानीको माध्यम:*' : 'Payment Mode:*'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSalaryPaymentMode('CASH')}
                    className={`py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      salaryPaymentMode === 'CASH'
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <Wallet className="w-4 h-4" />
                    <span>{isNe ? 'नगद काउन्टर (Cash)' : 'Cash Counter'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSalaryPaymentMode('BANK')}
                    className={`py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer ${
                      salaryPaymentMode === 'BANK'
                        ? 'bg-blue-700 text-white border-blue-700 shadow-xs'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>{isNe ? 'बैंक ट्रान्सफर (Bank)' : 'Bank Transfer'}</span>
                  </button>
                </div>

                {salaryPaymentMode === 'CASH' ? (
                  <p className="text-[11px] text-slate-500 font-mono">
                    {isNe ? 'काउन्टरमा हाल मौज्दात:' : 'Current Counter Cash:'} रु. {dailyCash.closingCashInHand.toLocaleString()}
                  </p>
                ) : (
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {isNe ? 'भुक्तानी गर्ने बैंक खाता छान्नुहोस्:*' : 'Select Bank Account:*'}
                    </label>
                    <select
                      value={salaryBankAccountId}
                      onChange={(e) => setSalaryBankAccountId(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 bg-white"
                    >
                      {bankAccounts.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.bankName} - {b.accountNumber} (मौज्दात: रु. {b.currentBalance.toLocaleString()})
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* Notes */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'कैफियत / टिप्पणी (Remarks):' : 'Remarks / Notes:'}
                </label>
                <input
                  type="text"
                  value={salaryNotes}
                  onChange={(e) => setSalaryNotes(e.target.value)}
                  placeholder="उदा. ५ दिनको दैनिक ज्याला भुक्तानी"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsSalaryModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {isNe
                      ? `रु. ${salaryAmount.toLocaleString()} भुक्तानी प्रमाणित गर्नुहोस्`
                      : `Confirm Payout of Rs. ${salaryAmount}`}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 6: CASH ADVANCE MODAL                                               */}
      {/* ========================================================================= */}
      {isAdvanceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-purple-900 text-white">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-purple-300" />
                <h3 className="text-sm font-bold">
                  {isNe ? 'कर्मचारीलाई नगद पेस्की (Cash Advance)' : 'Give Cash Advance'}
                </h3>
              </div>
              <button
                onClick={() => setIsAdvanceModalOpen(false)}
                className="text-purple-200 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!advanceEmpId || advanceAmount <= 0) return;
                recordCashAdvance(advanceEmpId, advanceAmount, advanceNotes);
                setIsAdvanceModalOpen(false);
                setAdvanceAmount(1000);
                setAdvanceNotes('');
                alert(isNe ? 'नगद पेस्की भुक्तानी दर्ता भयो !' : 'Cash advance recorded!');
              }}
              className="p-5 space-y-4 text-xs"
            >
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'कर्मचारी छान्नुहोस्:*' : 'Select Employee:*'}
                </label>
                <select
                  value={advanceEmpId}
                  onChange={(e) => setAdvanceEmpId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 bg-white"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'पेस्की रकम (रु.):*' : 'Advance Amount (Rs.):*'}
                </label>
                <input
                  type="number"
                  required
                  min={100}
                  value={advanceAmount}
                  onChange={(e) => setAdvanceAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-purple-300 rounded-xl font-mono text-sm font-bold text-purple-950 bg-purple-50/50"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'कैफियत / कारण:' : 'Reason / Note:'}
                </label>
                <input
                  type="text"
                  value={advanceNotes}
                  onChange={(e) => setAdvanceNotes(e.target.value)}
                  placeholder="घरायसी खर्चको लागि पेस्की"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAdvanceModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl shadow-xs transition cursor-pointer"
                >
                  {isNe ? 'पेस्की भुक्तानी दर्ता गर्नुहोस्' : 'Confirm Advance'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 7: PRINTABLE MONTHLY STAFF ATTENDANCE SHEET (स्टाफलाई दिन मिल्ने सिट) */}
      {/* ========================================================================= */}
      {isMonthlySheetModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-2 sm:p-4 overflow-y-auto print:static print:inset-auto print:bg-white print:p-0">
          <div className="w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[94vh] flex flex-col print:max-h-none print:shadow-none print:border-none print:rounded-none">
            {/* Modal Control Bar (Hidden when printing) */}
            <div className="px-5 py-4 border-b border-slate-200 bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 print:hidden">
              <div className="flex items-center gap-2.5">
                <Printer className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-sm sm:text-base font-bold">
                    {isNe
                      ? 'महिनाभरिको स्टाफ हाजिरी तथा कामको विवरण सिट (स्टाफलाई दिन मिल्ने प्रिन्ट कार्ड)'
                      : 'Printable Monthly Staff Attendance & Work Sheet'}
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    {isNe
                      ? 'टनेल बनाउने, प्लास्टिक राख्ने, ट्याक्टर बनाउने, फिटिङ गर्ने र अरुकोमा जाने काम सहितको मासिक हाजिरी सिट'
                      : 'Full month attendance card with daily work category breakdown to hand over to staff'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-auto">
                <button
                  type="button"
                  onClick={handlePrintMonthlyStaffSheet}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>{isNe ? '🖨️ अहिले प्रिन्ट गर्नुहोस् (Print Sheet)' : '🖨️ Print Sheet'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsMonthlySheetModalOpen(false)}
                  className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Filter & Customization Bar (Hidden when printing) */}
            <div className="px-5 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs print:hidden">
              <div className="flex flex-wrap items-center gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                    {isNe ? 'साल (B.S.):' : 'Year:'}
                  </label>
                  <select
                    value={sheetYear}
                    onChange={(e) => setSheetYear(e.target.value)}
                    className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                  >
                    <option value="2083">२०८३ (2083)</option>
                    <option value="2082">२०८२ (2082)</option>
                    <option value="2081">२०८१ (2081)</option>
                    <option value="2080">२०८० (2080)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                    {isNe ? 'महिना छान्नुहोस्:' : 'Month:'}
                  </label>
                  <select
                    value={sheetMonth}
                    onChange={(e) => setSheetMonth(e.target.value)}
                    className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                  >
                    {NEPALI_MONTHS_LIST.map((m) => (
                      <option key={m.code} value={m.code}>
                        {m.code} - {isNe ? m.nameNe : m.nameEn}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5">
                    {isNe ? 'स्टाफ / कर्मचारी छान्नुहोस्:' : 'Select Staff:'}
                  </label>
                  <select
                    value={sheetEmpId}
                    onChange={(e) => setSheetEmpId(e.target.value)}
                    className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg font-bold text-slate-900"
                  >
                    <option value="ALL">👥 सबै स्टाफको छुट्टाछुट्टै सिट (All Staff)</option>
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.name} ({emp.role})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <label className="flex items-center gap-1.5 cursor-pointer select-none font-semibold text-slate-700">
                  <input
                    type="checkbox"
                    checked={sheetShowFullCalendarDays}
                    onChange={(e) => setSheetShowFullCalendarDays(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600"
                  />
                  <span>{isNe ? 'महिनाको १ देखि ३० गते सम्म पूरै तालिका देखाउने' : 'Show all 1-30 days'}</span>
                </label>

                <label className="flex items-center gap-1.5 cursor-pointer select-none font-semibold text-slate-700">
                  <input
                    type="checkbox"
                    checked={sheetShowWageSummary}
                    onChange={(e) => setSheetShowWageSummary(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600"
                  />
                  <span>{isNe ? 'ज्याला / पेस्की हिसाब पनि समावेश गर्ने' : 'Include Wage & Advance Summary'}</span>
                </label>
              </div>
            </div>

            {/* Printable Sheet Body */}
            <div id="printable-attendance-sheet" className="p-4 sm:p-6 overflow-y-auto space-y-8 bg-white print:p-0 print:overflow-visible">
              {(() => {
                const targetStaffList =
                  sheetEmpId === 'ALL'
                    ? employees
                    : employees.filter((e) => e.id === sheetEmpId);

                const monthMeta =
                  NEPALI_MONTHS_LIST.find((m) => m.code === sheetMonth) || NEPALI_MONTHS_LIST[0];

                if (targetStaffList.length === 0) {
                  return (
                    <div className="p-8 text-center text-slate-400">
                      {isNe ? 'कुनै कर्मचारी दर्ता गरिएको छैन।' : 'No employees found.'}
                    </div>
                  );
                }

                return targetStaffList.map((emp, staffIdx) => {
                  const sheetData = buildStaffMonthlySheetData(emp, sheetYear, sheetMonth);

                  return (
                    <div
                      key={emp.id}
                      className={`border border-slate-300 rounded-lg p-6 bg-white space-y-6 ${
                        staffIdx > 0 ? 'print:break-before-page' : ''
                      }`}
                    >
                      {/* Header */}
                      <div className="flex justify-between items-start border-b-2 border-slate-900 pb-4">
                        <div>
                          <h2 className="text-2xl font-black text-slate-900 uppercase">{company.name}</h2>
                          <p className="text-xs text-slate-600 font-medium mt-1">{company.address} | फोन: {company.phone}</p>
                        </div>
                        <div className="text-right">
                          <span className="bg-slate-900 text-white px-4 py-1.5 text-sm font-bold uppercase tracking-wider rounded">
                            {isNe ? 'मासिक हाजिरी सिट' : 'Monthly Attendance Sheet'}
                          </span>
                          <p className="text-xs font-bold text-slate-700 mt-2">
                            {monthMeta.nameNe} {sheetYear}
                          </p>
                        </div>
                      </div>

                      {/* Staff Info */}
                      <div className="grid grid-cols-4 gap-4 bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <div>
                          <span className="text-[10px] text-slate-500 font-bold uppercase">कर्मचारी:</span>
                          <p className="font-black text-slate-900 text-sm">{emp.name}</p>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 font-bold uppercase">पद:</span>
                          <p className="font-bold text-slate-800 text-sm">{emp.role}</p>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 font-bold uppercase">फोन:</span>
                          <p className="font-mono font-bold text-slate-800 text-sm">{emp.phone || '-'}</p>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 font-bold uppercase">कुल हाजिर:</span>
                          <p className="font-black text-emerald-700 text-sm">{sheetData.presentDays} दिन</p>
                        </div>
                      </div>

                      {/* Work Category Summary */}
                      <div className="space-y-2">
                        <span className="text-xs font-bold text-slate-900 uppercase">कार्य विवरण सारांश:</span>
                        <div className="grid grid-cols-7 gap-2">
                          {activeWorkCategories.map((cat) => {
                            const count = sheetData.categoryCounts[cat.id] || 0;
                            return (
                              <div key={cat.id} className="border border-slate-200 rounded p-2 text-center">
                                <p className="text-[9px] font-bold text-slate-500 truncate">{cat.shortNe.split(' ')[0]}</p>
                                <p className="text-sm font-black text-slate-900">{count}</p>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Attendance Table */}
                      <table className="w-full text-xs border-collapse">
                        <thead className="bg-slate-800 text-white">
                          <tr>
                            <th className="border border-slate-300 p-2 text-center">गते</th>
                            <th className="border border-slate-300 p-2">मिति</th>
                            <th className="border border-slate-300 p-2 text-center">स्थिति</th>
                            <th className="border border-slate-300 p-2 text-center">समय (In-Out)</th>
                            <th className="border border-slate-300 p-2">कामको प्रकार</th>
                            <th className="border border-slate-300 p-2">साइट / विवरण</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {sheetData.dayRows.map((row) => {
                            const rec = row.record;
                            const isPresent = rec?.status === 'PRESENT';
                            return (
                              <tr key={row.dateBs} className={isPresent ? 'bg-white' : 'bg-slate-50 text-slate-500'}>
                                <td className="border border-slate-300 p-2 text-center font-bold">{row.dayNum}</td>
                                <td className="border border-slate-300 p-2 font-mono">{row.dateBs}</td>
                                <td className="border border-slate-300 p-2 text-center font-bold">
                                  {isPresent ? 'P' : rec?.status === 'ABSENT' ? 'A' : '-'}
                                </td>
                                <td className="border border-slate-300 p-2 text-center font-mono">
                                  {isPresent ? `${rec?.checkInTime || '-'} - ${rec?.checkOutTime || '-'}` : '-'}
                                </td>
                                <td className="border border-slate-300 p-2 font-semibold">
                                  {isPresent ? (rec?.workCategory ? getWorkCategoryMeta(rec.workCategory).shortNe : '-') : '-'}
                                </td>
                                <td className="border border-slate-300 p-2">
                                  {isPresent ? (rec?.siteOrClientName || rec?.locationLabel || '-') : '-'}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>

                      {/* Wage Summary */}
                      {sheetShowWageSummary && (
                        <div className="grid grid-cols-4 gap-4 p-4 bg-slate-100 rounded-lg border border-slate-200">
                          <div>
                            <p className="text-[10px] text-slate-500 font-bold uppercase">जम्मा (Gross):</p>
                            <p className="font-black text-emerald-800">रु. {sheetData.grossSalary.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-[10px] text-slate-500 font-bold uppercase">कट्टी (Deductions):</p>
                            <p className="font-black text-rose-700">रु. {sheetData.deductions.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-[10px] text-slate-500 font-bold uppercase">भुक्तानी (Paid):</p>
                            <p className="font-black text-purple-700">रु. {sheetData.salaryPaid.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-[10px] text-slate-500 font-bold uppercase">बाँकी (Net):</p>
                            <p className="font-black text-amber-900 text-lg">रु. {sheetData.netPayable.toLocaleString()}</p>
                          </div>
                        </div>
                      )}

                      {/* Footer */}
                      <div className="grid grid-cols-2 gap-12 pt-8">
                        <div className="border-t border-slate-400 text-center pt-2 text-[10px] font-bold">कर्मचारीको सही</div>
                        <div className="border-t border-slate-400 text-center pt-2 text-[10px] font-bold">प्रबन्धक / मालिक</div>
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        </div>
      )}

      {/* MODAL 8: SHAREABLE STAFF & OWNER LINK GENERATOR (हाजिरी तथा पोर्टल लिंक तयार गर्ने) */}
      {isLinkModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-4">
            <div className="bg-gradient-to-r from-teal-900 via-emerald-900 to-slate-900 text-white px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center">
                  <Key className="w-5 h-5 text-teal-300" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold">
                    {isNe
                      ? '🔗 स्टाफ हाजिरी तथा मालिक पोर्टल लिंकहरू (Ready-to-Share Links)'
                      : '🔗 Ready-to-Share Staff & Owner Portal Links'}
                  </h3>
                  <p className="text-[11px] text-teal-200">
                    {isNe
                      ? 'स्टाफलाई पठाउने र मालिकले चलाउने छुट्टाछुट्टै सिधा लिंक कपी गर्नुहोस्'
                      : 'Copy direct links for staff attendance, monthly sheets, and owner portal'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsLinkModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              {/* 1. Direct Staff Attendance Link */}
              <div className="p-3.5 rounded-xl bg-emerald-50/90 border border-emerald-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-950 flex items-center gap-1.5 text-sm">
                    <span>👷 १. स्टाफ काम अनुसार हाजिरी लिंक (Staff Attendance Link)</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-200/80 text-emerald-900 font-bold text-[10px]">
                    स्टाफलाई पठाउने
                  </span>
                </div>
                <p className="text-[11px] text-emerald-800">
                  {isNe
                    ? 'यो लिंक खोल्दा सिधै स्टाफ मोडमा काम अनुसार हाजिरी (टनेल, प्लास्टिक, ट्याक्टर, फिटिङ, फिल्ड) पेज खुल्छ।'
                    : 'Opens directly in Staff Mode on the Work-Category Attendance screen.'}
                </p>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${baseAppUrl}/?portal=staff&tab=attendance`}
                    className="flex-1 px-3 py-2 bg-white border border-emerald-300 rounded-lg font-mono text-[11px] text-slate-800 select-all"
                  />
                  <button
                    onClick={() =>
                      handleCopyLink(`${baseAppUrl}/?portal=staff&tab=attendance`, 'staff_att')
                    }
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg transition cursor-pointer shrink-0"
                  >
                    {copiedKey === 'staff_att'
                      ? isNe
                        ? '✓ कपी भयो!'
                        : '✓ Copied!'
                      : isNe
                        ? '📋 लिंक कपी गर्नुहोस्'
                        : '📋 Copy Link'}
                  </button>
                </div>
              </div>

              {/* 2. Individual Employee Personal Attendance & Monthly Sheet Link */}
              <div className="p-3.5 rounded-xl bg-amber-50/90 border border-amber-200 space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <span className="font-bold text-amber-950 text-sm">
                    📋 २. कर्मचारीको व्यक्तिगत हाजिरी र मासिक सिट लिंक (Individual Staff Link)
                  </span>
                  <select
                    value={linkEmpId}
                    onChange={(e) => setLinkEmpId(e.target.value)}
                    className="px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg text-xs font-bold text-slate-900"
                  >
                    <option value="ALL">सबै कर्मचारी (All Staff)</option>
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.name} ({emp.role})
                      </option>
                    ))}
                  </select>
                </div>
                <p className="text-[11px] text-amber-900">
                  {isNe
                    ? 'छानिएको कर्मचारीको नाम स्वतः सेलेक्ट भएर खुल्ने र महिनाभरिको हाजिरी सिट हेर्न/प्रिन्ट गर्न मिल्ने लिंक:'
                    : 'Direct link with employee pre-selected for attendance & monthly printable sheet:'}
                </p>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${baseAppUrl}/?portal=staff&tab=attendance${linkEmpId !== 'ALL' ? `&empId=${linkEmpId}` : ''}&sheet=1`}
                    className="flex-1 px-3 py-2 bg-white border border-amber-300 rounded-lg font-mono text-[11px] text-slate-800 select-all"
                  />
                  <button
                    onClick={() =>
                      handleCopyLink(
                        `${baseAppUrl}/?portal=staff&tab=attendance${linkEmpId !== 'ALL' ? `&empId=${linkEmpId}` : ''}&sheet=1`,
                        'emp_sheet'
                      )
                    }
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg transition cursor-pointer shrink-0"
                  >
                    {copiedKey === 'emp_sheet'
                      ? isNe
                        ? '✓ कपी भयो!'
                        : '✓ Copied!'
                      : isNe
                        ? '📋 मासिक सिट लिंक कपी'
                        : '📋 Copy Sheet Link'}
                  </button>
                </div>
              </div>

              {/* 3. Counter Billing Staff Link */}
              <div className="p-3.5 rounded-xl bg-blue-50/90 border border-blue-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-blue-950 text-sm">
                    🧾 ३. काउन्टर बिलिङ स्टाफ लिंक (Staff Billing & POS Link)
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-blue-200/80 text-blue-900 font-bold text-[10px]">
                    बिलिङ स्टाफ
                  </span>
                </div>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${baseAppUrl}/?portal=staff&tab=billing`}
                    className="flex-1 px-3 py-2 bg-white border border-blue-300 rounded-lg font-mono text-[11px] text-slate-800 select-all"
                  />
                  <button
                    onClick={() =>
                      handleCopyLink(`${baseAppUrl}/?portal=staff&tab=billing`, 'staff_bill')
                    }
                    className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-lg transition cursor-pointer shrink-0"
                  >
                    {copiedKey === 'staff_bill'
                      ? isNe
                        ? '✓ कपी भयो!'
                        : '✓ Copied!'
                      : isNe
                        ? '📋 लिंक कपी गर्नुहोस्'
                        : '📋 Copy Link'}
                  </button>
                </div>
              </div>

              {/* 4. Owner Master Portal Link */}
              <div className="p-3.5 rounded-xl bg-slate-900 text-white space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300 text-sm">
                    👑 ४. मालिक मुख्य पोर्टल लिंक (Owner Master Control Link)
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-400/30 font-bold text-[10px]">
                    मालिक मात्र (Owner Only)
                  </span>
                </div>
                <p className="text-[11px] text-slate-300">
                  {isNe
                    ? 'यो लिंकबाट लगइन गर्दा मालिकको सम्पूर्ण अधिकार (रिपोर्ट, भ्याट खाता, एक्सेल अपलोड, तलब र सेटिङ) खुल्छ।'
                    : 'Full Owner portal with all reports, VAT registers, Excel upload, payroll, and settings.'}
                </p>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${baseAppUrl}/?portal=owner`}
                    className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg font-mono text-[11px] text-emerald-300 select-all"
                  />
                  <button
                    onClick={() => handleCopyLink(`${baseAppUrl}/?portal=owner`, 'owner_link')}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-lg transition cursor-pointer shrink-0"
                  >
                    {copiedKey === 'owner_link'
                      ? isNe
                        ? '✓ कपी भयो!'
                        : '✓ Copied!'
                      : isNe
                        ? '📋 मालिक लिंक कपी'
                        : '📋 Copy Owner Link'}
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-600">
              <span>
                {isNe
                  ? 'डिफल्ट मालिक लगइन: 9855012345 (PIN: 1234)'
                  : 'Default Owner Login: 9855012345 (PIN: 1234)'}
              </span>
              <button
                onClick={() => setIsLinkModalOpen(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg cursor-pointer"
              >
                {isNe ? 'बन्द गर्नुहोस्' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
