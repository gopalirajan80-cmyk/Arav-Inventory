import { printPage } from '../utils/printHelper';
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Invoice } from '../types';
import { QRCodeSVG } from 'qrcode.react';
import {
  Printer,
  X,
  Receipt,
  FileDown,
  Loader2,
  CheckCircle2,
  Layers,
  QrCode
} from 'lucide-react';
import {
  formatCurrency,
  toNepaliDigits,
  formatBsDateNepaliText
} from '../utils/nepaliCalendar';
import { amountInNepaliWords, amountInEnglishWords } from '../utils/vatCalculator';
import { downloadElementAsPdf } from '../utils/pdfHelper';
import { getPaperSize } from '../utils/paperSize';
import { PaperSizeToggle } from './PaperSizeToggle';

interface BatchInvoicePrintModalProps {
  invoices: Invoice[];
  onClose: () => void;
}

type PrintFormat = 'A4' | 'THERMAL_80' | 'THERMAL_58';

export const BatchInvoicePrintModal: React.FC<BatchInvoicePrintModalProps> = ({
  invoices,
  onClose
}) => {
  const { company, language } = useApp();

  const getInitialFormat = (): PrintFormat => {
    if (company.defaultPrintFormat === 'THERMAL_58MM') return 'THERMAL_58';
    if (company.defaultPrintFormat === 'THERMAL_80MM') return 'THERMAL_80';
    return 'A4';
  };

  const [printFormat, setPrintFormat] = useState<PrintFormat>(getInitialFormat());
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const isNe = language === 'ne';

  const handleDownloadPdf = async () => {
    try {
      setIsGeneratingPdf(true);
      const pdfFormat = printFormat === 'A4' ? 'a4' : printFormat === 'THERMAL_80' ? 'pos80' : 'pos58';
      const fileName = `Batch_Invoices_${invoices.length}_Bills.pdf`;
      await downloadElementAsPdf({
        elementId: 'printable-batch-invoices',
        fileName,
        format: pdfFormat,
        onProgress: setIsGeneratingPdf
      });
    } catch (err) {
      console.error('Batch PDF generation error', err);
      setIsGeneratingPdf(false);
    }
  };

  const handlePrint = () => {
    const elem = document.getElementById('printable-batch-invoices');
    if (!elem) {
      printPage();
      return;
    }

    try {
      const existingIframe = document.getElementById('invoice-batch-print-frame');
      if (existingIframe) existingIframe.remove();

      const iframe = document.createElement('iframe');
      iframe.id = 'invoice-batch-print-frame';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      iframe.style.opacity = '0';
      iframe.style.pointerEvents = 'none';
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document;
      if (doc) {
        let styles = '';
        document.querySelectorAll('style, link[rel="stylesheet"]').forEach((s) => {
          styles += s.outerHTML;
        });

        doc.open();
        doc.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="utf-8" />
              <title>${company.name} - Batch Print (${invoices.length} Invoices)</title>
              ${styles}
              <style>
                @page {
                  size: ${printFormat === 'A4' ? `${getPaperSize()} portrait` : printFormat === 'THERMAL_80' ? '80mm auto' : '58mm auto'};
                  margin: 4mm;
                }
                body {
                  margin: 0;
                  padding: 4mm;
                  background: #fff !important;
                  color: #000 !important;
                  -webkit-print-color-adjust: exact !important;
                  print-color-adjust: exact !important;
                  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                }
                .single-batch-invoice {
                  page-break-after: always !important;
                  break-after: page !important;
                  margin-bottom: 20px !important;
                }
                .single-batch-invoice:last-child {
                  page-break-after: auto !important;
                  break-after: auto !important;
                }
                table, th, td {
                  border-color: #0f172a !important;
                }
              </style>
            </head>
            <body>
              ${elem.outerHTML}
            </body>
          </html>
        `);
        doc.close();

        setTimeout(() => {
          try {
            iframe.contentWindow?.focus();
            iframe.contentWindow?.print();
          } catch {
            printPage();
          }
        }, 400);
        return;
      }
    } catch {
      // fallback
    }

    printPage();
  };

  const totalGrandAmount = invoices.reduce((sum, inv) => sum + inv.grandTotal, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static print:overflow-visible print:block">
      {/* Inject print styles for batch page breaks */}
      <style>{`
        @media print {
          .no-print {
            display: none !important;
          }
          html, body, #root {
            visibility: visible !important;
            background: #fff !important;
            margin: 0 !important;
            padding: 0 !important;
            height: auto !important;
            overflow: visible !important;
          }
          .single-batch-invoice {
            page-break-after: always !important;
            break-after: page !important;
            display: block !important;
            visibility: visible !important;
          }
          .single-batch-invoice:last-child {
            page-break-after: auto !important;
            break-after: auto !important;
          }
          #printable-batch-invoices {
            display: block !important;
            box-shadow: none !important;
            width: 100% !important;
            visibility: visible !important;
          }
          @page {
            size: ${
              printFormat === 'A4'
                ? `${getPaperSize()} portrait`
                : printFormat === 'THERMAL_80'
                ? '80mm auto'
                : '58mm auto'
            };
            margin: 4mm;
          }
        }
      `}</style>

      <div className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl border border-slate-300 overflow-hidden my-auto max-h-[96vh] flex flex-col">
        {/* Top Control Bar */}
        <div className="no-print bg-slate-900 text-white px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <Layers className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-sm font-bold tracking-tight leading-tight flex items-center gap-2">
                <span>{isNe ? 'एकैपटक बहु-बीजक प्रिन्ट (Batch Invoice Print Job)' : 'Batch Multi-Invoice Print'}</span>
                <span className="bg-emerald-700 text-white text-[11px] px-2 py-0.5 rounded-full font-mono">
                  {isNe ? `${toNepaliDigits(invoices.length)} बिलहरू` : `${invoices.length} Bills`}
                </span>
              </h2>
              <p className="text-[11px] text-slate-400 font-mono">
                {isNe ? `कुल जम्मा रकम: रु. ${totalGrandAmount.toFixed(2)}` : `Total Batch Amount: Rs. ${totalGrandAmount.toFixed(2)}`}
              </p>
            </div>
          </div>

          <div className="flex items-center flex-wrap gap-2">
            <PaperSizeToggle />
            {/* Format toggle: A4 vs 80mm POS vs 58mm POS */}
            <div className="flex items-center bg-slate-800 p-0.5 rounded-lg border border-slate-700 text-xs">
              <button
                type="button"
                onClick={() => setPrintFormat('A4')}
                className={`px-2.5 py-1 font-medium rounded-md transition cursor-pointer ${
                  printFormat === 'A4'
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                A4 Tax Invoice
              </button>
              <button
                type="button"
                onClick={() => setPrintFormat('THERMAL_80')}
                className={`px-2.5 py-1 font-medium rounded-md transition cursor-pointer ${
                  printFormat === 'THERMAL_80'
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                80mm (3") POS
              </button>
              <button
                type="button"
                onClick={() => setPrintFormat('THERMAL_58')}
                className={`px-2.5 py-1 font-medium rounded-md transition cursor-pointer ${
                  printFormat === 'THERMAL_58'
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                58mm (2") Mini POS
              </button>
            </div>

            {/* Direct Batch PDF Download button */}
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer disabled:opacity-50 active:scale-95"
              title="सबै छानिएका बिलहरू एउटै PDF फाइलमा डाउनलोड गर्नुहोस्"
            >
              {isGeneratingPdf ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>{isNe ? 'PDF बन्दैछ...' : 'Generating Batch PDF...'}</span>
                </>
              ) : (
                <>
                  <FileDown className="w-4 h-4 text-white" />
                  <span>{isNe ? '📄 बैच PDF डाउनलोड' : 'Batch PDF Download'}</span>
                </>
              )}
            </button>

            {/* Batch Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-xs transition cursor-pointer active:scale-95"
            >
              <Printer className="w-4 h-4" />
              <span>{isNe ? '🖨️ एकैसाथ प्रिन्ट गर्नुहोस् (Print All)' : 'Print All in 1 Job'}</span>
            </button>

            {/* Close */}
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg transition cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Preview Area */}
        <div className="overflow-y-auto p-4 sm:p-8 bg-slate-100 flex-1 space-y-6">
          <div id="printable-batch-invoices" className="space-y-8">
            {invoices.map((invoice, invIndex) => {
              const words = isNe
                ? amountInNepaliWords(invoice.grandTotal)
                : amountInEnglishWords(invoice.grandTotal);

              return (
                <div
                  key={invoice.id}
                  className="single-batch-invoice relative mx-auto bg-white border border-slate-300 shadow-md transition-all"
                  style={{
                    pageBreakAfter: invIndex === invoices.length - 1 ? 'auto' : 'always',
                    breakAfter: invIndex === invoices.length - 1 ? 'auto' : 'page'
                  }}
                >
                  {/* Page Divider Indicator for screen view */}
                  <div className="no-print bg-slate-800 text-white px-3 py-1 text-[11px] font-mono font-bold flex items-center justify-between border-b border-slate-700">
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <Receipt className="w-3.5 h-3.5" />
                      <span>{isNe ? `बिल नं. ${invIndex + 1} / ${invoices.length}` : `Invoice ${invIndex + 1} of ${invoices.length}`}</span>
                    </span>
                    <span>{invoice.invoiceNo} • {invoice.customerName} • Rs. {invoice.grandTotal.toFixed(2)}</span>
                  </div>

                  <div
                    className={`p-6 sm:p-8 space-y-4 text-slate-900 ${
                      printFormat === 'A4'
                        ? 'w-full max-w-[800px] text-xs font-sans mx-auto'
                        : printFormat === 'THERMAL_80'
                        ? 'w-[320px] p-3 text-[11px] font-mono leading-tight mx-auto'
                        : 'w-[230px] p-2 text-[10px] font-mono leading-tight mx-auto'
                    }`}
                  >
                    {printFormat === 'A4' ? (
                      /* ================== A4 SINGLE INVOICE TEMPLATE ================== */
                      <div className="space-y-4">
                        {/* Header: Company Details & IRD Title */}
                        <div className="text-center border-b-2 border-slate-900 pb-3 mb-4">
                          {company.logoUrl && (
                            <img
                              src={company.logoUrl}
                              alt={company.name}
                              className="h-14 w-auto object-contain mx-auto mb-2 rounded"
                            />
                          )}
                          <div className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-500 mb-1">
                            {invoice.billType === 'VAT' ? 'Goverment of Nepal IRD Approved Format' : 'Internal Estimate / Quotation'}
                          </div>
                          <h1 className="text-xl sm:text-2xl font-black text-slate-950 tracking-tight leading-none uppercase">
                            {company.name}
                          </h1>
                          <p className="text-xs text-slate-800 font-bold mt-1">
                            {company.address}
                          </p>
                          <p className="text-xs text-slate-700 font-semibold">
                            फोन नं.: <span className="font-mono">{company.phone}</span> {company.email ? ` | इमेल: ${company.email}` : ''}
                          </p>
                          <div className="inline-block mt-1.5 px-4 py-0.5 bg-slate-900 text-white font-mono font-black text-[10px] rounded-xs shadow-sm">
                            स्थायी लेखा नं. (PAN / VAT No.): {company.panVatNo}
                          </div>
                          
                          <div className="mt-3 flex justify-center">
                            <div className="text-base font-black uppercase tracking-widest border-2 border-slate-900 px-6 py-0.5 rounded bg-slate-50 text-slate-900">
                              {invoice.billType === 'VAT' ? 'कर बीजक (TAX INVOICE)' : 'अनुमानित बीजक (ESTIMATE BILL)'}
                            </div>
                          </div>
                        </div>

                        {/* Invoice Meta Grid */}
                        <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-3 rounded-sm border border-slate-200">
                          <div className="space-y-1">
                            <div>
                              <span className="font-semibold text-slate-700">बीजक नं. (Invoice No): </span>
                              <span className="font-mono font-bold text-slate-900 text-sm">{invoice.invoiceNo}</span>
                            </div>
                            <div>
                              <span className="font-semibold text-slate-700">आर्थिक वर्ष (Fiscal Year): </span>
                              <span className="font-mono">{invoice.fiscalYear}</span>
                            </div>
                            <div>
                              <span className="font-semibold text-slate-700">मिति (Date B.S.): </span>
                              <span className="font-bold">{formatBsDateNepaliText(invoice.dateBs)}</span>
                              <span className="text-slate-500 font-mono text-[11px] ml-1">({invoice.dateBs})</span>
                            </div>
                            <div>
                              <span className="font-semibold text-slate-700">Date (A.D.): </span>
                              <span className="font-mono">{invoice.dateAd} {invoice.time}</span>
                            </div>
                            <div>
                              <span className="font-semibold text-slate-700">बिल तयार गर्ने (Billed By): </span>
                              <span className="font-bold text-emerald-900">{invoice.billedBy || 'काउन्टर कर्मचारी'}</span>
                            </div>
                          </div>

                          <div className="space-y-1 border-l border-slate-200 pl-4">
                            <div>
                              <span className="font-semibold text-slate-700">खरिदकर्ताको नाम (Buyer): </span>
                              <span className="font-bold text-slate-900">{invoice.customerName}</span>
                            </div>
                            <div>
                              <span className="font-semibold text-slate-700">ग्राहकको प्यान नं. (Buyer PAN): </span>
                              <span className="font-mono font-bold">{invoice.customerPan || '-'}</span>
                            </div>
                            <div>
                              <span className="font-semibold text-slate-700">ठेगाना (Address): </span>
                              <span>{invoice.customerAddress || '-'}</span>
                            </div>
                            <div>
                              <span className="font-semibold text-slate-700">भुक्तानी माध्यम (Payment): </span>
                              <span className="font-semibold">{invoice.paymentMode}</span>
                            </div>
                          </div>
                        </div>

                        {/* Items Table */}
                        <div className="overflow-x-auto">
                          <table className="w-full border-collapse border-2 border-slate-900 text-xs">
                            <thead>
                              <tr className="bg-slate-100 text-slate-900 font-bold border-b-2 border-slate-900 text-center">
                                <th className="border border-slate-900 py-1.5 px-1.5 w-8">क्र.सं.</th>
                                <th className="border border-slate-900 py-1.5 px-2 w-16">कोड</th>
                                <th className="border border-slate-900 py-1.5 px-2 w-16">HS Code</th>
                                <th className="border border-slate-900 py-1.5 px-3 text-left">सामानको विवरण (Description)</th>
                                <th className="border border-slate-900 py-1.5 px-2 w-14">साइज</th>
                                <th className="border border-slate-900 py-1.5 px-2 w-12">परिमाण</th>
                                <th className="border border-slate-900 py-1.5 px-2 w-12">एकाइ</th>
                                <th className="border border-slate-900 py-1.5 px-2 text-right w-18">दर (रु)</th>
                                <th className="border border-slate-900 py-1.5 px-1.5 text-center w-12">छुट %</th>
                                <th className="border border-slate-900 py-1.5 px-2 text-right w-22">जम्मा (रु)</th>
                              </tr>
                            </thead>
                            <tbody>
                              {invoice.items.map((line, idx) => {
                                const lineGross = line.quantity * line.rate;
                                const lineDiscAmt = (lineGross * (line.discountPercent || 0)) / 100;
                                const lineNet = line.amount !== undefined ? line.amount : (lineGross - lineDiscAmt);
                                return (
                                  <tr key={idx} className="border-b border-slate-900 text-slate-900">
                                    <td className="border border-slate-900 py-1 px-1.5 text-center font-mono font-medium">
                                      {idx + 1}
                                    </td>
                                    <td className="border border-slate-900 py-1 px-2 text-center font-mono text-[11px] font-bold">
                                      {line.code || '-'}
                                    </td>
                                    <td className="border border-slate-900 py-1 px-2 text-center font-mono text-[11px]">
                                      {line.hsCode || '-'}
                                    </td>
                                    <td className="border border-slate-900 py-1 px-3">
                                      <span className="font-semibold text-slate-900">{line.name}</span>
                                      {line.isVatExempt && (
                                        <span className="text-[10px] text-emerald-800 ml-1.5 font-bold">
                                          [कर छुट]
                                        </span>
                                      )}
                                    </td>
                                    <td className="border border-slate-900 py-1 px-2 text-center font-medium">
                                      {line.size || '-'}
                                    </td>
                                    <td className="border border-slate-900 py-1 px-2 text-center font-mono font-bold">
                                      {line.quantity}
                                    </td>
                                    <td className="border border-slate-900 py-1 px-2 text-center text-[11px]">
                                      {line.unit}
                                    </td>
                                    <td className="border border-slate-900 py-1 px-2 text-right font-mono tabular-nums">
                                      {line.rate.toFixed(2)}
                                    </td>
                                    <td className="border border-slate-900 py-1 px-1.5 text-center font-mono">
                                      {(line.discountPercent || 0) > 0 ? `${line.discountPercent}%` : '-'}
                                    </td>
                                    <td className="border border-slate-900 py-1 px-2 text-right font-mono tabular-nums font-bold">
                                      {lineNet.toFixed(2)}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>

                        {/* Totals Summary */}
                        <div className="flex justify-end pt-2">
                          <div className="w-full sm:w-72 border-2 border-slate-900 text-xs">
                            <div className="flex justify-between py-1 px-2.5 border-b border-slate-300">
                              <span className="font-semibold text-slate-700">उप-जम्मा (Sub Total):</span>
                              <span className="font-mono font-bold">{formatCurrency(invoice.subtotal, isNe)}</span>
                            </div>
                            {invoice.discountAmount > 0 && (
                              <div className="flex justify-between py-1 px-2.5 border-b border-slate-300 text-rose-800">
                                <span>छुट (Discount):</span>
                                <span className="font-mono">-{formatCurrency(invoice.discountAmount, isNe)}</span>
                              </div>
                            )}
                            <div className="flex justify-between py-1 px-2.5 border-b border-slate-300">
                              <span className="text-slate-700">अकरयोग्य / कर छुट रकम:</span>
                              <span className="font-mono">{formatCurrency(invoice.exemptAmount, isNe)}</span>
                            </div>
                            <div className="flex justify-between py-1 px-2.5 border-b border-slate-300">
                              <span className="font-semibold text-slate-900">करयोग्य रकम (Taxable Amount):</span>
                              <span className="font-mono font-bold">{formatCurrency(invoice.taxableAmount, isNe)}</span>
                            </div>
                            {invoice.billType === 'VAT' && (
                              <div className="flex justify-between py-1 px-2.5 border-b border-slate-300 text-blue-900 font-bold">
                                <span>१३% भ्याट रकम (13% VAT):</span>
                                <span className="font-mono">{formatCurrency(invoice.vatAmount, isNe)}</span>
                              </div>
                            )}
                            <div className="flex justify-between py-1.5 px-2.5 bg-slate-100 font-black text-slate-950 text-sm">
                              <span>कुल जम्मा (Grand Total):</span>
                              <span className="font-mono text-emerald-800">{formatCurrency(invoice.grandTotal, isNe)}</span>
                            </div>
                          </div>
                        </div>

                        {/* Words & Scan-to-Verify QR Code */}
                        <div className="grid grid-cols-12 gap-3 items-center">
                          <div className="col-span-8 p-2.5 bg-slate-50 border border-slate-300 rounded text-xs text-slate-800">
                            <span className="font-bold">अक्षरूपी: </span>
                            <span>{words}</span>
                          </div>
                          <div className="col-span-4 p-1.5 bg-slate-50 border border-slate-300 rounded flex items-center gap-2">
                            <div className="p-0.5 bg-white rounded border border-slate-200 shrink-0">
                              <QRCodeSVG
                                value={JSON.stringify({
                                  invoiceNo: invoice.invoiceNo,
                                  invoiceId: invoice.id,
                                  grandTotal: invoice.grandTotal,
                                  dateBs: invoice.dateBs,
                                  panVatNo: company.panVatNo
                                })}
                                size={48}
                                level="M"
                              />
                            </div>
                            <div className="text-[9px] text-slate-700 leading-tight">
                              <div className="font-bold text-slate-900 flex items-center gap-0.5">
                                <QrCode className="w-3 h-3 text-emerald-700" />
                                <span>Verify QR</span>
                              </div>
                              <p className="font-mono text-[8px] text-slate-600 truncate">{invoice.invoiceNo}</p>
                              <p className="font-mono text-[8px] font-bold text-emerald-800">Rs. {invoice.grandTotal.toFixed(2)}</p>
                            </div>
                          </div>
                        </div>

                        {/* Signatures */}
                        <div className="pt-8 grid grid-cols-2 text-center text-xs text-slate-700">
                          <div className="border-t border-slate-400 pt-1.5 mx-6">
                            <p className="font-bold text-slate-900">{invoice.billedBy || 'काउन्टर कर्मचारी'}</p>
                            <p className="text-[11px] text-slate-500">विक्रेताको दस्तखत</p>
                          </div>
                          <div className="border-t border-slate-400 pt-1.5 mx-6">
                            <p className="font-bold text-slate-900">{invoice.customerName}</p>
                            <p className="text-[11px] text-slate-500">खरिदकर्ताको दस्तखत</p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* ================== POS THERMAL BILL ================== */
                      <div className="text-center space-y-2">
                        <h2 className="font-black text-sm uppercase">{company.name}</h2>
                        <p className="text-[10px]">{company.address} • {company.phone}</p>
                        <p className="font-mono text-[10px] font-bold">PAN: {company.panVatNo}</p>
                        <div className="border-t border-b border-dashed border-slate-900 py-1 my-1 font-bold">
                          {invoice.billType === 'VAT' ? 'TAX INVOICE' : 'SALES BILL'}
                        </div>
                        <div className="text-left font-mono space-y-0.5 text-[10px]">
                          <div>Bill No: <strong>{invoice.invoiceNo}</strong></div>
                          <div>Date: {invoice.dateBs} ({invoice.dateAd})</div>
                          <div>Customer: <strong>{invoice.customerName}</strong></div>
                        </div>
                        <table className="w-full text-left font-mono text-[10px] border-t border-b border-slate-900 my-1">
                          <thead>
                            <tr className="border-b border-slate-300">
                              <th className="py-0.5">Item</th>
                              <th className="text-center">Qty</th>
                              <th className="text-right">Rate</th>
                              <th className="text-right">Amt</th>
                            </tr>
                          </thead>
                          <tbody>
                            {invoice.items.map((it, i) => (
                              <tr key={i}>
                                <td className="py-0.5 truncate max-w-[100px]">{it.name}</td>
                                <td className="text-center">{it.quantity}</td>
                                <td className="text-right">{it.rate}</td>
                                <td className="text-right font-bold">{(it.amount || (it.quantity * it.rate)).toFixed(2)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        <div className="font-mono text-right text-[11px] space-y-0.5 font-bold">
                          <div>Sub Total: Rs. {invoice.subtotal.toFixed(2)}</div>
                          {invoice.vatAmount > 0 && <div>13% VAT: Rs. {invoice.vatAmount.toFixed(2)}</div>}
                          <div className="text-xs font-black border-t border-slate-900 pt-0.5 mt-0.5">
                            GRAND TOTAL: Rs. {invoice.grandTotal.toFixed(2)}
                          </div>
                        </div>

                        {/* QR Scan to Verify */}
                        <div className="flex flex-col items-center justify-center pt-1 border-t border-dashed border-slate-400">
                          <div className="p-1 bg-white rounded border border-slate-300 my-0.5">
                            <QRCodeSVG
                              value={JSON.stringify({
                                invoiceNo: invoice.invoiceNo,
                                invoiceId: invoice.id,
                                grandTotal: invoice.grandTotal,
                                dateBs: invoice.dateBs
                              })}
                              size={52}
                              level="M"
                            />
                          </div>
                          <span className="text-[8px] font-bold text-slate-800">Scan to Verify Invoice</span>
                        </div>

                        <p className="text-[9px] text-slate-500 pt-1">धन्यवाद! पुन: पधार्नुहोला।</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
