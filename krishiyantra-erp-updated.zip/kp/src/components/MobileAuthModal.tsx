import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import {
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Building2,
  User,
  Key,
  X,
  AlertCircle,
  Clock,
  LogOut,
  MapPin,
  FileText
} from 'lucide-react';

interface MobileAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'LOGIN' | 'REGISTER' | 'ADMIN_APPROVAL';
}

export const MobileAuthModal: React.FC<MobileAuthModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'LOGIN'
}) => {
  const {
    companyAccounts,
    currentAccount,
    loginWithMobile,
    registerMobileAccount,
    approveAccount,
    rejectAccount,
    resetAccountPin,
    logoutAccount,
    language
  } = useApp();

  const isNe = language === 'ne';
  const [activeTab, setActiveTab] = useState<'LOGIN' | 'REGISTER' | 'ADMIN_APPROVAL'>(initialTab);

  // Login form state
  const [loginMobile, setLoginMobile] = useState('');
  const [loginPin, setLoginPin] = useState('');
  const [loginRole, setLoginRole] = useState<UserRole>('OWNER');
  const [loginFeedback, setLoginFeedback] = useState<{ type: 'success' | 'error' | 'pending'; message: string } | null>(null);
  const [showForgotHelp, setShowForgotHelp] = useState(false);

  // Registration form state
  const [regMobile, setRegMobile] = useState('');
  const [regCompanyName, setRegCompanyName] = useState('');
  const [regOwnerName, setRegOwnerName] = useState('');
  const [regPanVat, setRegPanVat] = useState('');
  const [regAddress, setRegAddress] = useState('');
  const [regPin, setRegPin] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('OWNER');
  const [regFeedback, setRegFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Admin Master Passcode & Reset PIN Modal
  const [adminPin, setAdminPin] = useState('');
  const [resetModalAccountId, setResetModalAccountId] = useState<string | null>(null);
  const [resetPinInput, setResetPinInput] = useState('');
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(
    currentAccount?.role === 'SUPER_ADMIN' || currentAccount?.role === 'ADMIN'
  );

  if (!isOpen) return null;

  const pendingAccounts = companyAccounts.filter((a) => a.status === 'PENDING_APPROVAL');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginFeedback(null);

    const res = loginWithMobile(loginMobile, loginPin);
    if (res.success) {
      setLoginFeedback({
        type: 'success',
        message: isNe
          ? `लग-इन सफल भयो! (${res.account?.mobileNumber})`
          : `Login successful! (${res.account?.mobileNumber})`
      });
      setTimeout(() => {
        onClose();
      }, 600);
    } else {
      const isPending = res.message.includes('Pending Admin Approval') || res.message.includes('स्वीकृतिको पर्खाइमा');
      setLoginFeedback({
        type: isPending ? 'pending' : 'error',
        message: res.message
      });
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegFeedback(null);

    if (!regMobile || !regCompanyName || !regOwnerName) {
      setRegFeedback({
        type: 'error',
        message: isNe ? 'कृपया अनिवार्य विवरणहरू भर्नुहोस्।' : 'Please fill all required fields.'
      });
      return;
    }

    const res = registerMobileAccount({
      mobileNumber: regMobile,
      companyName: regCompanyName,
      ownerName: regOwnerName,
      panVatNo: regPanVat,
      address: regAddress,
      pin: regPin,
      requestedRole: regRole
    });

    if (res.success) {
      setRegFeedback({
        type: 'success',
        message: res.message
      });
      setRegMobile('');
      setRegCompanyName('');
      setRegOwnerName('');
      setRegPanVat('');
      setRegAddress('');
      setRegPin('');
    } else {
      setRegFeedback({
        type: 'error',
        message: res.message
      });
    }
  };

  const quickLogin = (mobile: string, pin: string = '', role?: UserRole) => {
    setLoginMobile(mobile);
    setLoginPin(pin);
    const res = loginWithMobile(mobile, pin, role);
    if (res.success) {
      setLoginFeedback({
        type: 'success',
        message: isNe
          ? `लग-इन सफल भयो (${res.account?.mobileNumber})`
          : `Login successful (${res.account?.mobileNumber})`
      });
      setTimeout(() => {
        onClose();
      }, 600);
    } else {
      const isPending = res.message.includes('Pending Admin Approval') || res.message.includes('स्वीकृतिको पर्खाइमा');
      setLoginFeedback({
        type: isPending ? 'pending' : 'error',
        message: res.message
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold">
                {isNe ? 'लग-इन (User Login)' : 'User Login'}
              </h3>
              <p className="text-[11px] text-slate-300">
                {isNe
                  ? 'लग-इन आइडी (मोबाइल नम्बर) र पासवर्ड/पिन राख्नुहोस्'
                  : 'Enter Login ID (Mobile Number) and Password/PIN'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Active Account Banner (Only shows Login ID / Mobile Number, no Company Name) */}
        {currentAccount && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-5 py-2.5 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-emerald-950 font-semibold truncate">
              <User className="w-4 h-4 text-emerald-700 shrink-0" />
              <span className="truncate">
                {isNe ? 'लग-इन आइडी:' : 'Logged in ID:'}{' '}
                <strong className="font-mono text-emerald-900 font-bold">{currentAccount.mobileNumber}</strong>
              </span>
            </div>
            <button
              onClick={() => {
                logoutAccount();
                setLoginFeedback(null);
              }}
              className="px-2.5 py-1 bg-white hover:bg-rose-50 text-rose-700 hover:text-rose-800 border border-rose-200 rounded-lg font-bold text-[11px] flex items-center gap-1 shadow-2xs transition cursor-pointer shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{isNe ? 'लग-आउट' : 'Log Out'}</span>
            </button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 p-1.5 gap-1.5 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setActiveTab('LOGIN');
              setLoginFeedback(null);
            }}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'LOGIN'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{isNe ? 'लग-इन (Login)' : 'Login'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('REGISTER');
              setRegFeedback(null);
            }}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'REGISTER'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>{isNe ? 'दर्ता (Register)' : 'Register'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('ADMIN_APPROVAL')}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer relative ${
              activeTab === 'ADMIN_APPROVAL'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{isNe ? 'एडमिन (Admin)' : 'Admin'}</span>
            {pendingAccounts.length > 0 && (
              <span className="w-4 h-4 text-[10px] bg-rose-600 text-white rounded-full flex items-center justify-center font-bold">
                {pendingAccounts.length}
              </span>
            )}
          </button>
        </div>

        {/* Tab 1: LOGIN (Only Login ID / Mobile Number and Password / PIN) */}
        {activeTab === 'LOGIN' && (
          <div className="p-5 space-y-4 text-xs">
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'लग-इन आइडी (मोबाइल नम्बर):*' : 'Login ID (Mobile Number):*'}
                </label>
                <div className="relative">
                  <Smartphone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={loginMobile}
                    onChange={(e) => setLoginMobile(e.target.value)}
                    placeholder={isNe ? 'मोबाइल नम्बर (उदा: 9855012345)' : 'Enter Mobile Number / Login ID'}
                    className="w-full pl-9 pr-3 py-2.5 border border-slate-300 rounded-xl font-mono text-sm font-bold text-slate-900 bg-white focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'पासवर्ड / पिन कोड (Password / PIN):*' : 'Password / PIN:*'}
                </label>
                <div className="relative">
                  <Key className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    value={loginPin}
                    onChange={(e) => setLoginPin(e.target.value)}
                    placeholder={isNe ? 'पासवर्ड वा पिन कोड' : 'Password / PIN'}
                    className="w-full pl-9 pr-3 py-2.5 border border-slate-300 rounded-xl font-mono text-sm font-bold text-slate-900 bg-white focus:ring-2 focus:ring-emerald-600 focus:outline-none tracking-widest"
                  />
                </div>
              </div>

              {/* Feedback messages */}
              {loginFeedback && (
                <div
                  className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                    loginFeedback.type === 'success'
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                      : loginFeedback.type === 'pending'
                      ? 'bg-amber-50 border-amber-300 text-amber-950'
                      : 'bg-rose-50 border-rose-300 text-rose-950'
                  }`}
                >
                  {loginFeedback.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : loginFeedback.type === 'pending' ? (
                    <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <p className="font-semibold leading-relaxed">{loginFeedback.message}</p>
                    {loginFeedback.type === 'pending' && (
                      <button
                        type="button"
                        onClick={() => setActiveTab('ADMIN_APPROVAL')}
                        className="mt-2 text-[11px] font-bold text-amber-900 underline hover:text-amber-950 cursor-pointer"
                      >
                        {isNe ? '👉 एडमिन स्वीकृति प्यानल खोल्नुहोस्' : '👉 Open Admin Approval Panel'}
                      </button>
                    )}
                  </div>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Smartphone className="w-4 h-4" />
                <span>{isNe ? 'लग-इन गर्नुहोस् (Sign In)' : 'Sign In'}</span>
              </button>
            </form>
          </div>
        )}

        {/* Tab 2: REGISTER */}
        {activeTab === 'REGISTER' && (
          <form onSubmit={handleRegisterSubmit} className="p-5 space-y-3.5 text-xs">
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-xs">
              <p className="font-bold flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-blue-700" />
                <span>{isNe ? 'कम्पनी दर्ता तथा एडमिन स्वीकृति प्रक्रिया:' : 'Company Registration & Approval Process:'}</span>
              </p>
              <p className="text-[11px] text-blue-800 mt-1 leading-relaxed">
                {isNe
                  ? 'नयाँ मोबाइल नम्बर दर्ता गर्दा सुरुमा यो "स्वीकृतिको पर्खाइमा (Pending Approval)" रहनेछ। मुख्य एडमिनले स्वीकृत गरेपछि मात्र कम्पनी खाता सुचारु हुनेछ।'
                  : 'New registrations will remain in Pending Approval status until the Admin approves your mobile number.'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'मोबाइल नम्बर (१० अंक):*' : 'Mobile Number (10 digits):*'}
                </label>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={regMobile}
                  onChange={(e) => setRegMobile(e.target.value.replace(/\D/g, ''))}
                  placeholder="98xxxxxxxx"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-xs font-bold text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'कम्पनी / फर्मको नाम:*' : 'Company / Firm Name:*'}
                </label>
                <input
                  type="text"
                  required
                  value={regCompanyName}
                  onChange={(e) => setRegCompanyName(e.target.value)}
                  placeholder="उदा. पोखरा एग्रो मेसिनरी प्रा.लि."
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'संचालक / मालिकको नाम:*' : 'Owner / Contact Person:*'}
                </label>
                <input
                  type="text"
                  required
                  value={regOwnerName}
                  onChange={(e) => setRegOwnerName(e.target.value)}
                  placeholder="उदा. राम प्रसाद शर्मा"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'प्यान / भ्याट नम्बर:' : 'PAN / VAT No:'}
                </label>
                <input
                  type="text"
                  maxLength={9}
                  value={regPanVat}
                  onChange={(e) => setRegPanVat(e.target.value.replace(/\D/g, ''))}
                  placeholder="उदा. 601234567"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-xs font-bold text-slate-900 bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'ठेगाना / स्थान:' : 'Address / Location:'}
                </label>
                <input
                  type="text"
                  value={regAddress}
                  onChange={(e) => setRegAddress(e.target.value)}
                  placeholder="उदा. पोखरा, कास्की"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  {isNe ? 'लग-इन गोप्य पिन सेट गर्नुहोस्:' : 'Set 4-Digit Login PIN:'}
                </label>
                <input
                  type="password"
                  maxLength={6}
                  value={regPin}
                  onChange={(e) => setRegPin(e.target.value)}
                  placeholder="1234"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-xs font-bold text-slate-900 bg-white tracking-widest"
                />
              </div>
            </div>

            {regFeedback && (
              <div
                className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                  regFeedback.type === 'success'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                    : 'bg-rose-50 border-rose-300 text-rose-950'
                }`}
              >
                {regFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                )}
                <div>
                  <p className="font-semibold">{regFeedback.message}</p>
                  {regFeedback.type === 'success' && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('ADMIN_APPROVAL')}
                      className="mt-1 text-[11px] font-bold text-emerald-800 underline hover:text-emerald-950 cursor-pointer"
                    >
                      {isNe ? '👉 तुरुन्त एडमिनबाट स्वीकृत गर्न यहाँ थिच्नुहोस्' : '👉 Click here to approve as Admin'}
                    </button>
                  )}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setActiveTab('LOGIN')}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition"
              >
                {isNe ? 'रद्द' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <Building2 className="w-4 h-4" />
                <span>{isNe ? 'कम्पनी दर्ता गर्नुहोस् (Pending Approval)' : 'Register Company'}</span>
              </button>
            </div>
          </form>
        )}

        {/* Tab 3: ADMIN APPROVAL */}
        {activeTab === 'ADMIN_APPROVAL' && (
          <div className="p-5 space-y-4 text-xs">
            {!isAdminUnlocked ? (
              <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl text-center space-y-3">
                <div className="w-10 h-10 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center mx-auto">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    {isNe ? 'एडमिन सुरक्षा प्रमाणिकरण (Admin Verification)' : 'Admin Unlock Required'}
                  </h4>
                  <p className="text-xs text-slate-500 mt-1">
                    {isNe
                      ? 'नयाँ कम्पनीहरूलाई स्वीकृति दिन मास्टर एडमिन पिन प्रविष्ट गर्नुहोस् (Default: 1234)'
                      : 'Enter master PIN 1234 to unlock admin approval privileges.'}
                  </p>
                </div>
                <div className="max-w-xs mx-auto flex gap-2">
                  <input
                    type="password"
                    maxLength={6}
                    value={adminPin}
                    onChange={(e) => setAdminPin(e.target.value)}
                    placeholder="****"
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-xl text-center font-mono font-bold tracking-widest text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (companyAccounts.some((a) => a.role === 'SUPER_ADMIN' && !!a.pin && a.pin.trim() === adminPin.trim())) {
                        setIsAdminUnlocked(true);
                      } else {
                        alert(isNe ? 'गलत पिन कोड!' : 'Invalid PIN!');
                      }
                    }}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl shadow-xs cursor-pointer"
                  >
                    {isNe ? 'अन्लक' : 'Unlock'}
                  </button>
                </div>
                <p className="text-[10px] text-slate-400">
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>{isNe ? 'दर्ता भएका मोबाइल नम्बरहरूको सूची' : 'Registered Mobile Companies'}</span>
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      {isNe ? 'नयाँ कम्पनीलाई १-क्लिकमा स्वीकृत वा अस्वीकृत गर्नुहोस्:' : 'Approve or reject pending companies with 1 click:'}
                    </p>
                  </div>
                  <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-lg border">
                    {companyAccounts.length} {isNe ? 'कम्पनी' : 'Companies'}
                  </span>
                </div>

                <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                  {companyAccounts.map((account) => {
                    const isPending = account.status === 'PENDING_APPROVAL';
                    const isApproved = account.status === 'APPROVED';
                    const isRejected = account.status === 'REJECTED';

                    return (
                      <div
                        key={account.id}
                        className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                          isPending
                            ? 'bg-amber-50/70 border-amber-300'
                            : isApproved
                            ? 'bg-white border-slate-200'
                            : 'bg-rose-50/50 border-rose-200'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-slate-900 text-xs">{account.companyName}</span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                                isPending
                                  ? 'bg-amber-200 text-amber-900'
                                  : isApproved
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {isPending
                                ? isNe ? 'पर्खाइमा (Pending)' : 'Pending'
                                : isApproved
                                ? isNe ? 'स्वीकृत (Approved)' : 'Approved'
                                : isNe ? 'अस्वीकृत (Rejected)' : 'Rejected'}
                            </span>
                            <span className="text-[10px] font-bold bg-slate-900 text-emerald-400 px-2 py-0.5 rounded-md font-mono">
                              पद: {account.assignedRole || 'OWNER'}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-600">
                            <span className="font-mono font-semibold text-emerald-800">
                              📱 {account.mobileNumber}
                            </span>
                            <span>👤 {account.ownerName}</span>
                            {account.panVatNo && <span>PAN: {account.panVatNo}</span>}
                            {account.address && <span>📍 {account.address}</span>}
                          </div>
                        </div>

                        {/* Approval Action Buttons */}
                        <div className="flex items-center gap-1.5 shrink-0 flex-wrap sm:flex-nowrap">
                          {/* Role Assign Selector */}
                          <select
                            value={account.assignedRole || 'OWNER'}
                            onChange={(e) => {
                              approveAccount(account.id, e.target.value as UserRole);
                            }}
                            className="text-xs font-bold bg-white border border-slate-300 rounded-lg px-2 py-1 text-slate-800 cursor-pointer"
                            title={isNe ? 'एडमिनबाट तोकिने पद' : 'Assigned Role'}
                          >
                            <option value="OWNER">👑 OWNER (मालिक - सम्पुर्ण अधिकार)</option>
                            <option value="ACCOUNTANT">💼 ACCOUNTANT (एकाउण्टेण्ट - आम्दानी/खर्च/ज्याला)</option>
                            <option value="COUNTER_SALES">🧾 COUNTER SALES (काउन्टर - खरीद/बिक्री बिल)</option>
                            <option value="SALESMAN">📋 SALESMAN (सेल्सम्यान - Order टिपोट)</option>
                            <option value="SUPERVISOR">👷 SUPERVISOR (सुपरभाइजर - हाजिरी/सामान/नोट)</option>
                            <option value="STAFF">👤 STAFF (स्टाफ - हाजिर मात्र)</option>
                          </select>

                          {/* Admin Reset PIN Button */}
                          <button
                            type="button"
                            onClick={() => {
                              setResetModalAccountId(account.id);
                              setResetPinInput('');
                            }}
                            className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold text-xs rounded-lg transition flex items-center gap-1 cursor-pointer"
                            title={isNe ? 'एडमिनबाट नयाँ PIN तोक्नुहोस्' : 'Reset PIN'}
                          >
                            <Key className="w-3.5 h-3.5 text-amber-700" />
                            <span>{isNe ? 'PIN' : 'PIN'}</span>
                          </button>

                          {isPending ? (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  approveAccount(account.id, account.assignedRole || 'OWNER');
                                }}
                                className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-lg transition flex items-center gap-1 shadow-2xs cursor-pointer"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>{isNe ? 'स्वीकृत' : 'Approve'}</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  rejectAccount(account.id);
                                }}
                                className="px-2.5 py-1.5 bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 font-bold text-xs rounded-lg transition flex items-center gap-1 cursor-pointer"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>{isNe ? 'अस्वीकृत' : 'Reject'}</span>
                              </button>
                            </>
                          ) : isApproved ? (
                            <button
                              type="button"
                              onClick={() => quickLogin(account.mobileNumber, account.pin || '', account.assignedRole || 'OWNER')}
                              className="px-3 py-1.5 bg-slate-100 hover:bg-emerald-100 text-slate-800 hover:text-emerald-900 font-semibold text-xs rounded-lg transition flex items-center gap-1 cursor-pointer border border-slate-200"
                            >
                              <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
                              <span>{isNe ? 'यसमा लग-इन' : 'Switch'}</span>
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => approveAccount(account.id, account.assignedRole || 'OWNER')}
                              className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs rounded-lg transition border border-emerald-300 cursor-pointer"
                            >
                              <span>{isNe ? 'पुन: स्वीकृत' : 'Re-Approve'}</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

      </div>

      {/* Admin Reset PIN Modal */}
      {resetModalAccountId && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-amber-900 text-white">
              <div className="flex items-center gap-2">
                <Key className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold">
                  {isNe ? 'एडमिनबाट PIN रिसेट (Admin Reset PIN)' : 'Admin Reset PIN'}
                </h3>
              </div>
              <button
                onClick={() => setResetModalAccountId(null)}
                className="text-amber-200 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const res = resetAccountPin(resetModalAccountId, resetPinInput);
                if (res.success) {
                  alert(res.message);
                  setResetModalAccountId(null);
                } else {
                  alert(res.message);
                }
              }}
              className="p-5 space-y-4 text-xs"
            >
              {(() => {
                const acc = companyAccounts.find((a) => a.id === resetModalAccountId);
                if (!acc) return null;
                return (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1 text-amber-950">
                    <span className="font-bold text-xs block">{acc.companyName}</span>
                    <span className="font-mono text-emerald-800 text-xs block">📱 {acc.mobileNumber} (सञ्चालक: {acc.ownerName})</span>
                  </div>
                );
              })()}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isNe ? 'नयाँ गोप्य PIN प्रविष्ट गर्नुहोस् (४-६ अंक):*' : 'Enter New PIN (4-6 digits):*'}
                </label>
                <input
                  type="password"
                  required
                  maxLength={6}
                  autoFocus
                  value={resetPinInput}
                  onChange={(e) => setResetPinInput(e.target.value)}
                  placeholder="1234"
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-xl font-mono text-center tracking-widest text-lg font-bold text-slate-900 focus:ring-2 focus:ring-amber-500"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  {isNe ? '(उदा: 1234 वा 9855)' : '(e.g. 1234 or 9855)'}
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setResetModalAccountId(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-semibold"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-700 hover:bg-amber-800 text-white font-bold rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Key className="w-4 h-4" />
                  <span>{isNe ? 'PIN रिसेट गरी अपडेट गर्नुहोस्' : 'Update PIN'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
