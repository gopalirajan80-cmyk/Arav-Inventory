import React from 'react';
import { usePaperSize, setPaperSize, useLetterheadMode, setLetterheadMode } from '../utils/paperSize';

/** A4 / A5 kagaj chhanne choto toggle (sabai print ma lagchha) */
export const PaperSizeToggle: React.FC<{ className?: string }> = ({ className = '' }) => {
  const size = usePaperSize();
  const lh = useLetterheadMode();
  return (
    <div
      className={`no-print flex items-center gap-1 px-2 py-0.5 bg-slate-800 rounded-lg border border-slate-700 text-xs ${className}`}
      title="Kagaj ko size (Paper size)"
    >
      <span className="text-[10px] text-slate-400 font-bold uppercase">Paper:</span>
      {(['A4', 'A5'] as const).map((p) => (
        <button
          key={p}
          type="button"
          onClick={() => setPaperSize(p)}
          className={`px-2 py-0.5 rounded font-bold transition cursor-pointer ${
            size === p ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:text-white'
          }`}
        >
          {p}
        </button>
      ))}
      <span className="mx-1 h-4 w-px bg-slate-600" />
      <span className="text-[10px] text-slate-400 font-bold uppercase">Letterhead:</span>
      {([['PRINT', 'Print'], ['PREPRINTED', 'Pre-printed']] as const).map(([k, label]) => (
        <button
          key={k}
          type="button"
          onClick={() => setLetterheadMode(k)}
          title={k === 'PREPRINTED' ? 'Tayar letterhead kagaj ma chhapda mathi khali thau chhodne' : 'Company header sahit chhapne'}
          className={`px-2 py-0.5 rounded font-bold transition cursor-pointer ${
            lh === k ? 'bg-amber-500 text-slate-950' : 'text-slate-300 hover:text-white'
          }`}
        >
          {label}
        </button>
      ))}
    </div>
  );
};
