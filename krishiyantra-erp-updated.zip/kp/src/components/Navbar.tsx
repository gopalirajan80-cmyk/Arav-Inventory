import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PWAInstallButton } from './PWAInstallButton';
import { MobileAuthModal } from './MobileAuthModal';
import {
  Menu,
  Languages,
  Wifi,
  WifiOff,
  Calendar,
  PlusCircle,
  Receipt,
  FileSpreadsheet,
  Smartphone,
  Building2,
  ShieldCheck,
  ShieldAlert,
  Mic,
  Share2,
  X,
  Check,
  Cloud,
  RefreshCw
} from 'lucide-react';
import { getTodayBsString, formatBsDateNepaliText, getDateSyncMode } from '../utils/nepaliCalendar';
import { VoiceAssistantModal } from './VoiceAssistantModal';
import { GoogleDriveBackupModal } from './GoogleDriveBackupModal';
import { DateManagementModal } from './DateManagementModal';

interface NavbarProps {
  onToggleSidebar: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar }) => {
  const {
    language,
    setLanguage,
    activeTab,
    setActiveTab,
    isOnline,
    company,
    companyAccounts,
    currentAccount,
    setCurrentRole,
    loginWithMobile,
    billingSubTab,
    setBillingSubTab,
    setManufacturingSubTab,
    setLedgerSubTab,
    companiesList,
    activeCompanyId,
    switchCompany,
    fiscalYearsList,
    selectFiscalYear,
    addNewFiscalYear,
    syncToCloudNow,
    pullFromCloudNow,
    t
  } = useApp();

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'LOGIN' | 'REGISTER' | 'ADMIN_APPROVAL'>('LOGIN');
  const [isPortalLinksOpen, setIsPortalLinksOpen] = useState(false);
  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  const handleCloudSync = async () => {
    setSyncStatus('सिंक हुँदैछ...');
    const pushRes = await syncToCloudNow();
    const pullRes = await pullFromCloudNow();
    if (pushRes.success || pullRes.success) {
      setSyncStatus('✓ PC र Mobile सिंक सफल भयो!');
    } else {
      setSyncStatus('⚠️ सिंक भयो');
    }
    setTimeout(() => setSyncStatus(null), 3500);
  };

  const publicAppUrl = 'https://ais-pre-4wcnbnzz5cmaf6s6n5ud5c-301709447959.asia-southeast1.run.app';

  const copyPortalUrl = (url: string, id: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2500);
    }
  };

  const pendingApprovalsCount = companyAccounts.filter((a) => a.status === 'PENDING_APPROVAL').length;

  const isNe = language === 'ne';
  const todayBs = getTodayBsString();

  const getActiveTabTitle = () => {
    switch (activeTab) {
      case 'dashboard':
        return isNe ? 'ड्यासबोर्ड तथा व्यापार सारांश' : 'Dashboard Overview';
      case 'billing':
        return isNe ? 'बिलिङ तथा काउन्टर (POS)' : 'Billing & POS';
      case 'vouchers':
        return isNe ? 'रकम असुली तथा भुक्तानी' : 'Dues Collection & Vouchers';
      case 'ledger':
        return isNe ? 'खाता तथा बाँकी विवरण (Party Ledger)' : 'Party Ledger Statement';
      case 'inventory':
        return isNe ? 'इन्भेन्टरी तथा स्टक' : 'Inventory & Stock';
      case 'reports':
        return isNe ? 'विभिन्न रिपोर्टहरू (Reports)' : 'Reports Hub';
      case 'stock_costing':
        return isNe ? 'स्टक मूल्याङ्कन तथा पुनःक्रम' : 'Stock Valuation & Reorder';
      case 'accounting':
        return isNe ? 'लेखा तथा वित्त (Accounting)' : 'Accounting & Finance';
      case 'vat_books':
        return isNe ? 'भ्याट खाता (अनुसूची ५ र ८)' : 'VAT Books (Anusuchi 5 & 8)';
      case 'attendance':
        return isNe ? 'कर्मचारी तथा हाजिरी' : 'Staff & Attendance';
      case 'excel_wizard':
        return isNe ? 'Excel आयात तथा ब्याकअप' : 'Excel Import Wizard';
      case 'manufacturing':
        return isNe ? 'उत्पादन तथा म्यानुफ्याक्चरिङ' : 'Production & Manufacturing';
      case 'audit_trail':
        return isNe ? 'सुपर एडमिन अडिट ट्रेल (Audit Trail)' : 'Super Admin Audit Trail';
      case 'settings':
        return isNe ? 'कम्पनी तथा प्रणाली सेटिङ' : 'Settings';
      default:
        return 'कृषियन्त्र ERP';
    }
  };

  return (
    <header className="no-print ky-topbar sticky top-0 z-30 border-b select-none">
      <div className="w-full px-3 sm:px-6 flex items-center justify-between gap-3 h-16">
        
        {/* Left: Mobile/Desktop Sidebar Hamburger + Active Tab Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            className="p-2 -ml-1 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition cursor-pointer lg:hidden"
            title={isNe ? 'मेनु खोल्नुहोस्' : 'Toggle Menu'}
          >
            <Menu className="w-5 h-5" />
          </button>

          {company.logoUrl && (
            <img
              src={company.logoUrl}
              alt={company.name}
              onClick={() => setActiveTab('settings')}
              className="w-9 h-9 rounded-lg object-contain border border-slate-200 bg-white p-0.5 cursor-pointer shrink-0"
              title={company.name}
            />
          )}

          <div className="min-w-0">
            <h1 className="text-sm sm:text-base font-extrabold text-slate-900 tracking-tight leading-tight flex items-center gap-2 truncate">
              <span className="truncate">{company.name || 'कृषियन्त्र ERP'}</span>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('settings');
                  setTimeout(() => {
                    window.dispatchEvent(
                      new CustomEvent('ims-sub-nav', {
                        detail: { target: 'settings', settingsTab: 'BRANCHES' }
                      })
                    );
                  }, 40);
                }}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-indigo-900 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-2 py-0.5 rounded-md cursor-pointer shrink-0"
                title="शाखा खोल्ने तथा एडमिन कन्ट्रोल (Manage Branches)"
              >
                <span>🏬</span>
                <span className="truncate max-w-[140px]">
                  {(company.branches &&
                    company.branches.find((b) => b.id === company.activeBranchId)?.name) ||
                    (company.branches && company.branches[0]?.name) ||
                    'मुख्य शाखा'}
                </span>
              </button>
              <span className="hidden md:inline-block text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                {getActiveTabTitle()}
              </span>
            </h1>
            
            {/* Company Address, Phone Number, Email / Gmail displayed clearly under company name */}
            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[11px] text-slate-600 font-medium mt-0.5">
              <span className="flex items-center gap-1 text-slate-700">
                <span className="text-emerald-700">📍</span>
                <span className="truncate max-w-[150px] sm:max-w-[240px]">{company.address || 'भरतपुर-१०, चितवन / काठमाडौँ'}</span>
              </span>
              <span className="flex items-center gap-1 text-slate-700">
                <span className="text-blue-700">📞</span>
                <span>{company.phone || '९८५५०१२३४५'}</span>
              </span>
              <span className="flex items-center gap-1 text-slate-700">
                <span className="text-amber-700">✉️</span>
                <span className="truncate max-w-[170px] sm:max-w-[210px]">{company.email || 'krishiyantra.nepal@gmail.com'}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Right: Cloud Sync & Google Drive */}
        <div className="flex items-center gap-2">
          {syncStatus && (
            <span className="text-[11px] font-bold px-2.5 py-1 bg-emerald-100 text-emerald-900 rounded-lg border border-emerald-300 animate-pulse">
              {syncStatus}
            </span>
          )}

          {/* Instant Cloud Sync Button (PC & Mobile Sync) */}
          <button
            type="button"
            onClick={handleCloudSync}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-950 rounded-lg text-xs font-black transition cursor-pointer shadow-2xs"
            title="PC र Mobile बीच डाटा सिंक गर्नुहोस् (Cloud Sync)"
          >
            <RefreshCw className="w-3.5 h-3.5 text-emerald-700" />
            <span className="hidden sm:inline">क्लाउड सिंक</span>
          </button>

          {/* Google Drive Cloud Backup Button */}
          <button
            type="button"
            onClick={() => setIsDriveModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-900 rounded-lg text-xs font-bold transition cursor-pointer shadow-2xs"
            title="Google Drive क्लाउड ब्याकअप र सिंक"
          >
            <Cloud className="w-3.5 h-3.5 text-sky-600" />
            <span className="hidden sm:inline">गुगल ड्राइभ</span>
          </button>
        </div>
      </div>


      {/* Mobile Authentication & Admin Approval Modal */}
      <MobileAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialTab={authModalTab}
      />


      {/* Unified Master Link & All-Features Control Hub Modal */}
      {isPortalLinksOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-4">
            <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center">
                  <Share2 className="w-5 h-5 text-amber-300" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold">
                    {isNe
                      ? '👑 सबै फिचर समेटिएको एउटै मुख्य मास्टर लिंक (Unified Master Link)'
                      : '👑 All-in-One Unified Master Control Link'}
                  </h3>
                  <p className="text-[11px] text-emerald-200">
                    {isNe
                      ? 'एउटै मास्टर लिंकबाट बिलिङ, काम अनुसार हाजिरी, मासिक भ्याट, एक्सेल अपलोड र स्टाफ कन्ट्रोल गर्नुहोस्'
                      : 'Control all features from one single Master Link'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsPortalLinksOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              {/* Primary All-in-One Master Link Box */}
              <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3 border-2 border-amber-400/60 shadow-lg">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="font-extrabold text-amber-300 text-sm block">
                      👑 मुख्य मास्टर लिंक (सबै फिचर एकै ठाउँबाट कन्ट्रोल हुने लिंक)
                    </span>
                    <span className="text-[11px] text-slate-300">
                      यो एउटै लिंक बुकमार्क वा सेभ गर्नुहोस् — यसैबाट सबै मोड्युल र स्टाफ/मालिक मोड चल्छ
                    </span>
                  </div>
                  <button
                    onClick={() => copyPortalUrl(publicAppUrl, 'master_main')}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold rounded-xl cursor-pointer flex items-center gap-1.5 shadow-md"
                  >
                    {copiedId === 'master_main' ? <Check className="w-4 h-4" /> : null}
                    <span>{copiedId === 'master_main' ? '✓ मास्टर लिंक कपी भयो!' : '📋 मास्टर लिंक कपी गर्नुहोस्'}</span>
                  </button>
                </div>

                <input
                  type="text"
                  readOnly
                  value={publicAppUrl}
                  onClick={(e) => (e.target as HTMLInputElement).select()}
                  className="w-full px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-xl font-mono text-xs text-emerald-300 select-all"
                />

                {/* Direct Shareable Sub-Links (Copy or Open Directly) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {[
                    {
                      id: 'link_master',
                      label: '१. मुख्य मास्टर कन्ट्रोल लिंक (सबै फिचर)',
                      url: `${publicAppUrl}/?portal=owner`,
                      action: () => {
                        setCurrentRole('OWNER');
                        setActiveTab('dashboard');
                        setIsPortalLinksOpen(false);
                      }
                    },
                    {
                      id: 'link_purchase',
                      label: '२. खरिद बिल र सप्लायर स्टक (Purchase Link)',
                      url: `${publicAppUrl}/?tab=billing&sub=PURCHASE`,
                      action: () => {
                        setCurrentRole('OWNER');
                        setActiveTab('billing');
                        setBillingSubTab('PURCHASE');
                        setIsPortalLinksOpen(false);
                      }
                    },
                    {
                      id: 'link_manufacturing',
                      label: '३. उत्पादन र मेसिनरी (Manufacture Link)',
                      url: `${publicAppUrl}/?tab=manufacturing`,
                      action: () => {
                        setCurrentRole('OWNER');
                        setActiveTab('manufacturing');
                        setManufacturingSubTab('OVERVIEW');
                        setIsPortalLinksOpen(false);
                      }
                    },
                    {
                      id: 'link_ledger',
                      label: '४. पार्टी खाता र स्टेटमेन्ट (Party Ledger Link)',
                      url: `${publicAppUrl}/?tab=ledger`,
                      action: () => {
                        setCurrentRole('OWNER');
                        setActiveTab('ledger');
                        setLedgerSubTab('ALL');
                        setIsPortalLinksOpen(false);
                      }
                    },
                    {
                      id: 'link_attendance',
                      label: '५. काम अनुसार हाजिरी र प्रिन्ट लिंक',
                      url: `${publicAppUrl}/?tab=attendance`,
                      action: () => {
                        setCurrentRole('OWNER');
                        setActiveTab('attendance');
                        setIsPortalLinksOpen(false);
                      }
                    },
                    {
                      id: 'link_settings',
                      label: '६. मास्टर सेटिङ (सबै मिलाउने) लिंक',
                      url: `${publicAppUrl}/?tab=settings`,
                      action: () => {
                        setCurrentRole('OWNER');
                        setActiveTab('settings');
                        setIsPortalLinksOpen(false);
                      }
                    }
                  ].map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between gap-2 bg-slate-800/90 border border-slate-700 rounded-xl px-3 py-2"
                    >
                      <div className="min-w-0">
                        <div className="text-[11px] font-bold text-white truncate">{item.label}</div>
                        <div className="text-[10px] font-mono text-emerald-400 truncate">{item.url}</div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={item.action}
                          className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-lg text-[10px] cursor-pointer"
                        >
                          खोल्नुहोस्
                        </button>
                        <button
                          type="button"
                          onClick={() => copyPortalUrl(item.url, item.id)}
                          className="px-2 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold rounded-lg text-[10px] cursor-pointer"
                        >
                          {copiedId === item.id ? '✓ कपी' : 'कपी'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* 1-Click All Features Control Grid inside Master Link Modal */}
                <div className="pt-2 border-t border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-200 text-[11px]">
                      ⚡ यहीँबाट १-क्लिकमा सबै फिचर कन्ट्रोल गर्नुहोस्:
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          setCurrentRole('COUNTER_SALES');
                        }}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-md font-bold text-[10px] cursor-pointer"
                      >
                        👷 स्टाफ भ्यू हेर्नुहोस्
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      {
                        id: 'purchase_direct',
                        title: '🛒 खरिद बिल (Purchase)',
                        sub: 'सामान खरिद, फोटो/एक्सेल र सप्लायर खाता',
                        onClick: () => {
                          setCurrentRole('OWNER');
                          setActiveTab('billing');
                          setBillingSubTab('PURCHASE');
                          setIsPortalLinksOpen(false);
                        }
                      },
                      {
                        id: 'manufacturing_direct',
                        title: '🏭 उत्पादन (Manufacture)',
                        sub: 'कच्चा पदार्थ, WIP मेसिन, प्याकिङ र बजार',
                        onClick: () => {
                          setCurrentRole('OWNER');
                          setActiveTab('manufacturing');
                          setManufacturingSubTab('OVERVIEW');
                          setIsPortalLinksOpen(false);
                        }
                      },
                      {
                        id: 'ledger_direct',
                        title: '📒 पार्टी खाता (Party Ledger)',
                        sub: 'ग्राहक र सप्लायर भित्रको लेजर/स्टेटमेन्ट',
                        onClick: () => {
                          setCurrentRole('OWNER');
                          setActiveTab('ledger');
                          setLedgerSubTab('ALL');
                          setIsPortalLinksOpen(false);
                        }
                      },
                      {
                        id: 'sales_direct',
                        title: '🧾 बिक्री र फिर्ता (POS)',
                        sub: 'भ्याट/नन-भ्याट बिक्री र Sales/Purchase Return',
                        onClick: () => {
                          setCurrentRole('OWNER');
                          setActiveTab('billing');
                          setBillingSubTab('SALES');
                          setIsPortalLinksOpen(false);
                        }
                      },
                      {
                        id: 'attendance_direct',
                        title: '👷 काम अनुसार हाजिरी',
                        sub: 'टनेल/प्लास्टिक/ट्याक्टर + प्रिन्ट',
                        onClick: () => {
                          setCurrentRole('OWNER');
                          setActiveTab('attendance');
                          setIsPortalLinksOpen(false);
                        }
                      },
                      {
                        id: 'vat_books_direct',
                        title: '📘 मासिक भ्याट खाता',
                        sub: 'महिना अनुसार खरिद-बिक्री सारांश',
                        onClick: () => {
                          setCurrentRole('OWNER');
                          setActiveTab('vat_books');
                          setIsPortalLinksOpen(false);
                        }
                      },
                      {
                        id: 'vouchers_direct',
                        title: '💰 असुली र भुक्तानी',
                        sub: 'रसिद र भाउचर इन्ट्री',
                        onClick: () => {
                          setCurrentRole('OWNER');
                          setActiveTab('vouchers');
                          setIsPortalLinksOpen(false);
                        }
                      },
                      {
                        id: 'inventory_direct',
                        title: '📦 स्टक र सामान',
                        sub: 'गोदाम र स्टक व्यवस्थापन',
                        onClick: () => {
                          setCurrentRole('OWNER');
                          setActiveTab('inventory');
                          setIsPortalLinksOpen(false);
                        }
                      },
                      {
                        id: 'settings_direct',
                        title: '⚙️ मास्टर सेटिङ',
                        sub: 'कम्पनी, स्टाफ र रोल कन्ट्रोल',
                        onClick: () => {
                          setCurrentRole('OWNER');
                          setActiveTab('settings');
                          setIsPortalLinksOpen(false);
                        }
                      }
                    ].map((feat) => (
                      <button
                        key={feat.id}
                        onClick={feat.onClick}
                        className="p-2.5 rounded-xl bg-slate-800/90 hover:bg-emerald-700 text-left transition cursor-pointer border border-slate-700 flex flex-col justify-between"
                      >
                        <span className="font-bold text-white text-xs">{feat.title}</span>
                        <span className="text-[10px] text-slate-300 mt-0.5">{feat.sub}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-600">
              <span>
                <strong>मास्टर लगइन आईडी:</strong> 9855012345 (PIN: 1234)
              </span>
              <button
                onClick={() => setIsPortalLinksOpen(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg cursor-pointer"
              >
                बन्द गर्नुहोस्
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Google Drive Cloud Backup Modal */}
      <GoogleDriveBackupModal
        isOpen={isDriveModalOpen}
        onClose={() => setIsDriveModalOpen(false)}
      />

      {/* Date Management & Manual Correction Modal */}
      <DateManagementModal
        isOpen={isDateModalOpen}
        onClose={() => setIsDateModalOpen(false)}
      />
    </header>
  );
};
