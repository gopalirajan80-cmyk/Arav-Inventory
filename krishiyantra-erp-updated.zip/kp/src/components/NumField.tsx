import React, { useEffect, useRef, useState } from 'react';

interface Props {
  value: number;
  onCommit: (n: number) => void;
  className?: string;
  placeholder?: string;
  title?: string;
  /** show an empty box instead of 0 (e.g. discount %) */
  blankWhenZero?: boolean;
  /** Enter थिच्दा (जस्तै: सामान थप्न) */
  onEnter?: () => void;
}

/**
 * Edit गर्न मिल्ने अङ्क बाकस।
 * - पूरै मेटाएर नयाँ अङ्क लेख्न मिल्छ (पहिले मेटाउनासाथ "1" फर्किन्थ्यो)
 * - 0.5 जस्ता दशमलव अङ्क बीचमा नबिग्रिने गरी लेख्न मिल्छ
 * - क्लिक गर्दा अङ्क आफैं select हुन्छ — सिधै नयाँ अङ्क टाइप गर्दा पुरानो बदलिन्छ
 */
export const NumField: React.FC<Props> = ({ value, onCommit, className, placeholder, title, blankWhenZero, onEnter }) => {
  const fmt = (n: number) => (blankWhenZero && !n ? '' : String(n));
  const [text, setText] = useState<string>(fmt(value));
  const focused = useRef(false);

  useEffect(() => {
    if (!focused.current) setText(fmt(value));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  return (
    <input
      type="text"
      inputMode="decimal"
      value={text}
      placeholder={placeholder}
      title={title}
      onFocus={(e) => {
        focused.current = true;
        e.target.select();
      }}
      onChange={(e) => {
        const raw = e.target.value;
        if (!/^\d*\.?\d*$/.test(raw)) return;
        setText(raw);
        if (raw === '' || raw === '.') return;
        const n = Number(raw);
        if (!Number.isNaN(n)) onCommit(n);
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter' && onEnter) {
          e.preventDefault();
          onEnter();
        }
      }}
      onBlur={() => {
        focused.current = false;
        setText(fmt(value));
      }}
      className={className}
    />
  );
};

export default NumField;
