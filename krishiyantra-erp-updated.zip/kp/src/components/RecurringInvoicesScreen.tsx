import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { RecurringInvoice, RecurringFrequency } from '../types';
import { Plus, Trash2, Edit2, Calendar } from 'lucide-react';

export const RecurringInvoicesScreen: React.FC = () => {
  const { recurringInvoices, saveRecurringInvoice, deleteRecurringInvoice, parties, language } = useApp();
  const isNe = language === 'ne';

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<RecurringInvoice | null>(null);

  return (
    <div className="p-6 bg-white rounded-lg shadow space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">{isNe ? 'दोहोरिने बिलहरू (Recurring Invoices)' : 'Recurring Invoices'}</h2>
        <button
          onClick={() => { setEditingInvoice(null); setIsModalOpen(true); }}
          className="px-4 py-2 bg-emerald-700 text-white rounded-lg text-sm font-bold flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          {isNe ? 'नयाँ थप्नुहोस्' : 'Add New'}
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-100 text-slate-600 text-xs uppercase font-bold">
              <th className="p-3">ग्राहक</th>
              <th className="p-3">आवृत्ति</th>
              <th className="p-3">अर्को बिल मिति</th>
              <th className="p-3">एक्सन</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {recurringInvoices.map(ri => (
              <tr key={ri.id}>
                <td className="p-3 font-semibold">{ri.customerName}</td>
                <td className="p-3">{ri.frequency}</td>
                <td className="p-3">{ri.nextRunDateBs}</td>
                <td className="p-3 flex gap-2">
                  <button onClick={() => { setEditingInvoice(ri); setIsModalOpen(true); }} className="text-emerald-700 cursor-pointer"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => deleteRecurringInvoice(ri.id)} className="text-rose-700 cursor-pointer"><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
