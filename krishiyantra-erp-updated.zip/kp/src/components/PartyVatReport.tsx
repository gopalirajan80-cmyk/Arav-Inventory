import React, { useMemo, useState } from 'react';
import { Printer, FileSpreadsheet, Users } from 'lucide-react';
import { printPage } from '../utils/printHelper';
import { NEPALI_MONTHS_NE, NEPALI_MONTHS_EN, toNepaliDigits } from '../utils/nepaliCalendar';

/**
 * Party-wise VAT report.
 *  - pick a report type: VAT sales / Exempt sales / VAT purchase / Exempt purchase / All
 *  - pick one party (or all) and one month (or all)
 *  - shows: month-wise summary, party-wise summary, and bill-wise detail grouped by month
 *  - print (A4) and CSV export
 * Works on the already year-filtered invoices / purchases passed in by VatBookScreen.
 */

type ReportType = 'ALL' | 'SALES_VAT' | 'SALES_EXEMPT' | 'PURCH_VAT' | 'PURCH_EXEMPT';
type Side = 'SALES' | 'PURCHASE';

interface Rec {
  id: string;
  side: Side;
  dateBs: string;
  monthCode: string;
  billNo: string;
  partyName: string;
  pan: string;
  taxable: number;
  exempt: number;
  vat: number;
  total: number;
}

interface Props {
  invoices: any[]; // active invoices, already filtered by year
  purchases: any[]; // purchases, already filtered by year
  initialMonth: string; // 'ALL' | '01'..'12'
  yearLabel: string;
  isNe: boolean;
  company: { name?: string; address?: string; panVatNo?: string };
}

const TYPES: { id: ReportType; ne: string; en: string }[] = [
  { id: 'ALL', ne: 'सबै (बिक्री + खरिद)', en: 'All (Sales + Purchase)' },
  { id: 'SALES_VAT', ne: 'VAT बिक्री', en: 'VAT Sales' },
  { id: 'SALES_EXEMPT', ne: 'छुट बिक्री', en: 'Exempt Sales' },
  { id: 'PURCH_VAT', ne: 'VAT खरिद', en: 'VAT Purchase' },
  { id: 'PURCH_EXEMPT', ne: 'छुट खरिद', en: 'Exempt Purchase' }
];

const monthOf = (dateBs: string) => {
  const p = (dateBs || '').trim().replace(/\//g, '-').split('-');
  const m = p[1] ? parseInt(p[1], 10) : 0;
  return m >= 1 && m <= 12 ? String(m).padStart(2, '0') : '';
};

const r2 = (n: number) => Math.round((n || 0) * 100) / 100;
const num = (n: number) =>
  Math.abs(n) < 0.005 ? '-' : n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const partyKey = (name: string, pan: string) => `${(name || '').trim().toLowerCase()}|${(pan || '').trim()}`;

export const PartyVatReport: React.FC<Props> = ({ invoices, purchases, initialMonth, yearLabel, isNe, company }) => {
  const [type, setType] = useState<ReportType>('ALL');
  const [month, setMonth] = useState<string>(initialMonth || 'ALL');
  const [partyFilter, setPartyFilter] = useState<string>('ALL');
  const [partySearch, setPartySearch] = useState('');
  const [showDetail, setShowDetail] = useState(true);

  const t = (ne: string, en: string) => (isNe ? ne : en);
  const isSalesType = type === 'SALES_VAT' || type === 'SALES_EXEMPT';
  const isPurchType = type === 'PURCH_VAT' || type === 'PURCH_EXEMPT';
  const isVatType = type === 'SALES_VAT' || type === 'PURCH_VAT';
  const isExemptType = type === 'SALES_EXEMPT' || type === 'PURCH_EXEMPT';

  // 1. All bills turned into one flat list, shaped for the chosen report type
  const allRecs: Rec[] = useMemo(() => {
    const out: Rec[] = [];
    const push = (side: Side, x: any, billNo: string, partyName: string, pan: string) => {
      const taxable = Number(x.taxableAmount) || 0;
      const exempt = Number(x.exemptAmount) || 0;
      const vat = Number(x.vatAmount) || 0;
      const grand = Number(x.grandTotal) || 0;
      // keep only bills that belong to the chosen report type
      if (type === 'SALES_VAT' && !(side === 'SALES' && taxable > 0)) return;
      if (type === 'SALES_EXEMPT' && !(side === 'SALES' && exempt > 0)) return;
      if (type === 'PURCH_VAT' && !(side === 'PURCHASE' && taxable > 0)) return;
      if (type === 'PURCH_EXEMPT' && !(side === 'PURCHASE' && exempt > 0)) return;
      const rec: Rec = {
        id: `${side}-${x.id}`,
        side,
        dateBs: (x.dateBs || '').replace(/\//g, '-'),
        monthCode: monthOf(x.dateBs),
        billNo,
        partyName: partyName || '—',
        pan: pan || '',
        taxable: isExemptType ? 0 : taxable,
        exempt: isVatType ? 0 : exempt,
        vat: isExemptType ? 0 : vat,
        total: type === 'ALL' ? grand : isVatType ? taxable + vat : exempt
      };
      out.push(rec);
    };
    if (type !== 'PURCH_VAT' && type !== 'PURCH_EXEMPT') {
      invoices.forEach((i) => push('SALES', i, i.invoiceNo, i.customerName, i.customerPan));
    }
    if (type !== 'SALES_VAT' && type !== 'SALES_EXEMPT') {
      purchases.forEach((p) => push('PURCHASE', p, p.purchaseBillNo, p.supplierName, p.supplierPan));
    }
    return out.sort((a, b) => a.dateBs.localeCompare(b.dateBs));
  }, [invoices, purchases, type]);

  // 2. party list for the dropdown (only parties that have bills of this type)
  const partyOptions = useMemo(() => {
    const m = new Map<string, { key: string; name: string; pan: string }>();
    allRecs.forEach((r) => {
      const k = partyKey(r.partyName, r.pan);
      if (!m.has(k)) m.set(k, { key: k, name: r.partyName, pan: r.pan });
    });
    return Array.from(m.values()).sort((a, b) => a.name.localeCompare(b.name));
  }, [allRecs]);

  const visibleOptions = useMemo(() => {
    const q = partySearch.trim().toLowerCase();
    if (!q) return partyOptions;
    return partyOptions.filter((o) => o.name.toLowerCase().includes(q) || o.pan.includes(q));
  }, [partyOptions, partySearch]);

  // if the chosen party has no bills under this type, fall back to "all"
  const effectiveParty = partyFilter !== 'ALL' && partyOptions.some((o) => o.key === partyFilter) ? partyFilter : 'ALL';
  const selectedPartyObj = partyOptions.find((o) => o.key === effectiveParty);

  // 3. apply party + month
  const recs = useMemo(
    () =>
      allRecs.filter(
        (r) =>
          (effectiveParty === 'ALL' || partyKey(r.partyName, r.pan) === effectiveParty) &&
          (month === 'ALL' || r.monthCode === month)
      ),
    [allRecs, effectiveParty, month]
  );

  const sumOf = (list: Rec[]) => ({
    count: list.length,
    taxable: r2(list.reduce((s, r) => s + r.taxable, 0)),
    exempt: r2(list.reduce((s, r) => s + r.exempt, 0)),
    vat: r2(list.reduce((s, r) => s + r.vat, 0)),
    total: r2(list.reduce((s, r) => s + r.total, 0))
  });
  const grand = useMemo(() => sumOf(recs), [recs]);
  // In "All" mode sales and purchase must never be added together
  const grandRows = useMemo(
    () =>
      type === 'ALL'
        ? (['SALES', 'PURCHASE'] as Side[])
            .map((side) => ({ side: side as Side | null, s: sumOf(recs.filter((r) => r.side === side)) }))
            .filter((x) => x.s.count > 0)
        : [{ side: null as Side | null, s: grand }],
    [recs, type, grand]
  );

  // month-wise summary (month x side)
  const monthRows = useMemo(() => {
    const rows: { monthCode: string; side: Side; s: ReturnType<typeof sumOf> }[] = [];
    for (let m = 1; m <= 12; m++) {
      const code = String(m).padStart(2, '0');
      (['SALES', 'PURCHASE'] as Side[]).forEach((side) => {
        const list = recs.filter((r) => r.monthCode === code && r.side === side);
        if (list.length) rows.push({ monthCode: code, side, s: sumOf(list) });
      });
    }
    return rows;
  }, [recs]);

  // party-wise summary (party x side)
  const partyRows = useMemo(() => {
    const m = new Map<string, { name: string; pan: string; side: Side; list: Rec[] }>();
    recs.forEach((r) => {
      const k = `${r.side}|${partyKey(r.partyName, r.pan)}`;
      const e = m.get(k) || { name: r.partyName, pan: r.pan, side: r.side, list: [] };
      e.list.push(r);
      m.set(k, e);
    });
    return Array.from(m.values())
      .map((e) => ({ ...e, s: sumOf(e.list) }))
      .sort((a, b) => b.s.total - a.s.total);
  }, [recs]);

  // bill-wise detail grouped by month
  const detailGroups = useMemo(() => {
    const groups: { monthCode: string; side: Side | null; list: Rec[] }[] = [];
    const sides: (Side | null)[] = type === 'ALL' ? ['SALES', 'PURCHASE'] : [null];
    const codes = [...Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, '0')), ''];
    codes.forEach((code) => {
      sides.forEach((side) => {
        const list = recs.filter((r) => r.monthCode === code && (side === null || r.side === side));
        if (list.length) groups.push({ monthCode: code, side, list });
      });
    });
    return groups;
  }, [recs, type]);

  const monthName = (code: string) => {
    const i = parseInt(code, 10) - 1;
    if (i < 0) return t('मिति नखुलेको', 'No date');
    return isNe ? NEPALI_MONTHS_NE[i] : NEPALI_MONTHS_EN[i];
  };
  const sideLabel = (s: Side) => (s === 'SALES' ? t('बिक्री', 'Sales') : t('खरिद', 'Purchase'));
  const typeLabel = TYPES.find((x) => x.id === type)!;
  const periodLabel = month === 'ALL' ? t('सबै महिना', 'All months') : monthName(month);
  const partyLabel = selectedPartyObj ? selectedPartyObj.name : t('सबै पार्टी', 'All parties');

  const showTaxable = !isExemptType;
  const showExempt = !isVatType;
  const showVat = !isExemptType;
  const totalHead = type === 'ALL' ? t('जम्मा', 'Total') : isVatType ? t('करयोग्य + VAT', 'Taxable + VAT') : t('छुट रकम', 'Exempt Amount');

  const handleCsv = () => {
    const head = ['Section', 'Month', 'Date (BS)', 'Bill No', 'Party', 'PAN', 'Type', 'Bills', 'Taxable', 'Exempt', 'VAT', 'Total'];
    const esc = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
    const lines: (string | number)[][] = [];
    monthRows.forEach((r) =>
      lines.push(['Month summary', monthName(r.monthCode), '', '', '', '', sideLabel(r.side), r.s.count, r.s.taxable, r.s.exempt, r.s.vat, r.s.total])
    );
    partyRows.forEach((r) =>
      lines.push(['Party summary', '', '', '', r.name, r.pan, sideLabel(r.side), r.s.count, r.s.taxable, r.s.exempt, r.s.vat, r.s.total])
    );
    recs.forEach((r) =>
      lines.push(['Bill', monthName(r.monthCode), r.dateBs, r.billNo, r.partyName, r.pan, sideLabel(r.side), 1, r.taxable, r.exempt, r.vat, r.total])
    );
    const csv = '\uFEFF' + [head.map(esc).join(','), ...lines.map((l) => l.map(esc).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Party_VAT_Report_${typeLabel.id}_${(selectedPartyObj?.name || 'ALL').replace(/\s+/g, '_')}_${month}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const th = 'px-2 py-1.5 font-bold border border-slate-300 bg-slate-100 text-slate-800';
  const td = 'px-2 py-1 border border-slate-200';
  const tdn = `${td} text-right font-mono tabular-nums`;
  const showSideCol = type === 'ALL';

  const AmountHeads = () => (
    <>
      {showTaxable && <th className={`${th} text-right`}>{t('करयोग्य', 'Taxable')}</th>}
      {showExempt && <th className={`${th} text-right`}>{t('छुट', 'Exempt')}</th>}
      {showVat && <th className={`${th} text-right`}>VAT</th>}
      <th className={`${th} text-right`}>{totalHead}</th>
    </>
  );
  const AmountCells: React.FC<{ s: { taxable: number; exempt: number; vat: number; total: number }; bold?: boolean }> = ({ s, bold }) => (
    <>
      {showTaxable && <td className={`${tdn} ${bold ? 'font-bold' : ''}`}>{num(s.taxable)}</td>}
      {showExempt && <td className={`${tdn} ${bold ? 'font-bold' : ''}`}>{num(s.exempt)}</td>}
      {showVat && <td className={`${tdn} ${bold ? 'font-bold' : ''}`}>{num(s.vat)}</td>}
      <td className={`${tdn} font-bold`}>{num(s.total)}</td>
    </>
  );

  return (
    <div className="space-y-4">
      {/* ---------- Controls (not printed) ---------- */}
      <div className="no-print bg-white rounded-xl border border-slate-200 shadow-xs p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-purple-700" />
            <h2 className="text-sm sm:text-base font-bold text-slate-900">{t('पार्टी अनुसार VAT रिपोर्ट', 'Party-wise VAT Report')}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={handleCsv} className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold rounded-lg cursor-pointer">
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" /> CSV
            </button>
            <button type="button" onClick={() => printPage({ mode: 'A4' })} className="flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg cursor-pointer">
              <Printer className="w-3.5 h-3.5 text-emerald-400" /> {t('प्रिन्ट', 'Print')}
            </button>
          </div>
        </div>

        {/* report type */}
        <div className="flex flex-wrap gap-1.5">
          {TYPES.map((x) => (
            <button
              key={x.id}
              type="button"
              onClick={() => setType(x.id)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg border cursor-pointer transition ${
                type === x.id ? 'bg-emerald-700 text-white border-emerald-700' : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
              }`}
            >
              {isNe ? x.ne : x.en}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <label className="flex flex-col gap-1">
            <span className="text-slate-500 font-semibold">{t('महिना', 'Month')}</span>
            <select value={month} onChange={(e) => setMonth(e.target.value)} className="border border-slate-300 rounded-lg px-2 py-1.5 bg-white">
              <option value="ALL">{t('सबै १२ महिना', 'All 12 months')}</option>
              {NEPALI_MONTHS_NE.map((n, i) => (
                <option key={n} value={String(i + 1).padStart(2, '0')}>
                  {String(i + 1).padStart(2, '0')} - {isNe ? n : NEPALI_MONTHS_EN[i]}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-slate-500 font-semibold">{t('पार्टी खोज्नुहोस् (नाम / PAN)', 'Find party (name / PAN)')}</span>
            <input value={partySearch} onChange={(e) => setPartySearch(e.target.value)} placeholder={t('नाम टाइप गर्नुहोस्…', 'Type to filter…')} className="border border-slate-300 rounded-lg px-2 py-1.5" />
          </label>
          <label className="flex flex-col gap-1 sm:col-span-2">
            <span className="text-slate-500 font-semibold">{t('पार्टी', 'Party')} ({partyOptions.length})</span>
            <select value={effectiveParty} onChange={(e) => setPartyFilter(e.target.value)} className="border border-slate-300 rounded-lg px-2 py-1.5 bg-white">
              <option value="ALL">{t('सबै पार्टी', 'All parties')}</option>
              {visibleOptions.map((o) => (
                <option key={o.key} value={o.key}>
                  {o.name}{o.pan ? ` — PAN ${o.pan}` : ''}
                </option>
              ))}
            </select>
          </label>
        </div>
        <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
          <input type="checkbox" checked={showDetail} onChange={(e) => setShowDetail(e.target.checked)} />
          {t('बिल अनुसार विस्तृत विवरण पनि देखाउने / प्रिन्ट गर्ने', 'Include bill-wise detail')}
        </label>
      </div>

      {/* ---------- Report (this block is what gets printed) ---------- */}
      <div data-print-target className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-5 text-slate-900">
        <div className="text-center space-y-0.5">
          <h1 className="text-base font-bold">{company.name}</h1>
          {company.address && <p className="text-[11px]">{company.address}</p>}
          {company.panVatNo && <p className="text-[11px] font-semibold">PAN/VAT: {company.panVatNo}</p>}
          <h2 className="text-sm font-bold pt-1">
            {t('पार्टी अनुसार VAT रिपोर्ट', 'Party-wise VAT Report')} — {isNe ? typeLabel.ne : typeLabel.en}
          </h2>
          <p className="text-[11px]">
            {t('पार्टी', 'Party')}: <b>{partyLabel}</b>
            {selectedPartyObj?.pan ? ` (PAN ${selectedPartyObj.pan})` : ''} · {t('अवधि', 'Period')}: <b>{periodLabel}</b> · {t('वर्ष', 'Year')}: <b>{yearLabel}</b>
          </p>
        </div>

        {recs.length === 0 ? (
          <p className="text-sm text-slate-500 text-center py-6">{t('यो छनोटमा कुनै बिल भेटिएन।', 'No bills found for this selection.')}</p>
        ) : (
          <>
            {/* Grand total strip */}
            {type !== 'ALL' && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="border border-slate-200 rounded-lg p-2"><div className="text-slate-500">{t('बिल संख्या', 'Bills')}</div><div className="font-bold font-mono">{isNe ? toNepaliDigits(grand.count) : grand.count}</div></div>
              {showTaxable && <div className="border border-slate-200 rounded-lg p-2"><div className="text-slate-500">{t('करयोग्य', 'Taxable')}</div><div className="font-bold font-mono">{num(grand.taxable)}</div></div>}
              {showExempt && <div className="border border-slate-200 rounded-lg p-2"><div className="text-slate-500">{t('छुट', 'Exempt')}</div><div className="font-bold font-mono">{num(grand.exempt)}</div></div>}
              {showVat && <div className="border border-slate-200 rounded-lg p-2"><div className="text-slate-500">VAT (13%)</div><div className="font-bold font-mono">{num(grand.vat)}</div></div>}
            </div>
            )}

            {/* A. Month-wise */}
            <section>
              <h3 className="text-xs font-bold mb-1.5">{t('क. मासिक विवरण', 'A. Month-wise Summary')}</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-[11px] border-collapse">
                  <thead>
                    <tr>
                      <th className={`${th} text-left`}>{t('महिना', 'Month')}</th>
                      {showSideCol && <th className={`${th} text-left`}>{t('प्रकार', 'Type')}</th>}
                      <th className={`${th} text-right`}>{t('बिल', 'Bills')}</th>
                      <AmountHeads />
                    </tr>
                  </thead>
                  <tbody>
                    {monthRows.map((r) => (
                      <tr key={r.monthCode + r.side}>
                        <td className={td}>{monthName(r.monthCode)}</td>
                        {showSideCol && <td className={td}>{sideLabel(r.side)}</td>}
                        <td className={tdn}>{r.s.count}</td>
                        <AmountCells s={r.s} />
                      </tr>
                    ))}
                    {grandRows.map((g) => (
                      <tr key={g.side || 'all'} className="bg-slate-50 font-bold">
                        <td className={td}>{g.side ? `${sideLabel(g.side)} ${t('कुल जम्मा', 'Grand Total')}` : t('कुल जम्मा', 'Grand Total')}</td>
                        {showSideCol && <td className={td}></td>}
                        <td className={tdn}>{g.s.count}</td>
                        <AmountCells s={g.s} bold />
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* B. Party-wise */}
            {effectiveParty === 'ALL' && (
              <section>
                <h3 className="text-xs font-bold mb-1.5">{t('ख. पार्टी अनुसार विवरण', 'B. Party-wise Summary')}</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-[11px] border-collapse">
                    <thead>
                      <tr>
                        <th className={`${th} text-left`}>#</th>
                        <th className={`${th} text-left`}>{t('पार्टीको नाम', 'Party')}</th>
                        <th className={`${th} text-left`}>PAN</th>
                        {showSideCol && <th className={`${th} text-left`}>{t('प्रकार', 'Type')}</th>}
                        <th className={`${th} text-right`}>{t('बिल', 'Bills')}</th>
                        <AmountHeads />
                      </tr>
                    </thead>
                    <tbody>
                      {partyRows.map((r, i) => (
                        <tr key={r.side + r.name + r.pan}>
                          <td className={td}>{i + 1}</td>
                          <td className={`${td} font-semibold`}>{r.name}</td>
                          <td className={`${td} font-mono`}>{r.pan || '-'}</td>
                          {showSideCol && <td className={td}>{sideLabel(r.side)}</td>}
                          <td className={tdn}>{r.s.count}</td>
                          <AmountCells s={r.s} />
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            )}

            {/* C. Bill-wise detail, grouped by month */}
            {showDetail && (
              <section>
                <h3 className="text-xs font-bold mb-1.5">
                  {effectiveParty === 'ALL' ? t('ग. बिल अनुसार विवरण', 'C. Bill-wise Detail') : t('ख. बिल अनुसार विवरण', 'B. Bill-wise Detail')}
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-[11px] border-collapse">
                    <thead>
                      <tr>
                        <th className={`${th} text-left`}>{t('मिति', 'Date (BS)')}</th>
                        <th className={`${th} text-left`}>{t('बिल नं.', 'Bill No')}</th>
                        {effectiveParty === 'ALL' && <th className={`${th} text-left`}>{t('पार्टी', 'Party')}</th>}
                        {showSideCol && <th className={`${th} text-left`}>{t('प्रकार', 'Type')}</th>}
                        <AmountHeads />
                      </tr>
                    </thead>
                    <tbody>
                      {detailGroups.map((g) => {
                        const cols = 2 + (effectiveParty === 'ALL' ? 1 : 0) + (showSideCol ? 1 : 0);
                        const sub = sumOf(g.list);
                        return (
                          <React.Fragment key={`${g.monthCode || 'none'}-${g.side || 'x'}`}>
                            <tr className="bg-emerald-50">
                              <td className={`${td} font-bold`} colSpan={cols + (showTaxable ? 1 : 0) + (showExempt ? 1 : 0) + (showVat ? 1 : 0) + 1}>
                                {monthName(g.monthCode)}{g.side ? ` — ${sideLabel(g.side)}` : ''}
                              </td>
                            </tr>
                            {g.list.map((r) => (
                              <tr key={r.id}>
                                <td className={`${td} font-mono whitespace-nowrap`}>{r.dateBs}</td>
                                <td className={`${td} font-mono`}>{r.billNo}</td>
                                {effectiveParty === 'ALL' && <td className={td}>{r.partyName}</td>}
                                {showSideCol && <td className={td}>{sideLabel(r.side)}</td>}
                                <AmountCells s={r} />
                              </tr>
                            ))}
                            <tr className="bg-slate-50 font-bold">
                              <td className={td} colSpan={cols}>{monthName(g.monthCode)}{g.side ? ` ${sideLabel(g.side)}` : ''} {t('जम्मा', 'subtotal')}</td>
                              <AmountCells s={sub} bold />
                            </tr>
                          </React.Fragment>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </div>
  );
};
