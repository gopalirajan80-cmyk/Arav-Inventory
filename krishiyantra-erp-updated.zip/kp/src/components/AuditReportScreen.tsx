import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { formatCurrency, getTodayBsString } from '../utils/nepaliCalendar';
import { printOrDownloadReportPdf, exportReportToExcel, PrintableReportConfig } from '../utils/pdfReportExporter';
import { Printer, FileText, ShieldCheck, Activity, Landmark, FileSpreadsheet, Download, ShieldAlert, Layers } from 'lucide-react';
import { AuditTrailScreen } from './AuditTrailScreen';

export type AuditSubTab = 'NFRS_REPORT' | 'AUDIT_TRAIL' | 'BOTH';

interface AuditReportScreenProps {
  initialSubTab?: AuditSubTab;
}

const AuditReportScreen: React.FC<AuditReportScreenProps> = ({ initialSubTab = 'BOTH' }) => {
  const {
    company,
    parties,
    items,
    language,
    invoices,
    purchases,
    partyTransactions,
    employeeLedger,
    expenses,
    bankAccounts,
    auditLogs
  } = useApp();
  const isNe = language === 'ne';

  const [activeSubTab, setActiveSubTab] = useState<AuditSubTab>(initialSubTab);

  useEffect(() => {
    setActiveSubTab(initialSubTab);
  }, [initialSubTab]);

  useEffect(() => {
    const handleSubNav = (e: Event) => {
      const detail = (e as CustomEvent).detail || {};
      if (detail.auditSubTab) {
        setActiveSubTab(detail.auditSubTab);
      }
    };
    window.addEventListener('ims-sub-nav', handleSubNav);
    return () => window.removeEventListener('ims-sub-nav', handleSubNav);
  }, []);

  const reportData = React.useMemo(() => {
    // --- 1. INCOME STATEMENT (P&L) CALCULATION ---
    const totalSales = invoices.filter(i => i.status === 'ACTIVE').reduce((sum, i) => sum + i.grandTotal, 0);
    const vatOnSales = invoices.filter(i => i.status === 'ACTIVE' && i.billType === 'VAT').reduce((sum, i) => sum + (i.vatAmount || 0), 0);
    const revenue = totalSales - vatOnSales; // Net Revenue

    const totalPurchases = purchases.reduce((sum, p) => sum + p.grandTotal, 0);
    const vatOnPurchases = purchases.reduce((sum, p) => sum + (p.vatAmount || 0), 0);
    const netPurchases = totalPurchases - vatOnPurchases;

    const inventoryValue = items.reduce((sum, i) => sum + (i.currentStock * i.purchasePrice), 0);
    const cogs = Math.max(0, netPurchases - inventoryValue);

    const grossProfit = revenue - cogs;

    const staffExpenses = employeeLedger.filter(l => l.type === 'SALARY_PAYMENT').reduce((sum, l) => sum + l.amount, 0);
    const administrativeExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const totalExpenses = staffExpenses + administrativeExpenses;

    const netProfit = grossProfit - totalExpenses;

    // --- 2. STATEMENT OF FINANCIAL POSITION (BALANCE SHEET) ---
    // A. Assets
    const cashSales = invoices.filter(i => i.status === 'ACTIVE' && i.paymentMode === 'CASH').reduce((sum, i) => sum + (i.amountPaid || i.grandTotal), 0);
    const cashCollections = partyTransactions.filter(t => t.paymentMode === 'CASH' && t.type === 'COLLECTION_FROM_CUSTOMER').reduce((sum, t) => sum + t.amount, 0);
    const cashPurchases = purchases.filter(p => p.paymentMode === 'CASH').reduce((sum, p) => sum + p.grandTotal, 0);
    const cashPayments = partyTransactions.filter(t => t.paymentMode === 'CASH' && t.type === 'PAYMENT_TO_SUPPLIER').reduce((sum, t) => sum + t.amount, 0);
    const cashSalary = employeeLedger.filter(l => l.paymentMode === 'CASH').reduce((sum, l) => sum + l.amount, 0);
    const cashExpenses = expenses.filter(e => e.paymentMode === 'CASH').reduce((sum, e) => sum + e.amount, 0);

    const cashBalance = Math.max(0, (cashSales + cashCollections) - (cashPurchases + cashPayments + cashSalary + cashExpenses));
    const bankBalance = bankAccounts.reduce((sum, b) => sum + b.currentBalance, 0);

    const tradeReceivables = parties.filter(p => p.partyType === 'CUSTOMER' || p.partyType === 'BOTH').reduce((sum, p) => sum + Math.max(0, p.currentBalance), 0);

    // B. Liabilities
    const tradePayables = parties.filter(p => p.partyType === 'SUPPLIER' || p.partyType === 'BOTH').reduce((sum, p) => sum + Math.abs(Math.min(0, p.currentBalance)), 0);

    // C. Equity
    const totalAssets = cashBalance + bankBalance + inventoryValue + tradeReceivables;
    const totalLiabilities = tradePayables;
    const equity = totalAssets - totalLiabilities;

    return {
      cashBalance,
      bankBalance,
      pnl: {
        revenue,
        cogs,
        grossProfit,
        staffExpenses,
        administrativeExpenses,
        totalExpenses,
        netProfit
      },
      balanceSheet: {
        currentAssets: [
          { note: '3.1', label: isNe ? 'नगद र नगद बराबर (Cash & Equivalents)' : 'Cash & Cash Equivalents', amount: cashBalance + bankBalance },
          { note: '3.2', label: isNe ? 'व्यापारिक मौज्दात (Inventories)' : 'Inventories', amount: inventoryValue },
          { note: '3.3', label: isNe ? 'व्यापारिक प्राप्य रकम (Trade Receivables)' : 'Trade Receivables', amount: tradeReceivables },
        ],
        nonCurrentAssets: [
          { note: '3.4', label: isNe ? 'सम्पत्ति, संयन्त्र र उपकरण (PPE)' : 'Property, Plant & Equipment', amount: 0 },
        ],
        currentLiabilities: [
          { note: '4.1', label: isNe ? 'व्यापारिक देय रकम (Trade Payables)' : 'Trade Payables', amount: tradePayables },
          { note: '4.2', label: isNe ? 'अन्य चालू दायित्व (Other Liabilities)' : 'Other Current Liabilities', amount: 0 },
        ],
        equity: [
          { note: '5.1', label: isNe ? 'सेयर पुँजी (Share Capital)' : 'Share Capital', amount: equity - netProfit },
          { note: '5.2', label: isNe ? 'रिटेन्ड अर्निङ / नाफा (Retained Earnings)' : 'Retained Earnings (Profit)', amount: netProfit },
        ],
        totalAssets,
        totalLiabilities,
        netEquity: equity
      }
    };
  }, [invoices, purchases, partyTransactions, employeeLedger, expenses, bankAccounts, items, parties, isNe]);

  const buildNfrsExportConfig = (useRawNumbers = false): PrintableReportConfig => {
    const fmt = (val: number) => (useRawNumbers ? Number(val.toFixed(2)) : formatCurrency(val, isNe));
    const fmtNeg = (val: number) => (useRawNumbers ? Number((-val).toFixed(2)) : `(${formatCurrency(val, isNe)})`);

    return {
      company,
      titleNe: 'एनएफआरएस (NFRS) आधारित लेखा परीक्षण प्रतिवेदन',
      titleEn: 'NFRS Compliant Audit Report',
      subtitleNe: 'वित्तीय अवस्था र नाफा नोक्सानको विस्तृत विवरण',
      headers: [
        isNe ? 'नोट नं. (Note)' : 'Note Ref',
        isNe ? 'विवरण (Particulars)' : 'Particulars',
        isNe ? 'अनुसूची / वर्ग (NFRS Schedule)' : 'NFRS Schedule',
        isNe ? 'रकम रु. (Amount NPR)' : 'Amount (NPR)'
      ],
      rows: [
        // P&L Section
        ['1.0', isNe ? '--- नाफा वा नोक्सानको विवरण (Statement of Profit or Loss) ---' : '--- Statement of Profit or Loss ---', 'NFRS P&L', ''],
        ['1.1', isNe ? 'कुल आम्दानी (Revenue from Operations)' : 'Revenue from Operations', isNe ? 'सञ्चालन आम्दानी' : 'Operating Revenue', fmt(reportData.pnl.revenue)],
        ['1.2', isNe ? 'बिक्री लागत (Cost of Sales / COGS)' : 'Cost of Sales (COGS)', isNe ? 'प्रत्यक्ष लागत' : 'Direct Cost', fmtNeg(reportData.pnl.cogs)],
        ['1.3', isNe ? 'कुल नाफा (Gross Profit)' : 'Gross Profit', isNe ? 'कुल मुनाफा' : 'Gross Margin', fmt(reportData.pnl.grossProfit)],
        ['2.1', isNe ? 'कर्मचारी लाभ खर्च (Employee Benefit Expenses)' : 'Employee Benefit Expenses', isNe ? 'सञ्चालन खर्च' : 'Operating Expense', fmtNeg(reportData.pnl.staffExpenses)],
        ['2.2', isNe ? 'प्रशासकीय तथा अन्य खर्च (Administrative Expenses)' : 'Administrative Expenses', isNe ? 'सञ्चालन खर्च' : 'Operating Expense', fmtNeg(reportData.pnl.administrativeExpenses)],
        ['2.3', isNe ? 'अवधिको खुद नाफा (Net Profit for the Period)' : 'Net Profit for the Period', isNe ? 'खुद मुनाफा' : 'Net Profit', fmt(reportData.pnl.netProfit)],
        ['', '', '', ''],
        // Balance Sheet Section
        ['3.0', isNe ? '--- वित्तीय अवस्थाको विवरण (Statement of Financial Position) ---' : '--- Statement of Financial Position ---', 'NFRS SoFP', ''],
        ...reportData.balanceSheet.nonCurrentAssets.map(a => [a.note, a.label, isNe ? 'गैर-चालू सम्पत्ति (Non-Current Assets)' : 'Non-Current Assets', fmt(a.amount)]),
        ...reportData.balanceSheet.currentAssets.map(a => [a.note, a.label, isNe ? 'चालू सम्पत्ति (Current Assets)' : 'Current Assets', fmt(a.amount)]),
        ['3.T', isNe ? 'कुल सम्पत्ति (Total Assets)' : 'Total Assets', isNe ? 'जम्मा सम्पत्ति' : 'Total Assets', fmt(reportData.balanceSheet.totalAssets)],
        ['', '', '', ''],
        ...reportData.balanceSheet.equity.map(e => [e.note, e.label, isNe ? 'पुँजी तथा इक्विटी (Equity)' : 'Equity', fmt(e.amount)]),
        ...reportData.balanceSheet.currentLiabilities.map(l => [l.note, l.label, isNe ? 'चालू दायित्व (Current Liabilities)' : 'Current Liabilities', fmt(l.amount)]),
        ['5.T', isNe ? 'कुल पुँजी र दायित्व (Total Equity & Liabilities)' : 'Total Equity & Liabilities', isNe ? 'जम्मा पुँजी र दायित्व' : 'Total Equity & Liabilities', fmt(reportData.balanceSheet.netEquity + reportData.balanceSheet.totalLiabilities)],
      ],
      summaryCards: [
        { label: isNe ? 'कुल आम्दानी' : 'Net Revenue', value: formatCurrency(reportData.pnl.revenue, isNe) },
        { label: isNe ? 'खुद नाफा' : 'Net Profit', value: formatCurrency(reportData.pnl.netProfit, isNe) },
        { label: isNe ? 'कुल सम्पत्ति' : 'Total Assets', value: formatCurrency(reportData.balanceSheet.totalAssets, isNe) },
        { label: isNe ? 'नेट वर्थ' : 'Net Worth', value: formatCurrency(reportData.balanceSheet.netEquity, isNe) }
      ],
      fileName: 'NFRS_Audit_Report'
    };
  };

  const handlePrintNfrsReport = () => {
    printOrDownloadReportPdf(buildNfrsExportConfig(false));
  };

  const handleExportExcel = () => {
    exportReportToExcel(buildNfrsExportConfig(true));
  };

  const handleExportCsv = () => {
    const config = buildNfrsExportConfig(true);
    const todayBs = getTodayBsString();
    const csvRows: (string | number)[][] = [
      [company.name || 'KrishiYantra Agri & Machinery Center'],
      [`PAN/VAT No: ${company.panVatNo || '-'} | Address: ${company.address || '-'} | Fiscal Year: ${company.fiscalYear}`],
      [isNe ? 'एनएफआरएस (NFRS) लेखा परीक्षण प्रतिवेदन' : 'NFRS Compliant Audit Report'],
      [`Generated Date (B.S.): ${todayBs}`],
      [],
      config.headers,
      ...config.rows
    ];

    const escapeCsvCell = (cell: string | number) => {
      const str = String(cell ?? '');
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    const csvContent = '\uFEFF' + csvRows.map(row => row.map(escapeCsvCell).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `NFRS_Audit_Report_${todayBs}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Top Header & Export Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 no-print bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            <ShieldCheck className="w-7 h-7 text-emerald-700" />
            <span>{isNe ? 'एनएफआरएस (NFRS) अडिट रिपोर्ट र अडिट ट्रेल' : 'NFRS Audit Report & Audit Trail'}</span>
          </h2>
          <p className="text-slate-500 text-xs sm:text-sm font-medium mt-0.5">
            {isNe
              ? 'नेपाल वित्तीय प्रतिवेदन मान (NFRS) अनुसारको वित्तीय विवरण तथा प्रणाली सुरक्षा अडिट ट्रेल'
              : 'NFRS-compliant financial statements and system security audit trail logs'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md shadow-blue-600/15 transition-all flex items-center gap-2 cursor-pointer active:scale-95 text-xs sm:text-sm"
            title={isNe ? 'NFRS अडिट रिपोर्ट एक्सेल (.xlsx) मा डाउनलोड गर्नुहोस्' : 'Export NFRS Audit Report to Excel (.xlsx)'}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>{isNe ? 'एक्सेल (Excel .xlsx)' : 'Export Excel (.xlsx)'}</span>
          </button>
          <button
            onClick={handleExportCsv}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl shadow-md shadow-slate-800/15 transition-all flex items-center gap-2 cursor-pointer active:scale-95 text-xs sm:text-sm"
            title={isNe ? 'NFRS अडिट रिपोर्ट CSV फाइलमा डाउनलोड गर्नुहोस्' : 'Export NFRS Audit Report to CSV'}
          >
            <Download className="w-4 h-4" />
            <span>{isNe ? 'CSV फाइल (.csv)' : 'Export CSV'}</span>
          </button>
          <button
            onClick={handlePrintNfrsReport}
            className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-lg shadow-emerald-700/20 transition-all flex items-center gap-2 cursor-pointer active:scale-95 text-xs sm:text-sm"
          >
            <Printer className="w-4 h-4" />
            <span>{isNe ? 'NFRS रिपोर्ट प्रिन्ट / PDF' : 'Print NFRS Report / PDF'}</span>
          </button>
        </div>
      </div>

      {/* Sub-Navigation Tabs inside Audit Report */}
      <div className="no-print flex flex-wrap items-center gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
        <button
          type="button"
          onClick={() => setActiveSubTab('BOTH')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'BOTH'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-700 hover:bg-white'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>{isNe ? '१. एकीकृत दृश्य (NFRS रिपोर्ट + अडिट ट्रेल)' : '1. Combined View (NFRS + Audit Trail)'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('NFRS_REPORT')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'NFRS_REPORT'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-700 hover:bg-white'
          }`}
        >
          <Landmark className="w-4 h-4" />
          <span>{isNe ? '२. एनएफआरएस वित्तीय विवरण (NFRS Financial Report)' : '2. NFRS Financial Statements'}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('AUDIT_TRAIL')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'AUDIT_TRAIL'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'text-slate-700 hover:bg-white'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>
            {isNe
              ? `३. अडिट ट्रेल लग (Audit Trail - ${auditLogs.length})`
              : `3. Audit Trail Logs (${auditLogs.length})`}
          </span>
        </button>
      </div>

      {/* SECTION 1: NFRS FINANCIAL STATEMENTS */}
      {(activeSubTab === 'NFRS_REPORT' || activeSubTab === 'BOTH') && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Profit or Loss Statement */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                <h3 className="font-black text-slate-800 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  <span>{isNe ? 'नाफा वा नोक्सानको विवरण (Profit or Loss)' : 'Statement of Profit or Loss'}</span>
                </h3>
                <span className="text-[11px] font-mono font-bold text-slate-500">NFRS Schedule 1 & 2</span>
              </div>
              <div className="p-6 space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-slate-50">
                  <span className="text-sm font-bold text-slate-600">{isNe ? 'कुल आम्दानी (Revenue)' : 'Net Revenue'}</span>
                  <span className="font-mono font-black text-slate-900">{formatCurrency(reportData.pnl.revenue, isNe)}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-50">
                  <span className="text-sm font-bold text-slate-600">{isNe ? 'बिक्री लागत (COGS)' : 'Cost of Goods Sold'}</span>
                  <span className="font-mono font-bold text-rose-600">({formatCurrency(reportData.pnl.cogs, isNe)})</span>
                </div>
                <div className="flex justify-between items-center py-2 bg-emerald-50 px-3 rounded-lg">
                  <span className="text-sm font-black text-emerald-900">{isNe ? 'कुल नाफा (Gross Profit)' : 'Gross Profit'}</span>
                  <span className="font-mono font-black text-emerald-700">{formatCurrency(reportData.pnl.grossProfit, isNe)}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-50">
                  <span className="text-sm font-bold text-slate-600">{isNe ? 'सञ्चालन खर्च (Operating Expenses)' : 'Operating Expenses'}</span>
                  <span className="font-mono font-bold text-rose-600">({formatCurrency(reportData.pnl.totalExpenses, isNe)})</span>
                </div>
                <div className="flex justify-between items-center py-3 bg-slate-900 text-white px-4 rounded-xl shadow-lg">
                  <span className="text-base font-black uppercase tracking-wider">{isNe ? 'खुद नाफा (Net Profit)' : 'Net Profit'}</span>
                  <span className="text-xl font-black font-mono text-emerald-400">{formatCurrency(reportData.pnl.netProfit, isNe)}</span>
                </div>
              </div>
            </div>

            {/* Financial Position (Balance Sheet) */}
            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                <h3 className="font-black text-slate-800 flex items-center gap-2">
                  <Landmark className="w-5 h-5 text-emerald-600" />
                  <span>{isNe ? 'वित्तीय अवस्थाको विवरण (Financial Position)' : 'Statement of Financial Position'}</span>
                </h3>
                <span className="text-[11px] font-mono font-bold text-slate-500">NFRS Schedule 3, 4 & 5</span>
              </div>
              <div className="p-6 space-y-6">
                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">{isNe ? 'सम्पत्ति (Assets)' : 'Assets'}</h4>
                  <div className="space-y-2">
                    {reportData.balanceSheet.currentAssets.map((asset, idx) => (
                      <div key={idx} className="flex justify-between text-xs font-bold py-1.5 border-b border-slate-50">
                        <span className="text-slate-600">
                          <span className="font-mono text-[10px] text-slate-400 mr-2">[{asset.note}]</span>
                          {asset.label}
                        </span>
                        <span className="font-mono text-slate-900">{formatCurrency(asset.amount, isNe)}</span>
                      </div>
                    ))}
                    <div className="flex justify-between items-center py-2 bg-blue-50 px-3 rounded-lg mt-2">
                      <span className="text-xs font-black text-blue-900 uppercase">{isNe ? 'कुल सम्पत्ति' : 'Total Assets'}</span>
                      <span className="font-mono font-black text-blue-700">{formatCurrency(reportData.balanceSheet.totalAssets, isNe)}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">{isNe ? 'पुँजी र दायित्व (Equity & Liabilities)' : 'Equity & Liabilities'}</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-bold py-1.5 border-b border-slate-50">
                      <span className="text-slate-600">{isNe ? 'नेट इक्विटी / पुँजी' : 'Total Equity'}</span>
                      <span className="font-mono text-slate-900">{formatCurrency(reportData.balanceSheet.netEquity, isNe)}</span>
                    </div>
                    {reportData.balanceSheet.currentLiabilities.map((liab, idx) => (
                      <div key={idx} className="flex justify-between text-xs font-bold py-1.5 border-b border-slate-50">
                        <span className="text-slate-600">
                          <span className="font-mono text-[10px] text-slate-400 mr-2">[{liab.note}]</span>
                          {liab.label}
                        </span>
                        <span className="font-mono text-rose-600">{formatCurrency(liab.amount, isNe)}</span>
                      </div>
                    ))}
                    <div className="flex justify-between items-center py-2 bg-slate-100 px-3 rounded-lg mt-2">
                      <span className="text-xs font-black text-slate-900 uppercase">{isNe ? 'कुल दायित्व र पुँजी' : 'Total Equity & Liab'}</span>
                      <span className="font-mono font-black text-slate-800">{formatCurrency(reportData.balanceSheet.netEquity + reportData.balanceSheet.totalLiabilities, isNe)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Audit Insights */}
          <div className="bg-slate-50 rounded-3xl p-6 border border-slate-200">
            <h4 className="text-slate-900 font-black mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-slate-400" />
              <span>{isNe ? 'एनएफआरएस प्रतिवेदन टिपोट (NFRS Audit Notes)' : 'NFRS Audit Insights'}</span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                <div className="text-[10px] font-black text-emerald-600 uppercase mb-2">Revenue Recognition</div>
                <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
                  {isNe
                    ? 'आम्दानी बिक्रीको समयमा नै रेकर्ड गरिएको छ (Accrual Basis)।'
                    : 'Revenue is recognized upon point of sale, compliant with accrual accounting principles.'}
                </p>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                <div className="text-[10px] font-black text-blue-600 uppercase mb-2">Inventory Valuation</div>
                <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
                  {isNe
                    ? 'स्टकको मूल्याङ्कन खरिद लागतको आधारमा गरिएको छ।'
                    : 'Inventories are valued at cost, reflecting physical stock availability in the warehouse.'}
                </p>
              </div>
              <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                <div className="text-[10px] font-black text-amber-600 uppercase mb-2">Compliance</div>
                <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
                  {isNe
                    ? 'यो रिपोर्ट नेपालको प्रचलित लेखा मान र कर नियम अनुसार तयार पारिएको छ।'
                    : 'Prepared in accordance with standard accounting practices followed in Nepal for small enterprises.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: EMBEDDED AUDIT TRAIL INSIDE AUDIT REPORT */}
      {(activeSubTab === 'AUDIT_TRAIL' || activeSubTab === 'BOTH') && (
        <div className="pt-2 border-t border-slate-200">
          <AuditTrailScreen />
        </div>
      )}
    </div>
  );
};

export default AuditReportScreen;
