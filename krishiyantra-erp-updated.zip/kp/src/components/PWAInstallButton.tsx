import React, { useState, useEffect } from 'react';
import { Download, Smartphone, Monitor, Terminal, Copy, Check, X, Database, ExternalLink, QrCode } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useApp } from '../context/AppContext';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallButton: React.FC<{ label?: string }> = ({ label = 'Install' }) => {
  const { language, exportFullBackup } = useApp();
  const isNe = language === 'ne';
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    const standalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsStandalone(standalone);

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsStandalone(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        await deferredPrompt.prompt();
        const choice = await deferredPrompt.userChoice;
        if (choice.outcome === 'accepted') {
          setIsStandalone(true);
          setDeferredPrompt(null);
          return;
        }
      } catch (err) {
        console.error('Install prompt error:', err);
      }
    }
    setShowModal(true);
  };

  const currentUrl = window.location.href;

  const copyAppUrl = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // fallback
    }
  };

  const terminalCommands = `# १. कोड डाउनलोड वा क्लोन गर्नुहोस्
git clone https://github.com/your-username/krishiyantra-erp.git
cd krishiyantra-erp

# २. आवश्यक लाइब्रेरीहरू इन्स्टल गर्नुहोस्
npm install

# ३. सफ्टवेयर बिल्ड गर्नुहोस्
npm run build

# ४. सफ्टवेयर सुरु गर्नुहोस्
npm start

# त्यसपछि ब्राउजरमा http://localhost:3000 खोल्नुहोस्`;

  const copyTerminalCommands = async () => {
    try {
      await navigator.clipboard.writeText(terminalCommands);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2500);
    } catch {
      // Fallback
    }
  };

  return (
    <>
      <button
        onClick={handleInstallClick}
        title={isNe ? 'मोबाइल वा कम्प्युटरमा एप इन्स्टल/डाउनलोड गर्नुहोस्' : 'Install or Download App'}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-2xs"
      >
        <Download className="w-3.5 h-3.5 text-emerald-700" />
        <span>{label}</span>
      </button>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
          <div className="w-full max-w-xl rounded-2xl bg-white p-6 shadow-2xl border border-slate-200 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {isNe ? 'मोबाइल तथा कम्प्युटरमा एप इन्स्टल गर्ने तरिकाहरू' : 'Mobile & Desktop App Installation'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isNe ? 'मोबाइलमा सिधै होम स्क्रिनमा एप राख्ने सरल उपायहरू' : 'Easy ways to add app to mobile home screen & desktop'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-4 space-y-4 text-xs">

              {/* Notice about browser iframe / standalone */}
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 space-y-1.5">
                <p className="font-bold flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-amber-700" />
                  <span>{isNe ? 'मोबाइलमा इन्स्टल नभएमा वा iframe समस्या आएमा:' : 'If mobile installation prompt does not appear:'}</span>
                </p>
                <p className="text-[11px] text-amber-800 leading-relaxed">
                  {isNe
                    ? 'यदि तपाईं AI Studio प्रिभ्यू भित्र हुनुहुन्छ भने मोबाइलको ब्राउजरमा सिधै खोल्न तलको **QR कोड स्क्यान गर्नुहोस्** वा **नयाँ ट्याबमा खोल्नुहोस्** बटन थिच्नुहोस्।'
                    : 'If you are viewing inside a preview frame, scan the QR code below with your phone camera or open in a new tab.'}
                </p>
                <div className="pt-2 flex flex-wrap gap-2">
                  <a
                    href={currentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg shadow-xs transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>{isNe ? 'नयाँ ट्याबमा खोल्नुहोस् (Open in New Tab)' : 'Open in New Tab'}</span>
                  </a>
                  <button
                    onClick={copyAppUrl}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-amber-300 hover:bg-amber-100 text-amber-900 font-bold rounded-lg transition"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? (isNe ? 'लिंक कपी भयो!' : 'Link Copied!') : (isNe ? 'लिंक कपी गर्नुहोस्' : 'Copy Link')}</span>
                  </button>
                </div>
              </div>

              {/* QR Code Section for Mobile */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row items-center gap-4">
                <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-center">
                  <QRCodeSVG value={currentUrl} size={110} level="M" includeMargin={true} />
                </div>
                <div className="space-y-2 text-center sm:text-left">
                  <div className="flex items-center justify-center sm:justify-start gap-1.5 font-bold text-slate-900">
                    <QrCode className="w-4 h-4 text-emerald-700" />
                    <span>{isNe ? 'मोबाइलबाट स्क्यान गर्नुहोस् (Scan with Phone)' : 'Scan with Mobile Camera'}</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    {isNe
                      ? 'तपाईंको मोबाइलको क्यामेरा वा QR स्क्यानर खोलेर यो कोड स्क्यान गर्नुहोस्। त्यसपछि मोबाइलको Chrome वा Safari मा खुलेपछि "Add to Home Screen" थिच्नुहोस्।'
                      : 'Scan this code with your mobile camera. Open the link in mobile Chrome or Safari and tap "Add to Home Screen".'}
                  </p>
                </div>
              </div>

              {/* Option 1: Mobile App steps */}
              <div className="p-3.5 bg-blue-50/50 border border-blue-200 rounded-xl space-y-2">
                <div className="flex items-center gap-2 font-bold text-blue-950">
                  <Smartphone className="w-4 h-4 text-blue-700" />
                  <span>{isNe ? '२. मोबाइल होम स्क्रिनमा राख्ने तरिका (Android / iPhone)' : '2. Add to Mobile Home Screen'}</span>
                </div>
                <div className="text-blue-900 text-[11px] space-y-1.5 leading-relaxed">
                  <p>
                    <strong>🟢 Android (Chrome):</strong>{' '}
                    {isNe ? 'माथि दायाँतिर रहेको ३ वटा थोप्ला (⋮) मेनुमा क्लिक गर्नुहोस् → **"Add to Home screen"** वा **"Install app"** छान्नुहोस्।' : 'Tap Chrome menu (⋮) → **"Add to Home screen"** or **"Install app"**.'}
                  </p>
                  <p>
                    <strong>🍏 iPhone / iPad (Safari):</strong>{' '}
                    {isNe ? 'तलको सेयर (Share ⎋) बटनमा थिच्नुहोस् → तल सार्दै **"Add to Home Screen"** मा क्लिक गर्नुहोस्।' : 'Tap Safari Share button (⎋) → Scroll down and tap **"Add to Home Screen"**.'}
                  </p>
                </div>
              </div>

              {/* Option 2: Desktop App */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-slate-900">
                  <Monitor className="w-4 h-4 text-emerald-700" />
                  <span>{isNe ? '३. कम्प्युटर / ल्यापटपमा एपको रूपमा राख्न' : '3. Desktop Web App (Chrome / Edge)'}</span>
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  {isNe
                    ? 'ब्राउजरको एड्रेस बारमा रहेको Install (💻) आइकन थिच्नुहोस् वा तीनवटा थोप्ला मेनुबाट "Install KrishiYantra ERP" छान्नुहोस्।'
                    : 'Click the install icon in the address bar or browser menu to install as a desktop application.'}
                </p>
              </div>

              {/* Option 3: Instant Data Backup Download */}
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-bold text-emerald-950">
                    <Database className="w-4 h-4 text-emerald-700" />
                    <span>{isNe ? '४. सम्पूर्ण डाटा ब्याकअप JSON डाउनलोड' : '4. Full Data Backup JSON'}</span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    exportFullBackup();
                  }}
                  className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg transition flex items-center justify-center gap-2 shadow-xs cursor-pointer text-xs"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-300" />
                  <span>{isNe ? 'अहिले नै ब्याकअप JSON डाउनलोड गर्नुहोस्' : 'Download Full Backup JSON'}</span>
                </button>
              </div>

              {/* Option 4: Run locally via Terminal */}
              <div className="p-3.5 bg-slate-900 text-slate-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-100">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-emerald-400" />
                    <span>{isNe ? '५. टर्मिनलमा चलाउने कमान्डहरू:' : '5. Run via Terminal:'}</span>
                  </div>
                  <button
                    onClick={copyTerminalCommands}
                    className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] transition cursor-pointer"
                  >
                    {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedCode ? (isNe ? 'कपी भयो!' : 'Copied!') : (isNe ? 'कमान्ड कपी' : 'Copy')}</span>
                  </button>
                </div>
                <pre className="p-2.5 bg-black/60 rounded-lg font-mono text-[11px] text-emerald-400 overflow-x-auto leading-relaxed whitespace-pre-wrap">
                  {terminalCommands}
                </pre>
              </div>

            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="px-5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition cursor-pointer"
              >
                {isNe ? 'बन्द गर्नुहोस्' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
