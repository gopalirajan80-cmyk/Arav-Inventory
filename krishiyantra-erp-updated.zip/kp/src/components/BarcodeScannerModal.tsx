import React, { useEffect, useState, useRef } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { useApp } from '../context/AppContext';
import { Item } from '../types';
import {
  Scan,
  X,
  Camera,
  CheckCircle2,
  AlertCircle,
  Plus,
  Minus,
  Sparkles,
  Zap,
  Volume2,
  VolumeX,
  RefreshCw,
  ShoppingBag,
  ExternalLink,
  Keyboard
} from 'lucide-react';
import { formatCurrency, toNepaliDigits } from '../utils/nepaliCalendar';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onItemScanned: (item: Item, quantity: number) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onItemScanned
}) => {
  const { items, language } = useApp();
  const isNe = language === 'ne';

  const [scannerActive, setScannerActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string>('');
  const [availableCameras, setAvailableCameras] = useState<Array<{ id: string; label: string }>>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  
  // Continuous scanning vs single item modal
  const [continuousMode, setContinuousMode] = useState<boolean>(true);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Scanned item feedback
  const [lastScannedCode, setLastScannedCode] = useState<string>('');
  const [matchedItem, setMatchedItem] = useState<Item | null>(null);
  const [unmatchedCode, setUnmatchedCode] = useState<string>('');
  const [scanQty, setScanQty] = useState<number>(1);
  const [recentlyAddedList, setRecentlyAddedList] = useState<Array<{ item: Item; qty: number; time: string }>>([]);

  // Manual code entry
  const [manualCodeInput, setManualCodeInput] = useState<string>('');
  const [showManualInput, setShowManualInput] = useState<boolean>(false);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerContainerId = 'barcode-scanner-viewport';
  const lastScanTimestamp = useRef<number>(0);
  const lastScannedTextRef = useRef<string>('');

  // Audio Beep generator using Web Audio API
  const playBeepSound = () => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(987.77, ctx.currentTime); // B5 pleasant POS confirmation tone
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.16);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.16);

      // Trigger haptic vibration if supported
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(80);
      }
    } catch {
      // Audio not permitted or supported
    }
  };

  // Match scanned text to inventory item
  const findItemByCode = (code: string): Item | undefined => {
    const cleanCode = code.trim().toLowerCase();
    
    // 1. Direct match on code
    let found = items.find((it) => it.code.toLowerCase() === cleanCode);
    if (found) return found;

    // 2. Direct match on ID
    found = items.find((it) => it.id.toLowerCase() === cleanCode);
    if (found) return found;

    // 3. Match if QR code contains JSON payload e.g. {"code":"KY-PT01"}
    if (cleanCode.startsWith('{') && cleanCode.endsWith('}')) {
      try {
        const parsed = JSON.parse(code);
        const itemCode = (parsed.code || parsed.itemId || parsed.id || '').toString().toLowerCase();
        if (itemCode) {
          found = items.find(
            (it) => it.code.toLowerCase() === itemCode || it.id.toLowerCase() === itemCode
          );
          if (found) return found;
        }
      } catch {
        // Not JSON
      }
    }

    // 4. Substring / Prefix match
    found = items.find(
      (it) =>
        it.code.toLowerCase().includes(cleanCode) ||
        cleanCode.includes(it.code.toLowerCase())
    );

    return found;
  };

  const handleProcessCode = (rawCode: string) => {
    const trimmed = rawCode.trim();
    if (!trimmed) return;

    // Debounce duplicate rapid scans of same code within 1.2s
    const now = Date.now();
    if (trimmed === lastScannedTextRef.current && now - lastScanTimestamp.current < 1200) {
      return;
    }
    lastScanTimestamp.current = now;
    lastScannedTextRef.current = trimmed;

    setLastScannedCode(trimmed);
    const item = findItemByCode(trimmed);

    if (item) {
      setMatchedItem(item);
      setUnmatchedCode('');
      playBeepSound();

      if (continuousMode) {
        // In continuous mode, add 1 immediately to invoice and keep camera running
        onItemScanned(item, 1);
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        setRecentlyAddedList((prev) => [
          { item, qty: 1, time: timeStr },
          ...prev.slice(0, 4)
        ]);
      }
    } else {
      setMatchedItem(null);
      setUnmatchedCode(trimmed);
    }
  };

  // Start Scanner
  const startCamera = async (deviceId?: string) => {
    setCameraError('');
    try {
      if (scannerRef.current) {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
        scannerRef.current.clear();
      }

      const formatsToSupport = [
        Html5QrcodeSupportedFormats.QR_CODE,
        Html5QrcodeSupportedFormats.EAN_13,
        Html5QrcodeSupportedFormats.EAN_8,
        Html5QrcodeSupportedFormats.CODE_128,
        Html5QrcodeSupportedFormats.CODE_39,
        Html5QrcodeSupportedFormats.UPC_A,
        Html5QrcodeSupportedFormats.UPC_E,
        Html5QrcodeSupportedFormats.ITF
      ];

      const html5QrCode = new Html5Qrcode(scannerContainerId, {
        formatsToSupport,
        verbose: false
      });
      scannerRef.current = html5QrCode;

      // Get cameras if not yet queried
      try {
        const cameras = await Html5Qrcode.getCameras();
        if (cameras && cameras.length > 0) {
          setAvailableCameras(cameras.map((c) => ({ id: c.id, label: c.label || `Camera ${c.id.substring(0, 5)}` })));
        }
      } catch {
        // Camera query error
      }

      const cameraConfig = deviceId
        ? { deviceId: { exact: deviceId } }
        : { facingMode: 'environment' };

      await html5QrCode.start(
        cameraConfig,
        {
          fps: 15,
          qrbox: { width: 260, height: 180 },
          aspectRatio: 1.333333
        },
        (decodedText) => {
          handleProcessCode(decodedText);
        },
        () => {
          // Ignore scanning frame errors
        }
      );

      setScannerActive(true);
    } catch (err: unknown) {
      console.error('Camera start error:', err);
      const errMsg = err instanceof Error ? err.message : String(err);
      if (errMsg.includes('NotAllowedError') || errMsg.includes('Permission')) {
        setCameraError(
          isNe
            ? 'क्यामेरा खोल्न अनुमति (Permission) दिइएको छैन। कृपया ब्राउजर सेटिङमा क्यामेरा अनुमति खुला गर्नुहोस्।'
            : 'Camera permission denied. Please allow camera access in browser settings.'
        );
      } else if (errMsg.includes('NotFoundError') || errMsg.includes('DevicesNotFoundError')) {
        setCameraError(
          isNe
            ? 'तपाईंको डिभाइसमा क्यामेरा फेला परेन। कृपया म्यानुअल बारकोड इन्ट्री वा नमुना कोड प्रयोग गर्नुहोस्।'
            : 'No camera hardware found on this device.'
        );
      } else {
        setCameraError(
          isNe
            ? 'क्यामेरा सुरु गर्न सकिएन। तल म्यानुअल कोड इन्ट्री वा नमुना बारकोडहरू प्रयोग गर्न सक्नुहुन्छ।'
            : `Unable to access camera: ${errMsg}`
        );
      }
      setScannerActive(false);
    }
  };

  const stopCamera = async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
        scannerRef.current.clear();
      } catch (e) {
        console.error('Error stopping camera:', e);
      }
      scannerRef.current = null;
    }
    setScannerActive(false);
  };

  useEffect(() => {
    if (isOpen) {
      // Small timeout to ensure DOM container is mounted
      const t = setTimeout(() => {
        startCamera(selectedCameraId || undefined);
      }, 200);
      return () => {
        clearTimeout(t);
        stopCamera();
      };
    } else {
      stopCamera();
    }
  }, [isOpen]);

  const handleSwitchCamera = (newCamId: string) => {
    setSelectedCameraId(newCamId);
    stopCamera().then(() => {
      startCamera(newCamId);
    });
  };

  const handleManualAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCodeInput.trim()) return;
    handleProcessCode(manualCodeInput);
    setManualCodeInput('');
  };

  const handleAddSingleItem = () => {
    if (!matchedItem || scanQty <= 0) return;
    onItemScanned(matchedItem, scanQty);
    playBeepSound();
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setRecentlyAddedList((prev) => [
      { item: matchedItem, qty: scanQty, time: timeStr },
      ...prev.slice(0, 4)
    ]);
    setMatchedItem(null);
    setScanQty(1);
    lastScannedTextRef.current = '';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-3 sm:p-4 overflow-y-auto backdrop-blur-xs">
      <div className="w-full max-w-xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden flex flex-col my-auto max-h-[95vh]">
        
        {/* Header */}
        <div className="px-5 py-3.5 bg-gradient-to-r from-slate-900 to-slate-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-400/30">
              <Scan className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold flex items-center gap-2">
                <span>{isNe ? 'क्यामेरा बारकोड तथा QR स्क्यानर' : 'Live Barcode & QR Scanner'}</span>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  POS Active
                </span>
              </h3>
              <p className="text-[11px] text-slate-300">
                {isNe ? 'सामानको बारकोड वा QR देखाउनासाथ बिलमा स्वतः थपिन्छ' : 'Scan item label to instantly add to invoice'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Audio Toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-1.5 rounded-lg border text-xs transition cursor-pointer ${
                soundEnabled
                  ? 'bg-emerald-800/60 border-emerald-600 text-emerald-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
              title={soundEnabled ? 'Beep sound ON' : 'Beep sound OFF'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Close Button */}
            <button
              onClick={() => {
                stopCamera();
                onClose();
              }}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto space-y-3.5 text-xs">
          
          {/* Mode Selector & Camera Controls */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl">
            {/* Continuous vs Single Scan Mode */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-slate-700">
                {isNe ? 'स्क्यान मोड:' : 'Scan Mode:'}
              </span>
              <button
                type="button"
                onClick={() => setContinuousMode(true)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                  continuousMode
                    ? 'bg-emerald-700 text-white shadow-2xs'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                ⚡ {isNe ? 'निरन्तर स्क्यान (Auto +1)' : 'Continuous (Auto +1)'}
              </button>
              <button
                type="button"
                onClick={() => setContinuousMode(false)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
                  !continuousMode
                    ? 'bg-slate-800 text-white shadow-2xs'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {isNe ? 'एक-एक सामान (Single)' : 'Single Item'}
              </button>
            </div>

            {/* Switch Camera if multiple cameras detected */}
            {availableCameras.length > 1 && (
              <div className="flex items-center gap-1 text-[11px]">
                <Camera className="w-3.5 h-3.5 text-slate-500" />
                <select
                  value={selectedCameraId}
                  onChange={(e) => handleSwitchCamera(e.target.value)}
                  className="px-2 py-0.5 border border-slate-200 rounded bg-white text-slate-800 text-[11px]"
                >
                  {availableCameras.map((cam) => (
                    <option key={cam.id} value={cam.id}>
                      {cam.label}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Camera Viewfinder Box */}
          <div className="relative rounded-2xl overflow-hidden bg-slate-950 border-2 border-slate-800 shadow-inner min-h-[220px] flex items-center justify-center">
            
            {/* The HTML5 QR Code Video Anchor */}
            <div id={scannerContainerId} className="w-full h-full min-h-[220px] max-h-[300px]" />

            {/* Custom High-Tech Overlay when camera is active */}
            {scannerActive && !cameraError && (
              <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center p-4">
                
                {/* Target Frame Brackets */}
                <div className="relative w-64 h-40 border-2 border-emerald-400/80 rounded-xl shadow-lg flex items-center justify-center">
                  {/* Glowing Laser Scan Line */}
                  <div className="absolute left-1 right-1 h-0.5 bg-gradient-to-r from-emerald-500 via-emerald-300 to-emerald-500 shadow-[0_0_8px_#10b981] animate-pulse" />
                  
                  {/* Corner accents */}
                  <div className="absolute -top-1 -left-1 w-4 h-4 border-t-4 border-l-4 border-emerald-400 rounded-tl-sm" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 border-t-4 border-r-4 border-emerald-400 rounded-tr-sm" />
                  <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-4 border-l-4 border-emerald-400 rounded-bl-sm" />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-4 border-r-4 border-emerald-400 rounded-br-sm" />

                  <span className="text-[10px] text-emerald-200/90 font-mono tracking-wider uppercase bg-black/60 px-2 py-0.5 rounded-full backdrop-blur-xs">
                    {isNe ? 'बारकोड / QR यहाँ देखाउनुहोस्' : 'Align Barcode / QR here'}
                  </span>
                </div>
              </div>
            )}

            {/* Camera Error or Fallback Message */}
            {cameraError && (
              <div className="absolute inset-0 bg-slate-900/95 p-6 flex flex-col items-center justify-center text-center space-y-3">
                <AlertCircle className="w-8 h-8 text-amber-400" />
                <div className="space-y-1">
                  <p className="text-white font-bold text-xs">{isNe ? 'क्यामेरा सूचना' : 'Camera Notice'}</p>
                  <p className="text-slate-300 text-[11px] max-w-sm leading-relaxed">{cameraError}</p>
                </div>
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => startCamera(selectedCameraId || undefined)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>{isNe ? 'पुनः प्रयास गर्नुहोस्' : 'Retry Camera'}</span>
                  </button>
                  <button
                    onClick={() => setShowManualInput(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    <Keyboard className="w-3.5 h-3.5" />
                    <span>{isNe ? 'म्यानुअल कोड हान्नुहोस्' : 'Manual Input'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Scanned Result Banner / Feedback */}
          {matchedItem && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl space-y-2 animate-in fade-in">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-emerald-600 text-white rounded-lg">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                      {isNe ? matchedItem.nameNe || matchedItem.nameEn : matchedItem.nameEn}
                    </h4>
                    <span className="font-mono text-[10px] text-emerald-800 font-semibold">
                      कोड: {matchedItem.code} · एकाइ: {matchedItem.unit}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-mono font-bold text-emerald-900">
                    रु. {matchedItem.sellingPrice.toLocaleString('en-IN')}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono">
                    स्टक: {matchedItem.currentStock} {matchedItem.unit}
                  </div>
                </div>
              </div>

              {/* In Single Item Mode, offer Quantity Adjust and Explicit Add Button */}
              {!continuousMode && (
                <div className="pt-2 border-t border-emerald-200/80 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-1 bg-white px-2 py-1 border border-emerald-300 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setScanQty(Math.max(1, scanQty - 1))}
                      className="p-1 hover:bg-slate-100 rounded text-slate-700 cursor-pointer"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="font-mono font-bold text-xs px-2 text-slate-900">
                      {scanQty} {matchedItem.unit}
                    </span>
                    <button
                      type="button"
                      onClick={() => setScanQty(Math.min(matchedItem.currentStock || 999, scanQty + 1))}
                      className="p-1 hover:bg-slate-100 rounded text-slate-700 cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddSingleItem}
                    className="flex-1 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer text-xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{isNe ? 'बिलमा थप्नुहोस् (Add to Bill)' : 'Add to Invoice'}</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Unmatched Code Warning */}
          {unmatchedCode && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-xs text-rose-900">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <div>
                  <span className="font-bold">
                    {isNe ? 'सामान फेला परेन' : 'Item Not Found'}:
                  </span>{' '}
                  <span className="font-mono bg-white px-1.5 py-0.5 rounded border border-rose-200 font-semibold">
                    {unmatchedCode}
                  </span>
                </div>
              </div>
              <span className="text-[10px] text-slate-500">
                {isNe ? 'इन्भेन्टरी कोडसँग मेल खाएन' : 'Does not match any item code'}
              </span>
            </div>
          )}

          {/* Continuous Scan History Stream (Recent additions) */}
          {continuousMode && recentlyAddedList.length > 0 && (
            <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 pb-1 border-b border-slate-200">
                <span className="flex items-center gap-1">
                  <ShoppingBag className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isNe ? 'भर्खरै बिलमा थपिएका सामानहरू:' : 'Recently Scanned into Bill:'}</span>
                </span>
                <span className="font-mono text-emerald-700 font-semibold">
                  {toNepaliDigits(recentlyAddedList.length)} {isNe ? 'सामान' : 'items'}
                </span>
              </div>
              
              <div className="space-y-1 max-h-24 overflow-y-auto">
                {recentlyAddedList.map((entry, idx) => (
                  <div
                    key={`${entry.item.id}-${idx}`}
                    className="flex items-center justify-between bg-white px-2 py-1 rounded border border-slate-200/70 text-[11px]"
                  >
                    <div className="truncate max-w-[240px]">
                      <span className="font-semibold text-slate-800">
                        {isNe ? entry.item.nameNe || entry.item.nameEn : entry.item.nameEn}
                      </span>
                      <span className="text-slate-400 font-mono text-[10px] ml-1">
                        ({entry.item.code})
                      </span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 font-mono">
                      <span className="text-emerald-700 font-bold">+{entry.qty} {entry.item.unit}</span>
                      <span className="text-[10px] text-slate-400">{entry.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Demo Test Buttons (For testing on laptop/desktop without physical labels) */}
          <div className="p-2.5 bg-amber-50/70 border border-amber-200/80 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-amber-950 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-600" />
                <span>{isNe ? 'द्रुत परीक्षण नमुना बारकोडहरू (Click to Test Scan):' : 'Demo Barcode Simulator:'}</span>
              </span>
              <span className="text-[10px] text-amber-700 font-mono">१-क्लिक सिमुलेटर</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {items.slice(0, 4).map((it) => (
                <button
                  key={it.id}
                  type="button"
                  onClick={() => handleProcessCode(it.code)}
                  className="px-2 py-1.5 bg-white hover:bg-amber-100/70 border border-amber-300 rounded text-left transition cursor-pointer group"
                >
                  <div className="font-mono text-[10px] font-bold text-amber-900 group-hover:text-amber-950 truncate">
                    {it.code}
                  </div>
                  <div className="text-[10px] text-slate-600 truncate">
                    {isNe ? it.nameNe || it.nameEn : it.nameEn}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Manual Input Toggle Section */}
          <div className="pt-1">
            {!showManualInput ? (
              <button
                type="button"
                onClick={() => setShowManualInput(true)}
                className="text-[11px] text-slate-600 hover:text-emerald-700 flex items-center gap-1 font-semibold cursor-pointer"
              >
                <Keyboard className="w-3.5 h-3.5" />
                <span>{isNe ? 'बारकोड नम्बर टाइप गरेर खोज्नुहोस् (Manual Code)' : 'Type Barcode Number Manually'}</span>
              </button>
            ) : (
              <form onSubmit={handleManualAdd} className="flex gap-2 items-center">
                <input
                  type="text"
                  placeholder={isNe ? 'बारकोड / कोड हान्नुहोस् (जस्तै: KY-PT01)...' : 'Enter barcode e.g. KY-PT01...'}
                  value={manualCodeInput}
                  onChange={(e) => setManualCodeInput(e.target.value)}
                  className="flex-1 px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  autoFocus
                />
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg text-xs cursor-pointer shadow-2xs"
                >
                  {isNe ? 'स्क्यान' : 'Scan'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowManualInput(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>

        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="text-[11px] text-slate-500">
            {isNe ? 'स्क्यान सकिएपछि सिधै बन्द गर्नुहोस्।' : 'Close when finished scanning.'}
          </div>

          <button
            type="button"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-xs"
          >
            {isNe ? 'सकियो (Done)' : 'Done'}
          </button>
        </div>

      </div>
    </div>
  );
};
