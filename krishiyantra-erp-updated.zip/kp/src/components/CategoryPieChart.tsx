import React, { useState } from 'react';
import * as d3 from 'd3';
import { Party, CustomerCategory } from '../types';
import { formatCurrency, toNepaliDigits } from '../utils/nepaliCalendar';
import { PieChart, Info, Building2, Store, Landmark, HelpCircle } from 'lucide-react';

interface CategoryPieChartProps {
  parties: Party[];
  isNe?: boolean;
}

export interface CategorySummary {
  categoryKey: CustomerCategory;
  labelNe: string;
  labelEn: string;
  color: string;
  icon: any;
  totalDue: number;
  customerCount: number;
}

export const CATEGORY_CONFIG: Record<CustomerCategory, { labelNe: string; labelEn: string; color: string; icon: any }> = {
  RETAIL: {
    labelNe: 'खुद्रा ग्राहक (Retail)',
    labelEn: 'Retail Customers',
    color: '#10b981', // emerald-500
    icon: Store
  },
  WHOLESALE: {
    labelNe: 'थोक ग्राहक (Wholesale)',
    labelEn: 'Wholesale Customers',
    color: '#3b82f6', // blue-500
    icon: Building2
  },
  GOVERNMENT: {
    labelNe: 'सरकारी तथा संस्थागत (Government)',
    labelEn: 'Government & Institutional',
    color: '#8b5cf6', // purple-500
    icon: Landmark
  },
  OTHER: {
    labelNe: 'अन्य ग्राहक (Other)',
    labelEn: 'Other Customers',
    color: '#f59e0b', // amber-500
    icon: HelpCircle
  }
};

export const CategoryPieChart: React.FC<CategoryPieChartProps> = ({ parties, isNe = true }) => {
  const [hoveredSlice, setHoveredSlice] = useState<CategorySummary | null>(null);

  // Filter customers only with positive current balance (receivables)
  const customers = parties.filter((p) => {
    const isCust = (p.partyType || p.type) === 'CUSTOMER' || !(p.partyType || p.type);
    const bal = p.currentBalance ?? p.openingBalance;
    return isCust && bal > 0;
  });

  // Calculate totals per category
  const categoryDataMap: Record<CustomerCategory, { totalDue: number; count: number }> = {
    RETAIL: { totalDue: 0, count: 0 },
    WHOLESALE: { totalDue: 0, count: 0 },
    GOVERNMENT: { totalDue: 0, count: 0 },
    OTHER: { totalDue: 0, count: 0 }
  };

  customers.forEach((c) => {
    const cat = c.customerCategory || 'OTHER';
    const bal = c.currentBalance ?? c.openingBalance;
    categoryDataMap[cat].totalDue += bal;
    categoryDataMap[cat].count += 1;
  });

  const totalOutstandingAll = Object.values(categoryDataMap).reduce((sum, item) => sum + item.totalDue, 0);

  const data: CategorySummary[] = (Object.keys(CATEGORY_CONFIG) as CustomerCategory[]).map((key) => ({
    categoryKey: key,
    labelNe: CATEGORY_CONFIG[key].labelNe,
    labelEn: CATEGORY_CONFIG[key].labelEn,
    color: CATEGORY_CONFIG[key].color,
    icon: CATEGORY_CONFIG[key].icon,
    totalDue: categoryDataMap[key].totalDue,
    customerCount: categoryDataMap[key].count
  }));

  // Filter out slices with zero balance for cleaner chart
  const activeSlices = data.filter((d) => d.totalDue > 0);

  // SVG Chart Dimensions
  const width = 280;
  const height = 280;
  const radius = Math.min(width, height) / 2 - 16;

  // D3 Pie Generator
  const pieGenerator = d3
    .pie<CategorySummary>()
    .value((d) => d.totalDue)
    .sort(null);

  const arcData = pieGenerator(activeSlices);

  // D3 Arc Generator
  const arcGenerator = d3
    .arc<d3.PieArcDatum<CategorySummary>>()
    .innerRadius(60) // Donut style
    .outerRadius(radius)
    .cornerRadius(6)
    .padAngle(0.03);

  // Expanded Arc Generator for Hover effect
  const hoverArcGenerator = d3
    .arc<d3.PieArcDatum<CategorySummary>>()
    .innerRadius(55)
    .outerRadius(radius + 8)
    .cornerRadius(6)
    .padAngle(0.03);

  return (
    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-emerald-100 rounded-xl text-emerald-800">
            <PieChart className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              {isNe ? 'वर्ग अनुसार बक्यौता विश्लेषण (Category D3 Pie Chart)' : 'Outstanding Balances by Category'}
            </h2>
            <p className="text-[11px] text-slate-500">
              {isNe ? 'खुद्रा, थोक, सरकारी तथा अन्य ग्राहकहरूको बक्यौता रकम' : 'D3 Visualization of receivables across customer segments'}
            </p>
          </div>
        </div>

        <div className="text-right font-mono text-xs font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-xl">
          {isNe ? 'कुल बक्यौता: ' : 'Total: '} {formatCurrency(totalOutstandingAll, isNe)}
        </div>
      </div>

      {totalOutstandingAll === 0 ? (
        <div className="py-12 text-center text-slate-400 space-y-2">
          <Info className="w-8 h-8 text-slate-300 mx-auto" />
          <p className="text-xs font-medium">
            {isNe ? 'कुनै पनि वर्गमा ग्राहकको बक्यौता रकम छैन।' : 'No outstanding balances recorded across customer categories.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          
          {/* D3 SVG Pie Chart Render */}
          <div className="md:col-span-5 flex flex-col items-center justify-center relative">
            <svg width={width} height={height} className="overflow-visible cursor-pointer">
              <g transform={`translate(${width / 2}, ${height / 2})`}>
                {arcData.map((slice, index) => {
                  const isHovered = hoveredSlice?.categoryKey === slice.data.categoryKey;
                  const path = isHovered ? hoverArcGenerator(slice) : arcGenerator(slice);
                  const percentage = ((slice.data.totalDue / totalOutstandingAll) * 100).toFixed(1);

                  return (
                    <g
                      key={index}
                      onMouseEnter={() => setHoveredSlice(slice.data)}
                      onMouseLeave={() => setHoveredSlice(null)}
                      className="transition-all duration-200"
                    >
                      <path
                        d={path || ''}
                        fill={slice.data.color}
                        opacity={hoveredSlice && !isHovered ? 0.45 : 1}
                        stroke="#ffffff"
                        strokeWidth={2}
                        className="transition-all duration-300 hover:filter hover:drop-shadow-md"
                      />
                    </g>
                  );
                })}
              </g>
            </svg>

            {/* Center Donut Label */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                {hoveredSlice ? (isNe ? hoveredSlice.labelNe.split(' ')[0] : hoveredSlice.categoryKey) : (isNe ? 'कुल असुली' : 'Receivables')}
              </span>
              <span className="text-sm font-black font-mono text-slate-900">
                {hoveredSlice
                  ? formatCurrency(hoveredSlice.totalDue, isNe)
                  : formatCurrency(totalOutstandingAll, isNe)}
              </span>
              <span className="text-[10px] font-mono text-emerald-700 font-bold">
                {hoveredSlice
                  ? `${((hoveredSlice.totalDue / totalOutstandingAll) * 100).toFixed(1)}%`
                  : `${toNepaliDigits(customers.length)} ${isNe ? 'ग्राहक' : 'customers'}`}
              </span>
            </div>
          </div>

          {/* Detailed Category Legend Grid */}
          <div className="md:col-span-7 space-y-2.5">
            {data.map((cat) => {
              const IconComp = cat.icon;
              const percentage = totalOutstandingAll > 0 ? ((cat.totalDue / totalOutstandingAll) * 100).toFixed(1) : '0';
              const isHovered = hoveredSlice?.categoryKey === cat.categoryKey;

              return (
                <div
                  key={cat.categoryKey}
                  onMouseEnter={() => setHoveredSlice(cat)}
                  onMouseLeave={() => setHoveredSlice(null)}
                  className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                    isHovered
                      ? 'border-slate-400 bg-slate-50 shadow-xs ring-1 ring-slate-300'
                      : 'border-slate-100 hover:border-slate-200 bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-3.5 h-3.5 rounded-full shrink-0 shadow-xs"
                      style={{ backgroundColor: cat.color }}
                    />
                    <div className="flex items-center gap-2">
                      <IconComp className="w-4 h-4 text-slate-600 shrink-0" />
                      <div>
                        <div className="text-xs font-bold text-slate-900">
                          {isNe ? cat.labelNe : cat.labelEn}
                        </div>
                        <div className="text-[10px] text-slate-500 font-medium">
                          {toNepaliDigits(cat.customerCount)} {isNe ? 'जना ग्राहक' : 'parties'} · {toNepaliDigits(percentage)}%
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="text-right font-mono">
                    <div className="text-xs font-bold text-slate-900">
                      {formatCurrency(cat.totalDue, isNe)}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {cat.totalDue > 0 ? `${percentage}%` : (isNe ? 'शून्य' : 'Zero')}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      )}
    </div>
  );
};
