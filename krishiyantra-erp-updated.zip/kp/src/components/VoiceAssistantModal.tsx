import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Mic,
  MicOff,
  Volume2,
  X,
  Sparkles,
  Command,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Play,
  RotateCcw
} from 'lucide-react';

interface VoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onItemSpokenToAdd?: (itemName: string, quantity?: number) => void;
}

export const VoiceAssistantModal: React.FC<VoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  onItemSpokenToAdd
}) => {
  const {
    activeTab,
    setActiveTab,
    items,
    parties,
    language,
    employees
  } = useApp();

  const isNe = language === 'ne';

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [lastActionFeedback, setLastActionFeedback] = useState<string | null>(null);
  const [recognitionError, setRecognitionError] = useState<string | null>(null);
  const [selectedLang, setSelectedLang] = useState<'ne-NP' | 'en-US'>('ne-NP');
  const [isSupported, setIsSupported] = useState(true);

  const recognitionRef = useRef<any>(null);

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSupported(false);
      setRecognitionError(
        isNe
          ? 'तपाईंको ब्राउजरमा आवाज पहिचान (Web Speech API) उपलब्ध छैन। कृपया Google Chrome वा Edge प्रयोग गर्नुहोस्।'
          : 'Speech recognition is not supported in this browser. Please use Chrome or Edge.'
      );
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = selectedLang;

    recognition.onstart = () => {
      setIsListening(true);
      setRecognitionError(null);
    };

    recognition.onresult = (event: any) => {
      let currentTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const text = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          handleExecuteVoiceCommand(text);
        } else {
          currentTranscript += text;
        }
      }
      setTranscript(currentTranscript);
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      if (event.error === 'not-allowed') {
        setRecognitionError(
          isNe
            ? 'माइक्रोफोन अनुमति अस्वीकृत भयो! कृपया ब्राउजर सेटिङमा गई माइक्रोफोनको अनुमति दिनुहोस्।'
            : 'Microphone permission denied! Please allow microphone access.'
        );
      } else if (event.error === 'no-speech') {
        // silent
      } else {
        setRecognitionError(`आवाज त्रुटि: ${event.error}`);
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      try {
        recognition.stop();
      } catch {
        // ignore
      }
    };
  }, [selectedLang, isNe]);

  // Start / Stop listening when modal opens / closes
  useEffect(() => {
    if (isOpen && isSupported && recognitionRef.current) {
      startListening();
    } else {
      stopListening();
    }
  }, [isOpen, isSupported]);

  const startListening = () => {
    if (!recognitionRef.current) return;
    try {
      setRecognitionError(null);
      recognitionRef.current.lang = selectedLang;
      recognitionRef.current.start();
      setIsListening(true);
    } catch {
      // recognition might already be running
    }
  };

  const stopListening = () => {
    if (!recognitionRef.current) return;
    try {
      recognitionRef.current.stop();
      setIsListening(false);
    } catch {
      // ignore
    }
  };

  const speakFeedback = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = selectedLang === 'ne-NP' ? 'ne-NP' : 'en-US';
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Smart Voice Command Parser
  const handleExecuteVoiceCommand = (rawText: string) => {
    const text = rawText.trim().toLowerCase();
    setTranscript(rawText);

    // 1. Navigation Commands
    if (
      text.includes('बिल') ||
      text.includes('काउन्टर') ||
      text.includes('नयाँ बिल') ||
      text.includes('billing') ||
      text.includes('bill')
    ) {
      setActiveTab('billing');
      const msg = isNe ? 'बिलिङ स्क्रिन खोलियो !' : 'Opened Billing Screen!';
      setLastActionFeedback(msg);
      speakFeedback(msg);
      return;
    }

    if (
      text.includes('स्टक') ||
      text.includes('इन्भेन्टरी') ||
      text.includes('सामान') ||
      text.includes('inventory') ||
      text.includes('stock')
    ) {
      setActiveTab('inventory');
      const msg = isNe ? 'इन्भेन्टरी तथा स्टक स्क्रिन खोलियो !' : 'Opened Inventory!';
      setLastActionFeedback(msg);
      speakFeedback(msg);
      return;
    }

    if (
      text.includes('हाजिरी') ||
      text.includes('कर्मचारी') ||
      text.includes('तलब') ||
      text.includes('attendance') ||
      text.includes('staff')
    ) {
      setActiveTab('attendance');
      const msg = isNe ? 'कर्मचारी तथा हाजिरी स्क्रिन खोलियो !' : 'Opened Attendance Screen!';
      setLastActionFeedback(msg);
      speakFeedback(msg);
      return;
    }

    if (
      text.includes('खाता') ||
      text.includes('लेजर') ||
      text.includes('बाँकी') ||
      text.includes('ledger')
    ) {
      setActiveTab('ledger');
      const msg = isNe ? 'पार्टी लेजर खाता खोलियो !' : 'Opened Ledger!';
      setLastActionFeedback(msg);
      speakFeedback(msg);
      return;
    }

    if (
      text.includes('असुली') ||
      text.includes('भौचर') ||
      text.includes('voucher') ||
      text.includes('collection')
    ) {
      setActiveTab('vouchers');
      const msg = isNe ? 'रकम असुली तथा भौचर स्क्रिन खोलियो !' : 'Opened Vouchers!';
      setLastActionFeedback(msg);
      speakFeedback(msg);
      return;
    }

    if (
      text.includes('ड्यासबोर्ड') ||
      text.includes('गृहपृष्ठ') ||
      text.includes('dashboard') ||
      text.includes('home')
    ) {
      setActiveTab('dashboard');
      const msg = isNe ? 'ड्यासबोर्ड खोलियो !' : 'Opened Dashboard!';
      setLastActionFeedback(msg);
      speakFeedback(msg);
      return;
    }

    if (
      text.includes('सेटिङ') ||
      text.includes('settings') ||
      text.includes('setting')
    ) {
      setActiveTab('settings');
      const msg = isNe ? 'सेटिङ स्क्रिन खोलियो !' : 'Opened Settings!';
      setLastActionFeedback(msg);
      speakFeedback(msg);
      return;
    }

    if (
      text.includes('उत्पादन') ||
      text.includes('म्यानुफ्याक्चरिङ') ||
      text.includes('manufacturing') ||
      text.includes('factory')
    ) {
      setActiveTab('manufacturing');
      const msg = isNe ? 'म्यानुफ्याक्चरिङ तथा उत्पादन स्क्रिन खोलियो !' : 'Opened Manufacturing!';
      setLastActionFeedback(msg);
      speakFeedback(msg);
      return;
    }

    if (
      text.includes('भ्याट खाता') ||
      text.includes('अनुसूची') ||
      text.includes('vat')
    ) {
      setActiveTab('vat_books');
      const msg = isNe ? 'भ्याट खाता खोलियो !' : 'Opened VAT Books!';
      setLastActionFeedback(msg);
      speakFeedback(msg);
      return;
    }

    // 2. Billing Item Search & Add Command: "थप्नुहोस्", "add", "सामान"
    // e.g. "युरिया मल", "टिलर", "पाइप", "स्प्रेयर"
    const matchedItem = items.find((it) => {
      const nEn = it.nameEn.toLowerCase();
      const nNe = (it.nameNe || '').toLowerCase();
      const code = it.code.toLowerCase();
      return (
        text.includes(nEn) ||
        text.includes(nNe) ||
        text.includes(code) ||
        (nNe && text.split(' ').some((word) => word.length > 2 && nNe.includes(word))) ||
        (nEn && text.split(' ').some((word) => word.length > 3 && nEn.includes(word)))
      );
    });

    if (matchedItem) {
      // Extract quantity if spoken (e.g. "५ पिस", "2", "२", "१०")
      let qty = 1;
      const numMatch = text.match(/\d+/);
      if (numMatch) {
        qty = parseInt(numMatch[0]);
      } else {
        const nepaliDigits: { [k: string]: number } = {
          '१': 1, '२': 2, '३': 3, '४': 4, '५': 5,
          '६': 6, '७': 7, '८': 8, '९': 9, '१०': 10
        };
        for (const [d, v] of Object.entries(nepaliDigits)) {
          if (text.includes(d)) {
            qty = v;
            break;
          }
        }
      }

      if (onItemSpokenToAdd) {
        onItemSpokenToAdd(matchedItem.nameNe || matchedItem.nameEn, qty);
        setActiveTab('billing');
        const msg = isNe
          ? `सामान "${matchedItem.nameNe || matchedItem.nameEn}" (${qty} ${matchedItem.unit}) बिलमा थपियो !`
          : `Added "${matchedItem.nameEn}" (${qty} ${matchedItem.unit}) to bill!`;
        setLastActionFeedback(msg);
        speakFeedback(msg);
        return;
      }
    }

    // Unrecognized command
    setLastActionFeedback(
      isNe
        ? `आवाज सुनियो: "${rawText}"। (कमाण्ड बुझ्न सकिएन, तलका उदाहरणहरू हेर्नुहोस्)`
        : `Heard: "${rawText}" (Command not recognized)`
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-xl">
              <Sparkles className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-sm font-bold leading-tight">
                {isNe ? 'आवाज कमाण्ड तथा भ्वाइस बिलिङ (Voice Control)' : 'Voice Command & Billing'}
              </h2>
              <p className="text-[11px] text-emerald-200">
                {isNe ? 'बोलेरै बिल काट्नुहोस् वा कुनै पनि मेनु खोल्नुहोस्' : 'Speak to navigate or bill items'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Selector for Speech */}
            <select
              value={selectedLang}
              onChange={(e) => setSelectedLang(e.target.value as 'ne-NP' | 'en-US')}
              className="px-2 py-1 bg-white/20 hover:bg-white/30 border border-white/30 rounded-lg text-xs font-semibold text-white focus:outline-none cursor-pointer"
            >
              <option value="ne-NP" className="text-slate-900">🇳🇵 नेपाली (Nepali)</option>
              <option value="en-US" className="text-slate-900">🇺🇸 English</option>
            </select>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-xs">
          
          {/* Main Visual Microphone Button & Waveform */}
          <div className="flex flex-col items-center justify-center p-6 bg-slate-50 rounded-2xl border border-slate-200 text-center space-y-3">
            <div className="relative">
              {isListening && (
                <>
                  <span className="absolute -inset-3 rounded-full bg-emerald-500/20 animate-ping" />
                  <span className="absolute -inset-1.5 rounded-full bg-emerald-500/40 animate-pulse" />
                </>
              )}
              <button
                type="button"
                onClick={() => {
                  if (isListening) {
                    stopListening();
                  } else {
                    startListening();
                  }
                }}
                className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all shadow-md cursor-pointer ${
                  isListening
                    ? 'bg-rose-600 text-white hover:bg-rose-700 ring-4 ring-rose-200'
                    : 'bg-emerald-700 text-white hover:bg-emerald-800 ring-4 ring-emerald-100'
                }`}
              >
                {isListening ? (
                  <Mic className="w-9 h-9 animate-pulse" />
                ) : (
                  <MicOff className="w-9 h-9 text-white/80" />
                )}
              </button>
            </div>

            <div>
              <span className="text-sm font-bold text-slate-800 block">
                {isListening
                  ? (isNe ? '🎙️ सुन्दैछ... बोल्नुहोस् (Listening...)' : '🎙️ Listening... Speak now')
                  : (isNe ? 'माइक्रोफोन बन्द छ। बोल्न सुरु गर्न थिच्नुहोस्।' : 'Microphone stopped. Click to start.')}
              </span>
              <p className="text-[11px] text-slate-500">
                {isListening
                  ? (isNe ? 'जस्तै: "नयाँ बिल", "स्टक हेर्ने", "युरिया मल २ बोरा"' : 'Try: "billing", "inventory", "attendance"')
                  : (isNe ? 'माथिको माइक्रोफोन बटन थिचेर बोल्नुहोस्' : 'Click the microphone button to activate')}
              </p>
            </div>
          </div>

          {/* Live Transcript Display */}
          <div className="p-3.5 bg-white border border-slate-200 rounded-xl space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              {isNe ? 'तपाईंले बोलेको शब्द (Spoken Transcript):' : 'Spoken Transcript:'}
            </span>
            <div className="min-h-[38px] text-sm font-semibold text-slate-900 font-mono flex items-center">
              {transcript ? (
                <span className="text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                  "{transcript}"
                </span>
              ) : (
                <span className="text-slate-400 italic">
                  {isNe ? 'अझै केही बोलिएको छैन...' : 'Waiting for voice input...'}
                </span>
              )}
            </div>
          </div>

          {/* Action Feedback Banner */}
          {lastActionFeedback && (
            <div className="p-3 bg-teal-50 border border-teal-200 rounded-xl text-teal-950 font-medium flex items-start gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
              <span>{lastActionFeedback}</span>
            </div>
          )}

          {/* Error Notice */}
          {recognitionError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 font-medium flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{recognitionError}</span>
            </div>
          )}

          {/* Example Voice Commands list */}
          <div className="space-y-2">
            <span className="font-bold text-slate-700 flex items-center gap-1.5 text-[11px]">
              <HelpCircle className="w-3.5 h-3.5 text-emerald-700" />
              <span>{isNe ? 'तपाईंले बोल्न मिल्ने कमाण्डका उदाहरणहरू:' : 'Available Voice Commands:'}</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <button
                type="button"
                onClick={() => handleExecuteVoiceCommand('बिल')}
                className="p-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition cursor-pointer flex items-center justify-between"
              >
                <div>
                  <span className="font-bold text-slate-800 block">"नयाँ बिल" / "बिल काट्ने"</span>
                  <span className="text-[10px] text-slate-400">बिलिङ स्क्रिन खोल्छ</span>
                </div>
                <Play className="w-3.5 h-3.5 text-emerald-700" />
              </button>

              <button
                type="button"
                onClick={() => handleExecuteVoiceCommand('स्टक')}
                className="p-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition cursor-pointer flex items-center justify-between"
              >
                <div>
                  <span className="font-bold text-slate-800 block">"स्टक हेर्ने" / "सामान"</span>
                  <span className="text-[10px] text-slate-400">इन्भेन्टरी खोल्छ</span>
                </div>
                <Play className="w-3.5 h-3.5 text-emerald-700" />
              </button>

              <button
                type="button"
                onClick={() => handleExecuteVoiceCommand('हाजिरी')}
                className="p-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition cursor-pointer flex items-center justify-between"
              >
                <div>
                  <span className="font-bold text-slate-800 block">"कर्मचारी हाजिरी"</span>
                  <span className="text-[10px] text-slate-400">हाजिरी स्क्रिन खोल्छ</span>
                </div>
                <Play className="w-3.5 h-3.5 text-emerald-700" />
              </button>

              <button
                type="button"
                onClick={() => handleExecuteVoiceCommand('खाता')}
                className="p-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition cursor-pointer flex items-center justify-between"
              >
                <div>
                  <span className="font-bold text-slate-800 block">"खाता" / "लेजर"</span>
                  <span className="text-[10px] text-slate-400">ग्राहक खाता खोल्छ</span>
                </div>
                <Play className="w-3.5 h-3.5 text-emerald-700" />
              </button>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <button
            type="button"
            onClick={() => {
              setTranscript('');
              setLastActionFeedback(null);
              startListening();
            }}
            className="inline-flex items-center gap-1 text-slate-600 hover:text-slate-900 text-xs font-semibold cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isNe ? 'फेरि बोल्नुहोस्' : 'Clear & Speak Again'}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-lg transition cursor-pointer"
          >
            {isNe ? 'बन्द गर्नुहोस्' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
