import React, { useMemo, useState } from 'react';
import {
  ClipboardList,
  Plus,
  FileText,
  BarChart3,
  Phone,
  MapPin,
  Printer,
  MessageCircle,
  Edit2,
  CheckCircle2,
  XCircle,
  Factory,
  Receipt,
  Truck,
  PackageCheck,
  Trash2,
  ChevronDown,
  ChevronUp,
  Send,
  Zap
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FieldOrder, FieldOrderStatus, Quotation } from '../types';
import { FieldOrderForm } from './FieldOrderForm';
import { QuotationsPanel } from './QuotationsPanel';
import { buildOrderMessage, ORDER_STATUS_META, printOrderSlip } from '../utils/orderUtils';
import { shareViaWhatsApp } from '../utils/shareUtils';
import { getTodayBsString } from '../utils/nepaliCalendar';
import { getServerUser } from '../utils/auth';

type View = 'LIST' | 'NEW' | 'QUOTES' | 'SUMMARY';

export const FieldOrdersScreen: React.FC = () => {
  const {
    fieldOrders,
    saveFieldOrder,
    updateFieldOrderStatus,
    deleteFieldOrder,
    quotations,
    saveQuotation,
    parties,
    items,
    createInvoice,
    company,
    currentAccount,
    currentRole,
    language,
    setActiveTab,
    setManufacturingSubTab
  } = useApp();
  const isNe = language === 'ne';
  const office = ['OWNER', 'ACCOUNTANT', 'ADMINISTRATION', 'SUPERVISOR'].includes(currentRole as string);
  const me = currentAccount?.ownerName || getServerUser()?.name || '';
  const myId = getServerUser()?.id || currentAccount?.mobileNumber;

  const [view, setView] = useState<View>('LIST');
  const [editing, setEditing] = useState<FieldOrder | null>(null);
  const [prefill, setPrefill] = useState<Partial<FieldOrder> | null>(null);
  const [convertQuotationId, setConvertQuotationId] = useState<string | null>(null);
  const [quoteSeed, setQuoteSeed] = useState<Partial<Quotation> | null>(null);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'OPEN' | FieldOrderStatus>('OPEN');
  const [search, setSearch] = useState('');
  const [staffFilter, setStaffFilter] = useState('ALL');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [toast, setToast] = useState('');
  const [invoiceBillType, setInvoiceBillType] = useState<'VAT' | 'NON_VAT'>('NON_VAT');

  const showToast = (m: string) => {
    setToast(m);
    setTimeout(() => setToast(''), 4000);
  };

  const mine = (o: FieldOrder) => !o.takenById || o.takenById === myId || o.takenBy === me;
  const scoped = useMemo(() => (office ? fieldOrders : fieldOrders.filter(mine)), [fieldOrders, office, myId, me]);
  const staffNames = useMemo(() => Array.from(new Set(fieldOrders.map((o) => o.takenBy))), [fieldOrders]);

  const list = useMemo(() => {
    const t = search.trim().toLowerCase();
    return scoped
      .filter((o) => {
        if (statusFilter === 'OPEN') return !['DELIVERED', 'CANCELLED'].includes(o.status);
        if (statusFilter === 'ALL') return true;
        return o.status === statusFilter;
      })
      .filter((o) => staffFilter === 'ALL' || o.takenBy === staffFilter)
      .filter((o) => !t || [o.orderNo, o.customerName, o.customerPhone || '', o.customerAddress || ''].some((f) => f.toLowerCase().includes(t)))
      .sort((a, b) => (b.updatedAt || b.dateAd).localeCompare(a.updatedAt || a.dateAd));
  }, [scoped, statusFilter, staffFilter, search]);

  const today = getTodayBsString();
  const todayOrders = scoped.filter((o) => o.dateBs === today && o.status !== 'CANCELLED');
  const pendingApproval = fieldOrders.filter((o) => o.status === 'SUBMITTED').length;
  const needProd = fieldOrders.filter((o) => o.needsProduction && ['SUBMITTED', 'APPROVED'].includes(o.status)).length;

  const handleFormDone = (order: FieldOrder) => {
    if (convertQuotationId) {
      const q = quotations.find((x) => x.id === convertQuotationId);
      if (q) saveQuotation({ ...q, status: 'CONVERTED', fieldOrderId: order.id });
      setConvertQuotationId(null);
    }
    setEditing(null);
    setPrefill(null);
    setView('LIST');
    showToast(
      order.status === 'DRAFT'
        ? isNe ? `ड्राफ्ट सेभ भयो — ${order.orderNo}` : `Draft saved — ${order.orderNo}`
        : isNe ? `✓ अर्डर ${order.orderNo} अफिसमा पठाइयो` : `✓ Order ${order.orderNo} submitted`
    );
  };

  const createInvoiceFromOrder = (o: FieldOrder) => {
    const shortage = o.items.filter((l) => l.qty > (items.find((i) => i.id === l.itemId)?.currentStock ?? 0));
    if (shortage.length > 0) {
      const ok = window.confirm(
        isNe
          ? `यी सामानको मौज्दात नपुग छ: ${shortage.map((s) => s.name).join(', ')}।\nतैपनि बिल बनाउने?`
          : `Stock is short for: ${shortage.map((s) => s.name).join(', ')}. Create bill anyway?`
      );
      if (!ok) return;
    }
    const party = parties.find((p) => p.id === o.partyId);
    const advance = o.advanceAmount || 0;
    const inv = createInvoice({
      billType: invoiceBillType,
      customerName: o.customerName,
      customerPan: o.customerPan,
      customerAddress: o.customerAddress,
      customerPhone: o.customerPhone,
      partyId: o.partyId,
      previousDue: party ? party.currentBalance ?? party.openingBalance : 0,
      items: o.items.map((l) => {
        const it = items.find((i) => i.id === l.itemId);
        return {
          itemId: l.itemId,
          code: l.code || it?.code || '',
          name: l.name,
          size: l.size,
          unit: l.unit,
          quantity: l.qty,
          rate: l.rate,
          amount: l.amount,
          isVatExempt: !!l.isVatExempt
        };
      }),
      discountPercent: o.discountPercent || 0,
      freightCharge: 0,
      paymentMode: o.paymentTerm === 'CASH' ? 'CASH' : 'CREDIT',
      amountPaid: o.paymentTerm === 'CASH' ? undefined : advance,
      notes: `फिल्ड अर्डर ${o.orderNo} बाट | अर्डर लिने: ${o.takenBy}`,
      billedBy: me || undefined
    });
    updateFieldOrderStatus(o.id, o.status, { invoiceId: inv.id, invoiceNo: inv.invoiceNo }, `बिल ${inv.invoiceNo} बन्यो`);
    showToast(isNe ? `✓ बिल ${inv.invoiceNo} बन्यो` : `✓ Invoice ${inv.invoiceNo} created`);
  };

  const askCancel = (o: FieldOrder) => {
    const reason = window.prompt(isNe ? 'रद्द गर्नुको कारण:' : 'Reason for cancelling:');
    if (reason === null) return;
    updateFieldOrderStatus(o.id, 'CANCELLED', { cancelReason: reason || undefined }, reason || undefined);
  };

  const goPlanning = () => {
    setActiveTab('manufacturing');
    setManufacturingSubTab('PLANNING');
  };

  // ---------- सारांश (स्टाफ अनुसार) ----------
  const summary = useMemo(() => {
    const map = new Map<string, { name: string; count: number; value: number; thisMonth: number; delivered: number; newCust: number }>();
    const ym = today.slice(0, 7);
    scoped
      .filter((o) => o.status !== 'CANCELLED' && o.status !== 'DRAFT')
      .forEach((o) => {
        const r = map.get(o.takenBy) || { name: o.takenBy, count: 0, value: 0, thisMonth: 0, delivered: 0, newCust: 0 };
        r.count += 1;
        r.value += o.grandTotal;
        if (o.dateBs.startsWith(ym)) r.thisMonth += o.grandTotal;
        if (o.status === 'DELIVERED') r.delivered += 1;
        if (o.isNewCustomer) r.newCust += 1;
        map.set(o.takenBy, r);
      });
    return Array.from(map.values()).sort((a, b) => b.value - a.value);
  }, [scoped, today]);

  const TabBtn = ({ id, icon: Icon, label, badge }: { id: View; icon: any; label: string; badge?: number }) => (
    <button
      onClick={() => {
        setView(id);
        setEditing(null);
        setPrefill(null);
      }}
      className={`flex-1 sm:flex-none px-3 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 relative ${
        view === id ? 'bg-emerald-600 text-white shadow' : 'bg-white text-slate-700 border border-slate-200'
      }`}
    >
      <Icon className="w-4 h-4" />
      {label}
      {!!badge && <span className="ml-1 px-1.5 rounded-full bg-rose-500 text-white text-[10px]">{badge}</span>}
    </button>
  );

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-800 text-white rounded-2xl p-4 shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-white/15 rounded-xl">
            <ClipboardList className="w-6 h-6" />
          </div>
          <div className="min-w-0">
            <h1 className="text-lg sm:text-xl font-black leading-tight">{isNe ? 'फिल्ड अर्डर तथा कोटेशन' : 'Field Orders & Quotations'}</h1>
            <p className="text-[11px] text-emerald-100">
              {isNe ? 'ग्राहकको ठाउँमै अर्डर टिप्ने, कोटेशन दिने — अफिसमा तुरुन्त पुग्ने' : 'Take orders and give quotations at the customer site'}
            </p>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          <div className="bg-white/10 rounded-xl py-2">
            <div className="text-lg font-black">{todayOrders.length}</div>
            <div className="text-[10px] text-emerald-100">{isNe ? 'आजका अर्डर' : "Today's orders"}</div>
          </div>
          <div className="bg-white/10 rounded-xl py-2">
            <div className="text-lg font-black">{(todayOrders.reduce((s, o) => s + o.grandTotal, 0) / 1000).toFixed(1)}k</div>
            <div className="text-[10px] text-emerald-100">{isNe ? 'आजको मूल्य (रू.)' : "Today's value"}</div>
          </div>
          <div className="bg-white/10 rounded-xl py-2">
            <div className="text-lg font-black">{office ? pendingApproval : scoped.filter((o) => o.status === 'DRAFT').length}</div>
            <div className="text-[10px] text-emerald-100">{office ? (isNe ? 'स्वीकृति बाँकी' : 'Awaiting approval') : isNe ? 'ड्राफ्ट' : 'Drafts'}</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 flex-wrap">
        <TabBtn id="NEW" icon={Plus} label={isNe ? 'नयाँ अर्डर' : 'New order'} />
        <TabBtn id="LIST" icon={ClipboardList} label={isNe ? 'अर्डरहरू' : 'Orders'} />
        <TabBtn id="QUOTES" icon={FileText} label={isNe ? 'कोटेशन' : 'Quotations'} />
        <TabBtn id="SUMMARY" icon={BarChart3} label={isNe ? 'सारांश' : 'Summary'} />
      </div>

      {toast && <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 font-bold text-sm rounded-xl px-3 py-2">{toast}</div>}

      {view === 'NEW' && (
        <FieldOrderForm
          key={editing?.id || (prefill ? 'prefill' : 'new')}
          editing={editing}
          prefill={prefill}
          onDone={handleFormDone}
          onCancel={() => {
            setEditing(null);
            setPrefill(null);
            setConvertQuotationId(null);
            setView('LIST');
          }}
        />
      )}

      {view === 'QUOTES' && (
        <QuotationsPanel
          seed={quoteSeed}
          onSeedConsumed={() => setQuoteSeed(null)}
          onConvertToOrder={(pf, qid) => {
            setPrefill(pf);
            setConvertQuotationId(qid);
            setEditing(null);
            setView('NEW');
          }}
        />
      )}

      {view === 'SUMMARY' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b font-black text-sm">{office ? (isNe ? 'स्टाफ अनुसार अर्डर सारांश' : 'Orders by staff') : isNe ? 'मेरो अर्डर सारांश' : 'My summary'}</div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="text-left p-2">{isNe ? 'स्टाफ' : 'Staff'}</th>
                  <th className="text-right p-2">{isNe ? 'अर्डर' : 'Orders'}</th>
                  <th className="text-right p-2">{isNe ? 'कुल मूल्य' : 'Value'}</th>
                  <th className="text-right p-2">{isNe ? 'यो महिना' : 'This month'}</th>
                  <th className="text-right p-2">{isNe ? 'डेलिभर' : 'Delivered'}</th>
                  <th className="text-right p-2">{isNe ? 'नयाँ ग्राहक' : 'New cust.'}</th>
                </tr>
              </thead>
              <tbody>
                {summary.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-6 text-center text-slate-400">
                      {isNe ? 'अहिलेसम्म कुनै अर्डर छैन' : 'No orders yet'}
                    </td>
                  </tr>
                )}
                {summary.map((r) => (
                  <tr key={r.name} className="border-t">
                    <td className="p-2 font-bold">{r.name}</td>
                    <td className="p-2 text-right">{r.count}</td>
                    <td className="p-2 text-right font-bold">{r.value.toLocaleString('en-IN')}</td>
                    <td className="p-2 text-right">{r.thisMonth.toLocaleString('en-IN')}</td>
                    <td className="p-2 text-right">{r.delivered}</td>
                    <td className="p-2 text-right">{r.newCust}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {view === 'LIST' && (
        <div className="space-y-3">
          {office && needProd > 0 && (
            <button
              onClick={goPlanning}
              className="w-full text-left px-3 py-2.5 bg-amber-50 border-2 border-amber-300 rounded-xl text-sm font-bold text-amber-900 flex items-center justify-between"
            >
              <span>
                ⚠ {needProd} {isNe ? 'अर्डरका सामान मौज्दात नपुग — उत्पादन योजना हेर्नुहोस्' : 'orders need production — open Planning'}
              </span>
              <Factory className="w-4 h-4" />
            </button>
          )}

          <div className="flex flex-col sm:flex-row gap-2">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={isNe ? 'अर्डर नं. / ग्राहक / फोन खोज्नुहोस्' : 'Search order / customer / phone'}
              className="flex-1 px-3 py-2.5 border border-slate-300 rounded-xl text-sm"
            />
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as any)} className="px-3 py-2.5 border border-slate-300 rounded-xl text-sm bg-white">
              <option value="OPEN">{isNe ? 'चालु (खुला)' : 'Open'}</option>
              <option value="ALL">{isNe ? 'सबै' : 'All'}</option>
              {(Object.keys(ORDER_STATUS_META) as FieldOrderStatus[]).map((s) => (
                <option key={s} value={s}>
                  {ORDER_STATUS_META[s].ne}
                </option>
              ))}
            </select>
            {office && (
              <select value={staffFilter} onChange={(e) => setStaffFilter(e.target.value)} className="px-3 py-2.5 border border-slate-300 rounded-xl text-sm bg-white">
                <option value="ALL">{isNe ? 'सबै स्टाफ' : 'All staff'}</option>
                {staffNames.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            )}
          </div>

          {list.length === 0 ? (
            <div className="text-center text-sm text-slate-400 py-12 bg-white border border-dashed border-slate-300 rounded-2xl">
              {isNe ? 'कुनै अर्डर भेटिएन। "नयाँ अर्डर" थिचेर सुरु गर्नुहोस्।' : 'No orders found.'}
            </div>
          ) : (
            list.map((o) => {
              const meta = ORDER_STATUS_META[o.status];
              const open = expanded === o.id;
              const canEdit = ['DRAFT', 'SUBMITTED'].includes(o.status) && (office || mine(o));
              return (
                <div key={o.id} className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
                  <button onClick={() => setExpanded(open ? null : o.id)} className="w-full text-left p-3 flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-mono text-xs font-black text-slate-700">{o.orderNo}</span>
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${meta.cls}`}>{isNe ? meta.ne : meta.en}</span>
                        {o.priority === 'URGENT' && (
                          <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full bg-rose-600 text-white flex items-center gap-0.5">
                            <Zap className="w-3 h-3" />
                            {isNe ? 'जरुरी' : 'Urgent'}
                          </span>
                        )}
                        {o.needsProduction && !['DELIVERED', 'CANCELLED', 'READY', 'DISPATCHED'].includes(o.status) && (
                          <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300">
                            {isNe ? 'उत्पादन चाहिने' : 'Needs production'}
                          </span>
                        )}
                        {o.invoiceNo && <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full bg-sky-100 text-sky-800 border border-sky-300">{o.invoiceNo}</span>}
                      </div>
                      <div className="font-bold text-slate-900 truncate">{o.customerName}</div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {o.dateBs} · {o.items.length} {isNe ? 'सामान' : 'items'} · {o.takenBy}
                        {o.expectedDeliveryBs ? ` · ${isNe ? 'डेलिभरी' : 'due'}: ${o.expectedDeliveryBs}` : ''}
                      </div>
                    </div>
                    <div className="text-right shrink-0 flex items-start gap-1">
                      <div>
                        <div className="text-base font-black text-emerald-800">रू. {o.grandTotal.toLocaleString('en-IN')}</div>
                        {!!o.advanceAmount && <div className="text-[10px] text-slate-500">{isNe ? 'अग्रिम' : 'Adv'}: {o.advanceAmount.toLocaleString('en-IN')}</div>}
                      </div>
                      {open ? <ChevronUp className="w-4 h-4 text-slate-400 mt-1" /> : <ChevronDown className="w-4 h-4 text-slate-400 mt-1" />}
                    </div>
                  </button>

                  {open && (
                    <div className="border-t border-slate-100 p-3 space-y-3 bg-slate-50/60">
                      <div className="text-xs space-y-0.5">
                        {o.items.map((l, i) => (
                          <div key={i} className="flex justify-between gap-2">
                            <span className="truncate">
                              {i + 1}. {l.name}
                              {l.size ? ` (${l.size})` : ''} — {l.qty} {l.unit} × {l.rate}
                              {l.note ? ` · ${l.note}` : ''}
                            </span>
                            <b>{l.amount.toLocaleString('en-IN')}</b>
                          </div>
                        ))}
                        {o.discountAmount > 0 && (
                          <div className="flex justify-between text-rose-700">
                            <span>
                              {isNe ? 'छुट' : 'Discount'} ({o.discountPercent}%)
                            </span>
                            <b>- {o.discountAmount.toLocaleString('en-IN')}</b>
                          </div>
                        )}
                      </div>

                      <div className="text-[11px] text-slate-600 grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-0.5">
                        <div>
                          {isNe ? 'भुक्तानी' : 'Payment'}: <b>{o.paymentTerm === 'CASH' ? (isNe ? 'नगद' : 'Cash') : o.paymentTerm === 'CREDIT' ? `${isNe ? 'उधारो' : 'Credit'}${o.creditDays ? ` (${o.creditDays} ${isNe ? 'दिन' : 'd'})` : ''}` : isNe ? 'अग्रिम' : 'Advance'}</b>
                        </div>
                        {o.customerPhone && <div>{isNe ? 'फोन' : 'Phone'}: <b>{o.customerPhone}</b></div>}
                        {o.customerAddress && <div>{isNe ? 'ठेगाना' : 'Address'}: <b>{o.customerAddress}</b></div>}
                        {o.deliveryAddress && <div>{isNe ? 'डेलिभरी ठेगाना' : 'Deliver to'}: <b>{o.deliveryAddress}</b></div>}
                        {o.notes && <div className="sm:col-span-2">{isNe ? 'टिप्पणी' : 'Notes'}: {o.notes}</div>}
                        {o.cancelReason && <div className="sm:col-span-2 text-rose-700">{isNe ? 'रद्दको कारण' : 'Cancel reason'}: {o.cancelReason}</div>}
                      </div>
                      {o.photoUrl && <img src={o.photoUrl} alt="" className="h-24 rounded-lg border object-cover" />}

                      {o.statusHistory && o.statusHistory.length > 0 && (
                        <div className="text-[10px] text-slate-500 border-t border-slate-200 pt-2 space-y-0.5">
                          {o.statusHistory.map((h, i) => (
                            <div key={i}>
                              {h.dateBs} {h.time} — <b>{ORDER_STATUS_META[h.status].ne}</b> · {h.by}
                              {h.note ? ` (${h.note})` : ''}
                            </div>
                          ))}
                        </div>
                      )}

                      {/* कार्यहरू */}
                      <div className="flex flex-wrap gap-1.5">
                        {o.customerPhone && (
                          <a href={`tel:${o.customerPhone}`} className="px-2.5 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg flex items-center gap-1">
                            <Phone className="w-3.5 h-3.5" />
                            {isNe ? 'फोन' : 'Call'}
                          </a>
                        )}
                        {o.gpsLat && o.gpsLng && (
                          <a href={`https://maps.google.com/?q=${o.gpsLat},${o.gpsLng}`} target="_blank" rel="noreferrer" className="px-2.5 py-1.5 text-xs font-bold bg-sky-50 text-sky-800 border border-sky-300 rounded-lg flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5" />
                            {isNe ? 'नक्सा' : 'Map'}
                          </a>
                        )}
                        <button onClick={() => shareViaWhatsApp(o.customerPhone, buildOrderMessage(o, company))} className="px-2.5 py-1.5 text-xs font-bold bg-green-600 text-white rounded-lg flex items-center gap-1">
                          <MessageCircle className="w-3.5 h-3.5" />
                          WhatsApp
                        </button>
                        <button onClick={() => printOrderSlip(o, company)} className="px-2.5 py-1.5 text-xs font-bold bg-slate-800 text-white rounded-lg flex items-center gap-1">
                          <Printer className="w-3.5 h-3.5" />
                          {isNe ? 'स्लिप' : 'Slip'}
                        </button>
                        <button
                          onClick={() =>
                            setQuoteSeed({
                              partyId: o.partyId,
                              customerName: o.customerName,
                              customerPhone: o.customerPhone,
                              customerAddress: o.customerAddress,
                              customerPan: o.customerPan,
                              items: o.items,
                              discountPercent: o.discountPercent,
                              fieldOrderId: o.id
                            }) || setView('QUOTES')
                          }
                          className="px-2.5 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg flex items-center gap-1"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          {isNe ? 'कोटेशन बनाउ' : 'Quotation'}
                        </button>

                        {canEdit && (
                          <button
                            onClick={() => {
                              setEditing(o);
                              setView('NEW');
                            }}
                            className="px-2.5 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg flex items-center gap-1"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                            {isNe ? 'सच्याउनुहोस्' : 'Edit'}
                          </button>
                        )}
                        {o.status === 'DRAFT' && (office || mine(o)) && (
                          <button onClick={() => updateFieldOrderStatus(o.id, 'SUBMITTED', undefined, 'अफिसमा पठाइयो')} className="px-2.5 py-1.5 text-xs font-bold bg-emerald-600 text-white rounded-lg flex items-center gap-1">
                            <Send className="w-3.5 h-3.5" />
                            {isNe ? 'अफिसमा पठाउनुहोस्' : 'Submit'}
                          </button>
                        )}
                        {['DRAFT', 'SUBMITTED'].includes(o.status) && (office || mine(o)) && (
                          <button onClick={() => askCancel(o)} className="px-2.5 py-1.5 text-xs font-bold bg-rose-50 text-rose-800 border border-rose-300 rounded-lg flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5" />
                            {isNe ? 'रद्द' : 'Cancel'}
                          </button>
                        )}

                        {office && o.status === 'SUBMITTED' && (
                          <button
                            onClick={() => updateFieldOrderStatus(o.id, 'APPROVED', { approvedBy: me, approvedDateBs: today }, 'स्वीकृत')}
                            className="px-2.5 py-1.5 text-xs font-bold bg-emerald-600 text-white rounded-lg flex items-center gap-1"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {isNe ? 'स्वीकृत गर्नुहोस्' : 'Approve'}
                          </button>
                        )}
                        {office && o.needsProduction && ['SUBMITTED', 'APPROVED'].includes(o.status) && (
                          <button onClick={goPlanning} className="px-2.5 py-1.5 text-xs font-bold bg-purple-600 text-white rounded-lg flex items-center gap-1">
                            <Factory className="w-3.5 h-3.5" />
                            {isNe ? 'उत्पादन योजना' : 'Plan production'}
                          </button>
                        )}
                        {office && ['APPROVED', 'READY'].includes(o.status) && (
                          <button onClick={() => updateFieldOrderStatus(o.id, 'DISPATCHED', undefined, 'चलान गरियो')} className="px-2.5 py-1.5 text-xs font-bold bg-indigo-600 text-white rounded-lg flex items-center gap-1">
                            <Truck className="w-3.5 h-3.5" />
                            {isNe ? 'चलान गर्नुहोस्' : 'Dispatch'}
                          </button>
                        )}
                        {office && o.status === 'APPROVED' && !o.needsProduction && (
                          <button onClick={() => updateFieldOrderStatus(o.id, 'READY', undefined, 'सामान तयार')} className="px-2.5 py-1.5 text-xs font-bold bg-teal-600 text-white rounded-lg flex items-center gap-1">
                            <PackageCheck className="w-3.5 h-3.5" />
                            {isNe ? 'तयार भयो' : 'Mark ready'}
                          </button>
                        )}
                        {office && ['DISPATCHED', 'READY'].includes(o.status) && (
                          <button onClick={() => updateFieldOrderStatus(o.id, 'DELIVERED', undefined, 'डेलिभर भयो')} className="px-2.5 py-1.5 text-xs font-bold bg-green-700 text-white rounded-lg flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {isNe ? 'डेलिभर भयो' : 'Delivered'}
                          </button>
                        )}
                        {office && !o.invoiceId && ['APPROVED', 'IN_PRODUCTION', 'READY', 'DISPATCHED', 'DELIVERED'].includes(o.status) && (
                          <span className="flex items-center gap-1">
                            <select value={invoiceBillType} onChange={(e) => setInvoiceBillType(e.target.value as any)} className="px-1.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white">
                              <option value="NON_VAT">Non-VAT</option>
                              <option value="VAT">VAT</option>
                            </select>
                            <button onClick={() => createInvoiceFromOrder(o)} className="px-2.5 py-1.5 text-xs font-bold bg-sky-600 text-white rounded-lg flex items-center gap-1">
                              <Receipt className="w-3.5 h-3.5" />
                              {isNe ? 'बिल बनाउनुहोस्' : 'Create bill'}
                            </button>
                          </span>
                        )}
                        {currentRole === 'OWNER' && (
                          <button onClick={() => deleteFieldOrder(o.id)} className="px-2 py-1.5 text-xs text-rose-600 border border-rose-200 rounded-lg">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
