import React, { useMemo, useState } from 'react';
import { MapPin, Camera, UserPlus, Send, Save, X, Phone, AlertTriangle, Zap } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FieldOrder, FieldOrderItem, FieldOrderPayment, FieldOrderPriority, Party } from '../types';
import { OrderLinesEditor } from './OrderLinesEditor';
import { calcTotals, addDaysAd, adStringToBs, round2 } from '../utils/orderUtils';
import { getTodayBsString, getTodayAdString } from '../utils/nepaliCalendar';
import { fileToDataUrl } from '../utils/imageUtils';
import { getServerUser } from '../utils/auth';

interface Props {
  editing?: FieldOrder | null;
  /** कोटेशनबाट अर्डर बनाउँदा पहिले भरिने विवरण */
  prefill?: Partial<FieldOrder> | null;
  onDone: (order: FieldOrder) => void;
  onCancel: () => void;
}

export const FieldOrderForm: React.FC<Props> = ({ editing, prefill, onDone, onCancel }) => {
  const { parties, saveParty, saveFieldOrder, getNextFieldOrderNo, currentAccount, currentRole, language, items } = useApp();
  const isNe = language === 'ne';
  const privileged = ['OWNER', 'ACCOUNTANT', 'ADMINISTRATION', 'SUPERVISOR'].includes(currentRole as string);
  const base = editing || (prefill as Partial<FieldOrder>) || {};

  const [partyId, setPartyId] = useState<string>(base.partyId || '');
  const [partySearch, setPartySearch] = useState('');
  const [isNewCustomer, setIsNewCustomer] = useState<boolean>(!base.partyId && !!base.isNewCustomer);
  const [custName, setCustName] = useState(base.customerName || '');
  const [custPhone, setCustPhone] = useState(base.customerPhone || '');
  const [custAddress, setCustAddress] = useState(base.customerAddress || '');
  const [custPan, setCustPan] = useState(base.customerPan || '');

  const [gps, setGps] = useState<{ lat?: number; lng?: number; acc?: number }>({
    lat: base.gpsLat,
    lng: base.gpsLng,
    acc: base.gpsAccuracy
  });
  const [gpsBusy, setGpsBusy] = useState(false);
  const [gpsErr, setGpsErr] = useState('');

  const [lines, setLines] = useState<FieldOrderItem[]>(base.items || []);
  const [discountPercent, setDiscountPercent] = useState<number>(base.discountPercent || 0);
  const [paymentTerm, setPaymentTerm] = useState<FieldOrderPayment>(base.paymentTerm || 'CASH');
  const [advance, setAdvance] = useState<number>(base.advanceAmount || 0);
  const [advanceMode, setAdvanceMode] = useState<'CASH' | 'BANK'>(base.advanceMode || 'CASH');
  const [creditDays, setCreditDays] = useState<number>(base.creditDays || 30);
  const [deliveryAd, setDeliveryAd] = useState<string>(addDaysAd(7));
  const [deliveryBs, setDeliveryBs] = useState<string>(base.expectedDeliveryBs || adStringToBs(addDaysAd(7)));
  const [deliveryAddress, setDeliveryAddress] = useState(base.deliveryAddress || '');
  const [priority, setPriority] = useState<FieldOrderPriority>(base.priority || 'NORMAL');
  const [notes, setNotes] = useState(base.notes || '');
  const [photo, setPhoto] = useState<string>(base.photoUrl || '');
  const [error, setError] = useState('');

  const customers = useMemo(
    () => parties.filter((p) => (p.partyType || p.type) !== 'SUPPLIER'),
    [parties]
  );
  const filteredCustomers = useMemo(() => {
    const t = partySearch.trim().toLowerCase();
    if (!t) return [];
    return customers
      .filter((p) => [p.name, p.phone || '', p.address || ''].some((f) => f.toLowerCase().includes(t)))
      .slice(0, 6);
  }, [partySearch, customers]);
  const selectedParty = parties.find((p) => p.id === partyId);

  const totals = calcTotals(lines, discountPercent, false, 0);
  const shortLines = lines.filter((l) => l.qty > (items.find((i) => i.id === l.itemId)?.currentStock ?? 0));
  const partyDue = selectedParty ? selectedParty.currentBalance ?? selectedParty.openingBalance : 0;

  const pickParty = (p: Party) => {
    setPartyId(p.id);
    setCustName(p.name);
    setCustPhone(p.phone || '');
    setCustAddress(p.address || '');
    setCustPan(p.panNo || '');
    setPartySearch('');
    setIsNewCustomer(false);
  };

  const captureGps = () => {
    setGpsErr('');
    if (!navigator.geolocation) {
      setGpsErr(isNe ? 'यो फोनमा GPS उपलब्ध छैन।' : 'GPS not available.');
      return;
    }
    setGpsBusy(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGps({ lat: pos.coords.latitude, lng: pos.coords.longitude, acc: Math.round(pos.coords.accuracy) });
        setGpsBusy(false);
      },
      () => {
        setGpsErr(isNe ? 'लोकेसन लिन सकिएन। फोनको Location अनुमति दिनुहोस्।' : 'Could not get location. Allow location permission.');
        setGpsBusy(false);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
    );
  };

  const onPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    try {
      setPhoto(await fileToDataUrl(f, 800, 800, 0.7));
    } catch {
      setError(isNe ? 'फोटो लोड गर्न सकिएन।' : 'Could not load photo.');
    }
  };

  const submit = (status: 'DRAFT' | 'SUBMITTED') => {
    setError('');
    const name = custName.trim();
    if (!name) {
      setError(isNe ? 'ग्राहकको नाम चाहिन्छ।' : 'Customer name required.');
      return;
    }
    if (isNewCustomer && !custPhone.trim()) {
      setError(isNe ? 'नयाँ ग्राहकको फोन नम्बर चाहिन्छ।' : 'Phone number required for new customer.');
      return;
    }
    const validLines = lines.filter((l) => l.qty > 0);
    if (validLines.length === 0) {
      setError(isNe ? 'कम्तीमा एउटा सामान र परिमाण राख्नुहोस्।' : 'Add at least one item with quantity.');
      return;
    }
    if (paymentTerm !== 'CASH' && advance < 0) {
      setError(isNe ? 'अग्रिम रकम गलत छ।' : 'Invalid advance.');
      return;
    }
    if (advance > totals.grandTotal) {
      setError(isNe ? 'अग्रिम रकम जम्मा भन्दा बढी भयो।' : 'Advance is more than total.');
      return;
    }

    let finalPartyId = partyId;
    if (!finalPartyId && isNewCustomer) {
      // नयाँ ग्राहक फिल्डमै पार्टी खातामा थप्ने (डुप्लिकेट फोन जाँच)
      const dup = parties.find((p) => p.phone && custPhone.trim() && p.phone === custPhone.trim());
      if (dup) {
        finalPartyId = dup.id;
      } else {
        finalPartyId = `party-${Date.now()}`;
        saveParty({
          id: finalPartyId,
          name,
          phone: custPhone.trim(),
          address: custAddress.trim(),
          panNo: custPan.trim() || undefined,
          partyType: 'CUSTOMER',
          customerCategory: 'RETAIL',
          openingBalance: 0,
          currentBalance: 0
        });
      }
    }

    const now = new Date();
    const serverUser = getServerUser();
    const takenBy = editing?.takenBy || currentAccount?.ownerName || serverUser?.name || (isNe ? 'कर्मचारी' : 'Staff');
    const order: FieldOrder = {
      id: editing?.id || `fo-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      orderNo: editing?.orderNo || getNextFieldOrderNo(),
      dateBs: editing?.dateBs || getTodayBsString(),
      dateAd: editing?.dateAd || getTodayAdString(),
      time: editing?.time || now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      partyId: finalPartyId || undefined,
      customerName: name,
      customerPhone: custPhone.trim() || undefined,
      customerAddress: custAddress.trim() || undefined,
      customerPan: custPan.trim() || undefined,
      isNewCustomer: isNewCustomer || undefined,
      gpsLat: gps.lat,
      gpsLng: gps.lng,
      gpsAccuracy: gps.acc,
      takenBy,
      takenById: editing?.takenById || serverUser?.id || currentAccount?.mobileNumber,
      takenByRole: editing?.takenByRole || (currentRole as string),
      items: validLines.map((l) => ({ ...l, amount: round2(l.amount) })),
      subtotal: totals.subtotal,
      discountPercent,
      discountAmount: totals.discountAmount,
      grandTotal: totals.grandTotal,
      paymentTerm,
      advanceAmount: advance > 0 ? advance : undefined,
      advanceMode: advance > 0 ? advanceMode : undefined,
      creditDays: paymentTerm === 'CREDIT' ? creditDays : undefined,
      expectedDeliveryBs: deliveryBs || undefined,
      deliveryAddress: deliveryAddress.trim() || undefined,
      priority,
      notes: notes.trim() || undefined,
      photoUrl: photo || undefined,
      status: status === 'SUBMITTED' && editing && editing.status !== 'DRAFT' ? editing.status : status,
      needsProduction: shortLines.length > 0,
      statusHistory: [
        ...(editing?.statusHistory || []),
        {
          status,
          dateBs: getTodayBsString(),
          time: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          by: takenBy,
          note: editing ? 'सच्याइयो' : 'अर्डर टिपियो'
        }
      ]
    };
    saveFieldOrder(order);
    onDone(order);
  };

  return (
    <div className="space-y-4 pb-28">
      {/* ग्राहक */}
      <section className="bg-white border border-slate-200 rounded-2xl p-3 sm:p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-black text-slate-900 text-sm">{isNe ? '१. ग्राहक' : '1. Customer'}</h3>
          <button
            type="button"
            onClick={() => {
              setIsNewCustomer(!isNewCustomer);
              setPartyId('');
              setCustName('');
              setCustPhone('');
              setCustAddress('');
              setCustPan('');
            }}
            className="text-xs font-bold text-emerald-700 flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-emerald-50"
          >
            <UserPlus className="w-4 h-4" />
            {isNewCustomer ? (isNe ? 'पुरानो ग्राहक छान्नुहोस्' : 'Pick existing') : isNe ? 'नयाँ ग्राहक' : 'New customer'}
          </button>
        </div>

        {!isNewCustomer && (
          <div className="relative">
            <input
              value={partySearch}
              onChange={(e) => setPartySearch(e.target.value)}
              placeholder={isNe ? 'ग्राहकको नाम / फोन खोज्नुहोस्...' : 'Search customer name / phone...'}
              className="w-full px-3 py-3 border-2 border-emerald-300 rounded-xl text-sm"
            />
            {filteredCustomers.length > 0 && (
              <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-300 rounded-xl shadow-xl">
                {filteredCustomers.map((p) => (
                  <button
                    type="button"
                    key={p.id}
                    onClick={() => pickParty(p)}
                    className="w-full text-left px-3 py-2.5 border-b border-slate-100 hover:bg-emerald-50"
                  >
                    <div className="text-sm font-bold">{p.name}</div>
                    <div className="text-[11px] text-slate-500">
                      {p.phone || '-'} · {p.address || '-'}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input
            value={custName}
            onChange={(e) => setCustName(e.target.value)}
            readOnly={!isNewCustomer && !!partyId}
            placeholder={isNe ? 'ग्राहकको नाम *' : 'Customer name *'}
            className="px-3 py-2.5 border border-slate-300 rounded-xl text-sm font-bold read-only:bg-slate-50"
          />
          <input
            value={custPhone}
            onChange={(e) => setCustPhone(e.target.value)}
            inputMode="tel"
            placeholder={isNe ? 'फोन नम्बर' + (isNewCustomer ? ' *' : '') : 'Phone'}
            className="px-3 py-2.5 border border-slate-300 rounded-xl text-sm"
          />
          <input
            value={custAddress}
            onChange={(e) => setCustAddress(e.target.value)}
            placeholder={isNe ? 'ठेगाना (गाउँ / टोल / वडा)' : 'Address'}
            className="px-3 py-2.5 border border-slate-300 rounded-xl text-sm"
          />
          {isNewCustomer && (
            <input
              value={custPan}
              onChange={(e) => setCustPan(e.target.value)}
              placeholder={isNe ? 'PAN नं. (भए)' : 'PAN (optional)'}
              className="px-3 py-2.5 border border-slate-300 rounded-xl text-sm"
            />
          )}
        </div>

        {selectedParty && partyDue > 0 && (
          <div className="flex items-center gap-2 text-xs font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2">
            <AlertTriangle className="w-4 h-4" />
            {isNe ? `यो ग्राहकको पुरानो बाँकी: रू. ${partyDue.toLocaleString('en-IN')}` : `Outstanding: Rs. ${partyDue.toLocaleString('en-IN')}`}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={captureGps}
            disabled={gpsBusy}
            className="px-3 py-2 text-xs font-bold bg-sky-600 hover:bg-sky-700 text-white rounded-xl flex items-center gap-1.5 disabled:opacity-60"
          >
            <MapPin className="w-4 h-4" />
            {gpsBusy ? (isNe ? 'लोकेसन लिँदै...' : 'Locating...') : gps.lat ? (isNe ? 'लोकेसन फेरि लिनुहोस्' : 'Re-capture') : isNe ? 'ग्राहकको लोकेसन (GPS) राख्नुहोस्' : 'Capture GPS location'}
          </button>
          {gps.lat && gps.lng && (
            <a
              href={`https://maps.google.com/?q=${gps.lat},${gps.lng}`}
              target="_blank"
              rel="noreferrer"
              className="text-xs font-bold text-sky-700 underline"
            >
              {gps.lat.toFixed(5)}, {gps.lng.toFixed(5)} {gps.acc ? `(±${gps.acc}m)` : ''}
            </a>
          )}
          {gpsErr && <span className="text-xs text-rose-600">{gpsErr}</span>}
        </div>
      </section>

      {/* सामान */}
      <section className="bg-white border border-slate-200 rounded-2xl p-3 sm:p-4 space-y-3">
        <h3 className="font-black text-slate-900 text-sm">{isNe ? '२. अर्डर गरेको सामान' : '2. Items ordered'}</h3>
        <OrderLinesEditor lines={lines} onChange={setLines} privileged={privileged} />
        {shortLines.length > 0 && (
          <div className="text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            {isNe
              ? `⚠ ${shortLines.length} सामानको मौज्दात नपुग छ — अफिसले उत्पादन योजनामा राख्नेछ।`
              : `⚠ ${shortLines.length} item(s) exceed stock — office will plan production.`}
          </div>
        )}
      </section>

      {/* भुक्तानी र डेलिभरी */}
      <section className="bg-white border border-slate-200 rounded-2xl p-3 sm:p-4 space-y-3">
        <h3 className="font-black text-slate-900 text-sm">{isNe ? '३. भुक्तानी तथा डेलिभरी' : '3. Payment & delivery'}</h3>

        <div className="grid grid-cols-3 gap-2">
          {(
            [
              ['CASH', isNe ? 'नगद' : 'Cash'],
              ['CREDIT', isNe ? 'उधारो' : 'Credit'],
              ['ADVANCE', isNe ? 'अग्रिम' : 'Advance']
            ] as [FieldOrderPayment, string][]
          ).map(([k, label]) => (
            <button
              type="button"
              key={k}
              onClick={() => setPaymentTerm(k)}
              className={`py-2.5 rounded-xl text-sm font-bold border-2 ${
                paymentTerm === k ? 'bg-emerald-600 text-white border-emerald-700' : 'bg-white text-slate-700 border-slate-200'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <label className="text-[11px] font-bold text-slate-600">
            {isNe ? 'कुल छुट %' : 'Total discount %'}
            <input
              type="number"
              inputMode="decimal"
              min={0}
              max={privileged ? 100 : 10}
              value={discountPercent}
              onChange={(e) => {
                const v = Number(e.target.value);
                setDiscountPercent(privileged ? v : Math.min(10, v));
              }}
              className="mt-0.5 w-full px-2 py-2 border border-slate-300 rounded-lg text-sm font-normal"
            />
          </label>
          <label className="text-[11px] font-bold text-slate-600">
            {isNe ? 'अग्रिम लिएको (रू.)' : 'Advance taken'}
            <input
              type="number"
              inputMode="decimal"
              min={0}
              value={advance}
              onChange={(e) => setAdvance(Number(e.target.value))}
              className="mt-0.5 w-full px-2 py-2 border border-slate-300 rounded-lg text-sm font-normal"
            />
          </label>
          {advance > 0 && (
            <label className="text-[11px] font-bold text-slate-600">
              {isNe ? 'अग्रिम कसरी' : 'Advance via'}
              <select
                value={advanceMode}
                onChange={(e) => setAdvanceMode(e.target.value as 'CASH' | 'BANK')}
                className="mt-0.5 w-full px-2 py-2 border border-slate-300 rounded-lg text-sm font-normal bg-white"
              >
                <option value="CASH">{isNe ? 'नगद' : 'Cash'}</option>
                <option value="BANK">{isNe ? 'बैंक / फोनपे' : 'Bank / FonePay'}</option>
              </select>
            </label>
          )}
          {paymentTerm === 'CREDIT' && (
            <label className="text-[11px] font-bold text-slate-600">
              {isNe ? 'उधारो अवधि (दिन)' : 'Credit days'}
              <input
                type="number"
                min={1}
                value={creditDays}
                onChange={(e) => setCreditDays(Number(e.target.value))}
                className="mt-0.5 w-full px-2 py-2 border border-slate-300 rounded-lg text-sm font-normal"
              />
            </label>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <label className="text-[11px] font-bold text-slate-600">
            {isNe ? 'ग्राहकलाई कहिले चाहिन्छ (डेलिभरी मिति)' : 'Needed by (delivery date)'}
            <input
              type="date"
              value={deliveryAd}
              onChange={(e) => {
                setDeliveryAd(e.target.value);
                setDeliveryBs(adStringToBs(e.target.value));
              }}
              className="mt-0.5 w-full px-2 py-2 border border-slate-300 rounded-lg text-sm font-normal"
            />
            <span className="text-[11px] font-mono text-emerald-800">BS: {deliveryBs}</span>
          </label>
          <label className="text-[11px] font-bold text-slate-600">
            {isNe ? 'डेलिभरी ठेगाना (फरक भए)' : 'Delivery address (if different)'}
            <input
              value={deliveryAddress}
              onChange={(e) => setDeliveryAddress(e.target.value)}
              className="mt-0.5 w-full px-2 py-2 border border-slate-300 rounded-lg text-sm font-normal"
            />
          </label>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setPriority(priority === 'URGENT' ? 'NORMAL' : 'URGENT')}
            className={`px-3 py-2 rounded-xl text-xs font-bold border-2 flex items-center gap-1.5 ${
              priority === 'URGENT' ? 'bg-rose-600 text-white border-rose-700' : 'bg-white text-slate-700 border-slate-200'
            }`}
          >
            <Zap className="w-4 h-4" />
            {isNe ? 'जरुरी अर्डर' : 'Urgent'}
          </button>
          <label className="px-3 py-2 rounded-xl text-xs font-bold border-2 border-slate-200 bg-white flex items-center gap-1.5 cursor-pointer">
            <Camera className="w-4 h-4" />
            {photo ? (isNe ? 'फोटो बदल्नुहोस्' : 'Change photo') : isNe ? 'फोटो खिच्नुहोस्' : 'Take photo'}
            <input type="file" accept="image/*" capture="environment" className="hidden" onChange={onPhoto} />
          </label>
          {photo && (
            <>
              <img src={photo} alt="" className="h-10 w-10 rounded-lg object-cover border" />
              <button type="button" onClick={() => setPhoto('')} className="text-rose-600">
                <X className="w-4 h-4" />
              </button>
            </>
          )}
        </div>

        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={2}
          placeholder={isNe ? 'थप टिप्पणी (ग्राहकको माग, विशेष शर्त, खेतको साइज आदि)' : 'Notes (special requests, field size...)'}
          className="w-full px-3 py-2 border border-slate-300 rounded-xl text-sm"
        />
      </section>

      {error && <div className="text-sm font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-2">{error}</div>}

      {/* टिपिरहने तल्लो पट्टी */}
      <div className="fixed left-0 right-0 bottom-[60px] lg:bottom-0 lg:left-72 z-40 bg-white border-t-2 border-emerald-600 shadow-2xl px-3 py-2">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center gap-2 justify-between">
          <div>
            <div className="text-[11px] text-slate-500 font-bold">{isNe ? 'अनुमानित जम्मा' : 'Estimated total'}</div>
            <div className="text-lg font-black text-emerald-800 leading-tight">रू. {totals.grandTotal.toLocaleString('en-IN')}</div>
            {advance > 0 && (
              <div className="text-[11px] text-slate-500">
                {isNe ? 'बाँकी' : 'Balance'}: {(totals.grandTotal - advance).toLocaleString('en-IN')}
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={onCancel} className="px-3 py-2.5 text-xs font-bold rounded-xl border border-slate-300 bg-white">
              {isNe ? 'रद्द' : 'Cancel'}
            </button>
            <button
              type="button"
              onClick={() => submit('DRAFT')}
              className="px-3 py-2.5 text-xs font-bold rounded-xl bg-slate-800 text-white flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              {isNe ? 'ड्राफ्ट' : 'Draft'}
            </button>
            <button
              type="button"
              onClick={() => submit('SUBMITTED')}
              className="px-4 py-2.5 text-sm font-black rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5 shadow"
            >
              <Send className="w-4 h-4" />
              {isNe ? 'अफिसमा पठाउनुहोस्' : 'Submit order'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
