import React, { useMemo, useState } from 'react';
import { Plus, Trash2, Edit2, X, Save, FlaskConical, Copy, AlertTriangle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BillOfMaterial, BomLine } from '../types';
import { bomBatchCost, bomRequirements } from '../utils/bomUtils';
import { getTodayBsString } from '../utils/nepaliCalendar';

const emptyBom = (n: number): BillOfMaterial => ({
  id: `bom-${Date.now()}`,
  code: `BOM-${String(n + 1).padStart(3, '0')}`,
  productNameNe: '',
  productNameEn: '',
  outputQty: 100,
  outputUnit: 'Kg',
  lines: [],
  expectedYieldPercent: 95,
  laborCostPerBatch: 0,
  electricityCostPerBatch: 0,
  otherCostPerBatch: 0,
  workersRequired: 2,
  qcChecklist: ['तौल / परिमाण ठीक', 'रङ्ग तथा बनावट', 'प्याकिङ सिल / लेबल'],
  isActive: true,
  createdDateBs: getTodayBsString()
});

export const BomManagementScreen: React.FC = () => {
  const { boms, saveBom, deleteBom, rawMaterials, items, machines, language } = useApp();
  const isNe = language === 'ne';
  const [form, setForm] = useState<BillOfMaterial | null>(null);
  const [qcText, setQcText] = useState('');
  const [err, setErr] = useState('');
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    const t = search.trim().toLowerCase();
    return boms.filter((b) => !t || [b.productNameNe, b.productNameEn, b.code].some((f) => (f || '').toLowerCase().includes(t)));
  }, [boms, search]);

  const open = (b: BillOfMaterial) => {
    setForm(b);
    setQcText((b.qcChecklist || []).join('\n'));
    setErr('');
  };

  const setLine = (idx: number, patch: Partial<BomLine>) => {
    if (!form) return;
    const lines = [...form.lines];
    lines[idx] = { ...lines[idx], ...patch };
    setForm({ ...form, lines });
  };

  const addLine = () => {
    if (!form) return;
    const used = new Set(form.lines.map((l) => l.materialId));
    const m = rawMaterials.find((r) => !used.has(r.id)) || rawMaterials[0];
    if (!m) {
      setErr(isNe ? 'पहिले कच्चा पदार्थ स्टकमा कच्चा पदार्थ थप्नुहोस्।' : 'Add raw materials first.');
      return;
    }
    setForm({
      ...form,
      lines: [...form.lines, { materialId: m.id, materialName: m.nameNe, unit: m.unit, qtyPerBatch: 1, wastagePercent: 0 }]
    });
  };

  const save = () => {
    if (!form) return;
    if (!form.productNameNe.trim()) return setErr(isNe ? 'उत्पादनको नाम चाहिन्छ।' : 'Product name required.');
    if (!(form.outputQty > 0)) return setErr(isNe ? 'आधार ब्याचको परिमाण शून्यभन्दा बढी हुनुपर्छ।' : 'Base batch qty must be > 0.');
    if (form.lines.length === 0) return setErr(isNe ? 'कम्तीमा एउटा कच्चा पदार्थ थप्नुहोस्।' : 'Add at least one material.');
    if (form.lines.some((l) => !(l.qtyPerBatch > 0))) return setErr(isNe ? 'सबै कच्चा पदार्थको परिमाण राख्नुहोस्।' : 'Enter quantity for all materials.');
    saveBom({
      ...form,
      productNameEn: form.productNameEn.trim() || form.productNameNe.trim(),
      qcChecklist: qcText.split('\n').map((s) => s.trim()).filter(Boolean)
    });
    setForm(null);
  };

  const inp = 'w-full px-2.5 py-2 border border-slate-300 rounded-lg text-sm';
  const lbl = 'text-[11px] font-bold text-slate-600';
  const cost = form ? bomBatchCost(form, rawMaterials) : null;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-purple-600" />
            {isNe ? 'उत्पादन सूत्र (BOM / Recipe)' : 'Bill of Materials (Recipe)'}
          </h2>
          <p className="text-xs text-slate-500">
            {isNe
              ? 'एउटा सामान बनाउन कुन कच्चा पदार्थ कति चाहिन्छ, लागत, समय, कामदार र गुणस्तर जाँच बुँदा यहाँ राख्नुहोस्'
              : 'Materials, cost, time, workers and QC checklist per product'}
          </p>
        </div>
        <div className="flex gap-2">
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={isNe ? 'खोज्नुहोस्' : 'Search'} className="px-3 py-2 border border-slate-300 rounded-xl text-sm" />
          <button onClick={() => open(emptyBom(boms.length))} className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-sm font-black rounded-xl flex items-center gap-1.5">
            <Plus className="w-4 h-4" />
            {isNe ? 'नयाँ सूत्र' : 'New BOM'}
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center text-sm text-slate-400 py-12 bg-white border border-dashed border-slate-300 rounded-2xl">
          {isNe ? 'अहिलेसम्म कुनै उत्पादन सूत्र छैन।' : 'No BOM yet.'}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {filtered.map((b) => {
            const c = bomBatchCost(b, rawMaterials);
            const reqs = bomRequirements(b, b.outputQty, rawMaterials);
            const short = reqs.filter((r) => r.shortage > 0).length;
            return (
              <div key={b.id} className={`bg-white border rounded-2xl p-3 ${b.isActive ? 'border-slate-200' : 'border-slate-200 opacity-60'}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-[11px] font-mono text-slate-500">{b.code}</div>
                    <div className="font-black text-slate-900 truncate">{b.productNameNe}</div>
                    <div className="text-[11px] text-slate-500">
                      {isNe ? 'आधार ब्याच' : 'Base batch'}: {b.outputQty} {b.outputUnit} · {b.lines.length} {isNe ? 'कच्चा पदार्थ' : 'materials'}
                      {b.standardHoursPerBatch ? ` · ${b.standardHoursPerBatch} ${isNe ? 'घण्टा' : 'hr'}` : ''}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-sm font-black text-emerald-800">रू. {c.perUnit.toLocaleString('en-IN')}</div>
                    <div className="text-[10px] text-slate-500">/ {b.outputUnit}</div>
                  </div>
                </div>
                <div className="mt-2 text-[11px] text-slate-600 space-y-0.5">
                  {b.lines.slice(0, 4).map((l) => (
                    <div key={l.materialId} className="flex justify-between">
                      <span>{l.materialName}</span>
                      <span>
                        {l.qtyPerBatch} {l.unit}
                        {l.wastagePercent ? ` (+${l.wastagePercent}%)` : ''}
                      </span>
                    </div>
                  ))}
                  {b.lines.length > 4 && <div className="text-slate-400">+ {b.lines.length - 4} {isNe ? 'अन्य' : 'more'}</div>}
                </div>
                {short > 0 && (
                  <div className="mt-2 text-[11px] font-bold text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-2 py-1 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {isNe ? `एक ब्याचका लागि ${short} कच्चा पदार्थको स्टक नपुग` : `${short} material(s) short for one batch`}
                  </div>
                )}
                <div className="mt-2 flex gap-1.5">
                  <button onClick={() => open(b)} className="px-2.5 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg flex items-center gap-1">
                    <Edit2 className="w-3.5 h-3.5" />
                    {isNe ? 'सच्याउनुहोस्' : 'Edit'}
                  </button>
                  <button
                    onClick={() =>
                      open({ ...b, id: `bom-${Date.now()}`, code: `BOM-${String(boms.length + 1).padStart(3, '0')}`, productNameNe: b.productNameNe + ' (प्रतिलिपि)' })
                    }
                    className="px-2.5 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg flex items-center gap-1"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    {isNe ? 'कपी' : 'Copy'}
                  </button>
                  <button onClick={() => saveBom({ ...b, isActive: !b.isActive })} className="px-2.5 py-1.5 text-xs font-bold bg-white border border-slate-300 rounded-lg">
                    {b.isActive ? (isNe ? 'निष्क्रिय गर्नुहोस्' : 'Deactivate') : isNe ? 'सक्रिय गर्नुहोस्' : 'Activate'}
                  </button>
                  <button onClick={() => deleteBom(b.id)} className="px-2 py-1.5 text-xs text-rose-600 border border-rose-200 rounded-lg ml-auto">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {form && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl my-auto max-h-[94vh] flex flex-col">
            <div className="px-4 py-3 bg-slate-900 text-white rounded-t-2xl flex items-center justify-between">
              <h3 className="font-black text-sm">{isNe ? 'उत्पादन सूत्र (BOM)' : 'Bill of Materials'} — {form.code}</h3>
              <button onClick={() => setForm(null)}>
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 space-y-4 overflow-y-auto text-xs">
              <section className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <label className={lbl + ' sm:col-span-3'}>
                  {isNe ? 'तयारी सामान (इन्भेन्टरीबाट छान्नुहोस्)' : 'Finished item (from inventory)'}
                  <select
                    value={form.productItemId || ''}
                    onChange={(e) => {
                      const it = items.find((i) => i.id === e.target.value);
                      setForm({
                        ...form,
                        productItemId: e.target.value || undefined,
                        productNameNe: it ? it.nameNe : form.productNameNe,
                        productNameEn: it ? it.nameEn : form.productNameEn,
                        outputUnit: it ? it.unit : form.outputUnit
                      });
                    }}
                    className={inp + ' mt-0.5 bg-white font-normal'}
                  >
                    <option value="">{isNe ? '-- नयाँ वा अन्य --' : '-- none --'}</option>
                    {items.map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.nameNe} ({i.unit})
                      </option>
                    ))}
                  </select>
                </label>
                <label className={lbl}>
                  {isNe ? 'उत्पादनको नाम (नेपाली) *' : 'Product name (NE) *'}
                  <input value={form.productNameNe} onChange={(e) => setForm({ ...form, productNameNe: e.target.value })} className={inp + ' mt-0.5 font-bold'} />
                </label>
                <label className={lbl}>
                  Product name (EN)
                  <input value={form.productNameEn} onChange={(e) => setForm({ ...form, productNameEn: e.target.value })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'सूत्र कोड' : 'Code'}
                  <input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} className={inp + ' mt-0.5 font-mono font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'आधार ब्याचले बनाउने परिमाण *' : 'Base batch output *'}
                  <input type="number" min={0} value={form.outputQty} onChange={(e) => setForm({ ...form, outputQty: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'एकाइ' : 'Unit'}
                  <input value={form.outputUnit} onChange={(e) => setForm({ ...form, outputUnit: e.target.value })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'अपेक्षित उपज (Yield) %' : 'Expected yield %'}
                  <input type="number" min={0} max={100} value={form.expectedYieldPercent ?? ''} onChange={(e) => setForm({ ...form, expectedYieldPercent: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                </label>
              </section>

              <section className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-slate-900 text-sm">{isNe ? 'कच्चा पदार्थ (आधार ब्याचका लागि)' : 'Materials (for base batch)'}</h4>
                  <button onClick={addLine} className="px-3 py-1.5 bg-emerald-600 text-white rounded-lg font-bold flex items-center gap-1">
                    <Plus className="w-3.5 h-3.5" />
                    {isNe ? 'थप्नुहोस्' : 'Add'}
                  </button>
                </div>
                {form.lines.map((l, idx) => {
                  const mat = rawMaterials.find((r) => r.id === l.materialId);
                  return (
                    <div key={idx} className="grid grid-cols-12 gap-1.5 items-end bg-slate-50 border border-slate-200 rounded-xl p-2">
                      <label className={lbl + ' col-span-12 sm:col-span-5'}>
                        {isNe ? 'कच्चा पदार्थ' : 'Material'}
                        <select
                          value={l.materialId}
                          onChange={(e) => {
                            const m = rawMaterials.find((r) => r.id === e.target.value);
                            setLine(idx, { materialId: e.target.value, materialName: m?.nameNe || '', unit: m?.unit || l.unit });
                          }}
                          className={inp + ' mt-0.5 bg-white font-normal'}
                        >
                          {rawMaterials.map((r) => (
                            <option key={r.id} value={r.id}>
                              {r.nameNe} · {isNe ? 'स्टक' : 'stock'} {r.currentStock} {r.unit}
                            </option>
                          ))}
                        </select>
                      </label>
                      <label className={lbl + ' col-span-5 sm:col-span-3'}>
                        {isNe ? 'परिमाण' : 'Qty'} ({l.unit})
                        <input type="number" min={0} step="any" value={l.qtyPerBatch} onChange={(e) => setLine(idx, { qtyPerBatch: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                      </label>
                      <label className={lbl + ' col-span-5 sm:col-span-3'}>
                        {isNe ? 'खेर %' : 'Waste %'}
                        <input type="number" min={0} step="any" value={l.wastagePercent || 0} onChange={(e) => setLine(idx, { wastagePercent: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                      </label>
                      <button onClick={() => setForm({ ...form, lines: form.lines.filter((_, i) => i !== idx) })} className="col-span-2 sm:col-span-1 p-2 text-rose-600 flex justify-center">
                        <Trash2 className="w-4 h-4" />
                      </button>
                      {mat && mat.unit !== l.unit && (
                        <div className="col-span-12 text-[10px] text-amber-700">
                          ⚠ {isNe ? `स्टकको एकाइ ${mat.unit} छ, यहाँ ${l.unit} — एकाइ मिलाउनुहोस्` : `Stock unit is ${mat.unit}`}
                        </div>
                      )}
                    </div>
                  );
                })}
              </section>

              <section className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <label className={lbl}>
                  {isNe ? 'ज्याला / ब्याच (रू.)' : 'Labour / batch'}
                  <input type="number" min={0} value={form.laborCostPerBatch || 0} onChange={(e) => setForm({ ...form, laborCostPerBatch: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'बिजुली / ब्याच (रू.)' : 'Electricity / batch'}
                  <input type="number" min={0} value={form.electricityCostPerBatch || 0} onChange={(e) => setForm({ ...form, electricityCostPerBatch: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'अन्य खर्च / ब्याच' : 'Other / batch'}
                  <input type="number" min={0} value={form.otherCostPerBatch || 0} onChange={(e) => setForm({ ...form, otherCostPerBatch: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'चाहिने कामदार' : 'Workers needed'}
                  <input type="number" min={0} value={form.workersRequired || 0} onChange={(e) => setForm({ ...form, workersRequired: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'सामान्य मेसिन' : 'Usual machine'}
                  <select
                    value={form.machineId || ''}
                    onChange={(e) => {
                      const m = machines.find((x) => x.id === e.target.value);
                      setForm({ ...form, machineId: e.target.value || undefined, machineName: m?.nameNe });
                    }}
                    className={inp + ' mt-0.5 bg-white font-normal'}
                  >
                    <option value="">--</option>
                    {machines.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.nameNe}
                      </option>
                    ))}
                  </select>
                </label>
                <label className={lbl}>
                  {isNe ? 'मानक समय (घण्टा)' : 'Std hours / batch'}
                  <input type="number" min={0} step="any" value={form.standardHoursPerBatch || 0} onChange={(e) => setForm({ ...form, standardHoursPerBatch: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'प्याकेट साइज' : 'Pack size'}
                  <input value={form.packetSize || ''} onChange={(e) => setForm({ ...form, packetSize: e.target.value })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'म्याद (दिन)' : 'Shelf life (days)'}
                  <input type="number" min={0} value={form.shelfLifeDays || 0} onChange={(e) => setForm({ ...form, shelfLifeDays: Number(e.target.value) })} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl + ' col-span-2 sm:col-span-4'}>
                  {isNe ? 'प्याकिङ प्रकार' : 'Packaging type'}
                  <input value={form.packagingType || ''} onChange={(e) => setForm({ ...form, packagingType: e.target.value })} className={inp + ' mt-0.5 font-normal'} />
                </label>
              </section>

              <section className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <label className={lbl}>
                  {isNe ? 'गुणस्तर जाँच बुँदा (एक लाइनमा एक)' : 'QC checklist (one per line)'}
                  <textarea value={qcText} onChange={(e) => setQcText(e.target.value)} rows={5} className={inp + ' mt-0.5 font-normal'} />
                </label>
                <label className={lbl}>
                  {isNe ? 'उत्पादन विधि / चरणहरू' : 'Process steps'}
                  <textarea value={form.processSteps || ''} onChange={(e) => setForm({ ...form, processSteps: e.target.value })} rows={5} className={inp + ' mt-0.5 font-normal'} />
                </label>
              </section>

              {cost && (
                <div className="bg-slate-900 text-white rounded-xl p-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                  <div>
                    <div className="text-[10px] text-slate-400">{isNe ? 'कच्चा पदार्थ' : 'Materials'}</div>
                    <div className="font-black">{cost.material.toLocaleString('en-IN')}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">{isNe ? 'ज्याला/बिजुली/अन्य' : 'Labour etc.'}</div>
                    <div className="font-black">{cost.other.toLocaleString('en-IN')}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">{isNe ? 'ब्याच लागत' : 'Batch cost'}</div>
                    <div className="font-black text-amber-300">{cost.total.toLocaleString('en-IN')}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">
                      {isNe ? 'प्रति' : 'Per'} {form.outputUnit}
                    </div>
                    <div className="font-black text-emerald-300">रू. {cost.perUnit.toLocaleString('en-IN')}</div>
                  </div>
                </div>
              )}

              {err && <div className="text-sm font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-2">{err}</div>}
            </div>

            <div className="px-4 py-3 border-t flex justify-end gap-2">
              <button onClick={() => setForm(null)} className="px-4 py-2 text-sm font-bold border border-slate-300 rounded-xl">
                {isNe ? 'रद्द' : 'Cancel'}
              </button>
              <button onClick={save} className="px-5 py-2 text-sm font-black bg-purple-600 text-white rounded-xl flex items-center gap-1.5">
                <Save className="w-4 h-4" />
                {isNe ? 'सेभ गर्नुहोस्' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
