import React, { useState, useMemo } from 'react';
import {
  X,
  Share2,
  MessageSquare,
  Copy,
  Check,
  Send,
  Phone,
  QrCode,
  Building2,
  FileDown,
  Users,
  Loader2,
  Smartphone,
  Search
} from 'lucide-react';
import {
  shareViaWhatsApp,
  shareViaSms,
  copyMessageToClipboard,
  triggerNativeWebShare,
  cleanPhoneNumber,
  sharePdfFileViaWebShareOrWhatsApp
} from '../utils/shareUtils';
import { BankAccount } from '../types';
import { useApp } from '../context/AppContext';
import { QRCodeSVG } from 'qrcode.react';

interface UniversalShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  recipientName?: string;
  initialPhone?: string;
  message: string;
  bankDetails?: BankAccount;
  onGeneratePdfFile?: () => Promise<File | null>;
  pdfLabel?: string;
}

export const UniversalShareModal: React.FC<UniversalShareModalProps> = ({
  isOpen,
  onClose,
  title,
  recipientName,
  initialPhone = '',
  message,
  bankDetails,
  onGeneratePdfFile,
  pdfLabel = 'PDF बिल / रिपोर्ट'
}) => {
  const { parties, invoices } = useApp();

  const [phone, setPhone] = useState(initialPhone);
  const [selectedCustomerLabel, setSelectedCustomerLabel] = useState(recipientName || '');
  const [customerSearch, setCustomerSearch] = useState('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  // Build deduplicated directory of customers with phone numbers stored in the database (parties + invoices)
  const storedCustomerContacts = useMemo(() => {
    const map = new Map<
      string,
      { id: string; name: string; phone: string; address?: string; type: string }
    >();

    parties.forEach((p) => {
      if (p.phone && p.phone.trim()) {
        const key = `${p.name.trim().toLowerCase()}_${cleanPhoneNumber(p.phone)}`;
        map.set(key, {
          id: p.id,
          name: p.name,
          phone: p.phone.trim(),
          address: p.address,
          type: p.partyType === 'SUPPLIER' ? 'सप्लायर' : 'ग्राहक'
        });
      }
    });

    invoices.forEach((inv) => {
      if (inv.customerPhone && inv.customerPhone.trim()) {
        const key = `${inv.customerName.trim().toLowerCase()}_${cleanPhoneNumber(inv.customerPhone)}`;
        if (!map.has(key)) {
          map.set(key, {
            id: inv.id,
            name: inv.customerName,
            phone: inv.customerPhone.trim(),
            address: inv.customerAddress,
            type: 'बिल ग्राहक'
          });
        }
      }
    });

    return Array.from(map.values());
  }, [parties, invoices]);

  const filteredContacts = useMemo(() => {
    if (!customerSearch.trim()) return storedCustomerContacts;
    const q = customerSearch.toLowerCase();
    return storedCustomerContacts.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        cleanPhoneNumber(c.phone).includes(q) ||
        (c.address && c.address.toLowerCase().includes(q))
    );
  }, [storedCustomerContacts, customerSearch]);

  // Sync initialPhone or lookup recipientName in database when modal opens
  React.useEffect(() => {
    if (!isOpen) return;
    if (initialPhone && initialPhone.trim()) {
      setPhone(initialPhone.trim());
      setSelectedCustomerLabel(recipientName || '');
      return;
    }
    if (recipientName && recipientName.trim()) {
      const matched = storedCustomerContacts.find(
        (c) => c.name.trim().toLowerCase() === recipientName.trim().toLowerCase()
      );
      if (matched) {
        setPhone(matched.phone);
        setSelectedCustomerLabel(matched.name);
        return;
      }
    }
    setPhone(initialPhone || '');
    setSelectedCustomerLabel(recipientName || '');
  }, [isOpen, initialPhone, recipientName, storedCustomerContacts]);

  if (!isOpen) return null;

  const showTempFeedback = (msg: string) => {
    setShareFeedback(msg);
    setTimeout(() => setShareFeedback(null), 4000);
  };

  const handleCopy = async () => {
    const ok = await copyMessageToClipboard(message);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleWhatsAppText = () => {
    shareViaWhatsApp(phone, message);
    showTempFeedback('WhatsApp च्याट (wa.me) खोलिएको छ !');
  };

  const handleSms = () => {
    shareViaSms(phone, message);
  };

  const handleSharePdfViaWhatsApp = async (preferDirectWhatsAppNumber: boolean) => {
    if (!onGeneratePdfFile) {
      shareViaWhatsApp(phone, message);
      return;
    }
    try {
      setIsGeneratingPdf(true);
      const pdfFile = await onGeneratePdfFile();
      setIsGeneratingPdf(false);

      const res = await sharePdfFileViaWebShareOrWhatsApp({
        title,
        message,
        phone,
        pdfFile,
        preferDirectWhatsAppNumber
      });

      if (res.status === 'SHARED_FILE_NATIVE') {
        showTempFeedback('✓ Web Share API मार्फत PDF फाइल र सन्देश साझा गरियो !');
      } else if (res.status === 'DOWNLOADED_AND_OPENED_WAME') {
        showTempFeedback('✓ PDF डाउनलोड भयो र ग्राहकको WhatsApp (wa.me) च्याट खुल्यो !');
      } else {
        showTempFeedback('WhatsApp च्याट खुल्यो !');
      }
    } catch (e) {
      console.error('Error sharing PDF:', e);
      setIsGeneratingPdf(false);
      shareViaWhatsApp(phone, message);
    }
  };

  const handleNativeWebShare = async () => {
    if (onGeneratePdfFile) {
      await handleSharePdfViaWhatsApp(false);
      return;
    }
    const ok = await triggerNativeWebShare({
      title,
      text: message
    });
    if (!ok) {
      shareViaWhatsApp(phone, message);
    }
  };

  const formattedWhatsappNumber = cleanPhoneNumber(phone);

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-slate-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/20 text-emerald-300 rounded-lg">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base leading-tight">{title}</h3>
              {(selectedCustomerLabel || recipientName) && (
                <p className="text-xs text-emerald-200/90">
                  ग्राहक / पार्टी: <span className="font-semibold text-white">{selectedCustomerLabel || recipientName}</span>
                </p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-300 hover:text-white p-1 rounded-lg hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1 text-slate-800">
          
          {/* Customer Phone Selector from Database + Manual Input */}
          <div className="space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between gap-2">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-700" />
                <span>ग्राहकको WhatsApp / मोबाइल नम्बर:</span>
              </label>
              <button
                type="button"
                onClick={() => setShowCustomerDropdown((prev) => !prev)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-900 text-[11px] font-bold transition cursor-pointer"
              >
                <Users className="w-3.5 h-3.5" />
                <span>
                  {showCustomerDropdown
                    ? 'सूची बन्द गर्नुहोस्'
                    : `डाटाबेसबाट ग्राहक छान्नुहोस् (${storedCustomerContacts.length})`}
                </span>
              </button>
            </div>

            {/* Searchable Database Customer Phone Picker */}
            {showCustomerDropdown && (
              <div className="bg-white border border-emerald-300 rounded-xl p-2.5 shadow-md space-y-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={customerSearch}
                    onChange={(e) => setCustomerSearch(e.target.value)}
                    placeholder="ग्राहकको नाम वा फोन नम्बर खोज्नुहोस्..."
                    className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-600"
                  />
                </div>
                <div className="max-h-40 overflow-y-auto divide-y divide-slate-100">
                  {filteredContacts.length === 0 ? (
                    <div className="text-center py-3 text-xs text-slate-400">
                      कुनै ग्राहकको फोन नम्बर भेटिएन
                    </div>
                  ) : (
                    filteredContacts.map((c) => (
                      <button
                        key={`${c.id}_${c.phone}`}
                        type="button"
                        onClick={() => {
                          setPhone(c.phone);
                          setSelectedCustomerLabel(c.name);
                          setShowCustomerDropdown(false);
                        }}
                        className="w-full text-left px-2.5 py-1.5 hover:bg-emerald-50 flex items-center justify-between gap-2 transition cursor-pointer rounded-md"
                      >
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-800 truncate">
                            {c.name}{' '}
                            <span className="text-[10px] font-normal text-slate-500">({c.type})</span>
                          </div>
                          {c.address && (
                            <div className="text-[10px] text-slate-500 truncate">{c.address}</div>
                          )}
                        </div>
                        <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 shrink-0">
                          📞 {c.phone}
                        </span>
                      </button>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Phone Input Box */}
            <div className="relative">
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="९८xxxxxxxx (१० अंकको मोबाइल नम्बर)"
                className="w-full pl-3 pr-28 py-2 bg-white border border-slate-300 rounded-xl text-sm font-mono font-bold focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 outline-none"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-mono font-bold px-2 py-0.5 rounded-full">
                  {formattedWhatsappNumber ? `+${formattedWhatsappNumber}` : 'नेपाल +977'}
                </span>
              </div>
            </div>
          </div>

          {/* Primary PDF + WhatsApp / Web Share Actions */}
          {onGeneratePdfFile && (
            <div className="p-3 bg-emerald-50/90 border border-emerald-300 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-emerald-950 flex items-center gap-1.5">
                  <FileDown className="w-4 h-4 text-emerald-700" />
                  <span>{pdfLabel} प्रत्यक्ष पठाउनुहोस् (PDF + WhatsApp):</span>
                </span>
                <span className="text-[10px] font-bold bg-emerald-200/80 text-emerald-900 px-2 py-0.5 rounded-full">
                  Web Share / wa.me
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {/* 1. Direct WhatsApp wa.me to Customer Number + Auto PDF Download */}
                <button
                  type="button"
                  disabled={isGeneratingPdf}
                  onClick={() => handleSharePdfViaWhatsApp(true)}
                  className="flex items-center justify-center gap-2 px-3 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  {isGeneratingPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4 text-emerald-200" />
                  )}
                  <span>PDF + ग्राहकको WhatsApp मा</span>
                </button>

                {/* 2. Web Share API with PDF File Attachment */}
                <button
                  type="button"
                  disabled={isGeneratingPdf}
                  onClick={() => handleSharePdfViaWhatsApp(false)}
                  className="flex items-center justify-center gap-2 px-3 py-2.5 bg-teal-700 hover:bg-teal-800 disabled:opacity-60 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  {isGeneratingPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Smartphone className="w-4 h-4 text-teal-200" />
                  )}
                  <span>Web Share (PDF फाइल शेयर)</span>
                </button>
              </div>
            </div>
          )}

          {/* Direct WhatsApp Text (wa.me) & SMS Buttons */}
          <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
            {/* WhatsApp Text via wa.me */}
            <button
              type="button"
              onClick={handleWhatsAppText}
              className="flex items-center justify-center gap-2 px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer group"
            >
              <Send className="w-4 h-4 text-emerald-100 group-hover:scale-110 transition" />
              <span>WhatsApp सन्देश (wa.me)</span>
            </button>

            {/* Native SMS / Message */}
            <button
              type="button"
              onClick={handleSms}
              className="flex items-center justify-center gap-2 px-3.5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer group"
            >
              <MessageSquare className="w-4 h-4 text-blue-200 group-hover:scale-110 transition" />
              <span>SMS / Message मा</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {/* Copy Message */}
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center justify-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold border border-slate-300 transition cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700">कपी भयो !</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-600" />
                  <span>सन्देश कपी गर्नुहोस्</span>
                </>
              )}
            </button>

            {/* Bank QR Toggle or Native Share */}
            <button
              type="button"
              onClick={() => {
                if (bankDetails) {
                  setShowQr(!showQr);
                } else {
                  handleNativeWebShare();
                }
              }}
              className="flex items-center justify-center gap-2 px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-xl text-xs font-bold border border-amber-300 transition cursor-pointer"
            >
              <QrCode className="w-3.5 h-3.5 text-amber-700" />
              <span>{showQr ? 'QR बन्द गर्नुहोस्' : 'बैंक QR हेर्ने'}</span>
            </button>
          </div>

          {shareFeedback && (
            <div className="px-3 py-2 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-950 text-xs font-bold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>{shareFeedback}</span>
            </div>
          )}

          {/* Bank QR details preview if toggled */}
          {showQr && bankDetails && (
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center gap-3">
              <div className="bg-white p-2 rounded-lg border border-emerald-300 shrink-0">
                <QRCodeSVG
                  value={`Bank:${bankDetails.bankName};Acc:${bankDetails.accountNumber};Name:${bankDetails.accountHolder}`}
                  size={72}
                />
              </div>
              <div className="text-xs space-y-0.5">
                <div className="font-bold text-emerald-950 flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{bankDetails.bankName}</span>
                </div>
                <div className="font-mono text-slate-700">खाता: {bankDetails.accountNumber}</div>
                <div className="text-slate-600">खातावाला: {bankDetails.accountHolder}</div>
                <div className="text-[10px] text-emerald-700 font-semibold">
                  ग्राहकले मोबाइल बैंकिङबाट सिधै स्क्यान गरी तिर्न सक्नुहुन्छ
                </div>
              </div>
            </div>
          )}

          {/* Formatted Message Preview */}
          <div>
            <div className="flex items-center justify-between text-xs font-bold text-slate-600 mb-1">
              <span>पठाइने सन्देशको प्रिभ्यु (Message Preview):</span>
              <span className="text-[10px] font-mono text-slate-400">
                {message.length} अक्षरहरू
              </span>
            </div>
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 whitespace-pre-wrap max-h-44 overflow-y-auto leading-relaxed shadow-inner">
              {message}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            WhatsApp (wa.me) वा Web Share API मार्फत तुरुन्तै पठाउनुहोस्
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs rounded-lg transition cursor-pointer"
          >
            बन्द गर्नुहोस्
          </button>
        </div>

      </div>
    </div>
  );
};
