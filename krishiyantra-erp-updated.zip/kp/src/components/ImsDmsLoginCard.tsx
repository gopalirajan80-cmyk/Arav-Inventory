import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Clock,
  ShieldCheck,
  Building2,
  X,
  Key
} from 'lucide-react';

interface ImsDmsLoginCardProps {
  onSuccess?: () => void;
  onSwitchToRegister?: () => void;
  onSwitchToAdmin?: () => void;
  showCloseButton?: boolean;
  onClose?: () => void;
}

export const ImsDmsLoginCard: React.FC<ImsDmsLoginCardProps> = ({
  onSuccess,
  onSwitchToRegister,
  onSwitchToAdmin,
  showCloseButton = false,
  onClose
}) => {
  const { loginWithMobile, language, companyAccounts } = useApp();
  const isNe = language === 'ne';

  const [usernameOrMobile, setUsernameOrMobile] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'pending'; message: string } | null>(null);
  const [showForgotModal, setShowForgotModal] = useState(false);

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (!usernameOrMobile.trim()) {
      setFeedback({
        type: 'error',
        message: isNe ? 'कृपया आफ्नो युजरनेम वा मोबाइल नम्बर प्रविष्ट गर्नुहोस्।' : 'Please enter your username or mobile number.'
      });
      return;
    }

    // Role is NOT chosen by user - it was pre-set by Owner in companyAccounts
    const res = loginWithMobile(usernameOrMobile, password);

    if (res.success) {
      setFeedback({
        type: 'success',
        message: res.message
      });
      setTimeout(() => {
        if (onSuccess) onSuccess();
      }, 700);
    } else {
      const isPending = res.message.includes('Pending Admin Approval') || res.message.includes('स्वीकृतिको पर्खाइमा');
      setFeedback({
        type: isPending ? 'pending' : 'error',
        message: res.message
      });
    }
  };

  const handleQuickFill = (mobile: string, pin: string) => {
    setUsernameOrMobile(mobile);
    setPassword(pin);
    setFeedback(null);
  };

  const pendingAccounts = companyAccounts.filter((a) => a.status === 'PENDING_APPROVAL');

  return (
    <div className="relative min-h-[92vh] sm:min-h-[85vh] w-full flex flex-col items-center justify-between overflow-hidden bg-slate-50 text-slate-800 select-none">
      
      {/* 1. TOP HEADER: iMS SOFTWARE Brand Logo */}
      <header className="w-full px-6 py-5 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          {/* iMS Diamond 4-facet mark */}
          <div className="w-6 h-6 grid grid-cols-2 gap-0.5 transform -rotate-45 p-0.5">
            <div className="bg-[#2563eb] rounded-xs"></div>
            <div className="bg-[#0f172a] rounded-xs"></div>
            <div className="bg-[#f59e0b] rounded-xs"></div>
            <div className="bg-[#38bdf8] rounded-xs"></div>
          </div>
          <div className="flex flex-col leading-none pl-1">
            <div className="flex items-baseline font-black tracking-tight">
              <span className="text-sm text-[#0070f3] lowercase font-serif italic">i</span>
              <span className="text-base text-slate-900 font-extrabold tracking-tight">MS</span>
            </div>
            <span className="text-[7px] font-bold tracking-[0.2em] text-slate-600 uppercase">SOFTWARE</span>
          </div>
        </div>

        {showCloseButton && onClose && (
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-200/60 transition cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </header>

      {/* 2. BACKGROUND VECTOR WAVES: Recreating the curved blue backdrop from the screenshot */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {/* Large deep blue wave on bottom right */}
        <div className="absolute -bottom-32 -right-32 w-[420px] h-[420px] sm:w-[540px] sm:h-[540px] rounded-full bg-[#1d4ed8] opacity-90 blur-none"></div>
        {/* Lighter cyan blue inner curve */}
        <div className="absolute -bottom-16 -right-16 w-[320px] h-[320px] sm:w-[420px] sm:h-[420px] rounded-full bg-[#2563eb] opacity-85"></div>
        {/* Subtle decorative golden wave ribbon */}
        <div className="absolute -bottom-10 right-44 w-16 h-48 sm:h-64 rounded-full bg-gradient-to-t from-amber-400 to-amber-300 opacity-80 transform rotate-12"></div>
        {/* Bottom soft gradient glow */}
        <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-blue-700/20 to-transparent"></div>
      </div>

      {/* 3. CENTER FLOATING CARD (Matches uploaded screenshot precisely) */}
      <div className="relative z-10 w-full max-w-[390px] px-4 my-auto">
        <div className="bg-white rounded-[28px] shadow-[0_15px_50px_-10px_rgba(0,0,0,0.12)] border border-slate-100 p-7 sm:p-9 transition-all">
          
          {/* Top Circular Logo with Blue Border */}
          <div className="flex justify-center">
            <div className="w-[84px] h-[84px] rounded-full border-[3px] border-[#0070f3] bg-white flex flex-col items-center justify-center shadow-xs">
              {/* iMS Diamond 4-facet mark inside circle */}
              <div className="w-6 h-6 grid grid-cols-2 gap-0.5 transform -rotate-45 p-0.5">
                <div className="bg-[#2563eb] rounded-xs"></div>
                <div className="bg-[#0f172a] rounded-xs"></div>
                <div className="bg-[#f59e0b] rounded-xs"></div>
                <div className="bg-[#38bdf8] rounded-xs"></div>
              </div>
              <div className="flex flex-col items-center leading-none mt-1">
                <div className="flex items-baseline font-black tracking-tight">
                  <span className="text-[11px] text-[#0070f3] lowercase font-serif italic">i</span>
                  <span className="text-xs text-slate-900 font-extrabold tracking-tight">MS</span>
                </div>
                <span className="text-[5px] font-bold tracking-[0.18em] text-slate-500 uppercase">SOFTWARE</span>
              </div>
            </div>
          </div>

          {/* Heading */}
          <h1 className="text-[22px] sm:text-2xl font-bold text-slate-800 text-center mt-5 tracking-tight">
            Welcome to DMS
          </h1>

          {/* Subtitle */}
          <p className="text-[11px] sm:text-xs text-slate-400 font-medium text-center mt-1">
            Powered By IMS Software
          </p>

          {/* Login Form */}
          <form onSubmit={handleSignIn} className="mt-6 space-y-3.5">
            
            {/* Login ID / Mobile input */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                {isNe ? 'लग-इन आइडी (मोबाइल नम्बर)' : 'Login ID (Mobile Number)'}
              </label>
              <input
                type="text"
                autoFocus
                required
                value={usernameOrMobile}
                onChange={(e) => setUsernameOrMobile(e.target.value)}
                placeholder={isNe ? 'मोबाइल नम्बर (उदा: 9855012345)' : 'Mobile Number / Login ID'}
                className="w-full px-4 py-3 rounded-lg border border-slate-300 text-sm text-slate-800 placeholder-slate-400 bg-white focus:outline-none focus:border-[#0070f3] focus:ring-1 focus:ring-[#0070f3] transition font-mono"
              />
            </div>

            {/* Password / PIN input with eye toggle */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                {isNe ? 'पासवर्ड / पिन (Password / PIN)' : 'Password / PIN'}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={isNe ? 'पासवर्ड वा पिन कोड' : 'Password / PIN'}
                  className="w-full pl-4 pr-11 py-3 rounded-lg border border-slate-300 text-sm text-slate-800 placeholder-slate-400 bg-white focus:outline-none focus:border-[#0070f3] focus:ring-1 focus:ring-[#0070f3] transition font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800 p-1 cursor-pointer"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Feedback alert */}
            {feedback && (
              <div
                className={`p-2.5 rounded-lg border text-xs flex items-start gap-2 animate-fadeIn ${
                  feedback.type === 'success'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                    : feedback.type === 'pending'
                    ? 'bg-amber-50 border-amber-300 text-amber-950'
                    : 'bg-rose-50 border-rose-300 text-rose-950'
                }`}
              >
                {feedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : feedback.type === 'pending' ? (
                  <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                )}
                <div className="flex-1">
                  <p className="font-semibold leading-snug">{feedback.message}</p>
                  {feedback.type === 'pending' && onSwitchToAdmin && (
                    <button
                      type="button"
                      onClick={onSwitchToAdmin}
                      className="mt-1.5 text-[11px] font-bold text-amber-900 underline hover:text-amber-950 cursor-pointer block"
                    >
                      👉 एडमिन प्यानलमा गई खाता स्वीकृत गर्नुहोस्
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Sign In Button */}
            <button
              type="submit"
              className="w-full bg-[#0070f3] hover:bg-[#0060df] text-white font-medium py-3 rounded-lg text-sm transition shadow-sm cursor-pointer mt-2 active:scale-[0.99]"
            >
              Sign In
            </button>

            {/* Forgot Password? Link */}
            <div className="text-center pt-1">
              <button
                type="button"
                onClick={() => setShowForgotModal(true)}
                className="text-xs text-slate-700 hover:text-[#0070f3] font-medium transition cursor-pointer"
              >
                Forgot Password?
              </button>
            </div>
          </form>

          {/* Unified Single Master Link & 1-Click Master Control Box */}
          <div className="mt-5 pt-4 border-t border-slate-200 space-y-3 text-xs">
            <div className="p-3.5 rounded-2xl bg-slate-900 text-white space-y-2.5 shadow-lg border border-slate-800">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <span className="font-extrabold text-amber-300 text-xs block">
                    👑 मुख्य मास्टर लिंक (All-in-One Master Control Link)
                  </span>
                  <span className="text-[10px] text-slate-300">
                    सबै फिचर (बिलिङ, काम अनुसार हाजिरी, भ्याट खाता, एक्सेल, स्टक र स्टाफ कन्ट्रोल) एकै ठाउँबाट
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(
                      'https://ais-pre-4wcnbnzz5cmaf6s6n5ud5c-301709447959.asia-southeast1.run.app'
                    );
                    setFeedback({
                      type: 'success',
                      message: '✓ मुख्य मास्टर लिंक कपी भयो! (Copied Master Link)'
                    });
                  }}
                  className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg font-extrabold text-[11px] cursor-pointer shrink-0 shadow-xs"
                >
                  📋 Copy Master Link
                </button>
              </div>

              <input
                type="text"
                readOnly
                value="https://ais-pre-4wcnbnzz5cmaf6s6n5ud5c-301709447959.asia-southeast1.run.app"
                onClick={(e) => (e.target as HTMLInputElement).select()}
                className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-[11px] font-mono text-emerald-300 select-all"
              />
            </div>
          </div>

        </div>
      </div>

      {/* 5. BOTTOM BAR NAVIGATION / COPYRIGHT */}
      <footer className="w-full text-center py-3 text-[11px] text-slate-400 z-10">
        © 2026 iMS Software. All rights reserved.
      </footer>


      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl p-5 border border-slate-200 text-xs space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <span className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Key className="w-4 h-4 text-[#0070f3]" />
                <span>पासवर्ड / गोप्य कोड बिर्सनुभयो?</span>
              </span>
              <button onClick={() => setShowForgotModal(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-slate-600 leading-relaxed">
              कर्मचारीको पद र गोप्य कोड <strong>मालिक (Owner)</strong> ले मात्र तोक्ने वा सच्याउने व्यवस्था गरिएको छ।
            </p>
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 space-y-1">
              <p className="font-bold">सम्पर्क तथा रिसेट प्रक्रिया:</p>
              <p className="text-[11px]">
                आफ्नो मोबाइल नम्बर र नयाँ गोप्य कोडका लागि आफ्नो फर्मको मालिक वा मुख्य एडमिन (फोन: <strong>९८४५०१२३९९</strong>) सँग सम्पर्क गर्नुहोस्।
              </p>
            </div>
            <button
              onClick={() => setShowForgotModal(false)}
              className="w-full py-2 bg-[#0070f3] text-white font-bold rounded-lg cursor-pointer hover:bg-blue-700 transition"
            >
              बुझेँ (OK)
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
