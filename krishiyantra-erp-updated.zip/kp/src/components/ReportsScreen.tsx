import { InvoicePrintOptions, printArgsFor } from './InvoicePrintOptions';
import { printPage } from '../utils/printHelper';
import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  Tag,
  Calendar,
  Banknote,
  TrendingUp,
  Users,
  Wallet,
  Landmark,
  UserCheck,
  Package,
  Layers,
  Building2,
  DollarSign,
  ChevronRight,
  ChevronDown,
  ArrowLeft,
  Search,
  Filter,
  Download,
  Printer,
  Plus,
  X,
  CheckCircle,
  AlertCircle,
  MapPin,
  ArrowUpRight,
  ArrowDownLeft,
  FileSpreadsheet,
  Clock,
  Sparkles,
  PieChart,
  ShieldCheck,
  Receipt,
  FileText,
  Share2,
  MessageSquare,
  Send
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { formatCurrency, toNepaliDigits, getTodayBsString } from '../utils/nepaliCalendar';
import { exportCustomerDuesReportToExcel, exportSalesBookToExcel } from '../utils/excelEngine';
import {
  exportReportToExcel,
  printOrDownloadReportPdf,
  generateReportPdfFile,
  buildUnifiedBankStatement,
  exportAllReportsWorkbookToExcel
} from '../utils/pdfReportExporter';
import { ItemCategory } from '../types';
import { ExpenseAnalysisReport } from './ExpenseAnalysisReport';
import { FinancialStatementsScreen } from './reports/FinancialStatementsScreen';
import { UniversalShareModal } from './UniversalShareModal';
import { buildReportShareMessage, buildCustomerStatementMessage, sharePdfFileViaWebShareOrWhatsApp } from '../utils/shareUtils';

export type ReportType =
  | 'SALES_REPORT'
  | 'DAY_BOOK'
  | 'ALL_TRANSACTIONS'
  | 'PROFIT_LOSS'
  | 'PARTY_STATEMENT'
  | 'CASH_IN_HAND'
  | 'BANK_STATEMENT'
  | 'STAFF_REPORT'
  | 'TRANSACTIONS_REPORT'
  | 'PARTIES_REPORT'
  | 'INVENTORY_REPORT'
  | 'INCOME_EXPENSE'
  | 'BUSINESS_STATUS'
  | 'EXPENSE_ANALYSIS'
  | 'DAILY_OPERATIONS_SUMMARY'
  | 'FINANCIAL_STATEMENTS';

interface ReportMenuItem {
  id: ReportType;
  titleEn: string;
  titleNe: string;
  subtitleEn: string;
  subtitleNe: string;
  icon: React.ElementType;
  isNew?: boolean;
  isPopular?: boolean;
}

const REPORT_MENU_ITEMS: ReportMenuItem[] = [
  // 1. Popular Reports (as shown in Screenshot 1)
  {
    id: 'SALES_REPORT',
    titleEn: 'Sales Report',
    titleNe: 'बिक्री रिपोर्ट',
    subtitleEn: 'Invoices, VAT/Non-VAT breakdown and sales registers',
    subtitleNe: 'बीजक, भ्याट र नन-भ्याट बिक्री विवरण',
    icon: Tag,
    isPopular: true
  },
  {
    id: 'DAY_BOOK',
    titleEn: 'Day Book',
    titleNe: 'डे बुक (दैनिक खाता)',
    subtitleEn: 'Chronological daily receipts, payments & counter cash',
    subtitleNe: 'दैनिक आम्दानी, भुक्तानी तथा काउन्टर विवरण',
    icon: Calendar,
    isPopular: true
  },
  {
    id: 'ALL_TRANSACTIONS',
    titleEn: 'All Transactions Report',
    titleNe: 'सबै कारोबार विवरण',
    subtitleEn: 'Unified audit ledger of sales, receipts, payments & expenses',
    subtitleNe: 'बिक्री, असुली, भुक्तानी तथा खर्चको पूर्ण लेजर',
    icon: Banknote,
    isPopular: true
  },
  {
    id: 'PROFIT_LOSS',
    titleEn: 'Profit & Loss Report',
    titleNe: 'नाफा-नोक्सान हिसाब (P&L)',
    subtitleEn: 'Sales revenue, COGS, operating costs and net profitability',
    subtitleNe: 'कुल आम्दानी, सामान खरिद लागत र खुद नाफा',
    icon: TrendingUp,
    isNew: true,
    isPopular: true
  },
  {
    id: 'PARTY_STATEMENT',
    titleEn: 'Party Statement',
    titleNe: 'पार्टी खाता स्टेटमेन्ट',
    subtitleEn: 'Customer & supplier debit/credit transaction ledger',
    subtitleNe: 'ग्राहक तथा आपूर्तिकर्ताको व्यक्तिगत हिसाब लेजर',
    icon: Users,
    isPopular: true
  },
  {
    id: 'CASH_IN_HAND',
    titleEn: 'Cash In Hand Statement',
    titleNe: 'काउन्टर नगद हिसाब विवरण',
    subtitleEn: 'Counter drawer cash opening, inflows, outflows & net cash',
    subtitleNe: 'काउन्टर सुरु नगद, आजको संकलन र मौज्दात हिसाब',
    icon: Wallet,
    isPopular: true
  },
  {
    id: 'BANK_STATEMENT',
    titleEn: 'Bank Statement',
    titleNe: 'बैंक स्टेटमेन्ट तथा मौज्दात',
    subtitleEn: 'Bank accounts live balances, QR/FonePay deposits & transfers',
    subtitleNe: 'बैंक मौज्दात, QR/FonePay दाखिला र भुक्तानी विवरण',
    icon: Landmark,
    isPopular: true
  },
  {
    id: 'STAFF_REPORT',
    titleEn: 'Staff Report',
    titleNe: 'कर्मचारी तथा पेस्की रिपोर्ट',
    subtitleEn: 'Attendance, staff purchases deducted from salary & advances',
    subtitleNe: 'हाजिरी, सामान खरिद कट्टी, पेस्की र तलब भुक्तानी',
    icon: UserCheck,
    isNew: true,
    isPopular: true
  },

  // 2. Additional Reports (as shown in Screenshot 2)
  {
    id: 'TRANSACTIONS_REPORT',
    titleEn: 'Transactions Report',
    titleNe: 'कारोबार सारांश रिपोर्ट',
    subtitleEn: 'Category-wise volume analysis of business transactions',
    subtitleNe: 'कारोबारको प्रकार तथा माध्यम अनुसारको सारांश',
    icon: Receipt,
    isPopular: false
  },
  {
    id: 'PARTIES_REPORT',
    titleEn: 'Parties Report',
    titleNe: 'पार्टी/ग्राहक बाँकी रिपोर्ट',
    subtitleEn: 'Address-wise receivables & supplier payables summary',
    subtitleNe: 'ठेगाना अनुसार उठाउनुपर्ने र तिर्नुपर्ने बाँकी रकम',
    icon: Users,
    isPopular: false
  },
  {
    id: 'INCOME_EXPENSE',
    titleEn: 'Income Expense Report',
    titleNe: 'आम्दानी तथा खर्च रिपोर्ट',
    subtitleEn: 'Operating revenue vs supplier costs and staff outlays',
    subtitleNe: 'कुल व्यापारिक आम्दानी र सम्पूर्ण खर्चको हिसाब',
    icon: DollarSign,
    isPopular: false
  },
  {
    id: 'BUSINESS_STATUS',
    titleEn: 'Business Status Report',
    titleNe: 'समग्र व्यापार स्थिति (Balance Sheet)',
    subtitleEn: 'Executive health, net worth, total assets and liabilities',
    subtitleNe: 'कुल सम्पत्ति, दायित्व, बैंक मौज्दात र खुद पूँजी',
    icon: Building2,
    isPopular: false
  },
  {
    id: 'EXPENSE_ANALYSIS',
    titleEn: 'Expense Analysis',
    titleNe: 'खर्च विश्लेषण',
    subtitleEn: 'Monthly breakdown of daily expenses and spending trends',
    subtitleNe: 'मासिक खर्च विवरण र खर्च गर्ने प्रवृत्ति',
    icon: PieChart,
    isPopular: true
  },
  {
    id: 'DAILY_OPERATIONS_SUMMARY',
    titleEn: 'Daily Operations Summary',
    titleNe: 'दैनिक कार्य सारांश',
    subtitleEn: 'Total sales, purchases, and staff attendance for the day',
    subtitleNe: 'आजको बिक्री, खरिद र हाजिरीको सारांश',
    icon: FileText,
    isNew: true,
    isPopular: true
  },
  {
    id: 'FINANCIAL_STATEMENTS',
    titleEn: 'Financial Statements',
    titleNe: 'वित्तीय विवरणहरू (NFRS)',
    subtitleEn: 'Full balance sheet, cash flow and audit-ready reports',
    subtitleNe: 'वासलात, नगद प्रवाह र अडिट-योग्य प्रतिवेदन',
    icon: FileText,
    isNew: true,
    isPopular: true
  }
];

export const ReportsScreen: React.FC = () => {
  const {
    parties,
    invoices,
    purchases,
    bankAccounts,
    partyTransactions,
    dailyCash,
    items,
    employees,
    attendance,
    employeeLedger,
    expenses,
    rawMaterials,
    productionBatches,
    company,
    fiscalYearsList,
    recordCustomerCollection,
    recordPartyPayment,
    recordManualBankEntry,
    saveBankAccount,
    setActiveTab,
    reportSubTab,
    setReportSubTab,
    language
  } = useApp();

  const isNe = language === 'ne';
  const todayBs = getTodayBsString();

  const [reportToast, setReportToast] = useState<string | null>(null);
  const showReportToast = (msg: string) => {
    setReportToast(msg);
    setTimeout(() => setReportToast(null), 3200);
  };

  // Selected report screen state (null means master menu)
  const [selectedReport, setSelectedReport] = useState<ReportType | null>(
    reportSubTab ? (reportSubTab as ReportType) : null
  );

  React.useEffect(() => {
    if (reportSubTab) {
      setSelectedReport(reportSubTab as ReportType);
    } else {
      setSelectedReport(null);
    }
  }, [reportSubTab]);

  // Search filter inside master menu
  const [menuSearchQuery, setMenuSearchQuery] = useState('');

  // Date filters across reports ('ALL' | 'TODAY' | 'MONTH')
  const [datePeriod, setDatePeriod] = useState<'ALL' | 'TODAY' | 'MONTH'>('ALL');

  // Day Book specific dropdown filters (All / Today / Months / Year / Fiscal Year)
  const [dayBookPeriodMode, setDayBookPeriodMode] = useState<'ALL' | 'TODAY' | 'MONTH' | 'SPECIFIC_DATE'>('ALL');
  const [dayBookMonthBs, setDayBookMonthBs] = useState<string>('ALL');
  const [dayBookSpecificDateBs, setDayBookSpecificDateBs] = useState<string>(todayBs);
  const [dayBookYearOrFy, setDayBookYearOrFy] = useState<string>('ALL');
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [shareTitle, setShareTitle] = useState<string>('');
  const [shareMessage, setShareMessage] = useState<string>('');
  const [shareRecipientName, setShareRecipientName] = useState<string>('');
  const [shareRecipientPhone, setShareRecipientPhone] = useState<string>('');
  const [isSharingReportPdf, setIsSharingReportPdf] = useState<boolean>(false);

  // Party Statement & Parties Report specific filters (matching screenshot: Party Dropdown, Period Picker, PDF With Item)
  const [selectedPartyId, setSelectedPartyId] = useState<string>(parties[0]?.id || '');
  const [selectedPartiesReportPartyId, setSelectedPartiesReportPartyId] = useState<string>('ALL');
  const [pdfWithItem, setPdfWithItem] = useState<boolean>(false);
  const [isPartyDropdownOpen, setIsPartyDropdownOpen] = useState<boolean>(false);
  const [partyDropdownSearch, setPartyDropdownSearch] = useState<string>('');
  const [isPeriodDropdownOpen, setIsPeriodDropdownOpen] = useState<boolean>(false);

  // Bank Statement specific filters (Daily, Monthly, Yearly, Custom Date Range)
  const [selectedBankId, setSelectedBankId] = useState<string>('ALL');
  const [bankFilterMode, setBankFilterMode] = useState<'ALL' | 'DAILY' | 'MONTHLY' | 'YEARLY' | 'CUSTOM'>('ALL');
  const [bankDailyDateBs, setBankDailyDateBs] = useState<string>(todayBs);
  const [bankMonthYearBs, setBankMonthYearBs] = useState<string>(todayBs.substring(0, 7));
  const [bankYearBs, setBankYearBs] = useState<string>(todayBs.substring(0, 4));
  const [bankCustomFromBs, setBankCustomFromBs] = useState<string>(`${todayBs.substring(0, 4)}-01-01`);
  const [bankCustomToBs, setBankCustomToBs] = useState<string>(todayBs);

  // Manual Bank Transaction Entry state
  const [manualBankId, setManualBankId] = useState<string>(bankAccounts[0]?.id || '');
  const [manualBankType, setManualBankType] = useState<'DEPOSIT' | 'WITHDRAWAL' | 'INTEREST' | 'BANK_CHARGE'>('DEPOSIT');
  const [manualBankAmount, setManualBankAmount] = useState<number>(0);
  const [manualBankDateBs, setManualBankDateBs] = useState<string>(todayBs);
  const [manualBankRef, setManualBankRef] = useState<string>('');
  const [manualBankParticulars, setManualBankParticulars] = useState<string>('');

  // Inventory Report specific filters
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [stockStatusFilter, setStockStatusFilter] = useState<'ALL' | 'LOW' | 'OUT'>('ALL');

  // Parties Report address, timeframe, date range, amount & payment status filters
  const [addressFilter, setAddressFilter] = useState<string>('ALL');
  const [partyTypeFilter, setPartyTypeFilter] = useState<'ALL' | 'CUSTOMER' | 'SUPPLIER'>('ALL');
  const [partiesSearchQuery, setPartiesSearchQuery] = useState('');
  const [partyTimeframeMode, setPartyTimeframeMode] = useState<'ALL' | 'DAILY' | 'MONTHLY' | 'YEARLY' | 'CUSTOM_RANGE'>('ALL');
  const [partyDailyDateBs, setPartyDailyDateBs] = useState<string>(todayBs);
  const [partySelectedMonthBs, setPartySelectedMonthBs] = useState<string>(todayBs.substring(5, 7));
  const [partySelectedYearBs, setPartySelectedYearBs] = useState<string>('ALL');
  const [partyDateFromBs, setPartyDateFromBs] = useState<string>(`${todayBs.substring(0, 4)}-01-01`);
  const [partyDateToBs, setPartyDateToBs] = useState<string>(todayBs);
  const [partyMinAmount, setPartyMinAmount] = useState<string>('');
  const [partyMaxAmount, setPartyMaxAmount] = useState<string>('');
  const [partyPaymentStatusFilter, setPartyPaymentStatusFilter] = useState<
    'ALL' | 'UNPAID_DUE' | 'PARTIAL_PAID' | 'SETTLED_PAID'
  >('ALL');

  // Sales & Transactions Advanced Filters (Search, Date Range, Amount Range, Payment Status, Address)
  const [reportAdvSearch, setReportAdvSearch] = useState<string>('');
  const [reportAdvAddress, setReportAdvAddress] = useState<string>('ALL');
  const [reportAdvDateFromBs, setReportAdvDateFromBs] = useState<string>('');
  const [reportAdvDateToBs, setReportAdvDateToBs] = useState<string>('');
  const [reportAdvMinAmount, setReportAdvMinAmount] = useState<string>('');
  const [reportAdvMaxAmount, setReportAdvMaxAmount] = useState<string>('');
  const [reportAdvPaymentStatus, setReportAdvPaymentStatus] = useState<
    'ALL' | 'PAID' | 'PARTIAL' | 'CREDIT_UNPAID' | 'CASH' | 'BANK_FONEPAY'
  >('ALL');

  // Modals state
  const [collectionModalParty, setCollectionModalParty] = useState<{
    id: string;
    name: string;
    address: string;
    dueAmount: number;
  } | null>(null);
  const [collectionAmount, setCollectionAmount] = useState<number>(0);
  const [collectionMode, setCollectionMode] = useState<'CASH' | 'BANK'>('BANK');
  const [collectionBankId, setCollectionBankId] = useState<string>(bankAccounts[0]?.id || '');
  const [collectionRef, setCollectionRef] = useState<string>('');
  const [collectionNotes, setCollectionNotes] = useState<string>('');

  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [payPartyId, setPayPartyId] = useState<string>(parties[0]?.id || '');
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMode, setPayMode] = useState<'CASH' | 'BANK'>('BANK');
  const [payBankId, setPayBankId] = useState<string>(bankAccounts[0]?.id || '');
  const [payRef, setPayRef] = useState<string>('');
  const [payNotes, setPayNotes] = useState<string>('');

  const [isAddBankModalOpen, setIsAddBankModalOpen] = useState(false);
  const [newBankName, setNewBankName] = useState('');
  const [newAccountNo, setNewAccountNo] = useState('');
  const [newAccountHolder, setNewAccountHolder] = useState(company.name);
  const [newBranch, setNewBranch] = useState('');
  const [newOpeningBal, setNewOpeningBal] = useState(0);

  // Helper function to export any data to Excel
  const exportGenericToExcel = (headers: string[], rows: (string | number)[][], fileName: string) => {
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    XLSX.utils.book_append_sheet(wb, ws, 'Report');
    XLSX.writeFile(wb, `${fileName}_${todayBs}.xlsx`);
  };

  // Helper function to export any data to CSV with UTF-8 BOM for Devanagari script compatibility
  const exportGenericToCsv = (headers: string[], rows: (string | number | undefined | null)[][], fileName: string) => {
    const formatCell = (cell: string | number | undefined | null): string => {
      if (cell === null || cell === undefined) return '""';
      const str = String(cell).replace(/"/g, '""');
      return `"${str}"`;
    };

    const csvLines = [
      headers.map(formatCell).join(','),
      ...rows.map((row) => row.map(formatCell).join(','))
    ].join('\r\n');

    // UTF-8 BOM (\uFEFF) ensures Devanagari text renders correctly in Excel & accounting tools
    const blob = new Blob(['\uFEFF' + csvLines], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${fileName}_${todayBs}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // -------------------------------------------------------------
  // Calculations: Totals & KPIs
  // -------------------------------------------------------------
  const totalReceivables = parties.reduce(
    (sum, p) => sum + (p.currentBalance !== undefined ? p.currentBalance : p.openingBalance),
    0
  );

  const totalBankBalance = bankAccounts.reduce((sum, b) => sum + b.currentBalance, 0);

  const totalSalesRevenue = invoices
    .filter((inv) => inv.status === 'ACTIVE')
    .reduce((sum, inv) => sum + inv.grandTotal, 0);

  const totalTodaySales = invoices
    .filter((inv) => inv.status === 'ACTIVE' && inv.dateBs === todayBs)
    .reduce((sum, inv) => sum + inv.grandTotal, 0);

  // Inventory Cost & Retail Valuation
  const totalStockCostValuation = items.reduce(
    (sum, item) => sum + item.purchasePrice * (item.currentStock || 0),
    0
  );
  const totalStockRetailValuation = items.reduce(
    (sum, item) => sum + item.sellingPrice * (item.currentStock || 0),
    0
  );

  // Nepali Months List for Party Filter
  const NEPALI_MONTHS_LIST = [
    { code: '01', nameNe: 'बैशाख (Baisakh)' },
    { code: '02', nameNe: 'जेठ (Jestha)' },
    { code: '03', nameNe: 'असार (Ashadh)' },
    { code: '04', nameNe: 'श्रावण (Shrawan)' },
    { code: '05', nameNe: 'भदौ (Bhadra)' },
    { code: '06', nameNe: 'आश्विन (Ashwin)' },
    { code: '07', nameNe: 'कार्तिक (Kartik)' },
    { code: '08', nameNe: 'मंसिर (Mangsir)' },
    { code: '09', nameNe: 'पुष (Poush)' },
    { code: '10', nameNe: 'माघ (Magh)' },
    { code: '11', nameNe: 'फाल्गुन (Falgun)' },
    { code: '12', nameNe: 'चैत्र (Chaitra)' }
  ];

  // Helper to compute Nepal Fiscal Year (आर्थिक वर्ष e.g. "081/82", "082/83") from a B.S. date string "YYYY-MM-DD"
  const getFiscalYearFromBsDate = (dateBs: string): string => {
    if (!dateBs || dateBs.length < 7) return company.fiscalYear || '081/82';
    const clean = dateBs.trim().replace(/\//g, '-');
    const parts = clean.split('-');
    const yr = parseInt(parts[0], 10);
    const mo = parseInt(parts[1], 10);
    if (Number.isNaN(yr) || Number.isNaN(mo)) return company.fiscalYear || '081/82';
    // In Nepal, Fiscal Year starts on Shrawan 1 (Month 04) and ends on Ashadh end (Month 03 of next BS year)
    if (mo >= 4) {
      const start3 = String(yr).slice(-3);
      const end2 = String(yr + 1).slice(-2);
      return `${start3}/${end2}`;
    } else {
      const start3 = String(yr - 1).slice(-3);
      const end2 = String(yr).slice(-2);
      return `${start3}/${end2}`;
    }
  };

  // Helper to check if a BS date matches a selected Fiscal Year ("081/82") or Calendar BS Year ("2081")
  const doesDateMatchFyOrYear = (dateBs: string, selectedVal: string, recordFy?: string): boolean => {
    if (!selectedVal || selectedVal === 'ALL') return true;
    if (!dateBs) return false;
    if (selectedVal.includes('/')) {
      if (recordFy && recordFy === selectedVal) return true;
      return getFiscalYearFromBsDate(dateBs) === selectedVal;
    }
    return dateBs.startsWith(selectedVal);
  };

  // Available Fiscal Years (आर्थिक वर्षहरू)
  const availableFiscalYears = useMemo(() => {
    const fySet = new Set<string>(['080/81', '081/82', '082/83', '083/84']);
    if (company.fiscalYear) fySet.add(company.fiscalYear);
    (fiscalYearsList || []).forEach((fy) => fySet.add(fy));
    fySet.add(getFiscalYearFromBsDate(todayBs));
    invoices.forEach((inv) => {
      if (inv.fiscalYear) fySet.add(inv.fiscalYear);
      if (inv.dateBs) fySet.add(getFiscalYearFromBsDate(inv.dateBs));
    });
    purchases.forEach((pur) => {
      if (pur.dateBs) fySet.add(getFiscalYearFromBsDate(pur.dateBs));
    });
    partyTransactions.forEach((tx) => {
      if (tx.dateBs) fySet.add(getFiscalYearFromBsDate(tx.dateBs));
    });
    return Array.from(fySet).sort().reverse();
  }, [company.fiscalYear, fiscalYearsList, invoices, purchases, partyTransactions, todayBs]);

  // Unique BS Years present in transactions
  const availableBsYears = useMemo(() => {
    const yearSet = new Set<string>();
    const currY = todayBs.substring(0, 4);
    yearSet.add(currY);
    invoices.forEach((inv) => {
      if (inv.dateBs && inv.dateBs.length >= 4) yearSet.add(inv.dateBs.substring(0, 4));
    });
    purchases.forEach((pur) => {
      if (pur.dateBs && pur.dateBs.length >= 4) yearSet.add(pur.dateBs.substring(0, 4));
    });
    partyTransactions.forEach((tx) => {
      if (tx.dateBs && tx.dateBs.length >= 4) yearSet.add(tx.dateBs.substring(0, 4));
    });
    return Array.from(yearSet).sort().reverse();
  }, [invoices, purchases, partyTransactions, todayBs]);

  // Unified list of all parties (including any customers/suppliers from invoices/purchases not yet in `parties`, and enriching missing addresses)
  const allReportParties = useMemo(() => {
    const result = parties.map((p) => {
      if (p.address && p.address.trim()) return p;
      const matchingInv = invoices.find(
        (inv) =>
          (inv.partyId && inv.partyId === p.id) ||
          (inv.customerName.trim().toLowerCase() === p.name.trim().toLowerCase() && inv.customerAddress?.trim())
      );
      if (matchingInv?.customerAddress?.trim()) {
        return { ...p, address: matchingInv.customerAddress.trim() };
      }
      return p;
    });

    // Also include any invoice customers or purchase suppliers that don't exist in `parties`
    invoices.forEach((inv) => {
      const nameClean = (inv.customerName || '').trim();
      if (!nameClean || nameClean.toLowerCase() === 'cash customer' || nameClean === 'नगद ग्राहक') return;
      const addrClean = (inv.customerAddress || '').trim();
      const exists = result.some((p) => {
        if (inv.partyId && p.id === inv.partyId) return true;
        if (p.name.trim().toLowerCase() !== nameClean.toLowerCase()) return false;
        const pAddr = (p.address || '').trim().toLowerCase();
        if (pAddr && addrClean && pAddr !== addrClean.toLowerCase()) return false;
        return true;
      });
      if (!exists) {
        result.push({
          id: inv.partyId || `inv-party-${nameClean}-${addrClean}`,
          name: nameClean,
          type: 'CUSTOMER',
          phone: inv.customerPhone || '',
          address: addrClean,
          panNo: inv.customerPan || '',
          openingBalance: 0,
          currentBalance: inv.remainingDue || 0
        });
      }
    });

    purchases.forEach((pur) => {
      const nameClean = (pur.supplierName || '').trim();
      if (!nameClean) return;
      const exists = result.some((p) => p.name.trim().toLowerCase() === nameClean.toLowerCase());
      if (!exists) {
        result.push({
          id: `pur-party-${nameClean}`,
          name: nameClean,
          type: 'SUPPLIER',
          phone: '',
          address: '',
          panNo: pur.supplierPan || '',
          openingBalance: 0,
          currentBalance: 0
        });
      }
    });

    return result;
  }, [parties, invoices, purchases]);

  // Keep selectedPartyId always valid when allReportParties updates
  React.useEffect(() => {
    if (allReportParties.length > 0) {
      const exists = allReportParties.some((p) => p.id === selectedPartyId);
      if (!selectedPartyId || !exists) {
        setSelectedPartyId(allReportParties[0].id);
      }
    }
  }, [allReportParties, selectedPartyId]);

  // Unique party addresses list for Address Filter (includes party addresses & invoice customer addresses)
  const partyUniqueAddresses = useMemo(() => {
    const addrSet = new Set<string>();
    allReportParties.forEach((p) => {
      if (p.address && p.address.trim()) {
        addrSet.add(p.address.trim());
      }
    });
    invoices.forEach((inv) => {
      if (inv.customerAddress && inv.customerAddress.trim()) {
        addrSet.add(inv.customerAddress.trim());
      }
    });
    return Array.from(addrSet).sort();
  }, [allReportParties, invoices]);

  // Map to detect duplicate party names (एउटै नाम भएका तर ठेगाना फरक भएका पार्टीहरू पहिचान गर्ने)
  const partyNameCounts = useMemo(() => {
    const counts = new Map<string, number>();
    allReportParties.forEach((p) => {
      const key = p.name.trim().toLowerCase();
      counts.set(key, (counts.get(key) || 0) + 1);
    });
    return counts;
  }, [allReportParties]);

  // Helper to check if an invoice belongs to a specific party (disambiguating same-name parties by partyId or address)
  const doesInvoiceBelongToParty = (inv: typeof invoices[number], party: typeof allReportParties[number]) => {
    if (inv.partyId && !party.id.startsWith('inv-party-')) {
      return inv.partyId === party.id;
    }
    const cleanPartyName = party.name.trim().toLowerCase();
    const cleanInvName = (inv.customerName || '').trim().toLowerCase();
    if (cleanInvName !== cleanPartyName) return false;

    const cleanPartyAddr = (party.address || '').trim().toLowerCase();
    const cleanInvAddr = (inv.customerAddress || '').trim().toLowerCase();
    const isDuplicateName = (partyNameCounts.get(cleanPartyName) || 0) > 1;

    if (isDuplicateName || (cleanPartyAddr && cleanInvAddr)) {
      return cleanInvAddr === cleanPartyAddr;
    }
    return true;
  };

  // Helper to check if a party transaction belongs to a specific party (disambiguating same-name parties by partyId or address)
  const doesTransactionBelongToParty = (tx: typeof partyTransactions[number], party: typeof allReportParties[number]) => {
    if (tx.partyId && !party.id.startsWith('inv-party-')) {
      return tx.partyId === party.id;
    }
    const cleanPartyName = party.name.trim().toLowerCase();
    const cleanTxName = (tx.partyName || '').trim().toLowerCase();
    if (cleanTxName !== cleanPartyName) return false;

    const cleanPartyAddr = (party.address || '').trim().toLowerCase();
    const cleanTxAddr = (tx.partyAddress || '').trim().toLowerCase();
    const isDuplicateName = (partyNameCounts.get(cleanPartyName) || 0) > 1;

    if (isDuplicateName || (cleanPartyAddr && cleanTxAddr)) {
      return cleanTxAddr === cleanPartyAddr;
    }
    return true;
  };

  // Helper to get human-readable period label for the "[ This Month 📅 ]" button
  const getPartyPeriodButtonLabel = () => {
    if (partyTimeframeMode === 'ALL') {
      return partySelectedYearBs === 'ALL'
        ? isNe
          ? 'सबै समय (All Time)'
          : 'All Time'
        : `${isNe ? 'आ.व.' : 'F.Y.'} ${partySelectedYearBs}`;
    }
    if (partyTimeframeMode === 'DAILY') {
      return partyDailyDateBs === todayBs
        ? isNe
          ? `आज (${todayBs})`
          : `Today (${todayBs})`
        : partyDailyDateBs;
    }
    if (partyTimeframeMode === 'MONTHLY') {
      const mObj = NEPALI_MONTHS_LIST.find((m) => m.code === partySelectedMonthBs);
      const isCurrentMonth = partySelectedMonthBs === todayBs.substring(5, 7);
      if (isCurrentMonth && partySelectedYearBs === 'ALL') {
        return 'This Month';
      }
      return mObj ? mObj.nameNe : 'This Month';
    }
    if (partyTimeframeMode === 'YEARLY') {
      return partySelectedYearBs === 'ALL'
        ? isNe
          ? `आ.व. ${company.fiscalYear}`
          : `F.Y. ${company.fiscalYear}`
        : `${isNe ? 'आ.व.' : 'F.Y.'} ${partySelectedYearBs}`;
    }
    if (partyTimeframeMode === 'CUSTOM_RANGE') {
      return `${partyDateFromBs || '...'} → ${partyDateToBs || '...'}`;
    }
    return 'This Month';
  };

  // Unified Party Statement Ledger Builder (includes Opening Balance, Sales Invoices, Purchases, Collections & Payments, plus item details for "PDF With Item")
  const buildPartyStatementRows = (targetParty: typeof allReportParties[number] | undefined) => {
    if (!targetParty) return [];

    const matchTime = (dateStr: string, recordFy?: string) => {
      if (!dateStr) return false;
      if (partySelectedYearBs !== 'ALL' && !doesDateMatchFyOrYear(dateStr, partySelectedYearBs, recordFy)) {
        return false;
      }
      if (partyTimeframeMode === 'DAILY') return dateStr === partyDailyDateBs;
      if (partyTimeframeMode === 'MONTHLY') {
        const clean = dateStr.trim().replace(/\//g, '-');
        const parts = clean.split('-');
        const mo = parts[1] ? parts[1].padStart(2, '0') : '';
        return mo === partySelectedMonthBs;
      }
      if (partyTimeframeMode === 'YEARLY') {
        return partySelectedYearBs === 'ALL' || doesDateMatchFyOrYear(dateStr, partySelectedYearBs, recordFy);
      }
      if (partyTimeframeMode === 'CUSTOM_RANGE') {
        if (partyDateFromBs && dateStr < partyDateFromBs) return false;
        if (partyDateToBs && dateStr > partyDateToBs) return false;
        return true;
      }
      return true;
    };

    const minAmt = partyMinAmount.trim() !== '' ? Number(partyMinAmount) : null;
    const maxAmt = partyMaxAmount.trim() !== '' ? Number(partyMaxAmount) : null;

    interface StatementEntry {
      id: string;
      dateBs: string;
      particulars: string;
      voucherNo: string;
      modeLabel: string;
      statusLabel: string;
      statusType: 'PAID' | 'PARTIAL' | 'DUE' | 'OPENING';
      debit: number;
      credit: number;
      runningBalance: number;
      itemsList: { name: string; qty: number; unit: string; rate: number; amount: number }[];
    }

    const rawEntries: Omit<StatementEntry, 'runningBalance'>[] = [];

    // 1. Opening Balance row (if any)
    if (targetParty.openingBalance && targetParty.openingBalance !== 0 && partyTimeframeMode === 'ALL') {
      rawEntries.push({
        id: `open-${targetParty.id}`,
        dateBs: '-',
        particulars: isNe ? 'सुरुवाती मौज्दात (Opening Balance B/F)' : 'Opening Balance B/F',
        voucherNo: 'OPENING',
        modeLabel: 'Opening',
        statusLabel: isNe ? 'सुरु बाँकी' : 'Opening',
        statusType: 'OPENING',
        debit: targetParty.openingBalance > 0 ? targetParty.openingBalance : 0,
        credit: targetParty.openingBalance < 0 ? Math.abs(targetParty.openingBalance) : 0,
        itemsList: []
      });
    }

    // 2. Sales Invoices
    invoices
      .filter((i) => i.status === 'ACTIVE' && doesInvoiceBelongToParty(i, targetParty) && matchTime(i.dateBs, i.fiscalYear))
      .forEach((inv) => {
        const paid = inv.amountPaid ?? (inv.paymentMode === 'CREDIT' ? 0 : inv.grandTotal);
        const due = inv.remainingDue ?? (inv.paymentMode === 'CREDIT' ? inv.grandTotal : 0);
        rawEntries.push({
          id: inv.id,
          dateBs: inv.dateBs,
          particulars: `${isNe ? 'बिक्री बीजक' : 'Sales Invoice'} (${inv.invoiceNo})`,
          voucherNo: inv.invoiceNo,
          modeLabel: inv.paymentMode,
          statusLabel: due <= 0 ? (isNe ? 'चुक्ता' : 'Paid') : paid > 0 ? (isNe ? 'आंशिक' : 'Partial') : (isNe ? 'बाँकी' : 'Due'),
          statusType: due <= 0 ? 'PAID' : paid > 0 ? 'PARTIAL' : 'DUE',
          debit: inv.grandTotal,
          credit: paid,
          itemsList: (inv.items || []).map((line) => ({
            name: line.name,
            qty: line.quantity,
            unit: line.unit || 'Pcs',
            rate: line.rate,
            amount: line.amount
          }))
        });
      });

    // 3. Purchase Bills (for Supplier or both)
    purchases
      .filter(
        (pur) =>
          pur.supplierName.trim().toLowerCase() === targetParty.name.trim().toLowerCase() &&
          matchTime(pur.dateBs)
      )
      .forEach((pur) => {
        rawEntries.push({
          id: pur.id,
          dateBs: pur.dateBs,
          particulars: `${isNe ? 'खरिद बिल' : 'Purchase Bill'} (${pur.purchaseBillNo})`,
          voucherNo: pur.purchaseBillNo,
          modeLabel: pur.paymentMode,
          statusLabel: pur.paymentMode === 'CREDIT' ? (isNe ? 'उधारो खरिद' : 'Credit') : (isNe ? 'भुक्तानी' : 'Paid'),
          statusType: pur.paymentMode === 'CREDIT' ? 'DUE' : 'PAID',
          debit: pur.paymentMode === 'CREDIT' ? 0 : pur.grandTotal,
          credit: pur.grandTotal,
          itemsList: pur.itemsSummary
            ? [{ name: pur.itemsSummary, qty: 1, unit: 'Lot', rate: pur.grandTotal, amount: pur.grandTotal }]
            : []
        });
      });

    // 4. Party Transactions (Customer Collections & Supplier Payments)
    partyTransactions
      .filter((tx) => doesTransactionBelongToParty(tx, targetParty) && matchTime(tx.dateBs))
      .forEach((tx) => {
        const isCollection = tx.type === 'COLLECTION_FROM_CUSTOMER';
        rawEntries.push({
          id: tx.id,
          dateBs: tx.dateBs,
          particulars: isCollection
            ? `${isNe ? 'ग्राहक रकम असुली' : 'Payment Received'} ${tx.referenceNo ? `(${tx.referenceNo})` : ''}`
            : `${isNe ? 'सप्लायर भुक्तानी' : 'Payment to Supplier'} ${tx.referenceNo ? `(${tx.referenceNo})` : ''}`,
          voucherNo: tx.referenceNo || 'VOUCHER',
          modeLabel: tx.paymentMode === 'BANK' ? tx.bankName || 'Bank' : 'Cash',
          statusLabel: isNe ? 'भौचर' : 'Voucher',
          statusType: 'PAID',
          debit: isCollection ? 0 : tx.amount,
          credit: isCollection ? tx.amount : 0,
          itemsList: []
        });
      });

    // Calculate running balance and apply amount/status filters
    let running = 0;
    const withBalance: StatementEntry[] = rawEntries.map((entry) => {
      running = running + entry.debit - entry.credit;
      return {
        ...entry,
        runningBalance: running
      };
    });

    return withBalance.filter((entry) => {
      const rowAmt = Math.max(entry.debit, entry.credit);
      if (minAmt !== null && !Number.isNaN(minAmt) && rowAmt < minAmt) return false;
      if (maxAmt !== null && !Number.isNaN(maxAmt) && rowAmt > maxAmt) return false;
      if (partyPaymentStatusFilter === 'UNPAID_DUE' && entry.statusType !== 'DUE' && entry.runningBalance <= 0) return false;
      if (partyPaymentStatusFilter === 'PARTIAL_PAID' && entry.statusType !== 'PARTIAL') return false;
      if (partyPaymentStatusFilter === 'SETTLED_PAID' && entry.statusType !== 'PAID') return false;
      return true;
    });
  };

  // Party Report filtered records with period sales/purchases/collections, address disambiguation & advanced filters
  const filteredPartiesWithTotals = useMemo(() => {
    const minAmt = partyMinAmount.trim() !== '' ? Number(partyMinAmount) : null;
    const maxAmt = partyMaxAmount.trim() !== '' ? Number(partyMaxAmount) : null;

    return allReportParties
      .filter((p) => {
        // Specific Party Dropdown filter in PARTIES_REPORT
        if (selectedPartiesReportPartyId && selectedPartiesReportPartyId !== 'ALL') {
          if (p.id !== selectedPartiesReportPartyId) return false;
        }

        // Party Type Filter
        if (partyTypeFilter === 'CUSTOMER' && p.type && p.type !== 'CUSTOMER') return false;
        if (partyTypeFilter === 'SUPPLIER' && p.type && p.type !== 'SUPPLIER') return false;

        // Address Filter (ठेगाना अनुसार)
        if (addressFilter && addressFilter !== 'ALL') {
          if (!p.address || !p.address.toLowerCase().includes(addressFilter.toLowerCase())) {
            return false;
          }
        }

        // Search Query (नाम, ठेगाना, फोन, प्यान वा "नाम + ठेगाना" अनुसार)
        if (partiesSearchQuery.trim()) {
          const q = partiesSearchQuery.trim().toLowerCase();
          const combinedNameAddr = `${p.name} ${p.address || ''}`.toLowerCase();
          const matchName = p.name.toLowerCase().includes(q);
          const matchAddress = (p.address || '').toLowerCase().includes(q);
          const matchPhone = (p.phone || '').toLowerCase().includes(q);
          const matchPan = (p.panNo || '').toLowerCase().includes(q);
          const matchCombined = combinedNameAddr.includes(q);
          if (!matchName && !matchAddress && !matchPhone && !matchPan && !matchCombined) return false;
        }

        return true;
      })
      .map((party) => {
        // Timeframe filter check (दैनिक / मासिक / आर्थिक वर्ष / मिति दायरा / सबै)
        const matchTimeframe = (dateBsStr: string, recordFy?: string) => {
          if (!dateBsStr) return false;
          if (partySelectedYearBs !== 'ALL' && !doesDateMatchFyOrYear(dateBsStr, partySelectedYearBs, recordFy)) {
            return false;
          }
          if (partyTimeframeMode === 'DAILY') {
            return dateBsStr === partyDailyDateBs;
          }
          if (partyTimeframeMode === 'MONTHLY') {
            const clean = dateBsStr.trim().replace(/\//g, '-');
            const parts = clean.split('-');
            const mo = parts[1] ? parts[1].padStart(2, '0') : '';
            return mo === partySelectedMonthBs;
          }
          if (partyTimeframeMode === 'YEARLY') {
            return partySelectedYearBs === 'ALL' || doesDateMatchFyOrYear(dateBsStr, partySelectedYearBs, recordFy);
          }
          if (partyTimeframeMode === 'CUSTOM_RANGE') {
            if (partyDateFromBs && dateBsStr < partyDateFromBs) return false;
            if (partyDateToBs && dateBsStr > partyDateToBs) return false;
            return true;
          }
          return true;
        };

        const partyInvs = invoices.filter(
          (i) => i.status === 'ACTIVE' && doesInvoiceBelongToParty(i, party) && matchTimeframe(i.dateBs, i.fiscalYear)
        );

        const partyPurs = purchases.filter(
          (pur) => pur.supplierName.trim().toLowerCase() === party.name.trim().toLowerCase() && matchTimeframe(pur.dateBs)
        );

        const partyTxs = partyTransactions.filter(
          (tx) => doesTransactionBelongToParty(tx, party) && matchTimeframe(tx.dateBs)
        );

        const periodSales = partyInvs.reduce((s, i) => s + i.grandTotal, 0);
        const periodPurchases = partyPurs.reduce((s, p) => s + p.grandTotal, 0);
        const periodCollections =
          partyTxs
            .filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER')
            .reduce((s, t) => s + t.amount, 0) +
          partyInvs.reduce((s, i) => s + (i.amountPaid || 0), 0);
        const periodPayments =
          partyTxs
            .filter((t) => t.type === 'PAYMENT_TO_SUPPLIER')
            .reduce((s, t) => s + t.amount, 0) +
          partyPurs.reduce((s, p) => s + (p.grandTotal || 0), 0);

        const currentDue = party.currentBalance !== undefined ? party.currentBalance : party.openingBalance;
        const isDuplicateName = (partyNameCounts.get(party.name.trim().toLowerCase()) || 0) > 1;

        // Payment Status classification for this party
        const totalPaidEver = (party.paidAmount || 0) + periodCollections + periodPayments;
        let paymentStatus: 'UNPAID_DUE' | 'PARTIAL_PAID' | 'SETTLED_PAID' = 'SETTLED_PAID';
        if (currentDue > 0 && totalPaidEver > 0) {
          paymentStatus = 'PARTIAL_PAID';
        } else if (currentDue > 0) {
          paymentStatus = 'UNPAID_DUE';
        } else {
          paymentStatus = 'SETTLED_PAID';
        }

        return {
          party,
          isDuplicateName,
          salesCount: partyInvs.length,
          purchaseCount: partyPurs.length,
          periodSales,
          periodPurchases,
          periodCollections,
          periodPayments,
          currentDue,
          paymentStatus
        };
      })
      .filter((item) => {
        // Payment Status Filter
        if (partyPaymentStatusFilter === 'UNPAID_DUE' && item.currentDue <= 0) return false;
        if (partyPaymentStatusFilter === 'PARTIAL_PAID' && item.paymentStatus !== 'PARTIAL_PAID') return false;
        if (partyPaymentStatusFilter === 'SETTLED_PAID' && item.currentDue > 0) return false;

        // Amount Range Filter (checks against currentDue or periodSales/periodPurchases)
        const targetAmt = item.currentDue > 0 ? item.currentDue : (item.periodSales || item.periodPurchases || 0);
        if (minAmt !== null && !Number.isNaN(minAmt) && targetAmt < minAmt) return false;
        if (maxAmt !== null && !Number.isNaN(maxAmt) && targetAmt > maxAmt) return false;

        return true;
      });
  }, [
    allReportParties,
    selectedPartiesReportPartyId,
    invoices,
    purchases,
    partyTransactions,
    addressFilter,
    partyTypeFilter,
    partiesSearchQuery,
    partyTimeframeMode,
    partyDailyDateBs,
    partySelectedMonthBs,
    partySelectedYearBs,
    partyDateFromBs,
    partyDateToBs,
    partyMinAmount,
    partyMaxAmount,
    partyPaymentStatusFilter,
    partyNameCounts,
    todayBs
  ]);

  // Profit & Loss and Sales Report calculations with Advanced Filters
  const pnlData = useMemo(() => {
    let filteredInvoices = invoices.filter((i) => i.status === 'ACTIVE');
    if (datePeriod === 'TODAY') {
      filteredInvoices = filteredInvoices.filter((i) => i.dateBs === todayBs);
    } else if (datePeriod === 'MONTH') {
      const currentMonthPrefix = todayBs.substring(0, 7);
      filteredInvoices = filteredInvoices.filter((i) => i.dateBs.startsWith(currentMonthPrefix));
    }

    // Apply Advanced Filters (Search, Address, Date Range, Amount Range, Payment Status)
    if (reportAdvSearch.trim()) {
      const q = reportAdvSearch.trim().toLowerCase();
      filteredInvoices = filteredInvoices.filter(
        (i) =>
          i.customerName.toLowerCase().includes(q) ||
          (i.customerAddress || '').toLowerCase().includes(q) ||
          i.invoiceNo.toLowerCase().includes(q) ||
          (i.customerPan || '').toLowerCase().includes(q) ||
          (i.customerPhone || '').toLowerCase().includes(q) ||
          `${i.customerName} ${i.customerAddress || ''}`.toLowerCase().includes(q)
      );
    }

    if (reportAdvAddress && reportAdvAddress !== 'ALL') {
      filteredInvoices = filteredInvoices.filter((i) =>
        (i.customerAddress || '').toLowerCase().includes(reportAdvAddress.toLowerCase())
      );
    }

    if (reportAdvDateFromBs.trim()) {
      filteredInvoices = filteredInvoices.filter((i) => i.dateBs >= reportAdvDateFromBs.trim());
    }
    if (reportAdvDateToBs.trim()) {
      filteredInvoices = filteredInvoices.filter((i) => i.dateBs <= reportAdvDateToBs.trim());
    }

    const minAmt = reportAdvMinAmount.trim() !== '' ? Number(reportAdvMinAmount) : null;
    const maxAmt = reportAdvMaxAmount.trim() !== '' ? Number(reportAdvMaxAmount) : null;
    if (minAmt !== null && !Number.isNaN(minAmt)) {
      filteredInvoices = filteredInvoices.filter((i) => i.grandTotal >= minAmt);
    }
    if (maxAmt !== null && !Number.isNaN(maxAmt)) {
      filteredInvoices = filteredInvoices.filter((i) => i.grandTotal <= maxAmt);
    }

    if (reportAdvPaymentStatus !== 'ALL') {
      filteredInvoices = filteredInvoices.filter((i) => {
        const due = i.remainingDue ?? (i.paymentMode === 'CREDIT' ? i.grandTotal : 0);
        const paid = i.amountPaid ?? (i.paymentMode === 'CREDIT' ? 0 : i.grandTotal);
        if (reportAdvPaymentStatus === 'PAID') return due <= 0;
        if (reportAdvPaymentStatus === 'PARTIAL') return due > 0 && paid > 0;
        if (reportAdvPaymentStatus === 'CREDIT_UNPAID') return due > 0;
        if (reportAdvPaymentStatus === 'CASH') return i.paymentMode === 'CASH';
        if (reportAdvPaymentStatus === 'BANK_FONEPAY') return i.paymentMode === 'BANK_FONEPAY';
        return true;
      });
    }

    const revenue = filteredInvoices.reduce((s, i) => s + i.grandTotal, 0);
    const taxableRevenue = filteredInvoices.reduce((s, i) => s + i.taxableAmount, 0);
    const exemptRevenue = filteredInvoices.reduce((s, i) => s + i.exemptAmount, 0);
    const vatCollected = filteredInvoices.reduce((s, i) => s + i.vatAmount, 0);
    const totalDiscounts = filteredInvoices.reduce((s, i) => s + (i.discountAmount || 0), 0);
    const totalFreight = filteredInvoices.reduce((s, i) => s + (i.freightCharge || 0), 0);

    // Calculate COGS (Cost of goods sold)
    let cogs = 0;
    filteredInvoices.forEach((inv) => {
      inv.items.forEach((line) => {
        const product = items.find((p) => p.id === line.itemId || p.code === line.code);
        const costPerUnit = product ? product.purchasePrice : line.rate * 0.75; // fallback 25% margin
        cogs += costPerUnit * line.quantity;
      });
    });

    const grossProfit = taxableRevenue + exemptRevenue - cogs;
    const grossMarginPercent = revenue > 0 ? (grossProfit / (taxableRevenue + exemptRevenue)) * 100 : 0;

    // Staff wages and advances
    const staffExpenses = employeeLedger.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = grossProfit - staffExpenses;

    return {
      invoiceCount: filteredInvoices.length,
      revenue,
      taxableRevenue,
      exemptRevenue,
      vatCollected,
      totalDiscounts,
      totalFreight,
      cogs,
      grossProfit,
      grossMarginPercent,
      staffExpenses,
      netProfit,
      filteredInvoices
    };
  }, [
    invoices,
    items,
    employeeLedger,
    datePeriod,
    todayBs,
    reportAdvSearch,
    reportAdvAddress,
    reportAdvDateFromBs,
    reportAdvDateToBs,
    reportAdvMinAmount,
    reportAdvMaxAmount,
    reportAdvPaymentStatus
  ]);

  // Unified Bank Statement computation (Daily, Monthly, Yearly, Custom Date Range)
  const bankStatementData = useMemo(() => {
    return buildUnifiedBankStatement({
      bankAccounts,
      selectedBankId,
      invoices,
      purchases,
      partyTransactions,
      manualEntries: company.manualBankEntries || [],
      filterMode: bankFilterMode,
      dailyDateBs: bankDailyDateBs,
      monthYearBs: bankMonthYearBs,
      yearBs: bankYearBs,
      customFromBs: bankCustomFromBs,
      customToBs: bankCustomToBs
    });
  }, [
    bankAccounts,
    selectedBankId,
    invoices,
    purchases,
    partyTransactions,
    company.manualBankEntries,
    bankFilterMode,
    bankDailyDateBs,
    bankMonthYearBs,
    bankYearBs,
    bankCustomFromBs,
    bankCustomToBs
  ]);

  // Build structured payload for currently active report (used for Excel, PDF Save/Download, PDF Print, and CSV)
  const getCurrentReportPayload = () => {
    const menuItem = REPORT_MENU_ITEMS.find((r) => r.id === selectedReport);
    const titleNe = menuItem?.titleNe || 'प्रतिवेदन';
    const titleEn = menuItem?.titleEn || 'Report';

    if (selectedReport === 'SALES_REPORT') {
      return {
        titleNe,
        titleEn,
        subtitleNe: `अवधि: ${datePeriod} | कुल बिल: ${pnlData.invoiceCount}`,
        headers: ['क्र.सं.', 'बीजक नं.', 'प्रकार', 'मिति (B.S.)', 'ग्राहकको नाम', 'प्यान नं', 'भुक्तानी माध्यम', 'करयोग्य रकम', '१३% भ्याट', 'कर छुट रकम', 'कुल रकम (Rs.)'],
        rows: pnlData.filteredInvoices.map((inv, idx) => [
          idx + 1,
          inv.invoiceNo,
          inv.billType,
          inv.dateBs,
          inv.customerName,
          inv.customerPan || '-',
          inv.paymentMode,
          inv.taxableAmount,
          inv.vatAmount,
          inv.exemptAmount,
          inv.grandTotal
        ]),
        summaryCards: [
          { label: 'कुल बिक्री', value: formatCurrency(pnlData.revenue, true) },
          { label: 'करयोग्य बिक्री', value: formatCurrency(pnlData.taxableRevenue, true) },
          { label: '१३% भ्याट रकम', value: formatCurrency(pnlData.vatCollected, true) },
          { label: 'कर छुट बिक्री', value: formatCurrency(pnlData.exemptRevenue, true) }
        ],
        fileName: 'Sales_Report'
      };
    }

    if (selectedReport === 'BANK_STATEMENT') {
      const selectedBankObj = bankAccounts.find((b) => b.id === selectedBankId);
      const bankTitle = selectedBankObj
        ? `${selectedBankObj.bankName} (खाता नं: ${selectedBankObj.accountNumber})`
        : 'सबै बैंक खाताहरू (All Bank Accounts)';
      return {
        titleNe: `बैंक स्टेटमेन्ट (${bankTitle})`,
        titleEn: `Bank Statement - ${bankTitle}`,
        subtitleNe: `${bankStatementData.periodLabelNe} | सुरु मौज्दात: रु. ${bankStatementData.openingBalance.toLocaleString()} | अन्तिम मौज्दात: रु. ${bankStatementData.closingBalance.toLocaleString()}`,
        headers: ['क्र.सं.', 'मिति (B.S.)', 'भौचर / Ref', 'बैंक खाता', 'विवरण (Particulars)', 'प्रकार / माध्यम', 'जम्मा रकम (Deposit +)', 'झिकिएको रकम (Withdrawal -)', 'मौज्दात (Balance Rs.)'],
        rows: [
          [
            1,
            '-',
            'OPENING',
            bankTitle,
            'अघिल्लो मौज्दात (Opening Balance B/F)',
            'सुरु मौज्दात',
            bankStatementData.openingBalance,
            0,
            bankStatementData.openingBalance
          ],
          ...bankStatementData.rows.map((r, rIdx) => [
            rIdx + 2,
            r.dateBs,
            r.voucherNo,
            r.bankName,
            r.particulars,
            r.modeLabel,
            r.deposit,
            r.withdrawal,
            r.runningBalance
          ])
        ],
        summaryCards: [
          { label: 'सुरुवाती मौज्दात (Opening)', value: formatCurrency(bankStatementData.openingBalance, true) },
          { label: 'अवधिमा जम्मा (Total Deposit +)', value: formatCurrency(bankStatementData.totalDeposit, true) },
          { label: 'अवधिमा झिकिएको (Withdrawal -)', value: formatCurrency(bankStatementData.totalWithdrawal, true) },
          { label: 'अन्तिम मौज्दात (Closing Bal)', value: formatCurrency(bankStatementData.closingBalance, true) }
        ],
        fileName: `Bank_Statement_${selectedBankObj?.bankName || 'All'}`
      };
    }

    if (selectedReport === 'DAY_BOOK') {
      const matchDayBookDate = (dateBsStr: string, recordFy?: string) => {
        if (!dateBsStr) return false;
        if (dayBookYearOrFy !== 'ALL' && !doesDateMatchFyOrYear(dateBsStr, dayBookYearOrFy, recordFy)) {
          return false;
        }
        if (dayBookPeriodMode === 'TODAY') return dateBsStr === todayBs;
        if (dayBookPeriodMode === 'SPECIFIC_DATE') return dateBsStr === dayBookSpecificDateBs;
        if (dayBookPeriodMode === 'MONTH' && dayBookMonthBs !== 'ALL') {
          const clean = dateBsStr.trim().replace(/\//g, '-');
          const parts = clean.split('-');
          const mo = parts[1] ? parts[1].padStart(2, '0') : '';
          return mo === dayBookMonthBs;
        }
        if (dayBookMonthBs !== 'ALL') {
          const clean = dateBsStr.trim().replace(/\//g, '-');
          const parts = clean.split('-');
          const mo = parts[1] ? parts[1].padStart(2, '0') : '';
          if (mo !== dayBookMonthBs) return false;
        }
        return true;
      };

      const dbInvs = invoices.filter((i) => i.status === 'ACTIVE' && matchDayBookDate(i.dateBs, i.fiscalYear));
      const dbExps = (expenses || []).filter((e) => matchDayBookDate(e.dateBs));
      const dbTxs = partyTransactions.filter((t) => matchDayBookDate(t.dateBs));

      const rawDbRows: (string | number)[][] = [
        ...dbInvs.map((inv) => [
          inv.dateBs,
          inv.time || '-',
          inv.invoiceNo,
          `${inv.customerName}${inv.customerAddress ? ` (📍 ${inv.customerAddress})` : ''}`,
          'बिक्री (Sales)',
          inv.paymentMode,
          inv.grandTotal
        ]),
        ...dbTxs.map((tx) => [
          tx.dateBs,
          '-',
          tx.referenceNo || 'VOUCHER',
          `${tx.partyName}${tx.partyAddress ? ` (📍 ${tx.partyAddress})` : ''}`,
          tx.type === 'COLLECTION_FROM_CUSTOMER' ? 'ग्राहक असुली (+)' : 'पार्टी भुक्तानी (-)',
          tx.paymentMode,
          tx.amount
        ]),
        ...dbExps.map((e) => [
          e.dateBs,
          '-',
          e.voucherNo || 'EXP',
          `${e.category}${e.paidTo ? ` (${e.paidTo})` : ''}`,
          'दैनिक खर्च (Expense -)',
          e.paymentMode,
          e.amount
        ])
      ];

      const rows: (string | number)[][] = rawDbRows.map((r, rIdx) => [rIdx + 1, ...r]);

      return {
        titleNe,
        titleEn,
        subtitleNe: `अवधि: ${dayBookPeriodMode} | आ.व./वर्ष: ${dayBookYearOrFy} | महिना: ${dayBookMonthBs}`,
        headers: ['क्र.सं.', 'मिति (B.S.)', 'समय', 'बीजक / भौचर नं', 'ग्राहक / पार्टी / खर्च विवरण', 'प्रकार', 'भुक्तानी माध्यम', 'रकम (Rs.)'],
        rows,
        summaryCards: [
          { label: 'सुरुवाती नगद', value: formatCurrency(dailyCash.openingCash, true) },
          { label: 'बिक्री रकम (+)', value: formatCurrency(dbInvs.reduce((s, i) => s + i.grandTotal, 0), true) },
          { label: 'दैनिक खर्च (-)', value: formatCurrency(dbExps.reduce((s, e) => s + e.amount, 0), true) },
          { label: 'अन्तिम नगद मौज्दात', value: formatCurrency(dailyCash.closingCashInHand, true) }
        ],
        fileName: 'Day_Book_Report'
      };
    }

    if (selectedReport === 'ALL_TRANSACTIONS') {
      return {
        titleNe,
        titleEn,
        subtitleNe: `कुल कारोबार: ${partyTransactions.length}`,
        headers: ['क्र.सं.', 'मिति (B.S.)', 'प्रकार', 'पार्टी / खाता', 'माध्यम / बैंक', 'Ref No.', 'रकम (Rs.)', 'कैफियत'],
        rows: partyTransactions.map((tx, idx) => [
          idx + 1,
          tx.dateBs,
          tx.type === 'COLLECTION_FROM_CUSTOMER' ? 'ग्राहक असुली (+)' : 'पार्टी भुक्तानी (-)',
          tx.partyName,
          tx.paymentMode,
          tx.referenceNo || '-',
          tx.amount,
          tx.notes || '-'
        ]),
        summaryCards: [],
        fileName: 'All_Transactions_Report'
      };
    }

    if (selectedReport === 'PROFIT_LOSS') {
      return {
        titleNe,
        titleEn,
        subtitleNe: `अवधि: ${datePeriod}`,
        headers: ['क्र.सं.', 'शीर्षक (Particulars)', 'रकम (Rs.)'],
        rows: [
          [1, '१. व्यापारिक आम्दानी (Gross Operating Revenue)', pnlData.taxableRevenue + pnlData.exemptRevenue],
          [2, '२. सामान खरिद लागत (Cost of Goods Sold - COGS)', pnlData.cogs],
          [3, '३. सकल नाफा (Gross Profit)', pnlData.grossProfit],
          [4, '४. कर्मचारी तलब/पेस्की खर्च (Staff Expenses)', pnlData.staffExpenses],
          [5, '५. दिइएको कुल छुट (Total Discounts)', pnlData.totalDiscounts],
          [6, '६. खुद नाफा (Net Operating Profit)', pnlData.netProfit - pnlData.totalDiscounts]
        ],
        summaryCards: [
          { label: 'व्यापारिक आम्दानी', value: formatCurrency(pnlData.taxableRevenue + pnlData.exemptRevenue, true) },
          { label: 'खरिद लागत (COGS)', value: formatCurrency(pnlData.cogs, true) },
          { label: 'सकल नाफा', value: formatCurrency(pnlData.grossProfit, true) },
          { label: 'खुद नाफा', value: formatCurrency(pnlData.netProfit - pnlData.totalDiscounts, true) }
        ],
        fileName: 'Profit_Loss_Report'
      };
    }

    if (selectedReport === 'PARTY_STATEMENT') {
      const party = allReportParties.find((p) => p.id === selectedPartyId) || allReportParties[0];
      const statementEntries = buildPartyStatementRows(party);
      const rowsForPdf: (string | number)[][] = [];

      statementEntries.forEach((entry, idx) => {
        rowsForPdf.push([
          idx + 1,
          entry.dateBs,
          entry.particulars,
          `${entry.modeLabel} (${entry.statusLabel})`,
          entry.debit,
          entry.credit,
          entry.runningBalance
        ]);
        if (pdfWithItem && entry.itemsList.length > 0) {
          entry.itemsList.forEach((it) => {
            rowsForPdf.push([
              '',
              '',
              `   ↳ 📦 ${it.name} (${it.qty} ${it.unit} × रु. ${it.rate})`,
              'सामान विवरण (Item)',
              it.amount,
              0,
              entry.runningBalance
            ]);
          });
        }
      });

      const totalDebit = statementEntries.reduce((s, e) => s + e.debit, 0);
      const totalCredit = statementEntries.reduce((s, e) => s + e.credit, 0);
      const closingBal = statementEntries.length > 0 ? statementEntries[statementEntries.length - 1].runningBalance : 0;

      return {
        titleNe: `पार्टी स्टेटमेन्ट - ${party?.name || ''} ${pdfWithItem ? '(सामान विवरण सहित)' : ''}`,
        titleEn: `Party Statement - ${party?.name || ''} ${pdfWithItem ? '(With Items)' : ''}`,
        subtitleNe: `ठेगाना: ${party?.address || '-'} | फोन: ${party?.phone || '-'} | प्यान: ${party?.panNo || '-'} | अवधि: ${getPartyPeriodButtonLabel()}`,
        headers: ['क्र.सं.', 'मिति (B.S.)', 'विवरण (Particulars)', 'माध्यम / अवस्था', 'डेबिट (+) बिल रकम', 'क्रेडिट (-) बुझाएको', 'बाँकी (Balance)'],
        rows: rowsForPdf,
        summaryCards: [
          { label: 'कुल डेबिट (+)', value: formatCurrency(totalDebit, true) },
          { label: 'कुल क्रेडिट (-)', value: formatCurrency(totalCredit, true) },
          { label: 'अन्तिम बाँकी (Closing Due)', value: formatCurrency(closingBal, true) }
        ],
        fileName: `Party_Statement_${(party?.name || 'Report').replace(/\s+/g, '_')}`
      };
    }

    if (selectedReport === 'CASH_IN_HAND') {
      return {
        titleNe,
        titleEn,
        subtitleNe: `मिति: ${todayBs}`,
        headers: ['क्र.सं.', 'शीर्षक', 'रकम (Rs.)'],
        rows: [
          [1, 'सुरुवाती काउन्टर नगद (Opening Cash)', dailyCash.openingCash],
          [2, '(+) कुल नगद बिक्री असुली (Total Cash Inflow)', dailyCash.totalCashSales],
          [3, '(-) कर्मचारी पेस्की तथा भुक्तानी (Advances / Outflow)', dailyCash.totalAdvancesGiven],
          [4, 'अन्तिम काउन्टर नगद मौज्दात (Closing Cash in Hand)', dailyCash.closingCashInHand]
        ],
        summaryCards: [],
        fileName: 'Cash_In_Hand_Report'
      };
    }

    if (selectedReport === 'STAFF_REPORT') {
      return {
        titleNe,
        titleEn,
        subtitleNe: `कुल कर्मचारी: ${employees.length}`,
        headers: ['क्र.सं.', 'स्टाफ ID', 'कर्मचारीको नाम', 'पद', 'ज्याला प्रकार', 'दर / मासिक तलब', 'आजको हाजिरी', 'सुरुवाती पेस्की / बाँकी'],
        rows: employees.map((emp, idx) => {
          const todayAtt = attendance.find((a) => a.employeeId === emp.id && a.dateBs === todayBs);
          return [
            idx + 1,
            emp.staffCode || emp.id,
            emp.name,
            emp.role,
            emp.wageType || 'MONTHLY',
            emp.wageType === 'DAILY' ? emp.dailyWageRate || 1000 : emp.salaryMonthly,
            todayAtt?.status || 'ABSENT',
            emp.openingDue || 0
          ];
        }),
        summaryCards: [],
        fileName: 'Staff_Report'
      };
    }

    if (selectedReport === 'PARTIES_REPORT') {
      const filteredParties = parties.filter((p) => {
        return (
          p.name.toLowerCase().includes(partiesSearchQuery.toLowerCase()) ||
          p.address?.toLowerCase().includes(partiesSearchQuery.toLowerCase()) ||
          p.phone?.includes(partiesSearchQuery)
        );
      });
      return {
        titleNe,
        titleEn,
        subtitleNe: `कुल पार्टी: ${filteredParties.length}`,
        headers: ['क्र.सं.', 'पार्टी / ग्राहक', 'प्रकार', 'ठेगाना', 'फोन', 'प्यान', 'सुरुवाती बाँकी', 'हाल उठाउन बाँकी'],
        rows: filteredParties.map((p, idx) => {
          const due = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
          return [idx + 1, p.name, p.partyType || 'CUSTOMER', p.address || '-', p.phone || '-', p.panNo || '-', p.openingBalance || 0, due];
        }),
        summaryCards: [],
        fileName: 'Parties_Dues_Report'
      };
    }

    if (selectedReport === 'INVENTORY_REPORT') {
      return {
        titleNe,
        titleEn,
        subtitleNe: `कुल सामान प्रकार: ${items.length}`,
        headers: ['क्र.सं.', 'कोड', 'सामानको नाम', 'क्याटगोरी', 'एकाइ', 'खरिद मूल्य', 'बिक्री मूल्य', 'मौज्दात स्टक', 'भ्याट स्टक', 'नन-भ्याट स्टक', 'कुल लागत मूल्य'],
        rows: items.map((i, idx) => [
          idx + 1,
          i.code,
          isNe ? i.nameNe || i.nameEn : i.nameEn,
          i.category,
          i.unit,
          i.purchasePrice,
          i.sellingPrice,
          i.currentStock,
          i.vatStock || 0,
          i.nonVatStock || 0,
          i.purchasePrice * (i.currentStock || 0)
        ]),
        summaryCards: [
          { label: 'कुल खरिद मूल्याङ्कन', value: formatCurrency(totalStockCostValuation, true) },
          { label: 'खुद्रा मूल्याङ्कन', value: formatCurrency(totalStockRetailValuation, true) }
        ],
        fileName: 'Inventory_Report'
      };
    }

    if (selectedReport === 'INCOME_EXPENSE') {
      return {
        titleNe,
        titleEn,
        subtitleNe: `अवधि: ${datePeriod}`,
        headers: ['क्र.सं.', 'प्रकार', 'शीर्षक', 'रकम (Rs.)'],
        rows: [
          [1, 'आम्दानी (Income)', 'सामान बिक्री (Invoiced Revenue)', pnlData.taxableRevenue + pnlData.exemptRevenue],
          [2, 'खर्च (Expense)', 'सामान खरिद लागत (COGS)', pnlData.cogs],
          [3, 'खर्च (Expense)', 'कर्मचारी तलब तथा पेस्की (Payroll)', pnlData.staffExpenses],
          [4, 'खर्च (Expense)', 'दिइएको छूट (Discounts)', pnlData.totalDiscounts]
        ],
        summaryCards: [],
        fileName: 'Income_Expense_Report'
      };
    }

    // Default: BUSINESS_STATUS or TRANSACTIONS_REPORT
    return {
      titleNe,
      titleEn,
      subtitleNe: `मिति: ${todayBs}`,
      headers: ['क्र.सं.', 'सम्पत्ति / दायित्व शीर्षक', 'रकम (Rs.)'],
      rows: [
        [1, 'काउन्टर नगद मौज्दात', dailyCash.closingCashInHand],
        [2, 'बैंक खाता मौज्दात', totalBankBalance],
        [3, 'ग्राहकबाट उठाउन बाँकी (Receivables)', totalReceivables],
        [4, 'मौज्दात सामानको खरिद मूल्याङ्कन (Inventory Cost)', totalStockCostValuation],
        [5, 'कुल खुद व्यापारिक पूँजी (Net Capital)', dailyCash.closingCashInHand + totalBankBalance + totalReceivables + totalStockCostValuation]
      ],
      summaryCards: [],
      fileName: 'Business_Status_Report'
    };
  };

  const handleExportCurrentReportToCsv = () => {
    const payload = getCurrentReportPayload();
    exportGenericToCsv(payload.headers, payload.rows, payload.fileName);
  };

  const handleExportCurrentReportToExcel = () => {
    const payload = getCurrentReportPayload();
    exportReportToExcel({
      company,
      titleNe: payload.titleNe,
      titleEn: payload.titleEn,
      subtitleNe: payload.subtitleNe,
      headers: payload.headers,
      rows: payload.rows,
      fileName: payload.fileName
    });
  };

  const handleExportCurrentReportToPdf = (mode: 'PRINT' | 'DOWNLOAD') => {
    const payload = getCurrentReportPayload();
    printOrDownloadReportPdf({
      company,
      titleNe: payload.titleNe,
      titleEn: payload.titleEn,
      subtitleNe: payload.subtitleNe,
      headers: payload.headers,
      rows: payload.rows,
      summaryCards: payload.summaryCards,
      fileName: payload.fileName,
      mode
    });
  };

  const handleGenerateCurrentReportPdfFile = async (): Promise<File | null> => {
    const payload = getCurrentReportPayload();
    return await generateReportPdfFile({
      company,
      titleNe: payload.titleNe,
      titleEn: payload.titleEn,
      subtitleNe: payload.subtitleNe,
      headers: payload.headers,
      rows: payload.rows,
      summaryCards: payload.summaryCards,
      fileName: payload.fileName
    });
  };

  const resolveActiveReportParty = () => {
    if (selectedReport === 'PARTY_STATEMENT' && selectedPartyId) {
      return parties.find((p) => p.id === selectedPartyId) || null;
    }
    if (selectedReport === 'PARTIES_REPORT' && selectedPartiesReportPartyId !== 'ALL') {
      return parties.find((p) => p.id === selectedPartiesReportPartyId) || null;
    }
    return null;
  };

  const handleOpenShareReport = () => {
    const payload = getCurrentReportPayload();
    const activeParty = resolveActiveReportParty();
    const periodStr =
      datePeriod === 'TODAY'
        ? `आज (${todayBs})`
        : datePeriod === 'MONTH'
        ? `चालु महिना`
        : `सम्पूर्ण कारोबार`;
    const msg = activeParty
      ? buildCustomerStatementMessage(activeParty, company)
      : buildReportShareMessage(
          payload.titleNe,
          payload.subtitleNe || periodStr,
          payload.summaryCards,
          company,
          payload.headers,
          payload.rows
        );
    setShareRecipientName(activeParty?.name || '');
    setShareRecipientPhone(activeParty?.phone || '');
    setShareTitle(isNe ? `${payload.titleNe} - WhatsApp / Message शेयर` : `Share ${payload.titleEn} via WhatsApp / SMS`);
    setShareMessage(msg);
    setIsShareModalOpen(true);
  };

  const handleDirectWhatsAppReportPdfShare = async () => {
    try {
      setIsSharingReportPdf(true);
      const payload = getCurrentReportPayload();
      const activeParty = resolveActiveReportParty();
      const periodStr =
        datePeriod === 'TODAY'
          ? `आज (${todayBs})`
          : datePeriod === 'MONTH'
          ? `चालु महिना`
          : `सम्पूर्ण कारोबार`;
      const msg = activeParty
        ? buildCustomerStatementMessage(activeParty, company)
        : buildReportShareMessage(
            payload.titleNe,
            payload.subtitleNe || periodStr,
            payload.summaryCards,
            company,
            payload.headers,
            payload.rows
          );
      const pdfFile = await handleGenerateCurrentReportPdfFile();
      await sharePdfFileViaWebShareOrWhatsApp({
        title: `${payload.titleNe} - ${company.name}`,
        message: msg,
        phone: activeParty?.phone || '',
        pdfFile,
        preferDirectWhatsAppNumber: Boolean(activeParty?.phone)
      });
    } catch (err) {
      console.error('Report PDF share error:', err);
    } finally {
      setIsSharingReportPdf(false);
    }
  };

  // Handle Collection Submit
  const handleCollectionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!collectionModalParty || collectionAmount <= 0) return;

    recordCustomerCollection({
      partyId: collectionModalParty.id,
      amount: collectionAmount,
      paymentMode: collectionMode,
      bankAccountId: collectionMode === 'BANK' ? collectionBankId : undefined,
      referenceNo: collectionRef,
      notes: collectionNotes
    });

    setCollectionModalParty(null);
    setCollectionAmount(0);
    setCollectionRef('');
    setCollectionNotes('');
    showReportToast(isNe ? '✓ रकम सफलतापुर्वक असुली दर्ता गरियो !' : '✓ Collection recorded!');
  };

  // Handle Supplier Payment Submit
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payPartyId || payAmount <= 0) return;

    recordPartyPayment({
      partyId: payPartyId,
      amount: payAmount,
      paymentMode: payMode,
      bankAccountId: payMode === 'BANK' ? payBankId : undefined,
      referenceNo: payRef,
      notes: payNotes
    });

    setIsPaymentModalOpen(false);
    setPayAmount(0);
    setPayRef('');
    setPayNotes('');
    showReportToast(isNe ? '✓ पार्टी भुक्तानी सफलतापुर्वक प्रविष्टि गरियो !' : '✓ Supplier payment recorded!');
  };

  // Handle Save New Bank Account
  const handleSaveBankSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBankName.trim() || !newAccountNo.trim()) return;

    saveBankAccount({
      id: `bank-${Date.now()}`,
      bankName: newBankName.trim(),
      accountNumber: newAccountNo.trim(),
      accountHolder: newAccountHolder.trim(),
      branch: newBranch.trim(),
      openingBalance: newOpeningBal,
      currentBalance: newOpeningBal
    });

    setIsAddBankModalOpen(false);
    setNewBankName('');
    setNewAccountNo('');
    setNewBranch('');
    setNewOpeningBal(0);
  };

  // Filtered menu items based on search query
  const filteredPopularReports = REPORT_MENU_ITEMS.filter(
    (item) =>
      item.isPopular &&
      (item.titleEn.toLowerCase().includes(menuSearchQuery.toLowerCase()) ||
        item.titleNe.toLowerCase().includes(menuSearchQuery.toLowerCase()) ||
        item.subtitleEn.toLowerCase().includes(menuSearchQuery.toLowerCase()) ||
        item.subtitleNe.toLowerCase().includes(menuSearchQuery.toLowerCase()))
  );

  const filteredOtherReports = REPORT_MENU_ITEMS.filter(
    (item) =>
      !item.isPopular &&
      (item.titleEn.toLowerCase().includes(menuSearchQuery.toLowerCase()) ||
        item.titleNe.toLowerCase().includes(menuSearchQuery.toLowerCase()) ||
        item.subtitleEn.toLowerCase().includes(menuSearchQuery.toLowerCase()) ||
        item.subtitleNe.toLowerCase().includes(menuSearchQuery.toLowerCase()))
  );

  // =========================================================================
  // VIEW: 1. MASTER REPORTS MENU ("View Reports" Hub matching screenshots)
  // =========================================================================
  if (!selectedReport) {
    return (
      <div className="space-y-6 max-w-4xl mx-auto pb-12">
        {/* Top Header matching Screenshot */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('dashboard')}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition cursor-pointer"
              title={isNe ? 'ड्यासबोर्डमा फर्कनुहोस्' : 'Back to Dashboard'}
            >
              <ArrowLeft className="w-5 h-5 text-slate-700" />
            </button>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                {isNe ? 'रिपोर्टहरू हेर्नुहोस् (View Reports)' : 'View Reports'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {isNe
                  ? 'बिक्री, नाफा-नोक्सान, पार्टी हिसाब, बैंक, स्टक तथा सम्पूर्ण वित्तीय स्थिति'
                  : 'Sales, P&L, party ledgers, banking, inventory and business health'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                exportAllReportsWorkbookToExcel({
                  company,
                  invoices,
                  purchases,
                  items,
                  parties,
                  partyTransactions,
                  bankAccounts,
                  employees,
                  attendance,
                  employeeLedger,
                  rawMaterials,
                  productionBatches
                });
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>📊 सबै रिपोर्ट Excel Workbook</span>
            </button>
            <button
              onClick={() => setSelectedReport('BANK_STATEMENT')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
            >
              <Landmark className="w-3.5 h-3.5" />
              <span>🏦 बैंक स्टेटमेन्ट (Daily/Monthly/Yearly)</span>
            </button>
            <span className="text-xs font-mono font-medium px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg">
              {isNe ? `मिति: ${todayBs}` : `Date: ${todayBs}`}
            </span>
          </div>
        </div>

        {/* Quick KPI Stat Highlights */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] font-medium text-slate-500 block">
              {isNe ? 'आजको बिक्री (Today Sales)' : "Today's Sales"}
            </span>
            <div className="text-base sm:text-lg font-mono font-bold text-emerald-700 mt-0.5">
              {formatCurrency(totalTodaySales, isNe)}
            </div>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] font-medium text-slate-500 block">
              {isNe ? 'काउन्टर नगद (Cash in Hand)' : 'Cash in Hand'}
            </span>
            <div className="text-base sm:text-lg font-mono font-bold text-slate-900 mt-0.5">
              {formatCurrency(dailyCash.closingCashInHand, isNe)}
            </div>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] font-medium text-slate-500 block">
              {isNe ? 'बैंक मौज्दात (Bank Balance)' : 'Total Bank Balance'}
            </span>
            <div className="text-base sm:text-lg font-mono font-bold text-blue-900 mt-0.5">
              {formatCurrency(totalBankBalance, isNe)}
            </div>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-[11px] font-medium text-slate-500 block">
              {isNe ? 'उठाउन बाँकी (Receivables)' : 'Customer Dues'}
            </span>
            <div className="text-base sm:text-lg font-mono font-bold text-rose-700 mt-0.5">
              {formatCurrency(totalReceivables, isNe)}
            </div>
          </div>
        </div>

        {/* Search input for quick report filtering */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder={
              isNe
                ? 'रिपोर्ट खोज्नुहोस् (उदा: Sales, Day Book, Profit, Party, Bank, Staff, Inventory)...'
                : 'Search reports (e.g. Sales, Day Book, Profit, Party, Bank, Staff, Inventory)...'
            }
            value={menuSearchQuery}
            onChange={(e) => setMenuSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 shadow-xs"
          />
          {menuSearchQuery && (
            <button
              onClick={() => setMenuSearchQuery('')}
              className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* SECTION 1: Popular Reports (Screenshot 1) */}
        <div className="space-y-2">
          <h2 className="text-sm font-semibold text-slate-500 px-1">
            {isNe ? 'लोकप्रिय रिपोर्टहरू (Popular Reports)' : 'Popular Reports'}
          </h2>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs divide-y divide-slate-100 overflow-hidden">
            {filteredPopularReports.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setSelectedReport(item.id)}
                  className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-50/80 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="text-slate-700 group-hover:text-emerald-700 transition">
                      <Icon className="w-5 h-5 stroke-[1.8]" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm sm:text-base font-medium text-slate-900 group-hover:text-emerald-900 transition">
                          {isNe ? item.titleNe : item.titleEn}
                        </span>
                        {item.isNew && (
                          <span className="px-2 py-0.5 text-[10px] font-bold tracking-wide uppercase bg-rose-500 text-white rounded-md shadow-2xs">
                            New
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 font-normal mt-0.5">
                        {isNe ? item.subtitleNe : item.subtitleEn}
                      </p>
                    </div>
                  </div>

                  <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-slate-700 group-hover:translate-x-0.5 transition" />
                </button>
              );
            })}
          </div>
        </div>

        {/* SECTION 2: Additional Business Reports (Screenshot 2) */}
        <div className="space-y-2">
          <h2 className="text-sm font-semibold text-slate-500 px-1">
            {isNe ? 'थप वित्तीय तथा व्यापारिक रिपोर्टहरू' : 'More Reports'}
          </h2>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs divide-y divide-slate-100 overflow-hidden">
            {filteredOtherReports.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setSelectedReport(item.id)}
                  className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-50/80 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="text-slate-700 group-hover:text-emerald-700 transition">
                      <Icon className="w-5 h-5 stroke-[1.8]" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm sm:text-base font-medium text-slate-900 group-hover:text-emerald-900 transition">
                          {isNe ? item.titleNe : item.titleEn}
                        </span>
                        {item.isNew && (
                          <span className="px-2 py-0.5 text-[10px] font-bold tracking-wide uppercase bg-rose-500 text-white rounded-md shadow-2xs">
                            New
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 font-normal mt-0.5">
                        {isNe ? item.subtitleNe : item.subtitleEn}
                      </p>
                    </div>
                  </div>

                  <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-slate-700 group-hover:translate-x-0.5 transition" />
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // INDIVIDUAL REPORT VIEWS (Header with Back Button + Content)
  // =========================================================================
  const currentMenuItem = REPORT_MENU_ITEMS.find((r) => r.id === selectedReport);

  return (
    <div className="space-y-5 pb-12 max-w-6xl mx-auto">
      
      {/* Universal Top Header with "← View Reports" Back Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSelectedReport(null)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{isNe ? 'फिर्ता (View Reports)' : 'View Reports'}</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold text-slate-900">
                {isNe ? currentMenuItem?.titleNe : currentMenuItem?.titleEn}
              </h1>
              {currentMenuItem?.isNew && (
                <span className="px-2 py-0.5 text-[10px] font-bold uppercase bg-rose-500 text-white rounded-md">
                  New
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500">
              {isNe ? currentMenuItem?.subtitleNe : currentMenuItem?.subtitleEn}
            </p>
          </div>
        </div>

        {/* Global Action Bar: Excel Download, PDF Save/Download, PDF Print & Date Filter */}
        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          {selectedReport !== 'BANK_STATEMENT' &&
            selectedReport !== 'PARTY_STATEMENT' &&
            selectedReport !== 'PARTIES_REPORT' &&
            selectedReport !== 'DAY_BOOK' && (
              <div className="flex items-center gap-1.5">
                <label className="text-[11px] font-bold text-slate-600">
                  {isNe ? 'अवधि (Period):' : 'Period:'}
                </label>
                <select
                  value={datePeriod}
                  onChange={(e) => setDatePeriod(e.target.value as 'ALL' | 'TODAY' | 'MONTH')}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-600"
                >
                  <option value="ALL">{isNe ? 'सबै कारोबार (All)' : 'All'}</option>
                  <option value="TODAY">{isNe ? `आज (Today - ${todayBs})` : `Today (${todayBs})`}</option>
                  <option value="MONTH">{isNe ? `यो महिना (Current Month)` : 'This Month'}</option>
                </select>
              </div>
            )}

          <button
            onClick={handleExportCurrentReportToExcel}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-lg shadow-2xs transition cursor-pointer"
            title="Excel मा डाउनलोड र सेभ गर्नुहोस्"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isNe ? 'Excel डाउनलोड' : 'Excel Download'}</span>
          </button>

          <button
            onClick={() => handleExportCurrentReportToPdf('DOWNLOAD')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-lg shadow-2xs transition cursor-pointer"
            title="PDF मा सेभ / डाउनलोड गर्नुहोस्"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isNe ? 'PDF सेभ / डाउनलोड' : 'PDF Save'}</span>
          </button>

          <button
            onClick={() => handleExportCurrentReportToPdf('PRINT')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition cursor-pointer shadow-2xs"
            title="PDF प्रिन्ट गर्नुहोस्"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isNe ? 'PDF प्रिन्ट' : 'PDF Print'}</span>
          </button>

          <button
            type="button"
            onClick={handleDirectWhatsAppReportPdfShare}
            disabled={isSharingReportPdf}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-700 hover:bg-teal-800 disabled:opacity-60 text-white text-xs font-bold rounded-lg shadow-2xs transition cursor-pointer"
            title="यो रिपोर्टको PDF फाइल र विवरण सिधै WhatsApp (wa.me) वा Web Share मार्फत पठाउनुहोस्"
          >
            <Send className="w-3.5 h-3.5 text-teal-200" />
            <span>{isSharingReportPdf ? 'PDF बन्दैछ...' : isNe ? '📲 WhatsApp PDF' : 'WhatsApp PDF'}</span>
          </button>

          <button
            onClick={handleOpenShareReport}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-lg shadow-2xs transition cursor-pointer"
            title="ग्राहकको नम्बर छानेर WhatsApp वा SMS मा रिपोर्ट पठाउनुहोस्"
          >
            <Share2 className="w-3.5 h-3.5 text-emerald-300" />
            <span>{isNe ? 'WhatsApp / SMS शेयर' : 'Share via WhatsApp / SMS'}</span>
          </button>
        </div>
      </div>

      {selectedReport === 'DAILY_OPERATIONS_SUMMARY' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6" id="printable-daily-summary">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-lg text-slate-900">
              {isNe ? 'दैनिक कार्य सारांश' : 'Daily Operations Summary'} ({todayBs})
            </h3>
            <div className="flex items-center gap-2">
            <InvoicePrintOptions storageKey="report" features={{}} />
            <button
              onClick={() => printPage(printArgsFor('report', { features: { copies: false } }))}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>{isNe ? 'प्रिन्ट/PDF' : 'Print/PDF'}</span>
            </button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100">
              <p className="text-xs text-emerald-900">{isNe ? 'कुल बिक्री' : 'Total Sales'}</p>
              <p className="text-2xl font-black text-emerald-950">{formatCurrency(invoices.filter(i => i.status === 'ACTIVE' && i.dateBs === todayBs).reduce((s, i) => s + i.grandTotal, 0), isNe)}</p>
            </div>
            <div className="p-4 bg-amber-50 rounded-xl border border-amber-100">
              <p className="text-xs text-amber-900">{isNe ? 'कुल खरिद' : 'Total Purchases'}</p>
              <p className="text-2xl font-black text-amber-950">{formatCurrency(purchases.filter(p => p.dateBs === todayBs).reduce((s, p) => s + p.grandTotal, 0), isNe)}</p>
            </div>
            <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
              <p className="text-xs text-blue-900">{isNe ? 'उपस्थित कर्मचारी' : 'Employees Present'}</p>
              <p className="text-2xl font-black text-blue-950">{attendance.filter(a => a.dateBs === todayBs && a.status === 'PRESENT').length}</p>
            </div>
          </div>
        </div>
      )}
      {selectedReport === 'EXPENSE_ANALYSIS' && <ExpenseAnalysisReport />}

      {/* ------------------------------------------------------------------- */}
      {/* 1. SALES REPORT                                                     */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'SALES_REPORT' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'कुल बिक्री (Grand Sales)' : 'Total Sales'}</span>
              <div className="text-xl font-bold font-mono text-slate-900 mt-1">
                {formatCurrency(pnlData.revenue, isNe)}
              </div>
              <span className="text-[11px] text-slate-400 mt-0.5 block">{pnlData.invoiceCount} {isNe ? 'बीजक' : 'Bills'}</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'करयोग्य बिक्री (Taxable)' : 'Taxable Sales'}</span>
              <div className="text-xl font-bold font-mono text-emerald-700 mt-1">
                {formatCurrency(pnlData.taxableRevenue, isNe)}
              </div>
              <span className="text-[11px] text-slate-400 mt-0.5 block">{isNe ? '१३% भ्याट लाग्ने' : 'Subject to 13% VAT'}</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? '१३% भ्याट रकम (VAT)' : '13% VAT Collected'}</span>
              <div className="text-xl font-bold font-mono text-blue-800 mt-1">
                {formatCurrency(pnlData.vatCollected, isNe)}
              </div>
              <span className="text-[11px] text-slate-400 mt-0.5 block">{isNe ? 'सरकारलाई बुझाउनुपर्ने' : 'Output VAT'}</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'कर छुट बिक्री (Exempt)' : 'Tax Exempt Sales'}</span>
              <div className="text-xl font-bold font-mono text-amber-700 mt-1">
                {formatCurrency(pnlData.exemptRevenue, isNe)}
              </div>
              <span className="text-[11px] text-slate-400 mt-0.5 block">{isNe ? 'मल, बिउबिजन आदि' : 'Fertilizers/Seeds'}</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex justify-between items-center flex-wrap gap-2">
              <div className="text-xs font-semibold text-slate-700">
                {isNe ? 'उन्नत खोजी तथा फिल्टर (Advanced Search: नाम, ठेगाना, मिति दायरा, रकम र भुक्तानी अवस्था):' : 'Advanced Search & Filters (Name, Address, Date Range, Amount & Payment Status):'}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportCurrentReportToCsv}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>{isNe ? 'CSV Export' : 'CSV Export'}</span>
                </button>
                <button
                  onClick={() => exportSalesBookToExcel(pnlData.filteredInvoices, company.fiscalYear)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isNe ? 'अनुसूची ५ Excel Export' : 'Export Anusuchi 5 Excel'}</span>
                </button>
              </div>
            </div>

            {/* Row 1: Search Bar + Address Disambiguation Filter + Payment Status */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={reportAdvSearch}
                  onChange={(e) => setReportAdvSearch(e.target.value)}
                  placeholder={isNe ? 'नाम, ठेगाना, बिल नं. वा प्यानले खोज्नुहोस्...' : 'Search by name, address, bill no, PAN...'}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium text-slate-900"
                />
              </div>

              <select
                value={reportAdvAddress}
                onChange={(e) => setReportAdvAddress(e.target.value)}
                className="px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold text-slate-900 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value="ALL">{isNe ? '📍 सबै ठेगाना (All Addresses - एउटै नाम छुट्याउने)' : '📍 All Addresses'}</option>
                {partyUniqueAddresses.map((addr) => (
                  <option key={addr} value={addr}>
                    📍 {addr}
                  </option>
                ))}
              </select>

              <select
                value={reportAdvPaymentStatus}
                onChange={(e) => setReportAdvPaymentStatus(e.target.value as any)}
                className="px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold text-slate-900 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value="ALL">{isNe ? '💳 सबै भुक्तानी अवस्था (All Payment Status)' : '💳 All Payment Status'}</option>
                <option value="PAID">{isNe ? '✅ चुक्ता भएको (Fully Paid)' : '✅ Fully Paid'}</option>
                <option value="PARTIAL">{isNe ? '🌗 आंशिक भुक्तानी (Partially Paid)' : '🌗 Partially Paid'}</option>
                <option value="CREDIT_UNPAID">{isNe ? '⏳ उधारो / बाँकी (Credit / Due Pending)' : '⏳ Credit / Unpaid Due'}</option>
                <option value="CASH">{isNe ? '💵 नगद बिक्री मात्र (Cash Only)' : '💵 Cash Only'}</option>
                <option value="BANK_FONEPAY">{isNe ? '🏦 बैंक / QR मात्र (Bank / FonePay)' : '🏦 Bank / FonePay'}</option>
              </select>
            </div>

            {/* Row 2: Date Range (From - To) & Amount Range (Min - Max) */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-slate-600">{isNe ? 'मिति देखि (From BS):' : 'Date From:'}</span>
                  <input
                    type="text"
                    value={reportAdvDateFromBs}
                    onChange={(e) => setReportAdvDateFromBs(e.target.value)}
                    placeholder="2081-01-01"
                    className="w-28 px-2.5 py-1 border border-slate-300 rounded-lg font-mono text-slate-900"
                  />
                  <span className="font-semibold text-slate-600">{isNe ? 'सम्म (To):' : 'To:'}</span>
                  <input
                    type="text"
                    value={reportAdvDateToBs}
                    onChange={(e) => setReportAdvDateToBs(e.target.value)}
                    placeholder={todayBs}
                    className="w-28 px-2.5 py-1 border border-slate-300 rounded-lg font-mono text-slate-900"
                  />
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-slate-600">{isNe ? 'रकम दायरा (Amount Rs.):' : 'Amount Range:'}</span>
                  <input
                    type="number"
                    value={reportAdvMinAmount}
                    onChange={(e) => setReportAdvMinAmount(e.target.value)}
                    placeholder={isNe ? 'न्यूनतम (Min)' : 'Min Rs.'}
                    className="w-24 px-2.5 py-1 border border-slate-300 rounded-lg font-mono text-slate-900"
                  />
                  <span className="text-slate-400">-</span>
                  <input
                    type="number"
                    value={reportAdvMaxAmount}
                    onChange={(e) => setReportAdvMaxAmount(e.target.value)}
                    placeholder={isNe ? 'अधिकतम (Max)' : 'Max Rs.'}
                    className="w-24 px-2.5 py-1 border border-slate-300 rounded-lg font-mono text-slate-900"
                  />
                </div>
              </div>

              {(reportAdvSearch || reportAdvAddress !== 'ALL' || reportAdvDateFromBs || reportAdvDateToBs || reportAdvMinAmount || reportAdvMaxAmount || reportAdvPaymentStatus !== 'ALL') && (
                <button
                  type="button"
                  onClick={() => {
                    setReportAdvSearch('');
                    setReportAdvAddress('ALL');
                    setReportAdvDateFromBs('');
                    setReportAdvDateToBs('');
                    setReportAdvMinAmount('');
                    setReportAdvMaxAmount('');
                    setReportAdvPaymentStatus('ALL');
                  }}
                  className="text-xs text-rose-600 hover:text-rose-800 font-semibold underline cursor-pointer"
                >
                  {isNe ? 'फिल्टर रिसेट गर्नुहोस्' : 'Reset Filters'}
                </button>
              )}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">क्र.सं.</th>
                    <th className="py-2.5 px-3">बीजक नं.</th>
                    <th className="py-2.5 px-3">प्रकार</th>
                    <th className="py-2.5 px-3">मिति (B.S.)</th>
                    <th className="py-2.5 px-3">ग्राहकको नाम र ठेगाना</th>
                    <th className="py-2.5 px-3">भुक्तानी अवस्था / माध्यम</th>
                    <th className="py-2.5 px-3 text-right">करयोग्य रकम</th>
                    <th className="py-2.5 px-3 text-right">१३% भ्याट</th>
                    <th className="py-2.5 px-3 text-right">कुल रकम</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {pnlData.filteredInvoices.map((inv, idx) => {
                    const invDue = inv.remainingDue ?? (inv.paymentMode === 'CREDIT' ? inv.grandTotal : 0);
                    const invPaid = inv.amountPaid ?? (inv.paymentMode === 'CREDIT' ? 0 : inv.grandTotal);
                    const isSameNameCustomer = (partyNameCounts.get((inv.customerName || '').trim().toLowerCase()) || 0) > 1;
                    return (
                      <tr key={inv.id} className="hover:bg-slate-50/70">
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{toNepaliDigits(idx + 1)}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{inv.invoiceNo}</td>
                        <td className="py-2.5 px-3">
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                            inv.billType === 'VAT' ? 'bg-blue-50 text-blue-800' : 'bg-slate-100 text-slate-700'
                          }`}>
                            {inv.billType}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-600">{inv.dateBs}</td>
                        <td className="py-2.5 px-3 font-medium text-slate-900">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold">{inv.customerName}</span>
                            {inv.customerAddress && (
                              <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                                isSameNameCustomer
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                  : 'bg-slate-100 text-slate-700'
                              }`}>
                                📍 {inv.customerAddress}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-700">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span>{inv.paymentMode}</span>
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              invDue <= 0
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                : invPaid > 0
                                ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                : 'bg-rose-50 text-rose-800 border border-rose-200'
                            }`}>
                              {invDue <= 0 ? (isNe ? 'चुक्ता' : 'Paid') : invPaid > 0 ? (isNe ? 'आंशिक' : 'Partial') : (isNe ? 'बाँकी' : 'Unpaid')}
                            </span>
                          </div>
                          {inv.bankName && <span className="text-[10px] text-blue-700 block">({inv.bankName})</span>}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(inv.taxableAmount, isNe)}</td>
                        <td className="py-2.5 px-3 text-right font-mono text-blue-800">{formatCurrency(inv.vatAmount, isNe)}</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">{formatCurrency(inv.grandTotal, isNe)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 2. DAY BOOK (with All / Today / Months & Fiscal Year / Year Dropdowns) */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'DAY_BOOK' && (
        <div className="space-y-4">
          {/* Day Book Period, Month & Year / Fiscal Year Dropdown Filter Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex flex-wrap items-center gap-3">
              {/* 1. All / Today / Months Dropdown */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">
                  {isNe ? 'अवधि छान्नुहोस् (Select Period):' : 'Select Period:'}
                </label>
                <select
                  value={dayBookPeriodMode}
                  onChange={(e) => {
                    const nextMode = e.target.value as any;
                    setDayBookPeriodMode(nextMode);
                    if (nextMode === 'MONTH' && dayBookMonthBs === 'ALL') {
                      setDayBookMonthBs(todayBs.substring(5, 7));
                    }
                  }}
                  className="px-3 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="ALL">{isNe ? 'सबै कारोबार (All)' : 'All'}</option>
                  <option value="TODAY">{isNe ? `आजको मात्र (Today - ${todayBs})` : `Today (${todayBs})`}</option>
                  <option value="MONTH">{isNe ? 'महिना अनुसार (Months)' : 'Months'}</option>
                  <option value="SPECIFIC_DATE">{isNe ? 'तोकिएको मिति (Select Date)' : 'Specific Date'}</option>
                </select>
              </div>

              {/* 2. Month Dropdown */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">
                  {isNe ? 'महिना छान्नुहोस् (Select Month):' : 'Select Month:'}
                </label>
                <select
                  value={dayBookMonthBs}
                  onChange={(e) => {
                    setDayBookMonthBs(e.target.value);
                    if (e.target.value !== 'ALL' && dayBookPeriodMode === 'TODAY') {
                      setDayBookPeriodMode('MONTH');
                    }
                  }}
                  className="px-3 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="ALL">{isNe ? 'सबै १२ महिना (All Months)' : 'All Months'}</option>
                  {NEPALI_MONTHS_LIST.map((m) => (
                    <option key={m.code} value={m.code}>
                      {m.code} - {m.nameNe}
                    </option>
                  ))}
                </select>
              </div>

              {/* 3. Fiscal Year / Year Dropdown */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">
                  {isNe ? 'आर्थिक वर्ष / वर्ष छान्नुहोस् (Select Year):' : 'Select Fiscal Year / Year:'}
                </label>
                <select
                  value={dayBookYearOrFy}
                  onChange={(e) => setDayBookYearOrFy(e.target.value)}
                  className="px-3 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white cursor-pointer focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="ALL">{isNe ? 'सबै आर्थिक वर्ष / वर्ष (All Years)' : 'All Years'}</option>
                  <optgroup label={isNe ? 'आर्थिक वर्ष (Fiscal Year - आ.व.)' : 'Fiscal Years (आ.व.)'}>
                    {availableFiscalYears.map((fy) => (
                      <option key={`fy-${fy}`} value={fy}>
                        {isNe ? `आ.व. ${fy}` : `F.Y. ${fy}`}
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label={isNe ? 'वि.सं. वर्ष (B.S. Year)' : 'B.S. Calendar Years'}>
                    {availableBsYears.map((yr) => (
                      <option key={`yr-${yr}`} value={yr}>
                        {isNe ? `वि.सं. ${yr}` : `Year ${yr} B.S.`}
                      </option>
                    ))}
                  </optgroup>
                </select>
              </div>

              {/* 4. Specific Date Input if SPECIFIC_DATE is selected */}
              {dayBookPeriodMode === 'SPECIFIC_DATE' && (
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1">
                    {isNe ? 'मिति (YYYY-MM-DD):' : 'Date (B.S.):'}
                  </label>
                  <input
                    type="text"
                    value={dayBookSpecificDateBs}
                    onChange={(e) => setDayBookSpecificDateBs(e.target.value)}
                    placeholder={todayBs}
                    className="w-32 px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                  />
                </div>
              )}
            </div>

            {(dayBookPeriodMode !== 'ALL' || dayBookMonthBs !== 'ALL' || dayBookYearOrFy !== 'ALL') && (
              <button
                type="button"
                onClick={() => {
                  setDayBookPeriodMode('ALL');
                  setDayBookMonthBs('ALL');
                  setDayBookYearOrFy('ALL');
                }}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg cursor-pointer"
              >
                {isNe ? 'फिल्टर रिसेट (Reset)' : 'Reset Filter'}
              </button>
            )}
          </div>

          {(() => {
            const matchDayBook = (dateBsStr: string, recordFy?: string) => {
              if (!dateBsStr) return false;
              if (dayBookYearOrFy !== 'ALL' && !doesDateMatchFyOrYear(dateBsStr, dayBookYearOrFy, recordFy)) {
                return false;
              }
              if (dayBookPeriodMode === 'TODAY') return dateBsStr === todayBs;
              if (dayBookPeriodMode === 'SPECIFIC_DATE') return dateBsStr === dayBookSpecificDateBs;
              if (dayBookPeriodMode === 'MONTH' && dayBookMonthBs !== 'ALL') {
                const clean = dateBsStr.trim().replace(/\//g, '-');
                const parts = clean.split('-');
                const mo = parts[1] ? parts[1].padStart(2, '0') : '';
                return mo === dayBookMonthBs;
              }
              if (dayBookMonthBs !== 'ALL') {
                const clean = dateBsStr.trim().replace(/\//g, '-');
                const parts = clean.split('-');
                const mo = parts[1] ? parts[1].padStart(2, '0') : '';
                if (mo !== dayBookMonthBs) return false;
              }
              return true;
            };

            const dbInvoices = invoices.filter((i) => i.status === 'ACTIVE' && matchDayBook(i.dateBs, i.fiscalYear));
            const dbExpenses = (expenses || []).filter((e) => matchDayBook(e.dateBs));
            const dbPartyTxs = partyTransactions.filter((t) => matchDayBook(t.dateBs));
            const dbPurchases = purchases.filter((p) => matchDayBook(p.dateBs));

            const totalSalesAmt = dbInvoices.reduce((s, i) => s + i.grandTotal, 0);
            const totalCollectionsAmt = dbPartyTxs
              .filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER')
              .reduce((s, t) => s + t.amount, 0);
            const totalPaymentsAndExp =
              dbExpenses.reduce((s, e) => s + e.amount, 0) +
              dbPartyTxs.filter((t) => t.type === 'PAYMENT_TO_SUPPLIER').reduce((s, t) => s + t.amount, 0);

            return (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                    <span className="text-xs text-slate-500 block">{isNe ? 'काउन्टर सुरुवाती नगद' : 'Opening Counter Cash'}</span>
                    <div className="text-xl font-bold font-mono text-slate-800 mt-1">
                      {formatCurrency(dailyCash.openingCash, isNe)}
                    </div>
                  </div>
                  <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                    <span className="text-xs text-slate-500 block">{isNe ? 'अवधिको बिक्री तथा असुली (+)' : 'Filtered Sales & Collections (+)'}</span>
                    <div className="text-xl font-bold font-mono text-emerald-700 mt-1">
                      {formatCurrency(totalSalesAmt + totalCollectionsAmt, isNe)}
                    </div>
                  </div>
                  <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                    <span className="text-xs text-slate-500 block">{isNe ? 'अवधिको दैनिक खर्च तथा भुक्तानी (-)' : 'Expenses & Payments (-)'}</span>
                    <div className="text-xl font-bold font-mono text-rose-700 mt-1">
                      {formatCurrency(totalPaymentsAndExp, isNe)}
                    </div>
                  </div>
                  <div className="bg-emerald-900 text-white p-4 rounded-xl shadow-xs">
                    <span className="text-xs text-emerald-200 block">{isNe ? 'अन्तिम काउन्टर नगद मौज्दात' : 'Closing Cash In Hand'}</span>
                    <div className="text-xl font-bold font-mono text-white mt-1">
                      {formatCurrency(dailyCash.closingCashInHand, isNe)}
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                  <div className="p-4 border-b border-slate-200 flex justify-between items-center flex-wrap gap-2">
                    <h3 className="font-bold text-sm text-slate-900">
                      {isNe
                        ? `डे-बुक कारोबार विवरण (बिक्री: ${dbInvoices.length}, भौचर: ${dbPartyTxs.length}, खर्च: ${dbExpenses.length}, खरिद: ${dbPurchases.length})`
                        : `Day Book Transactions (${dbInvoices.length} Sales, ${dbPartyTxs.length} Vouchers, ${dbExpenses.length} Expenses)`}
                    </h3>
                    <span className="text-xs text-slate-500 font-mono">
                      {isNe ? 'नगद, बैंक, उधारो बिक्री, खरिद तथा दैनिक खर्च समावेश' : 'Includes sales, collections, payments & daily expenses'}
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                        <tr>
                          <th className="py-2.5 px-3">क्र.सं.</th>
                          <th className="py-2.5 px-3">मिति / समय</th>
                          <th className="py-2.5 px-3">विवरण / ग्राहक / खर्च शीर्षक (ठेगाना सहित)</th>
                          <th className="py-2.5 px-3">प्रकार</th>
                          <th className="py-2.5 px-3">माध्यम</th>
                          <th className="py-2.5 px-3 text-right">रकम (Rs.)</th>
                          <th className="py-2.5 px-3 text-right">अवस्था</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {dbInvoices.length === 0 && dbPartyTxs.length === 0 && dbExpenses.length === 0 && dbPurchases.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="py-8 text-center text-slate-400">
                              {isNe ? 'छानिएको अवधिमा कुनै कारोबार भेटिएन।' : 'No transactions found for the selected filter.'}
                            </td>
                          </tr>
                        ) : (
                          <>
                            {dbInvoices.map((inv, idx) => (
                              <tr key={`inv-${inv.id}`} className="hover:bg-slate-50/70">
                                <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{toNepaliDigits(idx + 1)}</td>
                                <td className="py-2.5 px-3 font-mono text-slate-600">
                                  <div>{inv.dateBs}</div>
                                  <div className="text-[10px] text-slate-400">{inv.time || '10:00 AM'}</div>
                                </td>
                                <td className="py-2.5 px-3 font-medium text-slate-900">
                                  {inv.customerName} {inv.customerAddress ? `— 📍 ${inv.customerAddress}` : ''} ({inv.invoiceNo})
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                                    {isNe ? 'बिक्री (Sales)' : 'Sales'}
                                  </span>
                                </td>
                                <td className="py-2.5 px-3 font-mono text-slate-700">
                                  {inv.paymentMode} {inv.bankName && `(${inv.bankName})`}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                                  +{formatCurrency(inv.grandTotal, isNe)}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono text-emerald-700 font-semibold">
                                  {isNe ? 'सम्पन्न' : 'Completed'}
                                </td>
                              </tr>
                            ))}

                            {dbPartyTxs.map((tx, idx) => (
                              <tr key={`tx-${tx.id}`} className="hover:bg-slate-50/70">
                                <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{toNepaliDigits(dbInvoices.length + idx + 1)}</td>
                                <td className="py-2.5 px-3 font-mono text-slate-600">{tx.dateBs}</td>
                                <td className="py-2.5 px-3 font-medium text-slate-900">
                                  {tx.partyName} {tx.partyAddress ? `— 📍 ${tx.partyAddress}` : ''} ({tx.referenceNo || 'VOUCHER'})
                                  {tx.incomeCategory && (
                                    <span className="ml-1.5 text-[10px] font-bold text-blue-800 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                                      {tx.incomeCategory}
                                    </span>
                                  )}
                                </td>
                                <td className="py-2.5 px-3">
                                  <span
                                    className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                                      tx.type === 'COLLECTION_FROM_CUSTOMER'
                                        ? tx.incomeType === 'LOAN_RECEIVED'
                                          ? 'bg-amber-50 text-amber-900 border-amber-200'
                                          : tx.incomeType === 'OTHER_INCOME'
                                          ? 'bg-blue-50 text-blue-900 border-blue-200'
                                          : 'bg-teal-50 text-teal-800 border-teal-200'
                                        : 'bg-rose-50 text-rose-800 border-rose-200'
                                    }`}
                                  >
                                    {tx.type === 'COLLECTION_FROM_CUSTOMER'
                                      ? tx.incomeType === 'LOAN_RECEIVED'
                                        ? isNe
                                          ? 'ऋण / सापटी प्राप्त (+)'
                                          : 'Loan Received (+)'
                                        : tx.incomeType === 'OTHER_INCOME'
                                        ? isNe
                                          ? 'अन्य आम्दानी (+)'
                                          : 'Other Income (+)'
                                        : isNe
                                        ? 'ग्राहक असुली (+)'
                                        : 'Collection (+)'
                                      : isNe
                                      ? 'पार्टी भुक्तानी (-)'
                                      : 'Payment (-)'}
                                  </span>
                                </td>
                                <td className="py-2.5 px-3 font-mono text-slate-700">{tx.paymentMode}</td>
                                <td
                                  className={`py-2.5 px-3 text-right font-mono font-bold ${
                                    tx.type === 'COLLECTION_FROM_CUSTOMER' ? 'text-emerald-700' : 'text-rose-700'
                                  }`}
                                >
                                  {tx.type === 'COLLECTION_FROM_CUSTOMER' ? '+' : '-'}
                                  {formatCurrency(tx.amount, isNe)}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono text-slate-600 font-semibold">
                                  {isNe ? 'भौचर' : 'Voucher'}
                                </td>
                              </tr>
                            ))}

                            {dbExpenses.map((exp, idx) => (
                              <tr key={`exp-${exp.id}`} className="hover:bg-amber-50/40">
                                <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{toNepaliDigits(dbInvoices.length + dbPartyTxs.length + idx + 1)}</td>
                                <td className="py-2.5 px-3 font-mono text-slate-600">{exp.dateBs}</td>
                                <td className="py-2.5 px-3 font-medium text-slate-900">
                                  <span className="font-bold">{exp.category}</span>
                                  {exp.paidTo && <span className="text-emerald-800 ml-1">({exp.paidTo})</span>}
                                  {exp.description && <span className="text-slate-500 ml-1">— {exp.description}</span>}
                                </td>
                                <td className="py-2.5 px-3">
                                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-900 border border-amber-200">
                                    {isNe ? 'दैनिक खर्च (-)' : 'Expense (-)'}
                                  </span>
                                </td>
                                <td className="py-2.5 px-3 font-mono text-slate-700">{exp.paymentMode}</td>
                                <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700">
                                  -{formatCurrency(exp.amount, isNe)}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono text-amber-800 font-semibold">
                                  {exp.voucherNo || 'EXP'}
                                </td>
                              </tr>
                            ))}
                          </>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            );
          })()}
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 3. ALL TRANSACTIONS REPORT                                          */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'ALL_TRANSACTIONS' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex justify-between items-center flex-wrap gap-2">
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  {isNe ? 'सम्पूर्ण कारोबार विवरण (All Transactions Audit Trail)' : 'All Transactions Audit Trail'}
                </h3>
                <p className="text-xs text-slate-500">
                  {isNe ? 'नाम, ठेगाना, मिति दायरा, रकम र भुक्तानी माध्यम अनुसार छान्नुहोस्' : 'Filter by party name, address, date range, amount & payment mode'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportCurrentReportToCsv}
                  className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>{isNe ? 'CSV Export' : 'CSV Export'}</span>
                </button>
                <button
                  onClick={() => {
                    const headers = ['मिति', 'प्रकार', 'विवरण / पार्टी', 'ठेगाना', 'माध्यम / बैंक', 'Ref No.', 'रकम'];
                    const rows = partyTransactions.map((t) => [
                      t.dateBs,
                      t.type,
                      t.partyName,
                      t.partyAddress || '-',
                      t.paymentMode,
                      t.referenceNo || '-',
                      t.amount
                    ]);
                    exportGenericToExcel(headers, rows, 'All_Transactions');
                  }}
                  className="flex items-center gap-1.5 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isNe ? 'Excel Export' : 'Excel Export'}</span>
                </button>
              </div>
            </div>

            {/* Advanced Filter Controls for All Transactions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 pt-2 border-t border-slate-100">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={reportAdvSearch}
                  onChange={(e) => setReportAdvSearch(e.target.value)}
                  placeholder={isNe ? 'पार्टीको नाम, ठेगाना वा Ref No. ले खोज्नुहोस्...' : 'Search party name, address, Ref No...'}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <select
                value={reportAdvAddress}
                onChange={(e) => setReportAdvAddress(e.target.value)}
                className="px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold text-slate-900 bg-white"
              >
                <option value="ALL">{isNe ? '📍 सबै ठेगाना (All Addresses)' : '📍 All Addresses'}</option>
                {partyUniqueAddresses.map((addr) => (
                  <option key={addr} value={addr}>
                    📍 {addr}
                  </option>
                ))}
              </select>

              <select
                value={reportAdvPaymentStatus}
                onChange={(e) => setReportAdvPaymentStatus(e.target.value as any)}
                className="px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold text-slate-900 bg-white"
              >
                <option value="ALL">{isNe ? '💳 सबै माध्यम (All Modes)' : '💳 All Modes'}</option>
                <option value="CASH">{isNe ? '💵 नगद मात्र (Cash)' : '💵 Cash Only'}</option>
                <option value="BANK_FONEPAY">{isNe ? '🏦 बैंक मात्र (Bank)' : '🏦 Bank Only'}</option>
              </select>
            </div>

            <div className="flex flex-wrap items-center gap-3 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-slate-600">{isNe ? 'मिति देखि:' : 'From:'}</span>
                <input
                  type="text"
                  value={reportAdvDateFromBs}
                  onChange={(e) => setReportAdvDateFromBs(e.target.value)}
                  placeholder="2081-01-01"
                  className="w-28 px-2.5 py-1 border border-slate-300 rounded-lg font-mono text-slate-900"
                />
                <span className="font-semibold text-slate-600">{isNe ? 'सम्म:' : 'To:'}</span>
                <input
                  type="text"
                  value={reportAdvDateToBs}
                  onChange={(e) => setReportAdvDateToBs(e.target.value)}
                  placeholder={todayBs}
                  className="w-28 px-2.5 py-1 border border-slate-300 rounded-lg font-mono text-slate-900"
                />
              </div>

              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-slate-600">{isNe ? 'रकम (Min - Max):' : 'Amount:'}</span>
                <input
                  type="number"
                  value={reportAdvMinAmount}
                  onChange={(e) => setReportAdvMinAmount(e.target.value)}
                  placeholder="Min"
                  className="w-24 px-2.5 py-1 border border-slate-300 rounded-lg font-mono text-slate-900"
                />
                <span>-</span>
                <input
                  type="number"
                  value={reportAdvMaxAmount}
                  onChange={(e) => setReportAdvMaxAmount(e.target.value)}
                  placeholder="Max"
                  className="w-24 px-2.5 py-1 border border-slate-300 rounded-lg font-mono text-slate-900"
                />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">क्र.सं.</th>
                    <th className="py-2.5 px-3">मिति (B.S.)</th>
                    <th className="py-2.5 px-3">प्रकार</th>
                    <th className="py-2.5 px-3">पार्टी / खाता (ठेगाना सहित)</th>
                    <th className="py-2.5 px-3">माध्यम / बैंक</th>
                    <th className="py-2.5 px-3">Ref No.</th>
                    <th className="py-2.5 px-3 text-right">रकम (Rs.)</th>
                    <th className="py-2.5 px-3">कैफियत</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {partyTransactions
                    .filter((tx) => {
                      if (reportAdvSearch.trim()) {
                        const q = reportAdvSearch.trim().toLowerCase();
                        const match =
                          tx.partyName.toLowerCase().includes(q) ||
                          (tx.partyAddress || '').toLowerCase().includes(q) ||
                          (tx.referenceNo || '').toLowerCase().includes(q) ||
                          `${tx.partyName} ${tx.partyAddress || ''}`.toLowerCase().includes(q);
                        if (!match) return false;
                      }
                      if (reportAdvAddress && reportAdvAddress !== 'ALL') {
                        if (!(tx.partyAddress || '').toLowerCase().includes(reportAdvAddress.toLowerCase())) return false;
                      }
                      if (reportAdvDateFromBs.trim() && tx.dateBs < reportAdvDateFromBs.trim()) return false;
                      if (reportAdvDateToBs.trim() && tx.dateBs > reportAdvDateToBs.trim()) return false;
                      if (reportAdvMinAmount.trim() !== '' && tx.amount < Number(reportAdvMinAmount)) return false;
                      if (reportAdvMaxAmount.trim() !== '' && tx.amount > Number(reportAdvMaxAmount)) return false;
                      if (reportAdvPaymentStatus === 'CASH' && tx.paymentMode !== 'CASH') return false;
                      if (reportAdvPaymentStatus === 'BANK_FONEPAY' && tx.paymentMode !== 'BANK') return false;
                      return true;
                    })
                    .map((tx, idx) => (
                      <tr key={tx.id} className="hover:bg-slate-50/70">
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{toNepaliDigits(idx + 1)}</td>
                        <td className="py-2.5 px-3 font-mono text-slate-600">{tx.dateBs}</td>
                        <td className="py-2.5 px-3">
                          {tx.type === 'COLLECTION_FROM_CUSTOMER' ? (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                              {isNe ? 'ग्राहक असुली (+)' : 'Customer Collection (+)'}
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-50 text-rose-800 border border-rose-200">
                              {isNe ? 'पार्टी भुक्तानी (-)' : 'Supplier Payment (-)'}
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 font-semibold text-slate-900">
                          <div>{tx.partyName}</div>
                          {tx.partyAddress && (
                            <span className="text-[10px] text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded inline-block mt-0.5">
                              📍 {tx.partyAddress}
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-700">
                          {tx.paymentMode === 'BANK' ? tx.bankName || 'Bank' : 'Cash'}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-400">{tx.referenceNo || '-'}</td>
                        <td className={`py-2.5 px-3 text-right font-mono font-bold ${
                          tx.type === 'COLLECTION_FROM_CUSTOMER' ? 'text-emerald-700' : 'text-rose-700'
                        }`}>
                          {tx.type === 'COLLECTION_FROM_CUSTOMER' ? '+' : '-'} {formatCurrency(tx.amount, isNe)}
                        </td>
                        <td className="py-2.5 px-3 text-slate-500 text-[11px]">{tx.notes || '-'}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 4. PROFIT & LOSS REPORT [New]                                       */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'PROFIT_LOSS' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block font-medium">
                {isNe ? 'कुल बिक्री आम्दानी (Total Revenue)' : 'Gross Sales Revenue'}
              </span>
              <div className="text-2xl font-black font-mono text-slate-900 mt-1">
                {formatCurrency(pnlData.taxableRevenue + pnlData.exemptRevenue, isNe)}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {isNe ? 'कर बाहेकको वास्तविक बिक्री' : 'Excluding 13% output VAT'}
              </span>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block font-medium">
                {isNe ? 'सामान खरिद लागत (Cost of Goods Sold - COGS)' : 'Cost of Goods Sold (COGS)'}
              </span>
              <div className="text-2xl font-black font-mono text-amber-800 mt-1">
                {formatCurrency(pnlData.cogs, isNe)}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {isNe ? 'बिक्री भएका सामानहरूको वास्तविक खरिद मूल्य' : 'Total inventory cost of sold items'}
              </span>
            </div>

            <div className="bg-emerald-900 text-white p-5 rounded-xl shadow-xs">
              <span className="text-xs text-emerald-200 block font-medium">
                {isNe ? 'सकल नाफा (Gross Profit)' : 'Gross Profit & Margin'}
              </span>
              <div className="text-2xl font-black font-mono text-white mt-1">
                {formatCurrency(pnlData.grossProfit, isNe)}
              </div>
              <span className="text-xs text-emerald-200 font-bold mt-1 block">
                {isNe ? `नाफा प्रतिशत: ${pnlData.grossMarginPercent.toFixed(1)}%` : `Gross Margin: ${pnlData.grossMarginPercent.toFixed(1)}%`}
              </span>
            </div>
          </div>

          {/* Detailed P&L Statement Card */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
              {isNe ? 'नाफा तथा नोक्सान विवरण (Income & Expenditure Breakdown)' : 'Profit and Loss Summary Statement'}
            </h3>

            <div className="divide-y divide-slate-100 text-sm">
              <div className="py-2.5 flex justify-between font-semibold text-slate-900">
                <span>१. व्यापारिक आम्दानी (Gross Operating Sales):</span>
                <span className="font-mono">{formatCurrency(pnlData.taxableRevenue + pnlData.exemptRevenue, isNe)}</span>
              </div>
              <div className="py-2.5 flex justify-between text-slate-600 pl-4">
                <span>- सामान खरिद लागत (Cost of Goods Sold):</span>
                <span className="font-mono text-rose-700">({formatCurrency(pnlData.cogs, isNe)})</span>
              </div>
              <div className="py-2.5 flex justify-between font-bold text-emerald-800 bg-emerald-50/50 px-2 rounded">
                <span>सकल नाफा (Gross Profit):</span>
                <span className="font-mono">{formatCurrency(pnlData.grossProfit, isNe)}</span>
              </div>
              <div className="py-2.5 flex justify-between text-slate-600 pl-4">
                <span>- कर्मचारी तलब तथा पेस्की खर्च (Staff Payroll/Advances):</span>
                <span className="font-mono text-rose-700">({formatCurrency(pnlData.staffExpenses, isNe)})</span>
              </div>
              <div className="py-2.5 flex justify-between text-slate-600 pl-4">
                <span>- ग्राहकलाई दिइएको छुट (Discounts Given):</span>
                <span className="font-mono text-rose-700">({formatCurrency(pnlData.totalDiscounts, isNe)})</span>
              </div>
              <div className="py-3 flex justify-between font-black text-base text-emerald-900 border-t-2 border-slate-900 bg-slate-50 px-3 rounded">
                <span>खुद नाफा (Net Operating Profit):</span>
                <span className="font-mono">{formatCurrency(pnlData.netProfit - pnlData.totalDiscounts, isNe)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 5. PARTY STATEMENT (Exact Screenshot UI: [ Party ⌄ ] [ This Month 📅 ] [ ] PDF With Item) */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'PARTY_STATEMENT' && (
        <div className="space-y-4">
          {(() => {
            const currentParty = allReportParties.find((p) => p.id === selectedPartyId) || allReportParties[0];
            const statementRows = buildPartyStatementRows(currentParty);
            const due = currentParty
              ? currentParty.currentBalance !== undefined
                ? currentParty.currentBalance
                : currentParty.openingBalance
              : 0;
            const isDup = currentParty
              ? (partyNameCounts.get(currentParty.name.trim().toLowerCase()) || 0) > 1
              : false;

            const dropdownFilteredParties = allReportParties.filter((p) => {
              if (
                addressFilter &&
                addressFilter !== 'ALL' &&
                !(p.address || '').toLowerCase().includes(addressFilter.toLowerCase())
              ) {
                return false;
              }
              if (!partyDropdownSearch.trim()) return true;
              const q = partyDropdownSearch.trim().toLowerCase();
              return (
                p.name.toLowerCase().includes(q) ||
                (p.address || '').toLowerCase().includes(q) ||
                (p.phone || '').includes(q) ||
                (p.panNo || '').toLowerCase().includes(q)
              );
            });

            return (
              <>
                {/* TOP BAR MATCHING SCREENSHOT: [ SANU KANCHA GOPALI ⌄ ] [ This Month 📅 ] [ ] PDF With Item */}
                <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                  <div className="flex flex-wrap items-center gap-3">
                    {/* 1. Searchable Party Dropdown Button matching [ SANU KANCHA GOPALI ⌄ ] */}
                    <div className="relative w-full sm:w-80">
                      <button
                        type="button"
                        onClick={() => {
                          setIsPartyDropdownOpen((prev) => !prev);
                          setIsPeriodDropdownOpen(false);
                        }}
                        className="w-full px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-left flex items-center justify-between gap-2 shadow-2xs cursor-pointer transition"
                      >
                        <div className="min-w-0">
                          <span className="text-xs sm:text-sm font-semibold text-slate-900 uppercase tracking-wide truncate block">
                            {currentParty ? currentParty.name : isNe ? 'पार्टी छान्नुहोस्' : 'Select Party'}
                          </span>
                          {currentParty?.address && (
                            <span className="text-[10px] font-bold text-emerald-700 truncate block">
                              📍 {currentParty.address} {isDup ? '• [एउटै नाम - ठेगानाले छुट्याइएको]' : ''}
                            </span>
                          )}
                        </div>
                        <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                      </button>

                      {isPartyDropdownOpen && (
                        <div className="absolute left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-xl z-40 overflow-hidden">
                          <div className="p-2 border-b border-slate-100 bg-slate-50 space-y-1.5">
                            <div className="relative">
                              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
                              <input
                                type="text"
                                autoFocus
                                value={partyDropdownSearch}
                                onChange={(e) => setPartyDropdownSearch(e.target.value)}
                                placeholder={isNe ? 'पार्टीको नाम वा ठेगाना खोज्नुहोस्...' : 'Search party name or address...'}
                                className="w-full pl-8 pr-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-600"
                              />
                            </div>
                            <select
                              value={addressFilter}
                              onChange={(e) => setAddressFilter(e.target.value)}
                              className="w-full px-2 py-1 text-[11px] border border-slate-200 rounded bg-white font-semibold text-slate-700"
                            >
                              <option value="ALL">{isNe ? '📍 सबै ठेगाना (All Addresses)' : '📍 All Addresses'}</option>
                              {partyUniqueAddresses.map((addr) => (
                                <option key={addr} value={addr}>
                                  📍 {addr}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="max-h-64 overflow-y-auto divide-y divide-slate-100">
                            {dropdownFilteredParties.length === 0 ? (
                              <div className="p-3 text-center text-xs text-slate-400">
                                {isNe ? 'कुनै पार्टी भेटिएन' : 'No party found'}
                              </div>
                            ) : (
                              dropdownFilteredParties.map((p) => {
                                const pDup = (partyNameCounts.get(p.name.trim().toLowerCase()) || 0) > 1;
                                const pBal = p.currentBalance !== undefined ? p.currentBalance : p.openingBalance;
                                const isSelected = currentParty?.id === p.id;
                                return (
                                  <button
                                    key={p.id}
                                    type="button"
                                    onClick={() => {
                                      setSelectedPartyId(p.id);
                                      setIsPartyDropdownOpen(false);
                                    }}
                                    className={`w-full px-3.5 py-2.5 text-left text-xs flex items-center justify-between gap-2 transition cursor-pointer ${
                                      isSelected ? 'bg-emerald-50 font-bold text-emerald-950' : 'hover:bg-slate-50 text-slate-800'
                                    }`}
                                  >
                                    <div className="min-w-0">
                                      <div className="font-bold uppercase truncate">{p.name}</div>
                                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 flex-wrap">
                                        <span>📍 {p.address || 'ठेगाना नखुलेको'}</span>
                                        {p.phone && <span>• 📞 {p.phone}</span>}
                                        {pDup && (
                                          <span className="px-1.5 py-0.2 bg-amber-100 text-amber-900 rounded text-[10px] font-bold">
                                            एउटै नाम
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                    <div className="text-right font-mono font-bold text-rose-700 shrink-0">
                                      रु. {pBal.toLocaleString()}
                                    </div>
                                  </button>
                                );
                              })
                            )}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* 2. Period Selector Button matching [ This Month 📅 ] */}
                    <div className="relative">
                      <button
                        type="button"
                        onClick={() => {
                          setIsPeriodDropdownOpen((prev) => !prev);
                          setIsPartyDropdownOpen(false);
                        }}
                        className="px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-xs sm:text-sm font-medium text-slate-700 flex items-center gap-2.5 shadow-2xs cursor-pointer transition"
                      >
                        <span>{getPartyPeriodButtonLabel()}</span>
                        <Calendar className="w-4 h-4 text-slate-500" />
                      </button>

                      {isPeriodDropdownOpen && (
                        <div className="absolute left-0 mt-1.5 w-72 bg-white border border-slate-200 rounded-xl shadow-xl z-40 p-3 space-y-2.5 text-xs">
                          <div className="font-bold text-slate-800 border-b border-slate-100 pb-1.5">
                            {isNe ? 'अवधि तथा आर्थिक वर्ष छान्नुहोस्' : 'Select Statement Period'}
                          </div>
                          <div className="grid grid-cols-2 gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setPartyTimeframeMode('MONTHLY');
                                setPartySelectedMonthBs(todayBs.substring(5, 7));
                                setPartySelectedYearBs('ALL');
                                setIsPeriodDropdownOpen(false);
                              }}
                              className={`px-2.5 py-1.5 rounded-lg font-bold text-left cursor-pointer ${
                                partyTimeframeMode === 'MONTHLY' && partySelectedMonthBs === todayBs.substring(5, 7)
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                              }`}
                            >
                              This Month (यो महिना)
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setPartyTimeframeMode('ALL');
                                setPartySelectedYearBs('ALL');
                                setIsPeriodDropdownOpen(false);
                              }}
                              className={`px-2.5 py-1.5 rounded-lg font-bold text-left cursor-pointer ${
                                partyTimeframeMode === 'ALL' && partySelectedYearBs === 'ALL'
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                              }`}
                            >
                              All Time (सबै समय)
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setPartyTimeframeMode('DAILY');
                                setPartyDailyDateBs(todayBs);
                                setIsPeriodDropdownOpen(false);
                              }}
                              className={`px-2.5 py-1.5 rounded-lg font-bold text-left cursor-pointer ${
                                partyTimeframeMode === 'DAILY'
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                              }`}
                            >
                              Today (आज)
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setPartyTimeframeMode('YEARLY');
                                setPartySelectedYearBs(company.fiscalYear || '081/82');
                                setIsPeriodDropdownOpen(false);
                              }}
                              className={`px-2.5 py-1.5 rounded-lg font-bold text-left cursor-pointer ${
                                partyTimeframeMode === 'YEARLY'
                                  ? 'bg-emerald-700 text-white'
                                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                              }`}
                            >
                              This Fiscal Year (आ.व.)
                            </button>
                          </div>

                          <div className="pt-1 border-t border-slate-100 space-y-2">
                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 mb-1">
                                {isNe ? 'आर्थिक वर्ष (Fiscal Year - आ.व.):' : 'Fiscal Year (आ.व.):'}
                              </label>
                              <select
                                value={partySelectedYearBs}
                                onChange={(e) => {
                                  setPartySelectedYearBs(e.target.value);
                                  if (partyTimeframeMode === 'ALL') setPartyTimeframeMode('YEARLY');
                                }}
                                className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white"
                              >
                                <option value="ALL">{isNe ? 'सबै आर्थिक वर्ष (All Fiscal Years)' : 'All Fiscal Years'}</option>
                                {availableFiscalYears.map((fy) => (
                                  <option key={fy} value={fy}>
                                    {isNe ? `आ.व. ${fy}` : `F.Y. ${fy}`}
                                  </option>
                                ))}
                              </select>
                            </div>

                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 mb-1">
                                {isNe ? 'महिना छान्नुहोस् (Select Month):' : 'Select Month:'}
                              </label>
                              <select
                                value={partySelectedMonthBs}
                                onChange={(e) => {
                                  setPartySelectedMonthBs(e.target.value);
                                  setPartyTimeframeMode('MONTHLY');
                                }}
                                className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white"
                              >
                                {NEPALI_MONTHS_LIST.map((m) => (
                                  <option key={m.code} value={m.code}>
                                    {m.nameNe}
                                  </option>
                                ))}
                              </select>
                            </div>

                            <div>
                              <label className="block text-[10px] font-bold text-slate-500 mb-1">
                                {isNe ? 'कस्टम मिति दायरा (From - To B.S.):' : 'Custom Date Range:'}
                              </label>
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="text"
                                  value={partyDateFromBs}
                                  onChange={(e) => {
                                    setPartyDateFromBs(e.target.value);
                                    setPartyTimeframeMode('CUSTOM_RANGE');
                                  }}
                                  placeholder="2081-04-01"
                                  className="w-full px-2 py-1 border border-slate-300 rounded font-mono"
                                />
                                <span>-</span>
                                <input
                                  type="text"
                                  value={partyDateToBs}
                                  onChange={(e) => {
                                    setPartyDateToBs(e.target.value);
                                    setPartyTimeframeMode('CUSTOM_RANGE');
                                  }}
                                  placeholder={todayBs}
                                  className="w-full px-2 py-1 border border-slate-300 rounded font-mono"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* 3. [ ] PDF With Item Checkbox matching screenshot */}
                    <label className="inline-flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-slate-50 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={pdfWithItem}
                        onChange={(e) => setPdfWithItem(e.target.checked)}
                        className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                      <span className="text-xs sm:text-sm font-medium text-slate-800">PDF With Item</span>
                    </label>

                    <div className="ml-auto flex items-center gap-2 flex-wrap">
                      <div className="text-right mr-1">
                        <span className="text-[10px] text-slate-500 block">
                          {isNe ? 'हालको कुल बाँकी:' : 'Outstanding Due:'}
                        </span>
                        <span className="font-mono font-bold text-sm sm:text-base text-rose-700">
                          {formatCurrency(due, isNe)}
                        </span>
                      </div>

                      {currentParty && due > 0 && (
                        <button
                          type="button"
                          onClick={() => {
                            setCollectionModalParty({
                              id: currentParty.id,
                              name: currentParty.name,
                              address: currentParty.address || '',
                              dueAmount: due
                            });
                            setCollectionAmount(due);
                          }}
                          className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold shadow-2xs transition cursor-pointer flex items-center gap-1"
                        >
                          <span>💰</span>
                          <span>{isNe ? 'रकम असुली' : 'Receive Due'}</span>
                        </button>
                      )}

                      {currentParty && (
                        <button
                          type="button"
                          onClick={() => {
                            setShareRecipientName(currentParty.name);
                            setShareRecipientPhone(currentParty.phone || '');
                            setShareTitle(`${currentParty.name} - पार्टी स्टेटमेन्ट (WhatsApp / PDF)`);
                            setShareMessage(buildCustomerStatementMessage(currentParty, company));
                            setIsShareModalOpen(true);
                          }}
                          className="px-3 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold shadow-2xs transition cursor-pointer flex items-center gap-1.5"
                          title="यस ग्राहकको फोन नम्बरमा सिधै WhatsApp वा PDF स्टेटमेन्ट पठाउनुहोस्"
                        >
                          <Share2 className="w-3.5 h-3.5 text-teal-200" />
                          <span>{isNe ? 'WhatsApp स्टेटमेन्ट' : 'WhatsApp Statement'}</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => setSelectedReport('PARTIES_REPORT')}
                        className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                      >
                        {isNe ? 'सबै पार्टी रिपोर्ट' : 'All Parties'}
                      </button>
                    </div>
                  </div>

                  {/* Quick Party Meta & Disambiguation Info */}
                  {currentParty && (
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 text-xs">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-black text-slate-900">{currentParty.name}</span>
                        <span className="px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-900 font-bold">
                          📍 {currentParty.address || 'ठेगाना नखुलेको'}
                        </span>
                        {currentParty.phone && (
                          <span className="font-mono text-slate-600">📞 {currentParty.phone}</span>
                        )}
                        {currentParty.panNo && (
                          <span className="font-mono text-slate-600">PAN: {currentParty.panNo}</span>
                        )}
                        {isDup && (
                          <span className="px-2 py-0.5 rounded bg-amber-100 border border-amber-300 text-amber-900 text-[11px] font-bold">
                            ⚠️ {isNe ? `एउटै नाम — ठेगाना (${currentParty.address}) बाट छुट्याइएको` : `Disambiguated by address: ${currentParty.address}`}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-slate-500">{isNe ? 'भुक्तानी अवस्था:' : 'Status:'}</span>
                        <select
                          value={partyPaymentStatusFilter}
                          onChange={(e) => setPartyPaymentStatusFilter(e.target.value as any)}
                          className="px-2 py-1 border border-slate-300 rounded-lg font-semibold bg-white text-slate-900 text-xs"
                        >
                          <option value="ALL">{isNe ? 'सबै (All)' : 'All'}</option>
                          <option value="UNPAID_DUE">{isNe ? 'बाँकी (Due)' : 'Unpaid / Due'}</option>
                          <option value="PARTIAL_PAID">{isNe ? 'आंशिक (Partial)' : 'Partial'}</option>
                          <option value="SETTLED_PAID">{isNe ? 'चुक्ता (Paid)' : 'Paid'}</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>

                {/* Party Detailed Ledger Table (with optional itemized rows when PDF With Item is checked) */}
                <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                        <tr>
                          <th className="py-2.5 px-3">क्र.सं.</th>
                          <th className="py-2.5 px-3">मिति (B.S.)</th>
                          <th className="py-2.5 px-3">
                            विवरण (Particulars) {pdfWithItem && <span className="text-emerald-700">• सामान विवरण सहित</span>}
                          </th>
                          <th className="py-2.5 px-3">माध्यम / अवस्था</th>
                          <th className="py-2.5 px-3 text-right">डेबिट (+) बिल रकम</th>
                          <th className="py-2.5 px-3 text-right">क्रेडिट (-) बुझाएको</th>
                          <th className="py-2.5 px-3 text-right">बाँकी (Balance)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {statementRows.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="py-8 text-center text-slate-400 font-medium">
                              {isNe
                                ? 'छानिएको अवधि वा फिल्टरमा कुनै कारोबार भेटिएन।'
                                : 'No transactions found for selected period or filters.'}
                            </td>
                          </tr>
                        ) : (
                          statementRows.map((entry, idx) => (
                            <React.Fragment key={entry.id}>
                              <tr className="hover:bg-slate-50/70">
                                <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{toNepaliDigits(idx + 1)}</td>
                                <td className="py-2.5 px-3 font-mono text-slate-600">{entry.dateBs}</td>
                                <td className="py-2.5 px-3 font-semibold text-slate-900">{entry.particulars}</td>
                                <td className="py-2.5 px-3 font-mono text-slate-500">
                                  <span className="mr-1.5">{entry.modeLabel}</span>
                                  <span
                                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                      entry.statusType === 'PAID'
                                        ? 'bg-emerald-50 text-emerald-800'
                                        : entry.statusType === 'PARTIAL'
                                        ? 'bg-amber-50 text-amber-800'
                                        : entry.statusType === 'OPENING'
                                        ? 'bg-slate-100 text-slate-700'
                                        : 'bg-rose-50 text-rose-800'
                                    }`}
                                  >
                                    {entry.statusLabel}
                                  </span>
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                                  {entry.debit > 0 ? formatCurrency(entry.debit, isNe) : '-'}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono text-emerald-700 font-semibold">
                                  {entry.credit > 0 ? formatCurrency(entry.credit, isNe) : '-'}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700">
                                  {formatCurrency(entry.runningBalance, isNe)}
                                </td>
                              </tr>

                              {/* Itemized Sub-Rows when "PDF With Item" is checked */}
                              {pdfWithItem &&
                                entry.itemsList.map((it, idx) => (
                                  <tr key={`${entry.id}-item-${idx}`} className="bg-emerald-50/40 text-[11px] text-slate-700">
                                    <td className="py-1.5 px-3"></td>
                                    <td colSpan={2} className="py-1.5 px-3 pl-7 font-medium text-emerald-950">
                                      ↳ 📦 <span className="font-bold">{it.name}</span> — {it.qty} {it.unit} × रु. {it.rate.toLocaleString()}
                                    </td>
                                    <td className="py-1.5 px-3 text-right font-mono text-slate-700">
                                      रु. {it.amount.toLocaleString()}
                                    </td>
                                    <td colSpan={2}></td>
                                  </tr>
                                ))}
                            </React.Fragment>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            );
          })()}
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 6. CASH IN HAND STATEMENT                                           */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'CASH_IN_HAND' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-emerald-900 text-white p-6 rounded-2xl shadow-xs space-y-2">
              <div className="flex justify-between items-center text-emerald-200 text-xs font-semibold uppercase">
                <span>{isNe ? 'हालको काउन्टर नगद मौज्दात' : 'Closing Cash in Hand'}</span>
                <Wallet className="w-5 h-5 text-emerald-300" />
              </div>
              <div className="text-3xl font-black font-mono text-white">
                {formatCurrency(dailyCash.closingCashInHand, isNe)}
              </div>
              <p className="text-xs text-emerald-200">
                {isNe ? 'दैनिक खरिद तथा सिधै भुक्तानीका लागि तयार रकम' : 'Current drawer balance ready for payouts'}
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
              <span className="text-xs font-bold text-slate-700 uppercase block">
                {isNe ? 'काउन्टर नगद प्रवाह हिसाब (Cash Flow Reconciliation)' : 'Cash Flow Reconciliation'}
              </span>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>सुरुवाती नगद (Opening Cash):</span>
                  <span className="font-mono font-semibold">{formatCurrency(dailyCash.openingCash, isNe)}</span>
                </div>
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>(+) नगद बिक्री संकलन (Cash Sales):</span>
                  <span className="font-mono font-semibold">+{formatCurrency(dailyCash.totalCashSales, isNe)}</span>
                </div>
                <div className="flex justify-between text-rose-700 font-medium">
                  <span>(-) कर्मचारीलाई पेस्की (Staff Advances):</span>
                  <span className="font-mono font-semibold">-{formatCurrency(dailyCash.totalAdvancesGiven, isNe)}</span>
                </div>
                <div className="flex justify-between font-bold text-slate-900 pt-2 border-t border-slate-200 text-sm">
                  <span>काउन्टरमा हुनुपर्ने मौज्दात:</span>
                  <span className="font-mono">{formatCurrency(dailyCash.closingCashInHand, isNe)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 7. BANK STATEMENT (दैनिक, मासिक, वार्षिक र कस्टम मिति प्रिन्ट र डाउनलोड) */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'BANK_STATEMENT' && (
        <div className="space-y-4">
          {reportToast && (
            <div className="p-3 bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center justify-between">
              <span>{reportToast}</span>
              <button onClick={() => setReportToast(null)} className="cursor-pointer">✕</button>
            </div>
          )}

          {/* Filter & Period Control Panel (Daily / Monthly / Yearly / Custom Date) */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border-2 border-blue-600/30 shadow-xs space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex flex-wrap items-center gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1">
                    बैंक खाता छान्नुहोस् (Select Bank Account):
                  </label>
                  <select
                    value={selectedBankId}
                    onChange={(e) => setSelectedBankId(e.target.value)}
                    className="px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 bg-white"
                  >
                    <option value="ALL">🏦 सबै बैंक खाताहरू (All Bank Accounts)</option>
                    {bankAccounts.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.bankName} ({b.accountNumber}) - मौज्दात: रु. {b.currentBalance.toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1">
                    स्टेटमेन्ट अवधि (Statement Period):
                  </label>
                  <div className="flex flex-wrap items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold">
                    {(
                      [
                        { id: 'ALL', label: 'सबै (All)' },
                        { id: 'DAILY', label: 'दैनिक (Daily)' },
                        { id: 'MONTHLY', label: 'मासिक (Monthly)' },
                        { id: 'YEARLY', label: 'वार्षिक (Yearly)' },
                        { id: 'CUSTOM', label: 'कस्टम मिति (Custom)' }
                      ] as const
                    ).map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setBankFilterMode(m.id)}
                        className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                          bankFilterMode === m.id
                            ? 'bg-blue-700 text-white shadow-xs'
                            : 'text-slate-700 hover:bg-white'
                        }`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleExportCurrentReportToExcel}
                  className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Excel डाउनलोड</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleExportCurrentReportToPdf('DOWNLOAD')}
                  className="px-3 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>PDF सेभ</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleExportCurrentReportToPdf('PRINT')}
                  className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5 text-emerald-400" />
                  <span>स्टेटमेन्ट प्रिन्ट</span>
                </button>
              </div>
            </div>

            {/* Dynamic Date Inputs based on selected filter mode */}
            {bankFilterMode !== 'ALL' && (
              <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl flex flex-wrap items-end gap-3 text-xs">
                {bankFilterMode === 'DAILY' && (
                  <div>
                    <label className="block font-bold text-blue-950 mb-1">
                      दैनिक मिति छान्नुहोस् (YYYY-MM-DD B.S.):
                    </label>
                    <input
                      type="text"
                      value={bankDailyDateBs}
                      onChange={(e) => setBankDailyDateBs(e.target.value)}
                      placeholder="2082-07-15"
                      className="px-3 py-1.5 bg-white border border-blue-300 rounded-lg font-mono font-bold text-slate-900"
                    />
                  </div>
                )}

                {bankFilterMode === 'MONTHLY' && (
                  <div>
                    <label className="block font-bold text-blue-950 mb-1">
                      वर्ष र महिना (YYYY-MM B.S.):
                    </label>
                    <input
                      type="text"
                      value={bankMonthYearBs}
                      onChange={(e) => setBankMonthYearBs(e.target.value)}
                      placeholder="2082-07"
                      className="px-3 py-1.5 bg-white border border-blue-300 rounded-lg font-mono font-bold text-slate-900"
                    />
                  </div>
                )}

                {bankFilterMode === 'YEARLY' && (
                  <div>
                    <label className="block font-bold text-blue-950 mb-1">
                      वार्षिक साल (YYYY B.S.):
                    </label>
                    <input
                      type="text"
                      value={bankYearBs}
                      onChange={(e) => setBankYearBs(e.target.value)}
                      placeholder="2082"
                      className="px-3 py-1.5 bg-white border border-blue-300 rounded-lg font-mono font-bold text-slate-900"
                    />
                  </div>
                )}

                {bankFilterMode === 'CUSTOM' && (
                  <>
                    <div>
                      <label className="block font-bold text-blue-950 mb-1">
                        सुरु मिति देखि (From Date B.S.):
                      </label>
                      <input
                        type="text"
                        value={bankCustomFromBs}
                        onChange={(e) => setBankCustomFromBs(e.target.value)}
                        placeholder="2082-01-01"
                        className="px-3 py-1.5 bg-white border border-blue-300 rounded-lg font-mono font-bold text-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-blue-950 mb-1">
                        अन्तिम मिति सम्म (To Date B.S.):
                      </label>
                      <input
                        type="text"
                        value={bankCustomToBs}
                        onChange={(e) => setBankCustomToBs(e.target.value)}
                        placeholder={todayBs}
                        className="px-3 py-1.5 bg-white border border-blue-300 rounded-lg font-mono font-bold text-slate-900"
                      />
                    </div>
                  </>
                )}

                <span className="text-xs font-bold text-blue-900 py-1.5">
                  📅 छानिएको अवधि: {bankStatementData.periodLabelNe}
                </span>
              </div>
            )}

            {/* 4 Summary KPI Cards for Bank Statement */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[11px] font-semibold text-slate-500 block">
                  सुरुवाती मौज्दात (Opening Balance)
                </span>
                <span className="text-base sm:text-lg font-mono font-black text-slate-900 mt-0.5 block">
                  {formatCurrency(bankStatementData.openingBalance, isNe)}
                </span>
              </div>

              <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200">
                <span className="text-[11px] font-semibold text-emerald-800 block">
                  अवधिमा कुल जम्मा (Total Deposit +)
                </span>
                <span className="text-base sm:text-lg font-mono font-black text-emerald-700 mt-0.5 block">
                  +{formatCurrency(bankStatementData.totalDeposit, isNe)}
                </span>
              </div>

              <div className="p-3.5 bg-rose-50 rounded-xl border border-rose-200">
                <span className="text-[11px] font-semibold text-rose-800 block">
                  अवधिमा कुल झिकिएको (Withdrawal -)
                </span>
                <span className="text-base sm:text-lg font-mono font-black text-rose-700 mt-0.5 block">
                  -{formatCurrency(bankStatementData.totalWithdrawal, isNe)}
                </span>
              </div>

              <div className="p-3.5 bg-blue-900 text-white rounded-xl shadow-xs">
                <span className="text-[11px] font-semibold text-blue-200 block">
                  अन्तिम बैंक मौज्दात (Closing Balance)
                </span>
                <span className="text-base sm:text-lg font-mono font-black text-white mt-0.5 block">
                  {formatCurrency(bankStatementData.closingBalance, isNe)}
                </span>
              </div>
            </div>
          </div>

          {/* Direct Manual Bank Deposit / Withdrawal / Charge Entry Form */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3 text-xs">
            <span className="font-bold text-slate-900 block">
              + बैंकमा सिधै नगद जम्मा, चेक भुक्तानी वा ब्याज/शुल्क टिपोट थप्नुहोस् (Add Bank Entry):
            </span>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (manualBankAmount <= 0 || !manualBankParticulars.trim()) return;
                recordManualBankEntry({
                  bankAccountId: manualBankId || bankAccounts[0]?.id || '',
                  dateBs: manualBankDateBs || todayBs,
                  type: manualBankType,
                  amount: manualBankAmount,
                  referenceNo: manualBankRef,
                  particulars: manualBankParticulars.trim()
                });
                setManualBankAmount(0);
                setManualBankRef('');
                setManualBankParticulars('');
                showReportToast('✓ बैंक स्टेटमेन्टमा कारोबार प्रविष्टि गरियो!');
              }}
              className="grid grid-cols-1 sm:grid-cols-6 gap-2.5 items-end"
            >
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">बैंक खाता:</label>
                <select
                  value={manualBankId}
                  onChange={(e) => setManualBankId(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white"
                >
                  {bankAccounts.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.bankName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">कारोबार प्रकार:</label>
                <select
                  value={manualBankType}
                  onChange={(e) => setManualBankType(e.target.value as any)}
                  className="w-full px-2.5 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white"
                >
                  <option value="DEPOSIT">बैंक जम्मा (Deposit +)</option>
                  <option value="WITHDRAWAL">बैंकबाट झिकिएको (Withdrawal -)</option>
                  <option value="INTEREST">बैंक ब्याज आम्दानी (Interest +)</option>
                  <option value="BANK_CHARGE">बैंक सेवा शुल्क (Charge -)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">मिति (B.S.):</label>
                <input
                  type="text"
                  value={manualBankDateBs}
                  onChange={(e) => setManualBankDateBs(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">रकम (Rs.)*:</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={manualBankAmount || ''}
                  onChange={(e) => setManualBankAmount(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full px-2.5 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">विवरण (Particulars)*:</label>
                <input
                  type="text"
                  required
                  value={manualBankParticulars}
                  onChange={(e) => setManualBankParticulars(e.target.value)}
                  placeholder="उदा: काउन्टर नगद बैंक दाखिला / चेक नं..."
                  className="w-full px-2.5 py-2 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <button
                type="submit"
                className="py-2 px-3 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-lg cursor-pointer"
              >
                + स्टेटमेन्टमा थप्नुहोस्
              </button>
            </form>
          </div>

          {/* Complete Chronological Bank Statement Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 bg-slate-50">
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  🏦 विस्तृत बैंक स्टेटमेन्ट खाता ({bankStatementData.periodLabelNe})
                </h3>
                <p className="text-[11px] text-slate-500">
                  बिक्री QR/FonePay दाखिला, ग्राहक असुली, खरिद भुक्तानी र सप्लायर बैंक ट्रान्सफर स्वतः समावेश
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-blue-900">
                कुल कारोबार: {bankStatementData.rows.length} वटा
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-900 text-white font-bold">
                  <tr>
                    <th className="py-2.5 px-3">क्र.सं.</th>
                    <th className="py-2.5 px-3">मिति (B.S.)</th>
                    <th className="py-2.5 px-3">भौचर / Ref</th>
                    <th className="py-2.5 px-3">बैंक खाता</th>
                    <th className="py-2.5 px-3">विवरण (Particulars)</th>
                    <th className="py-2.5 px-3">माध्यम</th>
                    <th className="py-2.5 px-3 text-right">जम्मा (Deposit +)</th>
                    <th className="py-2.5 px-3 text-right">झिकिएको (Withdrawal -)</th>
                    <th className="py-2.5 px-3 text-right">मौज्दात (Balance)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {/* Opening Balance Row */}
                  <tr className="bg-blue-50/60 font-bold text-slate-900">
                    <td className="py-2.5 px-3 font-mono font-bold text-blue-800">{toNepaliDigits(1)}</td>
                    <td className="py-2.5 px-3 font-mono">-</td>
                    <td className="py-2.5 px-3 font-mono text-blue-800">B/F</td>
                    <td className="py-2.5 px-3">सुरुवाती मौज्दात</td>
                    <td className="py-2.5 px-3">अघिल्लो मौज्दात सारिएको (Opening Balance Brought Forward)</td>
                    <td className="py-2.5 px-3">Opening</td>
                    <td className="py-2.5 px-3 text-right font-mono text-emerald-700">
                      {formatCurrency(bankStatementData.openingBalance, isNe)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono">-</td>
                    <td className="py-2.5 px-3 text-right font-mono text-blue-950">
                      {formatCurrency(bankStatementData.openingBalance, isNe)}
                    </td>
                  </tr>

                  {bankStatementData.rows.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-slate-400">
                        यस अवधिमा कुनै बैंक कारोबार भेटिएन।
                      </td>
                    </tr>
                  ) : (
                    bankStatementData.rows.map((row, idx) => (
                      <tr key={row.id} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{toNepaliDigits(idx + 2)}</td>
                        <td className="py-2.5 px-3 font-mono text-slate-700">{row.dateBs}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{row.voucherNo}</td>
                        <td className="py-2.5 px-3 text-slate-700 font-medium">{row.bankName}</td>
                        <td className="py-2.5 px-3 text-slate-900 font-medium">{row.particulars}</td>
                        <td className="py-2.5 px-3">
                          <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold text-[10px]">
                            {row.modeLabel}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700">
                          {row.deposit > 0 ? `+${formatCurrency(row.deposit, isNe)}` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-700">
                          {row.withdrawal > 0 ? `-${formatCurrency(row.withdrawal, isNe)}` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-black text-blue-950">
                          {formatCurrency(row.runningBalance, isNe)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 8. STAFF REPORT [New]                                               */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'STAFF_REPORT' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'कुल कर्मचारी संख्या' : 'Total Employees'}</span>
              <div className="text-xl font-bold font-mono text-slate-900 mt-1">{employees.length} जना</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'कुल तलब बजेट' : 'Total Monthly Salary'}</span>
              <div className="text-xl font-bold font-mono text-slate-900 mt-1">
                {formatCurrency(employees.reduce((s, e) => s + e.salaryMonthly, 0), isNe)}
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'कर्मचारी पेस्की/लिन बाँकी' : 'Staff Advances Outstanding'}</span>
              <div className="text-xl font-bold font-mono text-rose-700 mt-1">
                {formatCurrency(employees.reduce((s, e) => s + (e.openingDue || 0), 0), isNe)}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-50/70">
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  {isNe ? 'कर्मचारी हाजिरी, सामान खरिद कट्टी तथा पेस्की खाता' : 'Staff Roster, Purchases & Advances'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isNe ? 'दैनिक ज्याला भुक्तानी तथा मासिक/वार्षिक रिपोर्ट' : 'Daily wage payout and monthly/annual payroll reports'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('attendance')}
                className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <Calendar className="w-3.5 h-3.5 text-emerald-300" />
                <span>{isNe ? '👉 मासिक र वार्षिक रिपोर्ट खोल्नुहोस्' : '👉 Open Monthly & Annual Report'}</span>
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">क्र.सं.</th>
                    <th className="py-2.5 px-3">कर्मचारीको नाम</th>
                    <th className="py-2.5 px-3">पद</th>
                    <th className="py-2.5 px-3">ज्याला प्रकार</th>
                    <th className="py-2.5 px-3">दर / तलब</th>
                    <th className="py-2.5 px-3 text-center">आजको हाजिरी</th>
                    <th className="py-2.5 px-3 text-right">सुरुवाती पेस्की</th>
                    <th className="py-2.5 px-3 text-right">सामान खरिद कट्टी</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {employees.map((emp, idx) => {
                    const todayAtt = attendance.find((a) => a.employeeId === emp.id && a.dateBs === todayBs);
                    const isDaily = emp.wageType === 'DAILY';
                    return (
                      <tr key={emp.id} className="hover:bg-slate-50/70">
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{toNepaliDigits(idx + 1)}</td>
                        <td className="py-2.5 px-3 font-semibold text-slate-900">{emp.name}</td>
                        <td className="py-2.5 px-3 text-slate-600">{emp.role}</td>
                        <td className="py-2.5 px-3">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            isDaily ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
                          }`}>
                            {isDaily ? (isNe ? 'दैनिक ज्याला' : 'Daily') : (isNe ? 'मासिक तलब' : 'Monthly')}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono font-medium text-slate-900">
                          {isDaily
                            ? `रु. ${(emp.dailyWageRate || 1000).toLocaleString()}/दिन`
                            : formatCurrency(emp.salaryMonthly, isNe)}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            todayAtt?.status === 'PRESENT' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {todayAtt?.status || 'ABSENT'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-rose-700">
                          {formatCurrency(emp.openingDue || 0, isNe)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-500">
                          {isNe ? 'स्वतः कट्टी हुने' : 'Auto Deduct'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 9. TRANSACTIONS REPORT                                              */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'TRANSACTIONS_REPORT' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'कुल बिक्री कारोबार' : 'Sales Transactions'}</span>
              <div className="text-lg font-bold font-mono text-slate-900 mt-1">{invoices.length} वटा</div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'ग्राहक असुली कारोबार' : 'Customer Receipts'}</span>
              <div className="text-lg font-bold font-mono text-emerald-700 mt-1">
                {partyTransactions.filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER').length} वटा
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'पार्टी भुक्तानी कारोबार' : 'Supplier Payments'}</span>
              <div className="text-lg font-bold font-mono text-rose-700 mt-1">
                {partyTransactions.filter((t) => t.type === 'PAYMENT_TO_SUPPLIER').length} वटा
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'बैंक खाता संख्या' : 'Active Bank Accounts'}</span>
              <div className="text-lg font-bold font-mono text-blue-900 mt-1">{bankAccounts.length} वटा</div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <h3 className="font-bold text-sm text-slate-900 mb-2">
              {isNe ? 'कारोबारको माध्यम अनुसार वर्गीकरण (Payment Mode Distribution):' : 'Payment Mode Breakdown:'}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="text-emerald-900 font-semibold block">{isNe ? 'नगद कारोबार' : 'Cash'}</span>
                <span className="text-base font-bold font-mono text-emerald-800">
                  {formatCurrency(dailyCash.totalCashSales, isNe)}
                </span>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <span className="text-blue-900 font-semibold block">{isNe ? 'बैंक / QR कारोबार' : 'Bank & QR'}</span>
                <span className="text-base font-bold font-mono text-blue-800">
                  {formatCurrency(totalBankBalance, isNe)}
                </span>
              </div>
              <div className="p-3 bg-rose-50 rounded-lg border border-rose-200">
                <span className="text-rose-900 font-semibold block">{isNe ? 'उधारो बिक्री बाँकी' : 'Credit Dues'}</span>
                <span className="text-base font-bold font-mono text-rose-800">
                  {formatCurrency(totalReceivables, isNe)}
                </span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-900 font-semibold block">{isNe ? 'स्टक भ्यालु' : 'Stock Asset'}</span>
                <span className="text-base font-bold font-mono text-slate-800">
                  {formatCurrency(totalStockCostValuation, isNe)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 10. PARTIES REPORT (with Address, Name, Frequency & Year Filter)     */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'PARTIES_REPORT' && (
        <div className="space-y-4">
          {/* Summary Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block font-medium">
                {isNe ? 'कुल बाँकी उठाउनुपर्ने (Filter Total Due)' : 'Filtered Receivables'}
              </span>
              <div className="text-2xl font-bold font-mono text-rose-700 mt-1">
                {formatCurrency(
                  filteredPartiesWithTotals.reduce((s, item) => s + item.currentDue, 0),
                  isNe
                )}
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block font-medium">
                {isNe ? 'छानिएका पार्टी संख्या' : 'Filtered Parties'}
              </span>
              <div className="text-2xl font-bold font-mono text-slate-900 mt-1">
                {filteredPartiesWithTotals.length}
                <span className="text-xs text-slate-400 font-normal ml-1">/ {parties.length}</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block font-medium">
                {isNe ? 'अवधिको कुल बिक्री कारोबार' : 'Period Sales Total'}
              </span>
              <div className="text-2xl font-bold font-mono text-emerald-700 mt-1">
                {formatCurrency(
                  filteredPartiesWithTotals.reduce((s, item) => s + item.periodSales, 0),
                  isNe
                )}
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
              <span className="text-xs text-slate-500 block font-medium">
                {isNe ? 'डाटा एक्सपोर्ट (Data Export)' : 'Export Filtered Data'}
              </span>
              <div className="flex items-center gap-1.5 mt-2">
                <button
                  type="button"
                  onClick={handleExportCurrentReportToCsv}
                  className="flex-1 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center justify-center gap-1 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-slate-300" />
                  <span>CSV</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const headers = [
                      'क्र.सं.',
                      'पार्टी/ग्राहकको नाम',
                      'प्रकार',
                      'ठेगाना',
                      'फोन',
                      'प्यान',
                      'अवधिको बिक्री',
                      'अवधिको असुली',
                      'हालको बाँकी रकम'
                    ];
                    const rows = filteredPartiesWithTotals.map((item, idx) => [
                      idx + 1,
                      item.party.name,
                      item.party.type === 'SUPPLIER' ? 'सप्लायर' : 'ग्राहक',
                      item.party.address || '-',
                      item.party.phone || '-',
                      item.party.panNo || '-',
                      item.periodSales,
                      item.periodCollections,
                      item.currentDue
                    ]);
                    exportGenericToExcel(headers, rows, `Party_Report_${partyTimeframeMode}_${partySelectedYearBs}`);
                  }}
                  className="flex-1 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Excel</span>
                </button>
              </div>
            </div>
          </div>

          {/* Search, Address, Frequency, Year, Date Range, Amount Range & Payment Status Filter Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              {/* Name / Phone / PAN Search */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder={
                    isNe
                      ? 'ग्राहक वा पार्टीको नाम, ठेगाना, फोन वा प्यानले खोज्नुहोस्...'
                      : 'Search by party name, address, phone or PAN...'
                  }
                  value={partiesSearchQuery}
                  onChange={(e) => setPartiesSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium text-slate-900"
                />
              </div>

              {/* Address Filter Dropdown (Disambiguates same-name parties) */}
              <div className="w-full md:w-56">
                <select
                  value={addressFilter}
                  onChange={(e) => setAddressFilter(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold text-slate-900 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="ALL">{isNe ? '📍 सबै ठेगानाहरू (All Areas/Addresses)' : '📍 All Addresses'}</option>
                  {partyUniqueAddresses.map((addr) => (
                    <option key={addr} value={addr}>
                      📍 {addr}
                    </option>
                  ))}
                </select>
              </div>

              {/* Party Type Dropdown */}
              <div className="w-full md:w-44">
                <select
                  value={partyTypeFilter}
                  onChange={(e) => setPartyTypeFilter(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-bold text-slate-900 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="ALL">{isNe ? '👥 ग्राहक तथा सप्लायर' : '👥 All Parties'}</option>
                  <option value="CUSTOMER">{isNe ? '🛒 ग्राहक मात्र (Customers)' : '🛒 Customers Only'}</option>
                  <option value="SUPPLIER">{isNe ? '🚚 सप्लायर मात्र (Suppliers)' : '🚚 Suppliers Only'}</option>
                </select>
              </div>
            </div>

            {/* Timeframe Frequency (Daily/Monthly/Yearly/Custom Date Range) and Year/Month Pickers */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-slate-700 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{isNe ? 'अवधि आधार (Frequency):' : 'Period Frequency:'}</span>
                </span>

                {/* Frequency Mode Buttons */}
                <div className="inline-flex flex-wrap rounded-lg border border-slate-200 bg-slate-100 p-0.5">
                  <button
                    type="button"
                    onClick={() => setPartyTimeframeMode('ALL')}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer ${
                      partyTimeframeMode === 'ALL'
                        ? 'bg-emerald-700 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isNe ? 'सबै (All)' : 'All'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPartyTimeframeMode('DAILY')}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer ${
                      partyTimeframeMode === 'DAILY'
                        ? 'bg-emerald-700 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isNe ? 'दैनिक (Daily)' : 'Daily'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPartyTimeframeMode('MONTHLY')}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer ${
                      partyTimeframeMode === 'MONTHLY'
                        ? 'bg-emerald-700 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isNe ? 'मासिक (Monthly)' : 'Monthly'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPartyTimeframeMode('YEARLY')}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer ${
                      partyTimeframeMode === 'YEARLY'
                        ? 'bg-emerald-700 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isNe ? 'वार्षिक (Yearly)' : 'Yearly'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPartyTimeframeMode('CUSTOM_RANGE')}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition cursor-pointer ${
                      partyTimeframeMode === 'CUSTOM_RANGE'
                        ? 'bg-emerald-700 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isNe ? 'मिति दायरा (Date Range)' : 'Date Range'}
                  </button>
                </div>

                {/* Fiscal Year Selector (Select Fiscal Year / All) */}
                {partyTimeframeMode !== 'CUSTOM_RANGE' && (
                  <div className="flex items-center gap-1.5 ml-1">
                    <span className="font-semibold text-slate-600">{isNe ? 'आर्थिक वर्ष छान्नुहोस्:' : 'Fiscal Year:'}</span>
                    <select
                      value={partySelectedYearBs}
                      onChange={(e) => setPartySelectedYearBs(e.target.value)}
                      className="px-2.5 py-1 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white"
                    >
                      <option value="ALL">{isNe ? 'सबै आर्थिक वर्ष (All Fiscal Years)' : 'All Fiscal Years'}</option>
                      {availableFiscalYears.map((fy) => (
                        <option key={fy} value={fy}>
                          {isNe ? `आ.व. ${fy}` : `F.Y. ${fy}`}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Month Selector if Monthly Mode */}
                {partyTimeframeMode === 'MONTHLY' && (
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-slate-600">{isNe ? 'महिना:' : 'Month:'}</span>
                    <select
                      value={partySelectedMonthBs}
                      onChange={(e) => setPartySelectedMonthBs(e.target.value)}
                      className="px-2.5 py-1 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white"
                    >
                      {NEPALI_MONTHS_LIST.map((m) => (
                        <option key={m.code} value={m.code}>
                          {m.nameNe}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Daily Date Picker if Daily Mode */}
                {partyTimeframeMode === 'DAILY' && (
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-slate-600">{isNe ? 'मिति (BS):' : 'Date:'}</span>
                    <input
                      type="text"
                      value={partyDailyDateBs}
                      onChange={(e) => setPartyDailyDateBs(e.target.value)}
                      placeholder="2081-07-15"
                      className="w-28 px-2 py-1 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                    />
                    <button
                      type="button"
                      onClick={() => setPartyDailyDateBs(todayBs)}
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-semibold"
                    >
                      {isNe ? 'आज' : 'Today'}
                    </button>
                  </div>
                )}

                {/* Custom Date Range Pickers if CUSTOM_RANGE Mode */}
                {partyTimeframeMode === 'CUSTOM_RANGE' && (
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-semibold text-slate-600">{isNe ? 'मिति देखि (From BS):' : 'From BS:'}</span>
                    <input
                      type="text"
                      value={partyDateFromBs}
                      onChange={(e) => setPartyDateFromBs(e.target.value)}
                      placeholder="2081-01-01"
                      className="w-28 px-2 py-1 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                    />
                    <span className="font-semibold text-slate-600">{isNe ? 'सम्म (To BS):' : 'To BS:'}</span>
                    <input
                      type="text"
                      value={partyDateToBs}
                      onChange={(e) => setPartyDateToBs(e.target.value)}
                      placeholder={todayBs}
                      className="w-28 px-2 py-1 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Advanced Row: Amount Range (Min/Max) & Payment Status Filter */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
              <div className="flex flex-wrap items-center gap-3">
                {/* Amount Range (Min - Max) */}
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-slate-700">
                    {isNe ? '💰 रकम दायरा (Amount रु.):' : '💰 Amount Range (Rs.):'}
                  </span>
                  <input
                    type="number"
                    min="0"
                    value={partyMinAmount}
                    onChange={(e) => setPartyMinAmount(e.target.value)}
                    placeholder={isNe ? 'न्यूनतम (Min)' : 'Min Rs.'}
                    className="w-28 px-2.5 py-1 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                  <span className="text-slate-400 font-bold">-</span>
                  <input
                    type="number"
                    min="0"
                    value={partyMaxAmount}
                    onChange={(e) => setPartyMaxAmount(e.target.value)}
                    placeholder={isNe ? 'अधिकतम (Max)' : 'Max Rs.'}
                    className="w-28 px-2.5 py-1 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                {/* Payment Status Selector */}
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-slate-700">
                    {isNe ? '💳 भुक्तानी अवस्था (Payment Status):' : '💳 Payment Status:'}
                  </span>
                  <select
                    value={partyPaymentStatusFilter}
                    onChange={(e) => setPartyPaymentStatusFilter(e.target.value as any)}
                    className="px-2.5 py-1 border border-slate-300 rounded-lg font-bold text-slate-900 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="ALL">{isNe ? 'सबै अवस्था (All Status)' : 'All Status'}</option>
                    <option value="UNPAID_DUE">{isNe ? '🔴 बाँकी / उधारो (Unpaid / Due)' : '🔴 Unpaid / Due'}</option>
                    <option value="PARTIAL_PAID">{isNe ? '🟡 आंशिक भुक्तानी (Partial Paid)' : '🟡 Partial Paid'}</option>
                    <option value="SETTLED_PAID">{isNe ? '🟢 चुक्ता भएको (Settled / Paid)' : '🟢 Settled / Paid'}</option>
                  </select>
                </div>
              </div>

              {/* Reset / Active filter badge */}
              {(addressFilter !== 'ALL' ||
                partyTypeFilter !== 'ALL' ||
                partiesSearchQuery ||
                partyTimeframeMode !== 'ALL' ||
                partySelectedYearBs !== 'ALL' ||
                partyDateFromBs ||
                partyDateToBs ||
                partyMinAmount ||
                partyMaxAmount ||
                partyPaymentStatusFilter !== 'ALL') && (
                <button
                  type="button"
                  onClick={() => {
                    setAddressFilter('ALL');
                    setPartyTypeFilter('ALL');
                    setPartiesSearchQuery('');
                    setPartyTimeframeMode('ALL');
                    setPartySelectedYearBs('ALL');
                    setPartyDateFromBs('');
                    setPartyDateToBs('');
                    setPartyMinAmount('');
                    setPartyMaxAmount('');
                    setPartyPaymentStatusFilter('ALL');
                  }}
                  className="text-xs text-rose-600 hover:text-rose-800 font-semibold underline cursor-pointer"
                >
                  {isNe ? 'सबै फिल्टर हटाउनुहोस्' : 'Clear All Filters'}
                </button>
              )}
            </div>
          </div>

          {/* Party Report Main Table */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">क्र.सं.</th>
                    <th className="py-2.5 px-3">पार्टी / ग्राहकको नाम</th>
                    <th className="py-2.5 px-3">ठेगाना (Address)</th>
                    <th className="py-2.5 px-3">फोन / प्यान</th>
                    <th className="py-2.5 px-3 text-right">अवधिको बिक्री / खरिद</th>
                    <th className="py-2.5 px-3 text-right">अवधिको असुली / भुक्तानी</th>
                    <th className="py-2.5 px-3 text-right">हालको बाँकी रकम</th>
                    <th className="py-2.5 px-3 text-center">कार्य (Actions)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredPartiesWithTotals.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-10 text-center text-slate-400 font-medium">
                        {isNe
                          ? 'छानिएको ठेगाना वा फिल्टर अनुसार कुनै पार्टी भेटिएन।'
                          : 'No parties matched the selected address or search criteria.'}
                      </td>
                    </tr>
                  ) : (
                    filteredPartiesWithTotals.map((item, idx) => {
                      const p = item.party;
                      const due = item.currentDue;
                      return (
                        <tr key={p.id} className="hover:bg-slate-50/80 transition">
                          <td className="py-2.5 px-3 font-mono text-slate-400">{idx + 1}</td>
                          <td className="py-2.5 px-3">
                            <div className="flex flex-col gap-0.5">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-bold text-slate-900">{p.name}</span>
                                <span
                                  className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                                    p.type === 'SUPPLIER'
                                      ? 'bg-amber-100 text-amber-900 border border-amber-200'
                                      : 'bg-blue-100 text-blue-900 border border-blue-200'
                                  }`}
                                >
                                  {p.type === 'SUPPLIER' ? (isNe ? 'सप्लायर' : 'Supplier') : (isNe ? 'ग्राहक' : 'Customer')}
                                </span>
                                {item.isDuplicateName && (
                                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-900 border border-purple-300">
                                    ⚠️ {isNe ? `एउटै नाम • ठेगाना: ${p.address || 'नखुलेको'}` : `Same Name • ${p.address || 'No Address'}`}
                                  </span>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="py-2.5 px-3 font-medium text-slate-700">
                            {p.address ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-900 border border-emerald-200 font-bold text-[11px]">
                                <span>📍</span>
                                <span>{p.address}</span>
                              </span>
                            ) : (
                              <span className="text-slate-400">-</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-slate-600">
                            <div>{p.phone || '-'}</div>
                            {p.panNo && <div className="text-[10px] text-slate-400">PAN: {p.panNo}</div>}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                            {formatCurrency(item.periodSales || item.periodPurchases, isNe)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-emerald-700 font-bold">
                            {formatCurrency(item.periodCollections || item.periodPayments, isNe)}
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <div className="font-mono font-bold text-rose-700">
                              {formatCurrency(due, isNe)}
                            </div>
                            <span
                              className={`inline-block mt-0.5 text-[10px] font-bold px-1.5 py-0.2 rounded ${
                                item.paymentStatus === 'SETTLED_PAID'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : item.paymentStatus === 'PARTIAL_PAID'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {item.paymentStatus === 'SETTLED_PAID'
                                ? isNe
                                  ? 'चुक्ता (Settled)'
                                  : 'Settled'
                                : item.paymentStatus === 'PARTIAL_PAID'
                                ? isNe
                                  ? 'आंशिक बाँकी'
                                  : 'Partial Due'
                                : isNe
                                ? 'उधारो बाँकी'
                                : 'Unpaid Due'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3">
                            <div className="flex items-center justify-center gap-1.5">
                              {/* Ledger button */}
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedPartyId(p.id);
                                  setSelectedReport('PARTY_STATEMENT');
                                }}
                                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-white text-[11px] font-semibold rounded shadow-2xs transition cursor-pointer flex items-center gap-1"
                              >
                                <FileText className="w-3 h-3 text-slate-300" />
                                <span>{isNe ? 'लेजर' : 'Ledger'}</span>
                              </button>

                              {/* Collect button */}
                              {due > 0 && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setCollectionModalParty({
                                      id: p.id,
                                      name: p.name,
                                      address: p.address,
                                      dueAmount: due
                                    });
                                    setCollectionAmount(due);
                                  }}
                                  className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-semibold rounded shadow-2xs transition cursor-pointer flex items-center gap-1"
                                >
                                  <span>💰</span>
                                  <span>{isNe ? 'असुली' : 'Collect'}</span>
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 11. INVENTORY REPORT                                                */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'INVENTORY_REPORT' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'कुल मौज्दात खरिद मूल्य (Cost Valuation)' : 'Stock Valuation at Cost'}</span>
              <div className="text-2xl font-bold font-mono text-slate-900 mt-1">
                {formatCurrency(totalStockCostValuation, isNe)}
              </div>
              <span className="text-[11px] text-slate-400 mt-0.5 block">{items.length} {isNe ? 'प्रकारका सामग्रीहरू' : 'Product items'}</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'बिक्री मूल्य अनुसार मूल्याङ्कन (Retail)' : 'Valuation at Retail Price'}</span>
              <div className="text-2xl font-bold font-mono text-emerald-700 mt-1">
                {formatCurrency(totalStockRetailValuation, isNe)}
              </div>
              <span className="text-[11px] text-slate-400 mt-0.5 block">{isNe ? 'सम्भावित खुद्रा मूल्य' : 'Expected revenue'}</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block">{isNe ? 'न्यून मौज्दात भएका सामान (Low Stock)' : 'Low Stock Items'}</span>
              <div className="text-2xl font-bold font-mono text-amber-700 mt-1">
                {items.filter((i) => (i.currentStock || 0) <= (i.minStockAlert || 5)).length}
              </div>
              <span className="text-[11px] text-slate-400 mt-0.5 block">{isNe ? 'तुरुन्त खरिद अर्डर गर्नुपर्ने' : 'Reorder recommended'}</span>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 flex justify-between items-center">
              <h3 className="font-bold text-sm text-slate-900">
                {isNe ? 'सामानहरूको मौज्दात, भ्याट/नन-भ्याट स्टक तथा मूल्याङ्कन' : 'Stock List, VAT / Non-VAT Stocks & Valuation'}
              </h3>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleExportCurrentReportToCsv}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition shadow-xs cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>CSV</span>
                </button>
                <button
                  onClick={() => {
                    const headers = ['कोड', 'सामानको नाम', 'क्याटगोरी', 'एकाइ', 'खरिद मूल्य', 'बिक्री मूल्य', 'मौज्दात स्टक', 'भ्याट स्टक', 'नन-भ्याट स्टक', 'कुल लागत मूल्य'];
                    const rows = items.map((i) => [
                      i.code,
                      i.nameNe || i.nameEn,
                      i.category,
                      i.unit,
                      i.purchasePrice,
                      i.sellingPrice,
                      i.currentStock,
                      i.vatStock || 0,
                      i.nonVatStock || 0,
                      i.purchasePrice * (i.currentStock || 0)
                    ]);
                    exportGenericToExcel(headers, rows, 'Inventory_Valuation_Report');
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 text-white rounded-lg text-xs font-semibold hover:bg-emerald-800 transition shadow-xs cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Excel</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">क्र.सं.</th>
                    <th className="py-2.5 px-3">कोड</th>
                    <th className="py-2.5 px-3">सामानको नाम</th>
                    <th className="py-2.5 px-3">क्याटगोरी</th>
                    <th className="py-2.5 px-3 text-right">खरिद मूल्य</th>
                    <th className="py-2.5 px-3 text-right">बिक्री मूल्य</th>
                    <th className="py-2.5 px-3 text-right">मौज्दात</th>
                    <th className="py-2.5 px-3 text-right">भ्याट स्टक</th>
                    <th className="py-2.5 px-3 text-right">नन-भ्याट</th>
                    <th className="py-2.5 px-3 text-right">कुल लागत</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((item, idx) => (
                    <tr key={item.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{toNepaliDigits(idx + 1)}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{item.code}</td>
                      <td className="py-2.5 px-3 font-medium text-slate-900">
                        {isNe ? item.nameNe || item.nameEn : item.nameEn}
                      </td>
                      <td className="py-2.5 px-3 text-[11px] text-slate-500">{item.category}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-600">{formatCurrency(item.purchasePrice, isNe)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-900">{formatCurrency(item.sellingPrice, isNe)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-800">
                        {item.currentStock} {item.unit}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-blue-700">{item.vatStock || 0}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-500">{item.nonVatStock || 0}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                        {formatCurrency(item.purchasePrice * (item.currentStock || 0), isNe)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 12. INCOME EXPENSE REPORT                                           */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'INCOME_EXPENSE' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Income Side */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                <h3 className="font-bold text-sm text-emerald-900">{isNe ? 'आम्दानीका स्रोतहरू (Income)' : 'Income Sources'}</h3>
                <span className="font-mono font-bold text-base text-emerald-700">
                  {formatCurrency(pnlData.revenue, isNe)}
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>सामान बिक्री आम्दानी (Invoiced Sales):</span>
                  <span className="font-mono font-semibold">{formatCurrency(pnlData.taxableRevenue + pnlData.exemptRevenue, isNe)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>ग्राहक बाँकी असुली (Customer Collections):</span>
                  <span className="font-mono font-semibold">
                    {formatCurrency(
                      partyTransactions
                        .filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER' && (!t.incomeType || t.incomeType === 'CUSTOMER_COLLECTION'))
                        .reduce((s, t) => s + t.amount, 0),
                      isNe
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-blue-800 font-medium">
                  <span>अन्य आम्दानी (Other Income - सेवा, भाडा, अनुदान):</span>
                  <span className="font-mono font-bold">
                    {formatCurrency(
                      partyTransactions
                        .filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER' && t.incomeType === 'OTHER_INCOME')
                        .reduce((s, t) => s + t.amount, 0),
                      isNe
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-amber-800 font-medium">
                  <span>ऋण तथा सापटी प्राप्त (Loans & Borrowings Received):</span>
                  <span className="font-mono font-bold">
                    {formatCurrency(
                      partyTransactions
                        .filter((t) => t.type === 'COLLECTION_FROM_CUSTOMER' && t.incomeType === 'LOAN_RECEIVED')
                        .reduce((s, t) => s + t.amount, 0),
                      isNe
                    )}
                  </span>
                </div>
              </div>
            </div>

            {/* Expense Side */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                <h3 className="font-bold text-sm text-rose-900">{isNe ? 'व्यापारिक खर्चहरू (Expenses)' : 'Operating Expenses'}</h3>
                <span className="font-mono font-bold text-base text-rose-700">
                  {formatCurrency(pnlData.cogs + pnlData.staffExpenses + pnlData.totalDiscounts, isNe)}
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>सामान खरिद लागत (COGS):</span>
                  <span className="font-mono font-semibold text-rose-700">{formatCurrency(pnlData.cogs, isNe)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>कर्मचारी तलब तथा पेस्की (Payroll):</span>
                  <span className="font-mono font-semibold text-rose-700">{formatCurrency(pnlData.staffExpenses, isNe)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>ग्राहक छुट (Discounts):</span>
                  <span className="font-mono font-semibold text-rose-700">{formatCurrency(pnlData.totalDiscounts, isNe)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 13. BUSINESS STATUS REPORT (Balance Sheet & Executive Health)       */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'BUSINESS_STATUS' && (
        <div className="space-y-4">
          {/* Executive Net Worth Card */}
          <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-sm space-y-3">
            <div className="flex justify-between items-center text-slate-400 text-xs uppercase font-semibold">
              <span>{isNe ? 'व्यापारिक खुद पूँजी / सम्पत्ति (Net Business Capital)' : 'Net Business Worth'}</span>
              <Building2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="text-3xl sm:text-4xl font-black font-mono text-emerald-400">
              {formatCurrency(
                dailyCash.closingCashInHand + totalBankBalance + totalReceivables + totalStockCostValuation,
                isNe
              )}
            </div>
            <p className="text-xs text-slate-300">
              {isNe
                ? 'नगद + बैंक मौज्दात + ग्राहकबाट लिन बाँकी + मौज्दात सामानको खरिद मूल्य'
                : 'Cash + Bank Balance + Customer Receivables + Inventory Cost Value'}
            </p>
          </div>

          {/* Asset Breakdown Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-2">
                {isNe ? 'चालु सम्पत्तिहरू (Current Assets)' : 'Current Liquid Assets'}
              </h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center text-slate-700">
                  <span className="flex items-center gap-1.5">
                    <Wallet className="w-3.5 h-3.5 text-emerald-600" />
                    <span>काउन्टर नगद मौज्दात:</span>
                  </span>
                  <span className="font-mono font-bold">{formatCurrency(dailyCash.closingCashInHand, isNe)}</span>
                </div>
                <div className="flex justify-between items-center text-slate-700">
                  <span className="flex items-center gap-1.5">
                    <Landmark className="w-3.5 h-3.5 text-blue-600" />
                    <span>बैंक खाता मौज्दात:</span>
                  </span>
                  <span className="font-mono font-bold text-blue-900">{formatCurrency(totalBankBalance, isNe)}</span>
                </div>
                <div className="flex justify-between items-center text-slate-700">
                  <span className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-rose-600" />
                    <span>ग्राहकबाट उठाउन बाँकी:</span>
                  </span>
                  <span className="font-mono font-bold text-rose-700">{formatCurrency(totalReceivables, isNe)}</span>
                </div>
                <div className="flex justify-between items-center text-slate-700">
                  <span className="flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5 text-amber-600" />
                    <span>मौज्दात सामानको मूल्य:</span>
                  </span>
                  <span className="font-mono font-bold text-amber-800">{formatCurrency(totalStockCostValuation, isNe)}</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-2">
                {isNe ? 'वित्तीय सूचकहरू (Health Indicators)' : 'Business Financial Ratios'}
              </h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>नगद तथा बैंक तरलता:</span>
                  <span className="font-mono font-semibold text-emerald-700">
                    {formatCurrency(dailyCash.closingCashInHand + totalBankBalance, isNe)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>औसत नाफा दर (Margin):</span>
                  <span className="font-mono font-semibold text-emerald-700">{pnlData.grossMarginPercent.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>सक्रिय ग्राहक खाता संख्या:</span>
                  <span className="font-mono font-semibold">{parties.length} पार्टीहरू</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>इन्भेन्टरी प्रकार संख्या:</span>
                  <span className="font-mono font-semibold">{items.length} वस्तुहरू</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------- */}
      {/* 14. FINANCIAL STATEMENTS                                            */}
      {/* ------------------------------------------------------------------- */}
      {selectedReport === 'FINANCIAL_STATEMENTS' && (
        <FinancialStatementsScreen />
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: CUSTOMER DUE COLLECTION (ग्राहक बाँकी असुली - नगद वा बैंक)         */}
      {/* ========================================================================= */}
      {collectionModalParty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {isNe ? 'ग्राहक बाँकी रकम असुली (Receive Due)' : 'Collect Customer Due'}
                </h3>
                <p className="text-xs text-slate-500">
                  {collectionModalParty.name} ({collectionModalParty.address})
                </p>
              </div>
              <button
                onClick={() => setCollectionModalParty(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCollectionSubmit} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 flex items-center justify-between">
                <span className="font-semibold text-amber-950">
                  {isNe ? 'हाल उठाउन बाँकी रकम:' : 'Total Due:'}
                </span>
                <span className="font-mono font-bold text-base text-amber-900">
                  {formatCurrency(collectionModalParty.dueAmount, isNe)}
                </span>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'असुली भएको रकम (रु.)*' : 'Collected Amount (Rs.)*'}
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  max={collectionModalParty.dueAmount * 2}
                  value={collectionAmount}
                  onChange={(e) => setCollectionAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded font-mono font-bold text-base text-slate-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1.5">
                  {isNe ? 'रकम कुन माध्यमबाट प्राप्त भयो?*' : 'Payment Mode*'}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCollectionMode('BANK')}
                    className={`py-2 px-3 rounded-lg border text-center font-semibold transition cursor-pointer ${
                      collectionMode === 'BANK'
                        ? 'bg-blue-50 border-blue-600 text-blue-900 shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {isNe ? 'बैंक / QR दाखिला (Bank)' : 'Bank / QR Deposit'}
                  </button>

                  <button
                    type="button"
                    onClick={() => setCollectionMode('CASH')}
                    className={`py-2 px-3 rounded-lg border text-center font-semibold transition cursor-pointer ${
                      collectionMode === 'CASH'
                        ? 'bg-emerald-50 border-emerald-600 text-emerald-900 shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {isNe ? 'काउन्टर नगद (Cash)' : 'Counter Cash'}
                  </button>
                </div>
              </div>

              {collectionMode === 'BANK' && (
                <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-lg space-y-2 text-xs">
                  <label className="block text-[11px] font-bold text-blue-950">
                    {isNe ? 'रकम जम्मा भएको बैंक खाता छान्नुहोस् (Bank Account)*' : 'Select Deposit Bank Account*'}
                  </label>
                  <select
                    value={collectionBankId}
                    onChange={(e) => setCollectionBankId(e.target.value)}
                    className="w-full px-2.5 py-2 border border-blue-300 rounded bg-white text-xs font-semibold text-slate-900"
                  >
                    {bankAccounts.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.bankName} (मौज्दात: रु. {b.currentBalance})
                      </option>
                    ))}
                  </select>
                  <span className="text-[10px] text-blue-700 block">
                    *यो बैंक खाताको मौज्दातमा स्वतः रु. {collectionAmount} थपिनेछ।
                  </span>
                </div>
              )}

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'FonePay / चेक / Ref No.' : 'Reference / Cheque No.'}
                </label>
                <input
                  type="text"
                  placeholder="e.g. FONEPAY-9912 / CHQ-0012"
                  value={collectionRef}
                  onChange={(e) => setCollectionRef(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'कैफियत (Notes)' : 'Notes'}
                </label>
                <input
                  type="text"
                  placeholder="e.g. पुरानो बाँकी किस्ता भुक्तानी"
                  value={collectionNotes}
                  onChange={(e) => setCollectionNotes(e.target.value)}
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCollectionModalParty(null)}
                  className="px-3 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-lg shadow-xs transition"
                >
                  {isNe ? 'असुली सुरक्षित गर्नुहोस्' : 'Confirm Collection'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: ADD NEW BANK ACCOUNT                                              */}
      {/* ========================================================================= */}
      {isAddBankModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                {isNe ? 'नयाँ बैंक खाता दर्ता गर्नुहोस्' : 'Register New Bank Account'}
              </h3>
              <button
                onClick={() => setIsAddBankModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveBankSubmit} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'बैंकको नाम (Bank Name)*' : 'Bank Name*'}
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. कृषि विकास बैंक (ADBL)"
                  value={newBankName}
                  onChange={(e) => setNewBankName(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-300 rounded font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'खाता नम्बर (Account Number)*' : 'Account Number*'}
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. ०२१०१०१२३४५६७८९०"
                  value={newAccountNo}
                  onChange={(e) => setNewAccountNo(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-300 rounded font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isNe ? 'खातावालाको नाम (Account Holder)' : 'Account Holder Name'}
                </label>
                <input
                  type="text"
                  value={newAccountHolder}
                  onChange={(e) => setNewAccountHolder(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-300 rounded"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'शाखा (Branch)' : 'Branch'}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. भरतपुर"
                    value={newBranch}
                    onChange={(e) => setNewBranch(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-300 rounded"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    {isNe ? 'सुरुवाती मौज्दात (Opening Bal)' : 'Opening Balance'}
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={newOpeningBal}
                    onChange={(e) => setNewOpeningBal(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-2 border border-slate-300 rounded font-mono font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddBankModalOpen(false)}
                  className="px-3 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  {isNe ? 'रद्द' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-lg shadow-xs transition"
                >
                  {isNe ? 'बैंक खाता सुरक्षित गर्नुहोस्' : 'Save Bank Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Universal Share Modal for Any Report */}
      <UniversalShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        title={shareTitle}
        recipientName={shareRecipientName}
        initialPhone={shareRecipientPhone}
        message={shareMessage}
        bankDetails={company.bankAccounts && company.bankAccounts[0]}
        onGeneratePdfFile={handleGenerateCurrentReportPdfFile}
        pdfLabel={isNe ? 'रिपोर्ट PDF फाइल' : 'Report PDF File'}
      />

    </div>
  );
};
