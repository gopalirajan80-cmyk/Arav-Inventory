import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Item, ItemCategory, ItemType } from '../types';
import {
  Boxes,
  Plus,
  Search,
  Filter,
  Download,
  Edit2,
  Trash2,
  AlertTriangle,
  ArrowUpRight,
  X,
  Check,
  Camera,
  Image as ImageIcon,
  Sliders,
  RefreshCw,
  ArrowUpDown,
  Tag,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Radio,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Wand2,
  RotateCcw,
  History,
  Printer,
  FileText,
  Settings
} from 'lucide-react';
import { formatCurrency, toNepaliDigits, getTodayBsString } from '../utils/nepaliCalendar';
import { exportInventoryToExcel } from '../utils/excelEngine';
import { printOrDownloadReportPdf } from '../utils/pdfReportExporter';
import { fileToDataUrl } from '../utils/cameraHelper';
import {
  DEFAULT_PRIMARY_UNITS,
  DEFAULT_SECONDARY_UNITS,
  DEFAULT_UNIT_CONVERSIONS,
  DEFAULT_PRODUCT_CATEGORIES
} from './SettingsScreen';

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export interface VoiceCommandResult {
  transcript: string;
  matchedItem?: Item;
  action?: 'SET' | 'ADD' | 'SUBTRACT';
  quantity?: number;
  message?: string;
  success: boolean;
}

export const InventoryScreen: React.FC = () => {
  const {
    items,
    saveItem,
    deleteItem,
    adjustStock,
    reconcileItemStock,
    loadAgricultureStarterCatalog,
    company,
    inventorySubTab,
    setInventorySubTab,
    setActiveTab,
    language,
    t
  } = useApp();

  const activePrimaryUnits = useMemo(
    () =>
      company.inventoryPrimaryUnits && company.inventoryPrimaryUnits.length > 0
        ? company.inventoryPrimaryUnits
        : DEFAULT_PRIMARY_UNITS,
    [company.inventoryPrimaryUnits]
  );

  const activeSecondaryUnits = useMemo(
    () =>
      company.inventorySecondaryUnits && company.inventorySecondaryUnits.length > 0
        ? company.inventorySecondaryUnits
        : DEFAULT_SECONDARY_UNITS,
    [company.inventorySecondaryUnits]
  );

  const activeUnitConversions = useMemo(
    () =>
      company.unitConversionPresets && company.unitConversionPresets.length > 0
        ? company.unitConversionPresets
        : DEFAULT_UNIT_CONVERSIONS,
    [company.unitConversionPresets]
  );

  const activeProductCategories = useMemo(
    () =>
      company.productCategories && company.productCategories.length > 0
        ? company.productCategories
        : [...DEFAULT_PRODUCT_CATEGORIES, ...(company.customCategories || [])],
    [company.productCategories, company.customCategories]
  );

  const isNe = language === 'ne';

  // Voice Command Interface State
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceLanguage, setVoiceLanguage] = useState<'ne-NP' | 'en-US'>(isNe ? 'ne-NP' : 'en-US');
  const [liveTranscript, setLiveTranscript] = useState('');
  const [voiceResult, setVoiceResult] = useState<VoiceCommandResult | null>(null);
  const [targetVoiceItem, setTargetVoiceItem] = useState<Item | null>(null);
  const [manualVoiceInput, setManualVoiceInput] = useState('');
  const [speechSynthesisEnabled, setSpeechSynthesisEnabled] = useState(true);
  const [voiceHistory, setVoiceHistory] = useState<{
    id: string;
    item: Item;
    oldStock: number;
    newStock: number;
    transcript: string;
    time: string;
  }[]>([]);

  // Speech synthesis confirmation
  const speakText = (text: string, lang: string) => {
    if (!speechSynthesisEnabled || typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn('Speech synthesis error:', err);
    }
  };

  // Process voice command text against item list
  const processVoiceCommand = (rawText: string, specificItem?: Item | null) => {
    setIsListening(false);
    const text = rawText.trim();
    if (!text) return;

    // Convert Devanagari numerals
    const devanagariDigits: { [key: string]: string } = {
      '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
      '५': '5', '६': '6', '७': '7', '८': '8', '९': '9'
    };
    let cleaned = text;
    Object.keys(devanagariDigits).forEach((d) => {
      cleaned = cleaned.replaceAll(d, devanagariDigits[d]);
    });

    // Extract quantity digits
    const numberMatches = cleaned.match(/\d+/g);
    let qty: number | undefined;
    if (numberMatches && numberMatches.length > 0) {
      qty = parseInt(numberMatches[0], 10);
    }

    // Determine action: ADD / SUBTRACT / SET
    const lower = cleaned.toLowerCase();
    let action: 'SET' | 'ADD' | 'SUBTRACT' = 'SET';
    if (lower.includes('थप') || lower.includes('add') || lower.includes('plus') || lower.includes('बढाउ')) {
      action = 'ADD';
    } else if (lower.includes('घटाउ') || lower.includes('घटा') || lower.includes('minus') || lower.includes('deduct') || lower.includes('कम')) {
      action = 'SUBTRACT';
    }

    // Match item
    let matched: Item | undefined = specificItem || undefined;
    if (!matched) {
      let bestScore = 0;
      items.forEach((item) => {
        const en = item.nameEn.toLowerCase();
        const ne = (item.nameNe || '').toLowerCase();
        const code = item.code.toLowerCase();

        let score = 0;
        if (code && lower.includes(code)) score += 10;
        if (en && lower.includes(en)) score += 8;
        if (ne && lower.includes(ne)) score += 8;

        const words = lower.split(/\s+/);
        words.forEach((w) => {
          if (w.length >= 2) {
            if (en.includes(w)) score += 3;
            if (ne.includes(w)) score += 3;
          }
        });

        if (score > bestScore) {
          bestScore = score;
          matched = item;
        }
      });
    }

    if (!matched) {
      const res: VoiceCommandResult = {
        transcript: rawText,
        success: false,
        message: isNe
          ? `कुनै सामान पहिचान हुन सकेन ("${rawText}")। कृपया सामानको नाम वा कोड स्पष्ट बोल्नुहोस्।`
          : `No matching item found for "${rawText}". Please speak the item name clearly.`
      };
      setVoiceResult(res);
      speakText(res.message || '', voiceLanguage);
      return;
    }

    if (qty === undefined) {
      const res: VoiceCommandResult = {
        transcript: rawText,
        matchedItem: matched,
        success: false,
        message: isNe
          ? `सामान "${matched.nameNe || matched.nameEn}" पहिचान भयो, तर परिमाण (संख्या) बुझिएन।`
          : `Matched item "${matched.nameEn}", but stock count was not detected.`
      };
      setVoiceResult(res);
      speakText(res.message || '', voiceLanguage);
      return;
    }

    let calculatedStock = qty;
    if (action === 'ADD') {
      calculatedStock = matched.currentStock + qty;
    } else if (action === 'SUBTRACT') {
      calculatedStock = Math.max(0, matched.currentStock - qty);
    }

    const res: VoiceCommandResult = {
      transcript: rawText,
      matchedItem: matched,
      action,
      quantity: qty,
      success: true,
      message: isNe
        ? `${matched.nameNe || matched.nameEn} को स्टक ${matched.currentStock} बाट ${calculatedStock} ${matched.unit} मा अद्यावधिक गरियो!`
        : `Updated ${matched.nameEn} stock from ${matched.currentStock} to ${calculatedStock} ${matched.unit}!`
    };

    const oldStock = matched.currentStock;
    adjustStock(matched.id, calculatedStock);

    setVoiceHistory((prev) => [
      {
        id: `vlog-${Date.now()}`,
        item: matched!,
        oldStock,
        newStock: calculatedStock,
        transcript: rawText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      },
      ...prev
    ]);

    setVoiceResult(res);
    speakText(res.message || '', voiceLanguage);
  };

  // Start microphone speech recognition
  const startListening = (specificItem?: Item | null) => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      const fallbackPrompt = prompt(
        isNe
          ? 'तपाईंको ब्राउजरमा माइक अटो-पहिचान बन्द छ। कृपया यहाँ कमान्ड टाइप गर्नुहोस् (उदा: "चामल ५० बनाउनुहोस्"):'
          : 'Speech recognition not available. Please type voice command (e.g. "Rice stock 50"):',
        specificItem ? `${specificItem.nameNe || specificItem.nameEn} 50` : 'चामल ५० बनाउनुहोस्'
      );
      if (fallbackPrompt) {
        processVoiceCommand(fallbackPrompt, specificItem);
      }
      return;
    }

    try {
      window.speechSynthesis?.cancel();
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = voiceLanguage;

      setLiveTranscript(isNe ? 'आवाज सुन्दैछ... बोल्नुहोस् (Listening... Speak now)' : 'Listening... Speak now');
      setIsListening(true);
      setVoiceResult(null);

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setLiveTranscript(currentTranscript);

        if (event.results[0].isFinal) {
          processVoiceCommand(currentTranscript, specificItem);
        }
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        setLiveTranscript(
          isNe
            ? `माइक त्रुटि (${event.error})! तल कमान्ड टाइप गरी पनि परीक्षण गर्न सक्नुहुन्छ।`
            : `Mic Error (${event.error})! You can also type a command below.`
        );
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err) {
      console.error('Failed to start speech recognition:', err);
      setIsListening(false);
    }
  };

  // Undo previous voice stock update
  const handleUndoVoiceUpdate = (logId: string, itemId: string, oldStock: number) => {
    adjustStock(itemId, oldStock);
    setVoiceHistory((prev) => prev.filter((l) => l.id !== logId));
    if (voiceResult && voiceResult.matchedItem?.id === itemId) {
      setVoiceResult(null);
    }
    speakText(isNe ? 'स्टक पुरानै अवस्थामा फिर्ता गरियो' : 'Stock update undone', voiceLanguage);
  };

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedItemTypeFilter, setSelectedItemTypeFilter] = useState<string>('ALL');
  const [stockStatusFilter, setStockStatusFilter] = useState<'ALL' | 'LOW' | 'OUT' | 'IN_STOCK' | 'VAT_EXEMPT'>('ALL');
  const [sortBy, setSortBy] = useState<'NAME' | 'CODE' | 'PRICE_DESC' | 'PRICE_ASC' | 'STOCK_LOW'>('NAME');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Item | null>(null);

  // Quick Stock Adjustment modal
  const [stockModalItem, setStockModalItem] = useState<Item | null>(null);
  const [stockAdjustmentQty, setStockAdjustmentQty] = useState<number>(0);

  // VAT & Non-VAT Stock Reconciliation Modal state
  const [reconcileModalItem, setReconcileModalItem] = useState<Item | null>(null);
  const [reconcileTotalStock, setReconcileTotalStock] = useState<number>(0);
  const [reconcileVatStock, setReconcileVatStock] = useState<number>(0);
  const [reconcileNonVatStock, setReconcileNonVatStock] = useState<number>(0);
  const [reconcileReason, setReconcileReason] = useState<string>('भ्याट तथा नन-भ्याट मौज्दात मिलान');

  const openReconcileModal = (item: Item) => {
    setReconcileModalItem(item);
    setReconcileTotalStock(item.currentStock);
    setReconcileVatStock(item.vatStock !== undefined ? item.vatStock : item.currentStock);
    setReconcileNonVatStock(item.nonVatStock !== undefined ? item.nonVatStock : 0);
    setReconcileReason('भ्याट तथा नन-भ्याट मौज्दात मिलान');
  };

  React.useEffect(() => {
    if (inventorySubTab === 'ALL') {
      setStockStatusFilter('ALL');
      setSelectedItemTypeFilter('ALL');
    } else if (inventorySubTab === 'LOW_STOCK') {
      setStockStatusFilter('LOW');
      setSelectedItemTypeFilter('ALL');
    } else if (inventorySubTab === 'RAW_MATERIALS') {
      setStockStatusFilter('ALL');
      setSelectedItemTypeFilter('RAW_MATERIALS');
    } else if (inventorySubTab === 'FINISHED_GOODS') {
      setStockStatusFilter('ALL');
      setSelectedItemTypeFilter('FINISHED_GOODS');
    } else if (inventorySubTab === 'ADD_ITEM') {
      setEditingItem(null);
      setIsModalOpen(true);
    } else if (inventorySubTab === 'RECONCILE' && items.length > 0) {
      openReconcileModal(items[0]);
    }
  }, [inventorySubTab]);

  const handleSaveReconcile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reconcileModalItem) return;

    reconcileItemStock(reconcileModalItem.id, {
      adjustmentQty: reconcileTotalStock,
      isAbsolute: true,
      reason: reconcileReason,
      vatStock: reconcileVatStock,
      nonVatStock: reconcileNonVatStock
    });

    setReconcileModalItem(null);
  };

  // Item form state
  const [formCode, setFormCode] = useState('');
  const [formNameEn, setFormNameEn] = useState('');
  const [formNameNe, setFormNameNe] = useState('');
  const [formCategory, setFormCategory] = useState<ItemCategory>('TRACTOR_TILLER');
  const [formItemType, setFormItemType] = useState<ItemType>('FINISHED_GOODS');
  const [formUnit, setFormUnit] = useState('Pcs');
  const [formPrimaryUnit, setFormPrimaryUnit] = useState('Pcs');
  const [customUnitInput, setCustomUnitInput] = useState('');
  const [formSecondaryUnit, setFormSecondaryUnit] = useState('Pcs');
  const [customSecondaryUnitInput, setCustomSecondaryUnitInput] = useState('');
  const [formSecondaryUnitRatio, setFormSecondaryUnitRatio] = useState<number>(1);
  const [formSecondaryPurchasePrice, setFormSecondaryPurchasePrice] = useState<number>(0);
  const [formSecondarySellingPrice, setFormSecondarySellingPrice] = useState<number>(0);
  const [formHsCode, setFormHsCode] = useState('');
  const [formPurchasePrice, setFormPurchasePrice] = useState<number>(0);
  const [formSellingPrice, setFormSellingPrice] = useState<number>(0);
  const [formOpeningStock, setFormOpeningStock] = useState<number>(0);
  const [formStock, setFormStock] = useState<number>(0);
  const [formMinStock, setFormMinStock] = useState<number>(3);
  const [formIsVatExempt, setFormIsVatExempt] = useState(false);
  const [formImageUrl, setFormImageUrl] = useState<string>('');

  const handleImageCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const url = await fileToDataUrl(file, 800, 800, 0.75);
        setFormImageUrl(url);
      } catch (err) {
        console.error('Image capture error', err);
      }
    }
  };

  const openAddModal = () => {
    setEditingItem(null);
    setFormCode(`KY-${Math.floor(100 + Math.random() * 900)}`);
    setFormNameEn('');
    setFormNameNe('');
    setFormCategory(activeProductCategories[0]?.id || 'TRACTOR_TILLER');
    setFormItemType('FINISHED_GOODS');
    const defPri = activePrimaryUnits[0]?.code || 'Pcs';
    const defSec = activeSecondaryUnits[0]?.code || 'Pcs';
    setFormUnit(defPri);
    setFormPrimaryUnit(defPri);
    setCustomUnitInput('');
    setFormSecondaryUnit(defSec);
    setCustomSecondaryUnitInput('');
    setFormSecondaryUnitRatio(1);
    setFormSecondaryPurchasePrice(0);
    setFormSecondarySellingPrice(0);
    setFormHsCode('');
    setFormPurchasePrice(0);
    setFormSellingPrice(0);
    setFormOpeningStock(0);
    setFormStock(0);
    setFormMinStock(3);
    setFormIsVatExempt(false);
    setFormImageUrl('');
    setIsModalOpen(true);
  };

  const openEditModal = (item: Item) => {
    setEditingItem(item);
    setFormCode(item.code);
    setFormNameEn(item.nameEn);
    setFormNameNe(item.nameNe);
    setFormCategory(item.category);
    setFormItemType(item.itemType || 'FINISHED_GOODS');
    const existingPrimary = item.primaryUnit || item.unit || 'Pcs';
    const existingSecondary = item.secondaryUnit || existingPrimary;
    const ratio = item.secondaryUnitRatio && item.secondaryUnitRatio > 0 ? item.secondaryUnitRatio : 1;
    setFormUnit(existingPrimary);
    setFormPrimaryUnit(existingPrimary);
    setCustomUnitInput('');
    setFormSecondaryUnit(existingSecondary);
    setCustomSecondaryUnitInput('');
    setFormSecondaryUnitRatio(ratio);
    setFormHsCode(item.hsCode || item.hsnCode || '');
    setFormPurchasePrice(item.purchasePrice);
    setFormSellingPrice(item.sellingPrice);
    setFormSecondaryPurchasePrice(
      item.secondaryPurchasePrice !== undefined
        ? item.secondaryPurchasePrice
        : Math.round((item.purchasePrice / ratio) * 100) / 100
    );
    setFormSecondarySellingPrice(
      item.secondarySellingPrice !== undefined
        ? item.secondarySellingPrice
        : Math.round((item.sellingPrice / ratio) * 100) / 100
    );
    setFormOpeningStock(item.openingStock || 0);
    setFormStock(item.currentStock);
    setFormMinStock(item.minStockAlert);
    setFormIsVatExempt(item.isVatExempt);
    setFormImageUrl(item.imageUrl || '');
    setIsModalOpen(true);
  };

  const handleSaveItemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNameEn.trim() && !formNameNe.trim()) return;

    const finalPrimaryUnit =
      formPrimaryUnit === 'CUSTOM' ? customUnitInput.trim() || 'Pcs' : formPrimaryUnit;
    const finalSecondaryUnit =
      formSecondaryUnit === 'CUSTOM' ? customSecondaryUnitInput.trim() || 'Pcs' : formSecondaryUnit;
    const finalRatio = Math.max(1, Number(formSecondaryUnitRatio) || 1);
    const resolvedSecPurchase =
      formSecondaryPurchasePrice > 0
        ? formSecondaryPurchasePrice
        : Math.round((formPurchasePrice / finalRatio) * 100) / 100;
    const resolvedSecSelling =
      formSecondarySellingPrice > 0
        ? formSecondarySellingPrice
        : Math.round((formSellingPrice / finalRatio) * 100) / 100;

    const newItem: Item = {
      id: editingItem ? editingItem.id : `item-${Date.now()}`,
      code: formCode.trim() || `KY-${Date.now().toString().slice(-4)}`,
      nameEn: formNameEn.trim() || formNameNe.trim(),
      nameNe: formNameNe.trim() || formNameEn.trim(),
      category: formCategory,
      itemType: formItemType,
      unit: finalPrimaryUnit,
      primaryUnit: finalPrimaryUnit,
      secondaryUnit: finalSecondaryUnit,
      secondaryUnitRatio: finalRatio,
      secondaryPurchasePrice: resolvedSecPurchase,
      secondarySellingPrice: resolvedSecSelling,
      hsCode: formHsCode.trim(),
      hsnCode: formHsCode.trim(),
      purchasePrice: formPurchasePrice,
      sellingPrice: formSellingPrice,
      openingStock: formOpeningStock,
      currentStock: formStock,
      minStockAlert: formMinStock,
      isVatExempt: formIsVatExempt,
      imageUrl: formImageUrl || undefined
    };

    saveItem(newItem);
    setIsModalOpen(false);
  };

  const handleStockUpdate = () => {
    if (!stockModalItem) return;
    const newStock = stockModalItem.currentStock + stockAdjustmentQty;
    adjustStock(stockModalItem.id, newStock);
    setStockModalItem(null);
    setStockAdjustmentQty(0);
  };

  const filteredItems = useMemo(() => {
    let result = items.filter((it) => {
      const q = search.trim().toLowerCase();
      const matchSearch =
        !q ||
        it.nameEn.toLowerCase().includes(q) ||
        it.nameNe.toLowerCase().includes(q) ||
        it.code.toLowerCase().includes(q) ||
        it.category.toLowerCase().includes(q) ||
        (it.hsnCode && it.hsnCode.toLowerCase().includes(q));

      const matchCat = selectedCategory === 'ALL' || it.category === selectedCategory;
      const matchType = selectedItemTypeFilter === 'ALL' || (it.itemType || 'FINISHED_GOODS') === selectedItemTypeFilter;

      let matchStatus = true;
      if (stockStatusFilter === 'LOW') {
        matchStatus = it.currentStock <= it.minStockAlert;
      } else if (stockStatusFilter === 'OUT') {
        matchStatus = it.currentStock <= 0;
      } else if (stockStatusFilter === 'IN_STOCK') {
        matchStatus = it.currentStock > 0;
      } else if (stockStatusFilter === 'VAT_EXEMPT') {
        matchStatus = !!it.isVatExempt;
      }

      return matchSearch && matchCat && matchType && matchStatus;
    });

    return result.sort((a, b) => {
      if (sortBy === 'NAME') {
        const nameA = isNe ? a.nameNe || a.nameEn : a.nameEn;
        const nameB = isNe ? b.nameNe || b.nameEn : b.nameEn;
        return nameA.localeCompare(nameB);
      } else if (sortBy === 'CODE') {
        return a.code.localeCompare(b.code);
      } else if (sortBy === 'PRICE_DESC') {
        return b.sellingPrice - a.sellingPrice;
      } else if (sortBy === 'PRICE_ASC') {
        return a.sellingPrice - b.sellingPrice;
      } else if (sortBy === 'STOCK_LOW') {
        return a.currentStock - b.currentStock;
      }
      return 0;
    });
  }, [items, search, selectedCategory, stockStatusFilter, sortBy, isNe]);

  const getCategoryLabel = (cat: ItemCategory) => {
    const customMatch = activeProductCategories.find((c) => c.id === cat);
    if (customMatch) return isNe ? customMatch.labelNe : customMatch.labelEn;
    switch (cat) {
      case 'TRACTOR_TILLER': return t.catTractorTiller;
      case 'IRRIGATION_PUMP': return t.catIrrigationPump;
      case 'SPRAYER_TOOLS': return t.catSprayerTools;
      case 'SPARE_PARTS': return t.catSpareParts;
      case 'SEEDS_AGRO': return t.catSeedsAgro;
      case 'FERTILIZER': return t.catFertilizer;
      case 'PESTICIDES': return t.catPesticides;
      case 'LIVESTOCK_FEED': return t.catLivestockFeed;
      default: return cat;
    }
  };

  // Stock Valuation Summary Metrics (Merged from Inventory & Stock Report)
  const stockValuationMetrics = useMemo(() => {
    const totalCostValue = filteredItems.reduce(
      (sum, it) => sum + Math.max(0, it.currentStock) * (it.purchasePrice || 0),
      0
    );
    const totalSalesValue = filteredItems.reduce(
      (sum, it) => sum + Math.max(0, it.currentStock) * (it.sellingPrice || 0),
      0
    );
    const lowStockItemsCount = filteredItems.filter((it) => it.currentStock <= it.minStockAlert).length;
    const outOfStockCount = filteredItems.filter((it) => it.currentStock <= 0).length;
    return { totalCostValue, totalSalesValue, lowStockItemsCount, outOfStockCount };
  }, [filteredItems]);

  const handlePrintOrDownloadStockReport = (mode: 'PRINT' | 'DOWNLOAD') => {
    printOrDownloadReportPdf({
      company,
      titleNe: 'इन्भेन्टरी तथा गोदाम स्टक मूल्याङ्कन प्रतिवेदन (Inventory & Stock Valuation Report)',
      titleEn: 'Inventory & Stock Valuation Report',
      subtitleNe: `मिति: ${getTodayBsString()} | कुल सामान: ${filteredItems.length} | परल मूल्य: ${formatCurrency(stockValuationMetrics.totalCostValue, true)} | बिक्री मूल्य: ${formatCurrency(stockValuationMetrics.totalSalesValue, true)}`,
      headers: [
        'कोड (Code)',
        'सामानको नाम (Item Name)',
        'मुख्य = द्वितीय एकाइ',
        'हालको स्टक (Stock)',
        'खरिद दर (Cost)',
        'बिक्री दर (Sale)',
        'कुल परल मूल्य (Total Cost)',
        'कुल बिक्री मूल्य (Total Sales)'
      ],
      rows: filteredItems.map((it) => {
        const ratio = it.secondaryUnitRatio && it.secondaryUnitRatio > 1 ? it.secondaryUnitRatio : 1;
        const unitDesc =
          ratio > 1 && it.secondaryUnit
            ? `${it.unit} (= ${ratio} ${it.secondaryUnit})`
            : it.unit;
        const stockText =
          ratio > 1 && it.secondaryUnit
            ? `${it.currentStock} ${it.unit} (${Math.round(it.currentStock * ratio * 100) / 100} ${it.secondaryUnit})`
            : `${it.currentStock} ${it.unit}`;
        return [
          it.code,
          it.nameNe || it.nameEn,
          unitDesc,
          stockText,
          it.purchasePrice,
          it.sellingPrice,
          Math.max(0, it.currentStock) * (it.purchasePrice || 0),
          Math.max(0, it.currentStock) * (it.sellingPrice || 0)
        ];
      }),
      summaryCards: [
        { label: 'कुल परल मूल्य (Total Cost Valuation)', value: formatCurrency(stockValuationMetrics.totalCostValue, true) },
        { label: 'कुल बिक्री मूल्य (Total Sales Valuation)', value: formatCurrency(stockValuationMetrics.totalSalesValue, true) },
        { label: 'कम स्टक सामान (Low Stock Alert)', value: `${stockValuationMetrics.lowStockItemsCount} आइटम` }
      ],
      fileName: `Inventory_Stock_Valuation_Report_${getTodayBsString()}`,
      mode
    });
  };

  return (
    <div className="space-y-5">
      
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-xl border border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            {isNe ? 'इन्भेन्टरी, गोदाम स्टक तथा मूल्याङ्कन ड्यासबोर्ड' : 'Inventory, Stock & Valuation Dashboard'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {isNe
              ? 'मुख्य एकाइ (100mtr, 1 Carton, 12pcs) र द्वितीय एकाइ (Pcs, Mtr, Ltr) रूपान्तरण सहित स्टक तथा गोदाम मूल्याङ्कन रिपोर्ट'
              : 'Manage equipment stock with Primary = Secondary unit conversions and live Stock Valuation Report'}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          {items.length === 0 && (
            <button
              onClick={loadAgricultureStarterCatalog}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition cursor-pointer"
            >
              <span>{isNe ? 'नमुना सामान लोड गर्नुहोस्' : 'Load Sample Items'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => handlePrintOrDownloadStockReport('DOWNLOAD')}
            disabled={filteredItems.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white text-xs font-bold rounded-lg transition cursor-pointer shadow-2xs"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isNe ? 'स्टक PDF सेभ' : 'Stock PDF'}</span>
          </button>

          <button
            type="button"
            onClick={() => handlePrintOrDownloadStockReport('PRINT')}
            disabled={filteredItems.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-bold rounded-lg transition cursor-pointer shadow-2xs"
          >
            <Printer className="w-3.5 h-3.5 text-amber-400" />
            <span>{isNe ? 'स्टक प्रिन्ट' : 'Print Report'}</span>
          </button>

          <button
            onClick={() => exportInventoryToExcel(items)}
            disabled={items.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 border border-slate-200 hover:bg-slate-50 disabled:opacity-50 text-slate-700 text-xs font-semibold rounded-lg transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Excel</span>
          </button>

          <button
            onClick={() => {
              setTargetVoiceItem(null);
              setIsVoiceModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg shadow-xs transition cursor-pointer"
            title={isNe ? 'आवाज कमान्डबाट स्टक अद्यावधिक गर्नुहोस्' : 'Update item stock counts using microphone'}
          >
            <Mic className="w-4 h-4 text-slate-950 animate-pulse" />
            <span>{isNe ? 'आवाज स्टक' : 'Voice Stock'}</span>
          </button>

          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addNewItem}</span>
          </button>
        </div>
      </div>

      {/* Merged Inventory & Stock Valuation KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-[11px] font-bold text-slate-500">
            {isNe ? 'कुल गोदाम परल मूल्य (Cost Valuation)' : 'Total Stock Cost Valuation'}
          </div>
          <div className="text-lg font-black font-mono text-slate-900 mt-1">
            {formatCurrency(stockValuationMetrics.totalCostValue, isNe)}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {isNe ? `${toNepaliDigits(filteredItems.length)} प्रकारका सामान` : `${filteredItems.length} active items`}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-2xs">
          <div className="text-[11px] font-bold text-emerald-800">
            {isNe ? 'कुल सम्भावित बिक्री मूल्य (Sales Valuation)' : 'Estimated Sales Value'}
          </div>
          <div className="text-lg font-black font-mono text-emerald-700 mt-1">
            {formatCurrency(stockValuationMetrics.totalSalesValue, isNe)}
          </div>
          <div className="text-[10px] text-emerald-600 mt-0.5">
            {isNe
              ? `अनुमानित मार्जिन: ${formatCurrency(Math.max(0, stockValuationMetrics.totalSalesValue - stockValuationMetrics.totalCostValue), isNe)}`
              : 'Projected gross margin'}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-2xs">
          <div className="text-[11px] font-bold text-amber-800">
            {isNe ? 'न्यून स्टक अलर्ट (Low Stock Alert)' : 'Low Stock Items'}
          </div>
          <div className="text-lg font-black font-mono text-amber-700 mt-1">
            {isNe ? toNepaliDigits(stockValuationMetrics.lowStockItemsCount) : stockValuationMetrics.lowStockItemsCount}{' '}
            <span className="text-xs font-semibold">{isNe ? 'सामान' : 'Items'}</span>
          </div>
          <div className="text-[10px] text-amber-700 mt-0.5">
            {isNe ? `सकिएको स्टक: ${toNepaliDigits(stockValuationMetrics.outOfStockCount)} सामान` : `Out of stock: ${stockValuationMetrics.outOfStockCount}`}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-2xs flex flex-col justify-between">
          <div className="text-[11px] font-bold text-blue-900">
            {isNe ? 'एकाइ तथा क्याटगोरी सेटिङ' : 'Units & Categories Master'}
          </div>
          <div className="text-[11px] text-slate-600 my-1">
            {isNe ? 'मुख्य (100mtr, Carton) र द्वितीय (Pcs, Mtr, Ltr) मिलाउनुहोस्' : 'Configure primary & secondary units'}
          </div>
          <button
            type="button"
            onClick={() => {
              setActiveTab('settings');
              setTimeout(() => {
                window.dispatchEvent(
                  new CustomEvent('ims-sub-nav', {
                    detail: { target: 'settings', settingsTab: 'CATEGORIES' }
                  })
                );
              }, 50);
            }}
            className="w-full py-1.5 px-2.5 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Settings className="w-3.5 h-3.5" />
            <span>{isNe ? 'मास्टर सेटिङबाट एकाइ मिलाउने' : 'Configure Units & Categories'}</span>
          </button>
        </div>
      </div>

      {/* Real-Time Multi-Filter and Search Bar Panel */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3 shadow-2xs">
        
        {/* Search input with live clear (X) and result count pill */}
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center">
          
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-emerald-600 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder={isNe ? 'सामानको नाम, कोड वा क्याटगोरीबाट तुरुन्त खोज्नुहोस्...' : 'Search items by name, code, category, or HSN...'}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium text-slate-900 bg-white"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                title="Clear Search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Category Select */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs">
              <Filter className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-transparent font-medium text-slate-800 focus:outline-none cursor-pointer"
              >
                <option value="ALL">{t.allCategories}</option>
                {activeProductCategories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {isNe ? cat.labelNe : cat.labelEn}
                  </option>
                ))}
              </select>
            </div>

            {/* Item Type Select */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs">
              <Sliders className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <select
                value={selectedItemTypeFilter}
                onChange={(e) => setSelectedItemTypeFilter(e.target.value)}
                className="bg-transparent font-medium text-slate-800 focus:outline-none cursor-pointer"
              >
                <option value="ALL">{isNe ? 'सबै प्रकार (All Item Types)' : 'All Item Types'}</option>
                <option value="FINISHED_GOODS">{isNe ? 'तयारी औजार / सामान (Finished Goods)' : 'Finished Goods'}</option>
                <option value="RAW_MATERIAL">{isNe ? 'कच्चा पदार्थ (Raw Material)' : 'Raw Material'}</option>
                <option value="SPARE_PARTS">{isNe ? 'स्पेयर पार्ट्स (Spare Parts)' : 'Spare Parts'}</option>
                <option value="MERCHANDISE_TRADING">{isNe ? 'व्यापारिक माल (Trading Merchandise)' : 'Trading Merchandise'}</option>
                <option value="SERVICES_CHARGES">{isNe ? 'सेवा तथा मर्मत (Services & Repairs)' : 'Services & Repairs'}</option>
              </select>
            </div>

            {/* Sort By Select */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent font-medium text-slate-800 focus:outline-none cursor-pointer"
              >
                <option value="NAME">{isNe ? 'नाम (अक्षर क्रम)' : 'Name (A-Z)'}</option>
                <option value="CODE">{isNe ? 'कोड क्रम' : 'Code'}</option>
                <option value="STOCK_LOW">{isNe ? 'कम स्टक पहिले' : 'Stock (Lowest First)'}</option>
                <option value="PRICE_DESC">{isNe ? 'दर (उच्च देखि कम)' : 'Price (High to Low)'}</option>
                <option value="PRICE_ASC">{isNe ? 'दर (कम देखि उच्च)' : 'Price (Low to High)'}</option>
              </select>
            </div>
          </div>

        </div>

        {/* Stock Status Quick Filter Chips */}
        <div className="flex items-center justify-between gap-2 flex-wrap pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-semibold text-slate-500 mr-1">
              {isNe ? 'स्टक अवस्था:' : 'Stock Status:'}
            </span>

            <button
              onClick={() => setStockStatusFilter('ALL')}
              className={`px-2.5 py-1 rounded-md font-semibold transition cursor-pointer ${
                stockStatusFilter === 'ALL'
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {isNe ? `सबै सामान (${toNepaliDigits(items.length)})` : `All (${items.length})`}
            </button>

            <button
              onClick={() => setStockStatusFilter('LOW')}
              className={`px-2.5 py-1 rounded-md font-semibold transition cursor-pointer flex items-center gap-1 ${
                stockStatusFilter === 'LOW'
                  ? 'bg-amber-600 text-white shadow-2xs'
                  : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200'
              }`}
            >
              <AlertTriangle className="w-3 h-3" />
              <span>
                {isNe
                  ? `न्यून स्टक (${toNepaliDigits(items.filter((i) => i.currentStock <= i.minStockAlert).length)})`
                  : `Low Stock (${items.filter((i) => i.currentStock <= i.minStockAlert).length})`}
              </span>
            </button>

            <button
              onClick={() => setStockStatusFilter('OUT')}
              className={`px-2.5 py-1 rounded-md font-semibold transition cursor-pointer ${
                stockStatusFilter === 'OUT'
                  ? 'bg-rose-700 text-white shadow-2xs'
                  : 'bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-200'
              }`}
            >
              {isNe
                ? `सकिएको (${toNepaliDigits(items.filter((i) => i.currentStock <= 0).length)})`
                : `Out of Stock (${items.filter((i) => i.currentStock <= 0).length})`}
            </button>

            <button
              onClick={() => setStockStatusFilter('VAT_EXEMPT')}
              className={`px-2.5 py-1 rounded-md font-semibold transition cursor-pointer ${
                stockStatusFilter === 'VAT_EXEMPT'
                  ? 'bg-purple-700 text-white shadow-2xs'
                  : 'bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200'
              }`}
            >
              {isNe
                ? `भ्याट छुट (${toNepaliDigits(items.filter((i) => i.isVatExempt).length)})`
                : `VAT Exempt (${items.filter((i) => i.isVatExempt).length})`}
            </button>
          </div>

          <div className="text-[11px] font-mono text-slate-500">
            {isNe
              ? `नतिजा: ${toNepaliDigits(filteredItems.length)} / ${toNepaliDigits(items.length)} सामान`
              : `Showing ${filteredItems.length} of ${items.length} items`}
          </div>
        </div>

      </div>

      {/* Items Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        {filteredItems.length === 0 ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <Boxes className="w-10 h-10 mx-auto text-slate-300" />
            <p className="text-sm font-semibold text-slate-600">
              {isNe ? 'कुनै सामान फेला परेन।' : 'No inventory items found.'}
            </p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {isNe
                ? 'नयाँ सामान थप्न माथिको "नयाँ सामान दर्ता गर्नुहोस्" बटन थिच्नुहोस् वा Excel Import विजार्ड प्रयोग गर्नुहोस्।'
                : 'Click "Register New Item" above or use Excel Import Wizard to populate stock.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-bold">
                <tr>
                  <th className="py-2.5 px-2.5 w-14 text-center">फोटो</th>
                  <th className="py-2.5 px-3 w-24">कोड (Code)</th>
                  <th className="py-2.5 px-3">सामानको नाम (Item Name)</th>
                  <th className="py-2.5 px-3">सामग्री प्रकार / HS Code</th>
                  <th className="py-2.5 px-3">श्रेणी (Category)</th>
                  <th className="py-2.5 px-3 text-right">खरिद मूल्य</th>
                  <th className="py-2.5 px-3 text-right">बिक्री मूल्य</th>
                  <th className="py-2.5 px-3 text-center">पुरानो स्टक (Opening)</th>
                  <th className="py-2.5 px-3 text-center">हालको स्टक (Current)</th>
                  <th className="py-2.5 px-3 text-center">भ्याट (VAT)</th>
                  <th className="py-2.5 px-3 text-center w-28">कार्य (Action)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredItems.map((item) => {
                  const isLow = item.currentStock <= item.minStockAlert;
                  const itemTypeLabel =
                    item.itemType === 'RAW_MATERIAL'
                      ? 'कच्चा पदार्थ'
                      : item.itemType === 'SPARE_PARTS'
                      ? 'स्पेयर पार्ट्स'
                      : item.itemType === 'MERCHANDISE_TRADING'
                      ? 'व्यापारिक माल'
                      : item.itemType === 'SERVICES_CHARGES'
                      ? 'सेवा/मर्मत'
                      : 'तयारी औजार';
                  const itemTypeColor =
                    item.itemType === 'RAW_MATERIAL'
                      ? 'bg-amber-100 text-amber-900 border-amber-300'
                      : item.itemType === 'SPARE_PARTS'
                      ? 'bg-slate-200 text-slate-800 border-slate-300'
                      : item.itemType === 'MERCHANDISE_TRADING'
                      ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                      : item.itemType === 'SERVICES_CHARGES'
                      ? 'bg-blue-100 text-blue-900 border-blue-300'
                      : 'bg-indigo-50 text-indigo-800 border-indigo-200';

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2 px-2.5 text-center">
                        {item.imageUrl ? (
                          <img
                            src={item.imageUrl}
                            alt={item.nameEn}
                            className="w-10 h-10 object-cover rounded-md border border-slate-200 mx-auto shadow-2xs"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-md bg-slate-100 flex items-center justify-center text-slate-300 mx-auto">
                            <Boxes className="w-4 h-4" />
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-medium text-slate-600">
                        {item.code}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-slate-900">
                          {isNe ? item.nameNe || item.nameEn : item.nameEn}
                        </div>
                        {isNe && item.nameNe && (
                          <div className="text-[10px] text-slate-400 font-mono">
                            {item.nameEn}
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        <div className="flex flex-col gap-0.5 items-start">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${itemTypeColor}`}>
                            {itemTypeLabel}
                          </span>
                          {(item.hsCode || item.hsnCode) && (
                            <span className="text-[10px] font-mono text-slate-500">
                              HS: {item.hsCode || item.hsnCode}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] font-medium">
                          {getCategoryLabel(item.category)}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                        <div>{formatCurrency(item.purchasePrice, isNe)} <span className="text-[10px] text-slate-400">/{item.unit}</span></div>
                        {item.secondaryUnit && item.secondaryUnitRatio && item.secondaryUnitRatio > 1 && (
                          <div className="text-[10px] text-blue-700">
                            {formatCurrency(
                              item.secondaryPurchasePrice || Math.round((item.purchasePrice / item.secondaryUnitRatio) * 100) / 100,
                              isNe
                            )} /{item.secondaryUnit}
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                        <div>{formatCurrency(item.sellingPrice, isNe)} <span className="text-[10px] font-normal text-slate-400">/{item.unit}</span></div>
                        {item.secondaryUnit && item.secondaryUnitRatio && item.secondaryUnitRatio > 1 && (
                          <div className="text-[10px] font-semibold text-emerald-700">
                            {formatCurrency(
                              item.secondarySellingPrice || Math.round((item.sellingPrice / item.secondaryUnitRatio) * 100) / 100,
                              isNe
                            )} /{item.secondaryUnit}
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono text-slate-600">
                        <div>{isNe ? toNepaliDigits(item.openingStock || 0) : (item.openingStock || 0)} {item.unit}</div>
                        {item.secondaryUnit && item.secondaryUnitRatio && item.secondaryUnitRatio > 1 && (
                          <div className="text-[10px] text-slate-400">
                            (1 {item.unit} = {item.secondaryUnitRatio} {item.secondaryUnit})
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <div className="flex flex-col items-center justify-center gap-0.5">
                          <div className="flex items-center gap-1">
                            <span
                              className={`font-mono font-bold text-xs px-2 py-0.5 rounded ${
                                isLow
                                  ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                  : 'bg-slate-100 text-slate-800'
                              }`}
                            >
                              {isNe ? toNepaliDigits(item.currentStock) : item.currentStock} {item.unit}
                            </span>
                            {isLow && (
                              <span title={t.lowStockWarning} className="text-amber-600">
                                <AlertTriangle className="w-3.5 h-3.5" />
                              </span>
                            )}
                          </div>
                          {item.secondaryUnit && item.secondaryUnitRatio && item.secondaryUnitRatio > 1 && (
                            <span className="text-[10px] font-mono font-bold text-blue-800 bg-blue-50 px-1.5 py-0.2 rounded border border-blue-200">
                              = {Math.round(item.currentStock * item.secondaryUnitRatio * 100) / 100} {item.secondaryUnit}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        {item.isVatExempt ? (
                          <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            कर छुट
                          </span>
                        ) : (
                          <span className="text-[10px] font-semibold text-blue-800 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                            १३% भ्याट
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => {
                              setTargetVoiceItem(item);
                              setIsVoiceModalOpen(true);
                              startListening(item);
                            }}
                            title={isNe ? 'आवाजबाट स्टक अद्यावधिक (Voice Stock Update)' : 'Voice Stock Update for this Item'}
                            className="p-1 text-slate-500 hover:text-amber-700 hover:bg-amber-50 rounded cursor-pointer"
                          >
                            <Mic className="w-3.5 h-3.5 text-amber-600" />
                          </button>
                          <button
                            onClick={() => openReconcileModal(item)}
                            title={isNe ? 'भ्याट तथा नन-भ्याट स्टक मिलान (Reconcile)' : 'Reconcile VAT/Non-VAT Stock'}
                            className="p-1 text-slate-500 hover:text-purple-700 hover:bg-purple-50 rounded cursor-pointer"
                          >
                            <Sliders className="w-3.5 h-3.5 text-purple-700" />
                          </button>
                          <button
                            onClick={() => {
                              setStockModalItem(item);
                              setStockAdjustmentQty(1);
                            }}
                            title="Quick Stock In / Inflow"
                            className="p-1 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded cursor-pointer"
                          >
                            <ArrowUpRight className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => openEditModal(item)}
                            title="Edit Item"
                            className="p-1 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteItem(item.id)}
                            title={isNe ? 'सामान हटाउने (Owner Key आवश्यक)' : 'Delete Item (Requires Owner Key)'}
                            className="p-1 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-slate-900 text-white font-bold text-xs">
                <tr>
                  <td colSpan={5} className="py-3 px-3 text-right">
                    {isNe ? 'कुल गोदाम स्टक मूल्याङ्कन जम्मा (Total Stock Valuation):' : 'Total Stock Valuation:'}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-amber-300">
                    <div>{ isNe ? 'परल:' : 'Cost:' } {formatCurrency(stockValuationMetrics.totalCostValue, isNe)}</div>
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-300">
                    <div>{ isNe ? 'बिक्री:' : 'Sale:' } {formatCurrency(stockValuationMetrics.totalSalesValue, isNe)}</div>
                  </td>
                  <td colSpan={4} className="py-3 px-3 text-right font-mono text-slate-300">
                    {isNe ? `${toNepaliDigits(filteredItems.length)} सामान सूचीकृत` : `${filteredItems.length} items listed`}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Item Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                {editingItem ? (isNe ? 'सामानको विवरण सम्पादन' : 'Edit Item') : (isNe ? 'नयाँ कृषि मेसिनरी / औजार दर्ता' : 'Register New Item')}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveItemSubmit} className="p-5 space-y-4 text-xs overflow-y-auto flex-1 min-h-0">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    सामान कोड (Code)*
                  </label>
                  <input
                    type="text"
                    required
                    value={formCode}
                    onChange={(e) => setFormCode(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    सामग्री प्रकार (Item Type)*
                  </label>
                  <select
                    value={formItemType}
                    onChange={(e) => setFormItemType(e.target.value as ItemType)}
                    className="w-full px-2 py-2 border border-slate-200 rounded bg-white text-xs font-medium"
                  >
                    <option value="FINISHED_GOODS">{isNe ? 'तयारी औजार / सामान' : 'Finished Goods'}</option>
                    <option value="RAW_MATERIAL">{isNe ? 'कच्चा पदार्थ' : 'Raw Material'}</option>
                    <option value="SPARE_PARTS">{isNe ? 'स्पेयर पार्ट्स' : 'Spare Parts'}</option>
                    <option value="MERCHANDISE_TRADING">{isNe ? 'व्यापारिक माल' : 'Trading Merchandise'}</option>
                    <option value="SERVICES_CHARGES">{isNe ? 'सेवा / मर्मत चार्ज' : 'Services & Repairs'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    एच.एस. कोड (HS Code)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 8432.10.00"
                    value={formHsCode}
                    onChange={(e) => setFormHsCode(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    श्रेणी (Category)*
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as ItemCategory)}
                    className="w-full px-2.5 py-2 border border-slate-200 rounded bg-white"
                  >
                    {activeProductCategories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {isNe ? cat.labelNe : cat.labelEn}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  सामानको नाम (English)*
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Power Tiller 7HP Diesel"
                  value={formNameEn}
                  onChange={(e) => setFormNameEn(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  सामानको नाम (नेपाली)
                </label>
                <input
                  type="text"
                  placeholder="जस्तै: पावर टिलर ७ एचपी डिजेल"
                  value={formNameNe}
                  onChange={(e) => setFormNameNe(e.target.value)}
                  className="w-full px-2.5 py-2 border border-slate-200 rounded"
                />
              </div>

              {/* Mobile Camera / Photo Capture for Item */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-slate-700 flex items-center gap-1.5">
                    <Camera className="w-3.5 h-3.5 text-emerald-700" />
                    {isNe ? 'मोबाइल क्यामेराबाट सामानको फोटो' : 'Item Photo (Mobile Camera / Upload)'}
                  </span>
                  {formImageUrl && (
                    <button
                      type="button"
                      onClick={() => setFormImageUrl('')}
                      className="text-[10px] text-rose-600 hover:underline cursor-pointer"
                    >
                      {isNe ? 'हटाउनुहोस्' : 'Remove'}
                    </button>
                  )}
                </div>
                <div className="flex items-center gap-3">
                  {formImageUrl ? (
                    <img
                      src={formImageUrl}
                      alt="Preview"
                      className="w-14 h-14 object-cover rounded-lg border border-slate-300 shadow-2xs"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-lg border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 bg-white">
                      <Camera className="w-5 h-5 text-slate-400" />
                    </div>
                  )}
                  <div className="flex-1">
                    <label
                      htmlFor="item-camera-input"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:border-emerald-600 hover:text-emerald-700 rounded-lg text-xs font-semibold cursor-pointer shadow-2xs transition"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>{formImageUrl ? (isNe ? 'अर्को फोटो खिच्नुहोस्' : 'Change Photo') : (isNe ? 'फोटो खिच्नुहोस् / अपलोड' : 'Take / Upload Photo')}</span>
                    </label>
                    <input
                      type="file"
                      id="item-camera-input"
                      accept="image/*"
                      capture="environment"
                      onChange={handleImageCapture}
                      className="hidden"
                    />
                    <p className="text-[10px] text-slate-400 mt-1">
                      {isNe ? 'मोबाइल फोनको क्यामेराले सिधै फोटो खिच्न सकिन्छ' : 'Direct capture with phone camera or select file'}
                    </p>
                  </div>
                </div>
              </div>

              {/* PRIMARY UNIT = SECONDARY UNIT CONVERSION & PRICING HUB */}
              <div className="p-3.5 bg-emerald-50/70 rounded-xl border border-emerald-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-black text-emerald-950 block">
                      📦 मुख्य एकाइ = द्वितीय एकाइ तथा खरिद/बिक्री दर मिलान
                    </span>
                    <span className="text-[10px] text-emerald-800">
                      जस्तै: 100mtr = 100 Mtr, 1 Carton = 12 Pcs, 12pcs = 12 Pcs, 1 Roll = 100 Mtr
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsModalOpen(false);
                      setActiveTab('settings');
                      setTimeout(() => {
                        window.dispatchEvent(
                          new CustomEvent('ims-sub-nav', {
                            detail: { target: 'settings', settingsTab: 'CATEGORIES' }
                          })
                        );
                      }, 50);
                    }}
                    className="px-2 py-1 bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-md text-[10px] font-bold cursor-pointer"
                  >
                    ⚙️ मास्टर सेटिङबाट एकाइ मिलाउने
                  </button>
                </div>

                {/* Quick 1-Click Conversion Presets */}
                <div className="flex flex-wrap gap-1.5">
                  {activeUnitConversions.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setFormPrimaryUnit(preset.primaryUnit);
                        setFormUnit(preset.primaryUnit);
                        setFormSecondaryUnit(preset.secondaryUnit);
                        setFormSecondaryUnitRatio(preset.ratio);
                        if (formPurchasePrice > 0) {
                          setFormSecondaryPurchasePrice(Math.round((formPurchasePrice / preset.ratio) * 100) / 100);
                        }
                        if (formSellingPrice > 0) {
                          setFormSecondarySellingPrice(Math.round((formSellingPrice / preset.ratio) * 100) / 100);
                        }
                      }}
                      className={`px-2 py-1 rounded text-[10px] font-mono font-bold border transition cursor-pointer ${
                        formPrimaryUnit === preset.primaryUnit &&
                        formSecondaryUnit === preset.secondaryUnit &&
                        formSecondaryUnitRatio === preset.ratio
                          ? 'bg-emerald-700 text-white border-emerald-700'
                          : 'bg-white text-slate-700 border-emerald-200 hover:bg-emerald-100'
                      }`}
                    >
                      {preset.primaryUnit} = {preset.ratio} {preset.secondaryUnit}
                    </button>
                  ))}
                </div>

                {/* Primary Unit = Ratio * Secondary Unit Row */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-end bg-white p-2.5 rounded-lg border border-emerald-200">
                  <div className="sm:col-span-5">
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">
                      मुख्य एकाइ (Primary Unit — उदा: 100mtr, 1 Carton, 12pcs)*
                    </label>
                    <select
                      value={
                        activePrimaryUnits.some((u) => u.code === formPrimaryUnit)
                          ? formPrimaryUnit
                          : 'CUSTOM'
                      }
                      onChange={(e) => {
                        const val = e.target.value;
                        setFormPrimaryUnit(val);
                        if (val !== 'CUSTOM') {
                          setFormUnit(val);
                          // Auto-apply matching preset if available
                          const matchedPreset = activeUnitConversions.find(
                            (p) => p.primaryUnit.toLowerCase() === val.toLowerCase()
                          );
                          if (matchedPreset) {
                            setFormSecondaryUnit(matchedPreset.secondaryUnit);
                            setFormSecondaryUnitRatio(matchedPreset.ratio);
                            if (formPurchasePrice > 0) {
                              setFormSecondaryPurchasePrice(
                                Math.round((formPurchasePrice / matchedPreset.ratio) * 100) / 100
                              );
                            }
                            if (formSellingPrice > 0) {
                              setFormSecondarySellingPrice(
                                Math.round((formSellingPrice / matchedPreset.ratio) * 100) / 100
                              );
                            }
                          }
                        }
                      }}
                      className="w-full px-2 py-1.5 border border-slate-300 rounded bg-white text-xs font-bold text-slate-900"
                    >
                      {activePrimaryUnits.map((u) => (
                        <option key={u.id} value={u.code}>
                          {u.code} — {u.labelNe}
                        </option>
                      ))}
                      <option value="CUSTOM">✏️ + आफैँ टाइप गर्ने (Custom Primary Unit)</option>
                    </select>
                    {formPrimaryUnit === 'CUSTOM' && (
                      <input
                        type="text"
                        placeholder="उदा: 100mtr / 1 Carton / 12pcs"
                        value={customUnitInput}
                        onChange={(e) => setCustomUnitInput(e.target.value)}
                        className="w-full mt-1.5 px-2 py-1.5 border border-emerald-400 rounded text-xs font-mono font-bold"
                      />
                    )}
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-[10px] font-bold text-blue-900 mb-1">
                      = कति द्वितीय एकाइ? (Ratio)
                    </label>
                    <div className="flex items-center gap-1">
                      <span className="font-black text-slate-500">=</span>
                      <input
                        type="number"
                        min={1}
                        step="any"
                        value={formSecondaryUnitRatio}
                        onChange={(e) => {
                          const r = Math.max(1, parseFloat(e.target.value) || 1);
                          setFormSecondaryUnitRatio(r);
                          if (formPurchasePrice > 0) {
                            setFormSecondaryPurchasePrice(Math.round((formPurchasePrice / r) * 100) / 100);
                          }
                          if (formSellingPrice > 0) {
                            setFormSecondarySellingPrice(Math.round((formSellingPrice / r) * 100) / 100);
                          }
                        }}
                        className="w-full px-2 py-1.5 border border-blue-300 rounded font-mono font-black text-center text-blue-950 bg-blue-50/40"
                      />
                    </div>
                  </div>

                  <div className="sm:col-span-4">
                    <label className="block text-[10px] font-bold text-blue-900 mb-1">
                      द्वितीय एकाइ (Secondary: Pcs / Mtr / Ltr)
                    </label>
                    <select
                      value={
                        activeSecondaryUnits.some((u) => u.code === formSecondaryUnit)
                          ? formSecondaryUnit
                          : 'CUSTOM'
                      }
                      onChange={(e) => setFormSecondaryUnit(e.target.value)}
                      className="w-full px-2 py-1.5 border border-blue-300 rounded bg-white text-xs font-bold text-blue-950"
                    >
                      {activeSecondaryUnits.map((u) => (
                        <option key={u.id} value={u.code}>
                          {u.code} — {u.labelNe}
                        </option>
                      ))}
                      <option value="CUSTOM">✏️ + अन्य द्वितीय एकाइ (Custom)</option>
                    </select>
                    {formSecondaryUnit === 'CUSTOM' && (
                      <input
                        type="text"
                        placeholder="उदा: Pcs / Mtr / Ltr"
                        value={customSecondaryUnitInput}
                        onChange={(e) => setCustomSecondaryUnitInput(e.target.value)}
                        className="w-full mt-1.5 px-2 py-1.5 border border-blue-400 rounded text-xs font-mono font-bold"
                      />
                    )}
                  </div>
                </div>

                {/* Primary & Secondary Purchase / Selling Rates */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-white p-2.5 rounded-lg border border-slate-200">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 mb-1">
                      मुख्य खरिद दर ({formPrimaryUnit === 'CUSTOM' ? customUnitInput || 'Primary' : formPrimaryUnit})
                    </label>
                    <input
                      type="number"
                      min={0}
                      step="any"
                      value={formPurchasePrice}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        setFormPurchasePrice(val);
                        const r = Math.max(1, formSecondaryUnitRatio || 1);
                        setFormSecondaryPurchasePrice(Math.round((val / r) * 100) / 100);
                      }}
                      className="w-full px-2 py-1.5 border border-slate-300 rounded font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-emerald-800 mb-1">
                      मुख्य बिक्री दर ({formPrimaryUnit === 'CUSTOM' ? customUnitInput || 'Primary' : formPrimaryUnit})*
                    </label>
                    <input
                      type="number"
                      min={0}
                      step="any"
                      required
                      value={formSellingPrice}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        setFormSellingPrice(val);
                        const r = Math.max(1, formSecondaryUnitRatio || 1);
                        setFormSecondarySellingPrice(Math.round((val / r) * 100) / 100);
                      }}
                      className="w-full px-2 py-1.5 border-2 border-emerald-400 rounded font-mono font-black text-emerald-950"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-blue-800 mb-1">
                      द्वितीय खरिद दर (१ {formSecondaryUnit === 'CUSTOM' ? customSecondaryUnitInput || 'Sec' : formSecondaryUnit})
                    </label>
                    <input
                      type="number"
                      min={0}
                      step="any"
                      value={formSecondaryPurchasePrice}
                      onChange={(e) => setFormSecondaryPurchasePrice(parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1.5 border border-blue-200 rounded font-mono bg-blue-50/30 text-blue-950"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-blue-900 mb-1">
                      द्वितीय बिक्री दर (१ {formSecondaryUnit === 'CUSTOM' ? customSecondaryUnitInput || 'Sec' : formSecondaryUnit})
                    </label>
                    <input
                      type="number"
                      min={0}
                      step="any"
                      value={formSecondarySellingPrice}
                      onChange={(e) => setFormSecondarySellingPrice(parseFloat(e.target.value) || 0)}
                      className="w-full px-2 py-1.5 border border-blue-300 rounded font-mono font-bold bg-blue-50/50 text-blue-950"
                    />
                  </div>
                </div>
              </div>

              {/* Stock Configuration: Opening Stock, Current Stock, Min Alert */}
              <div className="p-3 bg-slate-50/80 rounded-lg border border-slate-200 space-y-2">
                <span className="text-[11px] font-bold text-slate-700 block">
                  {isNe ? 'स्टक मौज्दात व्यवस्थापन (Stock Tracking):' : 'Stock Configuration:'}
                </span>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                      पुरानो स्टक (Opening)
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={formOpeningStock}
                      onChange={(e) => setFormOpeningStock(parseInt(e.target.value) || 0)}
                      className="w-full px-2 py-1.5 border border-slate-200 rounded bg-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                      हालको स्टक (Current)
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={formStock}
                      onChange={(e) => setFormStock(parseInt(e.target.value) || 0)}
                      className="w-full px-2 py-1.5 border border-slate-200 rounded bg-white font-mono font-bold text-emerald-950"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                      अलर्ट सीमा (Min Limit)
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={formMinStock}
                      onChange={(e) => setFormMinStock(parseInt(e.target.value) || 1)}
                      className="w-full px-2 py-1.5 border border-slate-200 rounded bg-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* VAT Exempt Checkbox */}
              <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg border border-slate-200">
                <input
                  type="checkbox"
                  id="vatExempt"
                  checked={formIsVatExempt}
                  onChange={(e) => setFormIsVatExempt(e.target.checked)}
                  className="rounded text-emerald-700 w-4 h-4 cursor-pointer"
                />
                <label htmlFor="vatExempt" className="text-slate-800 font-medium cursor-pointer">
                  यो सामान भ्याट छुट हुने कृषि सामग्री/बिउ हो (VAT Exempt)
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  {t.close}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition"
                >
                  सुरक्षित गर्नुहोस् (Save)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Stock Adjustment Modal */}
      {stockModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm bg-white rounded-xl shadow-xl border border-slate-200 p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100">
              स्टक थप (Quick Stock Inflow)
            </h3>
            <div>
              <p className="text-xs font-semibold text-slate-800">
                {isNe ? stockModalItem.nameNe || stockModalItem.nameEn : stockModalItem.nameEn}
              </p>
              <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                हालको स्टक: {stockModalItem.currentStock} {stockModalItem.unit}
              </p>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                थप गर्नुपर्ने परिमाण (Qty to Add)
              </label>
              <input
                type="number"
                value={stockAdjustmentQty}
                onChange={(e) => setStockAdjustmentQty(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono text-sm"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setStockModalItem(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded"
              >
                रद्द
              </button>
              <button
                onClick={handleStockUpdate}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded"
              >
                स्टक अद्यावधिक गर्नुहोस्
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VAT & Non-VAT Stock Reconciliation Modal */}
      {reconcileModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-purple-700" />
                <span>{isNe ? 'भ्याट र नन-भ्याट स्टक मिलान तथा समायोजन' : 'Reconcile Stock (VAT & Non-VAT)'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setReconcileModalItem(null)}
                className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveReconcile} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-purple-50/70 rounded-lg border border-purple-200">
                <span className="font-bold text-slate-900 block">
                  {isNe ? reconcileModalItem.nameNe || reconcileModalItem.nameEn : reconcileModalItem.nameEn}
                </span>
                <span className="text-[11px] text-slate-500 font-mono">
                  कोड: {reconcileModalItem.code} | एकाइ: {reconcileModalItem.unit}
                </span>
              </div>

              {/* Total Stock */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  कुल वास्तविक स्टक (Total Physical Stock)
                </label>
                <input
                  type="number"
                  min={0}
                  required
                  value={reconcileTotalStock}
                  onChange={(e) => setReconcileTotalStock(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg font-mono font-bold text-sm bg-white"
                />
              </div>

              {/* VAT Stock vs Non-VAT Stock */}
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <label className="block text-[11px] font-bold text-blue-900 mb-1">
                    भ्याट बिल स्टक (VAT Book)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={reconcileVatStock}
                    onChange={(e) => setReconcileVatStock(parseInt(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 border border-blue-300 rounded bg-white font-mono font-bold text-blue-950"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">१३% कर बीजकको लागि</span>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-800 mb-1">
                    नन-भ्याट स्टक (Non-VAT)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={reconcileNonVatStock}
                    onChange={(e) => setReconcileNonVatStock(parseInt(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white font-mono font-bold text-slate-900"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">अनुमानित/सादा बिलको लागि</span>
                </div>
              </div>

              {/* Quick Equalize Button */}
              <button
                type="button"
                onClick={() => {
                  setReconcileVatStock(reconcileTotalStock);
                  setReconcileNonVatStock(0);
                }}
                className="w-full py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold flex items-center justify-center gap-1.5 cursor-pointer text-[11px] transition"
              >
                <RefreshCw className="w-3 h-3" />
                <span>सबै स्टक भ्याट बुकमा मिलान गर्नुहोस् (All to VAT Stock)</span>
              </button>

              {/* Reason */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  मिलानको कारण / कैफियत (Reason / Remarks)
                </label>
                <input
                  type="text"
                  value={reconcileReason}
                  onChange={(e) => setReconcileReason(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setReconcileModalItem(null)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  रद्द
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-lg shadow-xs cursor-pointer"
                >
                  स्टक मिलान सुरक्षित गर्नुहोस् (Save Sync)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Voice Command Warehouse Control Center Modal */}
      {isVoiceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Header */}
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-blue-500/10">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500 text-slate-950 rounded-xl shadow-xs">
                  <Mic className="w-5 h-5 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <span>{isNe ? 'आवाजबाट स्टक नियन्त्रण (Voice Command Warehouse Control)' : 'Voice-Command Warehouse Control'}</span>
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-900 rounded-full border border-amber-300 uppercase">
                      Hands-Free
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {isNe
                      ? 'माइक बोल्नुहोस् वा कमान्ड थिची वेयरहाउसको स्टक तुरुन्तै अद्यावधिक गर्नुहोस्'
                      : 'Hands-free voice recognition for updating warehouse item stock levels on the go'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsVoiceModalOpen(false);
                  setIsListening(false);
                  window.speechSynthesis?.cancel();
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs">

              {/* Specific Item Banner if selected */}
              {targetVoiceItem && (
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-amber-800 uppercase block">
                      {isNe ? 'लक्षित सामान (Target Item Selected):' : 'Target Item Selected:'}
                    </span>
                    <span className="font-bold text-slate-900 text-sm">
                      {isNe ? targetVoiceItem.nameNe || targetVoiceItem.nameEn : targetVoiceItem.nameEn} ({targetVoiceItem.code})
                    </span>
                    <span className="text-xs text-slate-600 ml-2 font-mono">
                      | हालको मौज्दात: <strong>{targetVoiceItem.currentStock} {targetVoiceItem.unit}</strong>
                    </span>
                  </div>
                  <button
                    onClick={() => setTargetVoiceItem(null)}
                    className="text-xs text-amber-800 underline font-semibold cursor-pointer hover:text-amber-950"
                  >
                    {isNe ? 'सबै सामानमा लागू गर्ने' : 'Reset to All'}
                  </button>
                </div>
              )}

              {/* Settings Bar: Language & Audio Feedback */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-700 text-[11px]">
                    {isNe ? 'आवाज भाषा (Voice Language):' : 'Voice Language:'}
                  </span>
                  <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
                    <button
                      onClick={() => setVoiceLanguage('ne-NP')}
                      className={`px-2.5 py-1 rounded-md text-xs font-semibold transition cursor-pointer ${
                        voiceLanguage === 'ne-NP'
                          ? 'bg-emerald-700 text-white shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      🇳🇵 नेपाली (ne-NP)
                    </button>
                    <button
                      onClick={() => setVoiceLanguage('en-US')}
                      className={`px-2.5 py-1 rounded-md text-xs font-semibold transition cursor-pointer ${
                        voiceLanguage === 'en-US'
                          ? 'bg-emerald-700 text-white shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      🇬🇧 English (en-US)
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => setSpeechSynthesisEnabled(!speechSynthesisEnabled)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border font-semibold text-xs transition cursor-pointer ${
                    speechSynthesisEnabled
                      ? 'bg-blue-50 border-blue-300 text-blue-900'
                      : 'bg-slate-100 border-slate-200 text-slate-500'
                  }`}
                  title={isNe ? 'आवाजबाट अद्यावधिक पुष्टि सुन्नुहोस्' : 'Audio Confirmation Spoken Back'}
                >
                  {speechSynthesisEnabled ? <Volume2 className="w-3.5 h-3.5 text-blue-700" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
                  <span>{isNe ? 'आवाज प्रतिक्रिया (Voice Readout)' : 'Voice Readout'}</span>
                </button>
              </div>

              {/* Microphone Call-to-Action Panel */}
              <div className="bg-slate-900 text-white p-6 rounded-2xl text-center space-y-4 shadow-md relative overflow-hidden">
                <div className="absolute -top-12 -right-12 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl"></div>
                <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl"></div>

                <div className="relative z-10 flex flex-col items-center">
                  <button
                    onClick={() => {
                      if (isListening) {
                        setIsListening(false);
                      } else {
                        startListening(targetVoiceItem);
                      }
                    }}
                    className={`w-20 h-20 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-lg relative ${
                      isListening
                        ? 'bg-rose-600 text-white scale-105 ring-8 ring-rose-500/40 animate-pulse'
                        : 'bg-gradient-to-tr from-amber-500 to-emerald-500 hover:scale-105 text-slate-950 hover:shadow-amber-500/20'
                    }`}
                  >
                    {isListening ? (
                      <MicOff className="w-9 h-9 stroke-[2.5]" />
                    ) : (
                      <Mic className="w-9 h-9 stroke-[2.5]" />
                    )}
                  </button>

                  <div className="mt-3 space-y-1">
                    <span className="text-sm font-bold text-amber-400 block">
                      {isListening
                        ? (isNe ? '🎙️ आवाज सुन्दैछ... बोल्नुहोस्!' : '🎙️ Listening... Speak now!')
                        : (isNe ? 'माइक थिची बोल्नुहोस् (Tap to Speak)' : 'Tap Microphone to Speak')}
                    </span>
                    <p className="text-xs text-slate-300 max-w-sm mx-auto">
                      {targetVoiceItem
                        ? (isNe ? `उदा: "५० बनाउनुहोस्" वा "१० थप्नुहोस्"` : `e.g. "Stock 50" or "Add 10"`)
                        : (isNe ? `उदा: "चामल मौज्दात ५०" वा "पावर टिलर १० थप्नुहोस्"` : `e.g. "Rice stock 50" or "Add 10 to Sprayer"`)}
                    </p>
                  </div>

                  {/* Live Waveform Text Box */}
                  <div className="w-full bg-slate-800/90 border border-slate-700/80 rounded-xl p-3 text-left font-mono text-xs mt-3 min-h-[44px] flex items-center justify-between gap-2 shadow-inner">
                    <div className="flex items-center gap-2 overflow-hidden text-emerald-300">
                      <Radio className={`w-4 h-4 shrink-0 ${isListening ? 'text-rose-400 animate-spin' : 'text-slate-500'}`} />
                      <span className="truncate">
                        {liveTranscript || (isNe ? 'आवाजको कमान्ड यहाँ देखिनेछ...' : 'Voice command transcript will appear here...')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Voice Result Toast / Alert Card */}
              {voiceResult && (
                <div
                  className={`p-4 rounded-xl border space-y-2 transition-all shadow-xs ${
                    voiceResult.success
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                      : 'bg-rose-50 border-rose-300 text-rose-950'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2 font-bold text-sm">
                      {voiceResult.success ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
                      ) : (
                        <AlertCircle className="w-5 h-5 text-rose-700 shrink-0" />
                      )}
                      <span>
                        {voiceResult.success
                          ? (isNe ? 'स्टक अद्यावधिक सम्पन्न!' : 'Stock Updated Successfully!')
                          : (isNe ? 'आवाज कमान्ड बुझ्न सकिएन' : 'Could Not Process Voice Command')}
                      </span>
                    </div>

                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-white/80 border text-slate-700">
                      "{voiceResult.transcript}"
                    </span>
                  </div>

                  <p className="text-xs font-medium">
                    {voiceResult.message}
                  </p>

                  {voiceResult.matchedItem && voiceResult.success && (
                    <div className="pt-2 border-t border-emerald-200/80 flex items-center justify-between text-xs font-mono font-bold text-emerald-900">
                      <span>{isNe ? 'नयाँ मौज्दात:' : 'New Current Stock:'} {voiceResult.matchedItem.currentStock} {voiceResult.matchedItem.unit}</span>
                      <button
                        onClick={() => {
                          setVoiceResult(null);
                        }}
                        className="px-2.5 py-1 bg-emerald-700 text-white rounded text-[11px] font-sans hover:bg-emerald-800 transition cursor-pointer"
                      >
                        {isNe ? 'ठिक छ (OK)' : 'OK'}
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Manual Voice Command Testing Input */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <span className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
                  <Wand2 className="w-3.5 h-3.5 text-amber-600" />
                  <span>{isNe ? 'वा कमान्ड टाइप गरेर परीक्षण गर्नुहोस् (Manual Command Test):' : 'Or Type Voice Command Text:'}</span>
                </span>

                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={
                      isNe
                        ? 'उदा: "चामल मौज्दात ५० बनाउनुहोस्" वा "पावर टिलर १० थप्नुहोस्"'
                        : 'e.g. "Rice stock 50" or "Add 10 to Sprayer"'
                    }
                    value={manualVoiceInput}
                    onChange={(e) => setManualVoiceInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && manualVoiceInput.trim()) {
                        processVoiceCommand(manualVoiceInput, targetVoiceItem);
                        setManualVoiceInput('');
                      }
                    }}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 bg-white"
                  />
                  <button
                    onClick={() => {
                      if (manualVoiceInput.trim()) {
                        processVoiceCommand(manualVoiceInput, targetVoiceItem);
                        setManualVoiceInput('');
                      }
                    }}
                    className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold text-xs transition cursor-pointer shrink-0"
                  >
                    {isNe ? 'लागू गर्नुहोस्' : 'Run'}
                  </button>
                </div>
              </div>

              {/* Preset Quick Voice Command Test Chips */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-semibold text-slate-500 block">
                  {isNe ? 'तुरुन्त थिचेर परीक्षण गर्ने नमुना कमान्डहरू:' : 'Quick Sample Voice Commands:'}
                </span>
                <div className="flex items-center gap-1.5 flex-wrap text-xs">
                  {items.slice(0, 4).map((it) => {
                    const itemName = isNe ? it.nameNe || it.nameEn : it.nameEn;
                    const sampleCommand = isNe ? `${itemName} मौज्दात ५० बनाउनुहोस्` : `Set ${it.nameEn} stock to 50`;
                    return (
                      <button
                        key={it.id}
                        onClick={() => processVoiceCommand(sampleCommand, it)}
                        className="px-2.5 py-1 bg-white hover:bg-amber-50 border border-slate-200 hover:border-amber-400 rounded-lg text-[11px] font-medium text-slate-800 transition cursor-pointer shadow-2xs"
                      >
                        🗣️ "{sampleCommand}"
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Voice Updates Audit History Log */}
              {voiceHistory.length > 0 && (
                <div className="pt-3 border-t border-slate-200 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900 flex items-center gap-1.5">
                      <History className="w-3.5 h-3.5 text-blue-700" />
                      <span>{isNe ? 'आवाजबाट भएका अद्यावधिकहरूको लग (Voice Updates Audit Log):' : 'Voice Updates Audit Log:'}</span>
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">{voiceHistory.length} अद्यावधिक</span>
                  </div>

                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {voiceHistory.map((log) => (
                      <div
                        key={log.id}
                        className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between text-xs"
                      >
                        <div>
                          <div className="font-bold text-slate-900">
                            {isNe ? log.item.nameNe || log.item.nameEn : log.item.nameEn}
                          </div>
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                            "{log.transcript}" • {log.time}
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="text-right font-mono text-xs">
                            <span className="text-slate-400 line-through mr-1">{log.oldStock}</span>
                            <span className="font-bold text-emerald-800">➔ {log.newStock} {log.item.unit}</span>
                          </div>

                          <button
                            onClick={() => handleUndoVoiceUpdate(log.id, log.item.id, log.oldStock)}
                            className="p-1 text-slate-500 hover:text-rose-700 hover:bg-rose-100 rounded transition cursor-pointer"
                            title={isNe ? 'फिर्ता (Undo)' : 'Undo Update'}
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-2">
              <button
                onClick={() => {
                  setIsVoiceModalOpen(false);
                  setIsListening(false);
                  window.speechSynthesis?.cancel();
                }}
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-800 transition cursor-pointer"
              >
                {isNe ? 'सम्पन्न गर्नुहोस् (Done)' : 'Close'}
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
