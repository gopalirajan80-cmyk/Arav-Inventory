import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Item, InvoiceItem } from '../types';
import {
  Camera,
  Upload,
  Sparkles,
  Loader2,
  X,
  CheckCircle2,
  AlertCircle,
  FileText,
  User,
  PackageCheck
} from 'lucide-react';
import { fileToDataUrl } from '../utils/cameraHelper';
import { formatCurrency } from '../utils/nepaliCalendar';
import { authFetch } from '../utils/auth';

interface ScannedBillData {
  invoiceNo?: string;
  customerName?: string;
  customerPan?: string;
  customerAddress?: string;
  customerPhone?: string;
  billType?: 'VAT' | 'NON_VAT';
  paymentDueDate?: string;
  previousDue?: number;
  amountPaid?: number;
  discountPercent?: number;
  freightCharge?: number;
  notes?: string;
  items: Array<{
    name: string;
    quantity: number;
    unit?: string;
    rate: number;
    amount?: number;
  }>;
}

interface HandwrittenBillScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyExtractedData: (data: {
    invoiceNo?: string;
    customerName: string;
    customerPan: string;
    customerAddress: string;
    customerPhone: string;
    billType: 'VAT' | 'NON_VAT';
    paymentDueDate: string;
    previousDue: number;
    amountPaid: number;
    discountPercent: number;
    freightCharge: number;
    notes: string;
    lineItems: InvoiceItem[];
    photoUrl: string;
  }) => void;
}

export const HandwrittenBillScannerModal: React.FC<HandwrittenBillScannerModalProps> = ({
  isOpen,
  onClose,
  onApplyExtractedData
}) => {
  const { items: inventoryItems, language } = useApp();
  const isNe = language === 'ne';

  const [photoDataUrl, setPhotoDataUrl] = useState<string>('');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [extractedData, setExtractedData] = useState<ScannedBillData | null>(null);

  if (!isOpen) return null;

  const runAiScan = async (dataUrlToScan: string) => {
    if (!dataUrlToScan) return;
    setIsScanning(true);
    setErrorMsg('');

    try {
      const res = await authFetch('/api/scan-handwritten-bill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: dataUrlToScan,
          mimeType: dataUrlToScan.startsWith('data:image/png') ? 'image/png' : 'image/jpeg'
        })
      });

      const json = await res.json();

      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Failed to scan handwritten bill');
      }

      const d = json.data || {};
      setExtractedData({
        invoiceNo: d.invoiceNo || '',
        customerName: d.customerName || '',
        customerPan: d.customerPan || '',
        customerAddress: d.customerAddress || '',
        customerPhone: d.customerPhone || '',
        billType: d.billType === 'NON_VAT' ? 'NON_VAT' : 'VAT',
        paymentDueDate: d.paymentDueDate || '',
        previousDue: Number(d.previousDue) || 0,
        amountPaid: Number(d.amountPaid) || 0,
        discountPercent: Number(d.discountPercent) || 0,
        freightCharge: Number(d.freightCharge) || 0,
        notes: d.notes || '',
        items:
          Array.isArray(d.items) && d.items.length > 0
            ? d.items
            : [{ name: 'फोटो बिल सामान (Photo Bill Item)', quantity: 1, unit: 'Pcs', rate: 0, amount: 0 }]
      });
    } catch (err: any) {
      console.error('Scan error:', err);
      // Even if AI OCR fails or offline, provide editable structure so direct photo bill upload always works!
      setExtractedData((prev) =>
        prev || {
          invoiceNo: '',
          customerName: '',
          customerPan: '',
          customerAddress: '',
          customerPhone: '',
          billType: 'VAT',
          paymentDueDate: '',
          previousDue: 0,
          amountPaid: 0,
          discountPercent: 0,
          freightCharge: 0,
          notes: 'फोटो बिल अपलोड (Photo Bill Attached)',
          items: [{ name: 'फोटो बिल अनुसारको सामान', quantity: 1, unit: 'Lot', rate: 0, amount: 0 }]
        }
      );
      setErrorMsg(
        isNe
          ? 'फोटो संलग्न भयो! तल विवरण जाँच वा टाइप गरी सिधै बिलमा भर्नुहोस्।'
          : 'Photo attached! Verify or enter details below and apply directly to bill.'
      );
    } finally {
      setIsScanning(false);
    }
  };

  const handleCapturePhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMsg('');
    try {
      const dataUrl = await fileToDataUrl(file, 1600, 1600, 0.85);
      setPhotoDataUrl(dataUrl);
      // Initialize default editable data immediately and auto-trigger AI scan
      setExtractedData({
        invoiceNo: '',
        customerName: '',
        customerPan: '',
        customerAddress: '',
        customerPhone: '',
        billType: 'VAT',
        paymentDueDate: '',
        previousDue: 0,
        amountPaid: 0,
        discountPercent: 0,
        freightCharge: 0,
        notes: 'फोटो बिल प्रविष्टि',
        items: [{ name: 'कृषि औजार / सामान (Photo Bill)', quantity: 1, unit: 'Pcs', rate: 0, amount: 0 }]
      });
      await runAiScan(dataUrl);
    } catch (err) {
      console.error(err);
      setErrorMsg(isNe ? 'फोटो लोड गर्न सकिएन।' : 'Failed to load photo.');
    }
  };

  const handleScanWithAI = async () => {
    if (!photoDataUrl) {
      setErrorMsg(isNe ? 'कृपया पहिले बिलको फोटो खिच्नुहोस् वा छान्नुहोस्।' : 'Please take or select a photo of the bill first.');
      return;
    }
    await runAiScan(photoDataUrl);
  };

  const handleApplyToBilling = () => {
    if (!extractedData) return;

    // Convert extracted items to InvoiceItem format, matching with inventory if existing
    const itemsList = Array.isArray(extractedData.items) ? extractedData.items : [];
    const mappedLineItems: InvoiceItem[] = itemsList.map((item, idx) => {
      const itemNameClean = (item.name || '').toLowerCase().trim();
      const matched = itemNameClean
        ? inventoryItems.find(
            (inv) =>
              inv.nameNe.toLowerCase().includes(itemNameClean) ||
              inv.nameEn.toLowerCase().includes(itemNameClean) ||
              itemNameClean.includes(inv.nameNe.toLowerCase().trim())
          )
        : undefined;

      const qty = Math.max(1, Number(item.quantity) || 1);
      const rate = Number(item.rate) || (matched ? matched.sellingPrice : 0);
      const amount = Number(item.amount) || qty * rate;

      return {
        itemId: matched ? matched.id : `scan-${Date.now()}-${idx}`,
        code: matched ? matched.code : `SCAN-${idx + 1}`,
        name: item.name || (matched ? (isNe ? matched.nameNe : matched.nameEn) : `सामान ${idx + 1}`),
        unit: item.unit || (matched ? matched.unit : 'Pcs'),
        quantity: qty,
        rate: rate,
        amount: amount,
        isVatExempt: matched ? matched.isVatExempt : false
      };
    });

    onApplyExtractedData({
      invoiceNo: extractedData.invoiceNo || '',
      customerName: extractedData.customerName || '',
      customerPan: extractedData.customerPan || '',
      customerAddress: extractedData.customerAddress || '',
      customerPhone: extractedData.customerPhone || '',
      billType: extractedData.billType || 'VAT',
      paymentDueDate: extractedData.paymentDueDate || '',
      previousDue: extractedData.previousDue || 0,
      amountPaid: extractedData.amountPaid || 0,
      discountPercent: extractedData.discountPercent || 0,
      freightCharge: extractedData.freightCharge || 0,
      notes: extractedData.notes
        ? `फोटो बिल प्रविष्टि - ${extractedData.notes}`
        : 'फोटो बिल प्रविष्टि (Photo Bill Upload)',
      lineItems: mappedLineItems,
      photoUrl: photoDataUrl
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold">
                {isNe ? 'लिखित बिल AI स्क्यानर (Handwritten Bill to POS)' : 'Scan Handwritten Bill with AI'}
              </h2>
              <p className="text-[11px] text-slate-300">
                {isNe
                  ? 'हातले लेखेको कच्चा बिल वा रसिदको फोटो खिच्नुहोस्, AI ले सिधै डिजिटल बिल बनाइदिनेछ'
                  : 'Take photo of handwritten bill / receipt to auto-fill POS'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs flex-1">
          
          {/* Image Capture & Upload Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            
            {/* Left: Preview Box */}
            <div className="border-2 border-dashed border-slate-300 rounded-xl bg-slate-50 min-h-[220px] max-h-[300px] flex flex-col items-center justify-center p-3 overflow-hidden relative">
              {photoDataUrl ? (
                <div className="relative w-full h-full flex flex-col items-center">
                  <img
                    src={photoDataUrl}
                    alt="Captured Bill"
                    className="max-h-[250px] w-auto object-contain rounded-lg border border-slate-300 shadow-sm"
                  />
                  <label
                    htmlFor="retake-camera-input"
                    className="mt-2 text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer flex items-center gap-1"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>{isNe ? 'अर्को फोटो खिच्नुहोस्' : 'Retake / Change Photo'}</span>
                  </label>
                  <input
                    type="file"
                    id="retake-camera-input"
                    accept="image/*"
                    capture="environment"
                    onChange={handleCapturePhoto}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="text-center p-6 space-y-3">
                  <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto border border-emerald-200">
                    <Camera className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-800">
                      {isNe ? 'लिखित बिलको फोटो खिच्नुहोस्' : 'Snap photo of handwritten bill'}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {isNe ? 'मोबाइल फोनको मुख्य क्यामेराले बिलको सिधा फोटो लिनुहोस्' : 'Point camera directly at the receipt'}
                    </p>
                  </div>

                  <div className="flex items-center justify-center gap-2 pt-1">
                    <label
                      htmlFor="main-camera-input"
                      className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>{isNe ? 'क्यामेरा खोल्नुहोस्' : 'Open Camera'}</span>
                    </label>
                    <input
                      type="file"
                      id="main-camera-input"
                      accept="image/*"
                      capture="environment"
                      onChange={handleCapturePhoto}
                      className="hidden"
                    />

                    <label
                      htmlFor="gallery-input"
                      className="px-3 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs transition"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{isNe ? 'ग्यालरीबाट छान्नुहोस्' : 'Upload File'}</span>
                    </label>
                    <input
                      type="file"
                      id="gallery-input"
                      accept="image/*"
                      onChange={handleCapturePhoto}
                      className="hidden"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Right: Action and Instructions */}
            <div className="space-y-3">
              <div className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-200/80 space-y-1.5">
                <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                  {isNe ? 'AI ले के-के विवरण पढ्छ?' : 'What will AI extract?'}
                </span>
                <ul className="list-disc list-inside text-[11px] text-emerald-900/90 space-y-1 leading-relaxed">
                  <li>{isNe ? 'ग्राहकको नाम, ठेगाना, सम्पर्क नम्बर र प्यान' : 'Customer Name, Address, Phone & PAN'}</li>
                  <li>{isNe ? 'हातले लेखिएका सामानको नाम, परिमाण, एकाइ र दर' : 'Items, Quantities, Units and Rates'}</li>
                  <li>{isNe ? 'रकम बुझाउने भाका/म्याद (Payment Due Date)' : 'Payment Deadline / Due Date'}</li>
                  <li>{isNe ? 'पुरानो बाँकी रकम तथा अग्रिम/नगद बुझाएको विवरण' : 'Old Dues & Advance Cash Paid'}</li>
                </ul>
              </div>

              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="text-xs">{errorMsg}</span>
                </div>
              )}

              <button
                type="button"
                onClick={handleScanWithAI}
                disabled={!photoDataUrl || isScanning}
                className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm"
              >
                {isScanning ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{isNe ? 'AI ले बिल पढ्दै छ, कृपया पर्खनुहोस्...' : 'AI is reading bill, please wait...'}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>{isNe ? 'AI स्क्यान गरी बिल विवरण निकाल्नुहोस्' : 'Extract Bill Details with AI'}</span>
                  </>
                )}
              </button>
            </div>

          </div>

          {/* Extracted Data Preview & Editable Box */}
          {extractedData && (
            <div className="border border-emerald-200 bg-emerald-50/30 rounded-xl p-4 space-y-4 animate-fade-in">
              <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
                <span className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  {isNe ? 'फोटो बिल विवरण (आवश्यक परे सच्याउनुहोस् र बिलमा राख्नुहोस्):' : 'Photo Bill Details (Review / Edit & Apply):'}
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setExtractedData({ ...extractedData, billType: 'VAT' })}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer ${
                      extractedData.billType === 'VAT'
                        ? 'bg-emerald-700 text-white'
                        : 'bg-white border border-slate-300 text-slate-700'
                    }`}
                  >
                    VAT Bill
                  </button>
                  <button
                    type="button"
                    onClick={() => setExtractedData({ ...extractedData, billType: 'NON_VAT' })}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer ${
                      extractedData.billType === 'NON_VAT'
                        ? 'bg-slate-800 text-white'
                        : 'bg-white border border-slate-300 text-slate-700'
                    }`}
                  >
                    Non-VAT Bill
                  </button>
                </div>
              </div>

              {/* Editable Header Details */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 text-[11px]">
                <div className="bg-white p-2 rounded-lg border border-slate-200">
                  <label className="text-slate-500 block font-semibold mb-0.5">ग्राहक / सप्लायरको नाम</label>
                  <input
                    type="text"
                    value={extractedData.customerName || ''}
                    onChange={(e) => setExtractedData({ ...extractedData, customerName: e.target.value })}
                    placeholder="नाम..."
                    className="w-full px-2 py-1 border border-slate-200 rounded font-bold text-slate-900"
                  />
                </div>
                <div className="bg-white p-2 rounded-lg border border-slate-200">
                  <label className="text-slate-500 block font-semibold mb-0.5">बिल नं (Bill / Invoice No)</label>
                  <input
                    type="text"
                    value={extractedData.invoiceNo || ''}
                    onChange={(e) => setExtractedData({ ...extractedData, invoiceNo: e.target.value })}
                    placeholder="Auto / Manual Bill No"
                    className="w-full px-2 py-1 border border-slate-200 rounded font-mono font-bold text-slate-900"
                  />
                </div>
                <div className="bg-white p-2 rounded-lg border border-slate-200">
                  <label className="text-slate-500 block font-semibold mb-0.5">PAN / भ्याट नं</label>
                  <input
                    type="text"
                    value={extractedData.customerPan || ''}
                    onChange={(e) => setExtractedData({ ...extractedData, customerPan: e.target.value })}
                    placeholder="PAN No"
                    className="w-full px-2 py-1 border border-slate-200 rounded font-mono text-slate-800"
                  />
                </div>
                <div className="bg-white p-2 rounded-lg border border-slate-200">
                  <label className="text-slate-500 block font-semibold mb-0.5">ठेगाना / फोन</label>
                  <input
                    type="text"
                    value={extractedData.customerAddress || extractedData.customerPhone || ''}
                    onChange={(e) => setExtractedData({ ...extractedData, customerAddress: e.target.value })}
                    placeholder="ठेगाना..."
                    className="w-full px-2 py-1 border border-slate-200 rounded font-semibold text-slate-900"
                  />
                </div>
              </div>

              {/* Editable Line Items Table */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-slate-800 text-[11px] flex items-center gap-1">
                    <PackageCheck className="w-3.5 h-3.5 text-emerald-700" />
                    {isNe ? 'सामानहरूको सूची (सम्पादन गर्न मिल्ने):' : 'Extracted Items (Editable):'}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setExtractedData({
                        ...extractedData,
                        items: [
                          ...(extractedData.items || []),
                          { name: 'नयाँ सामान', quantity: 1, unit: 'Pcs', rate: 0, amount: 0 }
                        ]
                      })
                    }
                    className="px-2 py-1 bg-white border border-emerald-300 text-emerald-800 rounded text-[10px] font-bold cursor-pointer hover:bg-emerald-50"
                  >
                    + सामान थप्नुहोस्
                  </button>
                </div>
                <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
                  <table className="w-full text-[11px] text-left">
                    <thead className="bg-slate-50 border-b border-slate-200 font-bold text-slate-700">
                      <tr>
                        <th className="py-2 px-2">क्र.सं.</th>
                        <th className="py-2 px-2">सामान (Item Name)</th>
                        <th className="py-2 px-2 text-center w-20">परिमाण (Qty)</th>
                        <th className="py-2 px-2 text-right w-28">दर (Rate रु.)</th>
                        <th className="py-2 px-2 text-right w-28">जम्मा (Total)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(extractedData.items || []).map((it, idx) => (
                        <tr key={idx}>
                          <td className="py-1.5 px-2 font-mono text-slate-400">{idx + 1}</td>
                          <td className="py-1.5 px-2">
                            <input
                              type="text"
                              value={it.name}
                              onChange={(e) => {
                                const next = [...(extractedData.items || [])];
                                next[idx] = { ...next[idx], name: e.target.value };
                                setExtractedData({ ...extractedData, items: next });
                              }}
                              className="w-full px-2 py-1 border border-slate-200 rounded font-semibold text-slate-900"
                            />
                          </td>
                          <td className="py-1.5 px-2 text-center">
                            <input
                              type="number"
                              min={1}
                              value={it.quantity}
                              onChange={(e) => {
                                const q = Math.max(1, Number(e.target.value) || 1);
                                const next = [...(extractedData.items || [])];
                                next[idx] = { ...next[idx], quantity: q, amount: q * (next[idx].rate || 0) };
                                setExtractedData({ ...extractedData, items: next });
                              }}
                              className="w-16 px-1.5 py-1 border border-slate-200 rounded font-mono text-center"
                            />
                          </td>
                          <td className="py-1.5 px-2 text-right">
                            <input
                              type="number"
                              min={0}
                              value={it.rate}
                              onChange={(e) => {
                                const r = Math.max(0, Number(e.target.value) || 0);
                                const next = [...(extractedData.items || [])];
                                next[idx] = { ...next[idx], rate: r, amount: (next[idx].quantity || 1) * r };
                                setExtractedData({ ...extractedData, items: next });
                              }}
                              className="w-24 px-1.5 py-1 border border-slate-200 rounded font-mono text-right"
                            />
                          </td>
                          <td className="py-1.5 px-2 text-right font-mono font-bold tabular-nums text-slate-900">
                            रु. {((it.quantity || 1) * (it.rate || 0)).toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Action Button: Load directly into Billing / Purchase */}
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleApplyToBilling}
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer"
                >
                  <PackageCheck className="w-4 h-4" />
                  <span>{isNe ? 'यो फोटो र विवरण सिधै बिलमा भर्नुहोस् (Apply to Bill)' : 'Apply Photo & Details to Bill'}</span>
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
