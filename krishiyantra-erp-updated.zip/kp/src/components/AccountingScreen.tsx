import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { loadStoredData, saveStoredData } from '../utils/storage';
import { getTodayBsString } from '../utils/nepaliCalendar';
import type {
  Account, AccountType, AccountingData, BudgetRecord, DepMethod, FixedAsset, JournalEntry,
  JournalLine, TaxAdjustments, TdsDirection, TdsEntry
} from '../types/accounting';
import {
  TDS_PRESETS, accountActivity, buildAccountLedger, buildAutoJournal, cmpFy, computeDepreciation,
  computeSlabTax, computeTrialBalance, downloadCsv, fmtMoney, fyMonthRange, fyOfBs, fyRange,
  nextFy, normBs, normalizeAccountingData, round2
} from '../utils/accountingEngine';

type Tab = 'COA' | 'JOURNAL' | 'LEDGER' | 'TB' | 'ASSETS' | 'TDS' | 'TAX' | 'BUDGET';

interface Ctx {
  isNe: boolean;
  data: AccountingData;
  update: (fn: (d: AccountingData) => AccountingData) => void;
  entries: JournalEntry[]; // manual + (optionally) auto
  autoEntries: JournalEntry[];
  fy: string;
  accName: (id: string) => string;
}

const inputCls = 'border border-slate-300 rounded-lg px-2 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/40 w-full';
const btnPrimary = 'px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed';
const btnGhost = 'px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold cursor-pointer';
const btnDanger = 'px-2 py-1 rounded-md border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 text-[11px] font-bold cursor-pointer';
const th = 'py-2 px-2.5 text-left font-bold text-slate-700';
const tdc = 'py-1.5 px-2.5';
const num = 'font-mono tabular-nums text-right';

const Field: React.FC<{ label: string; children: React.ReactNode; className?: string }> = ({ label, children, className }) => (
  <label className={`block ${className || ''}`}>
    <span className="block text-[10px] font-bold text-slate-600 mb-0.5">{label}</span>
    {children}
  </label>
);

const Card: React.FC<{ title?: string; children: React.ReactNode; right?: React.ReactNode }> = ({ title, children, right }) => (
  <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
    {(title || right) && (
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h3 className="text-sm font-extrabold text-slate-900">{title}</h3>
        {right}
      </div>
    )}
    {children}
  </div>
);

const toNum = (v: string | number | undefined): number => {
  const n = typeof v === 'number' ? v : parseFloat(String(v ?? '').replace(/,/g, ''));
  return Number.isFinite(n) ? n : 0;
};

const typeLabels: Record<AccountType, { ne: string; en: string }> = {
  ASSET: { ne: 'सम्पत्ति', en: 'Assets' },
  LIABILITY: { ne: 'दायित्व', en: 'Liabilities' },
  EQUITY: { ne: 'पुँजी / इक्विटी', en: 'Equity' },
  INCOME: { ne: 'आम्दानी', en: 'Income' },
  EXPENSE: { ne: 'खर्च', en: 'Expenses' }
};

// ============================================================================
// Main screen
// ============================================================================
export const AccountingScreen: React.FC = () => {
  const { language, company, invoices, purchases, partyTransactions, expenses, activeCompanyId } = useApp();
  const isNe = language === 'ne';
  const key = !activeCompanyId || activeCompanyId === 'comp-default'
    ? 'krishiyantra_accounting_v1'
    : `krishiyantra_accounting_v1__${activeCompanyId}`;

  const [store, setStore] = useState(() => ({
    key, data: normalizeAccountingData(loadStoredData<any>(key, null))
  }));
  let st = store;
  if (store.key !== key) {
    // company switched -> load that company's accounting books
    st = { key, data: normalizeAccountingData(loadStoredData<any>(key, null)) };
    setStore(st);
  }
  const data = st.data;
  useEffect(() => { saveStoredData(store.key, store.data); }, [store]);
  const update = (fn: (d: AccountingData) => AccountingData) =>
    setStore((s) => ({ ...s, data: fn(s.data) }));

  const [tab, setTab] = useState<Tab>('TB');
  const [fy, setFy] = useState<string>(company.fiscalYear || '082/83');
  const [includeAuto, setIncludeAuto] = useState(true);

  const autoEntries = useMemo(
    () => buildAutoJournal({ invoices, purchases, partyTransactions, expenses }),
    [invoices, purchases, partyTransactions, expenses]
  );
  const entries = useMemo(
    () => (includeAuto ? [...data.journals, ...autoEntries] : data.journals),
    [data.journals, autoEntries, includeAuto]
  );
  const accMap = useMemo(() => new Map(data.accounts.map((a) => [a.id, a])), [data.accounts]);
  const accName = (id: string) => {
    const a = accMap.get(id);
    return a ? `${a.code} · ${isNe ? a.nameNe : a.nameEn}` : id;
  };

  const fyOptions = useMemo(() => {
    const set = new Set<string>([company.fiscalYear, ...(company.fiscalYearsList || []), ...(company.closedFiscalYears || [])].filter(Boolean));
    set.add(fy);
    return Array.from(set).sort(cmpFy);
  }, [company.fiscalYear, company.fiscalYearsList, company.closedFiscalYears, fy]);

  const ctx: Ctx = { isNe, data, update, entries, autoEntries, fy, accName };

  const tabs: { id: Tab; ne: string; en: string }[] = [
    { id: 'TB', ne: 'ट्रायल ब्यालेन्स', en: 'Trial Balance' },
    { id: 'COA', ne: 'खाताको सूची (COA)', en: 'Chart of Accounts' },
    { id: 'JOURNAL', ne: 'जर्नल भौचर', en: 'Journal' },
    { id: 'LEDGER', ne: 'खाता बही', en: 'Ledger' },
    { id: 'ASSETS', ne: 'स्थिर सम्पत्ति / ह्रास', en: 'Fixed Assets' },
    { id: 'TDS', ne: 'TDS', en: 'TDS' },
    { id: 'TAX', ne: 'आयकर', en: 'Income Tax' },
    { id: 'BUDGET', ne: 'बजेट', en: 'Budget' }
  ];

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-extrabold text-slate-900">
              {isNe ? '📒 लेखा तथा वित्त (Accounting)' : '📒 Accounting & Finance'}
            </h2>
            <p className="text-[11px] text-slate-500">
              {isNe
                ? 'बिक्री, खरिद, भौचर र खर्च स्वतः लेखामा आउँछन्; म्यानुअल जर्नल अलग्गै थप्न सकिन्छ।'
                : 'Sales, purchases, vouchers and expenses post automatically; add manual journals on top.'}
            </p>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <label className="flex items-center gap-1.5 text-[11px] font-bold text-slate-700">
              {isNe ? 'आ.व.' : 'F.Y.'}
              <select value={fy} onChange={(e) => setFy(e.target.value)} className={`${inputCls} !w-auto`}>
                {fyOptions.map((f) => <option key={f} value={f}>{f}</option>)}
              </select>
            </label>
            <label className="flex items-center gap-1.5 text-[11px] font-bold text-slate-700 cursor-pointer">
              <input type="checkbox" checked={includeAuto} onChange={(e) => setIncludeAuto(e.target.checked)} />
              {isNe ? 'स्वचालित (बिलिङ/खरिद) समावेश' : 'Include auto-posted'} ({autoEntries.length})
            </label>
          </div>
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition ${
                tab === t.id ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {isNe ? t.ne : t.en}
            </button>
          ))}
        </div>
        <p className="text-[10px] text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5">
          {isNe
            ? 'सूचना: बन्द भइसकेको आ.व. का बिल/खरिद नयाँ आ.व. मा लुकेका हुन्छन्, त्यसैले अघिल्लो आ.व. को मौज्दात "खाताको सूची" मा Opening Balance को रूपमा राख्नुहोस्।'
            : 'Note: records of closed fiscal years are hidden in the new year, so carry prior-year closing balances in as Opening Balances in the Chart of Accounts.'}
        </p>
      </div>

      {tab === 'COA' && <CoaTab ctx={ctx} />}
      {tab === 'JOURNAL' && <JournalTab ctx={ctx} />}
      {tab === 'LEDGER' && <LedgerTab ctx={ctx} />}
      {tab === 'TB' && <TrialBalanceTab ctx={ctx} />}
      {tab === 'ASSETS' && <AssetsTab ctx={ctx} />}
      {tab === 'TDS' && <TdsTab ctx={ctx} />}
      {tab === 'TAX' && <TaxTab ctx={ctx} />}
      {tab === 'BUDGET' && <BudgetTab ctx={ctx} />}
    </div>
  );
};

// ============================================================================
// Chart of Accounts
// ============================================================================
const CoaTab: React.FC<{ ctx: Ctx }> = ({ ctx }) => {
  const { isNe, data, update } = ctx;
  const blank = { code: '', nameNe: '', nameEn: '', type: 'EXPENSE' as AccountType, opening: '', side: 'DR' as 'DR' | 'CR' };
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState<string | null>(null);
  const [msg, setMsg] = useState('');

  const used = useMemo(() => {
    const s = new Set<string>();
    data.journals.forEach((j) => j.lines.forEach((l) => s.add(l.accountId)));
    return s;
  }, [data.journals]);

  const save = () => {
    const code = form.code.trim();
    if (!code || !(form.nameNe.trim() || form.nameEn.trim())) {
      setMsg(isNe ? 'कोड र नाम आवश्यक छ।' : 'Code and name are required.');
      return;
    }
    const dup = data.accounts.some((a) => a.code === code && a.id !== editId);
    if (dup) { setMsg(isNe ? 'यो कोड पहिले नै छ।' : 'This code already exists.'); return; }
    const opening = Math.abs(toNum(form.opening));
    if (editId) {
      update((d) => ({
        ...d,
        accounts: d.accounts.map((a) =>
          a.id === editId
            ? { ...a, nameNe: form.nameNe.trim() || form.nameEn.trim(), nameEn: form.nameEn.trim() || form.nameNe.trim(),
                type: a.isSystem ? a.type : form.type, code: a.isSystem ? a.code : code, openingBalance: opening, openingSide: form.side }
            : a
        )
      }));
    } else {
      const acc: Account = {
        id: `acc-${code}`, code, nameNe: form.nameNe.trim() || form.nameEn.trim(), nameEn: form.nameEn.trim() || form.nameNe.trim(),
        type: form.type, isActive: true, openingBalance: opening, openingSide: form.side
      };
      update((d) => ({ ...d, accounts: [...d.accounts, acc] }));
    }
    setForm(blank); setEditId(null); setMsg('');
  };

  const startEdit = (a: Account) => {
    setEditId(a.id);
    setForm({ code: a.code, nameNe: a.nameNe, nameEn: a.nameEn, type: a.type, opening: a.openingBalance ? String(a.openingBalance) : '', side: a.openingSide });
  };

  const remove = (a: Account) => {
    if (a.isSystem || used.has(a.id)) return;
    if (!window.confirm(isNe ? `खाता ${a.code} मेटाउने?` : `Delete account ${a.code}?`)) return;
    update((d) => ({ ...d, accounts: d.accounts.filter((x) => x.id !== a.id) }));
  };

  const order: AccountType[] = ['ASSET', 'LIABILITY', 'EQUITY', 'INCOME', 'EXPENSE'];
  return (
    <div className="space-y-4">
      <Card title={editId ? (isNe ? 'खाता सच्याउने' : 'Edit Account') : (isNe ? 'नयाँ खाता थप्ने' : 'Add Account')}>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
          <Field label={isNe ? 'कोड' : 'Code'}>
            <input className={inputCls} value={form.code} disabled={!!editId && !!data.accounts.find((a) => a.id === editId)?.isSystem}
              onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="5501" />
          </Field>
          <Field label={isNe ? 'नाम (नेपाली)' : 'Name (Nepali)'} className="md:col-span-2">
            <input className={inputCls} value={form.nameNe} onChange={(e) => setForm({ ...form, nameNe: e.target.value })} />
          </Field>
          <Field label={isNe ? 'नाम (अंग्रेजी)' : 'Name (English)'} className="md:col-span-2">
            <input className={inputCls} value={form.nameEn} onChange={(e) => setForm({ ...form, nameEn: e.target.value })} />
          </Field>
          <Field label={isNe ? 'प्रकार' : 'Type'}>
            <select className={inputCls} value={form.type} disabled={!!editId && !!data.accounts.find((a) => a.id === editId)?.isSystem}
              onChange={(e) => {
                const t = e.target.value as AccountType;
                setForm({ ...form, type: t, side: t === 'ASSET' || t === 'EXPENSE' ? 'DR' : 'CR' });
              }}>
              {order.map((t) => <option key={t} value={t}>{isNe ? typeLabels[t].ne : typeLabels[t].en}</option>)}
            </select>
          </Field>
          <Field label={isNe ? 'सुरु मौज्दात (Opening)' : 'Opening Balance'} className="md:col-span-2">
            <input className={inputCls} type="number" step="0.01" value={form.opening} onChange={(e) => setForm({ ...form, opening: e.target.value })} />
          </Field>
          <Field label={isNe ? 'Dr / Cr' : 'Dr / Cr'}>
            <select className={inputCls} value={form.side} onChange={(e) => setForm({ ...form, side: e.target.value as 'DR' | 'CR' })}>
              <option value="DR">Dr (डेबिट)</option>
              <option value="CR">Cr (क्रेडिट)</option>
            </select>
          </Field>
        </div>
        {msg && <div className="text-[11px] text-rose-700 font-bold">{msg}</div>}
        <div className="flex gap-2">
          <button type="button" className={btnPrimary} onClick={save}>{editId ? (isNe ? 'अपडेट' : 'Update') : (isNe ? 'थप्नुहोस्' : 'Add')}</button>
          {editId && <button type="button" className={btnGhost} onClick={() => { setEditId(null); setForm(blank); setMsg(''); }}>{isNe ? 'रद्द' : 'Cancel'}</button>}
        </div>
      </Card>

      {order.map((t) => {
        const list = data.accounts.filter((a) => a.type === t).sort((a, b) => a.code.localeCompare(b.code));
        if (list.length === 0) return null;
        return (
          <Card key={t} title={`${isNe ? typeLabels[t].ne : typeLabels[t].en} (${list.length})`}>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-slate-50"><tr>
                  <th className={th}>{isNe ? 'कोड' : 'Code'}</th>
                  <th className={th}>{isNe ? 'खाताको नाम' : 'Account'}</th>
                  <th className={`${th} text-right`}>{isNe ? 'सुरु मौज्दात' : 'Opening'}</th>
                  <th className={th}>{isNe ? 'स्थिति' : 'Status'}</th>
                  <th className={th}></th>
                </tr></thead>
                <tbody className="divide-y divide-slate-100">
                  {list.map((a) => (
                    <tr key={a.id} className={a.isActive ? '' : 'opacity-50'}>
                      <td className={`${tdc} font-mono font-bold`}>{a.code}</td>
                      <td className={tdc}>{isNe ? a.nameNe : a.nameEn}{a.isSystem && <span className="ml-1.5 text-[9px] bg-slate-100 text-slate-600 px-1 rounded">system</span>}</td>
                      <td className={`${tdc} ${num}`}>{a.openingBalance ? `${fmtMoney(a.openingBalance)} ${a.openingSide === 'DR' ? 'Dr' : 'Cr'}` : '—'}</td>
                      <td className={tdc}>
                        <button type="button" className="text-[11px] underline text-slate-600 cursor-pointer"
                          onClick={() => update((d) => ({ ...d, accounts: d.accounts.map((x) => (x.id === a.id ? { ...x, isActive: !x.isActive } : x)) }))}>
                          {a.isActive ? (isNe ? 'सक्रिय' : 'Active') : (isNe ? 'निष्क्रिय' : 'Inactive')}
                        </button>
                      </td>
                      <td className={`${tdc} text-right whitespace-nowrap space-x-1.5`}>
                        <button type="button" className={btnGhost + ' !py-0.5 !px-2'} onClick={() => startEdit(a)}>{isNe ? 'सच्याउने' : 'Edit'}</button>
                        {!a.isSystem && !used.has(a.id) && <button type="button" className={btnDanger} onClick={() => remove(a)}>{isNe ? 'मेटाउने' : 'Delete'}</button>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        );
      })}
    </div>
  );
};

// ============================================================================
// Journal
// ============================================================================
interface FormLine { accountId: string; debit: string; credit: string; note: string }
const emptyLine = (): FormLine => ({ accountId: '', debit: '', credit: '', note: '' });

const JournalTab: React.FC<{ ctx: Ctx }> = ({ ctx }) => {
  const { isNe, data, update, autoEntries, fy } = ctx;
  const [dateBs, setDateBs] = useState(getTodayBsString());
  const [narration, setNarration] = useState('');
  const [lines, setLines] = useState<FormLine[]>([emptyLine(), emptyLine()]);
  const [editId, setEditId] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ t: 'ok' | 'err'; s: string } | null>(null);
  const [showAuto, setShowAuto] = useState(false);
  const [q, setQ] = useState('');
  const lock = useRef(false);

  const active = data.accounts.filter((a) => a.isActive).sort((a, b) => a.code.localeCompare(b.code));
  const totDr = round2(lines.reduce((s, l) => s + toNum(l.debit), 0));
  const totCr = round2(lines.reduce((s, l) => s + toNum(l.credit), 0));
  const diff = round2(totDr - totCr);
  const filled = lines.filter((l) => l.accountId && (toNum(l.debit) > 0 || toNum(l.credit) > 0));
  const balanced = diff === 0 && totDr > 0 && filled.length >= 2;

  const nextVoucherNo = () => {
    const prefix = `JV-${fyOfBs(dateBs) || fy}-`;
    let max = 0;
    data.journals.forEach((j) => {
      if (j.voucherNo.startsWith(prefix)) {
        const n = parseInt(j.voucherNo.slice(prefix.length), 10);
        if (Number.isFinite(n) && n > max) max = n;
      }
    });
    return `${prefix}${String(max + 1).padStart(4, '0')}`;
  };

  const reset = () => {
    setNarration(''); setLines([emptyLine(), emptyLine()]); setEditId(null);
  };

  const save = () => {
    if (lock.current) return; // double-save guard
    const d = normBs(dateBs);
    if (!d) { setMsg({ t: 'err', s: isNe ? 'मिति YYYY-MM-DD (BS) मा राख्नुहोस्।' : 'Enter a valid BS date (YYYY-MM-DD).' }); return; }
    if (!balanced) { setMsg({ t: 'err', s: isNe ? 'डेबिट र क्रेडिट बराबर हुनुपर्छ (कम्तिमा २ लाइन)।' : 'Debit and credit must be equal (min 2 lines).' }); return; }
    if (filled.some((l) => toNum(l.debit) > 0 && toNum(l.credit) > 0)) {
      setMsg({ t: 'err', s: isNe ? 'एउटै लाइनमा Dr र Cr दुवै नराख्नुहोस्।' : 'A line cannot have both Dr and Cr.' }); return;
    }
    lock.current = true;
    const jl: JournalLine[] = filled.map((l) => ({
      accountId: l.accountId, debit: round2(toNum(l.debit)), credit: round2(toNum(l.credit)), note: l.note.trim() || undefined
    }));
    if (editId) {
      update((x) => ({ ...x, journals: x.journals.map((j) => (j.id === editId ? { ...j, dateBs: d, narration: narration.trim(), lines: jl } : j)) }));
    } else {
      const entry: JournalEntry = {
        id: `jv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        voucherNo: nextVoucherNo(), dateBs: d, narration: narration.trim(), lines: jl, source: 'MANUAL', createdAt: new Date().toISOString()
      };
      update((x) => ({ ...x, journals: [entry, ...x.journals] }));
    }
    setMsg({ t: 'ok', s: isNe ? 'जर्नल सुरक्षित भयो।' : 'Journal saved.' });
    reset();
    setTimeout(() => { lock.current = false; }, 600);
  };

  const startEdit = (j: JournalEntry) => {
    setEditId(j.id); setDateBs(j.dateBs); setNarration(j.narration);
    setLines(j.lines.map((l) => ({ accountId: l.accountId, debit: l.debit ? String(l.debit) : '', credit: l.credit ? String(l.credit) : '', note: l.note || '' })));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const remove = (j: JournalEntry) => {
    if (!window.confirm(isNe ? `${j.voucherNo} मेटाउने?` : `Delete ${j.voucherNo}?`)) return;
    update((x) => ({ ...x, journals: x.journals.filter((e) => e.id !== j.id) }));
  };

  const list = (showAuto ? [...data.journals, ...autoEntries] : data.journals)
    .filter((j) => !q || `${j.voucherNo} ${j.narration}`.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => normBs(b.dateBs).localeCompare(normBs(a.dateBs)))
    .slice(0, 300);

  return (
    <div className="space-y-4">
      <Card title={editId ? (isNe ? 'जर्नल सच्याउने' : 'Edit Journal') : (isNe ? 'नयाँ जर्नल भौचर' : 'New Journal Voucher')}>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
          <Field label={isNe ? 'मिति (BS)' : 'Date (BS)'}><input className={inputCls} value={dateBs} onChange={(e) => setDateBs(e.target.value)} placeholder="2083-01-15" /></Field>
          <Field label={isNe ? 'विवरण / Narration' : 'Narration'} className="md:col-span-3"><input className={inputCls} value={narration} onChange={(e) => setNarration(e.target.value)} /></Field>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-slate-50"><tr>
              <th className={th}>{isNe ? 'खाता' : 'Account'}</th>
              <th className={`${th} w-32 text-right`}>Dr</th>
              <th className={`${th} w-32 text-right`}>Cr</th>
              <th className={th}>{isNe ? 'टिप्पणी' : 'Note'}</th>
              <th className="w-8"></th>
            </tr></thead>
            <tbody>
              {lines.map((l, i) => (
                <tr key={i}>
                  <td className="py-1 pr-1.5">
                    <select className={inputCls} value={l.accountId} onChange={(e) => setLines(lines.map((x, k) => (k === i ? { ...x, accountId: e.target.value } : x)))}>
                      <option value="">{isNe ? '— खाता छान्नुहोस् —' : '— select account —'}</option>
                      {active.map((a) => <option key={a.id} value={a.id}>{a.code} · {isNe ? a.nameNe : a.nameEn}</option>)}
                    </select>
                  </td>
                  <td className="py-1 pr-1.5"><input className={`${inputCls} text-right`} type="number" step="0.01" value={l.debit}
                    onChange={(e) => setLines(lines.map((x, k) => (k === i ? { ...x, debit: e.target.value, credit: e.target.value ? '' : x.credit } : x)))} /></td>
                  <td className="py-1 pr-1.5"><input className={`${inputCls} text-right`} type="number" step="0.01" value={l.credit}
                    onChange={(e) => setLines(lines.map((x, k) => (k === i ? { ...x, credit: e.target.value, debit: e.target.value ? '' : x.debit } : x)))} /></td>
                  <td className="py-1 pr-1.5"><input className={inputCls} value={l.note} onChange={(e) => setLines(lines.map((x, k) => (k === i ? { ...x, note: e.target.value } : x)))} /></td>
                  <td>{lines.length > 2 && <button type="button" className="text-rose-600 cursor-pointer" onClick={() => setLines(lines.filter((_, k) => k !== i))}>✕</button>}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="font-bold">
                <td className="py-1.5 text-right pr-2">{isNe ? 'जम्मा' : 'Total'}</td>
                <td className={`${num} py-1.5 pr-2`}>{fmtMoney(totDr)}</td>
                <td className={`${num} py-1.5 pr-2`}>{fmtMoney(totCr)}</td>
                <td colSpan={2} className={`py-1.5 text-[11px] ${diff === 0 && totDr > 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {diff === 0 && totDr > 0 ? (isNe ? '✔ बराबर छ' : '✔ Balanced') : `${isNe ? 'फरक' : 'Difference'}: ${fmtMoney(Math.abs(diff))}`}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
        {msg && <div className={`text-[11px] font-bold ${msg.t === 'ok' ? 'text-emerald-700' : 'text-rose-700'}`}>{msg.s}</div>}
        <div className="flex gap-2 flex-wrap">
          <button type="button" className={btnGhost} onClick={() => setLines([...lines, emptyLine()])}>+ {isNe ? 'लाइन थप्ने' : 'Add line'}</button>
          <button type="button" className={btnPrimary} disabled={!balanced} onClick={save}>{editId ? (isNe ? 'अपडेट गर्ने' : 'Update') : (isNe ? 'जर्नल सुरक्षित गर्ने' : 'Save Journal')}</button>
          {(editId || narration || filled.length > 0) && <button type="button" className={btnGhost} onClick={() => { reset(); setMsg(null); }}>{isNe ? 'खाली गर्ने' : 'Clear'}</button>}
        </div>
      </Card>

      <Card title={isNe ? 'जर्नल सूची' : 'Journal Entries'}
        right={
          <div className="flex items-center gap-3 flex-wrap">
            <input className={`${inputCls} !w-44`} placeholder={isNe ? 'खोज्नुहोस्…' : 'Search…'} value={q} onChange={(e) => setQ(e.target.value)} />
            <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer">
              <input type="checkbox" checked={showAuto} onChange={(e) => setShowAuto(e.target.checked)} />
              {isNe ? 'स्वचालित पनि देखाउने' : 'Show auto-posted'}
            </label>
          </div>
        }>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-slate-50"><tr>
              <th className={th}>{isNe ? 'मिति' : 'Date'}</th><th className={th}>{isNe ? 'भौचर नं.' : 'Voucher'}</th>
              <th className={th}>{isNe ? 'विवरण' : 'Narration'}</th><th className={th}>{isNe ? 'लाइनहरू' : 'Lines'}</th><th className={`${th} text-right`}>{isNe ? 'रकम' : 'Amount'}</th><th></th>
            </tr></thead>
            <tbody className="divide-y divide-slate-100">
              {list.length === 0 && <tr><td colSpan={6} className="py-6 text-center text-slate-400">{isNe ? 'कुनै जर्नल छैन' : 'No entries'}</td></tr>}
              {list.map((j) => {
                const total = round2(j.lines.reduce((s, l) => s + l.debit, 0));
                const manual = j.source !== 'AUTO';
                return (
                  <tr key={j.id} className="align-top">
                    <td className={`${tdc} font-mono whitespace-nowrap`}>{j.dateBs}</td>
                    <td className={`${tdc} font-mono`}>{j.voucherNo}{!manual && <span className="ml-1 text-[9px] bg-sky-100 text-sky-800 px-1 rounded">auto</span>}</td>
                    <td className={tdc}>{j.narration}</td>
                    <td className={`${tdc} text-[11px] text-slate-600`}>
                      {j.lines.map((l, i) => (
                        <div key={i}>{l.debit ? 'Dr' : 'Cr'} {ctx.accName(l.accountId)} — {fmtMoney(l.debit || l.credit)}</div>
                      ))}
                    </td>
                    <td className={`${tdc} ${num} font-bold`}>{fmtMoney(total)}</td>
                    <td className={`${tdc} whitespace-nowrap space-x-1`}>
                      {manual && <button type="button" className={btnGhost + ' !py-0.5 !px-2'} onClick={() => startEdit(j)}>{isNe ? 'सच्याउने' : 'Edit'}</button>}
                      {manual && <button type="button" className={btnDanger} onClick={() => remove(j)}>{isNe ? 'मेटाउने' : 'Del'}</button>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

// ============================================================================
// Ledger (account-wise)
// ============================================================================
const LedgerTab: React.FC<{ ctx: Ctx }> = ({ ctx }) => {
  const { isNe, data, entries, fy } = ctx;
  const accounts = data.accounts.slice().sort((a, b) => a.code.localeCompare(b.code));
  const [accId, setAccId] = useState(accounts[0]?.id || '');
  const range = fyRange(fy);
  const [from, setFrom] = useState(range.from);
  const [to, setTo] = useState(range.to);
  useEffect(() => { setFrom(range.from); setTo(range.to); }, [fy]);
  const acc = accounts.find((a) => a.id === accId);
  const res = useMemo(() => (acc ? buildAccountLedger(acc, entries, normBs(from) || range.from, normBs(to) || range.to) : null), [acc, entries, from, to]);
  const drcr = (n: number) => `${fmtMoney(Math.abs(n))} ${n >= 0 ? 'Dr' : 'Cr'}`;
  return (
    <Card title={isNe ? 'खाता बही (Ledger)' : 'Account Ledger'}
      right={res && <button type="button" className={btnGhost} onClick={() => downloadCsv(`ledger-${acc?.code}.csv`, [
        ['Date', 'Voucher', 'Narration', 'Debit', 'Credit', 'Balance'],
        ['', '', 'Opening', '', '', res.opening],
        ...res.rows.map((r) => [r.dateBs, r.voucherNo, r.narration, r.debit, r.credit, r.balance])
      ])}>CSV</button>}>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
        <Field label={isNe ? 'खाता' : 'Account'} className="md:col-span-2">
          <select className={inputCls} value={accId} onChange={(e) => setAccId(e.target.value)}>
            {accounts.map((a) => <option key={a.id} value={a.id}>{a.code} · {isNe ? a.nameNe : a.nameEn}</option>)}
          </select>
        </Field>
        <Field label={isNe ? 'देखि' : 'From'}><input className={inputCls} value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
        <Field label={isNe ? 'सम्म' : 'To'}><input className={inputCls} value={to} onChange={(e) => setTo(e.target.value)} /></Field>
      </div>
      {res && (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-slate-50"><tr>
              <th className={th}>{isNe ? 'मिति' : 'Date'}</th><th className={th}>{isNe ? 'भौचर' : 'Voucher'}</th><th className={th}>{isNe ? 'विवरण' : 'Narration'}</th>
              <th className={`${th} text-right`}>Dr</th><th className={`${th} text-right`}>Cr</th><th className={`${th} text-right`}>{isNe ? 'ब्यालेन्स' : 'Balance'}</th>
            </tr></thead>
            <tbody className="divide-y divide-slate-100">
              <tr className="bg-slate-50 font-bold"><td className={tdc} colSpan={5}>{isNe ? 'सुरु मौज्दात' : 'Opening balance'}</td><td className={`${tdc} ${num}`}>{drcr(res.opening)}</td></tr>
              {res.rows.map((r, i) => (
                <tr key={i}>
                  <td className={`${tdc} font-mono whitespace-nowrap`}>{r.dateBs}</td><td className={`${tdc} font-mono`}>{r.voucherNo}</td><td className={tdc}>{r.narration}</td>
                  <td className={`${tdc} ${num}`}>{r.debit ? fmtMoney(r.debit) : ''}</td><td className={`${tdc} ${num}`}>{r.credit ? fmtMoney(r.credit) : ''}</td>
                  <td className={`${tdc} ${num}`}>{drcr(r.balance)}</td>
                </tr>
              ))}
              <tr className="bg-emerald-50 font-extrabold"><td className={tdc} colSpan={5}>{isNe ? 'अन्तिम मौज्दात' : 'Closing balance'}</td><td className={`${tdc} ${num}`}>{drcr(res.closing)}</td></tr>
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
};

// ============================================================================
// Trial Balance
// ============================================================================
const TrialBalanceTab: React.FC<{ ctx: Ctx }> = ({ ctx }) => {
  const { isNe, data, entries, fy } = ctx;
  const range = fyRange(fy);
  const [from, setFrom] = useState(range.from);
  const [to, setTo] = useState(range.to);
  useEffect(() => { setFrom(range.from); setTo(range.to); }, [fy]);
  const f = normBs(from) || range.from;
  const t = normBs(to) || range.to;
  const tb = useMemo(() => computeTrialBalance(data.accounts, entries, f, t), [data.accounts, entries, f, t]);
  const balanced = tb.totals.closingDr === tb.totals.closingCr;
  const profit = useMemo(() => {
    const inc = data.accounts.filter((a) => a.type === 'INCOME').reduce((s, a) => s + accountActivity(a, entries, f, t), 0);
    const exp = data.accounts.filter((a) => a.type === 'EXPENSE').reduce((s, a) => s + accountActivity(a, entries, f, t), 0);
    return { inc: round2(inc), exp: round2(exp), net: round2(inc - exp) };
  }, [data.accounts, entries, f, t]);

  const exportCsv = () => downloadCsv(`trial-balance-${fy.replace('/', '-')}.csv`, [
    ['Code', 'Account', 'Type', 'Opening Dr', 'Opening Cr', 'Period Dr', 'Period Cr', 'Closing Dr', 'Closing Cr'],
    ...tb.rows.map((r) => [r.account.code, r.account.nameEn, r.account.type, r.openingDr, r.openingCr, r.periodDr, r.periodCr, r.closingDr, r.closingCr]),
    ['', 'TOTAL', '', tb.totals.openingDr, tb.totals.openingCr, tb.totals.periodDr, tb.totals.periodCr, tb.totals.closingDr, tb.totals.closingCr]
  ]);

  return (
    <div className="space-y-4">
      <Card title={isNe ? 'ट्रायल ब्यालेन्स' : 'Trial Balance'} right={<button type="button" className={btnGhost} onClick={exportCsv}>CSV / Excel</button>}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 items-end">
          <Field label={isNe ? 'देखि (BS)' : 'From (BS)'}><input className={inputCls} value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
          <Field label={isNe ? 'सम्म (BS)' : 'To (BS)'}><input className={inputCls} value={to} onChange={(e) => setTo(e.target.value)} /></Field>
          <div className={`md:col-span-2 text-xs font-extrabold px-3 py-2 rounded-lg ${balanced ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'}`}>
            {balanced
              ? (isNe ? '✔ ट्रायल ब्यालेन्स मिलेको छ' : '✔ Trial balance is balanced')
              : `${isNe ? '⚠ फरक' : '⚠ Out of balance by'} ${fmtMoney(Math.abs(tb.totals.closingDr - tb.totals.closingCr))} — ${isNe ? 'सुरु मौज्दात (Opening) जाँच्नुहोस्' : 'check Opening Balances'}`}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-slate-50">
              <tr>
                <th className={th} rowSpan={2}>{isNe ? 'कोड' : 'Code'}</th>
                <th className={th} rowSpan={2}>{isNe ? 'खाता' : 'Account'}</th>
                <th className={`${th} text-center`} colSpan={2}>{isNe ? 'सुरु' : 'Opening'}</th>
                <th className={`${th} text-center`} colSpan={2}>{isNe ? 'अवधिको कारोबार' : 'Period'}</th>
                <th className={`${th} text-center`} colSpan={2}>{isNe ? 'अन्तिम' : 'Closing'}</th>
              </tr>
              <tr>{['Dr', 'Cr', 'Dr', 'Cr', 'Dr', 'Cr'].map((h, i) => <th key={i} className={`${th} text-right`}>{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {tb.rows.length === 0 && <tr><td colSpan={8} className="py-6 text-center text-slate-400">{isNe ? 'यो अवधिमा कारोबार छैन' : 'No activity in this period'}</td></tr>}
              {tb.rows.map((r) => (
                <tr key={r.account.id}>
                  <td className={`${tdc} font-mono font-bold`}>{r.account.code}</td>
                  <td className={tdc}>{isNe ? r.account.nameNe : r.account.nameEn}</td>
                  {[r.openingDr, r.openingCr, r.periodDr, r.periodCr, r.closingDr, r.closingCr].map((v, i) => (
                    <td key={i} className={`${tdc} ${num}`}>{v ? fmtMoney(v) : ''}</td>
                  ))}
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-100 font-extrabold">
              <tr>
                <td className={tdc} colSpan={2}>{isNe ? 'जम्मा' : 'TOTAL'}</td>
                {[tb.totals.openingDr, tb.totals.openingCr, tb.totals.periodDr, tb.totals.periodCr, tb.totals.closingDr, tb.totals.closingCr].map((v, i) => (
                  <td key={i} className={`${tdc} ${num}`}>{fmtMoney(v)}</td>
                ))}
              </tr>
            </tfoot>
          </table>
        </div>
      </Card>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          { l: isNe ? 'कुल आम्दानी' : 'Total Income', v: profit.inc, c: 'text-emerald-800' },
          { l: isNe ? 'कुल खर्च' : 'Total Expenses', v: profit.exp, c: 'text-rose-800' },
          { l: isNe ? 'खुद नाफा / (नोक्सान)' : 'Net Profit / (Loss)', v: profit.net, c: profit.net >= 0 ? 'text-emerald-800' : 'text-rose-800' }
        ].map((x) => (
          <div key={x.l} className="bg-white border border-slate-200 rounded-xl p-3">
            <div className="text-[11px] font-bold text-slate-500">{x.l}</div>
            <div className={`text-lg font-extrabold font-mono ${x.c}`}>Rs. {fmtMoney(x.v)}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// Fixed assets & depreciation
// ============================================================================
const ASSET_CATEGORIES: Array<{ key: string; ne: string; en: string; rate: number }> = [
  { key: 'A', ne: 'ब्लक A — भवन / संरचना', en: 'Block A — Buildings', rate: 5 },
  { key: 'B', ne: 'ब्लक B — फर्निचर, कम्प्युटर, अफिस सामग्री', en: 'Block B — Furniture, computers, office equipment', rate: 25 },
  { key: 'C', ne: 'ब्लक C — सवारी साधन / निर्माण उपकरण', en: 'Block C — Vehicles / construction equipment', rate: 20 },
  { key: 'D', ne: 'ब्लक D — मेसिनरी तथा अन्य', en: 'Block D — Machinery & others', rate: 15 }
];

const AssetsTab: React.FC<{ ctx: Ctx }> = ({ ctx }) => {
  const { isNe, data, update, fy } = ctx;
  const blank = {
    name: '', category: 'D', purchaseDateBs: getTodayBsString(), cost: '', salvage: '0', method: 'WDV' as DepMethod,
    rate: '15', life: '5', depStartFy: '', openingAccum: '0', postJv: true, counter: 'acc-1001'
  };
  const [form, setForm] = useState(blank);
  const [msg, setMsg] = useState<{ t: 'ok' | 'err'; s: string } | null>(null);
  const [disposing, setDisposing] = useState<{ id: string; date: string; amount: string } | null>(null);
  const lock = useRef(false);

  const save = () => {
    if (lock.current) return;
    const cost = toNum(form.cost);
    const pd = normBs(form.purchaseDateBs);
    if (!form.name.trim() || cost <= 0 || !pd) {
      setMsg({ t: 'err', s: isNe ? 'नाम, खरिद मिति र लागत आवश्यक छ।' : 'Name, purchase date and cost are required.' }); return;
    }
    lock.current = true;
    const id = `fa-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const code = `FA-${String(data.assets.length + 1).padStart(3, '0')}`;
    const openingAccum = Math.max(0, toNum(form.openingAccum));
    const asset: FixedAsset = {
      id, code, name: form.name.trim(), category: form.category, purchaseDateBs: pd, cost: round2(cost),
      salvageValue: round2(Math.max(0, toNum(form.salvage))), method: form.method, ratePct: toNum(form.rate),
      usefulLifeYears: Math.max(1, toNum(form.life)), depStartFy: form.depStartFy.trim() || fyOfBs(pd),
      openingAccumDep: round2(openingAccum), status: 'ACTIVE'
    };
    update((d) => {
      const journals = [...d.journals];
      if (form.postJv) {
        const lines: JournalLine[] = [
          { accountId: 'acc-1501', debit: asset.cost, credit: 0 },
          { accountId: form.counter, debit: 0, credit: asset.cost }
        ];
        if (openingAccum > 0) {
          lines.push({ accountId: 'acc-3002', debit: round2(openingAccum), credit: 0 });
          lines.push({ accountId: 'acc-1599', debit: 0, credit: round2(openingAccum) });
        }
        journals.unshift({
          id: `jv-${id}`, voucherNo: `FA-${code}`, dateBs: pd, narration: `स्थिर सम्पत्ति खरिद — ${asset.name}`,
          lines, source: 'ASSET', refKey: `asset:${id}`, createdAt: new Date().toISOString()
        });
      }
      return { ...d, assets: [...d.assets, asset], journals };
    });
    setMsg({ t: 'ok', s: isNe ? 'सम्पत्ति थपियो।' : 'Asset added.' });
    setForm(blank);
    setTimeout(() => { lock.current = false; }, 600);
  };

  const rows = useMemo(
    () => data.assets.map((a) => {
      const sched = computeDepreciation(a, fy);
      const thisYear = sched.find((r) => r.fy === fy);
      const last = sched[sched.length - 1];
      const accum = last ? last.accumulated : a.openingAccumDep || 0;
      return { asset: a, sched, thisYear, accum, wdv: round2(a.cost - accum) };
    }),
    [data.assets, fy]
  );
  const totalDep = round2(rows.reduce((s, r) => s + (r.thisYear?.dep || 0), 0));
  const alreadyPosted = data.journals.some((j) => j.refKey === `dep:${fy}`);

  const postDep = () => {
    if (lock.current) return;
    if (alreadyPosted) { setMsg({ t: 'err', s: isNe ? `आ.व. ${fy} को ह्रास पहिले नै जर्नलमा चढिसकेको छ।` : `Depreciation for ${fy} is already posted.` }); return; }
    if (totalDep <= 0) { setMsg({ t: 'err', s: isNe ? 'यो आ.व. को ह्रास शून्य छ।' : 'No depreciation for this year.' }); return; }
    lock.current = true;
    const end = fyRange(fy).to.replace(/-32$/, '-30');
    update((d) => ({
      ...d,
      journals: [{
        id: `jv-dep-${fy}`, voucherNo: `DEP-${fy}`, dateBs: end, narration: `आ.व. ${fy} को ह्रासकट्टी`,
        lines: [{ accountId: 'acc-5301', debit: totalDep, credit: 0 }, { accountId: 'acc-1599', debit: 0, credit: totalDep }],
        source: 'DEPRECIATION', refKey: `dep:${fy}`, createdAt: new Date().toISOString()
      }, ...d.journals]
    }));
    setMsg({ t: 'ok', s: isNe ? 'ह्रासकट्टी जर्नलमा चढ्यो।' : 'Depreciation posted to journal.' });
    setTimeout(() => { lock.current = false; }, 600);
  };

  const removeAsset = (a: FixedAsset) => {
    if (!window.confirm(isNe ? `${a.name} मेटाउने? (यसको खरिद जर्नल पनि हट्छ)` : `Delete ${a.name}? Its purchase journal is removed too.`)) return;
    update((d) => ({ ...d, assets: d.assets.filter((x) => x.id !== a.id), journals: d.journals.filter((j) => j.refKey !== `asset:${a.id}`) }));
  };

  const confirmDispose = () => {
    if (!disposing) return;
    const dt = normBs(disposing.date);
    if (!dt) return;
    update((d) => ({
      ...d,
      assets: d.assets.map((a) => (a.id === disposing.id ? { ...a, status: 'DISPOSED', disposalDateBs: dt, disposalAmount: round2(toNum(disposing.amount)) } : a))
    }));
    setDisposing(null);
  };

  return (
    <div className="space-y-4">
      <Card title={isNe ? 'नयाँ स्थिर सम्पत्ति' : 'Add Fixed Asset'}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <Field label={isNe ? 'सम्पत्तिको नाम' : 'Asset name'} className="col-span-2"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label={isNe ? 'वर्ग' : 'Category'} className="col-span-2">
            <select className={inputCls} value={form.category} onChange={(e) => {
              const c = ASSET_CATEGORIES.find((x) => x.key === e.target.value);
              setForm({ ...form, category: e.target.value, rate: String(c?.rate ?? form.rate) });
            }}>
              {ASSET_CATEGORIES.map((c) => <option key={c.key} value={c.key}>{isNe ? c.ne : c.en} ({c.rate}%)</option>)}
            </select>
          </Field>
          <Field label={isNe ? 'खरिद मिति (BS)' : 'Purchase date (BS)'}><input className={inputCls} value={form.purchaseDateBs} onChange={(e) => setForm({ ...form, purchaseDateBs: e.target.value })} /></Field>
          <Field label={isNe ? 'लागत (रु.)' : 'Cost'}><input className={inputCls} type="number" step="0.01" value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value })} /></Field>
          <Field label={isNe ? 'विधि' : 'Method'}>
            <select className={inputCls} value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value as DepMethod })}>
              <option value="WDV">{isNe ? 'घट्दो मूल्य (WDV / पूल)' : 'Written-down value (pool)'}</option>
              <option value="SLM">{isNe ? 'सरल रेखा (SLM)' : 'Straight-line'}</option>
            </select>
          </Field>
          {form.method === 'WDV'
            ? <Field label={isNe ? 'दर % (वार्षिक)' : 'Rate % p.a.'}><input className={inputCls} type="number" step="0.01" value={form.rate} onChange={(e) => setForm({ ...form, rate: e.target.value })} /></Field>
            : <Field label={isNe ? 'उपयोगी आयु (वर्ष)' : 'Useful life (yrs)'}><input className={inputCls} type="number" value={form.life} onChange={(e) => setForm({ ...form, life: e.target.value })} /></Field>}
          <Field label={isNe ? 'अवशेष मूल्य' : 'Salvage value'}><input className={inputCls} type="number" step="0.01" value={form.salvage} onChange={(e) => setForm({ ...form, salvage: e.target.value })} /></Field>
          <Field label={isNe ? 'ह्रास सुरु आ.व.' : 'Depreciate from F.Y.'}><input className={inputCls} placeholder={fyOfBs(form.purchaseDateBs) || '082/83'} value={form.depStartFy} onChange={(e) => setForm({ ...form, depStartFy: e.target.value })} /></Field>
          <Field label={isNe ? 'अघिल्लो सञ्चित ह्रास' : 'Accumulated dep. b/f'}><input className={inputCls} type="number" step="0.01" value={form.openingAccum} onChange={(e) => setForm({ ...form, openingAccum: e.target.value })} /></Field>
          <Field label={isNe ? 'भुक्तानी खाता' : 'Paid from / Credit'} className="col-span-2">
            <select className={inputCls} value={form.counter} onChange={(e) => setForm({ ...form, counter: e.target.value })}>
              {['acc-1001', 'acc-1002', 'acc-2001', 'acc-3001', 'acc-3002', 'acc-2301'].map((id) => <option key={id} value={id}>{ctx.accName(id)}</option>)}
            </select>
          </Field>
          <label className="flex items-center gap-1.5 text-[11px] font-bold text-slate-700 col-span-2 md:col-span-4 cursor-pointer">
            <input type="checkbox" checked={form.postJv} onChange={(e) => setForm({ ...form, postJv: e.target.checked })} />
            {isNe ? 'खरिद जर्नल पनि बनाउने (स्थिर सम्पत्ति Dr / भुक्तानी खाता Cr) — पहिले नै अरू ठाउँ रेकर्ड गरिसकेको भए बन्द गर्नुहोस्' : 'Also post the purchase journal (Dr Fixed Assets / Cr selected account) — untick if already recorded elsewhere'}
          </label>
        </div>
        <button type="button" className={btnPrimary} onClick={save}>{isNe ? 'सम्पत्ति थप्ने' : 'Add Asset'}</button>
        <p className="text-[10px] text-slate-500">
          {isNe ? 'दरहरू सन्दर्भका लागि हुन् — आयकर ऐन अनुसार हालको दर आफ्नो लेखा परीक्षकसँग पुष्टि गर्नुहोस्।' : 'Rates are reference defaults — confirm current rates under the Income Tax Act with your auditor.'}
        </p>
      </Card>

      {msg && <div className={`text-xs font-bold ${msg.t === 'ok' ? 'text-emerald-700' : 'text-rose-700'}`}>{msg.s}</div>}

      <Card title={`${isNe ? 'ह्रास तालिका — आ.व.' : 'Depreciation Schedule — F.Y.'} ${fy}`}
        right={
          <div className="flex gap-2">
            <button type="button" className={btnGhost} onClick={() => downloadCsv(`depreciation-${fy.replace('/', '-')}.csv`, [
              ['Code', 'Asset', 'Cost', 'Opening WDV', 'Depreciation', 'Closing WDV', 'Accumulated'],
              ...rows.map((r) => [r.asset.code, r.asset.name, r.asset.cost, r.thisYear?.opening ?? '', r.thisYear?.dep ?? 0, r.thisYear?.closing ?? '', r.accum])
            ])}>CSV</button>
            <button type="button" className={btnPrimary} disabled={alreadyPosted || totalDep <= 0} onClick={postDep}>
              {alreadyPosted ? (isNe ? '✔ जर्नलमा चढिसक्यो' : '✔ Posted') : (isNe ? 'ह्रास जर्नलमा चढाउने' : 'Post depreciation')}
            </button>
          </div>
        }>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-slate-50"><tr>
              <th className={th}>{isNe ? 'कोड' : 'Code'}</th><th className={th}>{isNe ? 'सम्पत्ति' : 'Asset'}</th>
              <th className={`${th} text-right`}>{isNe ? 'लागत' : 'Cost'}</th><th className={`${th} text-right`}>{isNe ? 'सुरु मूल्य' : 'Opening WDV'}</th>
              <th className={`${th} text-right`}>{isNe ? 'यो वर्षको ह्रास' : 'Dep. (year)'}</th><th className={`${th} text-right`}>{isNe ? 'अन्तिम मूल्य' : 'Closing WDV'}</th>
              <th className={th}>{isNe ? 'स्थिति' : 'Status'}</th><th></th>
            </tr></thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 && <tr><td colSpan={8} className="py-6 text-center text-slate-400">{isNe ? 'कुनै सम्पत्ति छैन' : 'No assets yet'}</td></tr>}
              {rows.map(({ asset: a, thisYear, wdv }) => {
                const gain = a.status === 'DISPOSED' ? round2((a.disposalAmount || 0) - wdv) : null;
                return (
                  <tr key={a.id} className="align-top">
                    <td className={`${tdc} font-mono`}>{a.code}</td>
                    <td className={tdc}>{a.name}<div className="text-[10px] text-slate-500">{a.method} · {a.method === 'WDV' ? `${a.ratePct}%` : `${a.usefulLifeYears}y`} · {a.purchaseDateBs}</div></td>
                    <td className={`${tdc} ${num}`}>{fmtMoney(a.cost)}</td>
                    <td className={`${tdc} ${num}`}>{thisYear ? fmtMoney(thisYear.opening) : '—'}</td>
                    <td className={`${tdc} ${num}`}>{thisYear ? fmtMoney(thisYear.dep) : '—'}</td>
                    <td className={`${tdc} ${num}`}>{fmtMoney(wdv)}</td>
                    <td className={tdc}>
                      {a.status === 'ACTIVE' ? <span className="text-emerald-700 font-bold">{isNe ? 'सक्रिय' : 'Active'}</span>
                        : <span className="text-slate-600">{isNe ? 'बिक्री/हटाइएको' : 'Disposed'} {a.disposalDateBs}
                            <div className={`font-bold ${gain! >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>{gain! >= 0 ? (isNe ? 'नाफा' : 'Gain') : (isNe ? 'नोक्सान' : 'Loss')}: {fmtMoney(Math.abs(gain!))}</div></span>}
                    </td>
                    <td className={`${tdc} whitespace-nowrap space-x-1`}>
                      {a.status === 'ACTIVE' && <button type="button" className={btnGhost + ' !py-0.5 !px-2'} onClick={() => setDisposing({ id: a.id, date: getTodayBsString(), amount: '0' })}>{isNe ? 'हटाउने/बिक्री' : 'Dispose'}</button>}
                      <button type="button" className={btnDanger} onClick={() => removeAsset(a)}>{isNe ? 'मेटाउने' : 'Del'}</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot className="bg-slate-100 font-extrabold"><tr>
              <td className={tdc} colSpan={4}>{isNe ? 'जम्मा' : 'Total'}</td><td className={`${tdc} ${num}`}>{fmtMoney(totalDep)}</td><td colSpan={3}></td>
            </tr></tfoot>
          </table>
        </div>
        {disposing && (
          <div className="border border-amber-300 bg-amber-50 rounded-xl p-3 grid grid-cols-2 md:grid-cols-4 gap-2 items-end">
            <Field label={isNe ? 'हटाएको मिति (BS)' : 'Disposal date (BS)'}><input className={inputCls} value={disposing.date} onChange={(e) => setDisposing({ ...disposing, date: e.target.value })} /></Field>
            <Field label={isNe ? 'बिक्री रकम' : 'Sale proceeds'}><input className={inputCls} type="number" value={disposing.amount} onChange={(e) => setDisposing({ ...disposing, amount: e.target.value })} /></Field>
            <div className="flex gap-2 col-span-2">
              <button type="button" className={btnPrimary} onClick={confirmDispose}>{isNe ? 'पुष्टि' : 'Confirm'}</button>
              <button type="button" className={btnGhost} onClick={() => setDisposing(null)}>{isNe ? 'रद्द' : 'Cancel'}</button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

// ============================================================================
// TDS
// ============================================================================
const TdsTab: React.FC<{ ctx: Ctx }> = ({ ctx }) => {
  const { isNe, data, update, fy } = ctx;
  const blank = { dateBs: getTodayBsString(), direction: 'DEDUCTED' as TdsDirection, partyName: '', panNo: '', preset: 'SERVICE', gross: '', rate: '1.5', ref: '', notes: '' };
  const [form, setForm] = useState(blank);
  const [msg, setMsg] = useState('');
  const [depositing, setDepositing] = useState<{ id: string; date: string; ref: string } | null>(null);
  const lock = useRef(false);
  const range = fyRange(fy);

  const inFy = data.tds.filter((t) => { const d = normBs(t.dateBs); return d >= range.from && d <= range.to; })
    .sort((a, b) => normBs(b.dateBs).localeCompare(normBs(a.dateBs)));
  const sum = (arr: TdsEntry[]) => round2(arr.reduce((s, t) => s + t.tdsAmount, 0));
  const ded = inFy.filter((t) => t.direction === 'DEDUCTED');
  const suf = inFy.filter((t) => t.direction === 'SUFFERED');
  const dedTotal = sum(ded);
  const dedDeposited = sum(ded.filter((t) => t.deposited));

  const tdsPreview = round2((toNum(form.gross) * toNum(form.rate)) / 100);

  const save = () => {
    if (lock.current) return;
    const d = normBs(form.dateBs);
    if (!d || !form.partyName.trim() || toNum(form.gross) <= 0) { setMsg(isNe ? 'मिति, पक्षको नाम र रकम आवश्यक छ।' : 'Date, party and amount are required.'); return; }
    lock.current = true;
    const e: TdsEntry = {
      id: `tds-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, dateBs: d, direction: form.direction,
      partyName: form.partyName.trim(), panNo: form.panNo.trim() || undefined,
      category: form.preset, grossAmount: round2(toNum(form.gross)), ratePct: toNum(form.rate), tdsAmount: tdsPreview,
      referenceNo: form.ref.trim() || undefined, deposited: form.direction === 'SUFFERED', notes: form.notes.trim() || undefined
    };
    update((x) => ({ ...x, tds: [e, ...x.tds] }));
    setForm({ ...blank, direction: form.direction }); setMsg('');
    setTimeout(() => { lock.current = false; }, 600);
  };

  // monthly deposit summary (TDS deducted must be deposited by the 25th of the following Nepali month)
  const monthly = useMemo(() => {
    const m = new Map<string, { ded: number; dep: number }>();
    ded.forEach((t) => {
      const k = normBs(t.dateBs).slice(0, 7);
      const cur = m.get(k) || { ded: 0, dep: 0 };
      cur.ded = round2(cur.ded + t.tdsAmount);
      if (t.deposited) cur.dep = round2(cur.dep + t.tdsAmount);
      m.set(k, cur);
    });
    return Array.from(m.entries()).sort((a, b) => a[0].localeCompare(b[0])).map(([k, v]) => {
      let [y, mo] = k.split('-').map(Number);
      mo += 1; if (mo > 12) { mo = 1; y += 1; }
      return { month: k, ...v, due: `${y}-${String(mo).padStart(2, '0')}-25` };
    });
  }, [ded]);

  return (
    <div className="space-y-4">
      <Card title={isNe ? 'TDS दर्ता' : 'Record TDS'}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <Field label={isNe ? 'मिति (BS)' : 'Date (BS)'}><input className={inputCls} value={form.dateBs} onChange={(e) => setForm({ ...form, dateBs: e.target.value })} /></Field>
          <Field label={isNe ? 'प्रकार' : 'Direction'}>
            <select className={inputCls} value={form.direction} onChange={(e) => setForm({ ...form, direction: e.target.value as TdsDirection })}>
              <option value="DEDUCTED">{isNe ? 'हामीले कट्टी गरेको (तिर्नुपर्ने)' : 'Deducted by us (payable to IRD)'}</option>
              <option value="SUFFERED">{isNe ? 'ग्राहकले कट्टी गरेको (हाम्रो क्रेडिट)' : 'Deducted from us (our credit)'}</option>
            </select>
          </Field>
          <Field label={isNe ? 'पक्षको नाम' : 'Party'}><input className={inputCls} value={form.partyName} onChange={(e) => setForm({ ...form, partyName: e.target.value })} /></Field>
          <Field label="PAN"><input className={inputCls} value={form.panNo} onChange={(e) => setForm({ ...form, panNo: e.target.value })} /></Field>
          <Field label={isNe ? 'किसिम' : 'Category'} className="col-span-2">
            <select className={inputCls} value={form.preset} onChange={(e) => {
              const p = TDS_PRESETS.find((x) => x.key === e.target.value);
              setForm({ ...form, preset: e.target.value, rate: String(p?.rate ?? form.rate) });
            }}>
              {TDS_PRESETS.map((p) => <option key={p.key} value={p.key}>{isNe ? p.ne : p.en} ({p.rate}%)</option>)}
            </select>
          </Field>
          <Field label={isNe ? 'कुल भुक्तानी (Gross)' : 'Gross amount'}><input className={inputCls} type="number" step="0.01" value={form.gross} onChange={(e) => setForm({ ...form, gross: e.target.value })} /></Field>
          <Field label={isNe ? 'दर %' : 'Rate %'}><input className={inputCls} type="number" step="0.01" value={form.rate} onChange={(e) => setForm({ ...form, rate: e.target.value })} /></Field>
          <Field label={isNe ? 'सन्दर्भ / बिल नं.' : 'Reference'}><input className={inputCls} value={form.ref} onChange={(e) => setForm({ ...form, ref: e.target.value })} /></Field>
          <div className="md:col-span-3 flex items-end text-xs font-extrabold text-slate-800">
            TDS = Rs. {fmtMoney(tdsPreview)} <span className="ml-3 font-medium text-slate-500">{isNe ? 'खुद भुक्तानी' : 'Net payable'} = Rs. {fmtMoney(toNum(form.gross) - tdsPreview)}</span>
          </div>
        </div>
        {msg && <div className="text-[11px] text-rose-700 font-bold">{msg}</div>}
        <button type="button" className={btnPrimary} onClick={save}>{isNe ? 'दर्ता गर्ने' : 'Save'}</button>
        <p className="text-[10px] text-slate-500">{isNe ? 'दरहरू सम्पादन गर्न मिल्छ — हालको दर IRD/वित्त ऐन अनुसार पुष्टि गर्नुहोस्।' : 'Rates are editable defaults — verify with the current Finance Act / IRD.'}</p>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { l: isNe ? 'कट्टी गरेको TDS' : 'TDS deducted', v: dedTotal },
          { l: isNe ? 'बुझाइसकेको' : 'Deposited', v: dedDeposited },
          { l: isNe ? 'बुझाउन बाँकी' : 'Outstanding', v: round2(dedTotal - dedDeposited) },
          { l: isNe ? 'ग्राहकले काटेको (क्रेडिट)' : 'TDS suffered (credit)', v: sum(suf) }
        ].map((x) => (
          <div key={x.l} className="bg-white border border-slate-200 rounded-xl p-3">
            <div className="text-[11px] font-bold text-slate-500">{x.l}</div>
            <div className="text-base font-extrabold font-mono text-slate-900">Rs. {fmtMoney(x.v)}</div>
          </div>
        ))}
      </div>

      {monthly.length > 0 && (
        <Card title={isNe ? 'मासिक TDS बुझाउने स्थिति' : 'Monthly TDS deposit status'}>
          <table className="w-full text-xs">
            <thead className="bg-slate-50"><tr><th className={th}>{isNe ? 'महिना' : 'Month'}</th><th className={`${th} text-right`}>{isNe ? 'कट्टी' : 'Deducted'}</th><th className={`${th} text-right`}>{isNe ? 'बुझाएको' : 'Deposited'}</th><th className={`${th} text-right`}>{isNe ? 'बाँकी' : 'Due'}</th><th className={th}>{isNe ? 'अन्तिम मिति' : 'Deadline'}</th></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {monthly.map((m) => {
                const bal = round2(m.ded - m.dep);
                return (
                  <tr key={m.month}><td className={`${tdc} font-mono`}>{m.month}</td><td className={`${tdc} ${num}`}>{fmtMoney(m.ded)}</td><td className={`${tdc} ${num}`}>{fmtMoney(m.dep)}</td>
                    <td className={`${tdc} ${num} ${bal > 0 ? 'text-rose-700 font-bold' : ''}`}>{fmtMoney(bal)}</td><td className={`${tdc} font-mono`}>{m.due}</td></tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      )}

      <Card title={`${isNe ? 'TDS रजिस्टर — आ.व.' : 'TDS Register — F.Y.'} ${fy}`}
        right={<button type="button" className={btnGhost} onClick={() => downloadCsv(`tds-${fy.replace('/', '-')}.csv`, [
          ['Date', 'Direction', 'Party', 'PAN', 'Category', 'Gross', 'Rate %', 'TDS', 'Deposited', 'Deposit date', 'Deposit ref'],
          ...inFy.map((t) => [t.dateBs, t.direction, t.partyName, t.panNo || '', t.category, t.grossAmount, t.ratePct, t.tdsAmount, t.deposited ? 'Yes' : 'No', t.depositDateBs || '', t.depositRef || ''])
        ])}>CSV</button>}>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-slate-50"><tr>
              <th className={th}>{isNe ? 'मिति' : 'Date'}</th><th className={th}>{isNe ? 'प्रकार' : 'Type'}</th><th className={th}>{isNe ? 'पक्ष' : 'Party'}</th>
              <th className={`${th} text-right`}>Gross</th><th className={`${th} text-right`}>%</th><th className={`${th} text-right`}>TDS</th><th className={th}>{isNe ? 'स्थिति' : 'Status'}</th><th></th>
            </tr></thead>
            <tbody className="divide-y divide-slate-100">
              {inFy.length === 0 && <tr><td colSpan={8} className="py-6 text-center text-slate-400">{isNe ? 'यो आ.व. मा TDS दर्ता छैन' : 'No TDS entries this year'}</td></tr>}
              {inFy.map((t) => (
                <tr key={t.id}>
                  <td className={`${tdc} font-mono whitespace-nowrap`}>{t.dateBs}</td>
                  <td className={tdc}>{t.direction === 'DEDUCTED' ? (isNe ? 'कट्टी' : 'Deducted') : (isNe ? 'ग्राहकले काटेको' : 'Suffered')}</td>
                  <td className={tdc}>{t.partyName}<div className="text-[10px] text-slate-500">{t.panNo}</div></td>
                  <td className={`${tdc} ${num}`}>{fmtMoney(t.grossAmount)}</td><td className={`${tdc} ${num}`}>{t.ratePct}</td><td className={`${tdc} ${num} font-bold`}>{fmtMoney(t.tdsAmount)}</td>
                  <td className={tdc}>
                    {t.direction === 'SUFFERED' ? '—' : t.deposited
                      ? <span className="text-emerald-700 font-bold">✔ {t.depositDateBs}</span>
                      : <span className="text-rose-700 font-bold">{isNe ? 'बुझाउन बाँकी' : 'Pending'}</span>}
                  </td>
                  <td className={`${tdc} whitespace-nowrap space-x-1`}>
                    {t.direction === 'DEDUCTED' && !t.deposited && <button type="button" className={btnGhost + ' !py-0.5 !px-2'} onClick={() => setDepositing({ id: t.id, date: getTodayBsString(), ref: '' })}>{isNe ? 'बुझाइयो' : 'Mark deposited'}</button>}
                    <button type="button" className={btnDanger} onClick={() => { if (window.confirm(isNe ? 'मेटाउने?' : 'Delete?')) update((x) => ({ ...x, tds: x.tds.filter((e) => e.id !== t.id) })); }}>✕</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {depositing && (
          <div className="border border-amber-300 bg-amber-50 rounded-xl p-3 grid grid-cols-2 md:grid-cols-4 gap-2 items-end">
            <Field label={isNe ? 'बुझाएको मिति' : 'Deposit date (BS)'}><input className={inputCls} value={depositing.date} onChange={(e) => setDepositing({ ...depositing, date: e.target.value })} /></Field>
            <Field label={isNe ? 'रसिद / सन्दर्भ' : 'Receipt / ref'}><input className={inputCls} value={depositing.ref} onChange={(e) => setDepositing({ ...depositing, ref: e.target.value })} /></Field>
            <div className="flex gap-2 col-span-2">
              <button type="button" className={btnPrimary} onClick={() => {
                const dt = normBs(depositing.date); if (!dt) return;
                update((x) => ({ ...x, tds: x.tds.map((e) => (e.id === depositing.id ? { ...e, deposited: true, depositDateBs: dt, depositRef: depositing.ref.trim() || undefined } : e)) }));
                setDepositing(null);
              }}>{isNe ? 'पुष्टि' : 'Confirm'}</button>
              <button type="button" className={btnGhost} onClick={() => setDepositing(null)}>{isNe ? 'रद्द' : 'Cancel'}</button>
            </div>
          </div>
        )}
        <p className="text-[10px] text-slate-500">
          {isNe ? 'यो रजिस्टर छुट्टै ट्र्याकिङका लागि हो। TDS बुझाएको वा कट्टीको जर्नल चाहिए "जर्नल" ट्याबमा TDS Payable (2201) प्रयोग गरी भौचर बनाउनुहोस्।'
                 : 'This register tracks TDS separately. If you also want ledger entries, post a journal against TDS Payable (2201) in the Journal tab.'}
        </p>
      </Card>
    </div>
  );
};

// ============================================================================
// Income tax computation
// ============================================================================
const TaxTab: React.FC<{ ctx: Ctx }> = ({ ctx }) => {
  const { isNe, data, update, entries, fy } = ctx;
  const range = fyRange(fy);
  const adj: TaxAdjustments = data.taxAdjust[fy] || { otherAdditions: 0, otherDeductions: 0, lossBroughtForward: 0, advanceTaxPaid: 0 };
  const setAdj = (patch: Partial<TaxAdjustments>) => update((d) => ({ ...d, taxAdjust: { ...d.taxAdjust, [fy]: { ...adj, ...patch } } }));
  const ts = data.taxSettings;

  const calc = useMemo(() => {
    const inc = data.accounts.filter((a) => a.type === 'INCOME').reduce((s, a) => s + accountActivity(a, entries, range.from, range.to), 0);
    const exp = data.accounts.filter((a) => a.type === 'EXPENSE').reduce((s, a) => s + accountActivity(a, entries, range.from, range.to), 0);
    const profit = round2(inc - exp);
    const dep = accountActivity(data.accounts.find((a) => a.id === 'acc-5301') || data.accounts[0], entries, range.from, range.to);
    const accDep = data.accounts.some((a) => a.id === 'acc-5301') ? dep : 0;
    const regDep = round2(data.assets.reduce((s, a) => s + (computeDepreciation(a, fy).find((r) => r.fy === fy)?.dep || 0), 0));
    const taxDep = adj.taxDepreciation !== undefined ? adj.taxDepreciation : regDep;
    const taxable0 = round2(profit + accDep - taxDep + adj.otherAdditions - adj.otherDeductions);
    const afterLoss = round2(Math.max(0, taxable0 - adj.lossBroughtForward));
    const slabRows = ts.payerType === 'INDIVIDUAL' ? computeSlabTax(afterLoss, ts.slabs) : [];
    const rate = ts.payerType === 'COMPANY' ? 25 : ts.payerType === 'SPECIAL_INDUSTRY' ? 20 : ts.customRate;
    const tax = ts.payerType === 'INDIVIDUAL' ? round2(slabRows.reduce((s, r) => s + r.tax, 0)) : round2((afterLoss * rate) / 100);
    const suffered = round2(data.tds.filter((t) => t.direction === 'SUFFERED' && normBs(t.dateBs) >= range.from && normBs(t.dateBs) <= range.to).reduce((s, t) => s + t.tdsAmount, 0));
    const net = round2(tax - suffered - adj.advanceTaxPaid);
    return { inc: round2(inc), exp: round2(exp), profit, accDep, regDep, taxDep, taxable0, afterLoss, slabRows, rate, tax, suffered, net };
  }, [data.accounts, data.assets, data.tds, entries, fy, adj, ts]);

  const row = (label: string, value: React.ReactNode, strong = false) => (
    <tr className={strong ? 'bg-slate-100 font-extrabold' : ''}><td className={tdc}>{label}</td><td className={`${tdc} ${num}`}>{value}</td></tr>
  );

  return (
    <div className="space-y-4">
      <Card title={isNe ? 'करदाताको किसिम' : 'Taxpayer type'}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 items-end">
          <Field label={isNe ? 'किसिम' : 'Type'} className="col-span-2">
            <select className={inputCls} value={ts.payerType} onChange={(e) => update((d) => ({ ...d, taxSettings: { ...d.taxSettings, payerType: e.target.value as any } }))}>
              <option value="COMPANY">{isNe ? 'कम्पनी — सामान्य (२५%)' : 'Company — general (25%)'}</option>
              <option value="SPECIAL_INDUSTRY">{isNe ? 'विशेष उद्योग (२०%)' : 'Special industry (20%)'}</option>
              <option value="INDIVIDUAL">{isNe ? 'व्यक्ति / एकल (स्ल्याब)' : 'Individual / sole proprietor (slabs)'}</option>
              <option value="CUSTOM">{isNe ? 'आफ्नै दर' : 'Custom rate'}</option>
            </select>
          </Field>
          {ts.payerType === 'CUSTOM' && (
            <Field label={isNe ? 'दर %' : 'Rate %'}><input className={inputCls} type="number" step="0.01" value={ts.customRate} onChange={(e) => update((d) => ({ ...d, taxSettings: { ...d.taxSettings, customRate: toNum(e.target.value) } }))} /></Field>
          )}
        </div>
        {ts.payerType === 'INDIVIDUAL' && (
          <div className="space-y-1.5">
            <div className="text-[11px] font-bold text-slate-600">{isNe ? 'कर स्ल्याब (सम्पादन गर्न मिल्छ)' : 'Tax slabs (editable)'}</div>
            {ts.slabs.map((s, i) => (
              <div key={i} className="flex items-center gap-2 text-xs">
                <span className="w-16 text-slate-500">{isNe ? `स्ल्याब ${i + 1}` : `Slab ${i + 1}`}</span>
                {s.width === null
                  ? <span className="w-40 text-slate-600">{isNe ? 'बाँकी सबै आय' : 'Remaining income'}</span>
                  : <input className={`${inputCls} !w-40`} type="number" value={s.width} onChange={(e) => update((d) => ({ ...d, taxSettings: { ...d.taxSettings, slabs: d.taxSettings.slabs.map((x, k) => (k === i ? { ...x, width: toNum(e.target.value) } : x)) } }))} />}
                <input className={`${inputCls} !w-20`} type="number" step="0.1" value={s.rate} onChange={(e) => update((d) => ({ ...d, taxSettings: { ...d.taxSettings, slabs: d.taxSettings.slabs.map((x, k) => (k === i ? { ...x, rate: toNum(e.target.value) } : x)) } }))} />
                <span>%</span>
              </div>
            ))}
          </div>
        )}
        <p className="text-[10px] text-slate-500">{isNe ? 'दर र स्ल्याब सन्दर्भका लागि हुन्; आ.व. अनुसार वित्त ऐन हेरेर मिलाउनुहोस्।' : 'Rates and slabs are reference defaults; adjust per the Finance Act for the year.'}</p>
      </Card>

      <Card title={`${isNe ? 'आयकर गणना — आ.व.' : 'Income Tax Computation — F.Y.'} ${fy}`}
        right={<button type="button" className={btnGhost} onClick={() => downloadCsv(`income-tax-${fy.replace('/', '-')}.csv`, [
          ['Item', 'Amount'], ['Total income', calc.inc], ['Total expenses', calc.exp], ['Accounting profit', calc.profit],
          ['Add: accounting depreciation', calc.accDep], ['Less: tax depreciation', calc.taxDep], ['Other additions', adj.otherAdditions],
          ['Other deductions', adj.otherDeductions], ['Taxable income before loss', calc.taxable0], ['Loss b/f', adj.lossBroughtForward],
          ['Taxable income', calc.afterLoss], ['Income tax', calc.tax], ['TDS suffered', calc.suffered], ['Advance tax paid', adj.advanceTaxPaid], ['Net payable / (refund)', calc.net]
        ])}>CSV</button>}>
        <table className="w-full text-xs">
          <tbody className="divide-y divide-slate-100">
            {row(isNe ? 'कुल आम्दानी' : 'Total income', fmtMoney(calc.inc))}
            {row(isNe ? 'कुल खर्च' : 'Total expenses', fmtMoney(calc.exp))}
            {row(isNe ? 'लेखा अनुसार नाफा / (नोक्सान)' : 'Accounting profit / (loss)', fmtMoney(calc.profit), true)}
            {row(isNe ? 'थप: लेखाको ह्रासकट्टी खर्च' : 'Add: accounting depreciation', fmtMoney(calc.accDep))}
            {row(isNe ? 'घटाउ: कर प्रयोजनको ह्रास' : 'Less: tax depreciation', (
              <input className={`${inputCls} !w-40 text-right`} type="number" step="0.01" value={adj.taxDepreciation !== undefined ? adj.taxDepreciation : calc.regDep}
                onChange={(e) => setAdj({ taxDepreciation: e.target.value === '' ? undefined : toNum(e.target.value) })} />
            ))}
            {row(isNe ? 'थप: अन्य अस्वीकृत खर्च' : 'Add: other disallowed expenses', (
              <input className={`${inputCls} !w-40 text-right`} type="number" step="0.01" value={adj.otherAdditions} onChange={(e) => setAdj({ otherAdditions: toNum(e.target.value) })} />
            ))}
            {row(isNe ? 'घटाउ: अन्य कटौती' : 'Less: other deductions', (
              <input className={`${inputCls} !w-40 text-right`} type="number" step="0.01" value={adj.otherDeductions} onChange={(e) => setAdj({ otherDeductions: toNum(e.target.value) })} />
            ))}
            {row(isNe ? 'करयोग्य आय (नोक्सान घटाउनु अघि)' : 'Taxable income before losses', fmtMoney(calc.taxable0), true)}
            {row(isNe ? 'घटाउ: अघिल्लो वर्षको नोक्सान' : 'Less: loss brought forward', (
              <input className={`${inputCls} !w-40 text-right`} type="number" step="0.01" value={adj.lossBroughtForward} onChange={(e) => setAdj({ lossBroughtForward: toNum(e.target.value) })} />
            ))}
            {row(isNe ? 'करयोग्य आय' : 'Taxable income', fmtMoney(calc.afterLoss), true)}
            {ts.payerType === 'INDIVIDUAL'
              ? calc.slabRows.map((r, i) => row(`${isNe ? 'स्ल्याब' : 'Slab'} ${i + 1}: ${fmtMoney(r.amount)} × ${r.rate}%`, fmtMoney(r.tax)))
              : row(`${isNe ? 'आयकर' : 'Income tax'} @ ${calc.rate}%`, fmtMoney(calc.tax))}
            {row(isNe ? 'कुल आयकर दायित्व' : 'Total income tax', fmtMoney(calc.tax), true)}
            {row(isNe ? 'घटाउ: ग्राहकले काटेको TDS (रजिस्टरबाट)' : 'Less: TDS suffered (from register)', fmtMoney(calc.suffered))}
            {row(isNe ? 'घटाउ: तिरिसकेको अग्रिम कर' : 'Less: advance tax paid', (
              <input className={`${inputCls} !w-40 text-right`} type="number" step="0.01" value={adj.advanceTaxPaid} onChange={(e) => setAdj({ advanceTaxPaid: toNum(e.target.value) })} />
            ))}
            {row(calc.net >= 0 ? (isNe ? 'तिर्न बाँकी कर' : 'Tax payable') : (isNe ? 'फिर्ता / अग्रिम क्रेडिट' : 'Refund / carry-forward credit'), fmtMoney(Math.abs(calc.net)), true)}
          </tbody>
        </table>
        <p className="text-[10px] text-slate-500">
          {isNe ? 'यो अनुमानित गणना हो — अन्तिम कर दाखिला गर्नु अघि लेखा परीक्षक/कर सल्लाहकारसँग पुष्टि गर्नुहोस्।' : 'This is an estimate — confirm with your auditor / tax advisor before filing.'}
        </p>
      </Card>
    </div>
  );
};

// ============================================================================
// Budget vs actual
// ============================================================================
const BudgetTab: React.FC<{ ctx: Ctx }> = ({ ctx }) => {
  const { isNe, data, update, entries, fy } = ctx;
  const [month, setMonth] = useState<number>(-1); // -1 = full year to date
  const rec: BudgetRecord = data.budgets.find((b) => b.fiscalYear === fy) || { fiscalYear: fy, amounts: {} };
  const setAmount = (accId: string, v: number) =>
    update((d) => {
      const others = d.budgets.filter((b) => b.fiscalYear !== fy);
      return { ...d, budgets: [...others, { fiscalYear: fy, amounts: { ...rec.amounts, [accId]: v } }] };
    });
  const copyFromPrev = () => {
    const prevFy = (() => { let p = fy; for (let i = 0; i < 40; i++) { const n = nextFy(p); if (n === fy) return p; p = n; } return ''; })();
    void prevFy;
  };
  void copyFromPrev;

  const range = month < 0 ? fyRange(fy) : fyMonthRange(fy, month);
  const budgetFactor = month < 0 ? 1 : 1 / 12;
  const accounts = data.accounts.filter((a) => (a.type === 'INCOME' || a.type === 'EXPENSE') && a.isActive).sort((a, b) => a.code.localeCompare(b.code));
  const lines = accounts.map((a) => {
    const annual = rec.amounts[a.id] || 0;
    const budget = round2(annual * budgetFactor);
    const actual = accountActivity(a, entries, range.from, range.to);
    const variance = round2(a.type === 'INCOME' ? actual - budget : budget - actual); // positive = favourable
    const pct = budget > 0 ? Math.round((actual / budget) * 1000) / 10 : null;
    return { a, annual, budget, actual, variance, pct };
  });
  const totals = (type: AccountType) => {
    const l = lines.filter((x) => x.a.type === type);
    return { budget: round2(l.reduce((s, x) => s + x.budget, 0)), actual: round2(l.reduce((s, x) => s + x.actual, 0)) };
  };
  const tInc = totals('INCOME'); const tExp = totals('EXPENSE');

  const months = Array.from({ length: 12 }, (_, i) => ({ i, label: fyMonthRange(fy, i).label }));

  return (
    <Card title={`${isNe ? 'बजेट बनाम वास्तविक — आ.व.' : 'Budget vs Actual — F.Y.'} ${fy}`}
      right={
        <div className="flex items-center gap-2 flex-wrap">
          <select className={`${inputCls} !w-auto`} value={month} onChange={(e) => setMonth(parseInt(e.target.value, 10))}>
            <option value={-1}>{isNe ? 'पूरै वर्ष' : 'Full year'}</option>
            {months.map((m) => <option key={m.i} value={m.i}>{m.label}</option>)}
          </select>
          <button type="button" className={btnGhost} onClick={() => downloadCsv(`budget-${fy.replace('/', '-')}.csv`, [
            ['Code', 'Account', 'Annual budget', 'Budget (period)', 'Actual', 'Variance', 'Used %'],
            ...lines.map((x) => [x.a.code, x.a.nameEn, x.annual, x.budget, x.actual, x.variance, x.pct ?? ''])
          ])}>CSV</button>
        </div>
      }>
      <p className="text-[10px] text-slate-500">
        {isNe ? 'वार्षिक बजेट राख्नुहोस्। महिना छान्दा मासिक बजेट = वार्षिक ÷ १२ लिइन्छ। हरियो = अनुकूल, रातो = बजेट नाघेको खर्च / कम आम्दानी।'
               : 'Enter the annual budget. A single month uses annual ÷ 12. Green = favourable, red = over-spend / income shortfall.'}
      </p>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-slate-50"><tr>
            <th className={th}>{isNe ? 'खाता' : 'Account'}</th><th className={`${th} text-right w-36`}>{isNe ? 'वार्षिक बजेट' : 'Annual budget'}</th>
            <th className={`${th} text-right`}>{isNe ? 'अवधिको बजेट' : 'Period budget'}</th><th className={`${th} text-right`}>{isNe ? 'वास्तविक' : 'Actual'}</th>
            <th className={`${th} text-right`}>{isNe ? 'फरक' : 'Variance'}</th><th className={`${th} text-right`}>{isNe ? 'प्रयोग %' : 'Used %'}</th>
          </tr></thead>
          <tbody className="divide-y divide-slate-100">
            {(['INCOME', 'EXPENSE'] as AccountType[]).map((t) => (
              <React.Fragment key={t}>
                <tr className="bg-slate-100"><td colSpan={6} className={`${tdc} font-extrabold`}>{isNe ? typeLabels[t].ne : typeLabels[t].en}</td></tr>
                {lines.filter((x) => x.a.type === t).map((x) => (
                  <tr key={x.a.id}>
                    <td className={tdc}><span className="font-mono font-bold mr-1.5">{x.a.code}</span>{isNe ? x.a.nameNe : x.a.nameEn}</td>
                    <td className="py-1 px-2.5"><input className={`${inputCls} text-right`} type="number" step="0.01" value={x.annual || ''} placeholder="0"
                      onChange={(e) => setAmount(x.a.id, toNum(e.target.value))} /></td>
                    <td className={`${tdc} ${num}`}>{fmtMoney(x.budget)}</td>
                    <td className={`${tdc} ${num}`}>{fmtMoney(x.actual)}</td>
                    <td className={`${tdc} ${num} font-bold ${x.budget === 0 && x.actual === 0 ? 'text-slate-400' : x.variance >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>{fmtMoney(x.variance)}</td>
                    <td className={`${tdc} ${num} ${x.pct !== null && x.pct > 100 && t === 'EXPENSE' ? 'text-rose-700 font-bold' : ''}`}>{x.pct === null ? '—' : `${x.pct}%`}</td>
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
          <tfoot className="bg-slate-100 font-extrabold">
            <tr><td className={tdc}>{isNe ? 'कुल आम्दानी' : 'Total income'}</td><td></td><td className={`${tdc} ${num}`}>{fmtMoney(tInc.budget)}</td><td className={`${tdc} ${num}`}>{fmtMoney(tInc.actual)}</td><td colSpan={2}></td></tr>
            <tr><td className={tdc}>{isNe ? 'कुल खर्च' : 'Total expenses'}</td><td></td><td className={`${tdc} ${num}`}>{fmtMoney(tExp.budget)}</td><td className={`${tdc} ${num}`}>{fmtMoney(tExp.actual)}</td><td colSpan={2}></td></tr>
            <tr><td className={tdc}>{isNe ? 'खुद नाफा' : 'Net'}</td><td></td><td className={`${tdc} ${num}`}>{fmtMoney(tInc.budget - tExp.budget)}</td><td className={`${tdc} ${num}`}>{fmtMoney(tInc.actual - tExp.actual)}</td><td colSpan={2}></td></tr>
          </tfoot>
        </table>
      </div>
    </Card>
  );
};

export default AccountingScreen;
