import React, { useMemo, useState } from 'react';
import { Printer, Download, X, FileText, Loader2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Party } from '../types';
import { printPage } from '../utils/printHelper';
import { downloadElementAsPdf } from '../utils/pdfHelper';
import { bsToAd, adToBs, formatBsDate, getTodayBsString } from '../utils/nepaliCalendar';

interface Props {
  party: Party;
  onClose: () => void;
}

type Kind = 'SALE' | 'RECEIPT' | 'PURCHASE' | 'PAYMENT' | 'SALE_RETURN' | 'PURCH_RETURN';

interface Line {
  id: string;
  dateBs: string;
  kind: Kind;
  ref: string;
  particulars: string;
  dr: number; // party owes us more (Dr)
  cr: number; // party owes us less (Cr)
  taxable?: number;
  nonTaxable?: number;
  vat?: number;
}

const SALES_RETURN_KEY = 'krishiyantra_sales_returns_v1';
const PURCHASE_RETURN_KEY = 'krishiyantra_purchase_returns_v1';

const MONTHS_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTHS_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const norm = (d: string) => (d || '').replace(/\//g, '-').trim();
const round2 = (n: number) => Math.round(n * 100) / 100;

const readJsonList = (key: string): any[] => {
  try {
    const raw = localStorage.getItem(key);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

// BS -> AD that survives invalid days (e.g. 03-32 in a 31-day month)
const safeBsToAd = (bs: string): Date => {
  const parts = norm(bs).split('-').map((x) => parseInt(x, 10));
  if (parts.length !== 3 || parts.some((x) => !Number.isFinite(x))) return new Date();
  for (let day = parts[2]; day >= 28; day--) {
    const candidate = `${parts[0]}-${String(parts[1]).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const ad = bsToAd(candidate);
    if (formatBsDate(adToBs(ad)) === candidate) return ad;
  }
  return bsToAd(norm(bs));
};

const shortEn = (bs: string) => {
  const d = safeBsToAd(bs);
  return `${MONTHS_EN[d.getMonth()]} ${d.getDate()}, ${String(d.getFullYear()).slice(-2)}`;
};

const ordinal = (n: number) => {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
};

const longEn = (bs: string) => {
  const d = safeBsToAd(bs);
  return `${ordinal(d.getDate())} ${MONTHS_FULL[d.getMonth()]} ${d.getFullYear()}`;
};

const fmt = (n: number, dashIfZero = true) => {
  if (dashIfZero && Math.abs(n) < 0.005) return '-';
  return n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const drCr = (n: number) => (Math.abs(n) < 0.005 ? '' : n > 0 ? ' (Dr)' : ' (Cr)');

const fiscalRange = (fy: string) => {
  const start = parseInt('20' + (fy.split('/')[0] || '81').slice(-2), 10);
  return { from: `${start}-04-01`, to: `${start + 1}-03-32` };
};

export const BalanceConfirmationModal: React.FC<Props> = ({ party, onClose }) => {
  const { company, parties, invoices, purchases, partyTransactions, language } = useApp();
  const isNe = language === 'ne';

  const fiscalYears = useMemo(() => {
    const set = new Set<string>([...(company.fiscalYearsList || []), company.fiscalYear].filter(Boolean));
    return Array.from(set).sort();
  }, [company]);

  const initialRange = fiscalRange(company.fiscalYear || '081/82');
  const [fiscalYear, setFiscalYear] = useState(company.fiscalYear || '081/82');
  const [fromBs, setFromBs] = useState(initialRange.from);
  const [toBs, setToBs] = useState(initialRange.to);
  const [letterDateBs, setLetterDateBs] = useState(getTodayBsString());
  const [signatory, setSignatory] = useState('');
  const [includeNonVat, setIncludeNonVat] = useState(true);
  const [showAnnexure, setShowAnnexure] = useState(true);
  const [openingOverride, setOpeningOverride] = useState('');
  const [busy, setBusy] = useState(false);

  const onFiscalChange = (fy: string) => {
    setFiscalYear(fy);
    const r = fiscalRange(fy);
    setFromBs(r.from);
    setToBs(r.to);
  };

  const data = useMemo(() => {
    const cleanName = party.name.trim().toLowerCase();
    const cleanAddr = (party.address || '').trim().toLowerCase();
    const hasSameNamePeers = parties.filter((p) => p.name.trim().toLowerCase() === cleanName).length > 1;
    const isSupplierOnly = (party.partyType || party.type) === 'SUPPLIER';

    const lines: Line[] = [];

    // Sales invoices
    invoices
      .filter((inv) => {
        if (inv.status !== 'ACTIVE') return false;
        if (!includeNonVat && inv.billType !== 'VAT') return false;
        if (inv.partyId) return inv.partyId === party.id;
        if (inv.customerName.trim().toLowerCase() !== cleanName) return false;
        const invAddr = (inv.customerAddress || '').trim().toLowerCase();
        if (hasSameNamePeers || (cleanAddr && invAddr)) return invAddr === cleanAddr;
        return true;
      })
      .forEach((inv) => {
        const isVat = inv.billType === 'VAT';
        lines.push({
          id: `s-${inv.id}`,
          dateBs: norm(inv.dateBs),
          kind: 'SALE',
          ref: inv.invoiceNo,
          particulars: isVat ? 'Sales (VAT Invoice)' : 'Sales (Non-VAT Bill)',
          dr: inv.grandTotal,
          cr: 0,
          taxable: isVat ? inv.taxableAmount : 0,
          nonTaxable: isVat ? inv.exemptAmount : inv.grandTotal,
          vat: isVat ? inv.vatAmount : 0
        });
        const paid =
          inv.amountPaid !== undefined ? inv.amountPaid : inv.paymentMode === 'CREDIT' ? 0 : inv.grandTotal;
        if (paid > 0) {
          lines.push({
            id: `sr-${inv.id}`,
            dateBs: norm(inv.dateBs),
            kind: 'RECEIPT',
            ref: inv.invoiceNo,
            particulars: 'Received against bill',
            dr: 0,
            cr: paid
          });
        }
      });

    // Purchases from this party
    purchases
      .filter((pur) => pur.supplierName.trim().toLowerCase() === cleanName)
      .forEach((pur) => {
        lines.push({
          id: `p-${pur.id}`,
          dateBs: norm(pur.dateBs),
          kind: 'PURCHASE',
          ref: pur.purchaseBillNo,
          particulars: 'Purchase',
          dr: 0,
          cr: pur.grandTotal
        });
        const hasTxn = partyTransactions.some((tx) => tx.referenceNo === pur.purchaseBillNo);
        if (!hasTxn && pur.paymentMode !== 'CREDIT') {
          lines.push({
            id: `pp-${pur.id}`,
            dateBs: norm(pur.dateBs),
            kind: 'PAYMENT',
            ref: pur.purchaseBillNo,
            particulars: 'Paid against purchase bill',
            dr: pur.grandTotal,
            cr: 0
          });
        }
      });

    // Receipts / payments vouchers
    partyTransactions
      .filter((tx) => {
        if (tx.partyId && parties.some((p) => p.id === tx.partyId)) return tx.partyId === party.id;
        if (tx.partyName.trim().toLowerCase() !== cleanName) return false;
        const txAddr = (tx.partyAddress || '').trim().toLowerCase();
        if (hasSameNamePeers || (cleanAddr && txAddr)) return txAddr === cleanAddr;
        return true;
      })
      .forEach((tx) => {
        const isCollection = tx.type === 'COLLECTION_FROM_CUSTOMER';
        lines.push({
          id: `t-${tx.id}`,
          dateBs: norm(tx.dateBs),
          kind: isCollection ? 'RECEIPT' : 'PAYMENT',
          ref: tx.referenceNo || tx.id.slice(-6),
          particulars: isCollection ? 'Receipt' : 'Payment',
          dr: isCollection ? 0 : tx.amount,
          cr: isCollection ? tx.amount : 0
        });
      });

    // Sales returns (credit notes) and purchase returns (debit notes)
    readJsonList(SALES_RETURN_KEY)
      .filter((r) => (r.customerName || '').trim().toLowerCase() === cleanName)
      .forEach((r) => {
        const amt = Number(r.totalReturnAmount) || 0;
        lines.push({
          id: `sret-${r.id}`,
          dateBs: norm(r.dateBs),
          kind: 'SALE_RETURN',
          ref: r.creditNoteNo || r.invoiceNo,
          particulars: 'Sales return (credit note)',
          dr: 0,
          cr: amt
        });
        if (r.refundMode && r.refundMode !== 'CREDIT_ADJUST') {
          lines.push({
            id: `sretp-${r.id}`,
            dateBs: norm(r.dateBs),
            kind: 'PAYMENT',
            ref: r.creditNoteNo || r.invoiceNo,
            particulars: 'Refund paid for sales return',
            dr: amt,
            cr: 0
          });
        }
      });
    readJsonList(PURCHASE_RETURN_KEY)
      .filter((r) => (r.supplierName || '').trim().toLowerCase() === cleanName)
      .forEach((r) => {
        const amt = Number(r.totalReturnAmount) || 0;
        lines.push({
          id: `pret-${r.id}`,
          dateBs: norm(r.dateBs),
          kind: 'PURCH_RETURN',
          ref: r.debitNoteNo || r.purchaseBillNo,
          particulars: 'Purchase return (debit note)',
          dr: amt,
          cr: 0
        });
        if (r.refundMode && r.refundMode !== 'CREDIT_ADJUST') {
          lines.push({
            id: `pretr-${r.id}`,
            dateBs: norm(r.dateBs),
            kind: 'RECEIPT',
            ref: r.debitNoteNo || r.purchaseBillNo,
            particulars: 'Refund received for purchase return',
            dr: 0,
            cr: amt
          });
        }
      });

    lines.sort((a, b) => a.dateBs.localeCompare(b.dateBs));

    const from = norm(fromBs);
    const to = norm(toBs);

    const baseOpening = isSupplierOnly ? -(party.openingBalance || 0) : party.openingBalance || 0;
    const before = lines.filter((l) => l.dateBs < from);
    const inPeriod = lines.filter((l) => l.dateBs >= from && l.dateBs <= to);

    const computedOpening = round2(baseOpening + before.reduce((s, l) => s + l.dr - l.cr, 0));
    const opening = openingOverride.trim() !== '' && Number.isFinite(Number(openingOverride))
      ? Number(openingOverride)
      : computedOpening;

    const sum = (fn: (l: Line) => number, kind?: Kind) =>
      round2(inPeriod.filter((l) => !kind || l.kind === kind).reduce((s, l) => s + fn(l), 0));

    const taxableSales = sum((l) => l.taxable || 0, 'SALE');
    const nonTaxableSales = sum((l) => l.nonTaxable || 0, 'SALE');
    const vatSales = sum((l) => l.vat || 0, 'SALE');
    const salesReturn = sum((l) => l.cr, 'SALE_RETURN');
    const grossSales = sum((l) => l.dr, 'SALE');
    const netSales = round2(grossSales - salesReturn);
    // bill round-off: keeps Taxable - Return + Non-Taxable + VAT equal to Net Sales
    const salesRoundOff = round2(netSales - (taxableSales - salesReturn + nonTaxableSales + vatSales));

    const purchaseTotal = sum((l) => l.cr, 'PURCHASE');
    const purchaseReturn = sum((l) => l.dr, 'PURCH_RETURN');
    const netPurchase = round2(purchaseTotal - purchaseReturn);

    const receipt = sum((l) => l.cr, 'RECEIPT');
    const payment = sum((l) => l.dr, 'PAYMENT');

    const closing = round2(opening + netSales - netPurchase - receipt + payment);

    // Annexure with running balance
    let running = opening;
    const annexure = inPeriod.map((l) => {
      running = round2(running + l.dr - l.cr);
      return { ...l, running };
    });

    return {
      opening,
      computedOpening,
      taxableSales,
      nonTaxableSales,
      vatSales,
      salesReturn,
      netSales,
      salesRoundOff,
      netPurchase,
      receipt,
      payment,
      closing,
      annexure,
      periodHasData: inPeriod.length > 0
    };
  }, [party, parties, invoices, purchases, partyTransactions, fromBs, toBs, includeNonVat, openingOverride]);

  const handlePrint = () => printPage({ mode: 'A4' });

  const handlePdf = async () => {
    setBusy(true);
    await downloadElementAsPdf({
      elementId: 'printable-report',
      fileName: `Balance_Confirmation_${party.name.replace(/\s+/g, '_')}_${fiscalYear.replace('/', '-')}`,
      format: 'a4'
    });
    setBusy(false);
  };

  const row = 'flex justify-between items-baseline border-b border-dotted border-slate-400 py-2';
  const subRow = 'flex justify-between items-baseline border-b border-dotted border-slate-300 py-1.5 pl-6 text-[12px]';

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[96vh] flex flex-col">
        {/* Controls (hidden while printing) */}
        <div className="no-print bg-slate-900 text-white px-4 py-3 shrink-0 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-emerald-400" />
              <h2 className="text-sm font-bold">
                {isNe ? 'ब्यालेन्स कन्फर्मेसन पत्र' : 'Balance Confirmation Letter'} — {party.name}
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handlePdf}
                disabled={busy}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold rounded-lg cursor-pointer disabled:opacity-60"
              >
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                <span>PDF</span>
              </button>
              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>{isNe ? 'प्रिन्ट' : 'Print'}</span>
              </button>
              <button onClick={onClose} className="text-slate-400 hover:text-white p-1 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px]">
            <label className="flex flex-col gap-1">
              <span className="text-slate-400">{isNe ? 'आर्थिक वर्ष' : 'Fiscal Year'}</span>
              <select
                value={fiscalYear}
                onChange={(e) => onFiscalChange(e.target.value)}
                className="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white"
              >
                {fiscalYears.map((fy) => (
                  <option key={fy} value={fy}>{fy}</option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-slate-400">{isNe ? 'देखि (BS)' : 'From (BS)'}</span>
              <input value={fromBs} onChange={(e) => setFromBs(e.target.value)} className="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white font-mono" />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-slate-400">{isNe ? 'सम्म (BS)' : 'To (BS)'}</span>
              <input value={toBs} onChange={(e) => setToBs(e.target.value)} className="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white font-mono" />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-slate-400">{isNe ? 'पत्रको मिति (BS)' : 'Letter Date (BS)'}</span>
              <input value={letterDateBs} onChange={(e) => setLetterDateBs(e.target.value)} className="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white font-mono" />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-slate-400">{isNe ? 'सुरुवाती मौज्दात (बदल्न सकिने)' : 'Opening balance (editable, Dr +)'}</span>
              <input
                value={openingOverride}
                onChange={(e) => setOpeningOverride(e.target.value)}
                placeholder={String(data.computedOpening)}
                className="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white font-mono"
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-slate-400">{isNe ? 'हस्ताक्षरकर्ताको नाम' : 'Signatory name'}</span>
              <input value={signatory} onChange={(e) => setSignatory(e.target.value)} className="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white" />
            </label>
            <label className="flex items-center gap-2 mt-4">
              <input type="checkbox" checked={includeNonVat} onChange={(e) => setIncludeNonVat(e.target.checked)} />
              <span>{isNe ? 'Non-VAT बिल समावेश' : 'Include Non-VAT bills'}</span>
            </label>
            <label className="flex items-center gap-2 mt-4">
              <input type="checkbox" checked={showAnnexure} onChange={(e) => setShowAnnexure(e.target.checked)} />
              <span>{isNe ? 'विस्तृत लेजर (पेज २)' : 'Detailed ledger (page 2)'}</span>
            </label>
          </div>
          {!data.periodHasData && (
            <p className="text-[11px] text-amber-300">
              {isNe ? 'यो अवधिमा यो पार्टीको कुनै कारोबार भेटिएन।' : 'No transactions found for this party in the selected period.'}
            </p>
          )}
        </div>

        {/* Letter */}
        <div className="overflow-y-auto p-4 sm:p-8 flex justify-center bg-slate-100 flex-1">
          <div
            id="printable-report"
            className="w-full max-w-[850px] bg-white shadow-md border border-slate-200 p-8 sm:p-12 text-[13px] text-slate-900 font-sans leading-snug"
          >
            {/* Letterhead + title */}
            <div className="flex justify-between items-start gap-6">
              <div>
                <h1 className="text-lg font-bold">{company.name}</h1>
                {company.address && <p>{company.address}</p>}
                {company.phone && <p>Phone: {company.phone}</p>}
                {company.email && <p>{company.email}</p>}
                {company.panVatNo && <p className="font-semibold">PAN: {company.panVatNo}</p>}
              </div>
              <div className="text-center">
                <h2 className="text-lg font-bold">Balance Confirmation Report</h2>
                <p className="text-[12px] font-semibold mt-1">{shortEn(fromBs)} To {shortEn(toBs)}</p>
                <p className="text-[11px] font-semibold">({norm(fromBs)} To {norm(toBs)})</p>
              </div>
            </div>

            <p className="mt-6">Date: {longEn(letterDateBs)}</p>
            <p className="mt-3">To,</p>
            <p>The Manager</p>
            <div className="grid grid-cols-[70px_1fr] gap-y-1 mt-1">
              <span>Party:</span><span className="font-semibold">{party.name}</span>
              <span>Address:</span><span>{party.address || '-'}</span>
              <span>PAN:</span><span className="font-semibold">{party.panNo || '-'}</span>
            </div>

            <p className="mt-4 font-semibold">
              Subject: TRANSACTION &amp; BALANCE CONFIRMATION LETTER FROM {shortEn(fromBs)} TO {shortEn(toBs)}
            </p>
            <p className="mt-2">Dear Sir/Madam,</p>
            <p className="mt-1">
              With reference to above, we are sending you the following information regarding transaction &amp; balance at the end of {shortEn(toBs)} AD ({norm(toBs)} BS) for your confirmation.
            </p>

            {/* Particulars */}
            <div className="mt-5">
              <div className="flex justify-between bg-slate-800 text-white font-bold px-2 py-1.5">
                <span>Particulars</span><span>Amount</span>
              </div>
              <div className={row}>
                <span className="font-semibold">Opening Balance as on {shortEn(fromBs)}</span>
                <span className="font-mono">{fmt(Math.abs(data.opening))}{drCr(data.opening)}</span>
              </div>
              <div className={row}>
                <span className="font-semibold">Net Purchase</span>
                <span className="font-mono">{fmt(data.netPurchase)}{data.netPurchase ? ' (Cr)' : ''}</span>
              </div>
              <div className={row}>
                <span className="font-semibold">Net Sales</span>
                <span className="font-mono">{fmt(data.netSales)}{data.netSales ? ' (Dr)' : ''}</span>
              </div>
              <div className={subRow}><span>Taxable Sales</span><span className="font-mono mr-40">{fmt(data.taxableSales)}</span></div>
              <div className={subRow}><span>Less: Return</span><span className="font-mono mr-40">{data.salesReturn ? `(${fmt(data.salesReturn)})` : '-'}</span></div>
              <div className={subRow}><span>Non Taxable Sales</span><span className="font-mono mr-40">{fmt(data.nonTaxableSales)}</span></div>
              <div className={subRow}><span>Add: VAT</span><span className="font-mono mr-40">{fmt(data.vatSales)}</span></div>
              {Math.abs(data.salesRoundOff) >= 0.005 && (
                <div className={subRow}><span>Add/Less: Round off</span><span className="font-mono mr-40">{data.salesRoundOff < 0 ? `(${fmt(Math.abs(data.salesRoundOff))})` : fmt(data.salesRoundOff)}</span></div>
              )}
              <div className={row}>
                <span className="font-semibold">Receipt</span>
                <span className="font-mono">{fmt(data.receipt)}{data.receipt ? ' (Cr)' : ''}</span>
              </div>
              <div className={row}>
                <span className="font-semibold">Payment</span>
                <span className="font-mono">{fmt(data.payment)}{data.payment ? ' (Dr)' : ''}</span>
              </div>
              <div className={row}>
                <span className="font-semibold">Journal</span>
                <span className="font-mono">-</span>
              </div>
              <div className="flex justify-between items-baseline border-t-2 border-b border-slate-900 py-2 font-bold">
                <span>Closing Balance as on {shortEn(toBs)}</span>
                <span className="font-mono">{fmt(Math.abs(data.closing), false)}{drCr(data.closing)}</span>
              </div>
            </div>

            <p className="mt-4 text-[12px]">
              Detail ledger confirmation above information has been enclosed herewith. Please send us the received copy with sign &amp; official stamp on this letter within 15 days of its receipt, failing to which the details provided by us will be treated as final confirmed at your end.
            </p>
            <p className="mt-3">Sincerely yours,</p>

            <div className="grid grid-cols-2 gap-8 mt-6">
              <div className="pt-16">
                <div className="border-t border-slate-700 w-48" />
                <p className="mt-1">{signatory || ' '}</p>
                <p className="text-[12px] text-slate-600">{company.name}</p>
              </div>
              <div>
                <p className="text-[12px]">We confirm the Transaction/Balance mentioned above are correct according to our books of accounts.</p>
                <div className="grid grid-cols-[90px_1fr] gap-y-5 mt-6 items-end">
                  <span>Signature:</span><span className="border-b border-slate-700 h-5" />
                  <span>Full Name:</span><span className="border-b border-slate-700 h-5" />
                  <span>Designation:</span><span className="border-b border-slate-700 h-5" />
                  <span>Date:</span><span className="border-b border-slate-700 h-5" />
                </div>
              </div>
            </div>

            <p className="mt-10 text-center text-[11px] font-semibold">
              {showAnnexure ? 'page 1 — detail ledger enclosed' : 'page 1 of 1'}
            </p>

            {/* Annexure: detail ledger */}
            {showAnnexure && (
              <div style={{ pageBreakBefore: 'always' }} className="mt-10">
                <h3 className="text-base font-bold text-center">Detail Ledger — {party.name}</h3>
                <p className="text-center text-[11px] mb-3">{shortEn(fromBs)} To {shortEn(toBs)} ({norm(fromBs)} To {norm(toBs)})</p>
                <table className="w-full text-[11px] border-collapse">
                  <thead>
                    <tr className="bg-slate-800 text-white">
                      <th className="text-left px-1.5 py-1">Date (BS)</th>
                      <th className="text-left px-1.5 py-1">Particulars</th>
                      <th className="text-left px-1.5 py-1">Ref No.</th>
                      <th className="text-right px-1.5 py-1">Debit</th>
                      <th className="text-right px-1.5 py-1">Credit</th>
                      <th className="text-right px-1.5 py-1">Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-300 font-semibold">
                      <td className="px-1.5 py-1" colSpan={5}>Opening Balance</td>
                      <td className="px-1.5 py-1 text-right font-mono">{fmt(Math.abs(data.opening), false)}{drCr(data.opening)}</td>
                    </tr>
                    {data.annexure.map((l) => (
                      <tr key={l.id} className="border-b border-slate-200">
                        <td className="px-1.5 py-1 font-mono whitespace-nowrap">{l.dateBs}</td>
                        <td className="px-1.5 py-1">{l.particulars}</td>
                        <td className="px-1.5 py-1 font-mono">{l.ref}</td>
                        <td className="px-1.5 py-1 text-right font-mono">{l.dr ? fmt(l.dr) : ''}</td>
                        <td className="px-1.5 py-1 text-right font-mono">{l.cr ? fmt(l.cr) : ''}</td>
                        <td className="px-1.5 py-1 text-right font-mono">{fmt(Math.abs(l.running), false)}{drCr(l.running)}</td>
                      </tr>
                    ))}
                    <tr className="border-t-2 border-slate-900 font-bold">
                      <td className="px-1.5 py-1" colSpan={5}>Closing Balance</td>
                      <td className="px-1.5 py-1 text-right font-mono">{fmt(Math.abs(data.closing), false)}{drCr(data.closing)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
