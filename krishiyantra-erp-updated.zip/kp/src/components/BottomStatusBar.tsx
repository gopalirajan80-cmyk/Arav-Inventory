import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Calendar,
  Receipt,
  Wifi,
  WifiOff,
  Smartphone,
  ShieldAlert,
  Mic,
  Languages,
  X,
  Check
} from 'lucide-react';
import {
  getTodayBsString,
  getDateSyncMode
} from '../utils/nepaliCalendar';
import { DateManagementModal } from './DateManagementModal';
import { MobileAuthModal } from './MobileAuthModal';
import { VoiceAssistantModal } from './VoiceAssistantModal';

export const BottomStatusBar: React.FC = () => {
  const {
    isOnline,
    currentAccount,
    language,
    setLanguage,
    activeTab,
    setActiveTab,
    companyAccounts,
    company,
    fiscalYearsList,
    selectFiscalYear,
    isFiscalYearClosed,
    addNewFiscalYear
  } = useApp();

  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'LOGIN' | 'REGISTER' | 'ADMIN_APPROVAL'>('LOGIN');
  const [isVoiceAssistantOpen, setIsVoiceAssistantOpen] = useState(false);
  const [isAddFyModalOpen, setIsAddFyModalOpen] = useState(false);
  const [newFyInput, setNewFyInput] = useState('');

  const isNe = language === 'ne';
  const todayBs = getTodayBsString();
  const pendingApprovalsCount = companyAccounts.filter((a) => a.status === 'PENDING_APPROVAL').length;

  const handleCreateFiscalYear = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFyInput.trim()) return;
    const res = addNewFiscalYear(newFyInput.trim());
    if (res.success) {
      selectFiscalYear(newFyInput.trim());
      setIsAddFyModalOpen(false);
      setNewFyInput('');
    } else {
      alert(res.message);
    }
  };

  return (
    <>
      {/* Bottom Sticky Status & Action Dock */}
      <div className="no-print bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-lg px-2 sm:px-3 py-1.5 flex items-center justify-between gap-2 overflow-x-auto z-20">
        
        {/* Left Side: Device Sync Date Indicator, Online Status & Fiscal Year */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          
          {/* Device-Synchronized Nepali B.S. Date Indicator */}
          <button
            type="button"
            onClick={() => setIsDateModalOpen(true)}
            className="flex items-center gap-1 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 border border-slate-200 px-2 sm:px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-800 transition cursor-pointer shadow-2xs shrink-0"
            title={isNe ? 'कम्प्युटर तथा मोबाइल घडी अनुसार मिति (सच्याउन वा अटो-सिंक हेर्न थिच्नुहोस्)' : 'Computer/Mobile date (Click to edit or sync)'}
          >
            <Calendar className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
            <span className="font-mono font-bold text-slate-900 text-[11px] sm:text-xs">
              {todayBs}
            </span>
            <span
              className={`text-[9px] px-1 py-0.2 rounded font-mono font-bold flex items-center gap-0.5 ${
                getDateSyncMode() === 'MANUAL'
                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                  : 'bg-emerald-100/80 text-emerald-800 border border-emerald-300'
              }`}
            >
              {getDateSyncMode() === 'MANUAL' ? '✏️ म्यानुअल' : '💻📱 अटो'}
            </span>
          </button>

          {/* Online / Offline Syncing Status Indicator Badge */}
          <div
            title={
              isOnline
                ? (isNe ? 'अनलाइन मोड: सबै डाटा स्वतः सिंक भइरहेको छ' : 'Online Mode: Live data syncing active')
                : (isNe ? 'अफलाइन मोड: डाटा लोकल डिभाइसमा सुरक्षित छ' : 'Offline Mode: Local-only storage active')
            }
            className={`flex items-center gap-1 sm:gap-1.5 px-2 py-1 rounded-lg border text-xs font-semibold transition-all select-none shadow-2xs shrink-0 ${
              isOnline
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-amber-50 text-amber-900 border-amber-200'
            }`}
          >
            <span className="relative flex h-2 w-2">
              <span
                className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  isOnline ? 'bg-emerald-400' : 'bg-amber-400'
                }`}
              />
              <span
                className={`relative inline-flex rounded-full h-2 w-2 ${
                  isOnline ? 'bg-emerald-600' : 'bg-amber-600'
                }`}
              />
            </span>
            {isOnline ? (
              <Wifi className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            ) : (
              <WifiOff className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            )}
            <span className="hidden sm:inline font-mono text-[11px]">
              {isOnline
                ? (isNe ? 'अनलाइन' : 'Online')
                : (isNe ? 'अफलाइन' : 'Offline')}
            </span>
          </div>

          {/* Fiscal Year (आर्थिक वर्ष) Dropdown Selector & Quick Add - moved from top */}
          <div className="flex items-center gap-1 bg-amber-50/90 border border-amber-300 text-amber-950 rounded-lg px-2 py-0.5 text-xs font-bold shrink-0">
            <span className="text-[10px] text-amber-700 hidden sm:inline">आ.व.</span>
            <select
              value={company.fiscalYear || '081/82'}
              onChange={(e) => {
                if (e.target.value === '__ADD_NEW_FY__') {
                  setNewFyInput('');
                  setIsAddFyModalOpen(true);
                } else {
                  const r = selectFiscalYear(e.target.value);
                  if (!r.success && !r.needsCode) window.alert(r.message);
                }
              }}
              className="bg-transparent font-mono font-extrabold text-amber-950 cursor-pointer focus:outline-none text-xs"
              title={isNe ? 'आर्थिक वर्ष छान्नुहोस् वा नयाँ थप्नुहोस्' : 'Select Fiscal Year or Add New'}
            >
              {fiscalYearsList.map((fy) => (
                <option key={fy} value={fy} className="bg-white text-slate-900 font-bold">
                  📅 {isFiscalYearClosed(fy) ? '🔒 ' : ''}{fy}
                </option>
              ))}
              <option value="__ADD_NEW_FY__" className="bg-emerald-50 text-emerald-900 font-black">
                ➕ नयाँ थप्ने...
              </option>
            </select>
          </div>

        </div>

        {/* Right Side: Quick Bill, Voice Assistant, Language Toggle, User Account Switcher */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          
          {/* Quick Create Bill Button */}
          {activeTab !== 'billing' && (
            <button
              onClick={() => setActiveTab('billing')}
              className="flex items-center gap-1 px-2.5 sm:px-3 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-xs transition cursor-pointer shrink-0"
              title={isNe ? 'नयाँ बिल बनाउनुहोस्' : 'Create New Bill'}
            >
              <Receipt className="w-3.5 h-3.5 text-emerald-100" />
              <span className="text-[11px] sm:text-xs">{isNe ? 'नयाँ बिल' : 'New Bill'}</span>
            </button>
          )}

          {/* Voice Assistant / Commander Button - moved from top */}
          <button
            type="button"
            onClick={() => setIsVoiceAssistantOpen(true)}
            className="flex items-center justify-center p-1.5 sm:px-2 sm:py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-xs transition cursor-pointer border border-emerald-600/40 shrink-0"
            title={isNe ? 'आवाजबाट चलाउनुहोस् (Voice Command)' : 'Voice Command'}
          >
            <Mic className="w-3.5 h-3.5 text-emerald-200 animate-pulse" />
            <span className="hidden md:inline ml-1">{isNe ? 'आवाज' : 'Voice'}</span>
          </button>

          {/* Language Toggle - moved from top */}
          <button
            type="button"
            onClick={() => setLanguage(language === 'ne' ? 'en' : 'ne')}
            title="Toggle Nepali / English"
            className="flex items-center gap-1 px-2 py-1 text-xs font-semibold rounded-lg border border-slate-200 text-slate-700 bg-white hover:bg-slate-50 transition cursor-pointer shrink-0"
          >
            <Languages className="w-3.5 h-3.5 text-emerald-600" />
            <span className="font-mono text-[11px]">{isNe ? 'EN' : 'ने'}</span>
          </button>

          {/* Pending Approval Badge (for Admin) */}
          {pendingApprovalsCount > 0 && (
            <button
              onClick={() => {
                setAuthModalTab('ADMIN_APPROVAL');
                setIsAuthModalOpen(true);
              }}
              title={isNe ? `${pendingApprovalsCount} नयाँ कम्पनी स्वीकृतिको पर्खाइमा छ` : `${pendingApprovalsCount} company pending approval`}
              className="flex items-center gap-1 px-2 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-bold transition shadow-xs cursor-pointer animate-pulse shrink-0"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span className="bg-white text-amber-900 rounded-full px-1 text-[10px] font-black">
                {pendingApprovalsCount}
              </span>
            </button>
          )}

          {/* Mobile Login ID & Logged-in User Name Switcher */}
          <button
            onClick={() => {
              setAuthModalTab('LOGIN');
              setIsAuthModalOpen(true);
            }}
            title={isNe ? 'लग-इन प्रयोगकर्ता र मोबाइल नम्बर (फेरबदल गर्न थिच्नुहोस्)' : 'Logged-in User & Mobile (Click to switch)'}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 text-emerald-950 text-xs font-bold transition cursor-pointer shadow-2xs max-w-[170px] sm:max-w-[220px] shrink-0"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
            <span className="text-[11px] text-emerald-900 font-bold truncate">
              {currentAccount ? `👤 ${currentAccount.ownerName}` : (isNe ? 'लग-इन' : 'Login')}
            </span>
          </button>

        </div>

      </div>

      {/* Date Management Modal */}
      <DateManagementModal
        isOpen={isDateModalOpen}
        onClose={() => setIsDateModalOpen(false)}
      />

      {/* Mobile Auth Modal */}
      <MobileAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialTab={authModalTab}
      />

      {/* Voice Assistant Modal */}
      <VoiceAssistantModal
        isOpen={isVoiceAssistantOpen}
        onClose={() => setIsVoiceAssistantOpen(false)}
      />

      {/* Add New Fiscal Year Modal */}
      {isAddFyModalOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-amber-600" />
                <h3 className="font-extrabold text-sm text-slate-900">
                  {isNe ? 'नयाँ आर्थिक वर्ष थप्नुहोस् (Add Fiscal Year)' : 'Add New Fiscal Year'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddFyModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateFiscalYear} className="space-y-4">
              <p className="text-xs text-slate-600">
                {isNe
                  ? 'नयाँ आर्थिक वर्षको नाम टाइप गर्नुहोस् (जस्तै: 082/83, 083/84, वा 084/85):'
                  : 'Type new fiscal year format (e.g. 082/83, 083/84):'}
              </p>

              <input
                type="text"
                value={newFyInput}
                onChange={(e) => setNewFyInput(e.target.value)}
                placeholder="उदा: 082/83"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono font-black text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                autoFocus
              />

              <div className="space-y-1.5">
                <span className="text-[11px] text-slate-500 font-bold">छिटो सुझावहरू (Quick Suggestions):</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {['081/82', '082/83', '083/84', '084/85', '085/86'].map((suggestion) => (
                    <button
                      key={suggestion}
                      type="button"
                      onClick={() => setNewFyInput(suggestion)}
                      className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-950 font-mono font-bold text-xs rounded-lg cursor-pointer"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddFyModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  रद्द गर्नुहोस्
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer flex items-center gap-1.5 shadow-md"
                >
                  <Check className="w-4 h-4" />
                  <span>सुरक्षित गर्नुहोस्</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
