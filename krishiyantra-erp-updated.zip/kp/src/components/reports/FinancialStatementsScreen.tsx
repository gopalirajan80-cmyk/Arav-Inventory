import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { formatCurrency } from '../../utils/nepaliCalendar';

export const FinancialStatementsScreen: React.FC = () => {
  const { invoices, purchases, expenses, parties, bankAccounts, items, company, language } = useApp();
  const isNe = language === 'ne';

  // Basic P&L Calculations (Simplified for now, needs refinement with NFRS standards)
  const stats = useMemo(() => {
    const totalSales = invoices.filter(i => i.status === 'ACTIVE').reduce((s, i) => s + i.grandTotal, 0);
    const totalPurchases = purchases.reduce((s, p) => s + p.grandTotal, 0);
    const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
    
    // Simple COGS = Purchases (This is too simplistic, but a starting point)
    const cogs = totalPurchases;
    const grossProfit = totalSales - cogs;
    const netProfit = grossProfit - totalExpenses;

    return { totalSales, cogs, grossProfit, totalExpenses, netProfit };
  }, [invoices, purchases, expenses]);

  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="text-xl font-bold mb-4">
        {isNe ? 'वित्तीय विवरणहरू (Financial Statements)' : 'Financial Statements'}
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 border rounded">
          <h3 className="font-semibold mb-2">{isNe ? 'नाफा-नोक्सान (P&L)' : 'Profit & Loss'}</h3>
          <p>{isNe ? 'कुल बिक्री' : 'Total Sales'}: {formatCurrency(stats.totalSales)}</p>
          <p>{isNe ? 'खरिद लागत (COGS)' : 'COGS'}: {formatCurrency(stats.cogs)}</p>
          <p className="font-bold">{isNe ? 'कुल नाफा' : 'Gross Profit'}: {formatCurrency(stats.grossProfit)}</p>
          <p>{isNe ? 'कुल खर्च' : 'Total Expenses'}: {formatCurrency(stats.totalExpenses)}</p>
          <p className="font-bold text-lg">{isNe ? 'खुद नाफा' : 'Net Profit'}: {formatCurrency(stats.netProfit)}</p>
        </div>

        <div className="p-4 border rounded">
          <h3 className="font-semibold mb-2">{isNe ? 'वासलात सारांश (Balance Sheet)' : 'Balance Sheet Summary'}</h3>
          <p>{isNe ? 'चालु सम्पत्ति' : 'Current Assets'}: {formatCurrency(bankAccounts.reduce((s, b) => s + b.currentBalance, 0))}</p>
          <p>{isNe ? 'स्टक मूल्य' : 'Stock Valuation'}: {formatCurrency(items.reduce((s, i) => s + (i.purchasePrice * (i.currentStock || 0)), 0))}</p>
        </div>
      </div>
    </div>
  );
};
