export type BillType = 'VAT' | 'NON_VAT';
export type PaymentMode = 'CASH' | 'BANK_FONEPAY' | 'CREDIT' | 'STAFF_SALARY_DEDUCT';
export type UserRole = 'OWNER' | 'ACCOUNTANT' | 'SALESMAN' | 'COUNTER_SALES' | 'SUPERVISOR' | 'STAFF' | 'ADMINISTRATION';
export type Language = 'ne' | 'en';

export type AccountStatus = 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';

export interface CompanyDirectoryEntry {
  id: string;
  name: string;
  panVatNo: string;
  address: string;
  phone: string;
  tagline?: string;
  logoUrl?: string;
  createdAtBs: string;
}

export interface CompanyAccount {
  id: string;
  companyId?: string; // कुन कम्पनीको खाता / कर्मचारी हो (Multi-Company ID)
  mobileNumber: string; // १० अंकको मोबाइल नम्बर e.g. "9855012345"
  companyName: string; // कम्पनी वा पसलको नाम
  ownerName: string; // सञ्चालकको नाम
  panVatNo?: string;
  address?: string;
  status: AccountStatus;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'COMPANY_OWNER' | 'STAFF';
  assignedRole?: UserRole; // एडमिनले स्वीकृत गरेको तोकिएको पद (OWNER | ADMINISTRATION | SUPERVISOR | SALESMAN | STAFF)
  pin?: string;
  registeredDateBs: string;
  approvedDateBs?: string;
  notes?: string;
  allowedTabs?: string[]; // अनुमति प्राप्त ट्याबहरू (Permissions for staff)
}

export interface BankAccount {
  id: string;
  bankName: string; // e.g. "कृषि विकास बैंक (ADBL)" वा "ग्लोबल आइएमई बैंक"
  accountNumber: string; // e.g. "०२१०१०१२३४५६७८९०"
  accountHolder: string;
  branch: string; // e.g. "भरतपुर" वा "काठमाडौँ"
  openingBalance: number; // सुरुवाती मौज्दात रकम (Opening Balance)
  currentBalance: number; // हालको वास्तविक बैंक मौज्दात (Live Current Balance)
  qrCodeUrl?: string; // बैंकको आधिकारिक QR कोड फोटो (Uploaded Bank QR Image DataURL)
}

export interface BranchOffice {
  id: string;
  code: string; // e.g. "BR-01", "BR-KTM"
  name: string; // e.g. "मुख्य शाखा - भरतपुर (Head Office)", "काठमाडौँ शाखा (तीनकुने)"
  address: string;
  phone: string;
  email?: string;
  managerName: string; // शाखा प्रमुख / म्यानेजरको नाम
  managerMobile: string; // शाखा प्रमुखको लग-इन मोबाइल नं
  managerPin: string; // शाखा प्रमुखको लग-इन पिन
  isMainBranch?: boolean;
  status: 'ACTIVE' | 'LOCKED' | 'INACTIVE'; // एडमिन/ओनरले शाखा चालु वा लक गर्ने अवस्था
  billPrefix?: string; // e.g. "BHR", "KTM"
  dailyExpenseLimit?: number; // दैनिक खर्च सीमा (Admin control)
  maxDiscountPercent?: number; // अधिकतम छुट % सीमा (Admin control)
  permissions: {
    allowSalesBilling: boolean; // बिक्री बिल काट्न पाउने
    allowPurchaseEntry: boolean; // खरिद दर्ता गर्न पाउने
    allowCreditSales: boolean; // उधारो बिक्री दिन पाउने
    allowDiscount: boolean; // छुट (Discount) दिन पाउने
    allowStockTransfer: boolean; // स्टक थपघट / ट्रान्सफर गर्न पाउने
    allowExpenseVoucher: boolean; // खर्च भौचर काट्न पाउने
    allowDeleteOrEdit: boolean; // बिल वा डाटा सच्याउन/मेटाउन पाउने
    allowedTabs: string[]; // शाखाले चलाउन पाउने मोड्युलहरू
  };
  createdAtBs: string;
}

export interface CompanyProfile {
  id?: string; // Multi-company identifier
  name: string;
  logoUrl?: string; // कम्पनीको आधिकारिक लोगो (Company Logo DataURL / URL)
  panVatNo: string;
  address: string;
  phone: string;
  email?: string;
  tagline: string;
  vatBillPrefix: string; // e.g. "TI"
  nonVatBillPrefix: string; // e.g. "NV"
  fiscalYear: string; // e.g. "081/82"
  closedFiscalYears?: string[]; // bandha bhayeka arthik barsha (feri sakriya garna code chahincha)
  fiscalReopenCode?: string; // bandha barsha feri sakriya garne code
  fiscalYearsList?: string[]; // उपलब्ध वा थपिएका आर्थिक वर्षहरूको सूची e.g. ["080/81", "081/82", "082/83"]
  bankAccounts: BankAccount[];
  branches?: BranchOffice[]; // कम्पनीका शाखाहरू (Branches controlled by Admin/Owner)
  activeBranchId?: string; // हाल छानिएको सक्रिय शाखा (Active Branch ID)
  invoiceFooterNote?: string; // बिलको मुनि देखिने सन्देश (Footer Note)
  invoiceTerms?: string; // सर्त तथा नियमहरू (Terms & Conditions)
  defaultDueDays?: number; // रकम बुझाउने सामान्य म्याद (दिन)
  defaultPrintFormat?: 'A4' | 'THERMAL_80MM' | 'THERMAL_58MM'; // प्रिन्ट ढाँचा
  showQrOnInvoice?: boolean; // बिलमा बैंक QR कोड देखाउने
  deductStockOnNonVat?: boolean; // Non-VAT बिक्रीमा गोदाम स्टक घटाउने
  ownerPin?: string; // मालिकको सुरक्षा पिन (Master Owner PIN)
  customCategories?: { id: string; labelNe: string; labelEn: string }[];
  productCategories?: { id: string; labelNe: string; labelEn: string }[]; // मास्टर सेटिङबाट मिलाइने सामानको क्याटगोरी (Product Categories)
  inventoryPrimaryUnits?: { id: string; code: string; labelNe: string; labelEn: string }[]; // मास्टर सेटिङबाट मिलाइने मुख्य एकाइ (Primary Units e.g. 100mtr, 1 Carton, 12pcs, Roll)
  inventorySecondaryUnits?: { id: string; code: string; labelNe: string; labelEn: string }[]; // मास्टर सेटिङबाट मिलाइने द्वितीय एकाइ (Secondary Units e.g. Pcs, Mtr, Ltr, Kg)
  unitConversionPresets?: { id: string; primaryUnit: string; secondaryUnit: string; ratio: number; labelNe: string }[]; // मुख्य = द्वितीय एकाइ रूपान्तरण सूत्रहरू
  staffRoles?: { id: string; titleNe: string; titleEn: string; defaultWageType?: 'MONTHLY' | 'DAILY'; defaultRate?: number }[]; // मास्टर सेटिङबाट मिलाइने कर्मचारी पदहरू (Staff Roles)
  expenseCategories?: { id: string; ne: string; en: string }[]; // मास्टर सेटिङबाट मिलाइने दैनिक खर्च शीर्षकहरू (Expense Categories)
  incomeCategories?: { id: string; ne: string; en: string; incomeType?: 'OTHER_INCOME' | 'LOAN_RECEIVED' }[]; // अन्य आम्दानी तथा ऋण/सापटी शीर्षकहरू (Other Income & Loan Categories)
  // मालिकले तोक्ने हाजिरी समय (Owner Defined Shift Timing):
  shiftStartTime?: string; // बिहानी हाजिरी समय (उदा: "10:00 AM")
  shiftEndTime?: string; // साँझ बिदा समय (उदा: "05:00 PM")
  lateGraceMinutes?: number; // ढिलो आउन पाउने छुट (मिनेट, default 15)
  autoSetShiftTime?: boolean; // स्वतः तोकिएको समय सेट गर्ने
  // मालिकले GPS बाट तोक्ने कार्यस्थल लोकेसन (Owner-Defined Workplace Geofence):
  workplaceLatitude?: number; // कार्यस्थल अक्षांश (Latitude)
  workplaceLongitude?: number; // कार्यस्थल देशान्तर (Longitude)
  workplaceRadiusMeters?: number; // अनुमति प्राप्त परिधि (मिटर, default 200m)
  workplaceLocationLabel?: string; // कार्यस्थलको नाम (उदा: "कृषियन्त्र वर्कसप तथा काउन्टर")
  enforceGpsLocation?: boolean; // GPS परिधिभित्र मात्र हाजिर गर्न पाइने कडा नियम
  attendanceGroups?: AttendanceGroup[]; // मालिकले छुट्याएका हाजिरी समूहहरू र अधिकार प्राप्त सुपरभाइजर
  workCategories?: WorkCategoryConfig[]; // मास्टर सेटिङबाट मिलाइने कामका प्रकारहरू (टनेल बनाउने, प्लास्टिक राख्ने, ट्याक्टर बनाउने, फिटिङ गर्ने, अरुकोमा जाने)
  siteLocationPresets?: string[]; // मास्टर सेटिङबाट मिलाइने साइट / ठाउँ / फिल्ड टिपोटहरूको सूची
  customRoles?: { id: string; titleNe: string; titleEn: string; baseRole: UserRole; permissionsNote?: string }[];
  backupGmail?: string; // कम्पनीको ब्याकअप जिमेल ठेगाना (Company Backup Gmail)
  autoGmailBackup?: boolean;
  lastGmailBackupAt?: string;
  manualBankEntries?: {
    id: string;
    bankAccountId: string;
    bankName: string;
    dateBs: string;
    dateAd: string;
    type: 'DEPOSIT' | 'WITHDRAWAL' | 'INTEREST' | 'BANK_CHARGE';
    amount: number;
    referenceNo?: string;
    particulars: string;
  }[];
  lockDateBs?: string; // वित्तीय अवधि बन्द गर्ने मिति (Financial Period Lock Date)
}

export type ItemCategory = 
  | 'TRACTOR_TILLER' // टिलर, ट्रयाक्टर तथा जोत्ने उपकरण
  | 'IRRIGATION_PUMP' // सिँचाइ, पम्प, पाइप तथा ड्रिप
  | 'SPRAYER_TOOLS' // स्प्रेयर, कटर तथा बाली संरक्षण औजार
  | 'SPARE_PARTS' // रोटाभेटर ब्लेड, बेल्ट तथा स्पेयर पार्ट्स
  | 'SEEDS_AGRO' // प्रमाणित उन्नत बिउबिजन (धान, मकै, तरकारी)
  | 'FERTILIZER' // रासायनिक तथा जैविक मल (युरिया, डीएपी, पोटास)
  | 'PESTICIDES' // किटनाशक, ढुसीनाशक तथा भिटामिन औषधी
  | 'LIVESTOCK_FEED' // पशुपालन, कुखुरा दाना तथा डेरी सामग्री
  | string;

export type ItemType =
  | 'FINISHED_GOODS' // तयार सामग्री / औजार (Finished Goods)
  | 'RAW_MATERIAL' // कच्चा पदार्थ (Raw Material)
  | 'SPARE_PARTS' // स्पेयर पार्ट्स / पार्टपुर्जा (Spare Parts)
  | 'MERCHANDISE_TRADING' // व्यापारिक माल (Trading Merchandise)
  | 'SERVICES_CHARGES'; // सेवा तथा मर्मत चार्ज (Services & Repairs)

export interface Item {
  id: string;
  code: string;
  nameEn: string;
  nameNe: string;
  size?: string; // साइज (Size / Dimension / Specs)
  category: ItemCategory;
  itemType?: ItemType; // सामग्रीको प्रकार
  unit: string; // Pcs, Set, Meter, Litre, Kg, Bag, Roll, Bottle
  primaryUnit?: string; // मुख्य एकाइ (Primary Unit e.g. Roll, Carton, Dozen, 100mtr)
  secondaryUnit?: string; // द्वितीय एकाइ (Secondary Unit e.g. Pcs, Mtr, Ltr, Kg)
  secondaryUnitRatio?: number; // १ मुख्य एकाइ = कति द्वितीय एकाइ (e.g. 100 Mtr per Roll, 12 Pcs per Carton)
  secondaryPurchasePrice?: number; // द्वितीय एकाइको खरिद दर (Rate per Secondary Unit)
  secondarySellingPrice?: number; // द्वितीय एकाइको बिक्री दर (Rate per Secondary Unit)
  hsCode?: string; // HS Code (Harmonized System Code e.g. "8432.10.00")
  hsnCode?: string;
  purchasePrice: number;
  sellingPrice: number;
  openingStock: number; // पुरानो सुरुवाती स्टक (Opening / Historical Stock)
  currentStock: number; // हालको मौज्दात स्टक (in Primary Unit)
  vatStock?: number; // भ्याट बिलका लागि मौज्दात
  nonVatStock?: number; // नन-भ्याट बिलका लागि मौज्दात
  minStockAlert: number;
  isVatExempt: boolean; // True for subsidized ag produce/seeds/fertilizers
  imageUrl?: string; // मोबाइल क्यामेराबाट खिचिएको वा अपलोड गरिएको फोटो
}

export interface InvoiceItem {
  itemId: string;
  code: string;
  name: string;
  size?: string; // साइज (Size)
  unit: string;
  unitMode?: 'PRIMARY' | 'SECONDARY'; // मुख्य एकाइ वा द्वितीय एकाइमा कारोबार
  primaryQtyEquivalent?: number; // स्टक मिलानका लागि मुख्य एकाइ बराबरको परिमाण
  hsCode?: string; // HS Code in invoice line item
  quantity: number;
  rate: number;
  amount: number;
  isVatExempt: boolean;
  discountPercent?: number;
  vatAmount?: number;
}

export interface Invoice {
  id: string;
  billType: BillType;
  invoiceNo: string; // e.g. TI-081/82-0001 or NV-081/82-0001
  seriesNumber: number;
  fiscalYear: string;
  dateBs: string; // YYYY-MM-DD in Bikram Sambat (बिल/कारोबार मिति — म्यानुअल सच्याउन सकिने)
  dateAd: string; // YYYY-MM-DD
  entryDateBs?: string; // सिस्टममा वास्तविक रूपमा प्रविष्टि गरेको मिति (बिल मिति फरक/पछिल्लो भए पनि यो सधैं आजको वास्तविक मिति हो)
  time: string;
  
  customerName: string;
  customerPan?: string;
  customerAddress?: string;
  customerPhone?: string;
  partyId?: string;

  // Staff / Employee Purchase Link
  isEmployeePurchase?: boolean;
  employeeId?: string;
  employeeName?: string;

  // Previous Balance & Current Due Breakdown (पुरानो लिन बाँकी, आज बुझाएको, र हालसम्म बाँकी)
  previousDue?: number;
  netTotalDue?: number;
  amountPaid?: number; // आज बुझाएको रकम (नगद/बैंक)
  remainingDue?: number; // हालसम्म बाँकी रकम (Previous Due + Bill - Paid)
  paymentDueDate?: string; // रकम बुझाउने अन्तिम म्याद (Payment Due Date, e.g. 2081/11/30)
  
  items: InvoiceItem[];
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  freightCharge: number;
  
  taxableAmount: number;
  exemptAmount: number;
  vatAmount: number; // 13%
  grandTotal: number;
  
  paymentMode: PaymentMode;

  // Bank & Account Deposit / Transfer Details
  bankName?: string; // जम्मा वा ट्रान्सफर भएको बैंकको नाम
  bankAccountNo?: string; // बैंक खाता नम्बर
  transactionRef?: string; // FonePay / Cheque / Bank Ref No.

  // Attached Photo / Delivery Slip (मोबाइलबाट खिचिएको फोटो वा बिलको प्रमाण)
  photoUrl?: string;

  notes?: string;
  stockDeducted?: boolean; // यो बिलले गोदाम स्टक घटाएको थियो कि थिएन (सच्याउँदा सही उल्टाउन)
  editCount?: number; // बिल कति पटक सच्याइयो
  lastEditedAtBs?: string; // पछिल्लो सच्याएको मिति
  lastEditedBy?: string; // पछिल्लो पटक सच्याउने व्यक्ति
  status: 'ACTIVE' | 'CANCELLED';
  createdRole: UserRole;
  billedBy?: string; // बिल तयार गर्ने व्यक्तिको नाम (Cashier / Biller Name)
  billedByMobile?: string; // बिलिङ गर्नेको मोबाइल नम्बर
  billedByRole?: string; // बिलिङ गर्नेको पद
}

export type RecurringFrequency = 'WEEKLY' | 'MONTHLY' | 'QUARTERLY';

export interface RecurringInvoice {
  id: string;
  partyId: string;
  customerName: string;
  frequency: RecurringFrequency;
  lastGeneratedDateBs: string;
  nextRunDateBs: string;
  billType: BillType;
  items: InvoiceItem[];
  notes?: string;
}

export interface PurchaseRecord {
  id: string;
  purchaseBillNo: string;
  supplierName: string;
  supplierPan: string;
  dateBs: string; // खरिद/बिल मिति (म्यानुअल सच्याउन सकिने)
  dateAd: string;
  entryDateBs?: string; // सिस्टममा वास्तविक रूपमा प्रविष्टि गरेको मिति
  itemsSummary: string;
  items?: InvoiceItem[]; // क्रमसंख्या अनुसार प्रिन्ट गर्न चाहिने विस्तृत सामान सूची (सेल्स बिल जस्तै)
  hsCode?: string; // HS Code
  taxableAmount: number;
  exemptAmount: number;
  vatAmount: number; // 13%
  grandTotal: number;
  paymentMode: PaymentMode;
  bankAccountId?: string;
  bankName?: string;
  bankAccountNo?: string;
}

export type PartyType = 'CUSTOMER' | 'SUPPLIER' | 'BOTH';
export type CustomerCategory = 'RETAIL' | 'WHOLESALE' | 'GOVERNMENT' | 'OTHER';

export interface Party {
  id: string;
  name: string;
  panNo?: string;
  address?: string;
  phone?: string;
  partyType?: PartyType;
  type?: PartyType;
  customerCategory?: CustomerCategory;
  openingBalance: number; // पुरानो लिन बाँकी / कुल बक्यौता (Total / Opening Due Amount)
  paidAmount?: number; // बुझाएको / असुल भएको रकम (Pay Amount)
  currentBalance: number; // हालको कुल लिन बाँकी / तिर्न बाँकी रकम (Live Net Outstanding)
}

export interface PartyTransaction {
  id: string;
  partyId: string;
  partyName: string;
  partyAddress?: string;
  partyPhone?: string;
  dateBs: string;
  dateAd: string;
  type: 'PAYMENT_TO_SUPPLIER' | 'COLLECTION_FROM_CUSTOMER'; // आपूर्तिकर्तालाई भुक्तानी वा ग्राहकबाट असुली / आम्दानी
  incomeType?: 'CUSTOMER_COLLECTION' | 'OTHER_INCOME' | 'LOAN_RECEIVED'; // ग्राहक असुली, अन्य आम्दानी वा ऋण/सापटी प्राप्त
  incomeCategory?: string; // अन्य आम्दानी वा ऋणको शीर्षक (उदा: मर्मत सेवा, भाडा आम्दानी, बैंक ऋण, व्यक्तिगत सापटी)
  amount: number;
  paymentMode: 'CASH' | 'BANK';
  bankAccountId?: string;
  bankName?: string;
  bankAccountNo?: string;
  referenceNo?: string;
  notes?: string;
  /** खरिद बिल बनाउँदा सिस्टमले स्वतः राखेको भुक्तानी रेकर्ड (भौचर होइन — भौचर सूचीमा नदेखिने) */
  autoFromPurchase?: boolean;
}

export interface Employee {
  id: string;
  name: string;
  role: string;
  phone: string;
  salaryMonthly: number;
  wageType?: 'MONTHLY' | 'DAILY'; // भुक्तानीको प्रकार: 'MONTHLY' (मासिक तलब) वा 'DAILY' (दैनिक ज्याला/हिसाब)
  dailyWageRate?: number; // दैनिक ज्याला दर (उदा: रु. ८००, १०००, १५००)
  joinedDateBs: string;
  openingDue: number; // सुरुवाती पुरानो लिन बाँकी / पेस्की (Opening advance balance)
  groupId?: string; // सम्बन्धित हाजिरी समूह (Group ID)
  groupName?: string; // समूहको नाम (उदा: वर्कसप समूह, काउन्टर समूह)
  isGroupSupervisor?: boolean; // हाजिरी प्रमाणित गर्ने अधिकार प्राप्त सुपरभाइजर (Authority)
  supervisorAuthPin?: string; // सुपरभाइजर प्रमाणीकरण पिन (PIN)
  registeredPhotoUrl?: string; // पहिले नै दर्ता गरिएको फोटो / अनुहार (Registered Reference Photo)
  fingerprintEnrolled?: boolean; // बायोमेट्रिक फिंगरप्रिन्ट पहिले दर्ता गरिएको छ/छैन
  fingerprintHash?: string; // दर्ता गरिएको फिंगरप्रिन्ट टोकन / आईडी
  enrolledFingerName?: string; // दर्ता गरिएको औँला (उदा: दायाँ चोरी औँला - Right Index)
  fingerprintEnrolledDateBs?: string; // फिंगरप्रिन्ट दर्ता गरिएको मिति
  staffCode?: string; // कर्मचारीको आइडी कोड (उदा: EMP-001)
  loginMobile?: string; // लगइन आईडी / मोबाइल नम्बर
  loginPin?: string; // कर्मचारीको लगइन पिन
  systemRole?: UserRole; // प्रणाली अधिकार भूमिका
  approvalStatus?: AccountStatus; // स्वीकृत अवस्था (APPROVED / PENDING_APPROVAL / REJECTED)
  allowedTabs?: string[]; // अनुमति प्राप्त ट्याबहरू (Permissions: e.g. ['billing', 'inventory'])
}

export interface AttendanceGroup {
  id: string;
  nameNe: string;
  nameEn: string;
  supervisorEmpId?: string; // अधिकार प्राप्त समूह प्रमुख
  supervisorName?: string;
  color?: string;
}

export interface EmployeeLedgerEntry {
  id: string;
  employeeId: string;
  dateBs: string;
  dateAd: string;
  type: 'PURCHASE_DEDUCTION' | 'CASH_ADVANCE' | 'SALARY_PAYMENT';
  amount: number;
  wageType?: 'MONTHLY' | 'DAILY';
  daysWorked?: number; // दैनिक हिसाबमा भुक्तानी गरिएको दिन सङ्ख्या
  paymentMode?: 'CASH' | 'BANK';
  bankAccountId?: string;
  bankName?: string;
  referenceBillNo?: string;
  notes: string;
}

export type StaffWorkCategory =
  | 'TUNNEL_MAKING' // टनेल बनाउने
  | 'PLASTIC_LAYING' // प्लास्टिक राख्ने
  | 'TRACTOR_WORK' // ट्याक्टर बनाउने / मर्मत
  | 'FITTING_WORK' // फिटिङ गर्ने
  | 'CLIENT_SITE_VISIT' // अरुकोमा जाने / फिल्ड काम
  | 'WORKSHOP_REGULAR' // वर्कसप / पसल नियमित काम
  | 'OTHER_WORK' // अन्य काम
  | string;

export interface WorkCategoryConfig {
  id: StaffWorkCategory;
  labelNe: string;
  labelEn: string;
  shortNe: string;
  badgeClass: string;
  isFieldWork?: boolean;
  defaultSiteNote?: string;
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  dateBs: string;
  dateAd: string;
  checkInTime: string;
  checkOutTime?: string;
  latitude?: number;
  longitude?: number;
  locationLabel?: string;
  workCategory?: StaffWorkCategory; // के काम गरेको (टनेल, प्लास्टिक, ट्याक्टर, फिटिङ, अरुकोमा जाने)
  workDescription?: string; // कामको विवरण (उदा: टनेल बनाउने, प्लास्टिक राख्ने)
  siteOrClientName?: string; // कसकोमा / कुन ठाउँमा काम गरेको
  photoUrl?: string;
  status: 'PRESENT' | 'ABSENT' | 'HALF_DAY' | 'LEAVE';
  verificationMethod?: 'FINGERPRINT' | 'FACE_PHOTO' | 'MANUAL_SUPERVISOR' | 'GPS_AUTO';
  isOffline?: boolean; // अफलाइन हाजिरी भएको संकेत
  syncedAt?: string; // अनलाइन सिंक भएको समय
  deviceType?: 'MOBILE' | 'DESKTOP' | 'SUPERVISOR';
  isLate?: boolean; // ढिलो आगमन
  isApproved?: boolean; // Admin/Owner approval status
}

export interface DailyCashRecord {
  id: string;
  dateBs: string;
  openingCash: number; // काउन्टर सुरु गर्दाको नगद
  totalCashSales: number; // आजको नगद बिक्री
  totalBankTransfers: number; // आज बैंकमा जम्मा भएको
  totalAdvancesGiven: number; // कर्मचारीलाई दिएको पेस्की
  closingCashInHand: number; // दिनको अन्त्यमा काउन्टरमा हुनुपर्ने नगद
  notes?: string;
}

// ================= =========================================================
// MANUFACTURING & PRODUCTION LIFECYCLE (म्यानुफ्याक्चरिङ तथा उत्पादन चक्र)
// =========================================================================

export interface RawMaterial {
  id: string;
  code: string;
  nameNe: string;
  nameEn: string;
  category: string; // e.g. 'STEEL_METALS' | 'ENGINES' | 'PLASTIC_PACK' | 'HARDWARE_PARTS'
  unit: string; // Kg, Meter, Sheet, Pc, Litre, Roll
  currentStock: number;
  unitCostPrice: number;
  minStockAlert: number;
  supplierName?: string;
  lastPurchasedDateBs?: string;
}

export type ProductionStage = 'IN_MACHINE_WIP' | 'FINISHED_GOODS' | 'PACKAGING' | 'DISPATCHED_MARKET';

export interface RawMaterialUsage {
  materialId: string;
  materialName: string;
  quantityUsed: number;
  unit: string;
  costPerUnit: number;
  totalCost?: number;
}

export interface DispatchItem {
  id: string;
  sn: number;
  itemId?: string;
  particular: string;
  hsCode?: string; // HS Code
  qty: number;
  rate: number;
  total: number;
}

export interface DispatchRecord {
  id: string;
  challanNo: string;
  type: 'PURCHASE' | 'SALES' | 'MANUFACTURE';
  dealerName: string;
  partyId?: string;
  address?: string;
  phone?: string;
  items: DispatchItem[];
  dispatchedQuantity: number;
  dispatchDateBs: string;
  vehicleNo?: string; // गाडी नम्बर
  driverName?: string; // चालकको नाम
  driverPhone?: string; // चालकको सम्पर्क
  freightPaid?: number; // गाडी भाडा (Agreed Freight)
  driverAdvance?: number; // ड्राइभर पेस्की (Driver Advance)
  balanceAmountPaid?: number; // भुक्तानी गरिएको बाँकी भाडा (Final Balance Paid)
  purchaseAmount?: number; // खरिद रकम (Purchase Amount)
  salesAmount?: number; // बिक्री रकम (Sales Amount)
  notes?: string;
  status: 'IN_TRANSIT' | 'DELIVERED';
  isApproved?: boolean; // स्वीकृत भएको छ/छैन
  approvedBy?: string; // स्वीकृत गर्ने व्यक्तिको नाम
  approvedDateBs?: string; // स्वीकृत मिति
}

export interface ProductionBatch {
  id: string;
  batchNumber: string; // e.g. BATCH-2081-001
  productNameNe: string;
  productNameEn: string;
  stage: ProductionStage;
  targetQuantity: number;

  // Dual Date Tracking (BS & AD)
  productionDateBs: string; // YYYY-MM-DD
  productionDateAd?: string; // YYYY-MM-DD
  manufactureDateBs?: string;
  manufactureDateAd?: string;
  expiryDateBs?: string;
  expiryDateAd?: string;

  // Finished Goods Item Link
  finishedItemId?: string;

  // Input & Output Quantities & Units
  inputQuantity?: number; // Raw material used, total weight
  inputUnit?: string; // Kg, Gm, Quintal, Pcs
  outputQuantity?: number; // Finished product produced
  outputUnit?: string; // Kg, Packet, Pcs

  // Yield % & Wastage % (Auto-calculated: output/input * 100)
  yieldPercent?: number;
  wastagePercent?: number;

  // Cost Breakdown
  rawMaterialCost?: number;
  laborCost?: number;
  electricityCost?: number;
  otherOverheadCost?: number;
  totalProductionCost?: number;
  unitManufacturingCost?: number; // (Raw + Labor + Electricity/Overhead) ÷ outputQuantity
  costPerPacket?: number;

  // Packaging Details
  packetSize?: string; // e.g., 100g, 250g, 500g, 1kg
  packetsProduced?: number;
  packagingType?: string; // e.g., Silver Zipper Pouch, Heavy Crate, Box
  packedQuantity?: number;
  packedDateBs?: string;

  // Food Safety & Quality Tracking
  qualityCheckStatus?: 'PASS' | 'FAIL' | 'PENDING';
  qualityNotes?: string;
  qualityCheckedBy?: string;
  
  // 1. Raw Materials Issued
  rawMaterialsUsed: RawMaterialUsage[];
  
  // 2. Machine Processing (WIP)
  machineId?: string;
  machineName?: string; // e.g. CNC Lathe Machine, Welder Unit, Milling Machine
  operatorName?: string;
  startedDateBs: string;
  startedDateAd?: string;
  
  // 3. Finished Goods
  finishedGoodsQuantity?: number;
  completionDateBs?: string;
  completionDateAd?: string;
  overheadCosts?: { description: string; amount: number }[]; // बिजुली, प्याकेजिङ, ज्याला

  // 5. Market Supply / Dispatched
  dispatches?: DispatchRecord[];
  
  notes?: string;
  status: 'ACTIVE' | 'COMPLETED';

  // --- थप उत्पादन विवरण (Extended manufacturing details) ---
  bomId?: string; // प्रयोग भएको सूत्र (BOM)
  productionOrderId?: string; // जोडिएको उत्पादन आदेश
  fieldOrderIds?: string[]; // यो उत्पादन कुन-कुन फिल्ड अर्डरका लागि हो
  shift?: 'MORNING' | 'DAY' | 'EVENING' | 'NIGHT'; // शिफ्ट
  supervisorName?: string; // सुपरभाइजर
  machineHours?: number; // मेसिन चलेको घण्टा
  plannedQuantity?: number; // योजनाबद्ध परिमाण (लक्ष्य)
  scrapQuantity?: number; // स्क्र्याप / खेर गएको परिमाण
  scrapReason?: string; // खेर जानुको कारण
  qcChecks?: QcCheckResult[]; // गुणस्तर जाँच सूची
  storageLocation?: string; // तयारी सामान राखिएको स्थान / गोदाम
}

export interface QcCheckResult {
  name: string; // जाँच बुँदा (e.g. मोइस्चर, तौल, रङ्ग, प्याकिङ सिल)
  result: 'PASS' | 'FAIL' | 'NA';
  value?: string; // नापेको मान (e.g. 9.5%)
}

// =========================================================================
// FIELD ORDERS (फिल्ड स्टाफले टिप्ने अर्डर)
// =========================================================================

export type FieldOrderStatus =
  | 'DRAFT' // ड्राफ्ट (सेभ गरिएको, पठाइएको छैन)
  | 'SUBMITTED' // अफिसमा पठाइयो
  | 'APPROVED' // स्वीकृत
  | 'IN_PRODUCTION' // उत्पादनमा
  | 'READY' // तयार (डेलिभरीका लागि)
  | 'DISPATCHED' // चलान भयो
  | 'DELIVERED' // डेलिभर भयो
  | 'CANCELLED'; // रद्द

export type FieldOrderPriority = 'NORMAL' | 'URGENT';
export type FieldOrderPayment = 'CASH' | 'CREDIT' | 'ADVANCE';

export interface FieldOrderItem {
  itemId: string;
  code?: string;
  name: string;
  size?: string;
  unit: string;
  qty: number;
  rate: number;
  discountPercent?: number;
  amount: number; // qty x rate - discount
  isVatExempt?: boolean;
  note?: string;
}

export interface FieldOrder {
  id: string;
  orderNo: string; // e.g. FO-2083-0001
  dateBs: string;
  dateAd: string;
  time: string;

  // ग्राहक
  partyId?: string;
  customerName: string;
  customerPhone?: string;
  customerAddress?: string;
  customerPan?: string;
  isNewCustomer?: boolean; // फिल्डमै नयाँ थपिएको ग्राहक

  // स्थान (GPS)
  gpsLat?: number;
  gpsLng?: number;
  gpsAccuracy?: number;

  // अर्डर लिने स्टाफ
  takenBy: string; // नाम
  takenById?: string; // मोबाइल / लगइन ID
  takenByRole?: string;

  items: FieldOrderItem[];
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  grandTotal: number; // VAT बिना अनुमानित जम्मा

  paymentTerm: FieldOrderPayment;
  advanceAmount?: number; // अग्रिम लिएको रकम
  advanceMode?: 'CASH' | 'BANK';
  creditDays?: number; // उधारो अवधि
  expectedDeliveryBs?: string; // ग्राहकलाई चाहिने मिति
  deliveryAddress?: string; // डेलिभरी ठेगाना (फरक भए)
  priority: FieldOrderPriority;
  notes?: string;
  photoUrl?: string; // ग्राहक वा सामानको फोटो

  status: FieldOrderStatus;
  needsProduction?: boolean; // मौज्दात नपुग भएकाले उत्पादन आवश्यक
  approvedBy?: string;
  approvedDateBs?: string;
  cancelReason?: string;
  invoiceId?: string; // बिल बनाएपछि जोडिने
  invoiceNo?: string;
  productionOrderIds?: string[]; // जोडिएका उत्पादन आदेश
  statusHistory?: { status: FieldOrderStatus; dateBs: string; time: string; by: string; note?: string }[];
  updatedAt?: string;
}

// =========================================================================
// QUOTATIONS (कोटेशन / मूल्य प्रस्ताव)
// =========================================================================

export type QuotationStatus = 'DRAFT' | 'SENT' | 'ACCEPTED' | 'REJECTED' | 'CONVERTED';

export interface Quotation {
  id: string;
  quotationNo: string; // e.g. QT-082-83-0001
  dateBs: string;
  dateAd: string;
  validUntilBs?: string; // कोटेशन मान्य हुने अन्तिम मिति
  partyId?: string;
  customerName: string;
  customerPhone?: string;
  customerAddress?: string;
  customerPan?: string;
  subject?: string; // विषय
  items: FieldOrderItem[];
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  billType: BillType; // VAT भए १३% थपिन्छ
  vatAmount: number;
  freightCharge: number;
  grandTotal: number;
  deliveryTerms?: string; // डेलिभरी सर्त
  paymentTerms?: string; // भुक्तानी सर्त
  warrantyNote?: string; // ग्यारेन्टी / वारेन्टी
  notes?: string;
  preparedBy: string;
  preparedById?: string;
  status: QuotationStatus;
  fieldOrderId?: string; // अर्डरमा परिणत भएपछि
  updatedAt?: string;
}

// =========================================================================
// BILL OF MATERIALS & PRODUCTION ORDERS (उत्पादन सूत्र र उत्पादन आदेश)
// =========================================================================

export interface BomLine {
  materialId: string; // RawMaterial.id
  materialName: string;
  unit: string;
  qtyPerBatch: number; // आधार ब्याच (outputQty) का लागि चाहिने परिमाण
  wastagePercent?: number; // यो कच्चा पदार्थको अपेक्षित खेर % (थप चाहिने)
  note?: string;
}

export interface BillOfMaterial {
  id: string;
  code: string; // e.g. BOM-001
  productItemId?: string; // तयारी सामान (Item.id)
  productNameNe: string;
  productNameEn: string;
  outputQty: number; // आधार ब्याचले बनाउने परिमाण (e.g. 100)
  outputUnit: string;
  lines: BomLine[]; // कच्चा पदार्थको सूची
  expectedYieldPercent?: number; // अपेक्षित उपज %
  laborCostPerBatch?: number;
  electricityCostPerBatch?: number;
  otherCostPerBatch?: number;
  machineId?: string; // सामान्यतः प्रयोग हुने मेसिन
  machineName?: string;
  standardHoursPerBatch?: number; // आधार ब्याचको मानक समय
  workersRequired?: number; // चाहिने कामदार संख्या
  packetSize?: string; // प्याकेट साइज
  packagingType?: string;
  shelfLifeDays?: number; // म्याद (दिन)
  qcChecklist?: string[]; // गुणस्तर जाँच बुँदाहरू
  processSteps?: string; // उत्पादन विधि / प्रक्रिया
  notes?: string;
  isActive: boolean;
  createdDateBs?: string;
}

export type ProductionOrderStatus = 'PLANNED' | 'RELEASED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';

export interface ProductionOrder {
  id: string;
  orderNo: string; // e.g. PO-2083-0001
  bomId?: string;
  productItemId?: string;
  productNameNe: string;
  productNameEn?: string;
  quantity: number; // बनाउनुपर्ने परिमाण
  unit: string;
  createdDateBs: string;
  plannedStartBs?: string;
  dueDateBs?: string; // तयार हुनुपर्ने मिति
  priority: FieldOrderPriority;
  fieldOrderIds: string[]; // कुन फिल्ड अर्डरका लागि
  machineId?: string;
  machineName?: string;
  supervisorName?: string;
  status: ProductionOrderStatus;
  batchId?: string; // आदेश जारी गर्दा बनेको ब्याच
  batchNumber?: string;
  notes?: string;
  createdBy?: string;
}

// =========================================================================
// SUPER ADMIN AUDIT TRAIL (सुरक्षा अडिट ट्रेल तथा कार्य ट्र्याकिङ)
// =========================================================================

export type AuditActionType =
  | 'INVOICE_CREATED'
  | 'INVOICE_CANCELLED'
  | 'INVOICE_EDITED'
  | 'INVOICE_DELETED'
  | 'INVENTORY_ADDED'
  | 'INVENTORY_UPDATED'
  | 'INVENTORY_DELETED'
  | 'STOCK_ADJUSTED'
  | 'STOCK_RECONCILED'
  | 'PURCHASE_RECORDED'
  | 'PURCHASE_DELETED'
  | 'PAYMENT_COLLECTION'
  | 'SUPPLIER_PAYMENT'
  | 'USER_LOGIN'
  | 'ACCOUNT_APPROVED'
  | 'ACCOUNT_REJECTED'
  | 'SETTINGS_UPDATED'
  | 'EXPENSE_RECORDED';

export interface Expense {
  id: string;
  voucherNo?: string;
  dateBs: string;
  amount: number;
  category: string;
  paidTo?: string;
  description: string;
  paymentMode: 'CASH' | 'BANK';
  bankAccountId?: string;
  bankName?: string;
  notes?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  dateBs: string;
  dateAd: string;
  actionType: AuditActionType;
  module: 'BILLING' | 'INVENTORY' | 'PURCHASE' | 'VOUCHER' | 'AUTH' | 'SETTINGS' | 'EXPENSES';
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  actorName: string;
  actorMobile: string;
  actorRole: string;
  targetId?: string;
  summaryNe: string;
  summaryEn: string;
  details?: string;
}

export interface MaintenanceLog {
  id: string;
  machineId: string;
  dateBs: string;
  description: string;
  cost: number;
  performedBy: string;
}

export interface MachineWorker {
  id: string;
  machineId: string;
  employeeId: string;
  role: string;
  assignedDateBs: string;
}

export interface Machine {
  id: string;
  nameNe: string;
  nameEn: string;
  code: string;
  powerConsumptionPerHr: number; // kWh
  purchaseDateBs: string;
  lastMaintenanceDateBs?: string;
  status: 'ACTIVE' | 'IN_MAINTENANCE' | 'INACTIVE';
}

