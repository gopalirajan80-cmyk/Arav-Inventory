// Accounting module types (Chart of Accounts, Journal, Fixed Assets, TDS, Tax, Budget)

export type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'INCOME' | 'EXPENSE';

export interface Account {
  id: string; // "acc-<code>"
  code: string;
  nameNe: string;
  nameEn: string;
  type: AccountType;
  isSystem?: boolean; // system accounts (auto-posting uses them) cannot be deleted
  isActive: boolean;
  openingBalance: number; // always positive; side tells Dr/Cr
  openingSide: 'DR' | 'CR';
}

export interface JournalLine {
  accountId: string;
  debit: number;
  credit: number;
  note?: string;
}

export interface JournalEntry {
  id: string;
  voucherNo: string;
  dateBs: string;
  narration: string;
  lines: JournalLine[];
  source: 'MANUAL' | 'DEPRECIATION' | 'ASSET' | 'AUTO';
  refKey?: string; // used to stop the same system posting being made twice
  createdAt?: string;
}

export type DepMethod = 'SLM' | 'WDV';

export interface FixedAsset {
  id: string;
  code: string;
  name: string;
  category: string;
  purchaseDateBs: string;
  cost: number;
  salvageValue: number;
  method: DepMethod;
  ratePct: number; // WDV / pool rate
  usefulLifeYears: number; // SLM
  depStartFy: string; // first fiscal year to compute depreciation from, e.g. "082/83"
  openingAccumDep: number; // already depreciated before depStartFy
  status: 'ACTIVE' | 'DISPOSED';
  disposalDateBs?: string;
  disposalAmount?: number;
  notes?: string;
}

export interface BudgetRecord {
  fiscalYear: string;
  amounts: Record<string, number>; // accountId -> annual budget
}

export type TdsDirection = 'DEDUCTED' | 'SUFFERED';

export interface TdsEntry {
  id: string;
  dateBs: string;
  direction: TdsDirection; // DEDUCTED = we withheld (payable to IRD); SUFFERED = customer withheld from us (credit for us)
  partyName: string;
  panNo?: string;
  category: string;
  grossAmount: number;
  ratePct: number;
  tdsAmount: number;
  referenceNo?: string;
  deposited: boolean;
  depositDateBs?: string;
  depositRef?: string;
  notes?: string;
}

export interface TaxSlab {
  width: number | null; // null = remaining income
  rate: number;
}

export type TaxPayerType = 'COMPANY' | 'SPECIAL_INDUSTRY' | 'INDIVIDUAL' | 'CUSTOM';

export interface TaxSettings {
  payerType: TaxPayerType;
  customRate: number;
  slabs: TaxSlab[];
}

export interface TaxAdjustments {
  otherAdditions: number;
  otherDeductions: number;
  taxDepreciation?: number; // if empty -> from asset register
  lossBroughtForward: number;
  advanceTaxPaid: number;
}

export interface AccountingData {
  accounts: Account[];
  journals: JournalEntry[];
  assets: FixedAsset[];
  budgets: BudgetRecord[];
  tds: TdsEntry[];
  taxSettings: TaxSettings;
  taxAdjust: Record<string, TaxAdjustments>; // by fiscal year
}
