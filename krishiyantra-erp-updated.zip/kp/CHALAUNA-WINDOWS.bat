@echo off
setlocal
title KrishiYantra ERP
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto NO_NODE

if exist ".env" goto HAVE_ENV
copy ".env.example" ".env" >nul
:HAVE_ENV
findstr /b /c:"APP_PASSWORD=" ".env" >nul 2>nul
if not errorlevel 1 goto PW_OK
echo.
echo Login password set gareko chhaina. Aafno password lekhnus (English akshar/number matra, space, %% ra ^& ^< ^> ^| nabhaaune):
set "PW="
set /p PW=Password: 
if "%PW%"=="" ( echo Password khali huna hudaina. & pause & exit /b )
>> ".env" echo.
>> ".env" echo APP_PASSWORD="%PW%"
echo Password .env ma save bhayo. Login ID: owner
:PW_OK

if exist "node_modules\tsx" goto HAVE_MODULES
echo Pahilo patak: aawashyak file download hudaichha. Internet chahinchha, kehi minet lagchha...
call npm install --include=dev
if errorlevel 1 goto NPM_FAIL
:HAVE_MODULES

if exist "dist\index.html" goto HAVE_BUILD
echo App banaudai chha, kripaya kurnus...
call npm run build
if errorlevel 1 goto BUILD_FAIL
:HAVE_BUILD

echo.
echo ===== App chaldai chha. Browser aafai khulchha: http://localhost:3000 =====
echo ===== Login ID: owner    Password: .env bhitra ko APP_PASSWORD =====
echo ===== Banda garna yo window band garnus (Ctrl+C) =====
set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if defined CHROME (
  start "" cmd /c "timeout /t 6 >nul & "%CHROME%" http://localhost:3000"
) else (
  start "" cmd /c "timeout /t 6 >nul & start http://localhost:3000"
)
echo ===== Chrome ma address bar ko ekdam daayaan "Install" (kampyutar+tir) icon thichnus -> Install =====
call npm start
pause
exit /b

:NO_NODE
echo Node.js install gareko chhaina.
echo https://nodejs.org bata "LTS" version download garera install garnus, ani yo file pheri kholnus.
pause
exit /b

:NPM_FAIL
echo.
echo npm install fail bhayo. Internet jaanchnus ra pheri yo file kholnus.
echo Tala ko error ko photo/text pathaunus.
pause
exit /b

:BUILD_FAIL
echo.
echo build fail bhayo. Maathi ko error ko photo/text pathaunus.
pause
exit /b
