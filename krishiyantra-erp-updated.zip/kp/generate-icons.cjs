const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');
const path = require('path');

const svgLogo = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <rect width="512" height="512" rx="112" fill="#15803d"/>
  <!-- Inner ring -->
  <circle cx="256" cy="256" r="140" fill="none" stroke="#ffffff" stroke-width="4" opacity="0.5"/>
  
  <!-- Stylized Tractor/Machinery Silhouette -->
  <path d="M160 300 L160 260 L220 260 L220 220 L300 220 L300 300 Z" fill="#ffffff"/>
  <path d="M300 300 L350 300 L350 260 L300 260 Z" fill="#ffffff" opacity="0.8"/>
  
  <!-- Big Rear Wheel (Gear-like) -->
  <circle cx="190" cy="320" r="50" fill="#fbbf24"/>
  <circle cx="190" cy="320" r="40" fill="none" stroke="#15803d" stroke-width="8" stroke-dasharray="10 6"/>
  <circle cx="190" cy="320" r="15" fill="#15803d"/>
  
  <!-- Front Wheel -->
  <circle cx="320" cy="335" r="35" fill="#fbbf24"/>
  <circle cx="320" cy="335" r="10" fill="#15803d"/>

  <!-- Sprout/Agriculture Detail -->
  <path d="M260 210 C260 170 230 150 230 150 C230 150 240 180 260 210" fill="#4ade80"/>
  <path d="M260 210 C260 170 290 150 290 150 C290 150 280 180 260 210" fill="#4ade80"/>
</svg>
`;

async function generate() {
  const publicDir = path.join(process.cwd(), 'public');
  
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  // 1. Update SVG
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgLogo);
  console.log('✓ Updated public/icon.svg');

  const img = await loadImage(`data:image/svg+xml;base64,${Buffer.from(svgLogo).toString('base64')}`);

  // 2. Generate PNGs
  const generatePng = async (name, size, padding = 0) => {
    const canvas = createCanvas(size, size);
    const ctx = canvas.getContext('2d');
    
    if (padding > 0) {
      // For maskable icons, we add a background and center the logo
      ctx.fillStyle = '#15803d';
      ctx.fillRect(0, 0, size, size);
      const innerSize = size * (1 - padding * 2);
      const offset = size * padding;
      ctx.drawImage(img, offset, offset, innerSize, innerSize);
    } else {
      ctx.drawImage(img, 0, 0, size, size);
    }
    
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(publicDir, name), buffer);
    console.log(`✓ Generated public/${name} (${size}x${size})`);
  };

  await generatePng('pwa-192x192.png', 192);
  await generatePng('pwa-512x512.png', 512);
  await generatePng('apple-touch-icon.png', 180);
  await generatePng('pwa-maskable-512x512.png', 512, 0.15); // 15% safe zone for maskable

  console.log('Logo generation complete!');
}

generate().catch(err => {
  console.error('Error generating icons:', err);
  process.exit(1);
});
