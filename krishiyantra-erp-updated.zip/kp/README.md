# KrishiYantra ERP — Nepal VAT & Business Manager

- Deploy, backup र डाटा सुरक्षाको पूरा विवरण: **[DEPLOY.md](DEPLOY.md)**
- स्थानीय रूपमा चलाउन: `npm install` → `npm run dev` (APP_PASSWORD नराखे लगइन बन्द हुन्छ — विकासका लागि मात्र)
- Production: `APP_PASSWORD` र `DATA_DIR` अनिवार्य (`.env.example` हेर्नुहोस्)
- परीक्षण: `npm test`
